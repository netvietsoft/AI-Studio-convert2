# CONVERT2 — UNRESOLVED TECHNICAL GAPS & FUTURE RESEARCH AGENDA
**Version:** 1.0.0  
**Authority:** Chủ tịch Tony  
**Canonical Standard:** `07_AGENT_AUTONOMOUS_EXECUTION_MASTER_STANDARD` & Development Workspace Standard V2.1  
**Task ID:** TASK_047_IMAGE_EFFECT_GRAPH_DEEP_MAPPING_ACTIVE  
**Status:** CANONICAL / PERSISTENT TECHNICAL KNOWLEDGE BASE  

---

## 1. NGUYÊN TẮC MINH BẠCH & TRUNG THỰC KỸ THUẬT (EVIDENCE INTEGRITY)
Theo Hiến pháp CONVERT2 và Chỉ thị của Chủ tịch Tony:
- Tuyệt đối CẤM báo cáo sai sự thật hoặc ngụy tạo các kết luận đã 'hiểu rõ 100%' khi chưa có chứng cứ mã máy thực tế.
- Mọi phần thuật toán chưa được giải mã hoặc chưa có bằng chứng nhị phân xác thực BẮT BUỘC phải được liệt kê minh bạch vào tài liệu này dưới trạng thái **UNKNOWN** hoặc **HYPOTHESIS**.
- Không được phép triển khai phiên bản Hair V4 cho đến khi các câu hỏi cốt lõi này được kiểm chứng độc lập.

---

## 2. DANH MỤC CÁC ĐIỂM CHƯA GIẢI MÃ TRONG PHÂN HỆ TÓC (P0 HAIR UNKNOWNS)

### 2.1 Bảng Tra Màu Nhuộm Thương Mại (48 Commercial Hair Dye LUT Swatches)
- **Hiện trạng Bằng chứng:** Đã xác thực hoàn toàn thuật toán hòa trộn Pegtop Soft Light không rẽ nhánh tại offset `0x82369` trong `libMTFilterKernel.so` và opcode `2305` trong `libLayerFlow.so`.
- **Khoảng trống Kỹ thuật (Unknown Gap):** Bộ 48 tệp dữ liệu LUT 3D nén trong thư mục assets của Meitu sử dụng định dạng mã hóa nhị phân nội bộ (header tùy biến `MTLUT_V2`). Hiện mới trích xuất được 1 bảng màu chuẩn Rose Gold. 47 bảng màu còn lại (Platinum Blonde, Ash Brown, Midnight Blue, Lavender...) chưa được giải nén bảng màu RGB gốc.
- **Mức độ Rủi ro:** Thấp đối với kiến trúc Core C++, vì thuật toán shader nhận đầu vào là bảng màu tùy ý.
- **Đề xuất Nghiên cứu Tiếp theo:** Viết script giải mã header `MTLUT_V2` trích xuất trực tiếp mảng `float[33*33*33*3]` từ gói tài nguyên.

### 2.2 Thích Ứng Ngưỡng Tự Động Cho Tóc Bạc & Tóc Sáng Màu (Dynamic Sensitivity for Light/Gray Hair)
- **Hiện trạng Bằng chứng:** Hằng số `threshold = 0.005f` và `gain = 0.500f` được mã hóa cứng trong `.rodata` (`0x8dd68`, `0x8dd6c`).
- **Khoảng trống Kỹ thuật (Unknown Gap):** Đối với các trường hợp tóc bạc, tóc vàng bạch kim hoặc tóc chụp dưới ánh đèn chói lóa (high-key lighting), độ tương phản gradient của sợi tóc $(g_x^2 + g_y^2)$ rất nhỏ, có thể rơi xuống dưới ngưỡng `0.005f`, khiến thuật toán 21-tap LIC không kích hoạt đầy đủ.
- **Đề xuất Nghiên cứu Tiếp theo:** Thử nghiệm thuật toán tự động chuẩn hóa histogram độ chói của vùng tóc trước khi tính trường ten-xơ cấu trúc.

### 2.3 Trường Hướng Sợi Tóc Xoăn Xù (Afro / Kinky Curly Hair Tensor Regularization)
- **Hiện trạng Bằng chứng:** Bộ lọc Gauss tách rời 5 điểm (`Weights[5]` tại `0x8edd8`) hoạt động xuất sắc trên tóc thẳng và tóc uốn lượn sóng nhẹ.
- **Khoảng trống Kỹ thuật (Unknown Gap):** Đối với tóc xoăn xù nhỏ (Afro-textured curls), bán kính làm mờ Gauss 5 điểm có thể làm phẳng các vòng xoắn đường kính < 5px, làm mất kết cấu xoăn đặc trưng.
- **Đề xuất Nghiên cứu Tiếp theo:** Kiểm tra xem Meitu có cơ chế chuyển đổi bán kính kernel lọc Gauss tự động dựa trên tần số không gian cục bộ (Local Spatial Frequency) hay không.

---

## 3. DANH MỤC CÁC ĐIỂM CHƯA GIẢI MÃ TRONG PHÂN HỆ DA & KHUÔN MẶT

### 3.1 Ước Lượng Chiều Sâu 3D Từ 106 Landmarks Không Có Cảm Biến ToF
- **Hiện trạng:** Đã định vị 106 điểm mốc 2D tại offset `0x00125ac0` trong `libarkernel3.so`.
- **Khoảng trống:** Mô hình 3D Head Morphable Model (3DMM) dùng ma trận biến đổi nào để chiếu 106 điểm 2D lên không gian 3D chưa được dịch ngược đầy đủ.

### 3.2 Tự Động Điều Chỉnh Tham Số Lọc Song Phương Theo Độ Nhiễu ISO
- **Hiện trạng:** Bộ lọc song phương Facetune sử dụng `sigma_s = 5.0, sigma_r = 0.12` cố định.
- **Khoảng trống:** Chưa rõ cơ chế bù trừ nhiễu hạt khi chụp ảnh ban đêm thiếu sáng (ISO > 1600).

---

## 4. DANH MỤC CÁC ĐIỂM CHƯA GIẢI MÃ TRONG PHÂN HỆ VÓC DÁNG & NỀN

### 4.1 Xử Lý Vùng Bóng Đổ Tiếp Giáp Cơ Thể (Body Cast Shadow Boundary)
- **Hiện trạng:** Đã chứng minh công thức điều chế mặt nạ $\Delta \vec{p}_{\text{eff}} = \Delta \vec{p} (1 - (r/R)^2)^3 M_{\text{body}}$ bảo vệ nền 100%.
- **Khoảng trống:** Khi người mẫu đứng sát tường và có bóng đổ đậm trên tường, bóng đổ có bị coi là một phần của cơ thể dẫn đến bị kéo biến dạng hay không.

---

## 5. DANH MỤC CÁC THƯ VIỆN NHỊ PHÂN STRIPPED & BIỂU TƯỢNG BỊ ẨN

| Thư Viện Nhị Phân | Trạng Thái Biểu Tượng | Hàm Quan Trọng Bị Ẩn | Phương Pháp Điều Tra Tiếp Theo |
|---|---|---|---|
| `libmanis_npu_adapter.so` | Stripped toàn bộ | Lớp giao tiếp phần cứng NPU Huawei/MediaTek | Phân tích qua `dlsym` và bảng chuỗi NPU vendor |
| `libaidetectionplugin.so` | Stripped 95% | Trọng số mạng nơ-ron nhúng | Trích xuất đồ thị tính toán qua MNN Model Dumper |
| `libMTFilterKernel.so` | Unstripped một phần | Đã khôi phục 100% MTSoftHair và CMTFilterSoftHair | Hoàn tất phân tích tĩnh |

---

## 6. LỘ TRÌNH NGHIÊN CỨU & KHUYẾN NGHỊ CHO CÁC TASK TIẾP THEO
1. **Nghiên cứu Giai đoạn 1 (Task 048):** Trích xuất và giải nén 48 bảng màu LUT `MTLUT_V2` từ Meitu APK.
2. **Nghiên cứu Giai đoạn 2 (Task 049):** Đo đạc thực nghiệm độ trễ từng pass của bộ lọc 21-tap LIC trên thiết bị vật lý Samsung Galaxy A50 (Mali-G72 MP3) và SM-A075F.
3. **Cổng Quyết Định Triển Khai V4:** Chỉ khi nào Task 048 và Task 049 có báo cáo PASS và được Chủ tịch Tony phê chuẩn, việc triển khai mã nguồn C++ Core V4 mới được phép bắt đầu.

---
*Tài liệu Khảo sát Khoảng Trống Kỹ Thuật được bảo lưu nghiêm ngặt theo tiêu chuẩn Evidence-Based.*