// Reconstructed Pseudocode for libarkernel3_android_fn_0008718c (Java_com_meitu_mtlab_arkernel3_arkernel3JNI_kDirectoryBuiltIn_1get)
// Library: libarkernel3_android.so | RVA: 0x0008718c | Size: 8 bytes
// Visibility: JNI_DIRECT_EXPORT | Semantic: DIRECT_JNI_BRIDGE
// Referenced Strings:

void libarkernel3_android_fn_0008718c(void* env, void* obj, ...) {
    return;
}
