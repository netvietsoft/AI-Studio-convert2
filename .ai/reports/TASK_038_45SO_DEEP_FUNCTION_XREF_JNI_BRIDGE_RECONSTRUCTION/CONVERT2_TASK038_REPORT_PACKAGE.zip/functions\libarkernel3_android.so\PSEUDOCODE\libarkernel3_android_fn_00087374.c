// Reconstructed Pseudocode for libarkernel3_android_fn_00087374 (Java_com_meitu_mtlab_arkernel3_arkernel3JNI_kParamFlagCustomPosition_1get)
// Library: libarkernel3_android.so | RVA: 0x00087374 | Size: 8 bytes
// Visibility: JNI_DIRECT_EXPORT | Semantic: DIRECT_JNI_BRIDGE
// Referenced Strings:

void libarkernel3_android_fn_00087374(void* env, void* obj, ...) {
    return;
}
