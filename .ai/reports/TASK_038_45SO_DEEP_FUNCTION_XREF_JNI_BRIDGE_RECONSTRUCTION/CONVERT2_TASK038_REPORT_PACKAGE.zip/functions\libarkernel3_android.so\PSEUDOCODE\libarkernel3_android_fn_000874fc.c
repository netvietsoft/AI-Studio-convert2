// Reconstructed Pseudocode for libarkernel3_android_fn_000874fc (Java_com_meitu_mtlab_arkernel3_arkernel3JNI_kPartTypeStroke_1get)
// Library: libarkernel3_android.so | RVA: 0x000874fc | Size: 8 bytes
// Visibility: JNI_DIRECT_EXPORT | Semantic: DIRECT_JNI_BRIDGE
// Referenced Strings:

void libarkernel3_android_fn_000874fc(void* env, void* obj, ...) {
    return;
}
