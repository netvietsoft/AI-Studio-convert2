
F:\CONVERT\com.mt.mtxx.mtxx\SOURCE\extracted_native_libs\lib\arm64-v8a\libMTGif.so:	file format elf64-littleaarch64

Disassembly of section .text:

00000000000085c4 <.text>:
    85c4:      	bti	c
    85c8:      	nop
    85cc:      	adr	x0, 0x17420
    85d0:      	b	0x12a80 <__cxa_finalize@plt>
    85d4:      	bti	c
    85d8:      	ret
    85dc:      	bti	c
    85e0:      	b	0x85d4 <.text+0x10>
    85e4:      	bti	c
    85e8:      	cbz	x0, 0x85f4 <.text+0x30>
    85ec:      	mov	x16, x0
    85f0:      	br	x16
    85f4:      	ret
    85f8:      	bti	c
    85fc:      	mov	x1, x0
    8600:      	nop
    8604:      	adr	x0, 0x85e4 <.text+0x20>
    8608:      	nop
    860c:      	adr	x2, 0x17420
    8610:      	b	0x12a90 <__cxa_atexit@plt>

0000000000008614 <_ZN13FormatConvert15AllocMediaCoderEv>:
    8614:      	stp	x29, x30, [sp, #-0x10]!
    8618:      	mov	x29, sp
    861c:      	mov	w0, #0x28               // =40
    8620:      	bl	0x12aa0 <malloc@plt>
    8624:      	cbz	x0, 0x8638 <_ZN13FormatConvert15AllocMediaCoderEv+0x24>
    8628:      	movi	v0.2d, #0000000000000000
    862c:      	mov	w8, #-0x1               // =-1
    8630:      	str	w8, [x0, #0x20]
    8634:      	stp	q0, q0, [x0]
    8638:      	ldp	x29, x30, [sp], #0x10
    863c:      	ret

0000000000008640 <_ZN13FormatConvert18ImageParamsInitialEPNS_12_ImageParamsE>:
    8640:      	cbz	x0, 0x8668 <_ZN13FormatConvert18ImageParamsInitialEPNS_12_ImageParamsE+0x28>
    8644:      	mov	w8, #-0x1               // =-1
    8648:      	stp	wzr, wzr, [x0, #0x4]
    864c:      	str	w8, [x0]
    8650:      	mov	w8, #0x1                // =1
    8654:      	str	xzr, [x0, #0x10]
    8658:      	str	w8, [x0, #0x18]
    865c:      	stur	xzr, [x0, #0x24]
    8660:      	stur	xzr, [x0, #0x1c]
    8664:      	str	wzr, [x0, #0x2c]
    8668:      	ret

000000000000866c <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv>:
    866c:      	sub	sp, sp, #0x70
    8670:      	stp	x29, x30, [sp, #0x20]
    8674:      	stp	x26, x25, [sp, #0x30]
    8678:      	stp	x24, x23, [sp, #0x40]
    867c:      	stp	x22, x21, [sp, #0x50]
    8680:      	stp	x20, x19, [sp, #0x60]
    8684:      	add	x29, sp, #0x20
    8688:      	mrs	x23, TPIDR_EL0
    868c:      	ldr	x8, [x23, #0x28]
    8690:      	stur	x8, [x29, #-0x8]
    8694:      	cbz	x0, 0x88b0 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x244>
    8698:      	mov	x19, x0
    869c:      	bl	0x12ab0 <av_packet_alloc@plt>
    86a0:      	ldr	w8, [x19, #0xb0]
    86a4:      	mov	x20, x0
    86a8:      	str	x0, [sp, #0x10]
    86ac:      	cbz	x0, 0x8860 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x1f4>
    86b0:      	mov	w24, #0x8c              // =140
    86b4:      	tst	w8, w24
    86b8:      	b.ne	0x8870 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x204>
    86bc:      	adrp	x25, 0x17000 <syscall@plt+0x3bf0>
    86c0:      	add	x26, x19, #0x110
    86c4:      	mov	x21, x20
    86c8:      	ldr	x25, [x25, #0x7a8]
    86cc:      	b	0x86e4 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x78>
    86d0:      	add	x0, x19, #0xb4
    86d4:      	bl	0x12ac0 <pthread_mutex_unlock@plt>
    86d8:      	ldrb	w8, [x19, #0xb0]
    86dc:      	tst	w8, w24
    86e0:      	b.ne	0x886c <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x200>
    86e4:      	ldrsw	x8, [x25]
    86e8:      	ldr	x9, [x19, #0x120]
    86ec:      	cmp	x9, x8
    86f0:      	b.ne	0x871c <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0xb0>
    86f4:      	add	x0, x19, #0xb4
    86f8:      	bl	0x12ad0 <pthread_mutex_lock@plt>
    86fc:      	ldrsw	x8, [x25]
    8700:      	ldr	x9, [x19, #0x120]
    8704:      	cmp	x9, x8
    8708:      	b.ne	0x86d0 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x64>
    870c:      	add	x0, x19, #0xdc
    8710:      	add	x1, x19, #0xb4
    8714:      	bl	0x12ae0 <pthread_cond_wait@plt>
    8718:      	b	0x86d0 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x64>
    871c:      	ldr	x8, [x19, #0x10]
    8720:      	mov	x1, x21
    8724:      	ldr	x0, [x8]
    8728:      	bl	0x12af0 <av_read_frame@plt>
    872c:      	tbnz	w0, #0x1f, 0x880c <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x1a0>
    8730:      	ldr	x8, [x19, #0x10]
    8734:      	ldr	w9, [x21, #0x24]
    8738:      	ldr	w10, [x8, #0x20]
    873c:      	cmp	w9, w10
    8740:      	b.ne	0x881c <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x1b0>
    8744:      	ldr	x0, [x8, #0x10]
    8748:      	mov	x1, x21
    874c:      	bl	0x12b00 <avcodec_send_packet@plt>
    8750:      	ldr	x21, [sp, #0x10]
    8754:      	mov	w22, w0
    8758:      	mov	x0, x21
    875c:      	bl	0x12b10 <av_packet_unref@plt>
    8760:      	cmn	w22, #0xb
    8764:      	b.eq	0x86d8 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x6c>
    8768:      	cbnz	w22, 0x8828 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x1bc>
    876c:      	bl	0x12b20 <av_frame_alloc@plt>
    8770:      	str	x0, [sp, #0x8]
    8774:      	cbz	x0, 0x8838 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x1cc>
    8778:      	ldr	x8, [x19, #0x10]
    877c:      	mov	x1, x0
    8780:      	ldr	x0, [x8, #0x10]
    8784:      	bl	0x12b30 <avcodec_receive_frame@plt>
    8788:      	cmn	w0, #0xb
    878c:      	b.eq	0x8854 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x1e8>
    8790:      	cbnz	w0, 0x8848 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x1dc>
    8794:      	ldr	x0, [sp, #0x8]
    8798:      	bl	0x12b40 <av_frame_get_best_effort_timestamp@plt>
    879c:      	ldr	x8, [sp, #0x8]
    87a0:      	ldr	x9, [x19, #0x20]
    87a4:      	str	x0, [x8, #0x88]
    87a8:      	cbz	x9, 0x87c4 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x158>
    87ac:      	add	x1, sp, #0x8
    87b0:      	mov	x0, x19
    87b4:      	bl	0x12b50 <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame@plt>
    87b8:      	cbnz	w0, 0x8854 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x1e8>
    87bc:      	ldr	x8, [sp, #0x8]
    87c0:      	cbz	x8, 0x86d8 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x6c>
    87c4:      	add	x0, x19, #0xb4
    87c8:      	bl	0x12ad0 <pthread_mutex_lock@plt>
    87cc:      	mov	w0, #0x18               // =24
    87d0:      	bl	0x12b60 <_Znwm@plt>
    87d4:      	ldr	x8, [sp, #0x8]
    87d8:      	ldr	x9, [x19, #0x110]
    87dc:      	str	x0, [x19, #0x110]
    87e0:      	stp	x26, x8, [x0, #0x8]
    87e4:      	ldr	x8, [x19, #0x120]
    87e8:      	str	x9, [x0]
    87ec:      	str	x0, [x9, #0x8]
    87f0:      	add	x8, x8, #0x1
    87f4:      	add	x0, x19, #0xb4
    87f8:      	str	x8, [x19, #0x120]
    87fc:      	bl	0x12ac0 <pthread_mutex_unlock@plt>
    8800:      	add	x0, x19, #0xdc
    8804:      	bl	0x12b70 <pthread_cond_signal@plt>
    8808:      	b	0x86d8 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x6c>
    880c:      	ldr	w8, [x19, #0xb0]
    8810:      	orr	w8, w8, #0x8
    8814:      	str	w8, [x19, #0xb0]
    8818:      	b	0x86d8 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x6c>
    881c:      	mov	x0, x21
    8820:      	bl	0x12b10 <av_packet_unref@plt>
    8824:      	b	0x86d8 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x6c>
    8828:      	ldr	w8, [x19, #0xb0]
    882c:      	orr	w8, w8, #0x80
    8830:      	str	w8, [x19, #0xb0]
    8834:      	b	0x86d8 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x6c>
    8838:      	ldr	w8, [x19, #0xb0]
    883c:      	orr	w8, w8, #0x4
    8840:      	str	w8, [x19, #0xb0]
    8844:      	b	0x86d8 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x6c>
    8848:      	ldr	w8, [x19, #0xb0]
    884c:      	orr	w8, w8, #0x80
    8850:      	str	w8, [x19, #0xb0]
    8854:      	add	x0, sp, #0x8
    8858:      	bl	0x12b80 <av_frame_free@plt>
    885c:      	b	0x86d8 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x6c>
    8860:      	orr	w8, w8, #0x4
    8864:      	str	w8, [x19, #0xb0]
    8868:      	b	0x8878 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x20c>
    886c:      	cbz	x21, 0x8878 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x20c>
    8870:      	add	x0, sp, #0x10
    8874:      	bl	0x12b90 <av_packet_free@plt>
    8878:      	mov	x0, x19
    887c:      	bl	0x12ba0 <_ZN13FormatConvert18VideoFormatTranser6_flushEv@plt>
    8880:      	add	x0, x19, #0xb4
    8884:      	bl	0x12ad0 <pthread_mutex_lock@plt>
    8888:      	ldr	w8, [x19, #0xb0]
    888c:      	add	x0, x19, #0xb4
    8890:      	orr	w8, w8, #0x20
    8894:      	str	w8, [x19, #0xb0]
    8898:      	bl	0x12ac0 <pthread_mutex_unlock@plt>
    889c:      	add	x0, x19, #0xdc
    88a0:      	bl	0x12b70 <pthread_cond_signal@plt>
    88a4:      	cbnz	x20, 0x88b0 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x244>
    88a8:      	mov	x0, x19
    88ac:      	bl	0x12bb0 <_ZN13FormatConvert18VideoFormatTranser8_releaseEv@plt>
    88b0:      	ldr	x8, [x23, #0x28]
    88b4:      	ldur	x9, [x29, #-0x8]
    88b8:      	cmp	x8, x9
    88bc:      	b.ne	0x88e0 <_ZN13FormatConvert18VideoFormatTranser24ThreadFunc_Video_DecoderEPv+0x274>
    88c0:      	mov	x0, xzr
    88c4:      	ldp	x20, x19, [sp, #0x60]
    88c8:      	ldp	x22, x21, [sp, #0x50]
    88cc:      	ldp	x24, x23, [sp, #0x40]
    88d0:      	ldp	x26, x25, [sp, #0x30]
    88d4:      	ldp	x29, x30, [sp, #0x20]
    88d8:      	add	sp, sp, #0x70
    88dc:      	ret
    88e0:      	bl	0x12bc0 <__stack_chk_fail@plt>

00000000000088e4 <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame>:
    88e4:      	sub	sp, sp, #0x50
    88e8:      	stp	x29, x30, [sp, #0x10]
    88ec:      	str	x23, [sp, #0x20]
    88f0:      	stp	x22, x21, [sp, #0x30]
    88f4:      	stp	x20, x19, [sp, #0x40]
    88f8:      	add	x29, sp, #0x10
    88fc:      	mrs	x22, TPIDR_EL0
    8900:      	ldr	x8, [x22, #0x28]
    8904:      	str	x8, [sp, #0x8]
    8908:      	cbz	x1, 0x89f4 <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame+0x110>
    890c:      	ldr	x8, [x1]
    8910:      	mov	x19, x1
    8914:      	cbz	x8, 0x89f4 <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame+0x110>
    8918:      	mov	x21, x0
    891c:      	bl	0x12b20 <av_frame_alloc@plt>
    8920:      	str	x0, [sp]
    8924:      	cbz	x0, 0x89f4 <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame+0x110>
    8928:      	ldr	w8, [x21, #0x70]
    892c:      	cmp	w8, #0x9
    8930:      	b.hs	0x8a20 <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame+0x13c>
    8934:      	ldp	s1, s0, [x21, #0x74]
    8938:      	nop
    893c:      	adr	x23, 0x614c
    8940:      	ldr	w5, [x21, #0x88]
    8944:      	add	x1, x0, #0x40
    8948:      	ldr	w4, [x23, x8, lsl #2]
    894c:      	mov	x20, x0
    8950:      	fcvtzs	w3, s0
    8954:      	fcvtzs	w2, s1
    8958:      	bl	0x12bd0 <av_image_alloc@plt>
    895c:      	tbnz	w0, #0x1f, 0x89dc <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame+0xf8>
    8960:      	ldr	x8, [x20]
    8964:      	ldr	x0, [x21, #0x20]
    8968:      	add	x6, x20, #0x40
    896c:      	mov	w3, wzr
    8970:      	mov	x5, x20
    8974:      	str	x8, [x20, #0xb0]
    8978:      	ldr	x1, [x19]
    897c:      	ldr	w4, [x1, #0x6c]
    8980:      	add	x2, x1, #0x40
    8984:      	bl	0x12be0 <sws_scale@plt>
    8988:      	cmp	w0, #0x1
    898c:      	b.lt	0x89dc <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame+0xf8>
    8990:      	ldur	d0, [x21, #0x74]
    8994:      	ldr	x0, [x19]
    8998:      	ldr	w8, [x21, #0x70]
    899c:      	fcvtzs	v0.2s, v0.2s
    89a0:      	ldr	x9, [x0, #0x88]
    89a4:      	cmp	w8, #0x9
    89a8:      	str	x9, [x20, #0x88]
    89ac:      	str	d0, [x20, #0x68]
    89b0:      	b.hs	0x8a20 <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame+0x13c>
    89b4:      	ldr	w8, [x23, x8, lsl #2]
    89b8:      	ldr	x9, [x0, #0xb0]!
    89bc:      	str	w8, [x20, #0x74]
    89c0:      	cbz	x9, 0x89c8 <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame+0xe4>
    89c4:      	bl	0x12bf0 <av_freep@plt>
    89c8:      	mov	x0, x19
    89cc:      	bl	0x12b80 <av_frame_free@plt>
    89d0:      	mov	w0, wzr
    89d4:      	str	x20, [x19]
    89d8:      	b	0x89f8 <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame+0x114>
    89dc:      	ldr	x8, [x20, #0xb0]!
    89e0:      	cbz	x8, 0x89ec <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame+0x108>
    89e4:      	mov	x0, x20
    89e8:      	bl	0x12bf0 <av_freep@plt>
    89ec:      	mov	x0, sp
    89f0:      	bl	0x12b80 <av_frame_free@plt>
    89f4:      	mov	w0, #-0x1               // =-1
    89f8:      	ldr	x8, [x22, #0x28]
    89fc:      	ldr	x9, [sp, #0x8]
    8a00:      	cmp	x8, x9
    8a04:      	b.ne	0x8a38 <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame+0x154>
    8a08:      	ldp	x20, x19, [sp, #0x40]
    8a0c:      	ldr	x23, [sp, #0x20]
    8a10:      	ldp	x22, x21, [sp, #0x30]
    8a14:      	ldp	x29, x30, [sp, #0x10]
    8a18:      	add	sp, sp, #0x50
    8a1c:      	ret
    8a20:      	ldr	x8, [x22, #0x28]
    8a24:      	ldr	x9, [sp, #0x8]
    8a28:      	cmp	x8, x9
    8a2c:      	b.ne	0x8a38 <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame+0x154>
    8a30:      	mov	w0, wzr
    8a34:      	bl	0x12c00 <exit@plt>
    8a38:      	bl	0x12bc0 <__stack_chk_fail@plt>

0000000000008a3c <_ZN13FormatConvert18VideoFormatTranser6_flushEv>:
    8a3c:      	sub	sp, sp, #0x40
    8a40:      	stp	x29, x30, [sp, #0x10]
    8a44:      	stp	x22, x21, [sp, #0x20]
    8a48:      	stp	x20, x19, [sp, #0x30]
    8a4c:      	add	x29, sp, #0x10
    8a50:      	mrs	x20, TPIDR_EL0
    8a54:      	mov	x19, x0
    8a58:      	mov	x1, xzr
    8a5c:      	ldr	x8, [x20, #0x28]
    8a60:      	str	x8, [sp, #0x8]
    8a64:      	ldr	x9, [x0, #0x10]
    8a68:      	ldr	w8, [x0, #0xb0]
    8a6c:      	ldr	x0, [x9, #0x10]
    8a70:      	orr	w8, w8, #0x40
    8a74:      	str	w8, [x19, #0xb0]
    8a78:      	bl	0x12b00 <avcodec_send_packet@plt>
    8a7c:      	ldrb	w8, [x19, #0xb0]
    8a80:      	tbnz	w8, #0x2, 0x8bbc <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0x180>
    8a84:      	adrp	x21, 0x17000 <syscall@plt+0x3bf0>
    8a88:      	add	x22, x19, #0x110
    8a8c:      	ldr	x21, [x21, #0x7a8]
    8a90:      	b	0x8aa4 <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0x68>
    8a94:      	add	x0, x19, #0xb4
    8a98:      	bl	0x12ac0 <pthread_mutex_unlock@plt>
    8a9c:      	ldrb	w8, [x19, #0xb0]
    8aa0:      	tbnz	w8, #0x2, 0x8bbc <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0x180>
    8aa4:      	ldrsw	x8, [x21]
    8aa8:      	ldr	x9, [x19, #0x120]
    8aac:      	cmp	x9, x8
    8ab0:      	b.ne	0x8adc <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0xa0>
    8ab4:      	add	x0, x19, #0xb4
    8ab8:      	bl	0x12ad0 <pthread_mutex_lock@plt>
    8abc:      	ldrsw	x8, [x21]
    8ac0:      	ldr	x9, [x19, #0x120]
    8ac4:      	cmp	x9, x8
    8ac8:      	b.ne	0x8a94 <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0x58>
    8acc:      	add	x0, x19, #0xdc
    8ad0:      	add	x1, x19, #0xb4
    8ad4:      	bl	0x12ae0 <pthread_cond_wait@plt>
    8ad8:      	b	0x8a94 <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0x58>
    8adc:      	bl	0x12b20 <av_frame_alloc@plt>
    8ae0:      	str	x0, [sp]
    8ae4:      	cbz	x0, 0x8b30 <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0xf4>
    8ae8:      	ldr	x8, [x19, #0x10]
    8aec:      	mov	x1, x0
    8af0:      	ldr	x0, [x8, #0x10]
    8af4:      	bl	0x12b30 <avcodec_receive_frame@plt>
    8af8:      	cbnz	w0, 0x8b90 <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0x154>
    8afc:      	ldr	x0, [sp]
    8b00:      	bl	0x12b40 <av_frame_get_best_effort_timestamp@plt>
    8b04:      	ldr	x8, [sp]
    8b08:      	ldr	x9, [x19, #0x20]
    8b0c:      	str	x0, [x8, #0x88]
    8b10:      	cbz	x9, 0x8b48 <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0x10c>
    8b14:      	mov	x1, sp
    8b18:      	mov	x0, x19
    8b1c:      	bl	0x12b50 <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame@plt>
    8b20:      	cbz	w0, 0x8b40 <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0x104>
    8b24:      	mov	x0, sp
    8b28:      	bl	0x12b80 <av_frame_free@plt>
    8b2c:      	b	0x8a9c <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0x60>
    8b30:      	ldr	w8, [x19, #0xb0]
    8b34:      	orr	w8, w8, #0x4
    8b38:      	str	w8, [x19, #0xb0]
    8b3c:      	b	0x8a9c <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0x60>
    8b40:      	ldr	x8, [sp]
    8b44:      	cbz	x8, 0x8a9c <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0x60>
    8b48:      	add	x0, x19, #0xb4
    8b4c:      	bl	0x12ad0 <pthread_mutex_lock@plt>
    8b50:      	mov	w0, #0x18               // =24
    8b54:      	bl	0x12b60 <_Znwm@plt>
    8b58:      	ldr	x8, [sp]
    8b5c:      	ldr	x9, [x19, #0x110]
    8b60:      	str	x0, [x19, #0x110]
    8b64:      	stp	x22, x8, [x0, #0x8]
    8b68:      	ldr	x8, [x19, #0x120]
    8b6c:      	str	x9, [x0]
    8b70:      	str	x0, [x9, #0x8]
    8b74:      	add	x8, x8, #0x1
    8b78:      	add	x0, x19, #0xb4
    8b7c:      	str	x8, [x19, #0x120]
    8b80:      	bl	0x12ac0 <pthread_mutex_unlock@plt>
    8b84:      	add	x0, x19, #0xdc
    8b88:      	bl	0x12b70 <pthread_cond_signal@plt>
    8b8c:      	b	0x8a9c <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0x60>
    8b90:      	mov	w8, #0xb0bb             // =45243
    8b94:      	movk	w8, #0xdfb9, lsl #16
    8b98:      	cmp	w0, w8
    8b9c:      	b.eq	0x8bb4 <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0x178>
    8ba0:      	cmn	w0, #0xb
    8ba4:      	b.eq	0x8bb4 <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0x178>
    8ba8:      	ldr	w8, [x19, #0xb0]
    8bac:      	orr	w8, w8, #0x80
    8bb0:      	str	w8, [x19, #0xb0]
    8bb4:      	mov	x0, sp
    8bb8:      	bl	0x12b80 <av_frame_free@plt>
    8bbc:      	ldr	x8, [x20, #0x28]
    8bc0:      	ldr	x9, [sp, #0x8]
    8bc4:      	cmp	x8, x9
    8bc8:      	b.ne	0x8be0 <_ZN13FormatConvert18VideoFormatTranser6_flushEv+0x1a4>
    8bcc:      	ldp	x20, x19, [sp, #0x30]
    8bd0:      	ldp	x22, x21, [sp, #0x20]
    8bd4:      	ldp	x29, x30, [sp, #0x10]
    8bd8:      	add	sp, sp, #0x40
    8bdc:      	ret
    8be0:      	bl	0x12bc0 <__stack_chk_fail@plt>

0000000000008be4 <_ZN13FormatConvert18VideoFormatTranser8_releaseEv>:
    8be4:      	stp	x29, x30, [sp, #-0x20]!
    8be8:      	str	x19, [sp, #0x10]
    8bec:      	mov	x29, sp
    8bf0:      	ldr	x8, [x0, #0x10]
    8bf4:      	mov	x19, x0
    8bf8:      	ldr	x0, [x8, #0x10]
    8bfc:      	cbz	x0, 0x8c28 <_ZN13FormatConvert18VideoFormatTranser8_releaseEv+0x44>
    8c00:      	bl	0x12c10 <avcodec_is_open@plt>
    8c04:      	cbz	w0, 0x8c14 <_ZN13FormatConvert18VideoFormatTranser8_releaseEv+0x30>
    8c08:      	ldr	x8, [x19, #0x10]
    8c0c:      	ldr	x0, [x8, #0x10]
    8c10:      	bl	0x12c20 <avcodec_close@plt>
    8c14:      	ldr	x8, [x19, #0x10]
    8c18:      	add	x0, x8, #0x10
    8c1c:      	bl	0x12c30 <avcodec_free_context@plt>
    8c20:      	ldr	x8, [x19, #0x10]
    8c24:      	stp	xzr, xzr, [x8, #0x10]
    8c28:      	ldr	x0, [x19, #0x18]
    8c2c:      	ldr	x8, [x0, #0x10]
    8c30:      	cbz	x8, 0x8c60 <_ZN13FormatConvert18VideoFormatTranser8_releaseEv+0x7c>
    8c34:      	mov	x0, x8
    8c38:      	bl	0x12c10 <avcodec_is_open@plt>
    8c3c:      	cbz	w0, 0x8c4c <_ZN13FormatConvert18VideoFormatTranser8_releaseEv+0x68>
    8c40:      	ldr	x8, [x19, #0x18]
    8c44:      	ldr	x0, [x8, #0x10]
    8c48:      	bl	0x12c20 <avcodec_close@plt>
    8c4c:      	ldr	x8, [x19, #0x18]
    8c50:      	add	x0, x8, #0x10
    8c54:      	bl	0x12c30 <avcodec_free_context@plt>
    8c58:      	ldr	x0, [x19, #0x18]
    8c5c:      	stp	xzr, xzr, [x0, #0x10]
    8c60:      	ldr	x8, [x0]
    8c64:      	cbz	x8, 0x8c6c <_ZN13FormatConvert18VideoFormatTranser8_releaseEv+0x88>
    8c68:      	bl	0x12c40 <avformat_close_input@plt>
    8c6c:      	ldr	x0, [x19, #0x10]
    8c70:      	ldr	x8, [x0]
    8c74:      	cbz	x8, 0x8c80 <_ZN13FormatConvert18VideoFormatTranser8_releaseEv+0x9c>
    8c78:      	bl	0x12c40 <avformat_close_input@plt>
    8c7c:      	ldr	x0, [x19, #0x10]
    8c80:      	ldp	x9, x8, [x19, #0x18]
    8c84:      	str	xzr, [x0, #0x8]
    8c88:      	str	xzr, [x9, #0x8]
    8c8c:      	cbz	x8, 0x8c9c <_ZN13FormatConvert18VideoFormatTranser8_releaseEv+0xb8>
    8c90:      	mov	x0, x8
    8c94:      	bl	0x12c50 <sws_freeContext@plt>
    8c98:      	str	xzr, [x19, #0x20]
    8c9c:      	mov	w8, #0x1                // =1
    8ca0:      	mov	w0, wzr
    8ca4:      	str	w8, [x19, #0xb0]
    8ca8:      	ldr	x19, [sp, #0x10]
    8cac:      	ldp	x29, x30, [sp], #0x20
    8cb0:      	ret

0000000000008cb4 <_ZN13FormatConvert18VideoFormatTranserC2Ev>:
    8cb4:      	stp	x29, x30, [sp, #-0x30]!
    8cb8:      	stp	x22, x21, [sp, #0x10]
    8cbc:      	stp	x20, x19, [sp, #0x20]
    8cc0:      	mov	x29, sp
    8cc4:      	add	x19, x0, #0x110
    8cc8:      	mov	x20, x0
    8ccc:      	str	xzr, [x0, #0x120]
    8cd0:      	stp	x19, x19, [x0, #0x110]
    8cd4:      	mov	w0, #0x28               // =40
    8cd8:      	bl	0x12aa0 <malloc@plt>
    8cdc:      	cbz	x0, 0x8cf0 <_ZN13FormatConvert18VideoFormatTranserC2Ev+0x3c>
    8ce0:      	movi	v0.2d, #0000000000000000
    8ce4:      	mov	w8, #-0x1               // =-1
    8ce8:      	str	w8, [x0, #0x20]
    8cec:      	stp	q0, q0, [x0]
    8cf0:      	str	x0, [x20, #0x10]
    8cf4:      	mov	w0, #0x28               // =40
    8cf8:      	bl	0x12aa0 <malloc@plt>
    8cfc:      	cbz	x0, 0x8d10 <_ZN13FormatConvert18VideoFormatTranserC2Ev+0x5c>
    8d00:      	movi	v0.2d, #0000000000000000
    8d04:      	mov	w8, #-0x1               // =-1
    8d08:      	str	w8, [x0, #0x20]
    8d0c:      	stp	q0, q0, [x0]
    8d10:      	stp	x0, xzr, [x20, #0x18]
    8d14:      	str	xzr, [x20, #0x8]
    8d18:      	stp	xzr, xzr, [x20, #0xa0]
    8d1c:      	add	x0, x20, #0xdc
    8d20:      	mov	x1, xzr
    8d24:      	bl	0x12c60 <pthread_cond_init@plt>
    8d28:      	add	x0, x20, #0xb4
    8d2c:      	mov	x1, xzr
    8d30:      	bl	0x12c70 <pthread_mutex_init@plt>
    8d34:      	movi	d0, #0000000000000000
    8d38:      	mov	w8, #-0x1               // =-1
    8d3c:      	mov	w21, #0x1               // =1
    8d40:      	str	w8, [x20, #0x40]
    8d44:      	mov	x8, #-0x100000000       // =-4294967296
    8d48:      	stur	x8, [x20, #0x6c]
    8d4c:      	ldr	x8, [x20, #0x120]
    8d50:      	str	xzr, [x20, #0x50]
    8d54:      	stur	xzr, [x20, #0x64]
    8d58:      	str	w21, [x20, #0x58]
    8d5c:      	stur	d0, [x20, #0x44]
    8d60:      	stur	xzr, [x20, #0x5c]
    8d64:      	stur	d0, [x20, #0x74]
    8d68:      	str	xzr, [x20, #0x80]
    8d6c:      	str	w21, [x20, #0x88]
    8d70:      	stur	xzr, [x20, #0x94]
    8d74:      	stur	xzr, [x20, #0x8c]
    8d78:      	str	wzr, [x20, #0x9c]
    8d7c:      	str	wzr, [x20]
    8d80:      	cbz	x8, 0x8db8 <_ZN13FormatConvert18VideoFormatTranserC2Ev+0x104>
    8d84:      	ldp	x8, x0, [x20, #0x110]
    8d88:      	str	xzr, [x20, #0x120]
    8d8c:      	ldr	x8, [x8, #0x8]
    8d90:      	ldr	x9, [x0]
    8d94:      	cmp	x0, x19
    8d98:      	str	x8, [x9, #0x8]
    8d9c:      	str	x9, [x8]
    8da0:      	b.eq	0x8db8 <_ZN13FormatConvert18VideoFormatTranserC2Ev+0x104>
    8da4:      	ldr	x22, [x0, #0x8]
    8da8:      	bl	0x12c80 <_ZdlPv@plt>
    8dac:      	cmp	x22, x19
    8db0:      	mov	x0, x22
    8db4:      	b.ne	0x8da4 <_ZN13FormatConvert18VideoFormatTranserC2Ev+0xf0>
    8db8:      	str	w21, [x20, #0xb0]
    8dbc:      	ldp	x20, x19, [sp, #0x20]
    8dc0:      	ldp	x22, x21, [sp, #0x10]
    8dc4:      	ldp	x29, x30, [sp], #0x30
    8dc8:      	ret
    8dcc:      	mov	x20, x0
    8dd0:      	mov	x0, x19
    8dd4:      	bl	0x8de0 <_ZN13FormatConvert18VideoFormatTranserC2Ev+0x12c>
    8dd8:      	mov	x0, x20
    8ddc:      	bl	0xeda0 <_ZN5mtgif9Video2Gif3runEv+0x3c8>
    8de0:      	ldr	x8, [x0, #0x10]
    8de4:      	cbz	x8, 0x8e38 <_ZN13FormatConvert18VideoFormatTranserC2Ev+0x184>
    8de8:      	stp	x29, x30, [sp, #-0x20]!
    8dec:      	stp	x20, x19, [sp, #0x10]
    8df0:      	mov	x29, sp
    8df4:      	mov	x19, x0
    8df8:      	ldr	x0, [x0, #0x8]
    8dfc:      	ldr	x8, [x19]
    8e00:      	str	xzr, [x19, #0x10]
    8e04:      	ldr	x9, [x0]
    8e08:      	cmp	x0, x19
    8e0c:      	ldr	x8, [x8, #0x8]
    8e10:      	str	x8, [x9, #0x8]
    8e14:      	str	x9, [x8]
    8e18:      	b.eq	0x8e30 <_ZN13FormatConvert18VideoFormatTranserC2Ev+0x17c>
    8e1c:      	ldr	x20, [x0, #0x8]
    8e20:      	bl	0x12c80 <_ZdlPv@plt>
    8e24:      	cmp	x20, x19
    8e28:      	mov	x0, x20
    8e2c:      	b.ne	0x8e1c <_ZN13FormatConvert18VideoFormatTranserC2Ev+0x168>
    8e30:      	ldp	x20, x19, [sp, #0x10]
    8e34:      	ldp	x29, x30, [sp], #0x20
    8e38:      	ret

0000000000008e3c <_ZN13FormatConvert18VideoFormatTranser7prepareEv>:
    8e3c:      	ldrb	w8, [x0, #0xb0]
    8e40:      	tbnz	w8, #0x0, 0x8e4c <_ZN13FormatConvert18VideoFormatTranser7prepareEv+0x10>
    8e44:      	mov	w0, #-0x1               // =-1
    8e48:      	ret
    8e4c:      	stp	x29, x30, [sp, #-0x30]!
    8e50:      	str	x21, [sp, #0x10]
    8e54:      	stp	x20, x19, [sp, #0x20]
    8e58:      	mov	x29, sp
    8e5c:      	mov	x19, x0
    8e60:      	bl	0x12ca0 <av_register_all@plt>
    8e64:      	bl	0x12cb0 <avformat_network_init@plt>
    8e68:      	ldr	x9, [x19, #0x120]
    8e6c:      	mov	x8, #-0x1               // =-1
    8e70:      	str	wzr, [x19, #0x28]
    8e74:      	str	x8, [x19, #0x30]
    8e78:      	str	xzr, [x19, #0x8]
    8e7c:      	cbz	x9, 0x8eb8 <_ZN13FormatConvert18VideoFormatTranser7prepareEv+0x7c>
    8e80:      	ldp	x8, x0, [x19, #0x110]
    8e84:      	add	x20, x19, #0x110
    8e88:      	str	xzr, [x19, #0x120]
    8e8c:      	ldr	x8, [x8, #0x8]
    8e90:      	ldr	x9, [x0]
    8e94:      	cmp	x0, x20
    8e98:      	str	x8, [x9, #0x8]
    8e9c:      	str	x9, [x8]
    8ea0:      	b.eq	0x8eb8 <_ZN13FormatConvert18VideoFormatTranser7prepareEv+0x7c>
    8ea4:      	ldr	x21, [x0, #0x8]
    8ea8:      	bl	0x12c80 <_ZdlPv@plt>
    8eac:      	cmp	x21, x20
    8eb0:      	mov	x0, x21
    8eb4:      	b.ne	0x8ea4 <_ZN13FormatConvert18VideoFormatTranser7prepareEv+0x68>
    8eb8:      	mov	x0, x19
    8ebc:      	bl	0x12cc0 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv@plt>
    8ec0:      	cbnz	w0, 0x8edc <_ZN13FormatConvert18VideoFormatTranser7prepareEv+0xa0>
    8ec4:      	mov	x0, x19
    8ec8:      	bl	0x12cd0 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv@plt>
    8ecc:      	cbnz	w0, 0x8edc <_ZN13FormatConvert18VideoFormatTranser7prepareEv+0xa0>
    8ed0:      	mov	x0, x19
    8ed4:      	bl	0x12ce0 <_ZN13FormatConvert18VideoFormatTranser16_SwsMediaInitialEv@plt>
    8ed8:      	cbz	w0, 0x8ef8 <_ZN13FormatConvert18VideoFormatTranser7prepareEv+0xbc>
    8edc:      	mov	x0, x19
    8ee0:      	bl	0x12bb0 <_ZN13FormatConvert18VideoFormatTranser8_releaseEv@plt>
    8ee4:      	mov	w0, #-0x1               // =-1
    8ee8:      	ldp	x20, x19, [sp, #0x20]
    8eec:      	ldr	x21, [sp, #0x10]
    8ef0:      	ldp	x29, x30, [sp], #0x30
    8ef4:      	ret
    8ef8:      	mov	w8, #0x447a0000         // =1148846080
    8efc:      	ldr	s0, [x19, #0x98]
    8f00:      	ldr	w9, [x19, #0xb0]
    8f04:      	fmov	s1, w8
    8f08:      	fmul	s0, s0, s1
    8f0c:      	fcvtzs	w8, s0
    8f10:      	scvtf	d0, w8
    8f14:      	mov	x8, #0x400000000000     // =70368744177664
    8f18:      	movk	x8, #0x408f, lsl #48
    8f1c:      	fmov	d1, x8
    8f20:      	mov	x8, #0x848000000000     // =145685290680320
    8f24:      	movk	x8, #0x412e, lsl #48
    8f28:      	fdiv	d0, d1, d0
    8f2c:      	fmov	d1, x8
    8f30:      	fmul	d0, d0, d1
    8f34:      	fcvtzs	x8, d0
    8f38:      	str	x8, [x19, #0x38]
    8f3c:      	orr	w8, w9, #0x2
    8f40:      	str	w8, [x19, #0xb0]
    8f44:      	ldp	x20, x19, [sp, #0x20]
    8f48:      	ldr	x21, [sp, #0x10]
    8f4c:      	ldp	x29, x30, [sp], #0x30
    8f50:      	ret

0000000000008f54 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv>:
    8f54:      	stp	x29, x30, [sp, #-0x30]!
    8f58:      	str	x21, [sp, #0x10]
    8f5c:      	stp	x20, x19, [sp, #0x20]
    8f60:      	mov	x29, sp
    8f64:      	mov	x19, x0
    8f68:      	ldr	x0, [x0, #0x10]
    8f6c:      	mov	x2, xzr
    8f70:      	ldr	x1, [x19, #0xa0]
    8f74:      	mov	x3, xzr
    8f78:      	str	xzr, [x0, #0x8]
    8f7c:      	bl	0x12cf0 <avformat_open_input@plt>
    8f80:      	ldr	x8, [x19, #0x10]
    8f84:      	cbz	w0, 0x8fd8 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x84>
    8f88:      	ldr	x0, [x8, #0x10]
    8f8c:      	cbz	x0, 0x8fa4 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x50>
    8f90:      	bl	0x12c20 <avcodec_close@plt>
    8f94:      	ldr	x8, [x19, #0x10]
    8f98:      	add	x0, x8, #0x10
    8f9c:      	bl	0x12c30 <avcodec_free_context@plt>
    8fa0:      	ldr	x8, [x19, #0x10]
    8fa4:      	ldr	x9, [x8]
    8fa8:      	cbz	x9, 0x8fbc <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x68>
    8fac:      	mov	x0, x8
    8fb0:      	bl	0x12c40 <avformat_close_input@plt>
    8fb4:      	ldr	x8, [x19, #0x10]
    8fb8:      	str	xzr, [x8]
    8fbc:      	mov	w0, #-0x1               // =-1
    8fc0:      	str	xzr, [x8, #0x8]
    8fc4:      	str	w0, [x8, #0x20]
    8fc8:      	ldp	x20, x19, [sp, #0x20]
    8fcc:      	ldr	x21, [sp, #0x10]
    8fd0:      	ldp	x29, x30, [sp], #0x30
    8fd4:      	ret
    8fd8:      	ldr	x0, [x8]
    8fdc:      	mov	x1, xzr
    8fe0:      	bl	0x12d00 <avformat_find_stream_info@plt>
    8fe4:      	ldr	x8, [x19, #0x10]
    8fe8:      	tbnz	w0, #0x1f, 0x8f88 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x34>
    8fec:      	ldr	x20, [x8]
    8ff0:      	mov	w1, wzr
    8ff4:      	mov	w2, #-0x1               // =-1
    8ff8:      	mov	w3, #-0x1               // =-1
    8ffc:      	mov	x4, xzr
    9000:      	mov	w5, wzr
    9004:      	mov	x0, x20
    9008:      	bl	0x12d10 <av_find_best_stream@plt>
    900c:      	ldr	x8, [x19, #0x10]
    9010:      	str	w0, [x8, #0x20]
    9014:      	tbnz	w0, #0x1f, 0x8f88 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x34>
    9018:      	ldr	x9, [x20, #0x30]
    901c:      	ldr	x21, [x9, w0, uxtw #3]
    9020:      	ldr	x9, [x21, #0xd0]
    9024:      	str	x21, [x8, #0x8]
    9028:      	ldr	w0, [x9, #0x4]
    902c:      	bl	0x12d20 <avcodec_find_decoder@plt>
    9030:      	ldr	x8, [x19, #0x10]
    9034:      	str	x0, [x8, #0x18]
    9038:      	cbz	x0, 0x8f88 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x34>
    903c:      	bl	0x12d30 <avcodec_alloc_context3@plt>
    9040:      	ldr	x8, [x19, #0x10]
    9044:      	str	x0, [x8, #0x10]
    9048:      	cbz	x0, 0x8f88 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x34>
    904c:      	ldr	x1, [x21, #0xd0]
    9050:      	bl	0x12d40 <avcodec_parameters_to_context@plt>
    9054:      	ldr	x0, [x21, #0x48]
    9058:      	nop
    905c:      	adr	x1, 0x5cd9
    9060:      	mov	x2, xzr
    9064:      	mov	w3, wzr
    9068:      	bl	0x12d50 <av_dict_get@plt>
    906c:      	cbz	x0, 0x9078 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x124>
    9070:      	ldr	x0, [x0, #0x8]
    9074:      	bl	0x12d60 <atoi@plt>
    9078:      	str	w0, [x19, #0x6c]
    907c:      	ldr	x8, [x21, #0xd0]
    9080:      	ldr	d0, [x8, #0x38]
    9084:      	ldr	w0, [x8, #0x1c]
    9088:      	ldr	x9, [x8, #0x20]
    908c:      	scvtf	v0.2s, v0.2s
    9090:      	cmp	w0, #0x13
    9094:      	str	x9, [x19, #0x60]
    9098:      	stur	d0, [x19, #0x44]
    909c:      	b.le	0x90c8 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x174>
    90a0:      	cmp	w0, #0x17
    90a4:      	b.le	0x9100 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x1ac>
    90a8:      	cmp	w0, #0x18
    90ac:      	b.eq	0x9128 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x1d4>
    90b0:      	cmp	w0, #0x1a
    90b4:      	b.eq	0x9130 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x1dc>
    90b8:      	cmp	w0, #0x1c
    90bc:      	b.ne	0x91a8 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x254>
    90c0:      	mov	w8, #0x6                // =6
    90c4:      	b	0x9134 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x1e0>
    90c8:      	cmp	w0, #0x4
    90cc:      	b.gt	0x90e8 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x194>
    90d0:      	mov	w8, w0
    90d4:      	cbz	w0, 0x9134 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x1e0>
    90d8:      	cmp	w0, #0x4
    90dc:      	b.ne	0x91a8 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x254>
    90e0:      	mov	w8, #0x1                // =1
    90e4:      	b	0x9134 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x1e0>
    90e8:      	cmp	w0, #0x5
    90ec:      	b.eq	0x9118 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x1c4>
    90f0:      	cmp	w0, #0xc
    90f4:      	b.ne	0x91a8 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x254>
    90f8:      	mov	w8, #0x5                // =5
    90fc:      	b	0x9134 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x1e0>
    9100:      	cmp	w0, #0x14
    9104:      	b.eq	0x9120 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x1cc>
    9108:      	cmp	w0, #0x17
    910c:      	b.ne	0x91a8 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x254>
    9110:      	mov	w8, #0x3                // =3
    9114:      	b	0x9134 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x1e0>
    9118:      	mov	w8, #0x2                // =2
    911c:      	b	0x9134 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x1e0>
    9120:      	mov	w8, #0x8                // =8
    9124:      	b	0x9134 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x1e0>
    9128:      	mov	w8, #0x4                // =4
    912c:      	b	0x9134 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x1e0>
    9130:      	mov	w8, #0x7                // =7
    9134:      	ldp	w9, w10, [x21, #0x50]
    9138:      	fcvtzs	w1, s0
    913c:      	ldr	w3, [x19, #0x58]
    9140:      	str	w8, [x19, #0x40]
    9144:      	scvtf	d1, w9
    9148:      	scvtf	d2, w10
    914c:      	fdiv	d1, d1, d2
    9150:      	mov	s2, v0.s[1]
    9154:      	fcvtzs	w2, s2
    9158:      	fcvt	s1, d1
    915c:      	str	s1, [x19, #0x68]
    9160:      	bl	0x12d70 <av_image_get_buffer_size@plt>
    9164:      	ldr	x8, [x19, #0x10]
    9168:      	ldr	x2, [x19, #0xa0]
    916c:      	mov	w3, wzr
    9170:      	str	w0, [x19, #0x5c]
    9174:      	mov	x0, x20
    9178:      	ldr	w1, [x8, #0x20]
    917c:      	bl	0x12d80 <av_dump_format@plt>
    9180:      	ldp	x8, x9, [x19, #0x10]
    9184:      	mov	x2, xzr
    9188:      	ldr	x0, [x8, #0x10]
    918c:      	ldr	x1, [x9, #0x18]
    9190:      	bl	0x12d90 <avcodec_open2@plt>
    9194:      	mov	w8, w0
    9198:      	mov	w0, wzr
    919c:      	tbz	w8, #0x1f, 0x8fc8 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x74>
    91a0:      	ldr	x8, [x19, #0x10]
    91a4:      	b	0x8f88 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv+0x34>
    91a8:      	mov	w0, wzr
    91ac:      	bl	0x12c00 <exit@plt>

00000000000091b0 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv>:
    91b0:      	sub	sp, sp, #0x50
    91b4:      	stp	x29, x30, [sp, #0x10]
    91b8:      	stp	x24, x23, [sp, #0x20]
    91bc:      	stp	x22, x21, [sp, #0x30]
    91c0:      	stp	x20, x19, [sp, #0x40]
    91c4:      	add	x29, sp, #0x10
    91c8:      	mrs	x24, TPIDR_EL0
    91cc:      	mov	x19, x0
    91d0:      	ldr	x8, [x24, #0x28]
    91d4:      	str	x8, [sp, #0x8]
    91d8:      	ldr	s0, [x0, #0x74]
    91dc:      	fcmp	s0, #0.0
    91e0:      	b.ls	0x9228 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x78>
    91e4:      	ldr	s1, [x19, #0x78]
    91e8:      	fcmp	s1, #0.0
    91ec:      	b.ls	0x9228 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x78>
    91f0:      	ldr	x8, [x19, #0x90]
    91f4:      	cmp	x8, #0x3e8
    91f8:      	b.le	0x923c <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x8c>
    91fc:      	ldr	s2, [x19, #0x98]
    9200:      	fcmp	s2, #0.0
    9204:      	b.ls	0x9250 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0xa0>
    9208:      	ldr	w8, [x19, #0x70]
    920c:      	cmn	w8, #0x1
    9210:      	b.eq	0x9264 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0xb4>
    9214:      	mov	w9, #0x4                // =4
    9218:      	cmp	w8, #0x9
    921c:      	str	w9, [x19, #0x88]
    9220:      	b.lo	0x927c <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0xcc>
    9224:      	b	0x9638 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x488>
    9228:      	ldp	s0, s1, [x19, #0x44]
    922c:      	stp	s0, s1, [x19, #0x74]
    9230:      	ldr	x8, [x19, #0x90]
    9234:      	cmp	x8, #0x3e8
    9238:      	b.gt	0x91fc <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x4c>
    923c:      	ldr	x8, [x19, #0x60]
    9240:      	str	x8, [x19, #0x90]
    9244:      	ldr	s2, [x19, #0x98]
    9248:      	fcmp	s2, #0.0
    924c:      	b.hi	0x9208 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x58>
    9250:      	ldr	s2, [x19, #0x68]
    9254:      	str	s2, [x19, #0x98]
    9258:      	ldr	w8, [x19, #0x70]
    925c:      	cmn	w8, #0x1
    9260:      	b.ne	0x9214 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x64>
    9264:      	ldr	w8, [x19, #0x40]
    9268:      	str	w8, [x19, #0x70]
    926c:      	mov	w9, #0x4                // =4
    9270:      	cmp	w8, #0x9
    9274:      	str	w9, [x19, #0x88]
    9278:      	b.hs	0x9638 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x488>
    927c:      	fcvtzs	w1, s0
    9280:      	fcvtzs	w2, s1
    9284:      	nop
    9288:      	adr	x23, 0x614c
    928c:      	mov	w3, #0x4                // =4
    9290:      	ldr	w0, [x23, w8, uxtw #2]
    9294:      	bl	0x12d70 <av_image_get_buffer_size@plt>
    9298:      	ldr	w8, [x19]
    929c:      	str	w0, [x19, #0x8c]
    92a0:      	cbz	w8, 0x9554 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x3a4>
    92a4:      	ldr	x0, [x19, #0x18]
    92a8:      	ldr	x3, [x19, #0xa8]
    92ac:      	mov	x1, xzr
    92b0:      	mov	x2, xzr
    92b4:      	str	xzr, [sp]
    92b8:      	bl	0x12da0 <avformat_alloc_output_context2@plt>
    92bc:      	tbnz	w0, #0x1f, 0x9500 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x350>
    92c0:      	ldr	x8, [x19, #0x18]
    92c4:      	ldr	x1, [x19, #0xa8]
    92c8:      	mov	w2, #0x2                // =2
    92cc:      	ldr	x20, [x8]
    92d0:      	add	x0, x20, #0x20
    92d4:      	bl	0x12db0 <avio_open@plt>
    92d8:      	tbnz	w0, #0x1f, 0x9500 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x350>
    92dc:      	ldr	x21, [x19, #0xa8]
    92e0:      	mov	x0, x21
    92e4:      	bl	0x12dc0 <strlen@plt>
    92e8:      	mov	x2, x0
    92ec:      	add	x0, x20, #0x38
    92f0:      	mov	x1, x21
    92f4:      	mov	w3, #0x400              // =1024
    92f8:      	bl	0x12dd0 <__strncpy_chk@plt>
    92fc:      	adrp	x0, 0x5000
    9300:      	add	x0, x0, #0xbb0
    9304:      	bl	0x12de0 <avcodec_find_encoder_by_name@plt>
    9308:      	ldr	x8, [x19, #0x18]
    930c:      	str	x0, [x8, #0x18]
    9310:      	cbz	x0, 0x9500 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x350>
    9314:      	mov	x1, x0
    9318:      	ldr	x0, [x8]
    931c:      	bl	0x12df0 <avformat_new_stream@plt>
    9320:      	cbz	x0, 0x9500 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x350>
    9324:      	adrp	x8, 0x5000
    9328:      	ldr	x9, [x19, #0x18]
    932c:      	mov	x21, x0
    9330:      	ldr	d0, [x8, #0x5d8]
    9334:      	ldr	w8, [x0]
    9338:      	str	x0, [x9, #0x8]
    933c:      	str	d0, [x0, #0x18]
    9340:      	ldr	x0, [x9, #0x18]
    9344:      	str	w8, [x9, #0x20]
    9348:      	bl	0x12d30 <avcodec_alloc_context3@plt>
    934c:      	ldr	x8, [x19, #0x18]
    9350:      	str	x0, [x8, #0x10]
    9354:      	cbz	x0, 0x9500 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x350>
    9358:      	ldr	s0, [x19, #0x74]
    935c:      	mov	x22, x0
    9360:      	fneg	s1, s0
    9364:      	fcmp	s0, #0.0
    9368:      	fcsel	s0, s1, s0, mi
    936c:      	fcvtzs	w9, s0
    9370:      	str	w9, [x0, #0x74]
    9374:      	ldr	s0, [x19, #0x78]
    9378:      	fneg	s1, s0
    937c:      	fcmp	s0, #0.0
    9380:      	fcsel	s0, s1, s0, mi
    9384:      	fcvtzs	w9, s0
    9388:      	str	w9, [x0, #0x78]
    938c:      	ldr	w9, [x19, #0x70]
    9390:      	cmp	w9, #0x9
    9394:      	b.hs	0x9638 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x488>
    9398:      	mov	w10, #0x447a0000        // =1148846080
    939c:      	ldr	s0, [x19, #0x98]
    93a0:      	ldr	w9, [x23, x9, lsl #2]
    93a4:      	fmov	s1, w10
    93a8:      	ldr	x8, [x8, #0x18]
    93ac:      	mov	w10, #0x3c              // =60
    93b0:      	mov	w11, #0xfa              // =250
    93b4:      	str	w10, [x22, #0x160]
    93b8:      	ldr	w10, [x8, #0x10]
    93bc:      	stp	w11, w9, [x22, #0x84]
    93c0:      	mov	w9, #0x3e8              // =1000
    93c4:      	fmul	s0, s0, s1
    93c8:      	str	w9, [x22, #0x368]
    93cc:      	ldr	w8, [x8, #0x14]
    93d0:      	str	w9, [x22, #0x64]
    93d4:      	ldr	x9, [x19, #0x90]
    93d8:      	str	w10, [x22, #0xc]
    93dc:      	ldr	x10, [x20, #0x10]
    93e0:      	str	w8, [x22, #0x18]
    93e4:      	fcvtzs	w12, s0
    93e8:      	str	x9, [x22, #0x38]
    93ec:      	str	w12, [x22, #0x36c]
    93f0:      	str	w12, [x22, #0x68]
    93f4:      	ldrb	w9, [x10, #0x2c]
    93f8:      	tbz	w9, #0x6, 0x9408 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x258>
    93fc:      	ldr	w9, [x22, #0x4c]
    9400:      	orr	w9, w9, #0x400000
    9404:      	str	w9, [x22, #0x4c]
    9408:      	cmp	w8, #0x1b
    940c:      	b.ne	0x9464 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x2b4>
    9410:      	ldr	x0, [x22, #0x20]
    9414:      	adrp	x1, 0x5000
    9418:      	add	x1, x1, #0x6dd
    941c:      	adrp	x2, 0x5000
    9420:      	add	x2, x2, #0x99b
    9424:      	mov	w3, wzr
    9428:      	bl	0x12e00 <av_opt_set@plt>
    942c:      	ldr	x0, [x22, #0x20]
    9430:      	adrp	x1, 0x5000
    9434:      	add	x1, x1, #0x68f
    9438:      	adrp	x2, 0x5000
    943c:      	add	x2, x2, #0xeab
    9440:      	mov	w3, wzr
    9444:      	bl	0x12e00 <av_opt_set@plt>
    9448:      	ldr	x0, [x22, #0x20]
    944c:      	adrp	x1, 0x5000
    9450:      	add	x1, x1, #0xac7
    9454:      	adrp	x2, 0x5000
    9458:      	add	x2, x2, #0x638
    945c:      	mov	w3, wzr
    9460:      	bl	0x12e00 <av_opt_set@plt>
    9464:      	adrp	x1, 0x5000
    9468:      	add	x1, x1, #0x81d
    946c:      	adrp	x2, 0x5000
    9470:      	add	x2, x2, #0x644
    9474:      	mov	x0, sp
    9478:      	mov	w3, wzr
    947c:      	bl	0x12e10 <av_dict_set@plt>
    9480:      	ldr	x8, [x19, #0x18]
    9484:      	mov	x2, sp
    9488:      	mov	x0, x22
    948c:      	ldr	x1, [x8, #0x18]
    9490:      	bl	0x12d90 <avcodec_open2@plt>
    9494:      	mov	w23, w0
    9498:      	mov	x0, sp
    949c:      	bl	0x12e20 <av_dict_free@plt>
    94a0:      	tbnz	w23, #0x1f, 0x9500 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x350>
    94a4:      	ldr	x0, [x21, #0xd0]
    94a8:      	mov	x1, x22
    94ac:      	bl	0x12e30 <avcodec_parameters_from_context@plt>
    94b0:      	tbnz	w0, #0x1f, 0x9500 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x350>
    94b4:      	ldr	x8, [x21, #0xd0]
    94b8:      	ldr	d0, [x8, #0x38]
    94bc:      	ldr	w0, [x8, #0x1c]
    94c0:      	ldr	x9, [x8, #0x20]
    94c4:      	scvtf	v0.2s, v0.2s
    94c8:      	cmp	w0, #0x13
    94cc:      	str	x9, [x19, #0x90]
    94d0:      	stur	d0, [x19, #0x74]
    94d4:      	b.le	0x9580 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x3d0>
    94d8:      	cmp	w0, #0x17
    94dc:      	b.le	0x95b8 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x408>
    94e0:      	cmp	w0, #0x18
    94e4:      	b.eq	0x95e0 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x430>
    94e8:      	cmp	w0, #0x1a
    94ec:      	b.eq	0x95e8 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x438>
    94f0:      	cmp	w0, #0x1c
    94f4:      	b.ne	0x9638 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x488>
    94f8:      	mov	w8, #0x6                // =6
    94fc:      	b	0x95ec <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x43c>
    9500:      	ldr	x0, [x19, #0x18]
    9504:      	ldr	x8, [x0, #0x10]
    9508:      	cbz	x8, 0x9524 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x374>
    950c:      	mov	x0, x8
    9510:      	bl	0x12c20 <avcodec_close@plt>
    9514:      	ldr	x8, [x19, #0x18]
    9518:      	add	x0, x8, #0x10
    951c:      	bl	0x12c30 <avcodec_free_context@plt>
    9520:      	ldr	x0, [x19, #0x18]
    9524:      	ldr	x8, [x0]
    9528:      	str	xzr, [x0, #0x18]
    952c:      	cbz	x8, 0x953c <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x38c>
    9530:      	bl	0x12c40 <avformat_close_input@plt>
    9534:      	ldr	x8, [x19, #0x18]
    9538:      	str	xzr, [x8]
    953c:      	mov	w0, #-0x1               // =-1
    9540:      	ldr	x8, [x24, #0x28]
    9544:      	ldr	x9, [sp, #0x8]
    9548:      	cmp	x8, x9
    954c:      	b.eq	0x9568 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x3b8>
    9550:      	b	0x9634 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x484>
    9554:      	mov	w0, wzr
    9558:      	ldr	x8, [x24, #0x28]
    955c:      	ldr	x9, [sp, #0x8]
    9560:      	cmp	x8, x9
    9564:      	b.ne	0x9634 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x484>
    9568:      	ldp	x20, x19, [sp, #0x40]
    956c:      	ldp	x22, x21, [sp, #0x30]
    9570:      	ldp	x24, x23, [sp, #0x20]
    9574:      	ldp	x29, x30, [sp, #0x10]
    9578:      	add	sp, sp, #0x50
    957c:      	ret
    9580:      	cmp	w0, #0x4
    9584:      	b.gt	0x95a0 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x3f0>
    9588:      	mov	w8, w0
    958c:      	cbz	w0, 0x95ec <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x43c>
    9590:      	cmp	w0, #0x4
    9594:      	b.ne	0x9638 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x488>
    9598:      	mov	w8, #0x1                // =1
    959c:      	b	0x95ec <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x43c>
    95a0:      	cmp	w0, #0x5
    95a4:      	b.eq	0x95d0 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x420>
    95a8:      	cmp	w0, #0xc
    95ac:      	b.ne	0x9638 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x488>
    95b0:      	mov	w8, #0x5                // =5
    95b4:      	b	0x95ec <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x43c>
    95b8:      	cmp	w0, #0x14
    95bc:      	b.eq	0x95d8 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x428>
    95c0:      	cmp	w0, #0x17
    95c4:      	b.ne	0x9638 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x488>
    95c8:      	mov	w8, #0x3                // =3
    95cc:      	b	0x95ec <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x43c>
    95d0:      	mov	w8, #0x2                // =2
    95d4:      	b	0x95ec <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x43c>
    95d8:      	mov	w8, #0x8                // =8
    95dc:      	b	0x95ec <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x43c>
    95e0:      	mov	w8, #0x4                // =4
    95e4:      	b	0x95ec <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x43c>
    95e8:      	mov	w8, #0x7                // =7
    95ec:      	mov	s1, v0.s[1]
    95f0:      	fcvtzs	w1, s0
    95f4:      	ldr	w3, [x19, #0x88]
    95f8:      	str	w8, [x19, #0x70]
    95fc:      	fcvtzs	w2, s1
    9600:      	bl	0x12d70 <av_image_get_buffer_size@plt>
    9604:      	ldr	x8, [x19, #0x18]
    9608:      	ldr	x2, [x19, #0xa8]
    960c:      	mov	w3, #0x1                // =1
    9610:      	str	w0, [x19, #0x8c]
    9614:      	mov	x0, x20
    9618:      	ldr	w1, [x8, #0x20]
    961c:      	bl	0x12d80 <av_dump_format@plt>
    9620:      	mov	w0, wzr
    9624:      	ldr	x8, [x24, #0x28]
    9628:      	ldr	x9, [sp, #0x8]
    962c:      	cmp	x8, x9
    9630:      	b.eq	0x9568 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x3b8>
    9634:      	bl	0x12bc0 <__stack_chk_fail@plt>
    9638:      	ldr	x8, [x24, #0x28]
    963c:      	ldr	x9, [sp, #0x8]
    9640:      	cmp	x8, x9
    9644:      	b.ne	0x9634 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv+0x484>
    9648:      	mov	w0, wzr
    964c:      	bl	0x12c00 <exit@plt>

0000000000009650 <_ZN13FormatConvert18VideoFormatTranser16_SwsMediaInitialEv>:
    9650:      	sub	sp, sp, #0x30
    9654:      	stp	x29, x30, [sp, #0x10]
    9658:      	str	x19, [sp, #0x20]
    965c:      	add	x29, sp, #0x10
    9660:      	ldp	s0, s3, [x0, #0x74]
    9664:      	ldr	w9, [x0, #0x40]
    9668:      	ldp	s1, s2, [x0, #0x44]
    966c:      	ldr	w8, [x0, #0x70]
    9670:      	str	xzr, [x0, #0x20]
    9674:      	fcmp	s1, s0
    9678:      	fccmp	s2, s3, #0x0, eq
    967c:      	ccmp	w9, w8, #0x0, eq
    9680:      	b.eq	0x96dc <_ZN13FormatConvert18VideoFormatTranser16_SwsMediaInitialEv+0x8c>
    9684:      	cmp	w9, #0x9
    9688:      	b.hs	0x9704 <_ZN13FormatConvert18VideoFormatTranser16_SwsMediaInitialEv+0xb4>
    968c:      	ldr	w10, [x0, #0x70]
    9690:      	cmp	w10, #0x9
    9694:      	b.hs	0x9704 <_ZN13FormatConvert18VideoFormatTranser16_SwsMediaInitialEv+0xb4>
    9698:      	ldr	s3, [x0, #0x78]
    969c:      	fcvtzs	w8, s1
    96a0:      	fcvtzs	w1, s2
    96a4:      	fcvtzs	w3, s0
    96a8:      	nop
    96ac:      	adr	x11, 0x614c
    96b0:      	fcvtzs	w4, s3
    96b4:      	ldr	w2, [x11, x9, lsl #2]
    96b8:      	ldr	w5, [x11, x10, lsl #2]
    96bc:      	mov	x7, xzr
    96c0:      	mov	x19, x0
    96c4:      	mov	w6, #0x4                // =4
    96c8:      	mov	w0, w8
    96cc:      	stp	xzr, xzr, [sp]
    96d0:      	bl	0x12e40 <sws_getContext@plt>
    96d4:      	str	x0, [x19, #0x20]
    96d8:      	cbz	x0, 0x96f0 <_ZN13FormatConvert18VideoFormatTranser16_SwsMediaInitialEv+0xa0>
    96dc:      	mov	w0, wzr
    96e0:      	ldp	x29, x30, [sp, #0x10]
    96e4:      	ldr	x19, [sp, #0x20]
    96e8:      	add	sp, sp, #0x30
    96ec:      	ret
    96f0:      	mov	w0, #-0x1               // =-1
    96f4:      	ldp	x29, x30, [sp, #0x10]
    96f8:      	ldr	x19, [sp, #0x20]
    96fc:      	add	sp, sp, #0x30
    9700:      	ret
    9704:      	mov	w0, wzr
    9708:      	bl	0x12c00 <exit@plt>

000000000000970c <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl>:
    970c:      	sub	sp, sp, #0x50
    9710:      	stp	x29, x30, [sp, #0x10]
    9714:      	str	x23, [sp, #0x20]
    9718:      	stp	x22, x21, [sp, #0x30]
    971c:      	stp	x20, x19, [sp, #0x40]
    9720:      	add	x29, sp, #0x10
    9724:      	mrs	x22, TPIDR_EL0
    9728:      	mov	x19, x0
    972c:      	mov	w0, #-0x1               // =-1
    9730:      	ldr	x8, [x22, #0x28]
    9734:      	str	x8, [sp, #0x8]
    9738:      	cbz	x1, 0x97ac <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0xa0>
    973c:      	cbz	x2, 0x97ac <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0xa0>
    9740:      	str	xzr, [x1]
    9744:      	ldr	w8, [x19, #0xb0]
    9748:      	mov	x20, x1
    974c:      	ldr	x9, [x19, #0x120]
    9750:      	tbz	w8, #0x5, 0x9758 <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0x4c>
    9754:      	cbz	x9, 0x97a0 <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0x94>
    9758:      	mov	x23, x2
    975c:      	add	x0, x19, #0xb4
    9760:      	cbnz	x9, 0x97d4 <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0xc8>
    9764:      	bl	0x12ad0 <pthread_mutex_lock@plt>
    9768:      	ldr	x8, [x19, #0x120]
    976c:      	cbnz	x8, 0x9784 <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0x78>
    9770:      	ldrb	w8, [x19, #0xb0]
    9774:      	tbnz	w8, #0x5, 0x9784 <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0x78>
    9778:      	add	x0, x19, #0xdc
    977c:      	add	x1, x19, #0xb4
    9780:      	bl	0x12ae0 <pthread_cond_wait@plt>
    9784:      	add	x0, x19, #0xb4
    9788:      	bl	0x12ac0 <pthread_mutex_unlock@plt>
    978c:      	str	xzr, [x20]
    9790:      	ldr	w8, [x19, #0xb0]
    9794:      	ldr	x9, [x19, #0x120]
    9798:      	tbz	w8, #0x5, 0x975c <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0x50>
    979c:      	cbnz	x9, 0x975c <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0x50>
    97a0:      	orr	w8, w8, #0x10
    97a4:      	mov	w0, #-0x2               // =-2
    97a8:      	str	w8, [x19, #0xb0]
    97ac:      	ldr	x8, [x22, #0x28]
    97b0:      	ldr	x9, [sp, #0x8]
    97b4:      	cmp	x8, x9
    97b8:      	b.ne	0x9898 <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0x18c>
    97bc:      	ldp	x20, x19, [sp, #0x40]
    97c0:      	ldr	x23, [sp, #0x20]
    97c4:      	ldp	x22, x21, [sp, #0x30]
    97c8:      	ldp	x29, x30, [sp, #0x10]
    97cc:      	add	sp, sp, #0x50
    97d0:      	ret
    97d4:      	bl	0x12ad0 <pthread_mutex_lock@plt>
    97d8:      	ldp	x0, x8, [x19, #0x118]
    97dc:      	ldp	x9, x21, [x0, #0x8]
    97e0:      	sub	x8, x8, #0x1
    97e4:      	str	x8, [x19, #0x120]
    97e8:      	str	x21, [sp]
    97ec:      	ldr	x10, [x0]
    97f0:      	str	x9, [x10, #0x8]
    97f4:      	str	x10, [x9]
    97f8:      	bl	0x12c80 <_ZdlPv@plt>
    97fc:      	add	x0, x19, #0xb4
    9800:      	bl	0x12ac0 <pthread_mutex_unlock@plt>
    9804:      	add	x0, x19, #0xdc
    9808:      	bl	0x12b70 <pthread_cond_signal@plt>
    980c:      	ldrsw	x0, [x19, #0x8c]
    9810:      	bl	0x12e60 <av_mallocz@plt>
    9814:      	str	x0, [x20]
    9818:      	ldrsw	x2, [x19, #0x8c]
    981c:      	ldr	x1, [x21]
    9820:      	bl	0x12e70 <memcpy@plt>
    9824:      	ldr	x8, [x19, #0x10]
    9828:      	mov	x2, #0x1                // =1
    982c:      	ldr	x0, [x21, #0x88]
    9830:      	movk	x2, #0x4240, lsl #32
    9834:      	ldr	x8, [x8, #0x8]
    9838:      	movk	x2, #0xf, lsl #48
    983c:      	ldr	x1, [x8, #0x18]
    9840:      	bl	0x12e80 <av_rescale_q@plt>
    9844:      	scvtf	d0, x0
    9848:      	adrp	x8, 0x5000
    984c:      	ldr	d1, [x8, #0x5e0]
    9850:      	mov	x8, #0x400000000000     // =70368744177664
    9854:      	movk	x8, #0x408f, lsl #48
    9858:      	ldr	x9, [x21, #0xb0]!
    985c:      	fmul	d0, d0, d1
    9860:      	fmov	d1, x8
    9864:      	fmul	d0, d0, d1
    9868:      	fcvtzs	x8, d0
    986c:      	str	x8, [x23]
    9870:      	cbz	x9, 0x987c <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0x170>
    9874:      	mov	x0, x21
    9878:      	bl	0x12bf0 <av_freep@plt>
    987c:      	mov	x0, sp
    9880:      	bl	0x12b80 <av_frame_free@plt>
    9884:      	mov	w0, wzr
    9888:      	ldr	x8, [x22, #0x28]
    988c:      	ldr	x9, [sp, #0x8]
    9890:      	cmp	x8, x9
    9894:      	b.eq	0x97bc <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0xb0>
    9898:      	bl	0x12bc0 <__stack_chk_fail@plt>
    989c:      	cbz	x0, 0x98d8 <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0x1cc>
    98a0:      	stp	x29, x30, [sp, #-0x20]!
    98a4:      	str	x19, [sp, #0x10]
    98a8:      	mov	x29, sp
    98ac:      	mov	x19, x0
    98b0:      	ldr	x0, [x0]
    98b4:      	cbz	x0, 0x98d0 <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0x1c4>
    98b8:      	ldr	x8, [x0, #0xb0]!
    98bc:      	cbz	x8, 0x98c4 <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0x1b8>
    98c0:      	bl	0x12bf0 <av_freep@plt>
    98c4:      	mov	x0, x19
    98c8:      	bl	0x12b80 <av_frame_free@plt>
    98cc:      	str	xzr, [x19]
    98d0:      	ldr	x19, [sp, #0x10]
    98d4:      	ldp	x29, x30, [sp], #0x20
    98d8:      	ret

00000000000098dc <_ZN13FormatConvert18VideoFormatTranser20getOutputImageParamsEv>:
    98dc:      	add	x0, x0, #0x70
    98e0:      	ret

00000000000098e4 <_ZN13FormatConvert18VideoFormatTranser4stopEv>:
    98e4:      	sub	sp, sp, #0x40
    98e8:      	stp	x29, x30, [sp, #0x10]
    98ec:      	stp	x22, x21, [sp, #0x20]
    98f0:      	stp	x20, x19, [sp, #0x30]
    98f4:      	add	x29, sp, #0x10
    98f8:      	mrs	x20, TPIDR_EL0
    98fc:      	mov	x19, x0
    9900:      	ldr	x8, [x20, #0x28]
    9904:      	str	x8, [sp, #0x8]
    9908:      	ldr	w8, [x0, #0xb0]
    990c:      	orr	w8, w8, #0x4
    9910:      	str	w8, [x0, #0xb0]
    9914:      	add	x0, x0, #0xdc
    9918:      	bl	0x12b70 <pthread_cond_signal@plt>
    991c:      	ldr	x0, [x19, #0x8]
    9920:      	cbz	x0, 0x9930 <_ZN13FormatConvert18VideoFormatTranser4stopEv+0x4c>
    9924:      	mov	x1, xzr
    9928:      	bl	0x12ea0 <pthread_join@plt>
    992c:      	str	xzr, [x19, #0x8]
    9930:      	add	x0, x19, #0xb4
    9934:      	bl	0x12ad0 <pthread_mutex_lock@plt>
    9938:      	ldr	x22, [x19, #0x118]
    993c:      	add	x21, x19, #0x110
    9940:      	b	0x9950 <_ZN13FormatConvert18VideoFormatTranser4stopEv+0x6c>
    9944:      	mov	x0, sp
    9948:      	bl	0x12b80 <av_frame_free@plt>
    994c:      	ldr	x22, [x22, #0x8]
    9950:      	cmp	x22, x21
    9954:      	b.eq	0x9974 <_ZN13FormatConvert18VideoFormatTranser4stopEv+0x90>
    9958:      	ldr	x0, [x22, #0x10]
    995c:      	str	x0, [sp]
    9960:      	cbz	x0, 0x994c <_ZN13FormatConvert18VideoFormatTranser4stopEv+0x68>
    9964:      	ldr	x8, [x0, #0xb0]!
    9968:      	cbz	x8, 0x9944 <_ZN13FormatConvert18VideoFormatTranser4stopEv+0x60>
    996c:      	bl	0x12bf0 <av_freep@plt>
    9970:      	b	0x9944 <_ZN13FormatConvert18VideoFormatTranser4stopEv+0x60>
    9974:      	ldr	x8, [x19, #0x120]
    9978:      	cbz	x8, 0x99b0 <_ZN13FormatConvert18VideoFormatTranser4stopEv+0xcc>
    997c:      	ldp	x8, x0, [x19, #0x110]
    9980:      	str	xzr, [x19, #0x120]
    9984:      	ldr	x8, [x8, #0x8]
    9988:      	ldr	x9, [x0]
    998c:      	cmp	x0, x21
    9990:      	str	x8, [x9, #0x8]
    9994:      	str	x9, [x8]
    9998:      	b.eq	0x99b0 <_ZN13FormatConvert18VideoFormatTranser4stopEv+0xcc>
    999c:      	ldr	x22, [x0, #0x8]
    99a0:      	bl	0x12c80 <_ZdlPv@plt>
    99a4:      	cmp	x22, x21
    99a8:      	mov	x0, x22
    99ac:      	b.ne	0x999c <_ZN13FormatConvert18VideoFormatTranser4stopEv+0xb8>
    99b0:      	add	x0, x19, #0xb4
    99b4:      	bl	0x12ac0 <pthread_mutex_unlock@plt>
    99b8:      	add	x0, x19, #0xdc
    99bc:      	bl	0x12eb0 <pthread_cond_destroy@plt>
    99c0:      	add	x0, x19, #0xb4
    99c4:      	bl	0x12ec0 <pthread_mutex_destroy@plt>
    99c8:      	mov	x0, x19
    99cc:      	bl	0x12bb0 <_ZN13FormatConvert18VideoFormatTranser8_releaseEv@plt>
    99d0:      	ldr	x8, [x20, #0x28]
    99d4:      	ldr	x9, [sp, #0x8]
    99d8:      	cmp	x8, x9
    99dc:      	b.ne	0x99f4 <_ZN13FormatConvert18VideoFormatTranser4stopEv+0x110>
    99e0:      	ldp	x20, x19, [sp, #0x30]
    99e4:      	ldp	x22, x21, [sp, #0x20]
    99e8:      	ldp	x29, x30, [sp, #0x10]
    99ec:      	add	sp, sp, #0x40
    99f0:      	ret
    99f4:      	bl	0x12bc0 <__stack_chk_fail@plt>

00000000000099f8 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv>:
    99f8:      	sub	sp, sp, #0x50
    99fc:      	stp	x29, x30, [sp, #0x10]
    9a00:      	stp	x24, x23, [sp, #0x20]
    9a04:      	stp	x22, x21, [sp, #0x30]
    9a08:      	stp	x20, x19, [sp, #0x40]
    9a0c:      	add	x29, sp, #0x10
    9a10:      	mrs	x21, TPIDR_EL0
    9a14:      	ldr	x8, [x21, #0x28]
    9a18:      	str	x8, [sp, #0x8]
    9a1c:      	ldrb	w8, [x0, #0xb0]
    9a20:      	tbnz	w8, #0x1, 0x9a3c <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x44>
    9a24:      	mov	w0, #-0x1               // =-1
    9a28:      	ldr	x8, [x21, #0x28]
    9a2c:      	ldr	x9, [sp, #0x8]
    9a30:      	cmp	x8, x9
    9a34:      	b.eq	0x9b14 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x11c>
    9a38:      	b	0x9bf8 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x200>
    9a3c:      	ldr	w8, [x0]
    9a40:      	mov	x19, x0
    9a44:      	cbz	w8, 0x9a8c <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x94>
    9a48:      	ldr	x8, [x19, #0x20]
    9a4c:      	str	xzr, [sp]
    9a50:      	cbz	x8, 0x9ac0 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0xc8>
    9a54:      	ldr	x8, [x19, #0x18]
    9a58:      	mov	w20, #0x1               // =1
    9a5c:      	ldr	x0, [x8]
    9a60:      	mov	x1, xzr
    9a64:      	bl	0x12ee0 <avformat_write_header@plt>
    9a68:      	tbnz	w0, #0x1f, 0x9aec <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0xf4>
    9a6c:      	bl	0x12ab0 <av_packet_alloc@plt>
    9a70:      	ldr	w8, [x19, #0xb0]
    9a74:      	mov	w9, #0x14               // =20
    9a78:      	str	x0, [sp]
    9a7c:      	tst	w8, w9
    9a80:      	b.eq	0x9b2c <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x134>
    9a84:      	mov	w20, wzr
    9a88:      	b	0x9af0 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0xf8>
    9a8c:      	adrp	x2, 0x17000 <syscall@plt+0x3bf0>
    9a90:      	add	x0, x19, #0x8
    9a94:      	mov	x1, xzr
    9a98:      	ldr	x2, [x2, #0x7a0]
    9a9c:      	mov	x3, x19
    9aa0:      	bl	0x12ef0 <pthread_create@plt>
    9aa4:      	tbnz	w0, #0x1f, 0x9be0 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x1e8>
    9aa8:      	mov	w0, wzr
    9aac:      	ldr	x8, [x21, #0x28]
    9ab0:      	ldr	x9, [sp, #0x8]
    9ab4:      	cmp	x8, x9
    9ab8:      	b.eq	0x9b14 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x11c>
    9abc:      	b	0x9bf8 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x200>
    9ac0:      	ldp	x9, x8, [x19, #0x10]
    9ac4:      	ldr	x9, [x9, #0x18]
    9ac8:      	ldr	x10, [x8, #0x18]
    9acc:      	ldr	w9, [x9, #0x14]
    9ad0:      	ldr	w10, [x10, #0x14]
    9ad4:      	cmp	w9, w10
    9ad8:      	cset	w20, ne
    9adc:      	ldr	x0, [x8]
    9ae0:      	mov	x1, xzr
    9ae4:      	bl	0x12ee0 <avformat_write_header@plt>
    9ae8:      	tbz	w0, #0x1f, 0x9a6c <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x74>
    9aec:      	mov	w20, #-0x1              // =-1
    9af0:      	mov	x0, sp
    9af4:      	bl	0x12b90 <av_packet_free@plt>
    9af8:      	mov	x0, x19
    9afc:      	bl	0x12bb0 <_ZN13FormatConvert18VideoFormatTranser8_releaseEv@plt>
    9b00:      	mov	w0, w20
    9b04:      	ldr	x8, [x21, #0x28]
    9b08:      	ldr	x9, [sp, #0x8]
    9b0c:      	cmp	x8, x9
    9b10:      	b.ne	0x9bf8 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x200>
    9b14:      	ldp	x20, x19, [sp, #0x40]
    9b18:      	ldp	x22, x21, [sp, #0x30]
    9b1c:      	ldp	x24, x23, [sp, #0x20]
    9b20:      	ldp	x29, x30, [sp, #0x10]
    9b24:      	add	sp, sp, #0x50
    9b28:      	ret
    9b2c:      	tbz	w20, #0x0, 0x9bfc <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x204>
    9b30:      	mov	w22, #0x14              // =20
    9b34:      	b	0x9b50 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x158>
    9b38:      	ldr	w8, [x19, #0xb0]
    9b3c:      	orr	w8, w8, #0x8
    9b40:      	str	w8, [x19, #0xb0]
    9b44:      	ldr	w8, [x19, #0xb0]
    9b48:      	tst	w8, w22
    9b4c:      	b.ne	0x9a84 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x8c>
    9b50:      	tbnz	w8, #0x3, 0x9b80 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x188>
    9b54:      	ldr	x8, [x19, #0x10]
    9b58:      	ldr	x1, [sp]
    9b5c:      	ldr	x0, [x8]
    9b60:      	bl	0x12af0 <av_read_frame@plt>
    9b64:      	tbnz	w0, #0x1f, 0x9b38 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x140>
    9b68:      	ldr	x0, [sp]
    9b6c:      	ldr	x8, [x19, #0x10]
    9b70:      	ldr	w9, [x0, #0x24]
    9b74:      	ldr	w8, [x8, #0x20]
    9b78:      	cmp	w9, w8
    9b7c:      	b.ne	0x9bd8 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x1e0>
    9b80:      	mov	x1, sp
    9b84:      	mov	x0, x19
    9b88:      	bl	0x12f00 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket@plt>
    9b8c:      	cbz	w0, 0x9bb4 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x1bc>
    9b90:      	mov	w20, w0
    9b94:      	ldr	x0, [sp]
    9b98:      	cbz	x0, 0x9ba0 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x1a8>
    9b9c:      	bl	0x12b10 <av_packet_unref@plt>
    9ba0:      	cmn	w20, #0x2
    9ba4:      	b.ne	0x9b44 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x14c>
    9ba8:      	ldr	w8, [x19, #0xb0]
    9bac:      	orr	w8, w8, #0x4
    9bb0:      	b	0x9b40 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x148>
    9bb4:      	ldr	x8, [x19, #0x18]
    9bb8:      	ldr	x1, [sp]
    9bbc:      	ldr	x0, [x8]
    9bc0:      	bl	0x12f10 <av_interleaved_write_frame@plt>
    9bc4:      	tbz	w0, #0x1f, 0x9bd4 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x1dc>
    9bc8:      	ldr	w8, [x19, #0xb0]
    9bcc:      	orr	w8, w8, #0x4
    9bd0:      	str	w8, [x19, #0xb0]
    9bd4:      	ldr	x0, [sp]
    9bd8:      	bl	0x12b10 <av_packet_unref@plt>
    9bdc:      	b	0x9b44 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x14c>
    9be0:      	stur	xzr, [x19, #0x8]
    9be4:      	mov	w0, #-0x1               // =-1
    9be8:      	ldr	x8, [x21, #0x28]
    9bec:      	ldr	x9, [sp, #0x8]
    9bf0:      	cmp	x8, x9
    9bf4:      	b.eq	0x9b14 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x11c>
    9bf8:      	bl	0x12bc0 <__stack_chk_fail@plt>
    9bfc:      	mov	w20, #0xb0bb            // =45243
    9c00:      	mov	w22, #0x8               // =8
    9c04:      	mov	w23, #0x18              // =24
    9c08:      	movk	w20, #0xdfb9, lsl #16
    9c0c:      	mov	w24, #0x14              // =20
    9c10:      	b	0x9c68 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x270>
    9c14:      	ldr	w8, [x19, #0xb0]
    9c18:      	cmp	w0, w20
    9c1c:      	csel	w9, w23, w22, eq
    9c20:      	orr	w8, w8, w9
    9c24:      	str	w8, [x19, #0xb0]
    9c28:      	mov	w8, w8
    9c2c:      	tst	w8, w24
    9c30:      	b.eq	0x9c68 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x270>
    9c34:      	b	0x9a84 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x8c>
    9c38:      	ldr	x8, [x19, #0x18]
    9c3c:      	ldr	x0, [x8]
    9c40:      	bl	0x12f10 <av_interleaved_write_frame@plt>
    9c44:      	tbz	w0, #0x1f, 0x9c54 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x25c>
    9c48:      	ldr	w8, [x19, #0xb0]
    9c4c:      	orr	w8, w8, #0x4
    9c50:      	str	w8, [x19, #0xb0]
    9c54:      	ldr	x0, [sp]
    9c58:      	bl	0x12b10 <av_packet_unref@plt>
    9c5c:      	ldr	w8, [x19, #0xb0]
    9c60:      	tst	w8, w24
    9c64:      	b.ne	0x9a84 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x8c>
    9c68:      	ldr	x1, [sp]
    9c6c:      	tbnz	w8, #0x3, 0x9c38 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x240>
    9c70:      	ldr	x8, [x19, #0x10]
    9c74:      	ldr	x0, [x8]
    9c78:      	bl	0x12af0 <av_read_frame@plt>
    9c7c:      	tbnz	w0, #0x1f, 0x9c14 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x21c>
    9c80:      	ldr	x1, [sp]
    9c84:      	ldr	x8, [x19, #0x10]
    9c88:      	ldr	w9, [x1, #0x24]
    9c8c:      	ldr	w8, [x8, #0x20]
    9c90:      	cmp	w9, w8
    9c94:      	b.eq	0x9c38 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x240>
    9c98:      	mov	x0, x1
    9c9c:      	bl	0x12b10 <av_packet_unref@plt>
    9ca0:      	ldr	w8, [x19, #0xb0]
    9ca4:      	tst	w8, w24
    9ca8:      	b.eq	0x9c68 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x270>
    9cac:      	b	0x9a84 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv+0x8c>

0000000000009cb0 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket>:
    9cb0:      	sub	sp, sp, #0x60
    9cb4:      	stp	x29, x30, [sp, #0x20]
    9cb8:      	stp	x24, x23, [sp, #0x30]
    9cbc:      	stp	x22, x21, [sp, #0x40]
    9cc0:      	stp	x20, x19, [sp, #0x50]
    9cc4:      	add	x29, sp, #0x20
    9cc8:      	mrs	x22, TPIDR_EL0
    9ccc:      	ldr	x8, [x22, #0x28]
    9cd0:      	stur	x8, [x29, #-0x8]
    9cd4:      	cbz	x1, 0x9fcc <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x31c>
    9cd8:      	ldr	x8, [x1]
    9cdc:      	cbz	x8, 0x9fcc <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x31c>
    9ce0:      	ldr	w21, [x0, #0xb0]
    9ce4:      	mov	x19, x0
    9ce8:      	str	xzr, [sp, #0x10]
    9cec:      	tbnz	w21, #0x5, 0x9da4 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0xf4>
    9cf0:      	mov	w9, #0x88               // =136
    9cf4:      	mov	x20, x1
    9cf8:      	tst	w21, w9
    9cfc:      	b.eq	0x9d24 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x74>
    9d00:      	tbnz	w21, #0x6, 0x9d40 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x90>
    9d04:      	ldr	x8, [x19, #0x10]
    9d08:      	mov	x1, xzr
    9d0c:      	ldr	x0, [x8, #0x10]
    9d10:      	bl	0x12b00 <avcodec_send_packet@plt>
    9d14:      	ldr	w8, [x19, #0xb0]
    9d18:      	orr	w8, w8, #0x40
    9d1c:      	str	w8, [x19, #0xb0]
    9d20:      	b	0x9d40 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x90>
    9d24:      	ldr	x9, [x19, #0x10]
    9d28:      	mov	x1, x8
    9d2c:      	ldr	x0, [x9, #0x10]
    9d30:      	bl	0x12b00 <avcodec_send_packet@plt>
    9d34:      	cmn	w0, #0xb
    9d38:      	b.eq	0x9fcc <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x31c>
    9d3c:      	cbnz	w0, 0x9f14 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x264>
    9d40:      	bl	0x12b20 <av_frame_alloc@plt>
    9d44:      	str	x0, [sp, #0x10]
    9d48:      	cbz	x0, 0x9e1c <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x16c>
    9d4c:      	ldr	x8, [x19, #0x10]
    9d50:      	mov	x1, x0
    9d54:      	ldr	x0, [x8, #0x10]
    9d58:      	bl	0x12b30 <avcodec_receive_frame@plt>
    9d5c:      	cmn	w0, #0xb
    9d60:      	b.eq	0x9ea8 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x1f8>
    9d64:      	cbnz	w0, 0x9eb4 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x204>
    9d68:      	ldr	x8, [x19, #0x20]
    9d6c:      	mov	x1, x20
    9d70:      	cbz	x8, 0x9da4 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0xf4>
    9d74:      	tbnz	w21, #0x5, 0x9da4 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0xf4>
    9d78:      	add	x1, sp, #0x10
    9d7c:      	mov	x0, x19
    9d80:      	bl	0x12b50 <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame@plt>
    9d84:      	mov	x1, x20
    9d88:      	cbz	w0, 0x9da4 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0xf4>
    9d8c:      	ldr	x0, [sp, #0x10]
    9d90:      	cbz	x0, 0x9fcc <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x31c>
    9d94:      	ldr	x8, [x0, #0xb0]!
    9d98:      	cbz	x8, 0x9ec0 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x210>
    9d9c:      	bl	0x12bf0 <av_freep@plt>
    9da0:      	b	0x9ec0 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x210>
    9da4:      	ldr	w8, [x19, #0xb0]
    9da8:      	mov	w9, #0x420              // =1056
    9dac:      	tst	w8, w9
    9db0:      	b.eq	0x9e24 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x174>
    9db4:      	mov	x23, x1
    9db8:      	tbnz	w8, #0x9, 0x9dd8 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x128>
    9dbc:      	ldr	x8, [x19, #0x18]
    9dc0:      	mov	x1, xzr
    9dc4:      	ldr	x0, [x8, #0x10]
    9dc8:      	bl	0x12f20 <avcodec_send_frame@plt>
    9dcc:      	ldr	w8, [x19, #0xb0]
    9dd0:      	orr	w8, w8, #0x200
    9dd4:      	str	w8, [x19, #0xb0]
    9dd8:      	bl	0x12ab0 <av_packet_alloc@plt>
    9ddc:      	str	x0, [sp, #0x8]
    9de0:      	cbz	x0, 0x9e1c <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x16c>
    9de4:      	ldr	x8, [x19, #0x18]
    9de8:      	mov	x20, x0
    9dec:      	mov	x1, x20
    9df0:      	ldr	x0, [x8, #0x10]
    9df4:      	bl	0x12f30 <avcodec_receive_packet@plt>
    9df8:      	cmn	w0, #0xb
    9dfc:      	b.eq	0x9e9c <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x1ec>
    9e00:      	cbnz	w0, 0x9e7c <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x1cc>
    9e04:      	mov	x0, x23
    9e08:      	mov	x19, x23
    9e0c:      	bl	0x12b90 <av_packet_free@plt>
    9e10:      	mov	w0, wzr
    9e14:      	str	x20, [x23]
    9e18:      	b	0x9fd0 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x320>
    9e1c:      	mov	w0, #-0x2               // =-2
    9e20:      	b	0x9fd0 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x320>
    9e24:      	ldr	x20, [sp, #0x10]
    9e28:      	cbz	x20, 0x9ecc <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x21c>
    9e2c:      	ldr	x24, [x19, #0x30]
    9e30:      	mov	x23, x1
    9e34:      	tbnz	x24, #0x3f, 0x9f2c <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x27c>
    9e38:      	ldr	x8, [x19, #0x10]
    9e3c:      	mov	x21, #0x1               // =1
    9e40:      	ldr	x0, [x20, #0x88]
    9e44:      	movk	x21, #0x4240, lsl #32
    9e48:      	ldr	x8, [x8, #0x8]
    9e4c:      	movk	x21, #0xf, lsl #48
    9e50:      	mov	x2, x21
    9e54:      	ldr	x1, [x8, #0x18]
    9e58:      	bl	0x12e80 <av_rescale_q@plt>
    9e5c:      	ldr	x9, [x19, #0x38]
    9e60:      	mov	x8, x0
    9e64:      	add	x0, x9, x24
    9e68:      	cmp	x0, x8
    9e6c:      	b.le	0x9f50 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x2a0>
    9e70:      	add	x0, sp, #0x10
    9e74:      	bl	0x989c <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl+0x190>
    9e78:      	b	0x9fcc <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x31c>
    9e7c:      	ldr	w8, [x19, #0xb0]
    9e80:      	mov	w9, #0x100              // =256
    9e84:      	mov	w10, #0x400             // =1024
    9e88:      	tst	w8, #0x200
    9e8c:      	csel	w9, w10, w9, eq
    9e90:      	orr	w8, w8, w9
    9e94:      	orr	w8, w8, #0x10
    9e98:      	str	w8, [x19, #0xb0]
    9e9c:      	add	x0, sp, #0x8
    9ea0:      	bl	0x12b90 <av_packet_free@plt>
    9ea4:      	b	0x9fcc <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x31c>
    9ea8:      	ldr	w8, [x19, #0xb0]
    9eac:      	tbnz	w8, #0x6, 0x9eb8 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x208>
    9eb0:      	b	0x9ec0 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x210>
    9eb4:      	ldr	w8, [x19, #0xb0]
    9eb8:      	orr	w8, w8, #0x20
    9ebc:      	str	w8, [x19, #0xb0]
    9ec0:      	add	x0, sp, #0x10
    9ec4:      	bl	0x12b80 <av_frame_free@plt>
    9ec8:      	b	0x9fcc <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x31c>
    9ecc:      	ldr	x24, [x19, #0x18]
    9ed0:      	mov	x23, x1
    9ed4:      	ldr	x0, [x24, #0x10]
    9ed8:      	mov	x1, x20
    9edc:      	bl	0x12f20 <avcodec_send_frame@plt>
    9ee0:      	cbnz	w0, 0x9f80 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x2d0>
    9ee4:      	ldr	w8, [x19, #0x28]
    9ee8:      	ldr	x0, [sp, #0x10]
    9eec:      	add	w8, w8, #0x1
    9ef0:      	str	w8, [x19, #0x28]
    9ef4:      	cbz	x0, 0x9dd8 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x128>
    9ef8:      	ldr	x8, [x0, #0xb0]!
    9efc:      	cbz	x8, 0x9f04 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x254>
    9f00:      	bl	0x12bf0 <av_freep@plt>
    9f04:      	add	x0, sp, #0x10
    9f08:      	bl	0x12b80 <av_frame_free@plt>
    9f0c:      	str	xzr, [sp, #0x10]
    9f10:      	b	0x9dd8 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x128>
    9f14:      	ldr	w8, [x19, #0xb0]
    9f18:      	orr	w9, w8, #0x80
    9f1c:      	str	w9, [x19, #0xb0]
    9f20:      	tbnz	w8, #0x3, 0x9fcc <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x31c>
    9f24:      	mov	w9, #0x84               // =132
    9f28:      	b	0x9fbc <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x30c>
    9f2c:      	ldr	x24, [x19, #0x18]
    9f30:      	str	xzr, [x20, #0x88]
    9f34:      	mov	x1, #0x1                // =1
    9f38:      	str	xzr, [x19, #0x30]
    9f3c:      	movk	x1, #0x4240, lsl #32
    9f40:      	mov	x0, xzr
    9f44:      	ldr	x8, [x24, #0x8]
    9f48:      	movk	x1, #0xf, lsl #48
    9f4c:      	b	0x9f64 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x2b4>
    9f50:      	ldr	x24, [x19, #0x18]
    9f54:      	str	x0, [x20, #0x88]
    9f58:      	mov	x1, x21
    9f5c:      	str	x0, [x19, #0x30]
    9f60:      	ldr	x8, [x24, #0x8]
    9f64:      	ldr	x2, [x8, #0x18]
    9f68:      	bl	0x12e80 <av_rescale_q@plt>
    9f6c:      	str	x0, [x20, #0x88]
    9f70:      	ldr	x0, [x24, #0x10]
    9f74:      	mov	x1, x20
    9f78:      	bl	0x12f20 <avcodec_send_frame@plt>
    9f7c:      	cbz	w0, 0x9ee4 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x234>
    9f80:      	mov	w20, w0
    9f84:      	ldr	x0, [sp, #0x10]
    9f88:      	cbz	x0, 0x9fa0 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x2f0>
    9f8c:      	ldr	x8, [x0, #0xb0]!
    9f90:      	cbz	x8, 0x9f98 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x2e8>
    9f94:      	bl	0x12bf0 <av_freep@plt>
    9f98:      	add	x0, sp, #0x10
    9f9c:      	bl	0x12b80 <av_frame_free@plt>
    9fa0:      	cmn	w20, #0xb
    9fa4:      	b.eq	0x9fcc <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x31c>
    9fa8:      	ldr	w8, [x19, #0xb0]
    9fac:      	orr	w9, w8, #0x400
    9fb0:      	str	w9, [x19, #0xb0]
    9fb4:      	tbnz	w8, #0x5, 0x9fcc <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x31c>
    9fb8:      	mov	w9, #0x404              // =1028
    9fbc:      	orr	w8, w8, w9
    9fc0:      	mov	w0, #-0x1               // =-1
    9fc4:      	str	w8, [x19, #0xb0]
    9fc8:      	b	0x9fd0 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x320>
    9fcc:      	mov	w0, #-0x1               // =-1
    9fd0:      	ldr	x8, [x22, #0x28]
    9fd4:      	ldur	x9, [x29, #-0x8]
    9fd8:      	cmp	x8, x9
    9fdc:      	b.ne	0x9ff8 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket+0x348>
    9fe0:      	ldp	x20, x19, [sp, #0x50]
    9fe4:      	ldp	x22, x21, [sp, #0x40]
    9fe8:      	ldp	x24, x23, [sp, #0x30]
    9fec:      	ldp	x29, x30, [sp, #0x20]
    9ff0:      	add	sp, sp, #0x60
    9ff4:      	ret
    9ff8:      	bl	0x12bc0 <__stack_chk_fail@plt>

0000000000009ffc <_ZN13FormatConvert18VideoFormatTranserD2Ev>:
    9ffc:      	stp	x29, x30, [sp, #-0x20]!
    a000:      	stp	x20, x19, [sp, #0x10]
    a004:      	mov	x29, sp
    a008:      	mov	x19, x0
    a00c:      	bl	0x12bb0 <_ZN13FormatConvert18VideoFormatTranser8_releaseEv@plt>
    a010:      	mov	x0, x19
    a014:      	ldr	x8, [x0, #0xa0]!
    a018:      	cbz	x8, 0xa020 <_ZN13FormatConvert18VideoFormatTranserD2Ev+0x24>
    a01c:      	bl	0x12bf0 <av_freep@plt>
    a020:      	mov	x0, x19
    a024:      	ldr	x8, [x0, #0xa8]!
    a028:      	cbz	x8, 0xa030 <_ZN13FormatConvert18VideoFormatTranserD2Ev+0x34>
    a02c:      	bl	0x12bf0 <av_freep@plt>
    a030:      	ldr	x0, [x19, #0x10]
    a034:      	cbz	x0, 0xa040 <_ZN13FormatConvert18VideoFormatTranserD2Ev+0x44>
    a038:      	bl	0x12f40 <free@plt>
    a03c:      	str	xzr, [x19, #0x10]
    a040:      	ldr	x0, [x19, #0x18]
    a044:      	cbz	x0, 0xa050 <_ZN13FormatConvert18VideoFormatTranserD2Ev+0x54>
    a048:      	bl	0x12f40 <free@plt>
    a04c:      	str	xzr, [x19, #0x18]
    a050:      	ldr	x8, [x19, #0x120]
    a054:      	cbz	x8, 0xa090 <_ZN13FormatConvert18VideoFormatTranserD2Ev+0x94>
    a058:      	ldp	x8, x0, [x19, #0x110]
    a05c:      	add	x20, x19, #0x110
    a060:      	str	xzr, [x19, #0x120]
    a064:      	ldr	x8, [x8, #0x8]
    a068:      	ldr	x9, [x0]
    a06c:      	cmp	x0, x20
    a070:      	str	x8, [x9, #0x8]
    a074:      	str	x9, [x8]
    a078:      	b.eq	0xa090 <_ZN13FormatConvert18VideoFormatTranserD2Ev+0x94>
    a07c:      	ldr	x19, [x0, #0x8]
    a080:      	bl	0x12c80 <_ZdlPv@plt>
    a084:      	cmp	x19, x20
    a088:      	mov	x0, x19
    a08c:      	b.ne	0xa07c <_ZN13FormatConvert18VideoFormatTranserD2Ev+0x80>
    a090:      	ldp	x20, x19, [sp, #0x10]
    a094:      	ldp	x29, x30, [sp], #0x20
    a098:      	ret
    a09c:      	bl	0xa0a0 <_ZN13FormatConvert18VideoFormatTranserD2Ev+0xa4>
    a0a0:      	stp	x29, x30, [sp, #-0x10]!
    a0a4:      	mov	x29, sp
    a0a8:      	bl	0x12f50 <__cxa_begin_catch@plt>
    a0ac:      	bl	0x12f60 <_ZSt9terminatev@plt>

000000000000a0b0 <_ZN13FormatConvert18VideoFormatTranser22setInputVideoMediaFileEPc>:
    a0b0:      	stp	x29, x30, [sp, #-0x20]!
    a0b4:      	stp	x20, x19, [sp, #0x10]
    a0b8:      	mov	x29, sp
    a0bc:      	mov	x19, x0
    a0c0:      	mov	x20, x1
    a0c4:      	ldr	x8, [x19, #0xa0]!
    a0c8:      	cbz	x8, 0xa0d4 <_ZN13FormatConvert18VideoFormatTranser22setInputVideoMediaFileEPc+0x24>
    a0cc:      	mov	x0, x19
    a0d0:      	bl	0x12bf0 <av_freep@plt>
    a0d4:      	mov	x0, x20
    a0d8:      	bl	0x12f80 <av_strdup@plt>
    a0dc:      	str	x0, [x19]
    a0e0:      	ldp	x20, x19, [sp, #0x10]
    a0e4:      	ldp	x29, x30, [sp], #0x20
    a0e8:      	ret

000000000000a0ec <_ZN13FormatConvert18VideoFormatTranser23setVideoOutputFrameRateEf>:
    a0ec:      	ldr	w8, [x0]
    a0f0:      	cbz	w8, 0xa0f8 <_ZN13FormatConvert18VideoFormatTranser23setVideoOutputFrameRateEf+0xc>
    a0f4:      	str	s0, [x0, #0x98]
    a0f8:      	ret

000000000000a0fc <_ZN13FormatConvert18VideoFormatTranser23setVideoOutputPixFormatENS_16IMAGE_PIX_FORMATE>:
    a0fc:      	str	w1, [x0, #0x70]
    a100:      	ret

000000000000a104 <_ZN13FormatConvert18VideoFormatTranser21setVideoOutputBitrateEl>:
    a104:      	str	x1, [x0, #0x90]
    a108:      	ret

000000000000a10c <_ZN13FormatConvert18VideoFormatTranser18setVideoOutputSizeEii>:
    a10c:      	scvtf	s0, w1
    a110:      	scvtf	s1, w2
    a114:      	stp	s0, s1, [x0, #0x74]
    a118:      	ret

000000000000a11c <_ZN13FormatConvert18VideoFormatTranser23setOutputVideoMediaFileEPc>:
    a11c:      	stp	x29, x30, [sp, #-0x20]!
    a120:      	stp	x20, x19, [sp, #0x10]
    a124:      	mov	x29, sp
    a128:      	mov	x19, x0
    a12c:      	mov	x20, x1
    a130:      	ldr	x8, [x19, #0xa8]!
    a134:      	cbz	x8, 0xa140 <_ZN13FormatConvert18VideoFormatTranser23setOutputVideoMediaFileEPc+0x24>
    a138:      	mov	x0, x19
    a13c:      	bl	0x12bf0 <av_freep@plt>
    a140:      	mov	x0, x20
    a144:      	bl	0x12f80 <av_strdup@plt>
    a148:      	str	x0, [x19]
    a14c:      	ldp	x20, x19, [sp, #0x10]
    a150:      	ldp	x29, x30, [sp], #0x20
    a154:      	ret

000000000000a158 <_ZN5MTGifC2Ev>:
    a158:      	stp	x29, x30, [sp, #-0x20]!
    a15c:      	stp	x20, x19, [sp, #0x10]
    a160:      	mov	x29, sp
    a164:      	mov	x19, x0
    a168:      	mov	w0, #0xc7f0             // =51184
    a16c:      	bl	0x12b60 <_Znwm@plt>
    a170:      	mov	x20, x0
    a174:      	bl	0x12fd0 <_ZN11CMTImageGifC1Ev@plt>
    a178:      	str	x20, [x19]
    a17c:      	ldp	x20, x19, [sp, #0x10]
    a180:      	ldp	x29, x30, [sp], #0x20
    a184:      	ret
    a188:      	mov	x19, x0
    a18c:      	mov	x0, x20
    a190:      	bl	0x12c80 <_ZdlPv@plt>
    a194:      	mov	x0, x19
    a198:      	bl	0xeda0 <_ZN5mtgif9Video2Gif3runEv+0x3c8>

000000000000a19c <_ZN5MTGifD2Ev>:
    a19c:      	ldr	x0, [x0]
    a1a0:      	cbz	x0, 0xa1b0 <_ZN5MTGifD2Ev+0x14>
    a1a4:      	ldr	x8, [x0]
    a1a8:      	ldr	x1, [x8, #0x8]
    a1ac:      	br	x1
    a1b0:      	ret

000000000000a1b4 <_ZN5MTGif13SaveGifHeaderEPKciiii>:
    a1b4:      	ldr	x0, [x0]
    a1b8:      	b	0x12ff0 <_ZN11CMTImageGif13SaveGifHeaderEPKciiii@plt>

000000000000a1bc <_ZN5MTGif12SaveGifFrameEiPh>:
    a1bc:      	ldr	x0, [x0]
    a1c0:      	mov	x1, x2
    a1c4:      	mov	w2, wzr
    a1c8:      	b	0x13000 <_ZN11CMTImageGif12SaveGifFrameEPhi@plt>

000000000000a1cc <_ZN5MTGif12SaveGifFrameEPhi>:
    a1cc:      	ldr	x0, [x0]
    a1d0:      	b	0x13000 <_ZN11CMTImageGif12SaveGifFrameEPhi@plt>

000000000000a1d4 <_ZN5MTGif12SaveGifFrameEPh>:
    a1d4:      	ldr	x0, [x0]
    a1d8:      	mov	w2, wzr
    a1dc:      	b	0x13000 <_ZN11CMTImageGif12SaveGifFrameEPhi@plt>

000000000000a1e0 <_ZN5MTGif9SaveCloseEv>:
    a1e0:      	ldr	x0, [x0]
    a1e4:      	b	0x13030 <_ZN11CMTImageGif9SaveCloseEv@plt>

000000000000a1e8 <_ZN5MTGif12SetThreadNumEi>:
    a1e8:      	ldr	x0, [x0]
    a1ec:      	b	0x13040 <_ZN11CMTImageGif12SetThreadNumEi@plt>

000000000000a1f0 <get_nearest_index>:
    a1f0:      	sub	sp, sp, #0x30
    a1f4:      	stp	x29, x30, [sp, #0x20]
    a1f8:      	add	x29, sp, #0x20
    a1fc:      	mrs	x8, TPIDR_EL0
    a200:      	mov	w10, #0xd40             // =3392
    a204:      	movi	v1.2d, #0000000000000000
    a208:      	ldr	x9, [x8, #0x28]
    a20c:      	movk	w10, #0x3, lsl #16
    a210:      	movi	v0.4s, #0x20
    a214:      	movi	v5.2d, #0000000000000000
    a218:      	dup	v6.4s, w10
    a21c:      	stur	x9, [x29, #-0x8]
    a220:      	add	x9, x0, #0x2
    a224:      	ld1r	{ v2.16b }, [x0], #1
    a228:      	ld1r	{ v3.16b }, [x0]
    a22c:      	ld1r	{ v4.16b }, [x9]
    a230:      	mov	x9, xzr
    a234:      	add	x10, x1, x9
    a238:      	add	x9, x9, #0x60
    a23c:      	ldp	q7, q16, [x10]
    a240:      	ldr	q19, [x10, #0x20]
    a244:      	ldp	q18, q17, [x10, #0x30]
    a248:      	ldr	q20, [x10, #0x50]
    a24c:      	cmp	w9, #0x300
    a250:      	zip1	v21.16b, v7.16b, v18.16b
    a254:      	zip2	v7.16b, v7.16b, v18.16b
    a258:      	zip2	v18.16b, v16.16b, v17.16b
    a25c:      	zip1	v16.16b, v16.16b, v17.16b
    a260:      	zip1	v17.16b, v19.16b, v20.16b
    a264:      	zip2	v19.16b, v19.16b, v20.16b
    a268:      	zip1	v20.16b, v21.16b, v18.16b
    a26c:      	zip2	v18.16b, v21.16b, v18.16b
    a270:      	zip2	v21.16b, v7.16b, v17.16b
    a274:      	zip1	v22.16b, v16.16b, v19.16b
    a278:      	zip1	v7.16b, v7.16b, v17.16b
    a27c:      	zip2	v16.16b, v16.16b, v19.16b
    a280:      	zip1	v17.16b, v20.16b, v21.16b
    a284:      	zip2	v19.16b, v20.16b, v21.16b
    a288:      	zip2	v20.16b, v18.16b, v22.16b
    a28c:      	zip1	v18.16b, v18.16b, v22.16b
    a290:      	zip1	v21.16b, v7.16b, v16.16b
    a294:      	zip2	v7.16b, v7.16b, v16.16b
    a298:      	zip1	v16.16b, v17.16b, v20.16b
    a29c:      	zip2	v17.16b, v17.16b, v20.16b
    a2a0:      	zip2	v20.16b, v19.16b, v21.16b
    a2a4:      	zip1	v22.16b, v18.16b, v7.16b
    a2a8:      	zip1	v19.16b, v19.16b, v21.16b
    a2ac:      	zip2	v7.16b, v18.16b, v7.16b
    a2b0:      	zip1	v18.16b, v16.16b, v20.16b
    a2b4:      	zip1	v21.16b, v17.16b, v22.16b
    a2b8:      	zip2	v16.16b, v16.16b, v20.16b
    a2bc:      	zip1	v23.16b, v19.16b, v7.16b
    a2c0:      	zip2	v17.16b, v17.16b, v22.16b
    a2c4:      	zip2	v7.16b, v19.16b, v7.16b
    a2c8:      	uabd	v18.16b, v18.16b, v2.16b
    a2cc:      	uabd	v21.16b, v21.16b, v3.16b
    a2d0:      	uabd	v16.16b, v16.16b, v2.16b
    a2d4:      	uabd	v23.16b, v23.16b, v4.16b
    a2d8:      	uabd	v17.16b, v17.16b, v3.16b
    a2dc:      	uabd	v7.16b, v7.16b, v4.16b
    a2e0:      	umull	v24.8h, v18.8b, v18.8b
    a2e4:      	umull	v25.8h, v21.8b, v21.8b
    a2e8:      	umull2	v18.8h, v18.16b, v18.16b
    a2ec:      	umull	v26.8h, v23.8b, v23.8b
    a2f0:      	umull2	v20.8h, v21.16b, v21.16b
    a2f4:      	umull2	v19.8h, v23.16b, v23.16b
    a2f8:      	uaddl	v27.4s, v25.4h, v24.4h
    a2fc:      	uaddl2	v21.4s, v25.8h, v24.8h
    a300:      	umull	v25.8h, v16.8b, v16.8b
    a304:      	uaddl	v23.4s, v20.4h, v18.4h
    a308:      	uaddl2	v18.4s, v20.8h, v18.8h
    a30c:      	umull	v20.8h, v17.8b, v17.8b
    a310:      	umull2	v16.8h, v16.16b, v16.16b
    a314:      	umull2	v17.8h, v17.16b, v17.16b
    a318:      	uaddw	v22.4s, v27.4s, v26.4h
    a31c:      	uaddw2	v21.4s, v21.4s, v26.8h
    a320:      	uaddw	v23.4s, v23.4s, v19.4h
    a324:      	uaddw2	v18.4s, v18.4s, v19.8h
    a328:      	cmhi	v24.4s, v6.4s, v22.4s
    a32c:      	umin	v6.4s, v6.4s, v22.4s
    a330:      	mov	v22.16b, v1.16b
    a334:      	bit	v5.16b, v1.16b, v24.16b
    a338:      	orr	v22.4s, #0x4
    a33c:      	cmhi	v24.4s, v6.4s, v21.4s
    a340:      	umin	v6.4s, v6.4s, v21.4s
    a344:      	mov	v21.16b, v1.16b
    a348:      	bit	v5.16b, v22.16b, v24.16b
    a34c:      	umull	v22.8h, v7.8b, v7.8b
    a350:      	uaddl	v24.4s, v20.4h, v25.4h
    a354:      	umin	v19.4s, v6.4s, v23.4s
    a358:      	orr	v21.4s, #0x8
    a35c:      	cmhi	v6.4s, v6.4s, v23.4s
    a360:      	mov	v23.16b, v1.16b
    a364:      	uaddl2	v20.4s, v20.8h, v25.8h
    a368:      	umull2	v7.8h, v7.16b, v7.16b
    a36c:      	bit	v5.16b, v21.16b, v6.16b
    a370:      	uaddw	v24.4s, v24.4s, v22.4h
    a374:      	uaddl	v21.4s, v17.4h, v16.4h
    a378:      	umin	v6.4s, v19.4s, v18.4s
    a37c:      	orr	v23.4s, #0xc
    a380:      	cmhi	v18.4s, v19.4s, v18.4s
    a384:      	mov	v19.16b, v1.16b
    a388:      	uaddw2	v20.4s, v20.4s, v22.8h
    a38c:      	mov	v22.16b, v1.16b
    a390:      	uaddl2	v16.4s, v17.8h, v16.8h
    a394:      	bit	v5.16b, v23.16b, v18.16b
    a398:      	uaddw	v21.4s, v21.4s, v7.4h
    a39c:      	umin	v18.4s, v6.4s, v24.4s
    a3a0:      	orr	v19.4s, #0x10
    a3a4:      	cmhi	v6.4s, v6.4s, v24.4s
    a3a8:      	orr	v22.4s, #0x14
    a3ac:      	uaddw2	v7.4s, v16.4s, v7.8h
    a3b0:      	bit	v5.16b, v19.16b, v6.16b
    a3b4:      	umin	v6.4s, v18.4s, v20.4s
    a3b8:      	cmhi	v17.4s, v18.4s, v20.4s
    a3bc:      	mov	v18.16b, v1.16b
    a3c0:      	bit	v5.16b, v22.16b, v17.16b
    a3c4:      	orr	v18.4s, #0x18
    a3c8:      	cmhi	v17.4s, v6.4s, v21.4s
    a3cc:      	umin	v6.4s, v6.4s, v21.4s
    a3d0:      	bit	v5.16b, v18.16b, v17.16b
    a3d4:      	add	v17.4s, v1.4s, v0.4s
    a3d8:      	orr	v1.4s, #0x1c
    a3dc:      	cmhi	v16.4s, v6.4s, v7.4s
    a3e0:      	umin	v6.4s, v6.4s, v7.4s
    a3e4:      	bit	v5.16b, v1.16b, v16.16b
    a3e8:      	mov	v1.16b, v17.16b
    a3ec:      	b.ne	0xa234 <get_nearest_index+0x44>
    a3f0:      	fmov	w10, s6
    a3f4:      	mov	w9, v6.s[1]
    a3f8:      	mov	w11, #0xd40             // =3392
    a3fc:      	movk	w11, #0x3, lsl #16
    a400:      	mov	w12, v6.s[2]
    a404:      	str	q5, [sp]
    a408:      	cmp	w10, w11
    a40c:      	csel	w10, w10, w11, lo
    a410:      	mov	w11, v6.s[3]
    a414:      	cmp	w9, w10
    a418:      	csel	w9, w9, w10, lo
    a41c:      	cset	w10, lo
    a420:      	cmp	w12, w9
    a424:      	csel	w9, w12, w9, lo
    a428:      	mov	w12, #0x2               // =2
    a42c:      	csel	w10, w12, w10, lo
    a430:      	cmp	w11, w9
    a434:      	mov	w9, #0x3                // =3
    a438:      	csel	w9, w9, w10, lo
    a43c:      	mov	x10, sp
    a440:      	orr	x10, x10, x9, lsl #2
    a444:      	ldr	w10, [x10]
    a448:      	ldr	x8, [x8, #0x28]
    a44c:      	ldur	x11, [x29, #-0x8]
    a450:      	cmp	x8, x11
    a454:      	b.ne	0xa468 <get_nearest_index+0x278>
    a458:      	add	w0, w10, w9
    a45c:      	ldp	x29, x30, [sp, #0x20]
    a460:      	add	sp, sp, #0x30
    a464:      	ret
    a468:      	bl	0x12bc0 <__stack_chk_fail@plt>

000000000000a46c <_ZN11CMTImageGifC2Ev>:
    a46c:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
    a470:      	adrp	x9, 0x17000 <syscall@plt+0x3bf0>
    a474:      	movi	v0.2d, #0000000000000000
    a478:      	ldr	x8, [x8, #0x7b0]
    a47c:      	ldr	x9, [x9, #0x7b8]
    a480:      	add	x8, x8, #0x10
    a484:      	add	x9, x9, #0x10
    a488:      	str	x8, [x0]
    a48c:      	mov	w8, #0xc4b8             // =50360
    a490:      	add	x8, x0, x8
    a494:      	str	q0, [x0, #0xc4d0]
    a498:      	stp	x9, xzr, [x8]
    a49c:      	mov	w9, #0x1                // =1
    a4a0:      	strb	w9, [x8, #0x10]
    a4a4:      	str	d0, [x8, #0x328]
    a4a8:      	str	wzr, [x8, #0x330]
    a4ac:      	ret

000000000000a4b0 <_ZN11CMTImageGifD2Ev>:
    a4b0:      	stp	x29, x30, [sp, #-0x20]!
    a4b4:      	str	x19, [sp, #0x10]
    a4b8:      	mov	x29, sp
    a4bc:      	mov	w9, #0xc4b8             // =50360
    a4c0:      	mov	x8, x0
    a4c4:      	adrp	x10, 0x17000 <syscall@plt+0x3bf0>
    a4c8:      	add	x19, x0, x9
    a4cc:      	adrp	x9, 0x17000 <syscall@plt+0x3bf0>
    a4d0:      	ldr	x9, [x9, #0x7b0]
    a4d4:      	ldr	x0, [x19, #0x8]
    a4d8:      	ldr	x10, [x10, #0x7b8]
    a4dc:      	ldrb	w11, [x19, #0x10]
    a4e0:      	add	x9, x9, #0x10
    a4e4:      	cmp	x0, #0x0
    a4e8:      	str	x9, [x8]
    a4ec:      	add	x8, x10, #0x10
    a4f0:      	ccmp	w11, #0x0, #0x4, ne
    a4f4:      	str	x8, [x19]
    a4f8:      	b.eq	0xa504 <_ZN11CMTImageGifD2Ev+0x54>
    a4fc:      	bl	0x13080 <fclose@plt>
    a500:      	str	xzr, [x19, #0x8]
    a504:      	ldr	x19, [sp, #0x10]
    a508:      	ldp	x29, x30, [sp], #0x20
    a50c:      	ret

000000000000a510 <_ZN8CxIOFileD2Ev>:
    a510:      	stp	x29, x30, [sp, #-0x20]!
    a514:      	str	x19, [sp, #0x10]
    a518:      	mov	x29, sp
    a51c:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
    a520:      	mov	x19, x0
    a524:      	ldr	x8, [x8, #0x7b8]
    a528:      	ldr	x0, [x0, #0x8]
    a52c:      	add	x8, x8, #0x10
    a530:      	str	x8, [x19]
    a534:      	cbz	x0, 0xa548 <_ZN8CxIOFileD2Ev+0x38>
    a538:      	ldrb	w8, [x19, #0x10]
    a53c:      	cbz	w8, 0xa548 <_ZN8CxIOFileD2Ev+0x38>
    a540:      	bl	0x13080 <fclose@plt>
    a544:      	str	xzr, [x19, #0x8]
    a548:      	ldr	x19, [sp, #0x10]
    a54c:      	ldp	x29, x30, [sp], #0x20
    a550:      	ret

000000000000a554 <_ZN11CMTImageGifD0Ev>:
    a554:      	stp	x29, x30, [sp, #-0x20]!
    a558:      	str	x19, [sp, #0x10]
    a55c:      	mov	x29, sp
    a560:      	mov	x19, x0
    a564:      	bl	0x13090 <_ZN11CMTImageGifD1Ev@plt>
    a568:      	mov	x0, x19
    a56c:      	ldr	x19, [sp, #0x10]
    a570:      	ldp	x29, x30, [sp], #0x20
    a574:      	b	0x12c80 <_ZdlPv@plt>

000000000000a578 <_ZN11CMTImageGif7PutwordEiP6CxFile>:
    a578:      	stp	x29, x30, [sp, #-0x20]!
    a57c:      	stp	x20, x19, [sp, #0x10]
    a580:      	mov	x29, sp
    a584:      	ldr	x8, [x2]
    a588:      	mov	x0, x2
    a58c:      	mov	x19, x2
    a590:      	mov	w20, w1
    a594:      	ldr	x8, [x8, #0x58]
    a598:      	blr	x8
    a59c:      	ldr	x8, [x19]
    a5a0:      	lsr	w1, w20, #8
    a5a4:      	ldr	x2, [x8, #0x58]
    a5a8:      	mov	x0, x19
    a5ac:      	ldp	x20, x19, [sp, #0x10]
    a5b0:      	ldp	x29, x30, [sp], #0x20
    a5b4:      	br	x2

000000000000a5b8 <_ZN11CMTImageGif12EncodeHeaderEP6CxFilePh>:
    a5b8:      	stp	x29, x30, [sp, #-0x30]!
    a5bc:      	stp	x22, x21, [sp, #0x10]
    a5c0:      	stp	x20, x19, [sp, #0x20]
    a5c4:      	mov	x29, sp
    a5c8:      	ldr	x8, [x1]
    a5cc:      	mov	x20, x1
    a5d0:      	mov	x19, x2
    a5d4:      	add	x22, x0, #0xc, lsl #12  // =0xc000
    a5d8:      	nop
    a5dc:      	adr	x1, 0x5b0b
    a5e0:      	ldr	x8, [x8, #0x20]
    a5e4:      	mov	x0, x20
    a5e8:      	mov	w2, #0x1                // =1
    a5ec:      	mov	w3, #0x6                // =6
    a5f0:      	blr	x8
    a5f4:      	ldr	x8, [x20]
    a5f8:      	ldr	w21, [x22, #0x7e4]
    a5fc:      	mov	x0, x20
    a600:      	ldr	x8, [x8, #0x58]
    a604:      	mov	w1, w21
    a608:      	blr	x8
    a60c:      	ldr	x8, [x20]
    a610:      	lsr	w1, w21, #8
    a614:      	mov	x0, x20
    a618:      	ldr	x8, [x8, #0x58]
    a61c:      	blr	x8
    a620:      	ldr	x8, [x20]
    a624:      	ldr	w21, [x22, #0x7e8]
    a628:      	mov	x0, x20
    a62c:      	ldr	x8, [x8, #0x58]
    a630:      	mov	w1, w21
    a634:      	blr	x8
    a638:      	ldr	x8, [x20]
    a63c:      	lsr	w1, w21, #8
    a640:      	mov	x0, x20
    a644:      	ldr	x8, [x8, #0x58]
    a648:      	blr	x8
    a64c:      	ldr	x8, [x20]
    a650:      	mov	x0, x20
    a654:      	mov	w1, #0xe7               // =231
    a658:      	ldr	x8, [x8, #0x58]
    a65c:      	blr	x8
    a660:      	ldr	x8, [x20]
    a664:      	mov	x0, x20
    a668:      	mov	w1, wzr
    a66c:      	ldr	x8, [x8, #0x58]
    a670:      	blr	x8
    a674:      	ldr	x8, [x20]
    a678:      	mov	x0, x20
    a67c:      	mov	w1, wzr
    a680:      	ldr	x8, [x8, #0x58]
    a684:      	blr	x8
    a688:      	ldr	x8, [x20]
    a68c:      	mov	x0, x20
    a690:      	mov	x1, x19
    a694:      	mov	w2, #0x1                // =1
    a698:      	ldr	x4, [x8, #0x20]
    a69c:      	mov	w3, #0x300              // =768
    a6a0:      	ldp	x20, x19, [sp, #0x20]
    a6a4:      	ldp	x22, x21, [sp, #0x10]
    a6a8:      	ldp	x29, x30, [sp], #0x30
    a6ac:      	br	x4

000000000000a6b0 <_ZN11CMTImageGif19EncodeLoopExtensionEP6CxFile>:
    a6b0:      	stp	x29, x30, [sp, #-0x20]!
    a6b4:      	str	x19, [sp, #0x10]
    a6b8:      	mov	x29, sp
    a6bc:      	ldr	x8, [x1]
    a6c0:      	mov	x19, x1
    a6c4:      	mov	x0, x1
    a6c8:      	mov	w1, #0x21               // =33
    a6cc:      	ldr	x8, [x8, #0x58]
    a6d0:      	blr	x8
    a6d4:      	ldr	x8, [x19]
    a6d8:      	mov	x0, x19
    a6dc:      	mov	w1, #0xff               // =255
    a6e0:      	ldr	x8, [x8, #0x58]
    a6e4:      	blr	x8
    a6e8:      	ldr	x8, [x19]
    a6ec:      	mov	x0, x19
    a6f0:      	mov	w1, #0xb                // =11
    a6f4:      	ldr	x8, [x8, #0x58]
    a6f8:      	blr	x8
    a6fc:      	ldr	x8, [x19]
    a700:      	adrp	x1, 0x5000
    a704:      	add	x1, x1, #0x763
    a708:      	mov	x0, x19
    a70c:      	mov	w2, #0xb                // =11
    a710:      	mov	w3, #0x1                // =1
    a714:      	ldr	x8, [x8, #0x20]
    a718:      	blr	x8
    a71c:      	ldr	x8, [x19]
    a720:      	mov	x0, x19
    a724:      	mov	w1, #0x3                // =3
    a728:      	ldr	x8, [x8, #0x58]
    a72c:      	blr	x8
    a730:      	ldr	x8, [x19]
    a734:      	mov	x0, x19
    a738:      	mov	w1, #0x1                // =1
    a73c:      	ldr	x8, [x8, #0x58]
    a740:      	blr	x8
    a744:      	ldr	x8, [x19]
    a748:      	mov	x0, x19
    a74c:      	mov	w1, wzr
    a750:      	ldr	x8, [x8, #0x58]
    a754:      	blr	x8
    a758:      	ldr	x8, [x19]
    a75c:      	mov	x0, x19
    a760:      	mov	w1, wzr
    a764:      	ldr	x8, [x8, #0x58]
    a768:      	blr	x8
    a76c:      	ldr	x8, [x19]
    a770:      	mov	x0, x19
    a774:      	ldr	x2, [x8, #0x58]
    a778:      	mov	w1, wzr
    a77c:      	ldr	x19, [sp, #0x10]
    a780:      	ldp	x29, x30, [sp], #0x20
    a784:      	br	x2

000000000000a788 <_ZN11CMTImageGif15EncodeExtensionEP6CxFilei>:
    a788:      	stp	x29, x30, [sp, #-0x30]!
    a78c:      	stp	x22, x21, [sp, #0x10]
    a790:      	stp	x20, x19, [sp, #0x20]
    a794:      	mov	x29, sp
    a798:      	ldr	x8, [x1]
    a79c:      	mov	x19, x1
    a7a0:      	mov	x20, x0
    a7a4:      	mov	x0, x1
    a7a8:      	mov	w1, #0x21               // =33
    a7ac:      	mov	w21, w2
    a7b0:      	ldr	x8, [x8, #0x58]
    a7b4:      	blr	x8
    a7b8:      	ldr	x8, [x19]
    a7bc:      	mov	x0, x19
    a7c0:      	mov	w1, #0xf9               // =249
    a7c4:      	ldr	x8, [x8, #0x58]
    a7c8:      	blr	x8
    a7cc:      	mov	w8, #0x8                // =8
    a7d0:      	mov	x22, x20
    a7d4:      	mov	w9, #0xff               // =255
    a7d8:      	strb	w8, [x22, #0xc]!
    a7dc:      	ldur	w8, [x22, #-0x4]
    a7e0:      	ldr	x10, [x19]
    a7e4:      	strb	w9, [x22, #0x3]
    a7e8:      	mov	x0, x19
    a7ec:      	sturh	w8, [x22, #0x1]
    a7f0:      	mov	w1, #0x4                // =4
    a7f4:      	ldr	x8, [x10, #0x58]
    a7f8:      	blr	x8
    a7fc:      	cmp	w21, #0x1
    a800:      	b.lt	0xa810 <_ZN11CMTImageGif15EncodeExtensionEP6CxFilei+0x88>
    a804:      	ldurh	w8, [x20, #0xd]
    a808:      	madd	w8, w8, w21, w8
    a80c:      	sturh	w8, [x20, #0xd]
    a810:      	ldr	x8, [x19]
    a814:      	mov	x0, x19
    a818:      	mov	x1, x22
    a81c:      	mov	w2, #0x4                // =4
    a820:      	mov	w3, #0x1                // =1
    a824:      	ldr	x8, [x8, #0x20]
    a828:      	blr	x8
    a82c:      	ldurh	w8, [x20, #0xd]
    a830:      	ldr	x9, [x19]
    a834:      	mov	x0, x19
    a838:      	rev	w8, w8
    a83c:      	lsr	w8, w8, #16
    a840:      	sturh	w8, [x20, #0xd]
    a844:      	ldr	x2, [x9, #0x58]
    a848:      	mov	w1, wzr
    a84c:      	ldp	x20, x19, [sp, #0x20]
    a850:      	ldp	x22, x21, [sp, #0x10]
    a854:      	ldp	x29, x30, [sp], #0x30
    a858:      	br	x2

000000000000a85c <_ZN11CMTImageGif10EncodeBodyEP6CxFilePhS2_b>:
    a85c:      	stp	x29, x30, [sp, #-0x50]!
    a860:      	str	x25, [sp, #0x10]
    a864:      	stp	x24, x23, [sp, #0x20]
    a868:      	stp	x22, x21, [sp, #0x30]
    a86c:      	stp	x20, x19, [sp, #0x40]
    a870:      	mov	x29, sp
    a874:      	str	xzr, [x0, #0x10]
    a878:      	mov	x21, x0
    a87c:      	mov	x19, x1
    a880:      	ldr	x8, [x1]
    a884:      	add	x25, x0, #0xc, lsl #12  // =0xc000
    a888:      	mov	x0, x1
    a88c:      	mov	w1, #0x2c               // =44
    a890:      	mov	w23, w4
    a894:      	mov	x22, x3
    a898:      	ldr	x8, [x8, #0x58]
    a89c:      	mov	x20, x2
    a8a0:      	blr	x8
    a8a4:      	ldr	x8, [x19]
    a8a8:      	mov	x0, x19
    a8ac:      	mov	w1, wzr
    a8b0:      	ldr	x8, [x8, #0x58]
    a8b4:      	blr	x8
    a8b8:      	ldr	x8, [x19]
    a8bc:      	mov	x0, x19
    a8c0:      	mov	w1, wzr
    a8c4:      	ldr	x8, [x8, #0x58]
    a8c8:      	blr	x8
    a8cc:      	ldr	x8, [x19]
    a8d0:      	mov	x0, x19
    a8d4:      	mov	w1, wzr
    a8d8:      	ldr	x8, [x8, #0x58]
    a8dc:      	blr	x8
    a8e0:      	ldr	x8, [x19]
    a8e4:      	mov	x0, x19
    a8e8:      	mov	w1, wzr
    a8ec:      	ldr	x8, [x8, #0x58]
    a8f0:      	blr	x8
    a8f4:      	ldr	x8, [x19]
    a8f8:      	ldr	w24, [x25, #0x7e4]
    a8fc:      	mov	x0, x19
    a900:      	ldr	x8, [x8, #0x58]
    a904:      	mov	w1, w24
    a908:      	blr	x8
    a90c:      	ldr	x8, [x19]
    a910:      	lsr	w1, w24, #8
    a914:      	mov	x0, x19
    a918:      	ldr	x8, [x8, #0x58]
    a91c:      	blr	x8
    a920:      	ldr	x8, [x19]
    a924:      	ldr	w24, [x25, #0x7e8]
    a928:      	mov	x0, x19
    a92c:      	ldr	x8, [x8, #0x58]
    a930:      	mov	w1, w24
    a934:      	blr	x8
    a938:      	ldr	x8, [x19]
    a93c:      	lsr	w1, w24, #8
    a940:      	mov	x0, x19
    a944:      	ldr	x8, [x8, #0x58]
    a948:      	blr	x8
    a94c:      	ldr	x8, [x19]
    a950:      	tst	w23, #0x1
    a954:      	mov	w9, #-0x79              // =-121
    a958:      	csel	w1, w9, wzr, ne
    a95c:      	mov	x0, x19
    a960:      	ldr	x8, [x8, #0x58]
    a964:      	blr	x8
    a968:      	tbz	w23, #0x0, 0xa988 <_ZN11CMTImageGif10EncodeBodyEP6CxFilePhS2_b+0x12c>
    a96c:      	ldr	x8, [x19]
    a970:      	mov	x0, x19
    a974:      	mov	x1, x22
    a978:      	mov	w2, #0x1                // =1
    a97c:      	mov	w3, #0x300              // =768
    a980:      	ldr	x8, [x8, #0x20]
    a984:      	blr	x8
    a988:      	ldr	x8, [x19]
    a98c:      	mov	x0, x19
    a990:      	mov	w1, #0x8                // =8
    a994:      	ldr	x8, [x8, #0x58]
    a998:      	blr	x8
    a99c:      	mov	x0, x21
    a9a0:      	mov	w1, #0x9                // =9
    a9a4:      	mov	x2, x20
    a9a8:      	mov	x3, x19
    a9ac:      	bl	0x130a0 <_ZN11CMTImageGif11compressLZWEiPhP6CxFile@plt>
    a9b0:      	ldr	x8, [x19]
    a9b4:      	mov	x0, x19
    a9b8:      	ldr	x2, [x8, #0x58]
    a9bc:      	mov	w1, wzr
    a9c0:      	ldp	x20, x19, [sp, #0x40]
    a9c4:      	ldr	x25, [sp, #0x10]
    a9c8:      	ldp	x22, x21, [sp, #0x30]
    a9cc:      	ldp	x24, x23, [sp, #0x20]
    a9d0:      	ldp	x29, x30, [sp], #0x50
    a9d4:      	br	x2

000000000000a9d8 <_ZN11CMTImageGif11compressLZWEiPhP6CxFile>:
    a9d8:      	sub	sp, sp, #0x70
    a9dc:      	stp	x29, x30, [sp, #0x10]
    a9e0:      	stp	x28, x27, [sp, #0x20]
    a9e4:      	stp	x26, x25, [sp, #0x30]
    a9e8:      	stp	x24, x23, [sp, #0x40]
    a9ec:      	stp	x22, x21, [sp, #0x50]
    a9f0:      	stp	x20, x19, [sp, #0x60]
    a9f4:      	add	x29, sp, #0x10
    a9f8:      	mov	w8, #-0x1               // =-1
    a9fc:      	sub	w9, w1, #0x1
    aa00:      	mov	w10, #0x1               // =1
    aa04:      	lsl	w8, w8, w1
    aa08:      	add	x24, x0, #0xc, lsl #12  // =0xc000
    aa0c:      	lsl	w11, w10, w9
    aa10:      	ldr	w10, [x24, #0x7e8]
    aa14:      	mov	x20, x2
    aa18:      	mov	x19, x0
    aa1c:      	mvn	w8, w8
    aa20:      	add	w9, w11, #0x1
    aa24:      	str	w1, [x24, #0x3a4]
    aa28:      	strh	w8, [x24, #0x39c]
    aa2c:      	ldr	w8, [x0, #0x14]
    aa30:      	str	w9, [x24, #0x3b0]
    aa34:      	add	w9, w11, #0x2
    aa38:      	cmp	w8, w10
    aa3c:      	str	x3, [x24, #0x3a8]
    aa40:      	str	wzr, [x24, #0x3a0]
    aa44:      	str	wzr, [x0, #0x20]
    aa48:      	str	xzr, [x0, #0x18]
    aa4c:      	str	w1, [x24, #0x398]
    aa50:      	stur	w11, [x29, #-0x4]
    aa54:      	str	w9, [sp, #0x8]
    aa58:      	strh	w9, [x24, #0x39e]
    aa5c:      	str	wzr, [x24, #0x3b4]
    aa60:      	b.ne	0xaa6c <_ZN11CMTImageGif11compressLZWEiPhP6CxFile+0x94>
    aa64:      	mov	x23, #-0x1              // =-1
    aa68:      	b	0xaa90 <_ZN11CMTImageGif11compressLZWEiPhP6CxFile+0xb8>
    aa6c:      	ldr	w9, [x19, #0x10]
    aa70:      	ldr	w10, [x24, #0x7e4]
    aa74:      	add	w9, w9, #0x1
    aa78:      	cmp	w9, w10
    aa7c:      	str	w9, [x19, #0x10]
    aa80:      	b.ne	0xaa8c <_ZN11CMTImageGif11compressLZWEiPhP6CxFile+0xb4>
    aa84:      	add	w8, w8, #0x1
    aa88:      	stp	wzr, w8, [x19, #0x10]
    aa8c:      	ldrb	w23, [x20]
    aa90:      	add	x0, x19, #0x28
    aa94:      	mov	w1, #0xff               // =255
    aa98:      	mov	w2, #0x9c58             // =40024
    aa9c:      	bl	0x130b0 <memset@plt>
    aaa0:      	ldur	w1, [x29, #-0x4]
    aaa4:      	mov	x0, x19
    aaa8:      	bl	0x130c0 <_ZN11CMTImageGif6outputEs@plt>
    aaac:      	ldr	w8, [x19, #0x14]
    aab0:      	ldr	w9, [x24, #0x7e8]
    aab4:      	cmp	w8, w9
    aab8:      	b.ne	0xaaf4 <_ZN11CMTImageGif11compressLZWEiPhP6CxFile+0x11c>
    aabc:      	mov	x22, x23
    aac0:      	mov	x0, x19
    aac4:      	mov	w1, w22
    aac8:      	bl	0x130c0 <_ZN11CMTImageGif6outputEs@plt>
    aacc:      	ldr	w1, [x24, #0x3b0]
    aad0:      	mov	x0, x19
    aad4:      	ldp	x20, x19, [sp, #0x60]
    aad8:      	ldp	x22, x21, [sp, #0x50]
    aadc:      	ldp	x24, x23, [sp, #0x40]
    aae0:      	ldp	x26, x25, [sp, #0x30]
    aae4:      	ldp	x28, x27, [sp, #0x20]
    aae8:      	ldp	x29, x30, [sp, #0x10]
    aaec:      	add	sp, sp, #0x70
    aaf0:      	b	0x130c0 <_ZN11CMTImageGif6outputEs@plt>
    aaf4:      	mov	w26, #0x9c80            // =40064
    aaf8:      	mov	w27, #0x138b            // =5003
    aafc:      	b	0xab1c <_ZN11CMTImageGif11compressLZWEiPhP6CxFile+0x144>
    ab00:      	add	x8, x19, x25, lsl #1
    ab04:      	ldrh	w22, [x8, x26]
    ab08:      	ldr	w8, [x19, #0x14]
    ab0c:      	ldr	w9, [x24, #0x7e8]
    ab10:      	mov	x23, x22
    ab14:      	cmp	w8, w9
    ab18:      	b.eq	0xaac0 <_ZN11CMTImageGif11compressLZWEiPhP6CxFile+0xe8>
    ab1c:      	ldr	w9, [x19, #0x10]
    ab20:      	ldr	w10, [x24, #0x7e4]
    ab24:      	add	w9, w9, #0x1
    ab28:      	cmp	w9, w10
    ab2c:      	str	w9, [x19, #0x10]
    ab30:      	b.ne	0xab3c <_ZN11CMTImageGif11compressLZWEiPhP6CxFile+0x164>
    ab34:      	add	w8, w8, #0x1
    ab38:      	stp	wzr, w8, [x19, #0x10]
    ab3c:      	ldrb	w22, [x20, #0x1]!
    ab40:      	eor	x25, x23, x22, lsl #4
    ab44:      	add	x28, x23, x22, lsl #12
    ab48:      	add	x21, x19, x25, lsl #3
    ab4c:      	ldr	x8, [x21, #0x28]!
    ab50:      	cmp	x8, x28
    ab54:      	b.eq	0xab00 <_ZN11CMTImageGif11compressLZWEiPhP6CxFile+0x128>
    ab58:      	tbnz	x8, #0x3f, 0xab94 <_ZN11CMTImageGif11compressLZWEiPhP6CxFile+0x1bc>
    ab5c:      	mov	x8, #-0x138b            // =-5003
    ab60:      	cmp	x25, #0x0
    ab64:      	add	x8, x25, x8
    ab68:      	csinv	x8, x8, xzr, ne
    ab6c:      	add	x9, x25, x8
    ab70:      	add	x10, x9, x27
    ab74:      	cmp	x9, #0x0
    ab78:      	csel	x25, x10, x9, lt
    ab7c:      	add	x21, x19, x25, lsl #3
    ab80:      	ldr	x9, [x21, #0x28]!
    ab84:      	cmp	x9, x28
    ab88:      	b.eq	0xab00 <_ZN11CMTImageGif11compressLZWEiPhP6CxFile+0x128>
    ab8c:      	cmp	x9, #0x0
    ab90:      	b.gt	0xab6c <_ZN11CMTImageGif11compressLZWEiPhP6CxFile+0x194>
    ab94:      	mov	x0, x19
    ab98:      	mov	w1, w23
    ab9c:      	bl	0x130c0 <_ZN11CMTImageGif6outputEs@plt>
    aba0:      	ldrsh	w8, [x24, #0x39e]
    aba4:      	cmp	w8, #0xfff
    aba8:      	b.gt	0xabc4 <_ZN11CMTImageGif11compressLZWEiPhP6CxFile+0x1ec>
    abac:      	add	x10, x19, x25, lsl #1
    abb0:      	add	w9, w8, #0x1
    abb4:      	str	x28, [x21]
    abb8:      	strh	w9, [x24, #0x39e]
    abbc:      	strh	w8, [x10, x26]
    abc0:      	b	0xab08 <_ZN11CMTImageGif11compressLZWEiPhP6CxFile+0x130>
    abc4:      	add	x0, x19, #0x28
    abc8:      	mov	w1, #0xff               // =255
    abcc:      	mov	w2, #0x9c58             // =40024
    abd0:      	bl	0x130b0 <memset@plt>
    abd4:      	ldr	w8, [sp, #0x8]
    abd8:      	ldur	w1, [x29, #-0x4]
    abdc:      	mov	x0, x19
    abe0:      	strh	w8, [x24, #0x39e]
    abe4:      	mov	w8, #0x1                // =1
    abe8:      	str	w8, [x24, #0x3a0]
    abec:      	bl	0x130c0 <_ZN11CMTImageGif6outputEs@plt>
    abf0:      	b	0xab08 <_ZN11CMTImageGif11compressLZWEiPhP6CxFile+0x130>

000000000000abf4 <_ZN11CMTImageGif12GifNextPixelEPh>:
    abf4:      	add	x9, x0, #0xc, lsl #12   // =0xc000
    abf8:      	ldr	w8, [x0, #0x14]
    abfc:      	ldr	w10, [x9, #0x7e8]
    ac00:      	cmp	w8, w10
    ac04:      	b.ne	0xac10 <_ZN11CMTImageGif12GifNextPixelEPh+0x1c>
    ac08:      	mov	w0, #-0x1               // =-1
    ac0c:      	ret
    ac10:      	ldr	w10, [x0, #0x10]
    ac14:      	ldr	w9, [x9, #0x7e4]
    ac18:      	add	w10, w10, #0x1
    ac1c:      	cmp	w10, w9
    ac20:      	str	w10, [x0, #0x10]
    ac24:      	b.ne	0xac30 <_ZN11CMTImageGif12GifNextPixelEPh+0x3c>
    ac28:      	add	w8, w8, #0x1
    ac2c:      	stp	wzr, w8, [x0, #0x10]
    ac30:      	ldrb	w0, [x1]
    ac34:      	ret

000000000000ac38 <_ZN11CMTImageGif7cl_hashEi>:
    ac38:      	sbfiz	x2, x1, #3, #32
    ac3c:      	add	x0, x0, #0x28
    ac40:      	mov	w1, #0xff               // =255
    ac44:      	b	0x130b0 <memset@plt>

000000000000ac48 <_ZN11CMTImageGif6outputEs>:
    ac48:      	stp	x29, x30, [sp, #-0x30]!
    ac4c:      	stp	x22, x21, [sp, #0x10]
    ac50:      	stp	x20, x19, [sp, #0x20]
    ac54:      	mov	x29, sp
    ac58:      	ldr	w8, [x0, #0x20]
    ac5c:      	mov	w20, w1
    ac60:      	nop
    ac64:      	adr	x9, 0x6180
    ac68:      	sxth	x10, w20
    ac6c:      	ldr	x11, [x0, #0x18]
    ac70:      	ldr	x9, [x9, w8, sxtw #3]
    ac74:      	add	x21, x0, #0xc, lsl #12  // =0xc000
    ac78:      	cmp	w8, #0x0
    ac7c:      	lsl	x12, x10, x8
    ac80:      	mov	x19, x0
    ac84:      	and	x9, x11, x9
    ac88:      	ldr	w11, [x21, #0x398]
    ac8c:      	orr	x12, x9, x12
    ac90:      	add	w9, w11, w8
    ac94:      	csel	x8, x12, x10, gt
    ac98:      	cmp	w9, #0x8
    ac9c:      	str	x8, [x0, #0x18]
    aca0:      	str	w9, [x0, #0x20]
    aca4:      	b.lt	0xad28 <_ZN11CMTImageGif6outputEs+0xe0>
    aca8:      	ldr	w1, [x21, #0x3b4]
    acac:      	mov	w22, #0xc3b8            // =50104
    acb0:      	b	0xacd4 <_ZN11CMTImageGif6outputEs+0x8c>
    acb4:      	ldr	x8, [x19, #0x18]
    acb8:      	ldr	w10, [x19, #0x20]
    acbc:      	lsr	x8, x8, #8
    acc0:      	sub	w9, w10, #0x8
    acc4:      	cmp	w10, #0xf
    acc8:      	str	w9, [x19, #0x20]
    accc:      	str	x8, [x19, #0x18]
    acd0:      	b.le	0xad28 <_ZN11CMTImageGif6outputEs+0xe0>
    acd4:      	add	x10, x19, w1, sxtw
    acd8:      	add	w9, w1, #0x1
    acdc:      	str	w9, [x21, #0x3b4]
    ace0:      	strb	w8, [x10, x22]
    ace4:      	ldr	w1, [x21, #0x3b4]
    ace8:      	cmp	w1, #0xfe
    acec:      	b.lt	0xacb4 <_ZN11CMTImageGif6outputEs+0x6c>
    acf0:      	ldr	x0, [x21, #0x3a8]
    acf4:      	ldr	x8, [x0]
    acf8:      	ldr	x8, [x8, #0x58]
    acfc:      	blr	x8
    ad00:      	ldr	x0, [x21, #0x3a8]
    ad04:      	ldrsw	x3, [x21, #0x3b4]
    ad08:      	add	x1, x19, x22
    ad0c:      	mov	w2, #0x1                // =1
    ad10:      	ldr	x8, [x0]
    ad14:      	ldr	x8, [x8, #0x20]
    ad18:      	blr	x8
    ad1c:      	mov	w1, wzr
    ad20:      	str	wzr, [x21, #0x3b4]
    ad24:      	b	0xacb4 <_ZN11CMTImageGif6outputEs+0x6c>
    ad28:      	ldrsh	w11, [x21, #0x39e]
    ad2c:      	ldrsh	w12, [x21, #0x39c]
    ad30:      	ldr	w10, [x21, #0x3a0]
    ad34:      	cmp	w11, w12
    ad38:      	b.le	0xad5c <_ZN11CMTImageGif6outputEs+0x114>
    ad3c:      	cbnz	w10, 0xad60 <_ZN11CMTImageGif6outputEs+0x118>
    ad40:      	ldr	w10, [x21, #0x398]
    ad44:      	add	w10, w10, #0x1
    ad48:      	cmp	w10, #0xc
    ad4c:      	str	w10, [x21, #0x398]
    ad50:      	b.ne	0xae68 <_ZN11CMTImageGif6outputEs+0x220>
    ad54:      	mov	w10, #0x1000            // =4096
    ad58:      	b	0xae74 <_ZN11CMTImageGif6outputEs+0x22c>
    ad5c:      	cbz	w10, 0xad7c <_ZN11CMTImageGif6outputEs+0x134>
    ad60:      	ldr	w10, [x21, #0x3a4]
    ad64:      	mov	w11, #-0x1              // =-1
    ad68:      	str	wzr, [x21, #0x3a0]
    ad6c:      	lsl	w11, w11, w10
    ad70:      	str	w10, [x21, #0x398]
    ad74:      	mvn	w10, w11
    ad78:      	strh	w10, [x21, #0x39c]
    ad7c:      	ldr	w10, [x21, #0x3b0]
    ad80:      	cmp	w10, w20, sxth
    ad84:      	b.ne	0xae84 <_ZN11CMTImageGif6outputEs+0x23c>
    ad88:      	cmp	w9, #0x0
    ad8c:      	b.le	0xae0c <_ZN11CMTImageGif6outputEs+0x1c4>
    ad90:      	ldr	w1, [x21, #0x3b4]
    ad94:      	mov	w20, #0xc3b8            // =50104
    ad98:      	b	0xadb8 <_ZN11CMTImageGif6outputEs+0x170>
    ad9c:      	ldr	x8, [x19, #0x18]
    ada0:      	ldr	w9, [x19, #0x20]
    ada4:      	lsr	x8, x8, #8
    ada8:      	subs	w9, w9, #0x8
    adac:      	str	w9, [x19, #0x20]
    adb0:      	str	x8, [x19, #0x18]
    adb4:      	b.le	0xae10 <_ZN11CMTImageGif6outputEs+0x1c8>
    adb8:      	add	x10, x19, w1, sxtw
    adbc:      	add	w9, w1, #0x1
    adc0:      	str	w9, [x21, #0x3b4]
    adc4:      	strb	w8, [x10, x20]
    adc8:      	ldr	w1, [x21, #0x3b4]
    adcc:      	cmp	w1, #0xfe
    add0:      	b.lt	0xad9c <_ZN11CMTImageGif6outputEs+0x154>
    add4:      	ldr	x0, [x21, #0x3a8]
    add8:      	ldr	x8, [x0]
    addc:      	ldr	x8, [x8, #0x58]
    ade0:      	blr	x8
    ade4:      	ldr	x0, [x21, #0x3a8]
    ade8:      	ldrsw	x3, [x21, #0x3b4]
    adec:      	add	x1, x19, x20
    adf0:      	mov	w2, #0x1                // =1
    adf4:      	ldr	x8, [x0]
    adf8:      	ldr	x8, [x8, #0x20]
    adfc:      	blr	x8
    ae00:      	mov	w1, wzr
    ae04:      	str	wzr, [x21, #0x3b4]
    ae08:      	b	0xad9c <_ZN11CMTImageGif6outputEs+0x154>
    ae0c:      	ldr	w1, [x21, #0x3b4]
    ae10:      	cmp	w1, #0x1
    ae14:      	b.lt	0xae4c <_ZN11CMTImageGif6outputEs+0x204>
    ae18:      	ldr	x0, [x21, #0x3a8]
    ae1c:      	ldr	x8, [x0]
    ae20:      	ldr	x8, [x8, #0x58]
    ae24:      	blr	x8
    ae28:      	ldr	x0, [x21, #0x3a8]
    ae2c:      	ldrsw	x3, [x21, #0x3b4]
    ae30:      	mov	w9, #0xc3b8             // =50104
    ae34:      	add	x1, x19, x9
    ae38:      	mov	w2, #0x1                // =1
    ae3c:      	ldr	x8, [x0]
    ae40:      	ldr	x8, [x8, #0x20]
    ae44:      	blr	x8
    ae48:      	str	wzr, [x21, #0x3b4]
    ae4c:      	ldr	x0, [x21, #0x3a8]
    ae50:      	ldr	x8, [x0]
    ae54:      	ldr	x1, [x8, #0x40]
    ae58:      	ldp	x20, x19, [sp, #0x20]
    ae5c:      	ldp	x22, x21, [sp, #0x10]
    ae60:      	ldp	x29, x30, [sp], #0x30
    ae64:      	br	x1
    ae68:      	mov	w11, #-0x1              // =-1
    ae6c:      	lsl	w10, w11, w10
    ae70:      	mvn	w10, w10
    ae74:      	strh	w10, [x21, #0x39c]
    ae78:      	ldr	w10, [x21, #0x3b0]
    ae7c:      	cmp	w10, w20, sxth
    ae80:      	b.eq	0xad88 <_ZN11CMTImageGif6outputEs+0x140>
    ae84:      	ldp	x20, x19, [sp, #0x20]
    ae88:      	ldp	x22, x21, [sp, #0x10]
    ae8c:      	ldp	x29, x30, [sp], #0x30
    ae90:      	ret

000000000000ae94 <_ZN11CMTImageGif16GetNearestIndex2EPhS0_>:
    ae94:      	b	0x13070 <get_nearest_index@plt>

000000000000ae98 <_ZN11CMTImageGif8char_outEi>:
    ae98:      	stp	x29, x30, [sp, #-0x20]!
    ae9c:      	stp	x20, x19, [sp, #0x10]
    aea0:      	mov	x29, sp
    aea4:      	add	x20, x0, #0xc, lsl #12  // =0xc000
    aea8:      	mov	w8, #0xc3b8             // =50104
    aeac:      	ldrsw	x9, [x20, #0x3b4]
    aeb0:      	add	w10, w9, #0x1
    aeb4:      	add	x9, x0, x9
    aeb8:      	str	w10, [x20, #0x3b4]
    aebc:      	strb	w1, [x9, x8]
    aec0:      	ldr	w1, [x20, #0x3b4]
    aec4:      	cmp	w1, #0xfe
    aec8:      	b.lt	0xaf04 <_ZN11CMTImageGif8char_outEi+0x6c>
    aecc:      	mov	x19, x0
    aed0:      	ldr	x0, [x20, #0x3a8]
    aed4:      	ldr	x8, [x0]
    aed8:      	ldr	x8, [x8, #0x58]
    aedc:      	blr	x8
    aee0:      	ldr	x0, [x20, #0x3a8]
    aee4:      	ldrsw	x3, [x20, #0x3b4]
    aee8:      	mov	w9, #0xc3b8             // =50104
    aeec:      	add	x1, x19, x9
    aef0:      	mov	w2, #0x1                // =1
    aef4:      	ldr	x8, [x0]
    aef8:      	ldr	x8, [x8, #0x20]
    aefc:      	blr	x8
    af00:      	str	wzr, [x20, #0x3b4]
    af04:      	ldp	x20, x19, [sp, #0x10]
    af08:      	ldp	x29, x30, [sp], #0x20
    af0c:      	ret

000000000000af10 <_ZN11CMTImageGif10flush_charEv>:
    af10:      	stp	x29, x30, [sp, #-0x20]!
    af14:      	stp	x20, x19, [sp, #0x10]
    af18:      	mov	x29, sp
    af1c:      	add	x20, x0, #0xc, lsl #12  // =0xc000
    af20:      	ldr	w1, [x20, #0x3b4]
    af24:      	cmp	w1, #0x1
    af28:      	b.lt	0xaf64 <_ZN11CMTImageGif10flush_charEv+0x54>
    af2c:      	mov	x19, x0
    af30:      	ldr	x0, [x20, #0x3a8]
    af34:      	ldr	x8, [x0]
    af38:      	ldr	x8, [x8, #0x58]
    af3c:      	blr	x8
    af40:      	ldr	x0, [x20, #0x3a8]
    af44:      	ldrsw	x3, [x20, #0x3b4]
    af48:      	mov	w9, #0xc3b8             // =50104
    af4c:      	add	x1, x19, x9
    af50:      	mov	w2, #0x1                // =1
    af54:      	ldr	x8, [x0]
    af58:      	ldr	x8, [x8, #0x20]
    af5c:      	blr	x8
    af60:      	str	wzr, [x20, #0x3b4]
    af64:      	ldp	x20, x19, [sp, #0x10]
    af68:      	ldp	x29, x30, [sp], #0x20
    af6c:      	ret

000000000000af70 <_ZN11CMTImageGif12DecreaseBpp2EPv>:
    af70:      	sub	sp, sp, #0xd0
    af74:      	stp	x29, x30, [sp, #0x70]
    af78:      	stp	x28, x27, [sp, #0x80]
    af7c:      	stp	x26, x25, [sp, #0x90]
    af80:      	stp	x24, x23, [sp, #0xa0]
    af84:      	stp	x22, x21, [sp, #0xb0]
    af88:      	stp	x20, x19, [sp, #0xc0]
    af8c:      	add	x29, sp, #0x70
    af90:      	mrs	x8, TPIDR_EL0
    af94:      	str	x8, [sp, #0x8]
    af98:      	ldr	x8, [x8, #0x28]
    af9c:      	stur	x8, [x29, #-0x8]
    afa0:      	ldr	w25, [x0, #0x4]
    afa4:      	ldp	x28, x22, [x0, #0x30]
    afa8:      	ldp	w24, w19, [x0, #0xc]
    afac:      	add	w8, w25, w25, lsl #1
    afb0:      	str	x0, [sp]
    afb4:      	ldr	x20, [x0, #0x40]
    afb8:      	add	w8, w8, #0x6
    afbc:      	sbfiz	x23, x8, #2, #32
    afc0:      	cmp	w8, #0x0
    afc4:      	csinv	x0, x23, xzr, ge
    afc8:      	bl	0x130e0 <_Znam@plt>
    afcc:      	mov	w1, wzr
    afd0:      	mov	x2, x23
    afd4:      	mov	x21, x0
    afd8:      	bl	0x130b0 <memset@plt>
    afdc:      	cmp	w24, w19
    afe0:      	stur	w19, [x29, #-0x28]
    afe4:      	b.ge	0xb4b0 <_ZN11CMTImageGif12DecreaseBpp2EPv+0x540>
    afe8:      	mov	w23, #0xd40             // =3392
    afec:      	adrp	x8, 0x6000
    aff0:      	add	x9, x21, #0x18
    aff4:      	movk	w23, #0x3, lsl #16
    aff8:      	ldr	q29, [x8, #0x170]
    affc:      	mov	w19, #0xff              // =255
    b000:      	dup	v28.4s, w23
    b004:      	str	x9, [sp, #0x28]
    b008:      	str	q29, [sp, #0x10]
    b00c:      	str	q28, [sp, #0x30]
    b010:      	b	0xb028 <_ZN11CMTImageGif12DecreaseBpp2EPv+0xb8>
    b014:      	ldp	w8, w24, [x29, #-0x28]
    b018:      	mov	x22, x15
    b01c:      	add	w24, w24, #0x1
    b020:      	cmp	w24, w8
    b024:      	b.eq	0xb4b0 <_ZN11CMTImageGif12DecreaseBpp2EPv+0x540>
    b028:      	ldrb	w8, [x22]
    b02c:      	ldr	w9, [x21, #0xc]
    b030:      	mov	x0, x22
    b034:      	stur	w24, [x29, #-0x24]
    b038:      	mov	x1, x20
    b03c:      	add	w8, w9, w8
    b040:      	bic	w8, w8, w8, asr #31
    b044:      	cmp	w8, #0xff
    b048:      	csel	w27, w8, w19, lt
    b04c:      	ldrb	w8, [x22, #0x1]
    b050:      	strb	w27, [x22]
    b054:      	ldr	w9, [x21, #0x10]
    b058:      	add	w8, w9, w8
    b05c:      	bic	w8, w8, w8, asr #31
    b060:      	cmp	w8, #0xff
    b064:      	csel	w24, w8, w19, lt
    b068:      	ldrb	w8, [x22, #0x2]
    b06c:      	strb	w24, [x22, #0x1]
    b070:      	ldr	w9, [x21, #0x14]
    b074:      	strb	w27, [x22]
    b078:      	add	w8, w9, w8
    b07c:      	bic	w8, w8, w8, asr #31
    b080:      	cmp	w8, #0xff
    b084:      	csel	w26, w8, w19, lt
    b088:      	strb	w26, [x22, #0x2]
    b08c:      	bl	0x13070 <get_nearest_index@plt>
    b090:      	and	x8, x0, #0xff
    b094:      	strb	w0, [x28], #0x1
    b098:      	add	x8, x8, w0, uxtb #1
    b09c:      	ldrb	w9, [x22, #0x1]
    b0a0:      	ldrb	w11, [x22, #0x2]
    b0a4:      	ldrb	w13, [x22]
    b0a8:      	cmp	w25, #0x2
    b0ac:      	add	x15, x22, #0x4
    b0b0:      	add	x8, x20, x8
    b0b4:      	ldrb	w10, [x8, #0x1]
    b0b8:      	ldrb	w12, [x8, #0x2]
    b0bc:      	ldrb	w14, [x8]
    b0c0:      	sub	w8, w9, w10
    b0c4:      	sub	w9, w11, w12
    b0c8:      	sub	w11, w13, w14
    b0cc:      	asr	w10, w8, #4
    b0d0:      	asr	w12, w9, #4
    b0d4:      	asr	w13, w11, #2
    b0d8:      	stp	w10, w12, [x21, #0x1c]
    b0dc:      	asr	w10, w8, #2
    b0e0:      	asr	w12, w11, #4
    b0e4:      	stp	w13, w10, [x21, #0xc]
    b0e8:      	asr	w10, w9, #2
    b0ec:      	stp	w10, w12, [x21, #0x14]
    b0f0:      	b.lt	0xb014 <_ZN11CMTImageGif12DecreaseBpp2EPv+0xa4>
    b0f4:      	lsl	w10, w9, #3
    b0f8:      	movi	v27.4s, #0x20
    b0fc:      	lsl	w16, w8, #3
    b100:      	ldr	q28, [sp, #0x30]
    b104:      	ldr	q29, [sp, #0x10]
    b108:      	and	w14, w0, #0xff
    b10c:      	sub	w13, w10, w9
    b110:      	ldr	x9, [sp, #0x28]
    b114:      	sub	w16, w16, w8
    b118:      	mov	w8, #0x1                // =1
    b11c:      	mov	w2, #0x2                // =2
    b120:      	mov	w3, #0x3                // =3
    b124:      	sub	x4, x29, #0x20
    b128:      	b	0xb1c8 <_ZN11CMTImageGif12DecreaseBpp2EPv+0x258>
    b12c:      	mov	w11, w14
    b130:      	strb	w14, [x28], #0x1
    b134:      	add	x11, x11, w14, uxtw #1
    b138:      	mov	x15, x10
    b13c:      	ldrb	w16, [x22, #0x5]
    b140:      	add	w8, w8, #0x1
    b144:      	add	x12, x20, x11
    b148:      	ldrb	w11, [x15], #0x4
    b14c:      	ldrb	w13, [x12]
    b150:      	ldrb	w17, [x12, #0x1]
    b154:      	ldrb	w12, [x12, #0x2]
    b158:      	cmp	w8, w25
    b15c:      	sub	w11, w11, w13
    b160:      	sub	w13, w16, w17
    b164:      	ldrb	w16, [x22, #0x6]
    b168:      	fmov	s0, w11
    b16c:      	mov	x22, x10
    b170:      	sub	w16, w16, w12
    b174:      	asr	w12, w11, #4
    b178:      	asr	w1, w16, #4
    b17c:      	mov	v0.s[1], w13
    b180:      	str	w12, [x9, #0xc]!
    b184:      	ldp	w17, w0, [x9, #-0x8]
    b188:      	ldur	q1, [x9, #-0x18]
    b18c:      	mov	v0.s[2], w16
    b190:      	add	w17, w17, w13, asr #2
    b194:      	add	w0, w0, w16, asr #2
    b198:      	stp	w17, w0, [x9, #-0x8]
    b19c:      	lsl	w17, w13, #3
    b1a0:      	asr	w13, w13, #4
    b1a4:      	lsl	w0, w16, #3
    b1a8:      	mov	v0.s[3], w11
    b1ac:      	sub	w16, w17, w11
    b1b0:      	stp	w13, w1, [x9, #0x4]
    b1b4:      	sub	w13, w0, w11
    b1b8:      	sshl	v0.4s, v0.4s, v29.4s
    b1bc:      	add	v0.4s, v1.4s, v0.4s
    b1c0:      	stur	q0, [x9, #-0x18]
    b1c4:      	b.eq	0xb014 <_ZN11CMTImageGif12DecreaseBpp2EPv+0xa4>
    b1c8:      	ldrb	w10, [x22, #0x4]
    b1cc:      	add	w10, w12, w10
    b1d0:      	ldrb	w12, [x22, #0x5]
    b1d4:      	bic	w10, w10, w10, asr #31
    b1d8:      	cmp	w10, #0xff
    b1dc:      	csel	w10, w10, w19, lt
    b1e0:      	strb	w10, [x22, #0x4]
    b1e4:      	ldr	w17, [x9, #0x4]
    b1e8:      	add	w12, w17, w12
    b1ec:      	ldrb	w17, [x22, #0x6]
    b1f0:      	bic	w12, w12, w12, asr #31
    b1f4:      	cmp	w12, #0xff
    b1f8:      	csel	w12, w12, w19, lt
    b1fc:      	strb	w12, [x22, #0x5]
    b200:      	add	w12, w12, w16, asr #4
    b204:      	ldr	w0, [x9, #0x8]
    b208:      	bic	w12, w12, w12, asr #31
    b20c:      	add	w17, w0, w17
    b210:      	lsl	w0, w11, #3
    b214:      	bic	w17, w17, w17, asr #31
    b218:      	sub	w11, w0, w11
    b21c:      	cmp	w17, #0xff
    b220:      	add	w10, w10, w11, asr #4
    b224:      	csel	w11, w17, w19, lt
    b228:      	bic	w10, w10, w10, asr #31
    b22c:      	add	w11, w11, w13, asr #4
    b230:      	cmp	w10, #0xff
    b234:      	bic	w13, w11, w11, asr #31
    b238:      	csel	w11, w10, w19, lo
    b23c:      	cmp	w12, #0xff
    b240:      	mov	x10, x15
    b244:      	csel	w12, w12, w19, lo
    b248:      	cmp	w13, #0xff
    b24c:      	strb	w11, [x22, #0x4]
    b250:      	csel	w13, w13, w19, lo
    b254:      	cmp	w11, w27, uxtb
    b258:      	strb	w12, [x22, #0x5]
    b25c:      	strb	w13, [x22, #0x6]
    b260:      	b.ne	0xb27c <_ZN11CMTImageGif12DecreaseBpp2EPv+0x30c>
    b264:      	and	w15, w24, #0xff
    b268:      	cmp	w15, w12, uxtb
    b26c:      	b.ne	0xb27c <_ZN11CMTImageGif12DecreaseBpp2EPv+0x30c>
    b270:      	and	w15, w26, #0xff
    b274:      	cmp	w15, w13, uxtb
    b278:      	b.eq	0xb12c <_ZN11CMTImageGif12DecreaseBpp2EPv+0x1bc>
    b27c:      	movi	v1.2d, #0000000000000000
    b280:      	movi	v4.2d, #0000000000000000
    b284:      	mov	x14, xzr
    b288:      	dup	v0.16b, w11
    b28c:      	dup	v2.16b, w12
    b290:      	dup	v3.16b, w13
    b294:      	mov	v5.16b, v28.16b
    b298:      	add	x15, x20, x14
    b29c:      	add	x14, x14, #0x60
    b2a0:      	ldp	q6, q7, [x15]
    b2a4:      	ldr	q18, [x15, #0x20]
    b2a8:      	ldp	q17, q16, [x15, #0x30]
    b2ac:      	ldr	q19, [x15, #0x50]
    b2b0:      	cmp	w14, #0x300
    b2b4:      	zip1	v20.16b, v6.16b, v17.16b
    b2b8:      	zip2	v6.16b, v6.16b, v17.16b
    b2bc:      	zip2	v17.16b, v7.16b, v16.16b
    b2c0:      	zip1	v7.16b, v7.16b, v16.16b
    b2c4:      	zip1	v16.16b, v18.16b, v19.16b
    b2c8:      	zip2	v18.16b, v18.16b, v19.16b
    b2cc:      	zip1	v19.16b, v20.16b, v17.16b
    b2d0:      	zip2	v17.16b, v20.16b, v17.16b
    b2d4:      	zip2	v20.16b, v6.16b, v16.16b
    b2d8:      	zip1	v21.16b, v7.16b, v18.16b
    b2dc:      	zip1	v6.16b, v6.16b, v16.16b
    b2e0:      	zip2	v7.16b, v7.16b, v18.16b
    b2e4:      	zip1	v16.16b, v19.16b, v20.16b
    b2e8:      	zip2	v18.16b, v19.16b, v20.16b
    b2ec:      	zip2	v19.16b, v17.16b, v21.16b
    b2f0:      	zip1	v17.16b, v17.16b, v21.16b
    b2f4:      	zip1	v20.16b, v6.16b, v7.16b
    b2f8:      	zip2	v6.16b, v6.16b, v7.16b
    b2fc:      	zip1	v7.16b, v16.16b, v19.16b
    b300:      	zip2	v16.16b, v16.16b, v19.16b
    b304:      	zip2	v19.16b, v18.16b, v20.16b
    b308:      	zip1	v21.16b, v17.16b, v6.16b
    b30c:      	zip1	v18.16b, v18.16b, v20.16b
    b310:      	zip2	v6.16b, v17.16b, v6.16b
    b314:      	zip1	v17.16b, v7.16b, v19.16b
    b318:      	zip1	v20.16b, v16.16b, v21.16b
    b31c:      	zip2	v7.16b, v7.16b, v19.16b
    b320:      	zip1	v22.16b, v18.16b, v6.16b
    b324:      	zip2	v16.16b, v16.16b, v21.16b
    b328:      	zip2	v6.16b, v18.16b, v6.16b
    b32c:      	uabd	v17.16b, v17.16b, v0.16b
    b330:      	uabd	v20.16b, v20.16b, v2.16b
    b334:      	uabd	v7.16b, v7.16b, v0.16b
    b338:      	uabd	v22.16b, v22.16b, v3.16b
    b33c:      	uabd	v16.16b, v16.16b, v2.16b
    b340:      	uabd	v6.16b, v6.16b, v3.16b
    b344:      	umull	v23.8h, v17.8b, v17.8b
    b348:      	umull	v24.8h, v20.8b, v20.8b
    b34c:      	umull2	v17.8h, v17.16b, v17.16b
    b350:      	umull	v25.8h, v22.8b, v22.8b
    b354:      	umull2	v19.8h, v20.16b, v20.16b
    b358:      	umull2	v18.8h, v22.16b, v22.16b
    b35c:      	uaddl	v26.4s, v24.4h, v23.4h
    b360:      	uaddl2	v20.4s, v24.8h, v23.8h
    b364:      	umull	v24.8h, v7.8b, v7.8b
    b368:      	uaddl	v22.4s, v19.4h, v17.4h
    b36c:      	uaddl2	v17.4s, v19.8h, v17.8h
    b370:      	umull	v19.8h, v16.8b, v16.8b
    b374:      	umull2	v7.8h, v7.16b, v7.16b
    b378:      	umull2	v16.8h, v16.16b, v16.16b
    b37c:      	uaddw	v21.4s, v26.4s, v25.4h
    b380:      	uaddw2	v20.4s, v20.4s, v25.8h
    b384:      	uaddw	v22.4s, v22.4s, v18.4h
    b388:      	uaddw2	v17.4s, v17.4s, v18.8h
    b38c:      	cmhi	v23.4s, v5.4s, v21.4s
    b390:      	umin	v5.4s, v5.4s, v21.4s
    b394:      	mov	v21.16b, v1.16b
    b398:      	bit	v4.16b, v1.16b, v23.16b
    b39c:      	orr	v21.4s, #0x4
    b3a0:      	cmhi	v23.4s, v5.4s, v20.4s
    b3a4:      	umin	v5.4s, v5.4s, v20.4s
    b3a8:      	mov	v20.16b, v1.16b
    b3ac:      	bit	v4.16b, v21.16b, v23.16b
    b3b0:      	umull	v21.8h, v6.8b, v6.8b
    b3b4:      	uaddl	v23.4s, v19.4h, v24.4h
    b3b8:      	umin	v18.4s, v5.4s, v22.4s
    b3bc:      	orr	v20.4s, #0x8
    b3c0:      	cmhi	v5.4s, v5.4s, v22.4s
    b3c4:      	mov	v22.16b, v1.16b
    b3c8:      	uaddl2	v19.4s, v19.8h, v24.8h
    b3cc:      	umull2	v6.8h, v6.16b, v6.16b
    b3d0:      	bit	v4.16b, v20.16b, v5.16b
    b3d4:      	uaddw	v23.4s, v23.4s, v21.4h
    b3d8:      	uaddl	v20.4s, v16.4h, v7.4h
    b3dc:      	umin	v5.4s, v18.4s, v17.4s
    b3e0:      	orr	v22.4s, #0xc
    b3e4:      	cmhi	v17.4s, v18.4s, v17.4s
    b3e8:      	mov	v18.16b, v1.16b
    b3ec:      	uaddw2	v19.4s, v19.4s, v21.8h
    b3f0:      	mov	v21.16b, v1.16b
    b3f4:      	uaddl2	v7.4s, v16.8h, v7.8h
    b3f8:      	bit	v4.16b, v22.16b, v17.16b
    b3fc:      	uaddw	v20.4s, v20.4s, v6.4h
    b400:      	umin	v17.4s, v5.4s, v23.4s
    b404:      	orr	v18.4s, #0x10
    b408:      	cmhi	v5.4s, v5.4s, v23.4s
    b40c:      	orr	v21.4s, #0x14
    b410:      	uaddw2	v6.4s, v7.4s, v6.8h
    b414:      	bit	v4.16b, v18.16b, v5.16b
    b418:      	umin	v5.4s, v17.4s, v19.4s
    b41c:      	cmhi	v16.4s, v17.4s, v19.4s
    b420:      	mov	v17.16b, v1.16b
    b424:      	bit	v4.16b, v21.16b, v16.16b
    b428:      	orr	v17.4s, #0x18
    b42c:      	cmhi	v16.4s, v5.4s, v20.4s
    b430:      	umin	v5.4s, v5.4s, v20.4s
    b434:      	bit	v4.16b, v17.16b, v16.16b
    b438:      	add	v16.4s, v1.4s, v27.4s
    b43c:      	orr	v1.4s, #0x1c
    b440:      	cmhi	v7.4s, v5.4s, v6.4s
    b444:      	umin	v5.4s, v5.4s, v6.4s
    b448:      	bit	v4.16b, v1.16b, v7.16b
    b44c:      	mov	v1.16b, v16.16b
    b450:      	b.ne	0xb298 <_ZN11CMTImageGif12DecreaseBpp2EPv+0x328>
    b454:      	fmov	w15, s5
    b458:      	mov	w14, v5.s[1]
    b45c:      	stur	q4, [x29, #-0x20]
    b460:      	mov	w16, v5.s[2]
    b464:      	mov	w17, v5.s[3]
    b468:      	mov	w27, w11
    b46c:      	mov	w24, w12
    b470:      	mov	w26, w13
    b474:      	cmp	w15, w23
    b478:      	csel	w15, w15, w23, lo
    b47c:      	cmp	w14, w15
    b480:      	csel	w14, w14, w15, lo
    b484:      	cset	w15, lo
    b488:      	cmp	w16, w14
    b48c:      	csel	w14, w16, w14, lo
    b490:      	csel	w15, w2, w15, lo
    b494:      	cmp	w17, w14
    b498:      	csel	w14, w3, w15, lo
    b49c:      	orr	x15, x4, x14, lsl #2
    b4a0:      	ldr	w15, [x15]
    b4a4:      	add	w14, w15, w14
    b4a8:      	and	w14, w14, #0xff
    b4ac:      	b	0xb12c <_ZN11CMTImageGif12DecreaseBpp2EPv+0x1bc>
    b4b0:      	mov	x0, x21
    b4b4:      	bl	0x130f0 <_ZdaPv@plt>
    b4b8:      	ldr	x8, [sp]
    b4bc:      	ldr	w8, [x8]
    b4c0:      	cbnz	w8, 0xb4fc <_ZN11CMTImageGif12DecreaseBpp2EPv+0x58c>
    b4c4:      	ldr	x8, [sp, #0x8]
    b4c8:      	ldr	x8, [x8, #0x28]
    b4cc:      	ldur	x9, [x29, #-0x8]
    b4d0:      	cmp	x8, x9
    b4d4:      	b.ne	0xb518 <_ZN11CMTImageGif12DecreaseBpp2EPv+0x5a8>
    b4d8:      	mov	x0, xzr
    b4dc:      	ldp	x20, x19, [sp, #0xc0]
    b4e0:      	ldp	x22, x21, [sp, #0xb0]
    b4e4:      	ldp	x24, x23, [sp, #0xa0]
    b4e8:      	ldp	x26, x25, [sp, #0x90]
    b4ec:      	ldp	x28, x27, [sp, #0x80]
    b4f0:      	ldp	x29, x30, [sp, #0x70]
    b4f4:      	add	sp, sp, #0xd0
    b4f8:      	ret
    b4fc:      	ldr	x8, [sp, #0x8]
    b500:      	ldr	x8, [x8, #0x28]
    b504:      	ldur	x9, [x29, #-0x8]
    b508:      	cmp	x8, x9
    b50c:      	b.ne	0xb518 <_ZN11CMTImageGif12DecreaseBpp2EPv+0x5a8>
    b510:      	mov	x0, xzr
    b514:      	bl	0x13100 <pthread_exit@plt>
    b518:      	bl	0x12bc0 <__stack_chk_fail@plt>

000000000000b51c <_ZN11CMTImageGif13SaveGifHeaderEPKciiii>:
    b51c:      	stp	x29, x30, [sp, #-0x30]!
    b520:      	stp	x22, x21, [sp, #0x10]
    b524:      	stp	x20, x19, [sp, #0x20]
    b528:      	mov	x29, sp
    b52c:      	mov	w8, #0xc4b8             // =50360
    b530:      	mov	w21, w5
    b534:      	mov	x19, x0
    b538:      	add	x20, x0, x8
    b53c:      	ldr	x8, [x20, #0x8]
    b540:      	str	w2, [x20, #0x334]
    b544:      	str	w3, [x20, #0x32c]
    b548:      	str	w4, [x20, #0x330]
    b54c:      	cbnz	x8, 0xb574 <_ZN11CMTImageGif13SaveGifHeaderEPKciiii+0x58>
    b550:      	adrp	x8, 0x5000
    b554:      	add	x8, x8, #0xb15
    b558:      	mov	x0, x1
    b55c:      	mov	x1, x8
    b560:      	bl	0x13110 <fopen@plt>
    b564:      	str	x0, [x20, #0x8]
    b568:      	cbz	x0, 0xb574 <_ZN11CMTImageGif13SaveGifHeaderEPKciiii+0x58>
    b56c:      	mov	w8, #0x1                // =1
    b570:      	strb	w8, [x20, #0x10]
    b574:      	ldr	x8, [x20]
    b578:      	str	w21, [x19, #0x8]
    b57c:      	nop
    b580:      	adr	x1, 0x5b0b
    b584:      	mov	x0, x20
    b588:      	mov	w2, #0x1                // =1
    b58c:      	ldr	x8, [x8, #0x20]
    b590:      	mov	w3, #0x6                // =6
    b594:      	mov	w22, #0xc4e0            // =50400
    b598:      	blr	x8
    b59c:      	ldr	x8, [x20]
    b5a0:      	ldr	w21, [x20, #0x32c]
    b5a4:      	mov	x0, x20
    b5a8:      	ldr	x8, [x8, #0x58]
    b5ac:      	mov	w1, w21
    b5b0:      	blr	x8
    b5b4:      	ldr	x8, [x20]
    b5b8:      	lsr	w1, w21, #8
    b5bc:      	mov	x0, x20
    b5c0:      	ldr	x8, [x8, #0x58]
    b5c4:      	blr	x8
    b5c8:      	ldr	x8, [x20]
    b5cc:      	ldr	w21, [x20, #0x330]
    b5d0:      	mov	x0, x20
    b5d4:      	ldr	x8, [x8, #0x58]
    b5d8:      	mov	w1, w21
    b5dc:      	blr	x8
    b5e0:      	ldr	x8, [x20]
    b5e4:      	lsr	w1, w21, #8
    b5e8:      	mov	x0, x20
    b5ec:      	ldr	x8, [x8, #0x58]
    b5f0:      	blr	x8
    b5f4:      	ldr	x8, [x20]
    b5f8:      	mov	x0, x20
    b5fc:      	mov	w1, #0xe7               // =231
    b600:      	ldr	x8, [x8, #0x58]
    b604:      	blr	x8
    b608:      	ldr	x8, [x20]
    b60c:      	mov	x0, x20
    b610:      	mov	w1, wzr
    b614:      	ldr	x8, [x8, #0x58]
    b618:      	blr	x8
    b61c:      	ldr	x8, [x20]
    b620:      	mov	x0, x20
    b624:      	mov	w1, wzr
    b628:      	ldr	x8, [x8, #0x58]
    b62c:      	blr	x8
    b630:      	ldr	x8, [x20]
    b634:      	add	x1, x19, x22
    b638:      	mov	x0, x20
    b63c:      	mov	w2, #0x1                // =1
    b640:      	mov	w3, #0x300              // =768
    b644:      	ldr	x8, [x8, #0x20]
    b648:      	blr	x8
    b64c:      	ldr	x8, [x20]
    b650:      	mov	x0, x20
    b654:      	mov	w1, #0x21               // =33
    b658:      	ldr	x8, [x8, #0x58]
    b65c:      	blr	x8
    b660:      	ldr	x8, [x20]
    b664:      	mov	x0, x20
    b668:      	mov	w1, #0xff               // =255
    b66c:      	ldr	x8, [x8, #0x58]
    b670:      	blr	x8
    b674:      	ldr	x8, [x20]
    b678:      	mov	x0, x20
    b67c:      	mov	w1, #0xb                // =11
    b680:      	ldr	x8, [x8, #0x58]
    b684:      	blr	x8
    b688:      	ldr	x8, [x20]
    b68c:      	adrp	x1, 0x5000
    b690:      	add	x1, x1, #0x763
    b694:      	mov	x0, x20
    b698:      	mov	w2, #0xb                // =11
    b69c:      	mov	w3, #0x1                // =1
    b6a0:      	ldr	x8, [x8, #0x20]
    b6a4:      	blr	x8
    b6a8:      	ldr	x8, [x20]
    b6ac:      	mov	x0, x20
    b6b0:      	mov	w1, #0x3                // =3
    b6b4:      	ldr	x8, [x8, #0x58]
    b6b8:      	blr	x8
    b6bc:      	ldr	x8, [x20]
    b6c0:      	mov	x0, x20
    b6c4:      	mov	w1, #0x1                // =1
    b6c8:      	ldr	x8, [x8, #0x58]
    b6cc:      	blr	x8
    b6d0:      	ldr	x8, [x20]
    b6d4:      	mov	x0, x20
    b6d8:      	mov	w1, wzr
    b6dc:      	ldr	x8, [x8, #0x58]
    b6e0:      	blr	x8
    b6e4:      	ldr	x8, [x20]
    b6e8:      	mov	x0, x20
    b6ec:      	mov	w1, wzr
    b6f0:      	ldr	x8, [x8, #0x58]
    b6f4:      	blr	x8
    b6f8:      	ldr	x8, [x20]
    b6fc:      	mov	x0, x20
    b700:      	mov	w1, wzr
    b704:      	ldr	x8, [x8, #0x58]
    b708:      	blr	x8
    b70c:      	ldr	x0, [x20, #0x18]
    b710:      	cbz	x0, 0xb71c <_ZN11CMTImageGif13SaveGifHeaderEPKciiii+0x200>
    b714:      	bl	0x130f0 <_ZdaPv@plt>
    b718:      	str	xzr, [x20, #0x18]
    b71c:      	ldr	w8, [x20, #0x32c]
    b720:      	ldr	w9, [x20, #0x330]
    b724:      	mul	w8, w9, w8
    b728:      	cmp	w8, #0x0
    b72c:      	csinv	w8, w8, wzr, ge
    b730:      	sxtw	x0, w8
    b734:      	bl	0x130e0 <_Znam@plt>
    b738:      	ldr	x8, [x20, #0x20]
    b73c:      	str	x0, [x20, #0x18]
    b740:      	cbz	x8, 0xb758 <_ZN11CMTImageGif13SaveGifHeaderEPKciiii+0x23c>
    b744:      	ldr	x9, [x8]
    b748:      	mov	x0, x8
    b74c:      	ldr	x9, [x9, #0x8]
    b750:      	blr	x9
    b754:      	str	xzr, [x20, #0x20]
    b758:      	mov	w0, #0x70               // =112
    b75c:      	bl	0x12b60 <_Znwm@plt>
    b760:      	mov	x21, x0
    b764:      	mov	w1, #0x100              // =256
    b768:      	mov	w2, #0x8                // =8
    b76c:      	bl	0x13120 <_ZN10CQuantizerC1Ejj@plt>
    b770:      	add	x1, x19, x22
    b774:      	mov	x0, x21
    b778:      	str	x21, [x20, #0x20]
    b77c:      	bl	0x13130 <_ZN10CQuantizer13SetColorTableEPh@plt>
    b780:      	mov	w0, #0x1                // =1
    b784:      	ldp	x20, x19, [sp, #0x20]
    b788:      	ldp	x22, x21, [sp, #0x10]
    b78c:      	ldp	x29, x30, [sp], #0x30
    b790:      	ret
    b794:      	mov	x19, x0
    b798:      	mov	x0, x21
    b79c:      	bl	0x12c80 <_ZdlPv@plt>
    b7a0:      	mov	x0, x19
    b7a4:      	bl	0xeda0 <_ZN5mtgif9Video2Gif3runEv+0x3c8>

000000000000b7a8 <_ZN11CMTImageGif12SaveGifFrameEPhi>:
    b7a8:      	stp	x29, x30, [sp, #-0x60]!
    b7ac:      	stp	x28, x27, [sp, #0x10]
    b7b0:      	stp	x26, x25, [sp, #0x20]
    b7b4:      	stp	x24, x23, [sp, #0x30]
    b7b8:      	stp	x22, x21, [sp, #0x40]
    b7bc:      	stp	x20, x19, [sp, #0x50]
    b7c0:      	mov	x29, sp
    b7c4:      	sub	sp, sp, #0x60
    b7c8:      	mrs	x26, TPIDR_EL0
    b7cc:      	mov	w9, #0xc4b8             // =50360
    b7d0:      	mov	w25, w2
    b7d4:      	ldr	x8, [x26, #0x28]
    b7d8:      	add	x19, x0, x9
    b7dc:      	mov	x20, x0
    b7e0:      	mov	x24, x1
    b7e4:      	stur	x8, [x29, #-0x8]
    b7e8:      	ldr	x0, [x19, #0x20]
    b7ec:      	ldr	w2, [x19, #0x32c]
    b7f0:      	ldr	w3, [x19, #0x330]
    b7f4:      	bl	0x13140 <_ZN10CQuantizer13ProcessImage2EPhii@plt>
    b7f8:      	mov	w8, #0xc4e0             // =50400
    b7fc:      	ldr	x0, [x19, #0x20]
    b800:      	add	x21, x20, x8
    b804:      	mov	x1, x21
    b808:      	bl	0x13130 <_ZN10CQuantizer13SetColorTableEPh@plt>
    b80c:      	mov	w0, #0x61               // =97
    b810:      	bl	0x13150 <sysconf@plt>
    b814:      	and	x8, x0, #0xffffffff
    b818:      	mov	x9, sp
    b81c:      	lsl	x10, x8, #3
    b820:      	add	x10, x10, #0xf
    b824:      	and	x10, x10, #0xffffffff0
    b828:      	sub	x27, x9, x10
    b82c:      	mov	sp, x27
    b830:      	mov	w14, #0x48              // =72
    b834:      	mov	x9, sp
    b838:      	umull	x8, w8, w14
    b83c:      	add	x8, x8, #0xf
    b840:      	and	x8, x8, #0xfffffffff0
    b844:      	sub	x23, x9, x8
    b848:      	mov	sp, x23
    b84c:      	ldr	w9, [x19, #0x328]
    b850:      	ldr	w8, [x19, #0x330]
    b854:      	add	w10, w0, w0, lsl #1
    b858:      	mov	w11, #0x8               // =8
    b85c:      	mov	w13, #0x100             // =256
    b860:      	stp	x24, x21, [x23, #0x38]
    b864:      	cmp	w9, #0x0
    b868:      	str	x11, [x23, #0x18]
    b86c:      	ldr	w11, [x19, #0x32c]
    b870:      	csel	w9, w9, w0, gt
    b874:      	cmp	w8, w10, lsl #1
    b878:      	mov	w10, #0x1               // =1
    b87c:      	csinc	w28, w9, wzr, ge
    b880:      	strb	w10, [x23, #0x20]
    b884:      	sdiv	w9, w8, w28
    b888:      	subs	w12, w28, #0x1
    b88c:      	stp	wzr, w11, [x23]
    b890:      	cmp	w28, #0x1
    b894:      	stp	w8, wzr, [x23, #0x8]
    b898:      	mul	w2, w12, w9
    b89c:      	ldr	x12, [x19, #0x18]
    b8a0:      	stp	x13, x12, [x23, #0x28]
    b8a4:      	sub	w15, w8, w2
    b8a8:      	str	w15, [x23, #0x10]
    b8ac:      	b.le	0xb9d0 <_ZN11CMTImageGif12SaveGifFrameEPhi+0x228>
    b8b0:      	sub	w15, w15, #0x5
    b8b4:      	mov	w17, #0x2               // =2
    b8b8:      	mul	w16, w11, w9
    b8bc:      	mul	w15, w11, w15
    b8c0:      	sub	w17, w17, w28
    b8c4:      	mov	x0, #-0x48              // =-72
    b8c8:      	umaddl	x14, w28, w14, x0
    b8cc:      	mov	w3, #-0x5               // =-5
    b8d0:      	mov	x13, xzr
    b8d4:      	mul	w17, w9, w17
    b8d8:      	lsl	w1, w16, #2
    b8dc:      	sub	w2, w3, w2
    b8e0:      	lsl	w0, w15, #2
    b8e4:      	mov	w3, #0x8                // =8
    b8e8:      	mov	w4, #0x100              // =256
    b8ec:      	mov	w5, #0x1                // =1
    b8f0:      	mov	w6, w8
    b8f4:      	stur	w25, [x29, #-0x4c]
    b8f8:      	add	x7, x23, x13
    b8fc:      	add	w22, w2, w6
    b900:      	add	w25, w17, w6
    b904:      	stp	w8, w22, [x7, #0x50]
    b908:      	add	x22, x12, w15, sxtw
    b90c:      	add	x13, x13, #0x48
    b910:      	str	w25, [x7, #0x58]
    b914:      	add	x25, x24, w0, sxtw
    b918:      	add	w6, w6, w9
    b91c:      	stp	w5, w11, [x7, #0x48]
    b920:      	add	w0, w0, w1
    b924:      	cmp	x14, x13
    b928:      	add	w15, w15, w16
    b92c:      	add	w5, w5, #0x1
    b930:      	str	x3, [x7, #0x60]
    b934:      	strb	w10, [x7, #0x68]
    b938:      	stp	x4, x22, [x7, #0x70]
    b93c:      	stp	x25, x21, [x7, #0x80]
    b940:      	b.ne	0xb8f8 <_ZN11CMTImageGif12SaveGifFrameEPhi+0x150>
    b944:      	sub	x0, x29, #0x40
    b948:      	bl	0x13160 <pthread_attr_init@plt>
    b94c:      	ldur	w25, [x29, #-0x4c]
    b950:      	cmp	w28, #0x2
    b954:      	b.lt	0xb9d8 <_ZN11CMTImageGif12SaveGifFrameEPhi+0x230>
    b958:      	add	x8, x28, x28, lsl #3
    b95c:      	stur	x26, [x29, #-0x58]
    b960:      	adrp	x24, 0x17000 <syscall@plt+0x3bf0>
    b964:      	ldr	x24, [x24, #0x7c0]
    b968:      	add	x25, x27, #0x8
    b96c:      	mov	w22, #0x48              // =72
    b970:      	lsl	x26, x8, #3
    b974:      	add	x3, x23, x22
    b978:      	mov	x0, x25
    b97c:      	mov	x1, xzr
    b980:      	mov	x2, x24
    b984:      	bl	0x12ef0 <pthread_create@plt>
    b988:      	add	x22, x22, #0x48
    b98c:      	add	x25, x25, #0x8
    b990:      	cmp	x26, x22
    b994:      	b.ne	0xb974 <_ZN11CMTImageGif12SaveGifFrameEPhi+0x1cc>
    b998:      	mov	x0, x23
    b99c:      	bl	0x130d0 <_ZN11CMTImageGif12DecreaseBpp2EPv@plt>
    b9a0:      	ldur	x26, [x29, #-0x58]
    b9a4:      	ldur	w25, [x29, #-0x4c]
    b9a8:      	cmp	w28, #0x1
    b9ac:      	b.le	0xb9e0 <_ZN11CMTImageGif12SaveGifFrameEPhi+0x238>
    b9b0:      	add	x22, x27, #0x8
    b9b4:      	sub	x23, x28, #0x1
    b9b8:      	ldr	x0, [x22], #0x8
    b9bc:      	sub	x1, x29, #0x48
    b9c0:      	bl	0x12ea0 <pthread_join@plt>
    b9c4:      	subs	x23, x23, #0x1
    b9c8:      	b.ne	0xb9b8 <_ZN11CMTImageGif12SaveGifFrameEPhi+0x210>
    b9cc:      	b	0xb9e0 <_ZN11CMTImageGif12SaveGifFrameEPhi+0x238>
    b9d0:      	sub	x0, x29, #0x40
    b9d4:      	bl	0x13160 <pthread_attr_init@plt>
    b9d8:      	mov	x0, x23
    b9dc:      	bl	0x130d0 <_ZN11CMTImageGif12DecreaseBpp2EPv@plt>
    b9e0:      	ldr	x8, [x19]
    b9e4:      	mov	x0, x19
    b9e8:      	mov	w1, #0x21               // =33
    b9ec:      	ldr	x8, [x8, #0x58]
    b9f0:      	blr	x8
    b9f4:      	ldr	x8, [x19]
    b9f8:      	mov	x0, x19
    b9fc:      	mov	w1, #0xf9               // =249
    ba00:      	ldr	x8, [x8, #0x58]
    ba04:      	blr	x8
    ba08:      	mov	w8, #0x8                // =8
    ba0c:      	mov	x23, x20
    ba10:      	mov	w9, #0xff               // =255
    ba14:      	strb	w8, [x23, #0xc]!
    ba18:      	ldur	w8, [x23, #-0x4]
    ba1c:      	ldr	x10, [x19]
    ba20:      	strb	w9, [x23, #0x3]
    ba24:      	mov	x0, x19
    ba28:      	sturh	w8, [x23, #0x1]
    ba2c:      	mov	w1, #0x4                // =4
    ba30:      	ldr	x8, [x10, #0x58]
    ba34:      	blr	x8
    ba38:      	cmp	w25, #0x1
    ba3c:      	b.lt	0xba4c <_ZN11CMTImageGif12SaveGifFrameEPhi+0x2a4>
    ba40:      	ldurh	w8, [x20, #0xd]
    ba44:      	madd	w8, w8, w25, w8
    ba48:      	sturh	w8, [x20, #0xd]
    ba4c:      	ldr	x8, [x19]
    ba50:      	mov	x0, x19
    ba54:      	mov	x1, x23
    ba58:      	mov	w2, #0x4                // =4
    ba5c:      	mov	w3, #0x1                // =1
    ba60:      	ldr	x8, [x8, #0x20]
    ba64:      	blr	x8
    ba68:      	ldurh	w8, [x20, #0xd]
    ba6c:      	ldr	x9, [x19]
    ba70:      	mov	x0, x19
    ba74:      	mov	w1, wzr
    ba78:      	rev	w8, w8
    ba7c:      	lsr	w8, w8, #16
    ba80:      	sturh	w8, [x20, #0xd]
    ba84:      	ldr	x8, [x9, #0x58]
    ba88:      	blr	x8
    ba8c:      	ldr	x8, [x19]
    ba90:      	str	xzr, [x20, #0x10]
    ba94:      	mov	x0, x19
    ba98:      	ldr	x22, [x19, #0x18]
    ba9c:      	mov	w1, #0x2c               // =44
    baa0:      	ldr	x8, [x8, #0x58]
    baa4:      	blr	x8
    baa8:      	ldr	x8, [x19]
    baac:      	mov	x0, x19
    bab0:      	mov	w1, wzr
    bab4:      	ldr	x8, [x8, #0x58]
    bab8:      	blr	x8
    babc:      	ldr	x8, [x19]
    bac0:      	mov	x0, x19
    bac4:      	mov	w1, wzr
    bac8:      	ldr	x8, [x8, #0x58]
    bacc:      	blr	x8
    bad0:      	ldr	x8, [x19]
    bad4:      	mov	x0, x19
    bad8:      	mov	w1, wzr
    badc:      	ldr	x8, [x8, #0x58]
    bae0:      	blr	x8
    bae4:      	ldr	x8, [x19]
    bae8:      	mov	x0, x19
    baec:      	mov	w1, wzr
    baf0:      	ldr	x8, [x8, #0x58]
    baf4:      	blr	x8
    baf8:      	ldr	x8, [x19]
    bafc:      	ldr	w23, [x19, #0x32c]
    bb00:      	mov	x0, x19
    bb04:      	ldr	x8, [x8, #0x58]
    bb08:      	mov	w1, w23
    bb0c:      	blr	x8
    bb10:      	ldr	x8, [x19]
    bb14:      	lsr	w1, w23, #8
    bb18:      	mov	x0, x19
    bb1c:      	ldr	x8, [x8, #0x58]
    bb20:      	blr	x8
    bb24:      	ldr	x8, [x19]
    bb28:      	ldr	w23, [x19, #0x330]
    bb2c:      	mov	x0, x19
    bb30:      	ldr	x8, [x8, #0x58]
    bb34:      	mov	w1, w23
    bb38:      	blr	x8
    bb3c:      	ldr	x8, [x19]
    bb40:      	lsr	w1, w23, #8
    bb44:      	mov	x0, x19
    bb48:      	ldr	x8, [x8, #0x58]
    bb4c:      	blr	x8
    bb50:      	ldr	x8, [x19]
    bb54:      	mov	x0, x19
    bb58:      	mov	w1, #0x87               // =135
    bb5c:      	ldr	x8, [x8, #0x58]
    bb60:      	blr	x8
    bb64:      	ldr	x8, [x19]
    bb68:      	mov	x0, x19
    bb6c:      	mov	x1, x21
    bb70:      	mov	w2, #0x1                // =1
    bb74:      	mov	w3, #0x300              // =768
    bb78:      	ldr	x8, [x8, #0x20]
    bb7c:      	blr	x8
    bb80:      	ldr	x8, [x19]
    bb84:      	mov	x0, x19
    bb88:      	mov	w1, #0x8                // =8
    bb8c:      	ldr	x8, [x8, #0x58]
    bb90:      	blr	x8
    bb94:      	mov	x0, x20
    bb98:      	mov	w1, #0x9                // =9
    bb9c:      	mov	x2, x22
    bba0:      	mov	x3, x19
    bba4:      	bl	0x130a0 <_ZN11CMTImageGif11compressLZWEiPhP6CxFile@plt>
    bba8:      	ldr	x8, [x19]
    bbac:      	mov	x0, x19
    bbb0:      	mov	w1, wzr
    bbb4:      	ldr	x8, [x8, #0x58]
    bbb8:      	blr	x8
    bbbc:      	ldr	x8, [x26, #0x28]
    bbc0:      	ldur	x9, [x29, #-0x8]
    bbc4:      	cmp	x8, x9
    bbc8:      	b.ne	0xbbf0 <_ZN11CMTImageGif12SaveGifFrameEPhi+0x448>
    bbcc:      	mov	w0, #0x1                // =1
    bbd0:      	mov	sp, x29
    bbd4:      	ldp	x20, x19, [sp, #0x50]
    bbd8:      	ldp	x22, x21, [sp, #0x40]
    bbdc:      	ldp	x24, x23, [sp, #0x30]
    bbe0:      	ldp	x26, x25, [sp, #0x20]
    bbe4:      	ldp	x28, x27, [sp, #0x10]
    bbe8:      	ldp	x29, x30, [sp], #0x60
    bbec:      	ret
    bbf0:      	bl	0x12bc0 <__stack_chk_fail@plt>

000000000000bbf4 <_ZN11CMTImageGif9SaveCloseEv>:
    bbf4:      	stp	x29, x30, [sp, #-0x20]!
    bbf8:      	str	x19, [sp, #0x10]
    bbfc:      	mov	x29, sp
    bc00:      	add	x19, x0, #0xc, lsl #12  // =0xc000
    bc04:      	ldr	x1, [x19, #0x4c0]
    bc08:      	cbz	x1, 0xbc2c <_ZN11CMTImageGif9SaveCloseEv+0x38>
    bc0c:      	mov	w0, #0x3b               // =59
    bc10:      	bl	0x13170 <fputc@plt>
    bc14:      	ldr	x0, [x19, #0x4c0]
    bc18:      	cbz	x0, 0xbc2c <_ZN11CMTImageGif9SaveCloseEv+0x38>
    bc1c:      	ldrb	w8, [x19, #0x4c8]
    bc20:      	cbz	w8, 0xbc2c <_ZN11CMTImageGif9SaveCloseEv+0x38>
    bc24:      	bl	0x13080 <fclose@plt>
    bc28:      	str	xzr, [x19, #0x4c0]
    bc2c:      	ldr	x0, [x19, #0x4d0]
    bc30:      	cbz	x0, 0xbc3c <_ZN11CMTImageGif9SaveCloseEv+0x48>
    bc34:      	bl	0x130f0 <_ZdaPv@plt>
    bc38:      	str	xzr, [x19, #0x4d0]
    bc3c:      	ldr	x0, [x19, #0x4d8]
    bc40:      	cbz	x0, 0xbc54 <_ZN11CMTImageGif9SaveCloseEv+0x60>
    bc44:      	ldr	x8, [x0]
    bc48:      	ldr	x8, [x8, #0x8]
    bc4c:      	blr	x8
    bc50:      	str	xzr, [x19, #0x4d8]
    bc54:      	mov	w0, #0x1                // =1
    bc58:      	ldr	x19, [sp, #0x10]
    bc5c:      	ldp	x29, x30, [sp], #0x20
    bc60:      	ret

000000000000bc64 <_ZN8CxIOFile4PutCEh>:
    bc64:      	ldr	x8, [x0, #0x8]
    bc68:      	cbz	x8, 0xbc9c <_ZN8CxIOFile4PutCEh+0x38>
    bc6c:      	stp	x29, x30, [sp, #-0x20]!
    bc70:      	str	x19, [sp, #0x10]
    bc74:      	mov	x29, sp
    bc78:      	and	w19, w1, #0xff
    bc7c:      	mov	x1, x8
    bc80:      	mov	w0, w19
    bc84:      	bl	0x13170 <fputc@plt>
    bc88:      	cmp	w0, w19
    bc8c:      	cset	w0, eq
    bc90:      	ldr	x19, [sp, #0x10]
    bc94:      	ldp	x29, x30, [sp], #0x20
    bc98:      	ret
    bc9c:      	mov	w0, wzr
    bca0:      	ret

000000000000bca4 <_ZN8CxIOFile5CloseEv>:
    bca4:      	stp	x29, x30, [sp, #-0x20]!
    bca8:      	str	x19, [sp, #0x10]
    bcac:      	mov	x29, sp
    bcb0:      	ldr	x8, [x0, #0x8]
    bcb4:      	mov	x19, x0
    bcb8:      	mov	w0, #0x1                // =1
    bcbc:      	cbz	x8, 0xbcdc <_ZN8CxIOFile5CloseEv+0x38>
    bcc0:      	ldrb	w9, [x19, #0x10]
    bcc4:      	cbz	w9, 0xbcdc <_ZN8CxIOFile5CloseEv+0x38>
    bcc8:      	mov	x0, x8
    bccc:      	bl	0x13080 <fclose@plt>
    bcd0:      	cmp	w0, #0x0
    bcd4:      	str	xzr, [x19, #0x8]
    bcd8:      	cset	w0, eq
    bcdc:      	ldr	x19, [sp, #0x10]
    bce0:      	ldp	x29, x30, [sp], #0x20
    bce4:      	ret

000000000000bce8 <_ZN11CMTImageGif12SetThreadNumEi>:
    bce8:      	mov	x8, x0
    bcec:      	mov	w9, #0xc7e0             // =51168
    bcf0:      	mov	w0, #0x1                // =1
    bcf4:      	str	w1, [x8, x9]
    bcf8:      	ret

000000000000bcfc <_ZN8CxIOFileD0Ev>:
    bcfc:      	adrp	x9, 0x17000 <syscall@plt+0x3bf0>
    bd00:      	ldr	x9, [x9, #0x7b8]
    bd04:      	ldr	x8, [x0, #0x8]
    bd08:      	add	x9, x9, #0x10
    bd0c:      	str	x9, [x0]
    bd10:      	cbz	x8, 0xbd40 <_ZN8CxIOFileD0Ev+0x44>
    bd14:      	ldrb	w9, [x0, #0x10]
    bd18:      	cbz	w9, 0xbd40 <_ZN8CxIOFileD0Ev+0x44>
    bd1c:      	stp	x29, x30, [sp, #-0x20]!
    bd20:      	str	x19, [sp, #0x10]
    bd24:      	mov	x29, sp
    bd28:      	mov	x19, x0
    bd2c:      	mov	x0, x8
    bd30:      	bl	0x13080 <fclose@plt>
    bd34:      	mov	x0, x19
    bd38:      	ldr	x19, [sp, #0x10]
    bd3c:      	ldp	x29, x30, [sp], #0x20
    bd40:      	b	0x12c80 <_ZdlPv@plt>

000000000000bd44 <_ZN8CxIOFile4ReadEPvmm>:
    bd44:      	ldr	x8, [x0, #0x8]
    bd48:      	cbz	x8, 0xbd60 <_ZN8CxIOFile4ReadEPvmm+0x1c>
    bd4c:      	mov	x0, x1
    bd50:      	mov	x1, x2
    bd54:      	mov	x2, x3
    bd58:      	mov	x3, x8
    bd5c:      	b	0x13180 <fread@plt>
    bd60:      	mov	x0, xzr
    bd64:      	ret

000000000000bd68 <_ZN8CxIOFile5WriteEPKvmm>:
    bd68:      	ldr	x8, [x0, #0x8]
    bd6c:      	cbz	x8, 0xbd84 <_ZN8CxIOFile5WriteEPKvmm+0x1c>
    bd70:      	mov	x0, x1
    bd74:      	mov	x1, x2
    bd78:      	mov	x2, x3
    bd7c:      	mov	x3, x8
    bd80:      	b	0x13190 <fwrite@plt>
    bd84:      	mov	x0, xzr
    bd88:      	ret

000000000000bd8c <_ZN8CxIOFile4SeekEli>:
    bd8c:      	ldr	x0, [x0, #0x8]
    bd90:      	cbz	x0, 0xbdac <_ZN8CxIOFile4SeekEli+0x20>
    bd94:      	stp	x29, x30, [sp, #-0x10]!
    bd98:      	mov	x29, sp
    bd9c:      	bl	0x131a0 <fseek@plt>
    bda0:      	cmp	w0, #0x0
    bda4:      	cset	w0, eq
    bda8:      	ldp	x29, x30, [sp], #0x10
    bdac:      	ret

000000000000bdb0 <_ZN8CxIOFile4TellEv>:
    bdb0:      	ldr	x0, [x0, #0x8]
    bdb4:      	cbz	x0, 0xbdbc <_ZN8CxIOFile4TellEv+0xc>
    bdb8:      	b	0x131b0 <ftell@plt>
    bdbc:      	ret

000000000000bdc0 <_ZN8CxIOFile4SizeEv>:
    bdc0:      	stp	x29, x30, [sp, #-0x20]!
    bdc4:      	stp	x20, x19, [sp, #0x10]
    bdc8:      	mov	x29, sp
    bdcc:      	mov	x19, x0
    bdd0:      	ldr	x0, [x0, #0x8]
    bdd4:      	cbz	x0, 0xbe24 <_ZN8CxIOFile4SizeEv+0x64>
    bdd8:      	bl	0x131b0 <ftell@plt>
    bddc:      	ldr	x8, [x19, #0x8]
    bde0:      	mov	x20, x0
    bde4:      	mov	x1, xzr
    bde8:      	mov	w2, #0x2                // =2
    bdec:      	mov	x0, x8
    bdf0:      	bl	0x131a0 <fseek@plt>
    bdf4:      	ldr	x0, [x19, #0x8]
    bdf8:      	bl	0x131b0 <ftell@plt>
    bdfc:      	ldr	x8, [x19, #0x8]
    be00:      	mov	x19, x0
    be04:      	mov	x1, x20
    be08:      	mov	w2, wzr
    be0c:      	mov	x0, x8
    be10:      	bl	0x131a0 <fseek@plt>
    be14:      	mov	x0, x19
    be18:      	ldp	x20, x19, [sp, #0x10]
    be1c:      	ldp	x29, x30, [sp], #0x20
    be20:      	ret
    be24:      	mov	x0, #-0x1               // =-1
    be28:      	ldp	x20, x19, [sp, #0x10]
    be2c:      	ldp	x29, x30, [sp], #0x20
    be30:      	ret

000000000000be34 <_ZN8CxIOFile5FlushEv>:
    be34:      	ldr	x0, [x0, #0x8]
    be38:      	cbz	x0, 0xbe54 <_ZN8CxIOFile5FlushEv+0x20>
    be3c:      	stp	x29, x30, [sp, #-0x10]!
    be40:      	mov	x29, sp
    be44:      	bl	0x131c0 <fflush@plt>
    be48:      	cmp	w0, #0x0
    be4c:      	cset	w0, eq
    be50:      	ldp	x29, x30, [sp], #0x10
    be54:      	ret

000000000000be58 <_ZN8CxIOFile3EofEv>:
    be58:      	ldr	x0, [x0, #0x8]
    be5c:      	cbz	x0, 0xbe7c <_ZN8CxIOFile3EofEv+0x24>
    be60:      	stp	x29, x30, [sp, #-0x10]!
    be64:      	mov	x29, sp
    be68:      	bl	0x131d0 <feof@plt>
    be6c:      	cmp	w0, #0x0
    be70:      	cset	w0, ne
    be74:      	ldp	x29, x30, [sp], #0x10
    be78:      	ret
    be7c:      	mov	w0, #0x1                // =1
    be80:      	ret

000000000000be84 <_ZN8CxIOFile5ErrorEv>:
    be84:      	ldr	x0, [x0, #0x8]
    be88:      	cbz	x0, 0xbea4 <_ZN8CxIOFile5ErrorEv+0x20>
    be8c:      	stp	x29, x30, [sp, #-0x10]!
    be90:      	mov	x29, sp
    be94:      	bl	0x131e0 <ferror@plt>
    be98:      	sxtw	x0, w0
    be9c:      	ldp	x29, x30, [sp], #0x10
    bea0:      	ret
    bea4:      	mov	x0, #-0x1               // =-1
    bea8:      	ret

000000000000beac <_ZN8CxIOFile4GetCEv>:
    beac:      	ldr	x0, [x0, #0x8]
    beb0:      	cbz	x0, 0xbecc <_ZN8CxIOFile4GetCEv+0x20>
    beb4:      	stp	x29, x30, [sp, #-0x10]!
    beb8:      	mov	x29, sp
    bebc:      	bl	0x131f0 <getc@plt>
    bec0:      	sxtw	x0, w0
    bec4:      	ldp	x29, x30, [sp], #0x10
    bec8:      	ret
    becc:      	mov	x0, #-0x1               // =-1
    bed0:      	ret

000000000000bed4 <_ZN8CxIOFile4GetSEPci>:
    bed4:      	ldr	x8, [x0, #0x8]
    bed8:      	cbz	x8, 0xbeec <_ZN8CxIOFile4GetSEPci+0x18>
    bedc:      	mov	x0, x1
    bee0:      	mov	w1, w2
    bee4:      	mov	x2, x8
    bee8:      	b	0x13200 <fgets@plt>
    beec:      	mov	x0, xzr
    bef0:      	ret

000000000000bef4 <_ZN8CxIOFile5ScanfEPKcPv>:
    bef4:      	ldr	x0, [x0, #0x8]
    bef8:      	cbz	x0, 0xbf14 <_ZN8CxIOFile5ScanfEPKcPv+0x20>
    befc:      	stp	x29, x30, [sp, #-0x10]!
    bf00:      	mov	x29, sp
    bf04:      	bl	0x13210 <fscanf@plt>
    bf08:      	sxtw	x0, w0
    bf0c:      	ldp	x29, x30, [sp], #0x10
    bf10:      	ret
    bf14:      	mov	x0, #-0x1               // =-1
    bf18:      	ret

000000000000bf1c <_ZN10CQuantizerC2Ejj>:
    bf1c:      	stp	x29, x30, [sp, #-0x20]!
    bf20:      	stp	x20, x19, [sp, #0x10]
    bf24:      	mov	x29, sp
    bf28:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
    bf2c:      	cmp	w2, #0x8
    bf30:      	mov	w9, #0x8                // =8
    bf34:      	ldr	x8, [x8, #0x7c8]
    bf38:      	csel	w9, w2, w9, lo
    bf3c:      	mov	w19, w1
    bf40:      	str	w9, [x0, #0x68]
    bf44:      	lsl	w9, w9, #3
    bf48:      	mov	x20, x0
    bf4c:      	add	x8, x8, #0x10
    bf50:      	str	wzr, [x0, #0x10]
    bf54:      	mov	w1, wzr
    bf58:      	stp	x8, xzr, [x0], #0x18
    bf5c:      	add	w2, w9, #0x8
    bf60:      	bl	0x130b0 <memset@plt>
    bf64:      	cmp	w19, #0x10
    bf68:      	mov	w8, #0x10               // =16
    bf6c:      	csel	w8, w19, w8, hi
    bf70:      	stp	w8, w19, [x20, #0x60]
    bf74:      	ldp	x20, x19, [sp, #0x10]
    bf78:      	ldp	x29, x30, [sp], #0x20
    bf7c:      	ret

000000000000bf80 <_ZN10CQuantizerD2Ev>:
    bf80:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
    bf84:      	mov	x1, x0
    bf88:      	ldr	x8, [x8, #0x7c8]
    bf8c:      	ldr	x9, [x1, #0x8]!
    bf90:      	add	x8, x8, #0x10
    bf94:      	str	x8, [x0]
    bf98:      	cbz	x9, 0xbfa0 <_ZN10CQuantizerD2Ev+0x20>
    bf9c:      	b	0x13220 <_ZN10CQuantizer10DeleteTreeEPP5_NODE@plt>
    bfa0:      	ret

000000000000bfa4 <_ZN10CQuantizer10DeleteTreeEPP5_NODE>:
    bfa4:      	stp	x29, x30, [sp, #-0x20]!
    bfa8:      	stp	x20, x19, [sp, #0x10]
    bfac:      	mov	x29, sp
    bfb0:      	ldr	x8, [x1]
    bfb4:      	mov	x19, x1
    bfb8:      	mov	x20, x0
    bfbc:      	mov	x1, x8
    bfc0:      	ldr	x9, [x1, #0x18]!
    bfc4:      	cbz	x9, 0xbfd4 <_ZN10CQuantizer10DeleteTreeEPP5_NODE+0x30>
    bfc8:      	mov	x0, x20
    bfcc:      	bl	0x13220 <_ZN10CQuantizer10DeleteTreeEPP5_NODE@plt>
    bfd0:      	ldr	x8, [x19]
    bfd4:      	mov	x1, x8
    bfd8:      	ldr	x9, [x1, #0x20]!
    bfdc:      	cbz	x9, 0xbfec <_ZN10CQuantizer10DeleteTreeEPP5_NODE+0x48>
    bfe0:      	mov	x0, x20
    bfe4:      	bl	0x13220 <_ZN10CQuantizer10DeleteTreeEPP5_NODE@plt>
    bfe8:      	ldr	x8, [x19]
    bfec:      	mov	x1, x8
    bff0:      	ldr	x9, [x1, #0x28]!
    bff4:      	cbz	x9, 0xc004 <_ZN10CQuantizer10DeleteTreeEPP5_NODE+0x60>
    bff8:      	mov	x0, x20
    bffc:      	bl	0x13220 <_ZN10CQuantizer10DeleteTreeEPP5_NODE@plt>
    c000:      	ldr	x8, [x19]
    c004:      	mov	x1, x8
    c008:      	ldr	x9, [x1, #0x30]!
    c00c:      	cbz	x9, 0xc01c <_ZN10CQuantizer10DeleteTreeEPP5_NODE+0x78>
    c010:      	mov	x0, x20
    c014:      	bl	0x13220 <_ZN10CQuantizer10DeleteTreeEPP5_NODE@plt>
    c018:      	ldr	x8, [x19]
    c01c:      	mov	x1, x8
    c020:      	ldr	x9, [x1, #0x38]!
    c024:      	cbz	x9, 0xc034 <_ZN10CQuantizer10DeleteTreeEPP5_NODE+0x90>
    c028:      	mov	x0, x20
    c02c:      	bl	0x13220 <_ZN10CQuantizer10DeleteTreeEPP5_NODE@plt>
    c030:      	ldr	x8, [x19]
    c034:      	mov	x1, x8
    c038:      	ldr	x9, [x1, #0x40]!
    c03c:      	cbz	x9, 0xc04c <_ZN10CQuantizer10DeleteTreeEPP5_NODE+0xa8>
    c040:      	mov	x0, x20
    c044:      	bl	0x13220 <_ZN10CQuantizer10DeleteTreeEPP5_NODE@plt>
    c048:      	ldr	x8, [x19]
    c04c:      	mov	x1, x8
    c050:      	ldr	x9, [x1, #0x48]!
    c054:      	cbz	x9, 0xc064 <_ZN10CQuantizer10DeleteTreeEPP5_NODE+0xc0>
    c058:      	mov	x0, x20
    c05c:      	bl	0x13220 <_ZN10CQuantizer10DeleteTreeEPP5_NODE@plt>
    c060:      	ldr	x8, [x19]
    c064:      	mov	x1, x8
    c068:      	ldr	x9, [x1, #0x50]!
    c06c:      	cbz	x9, 0xc07c <_ZN10CQuantizer10DeleteTreeEPP5_NODE+0xd8>
    c070:      	mov	x0, x20
    c074:      	bl	0x13220 <_ZN10CQuantizer10DeleteTreeEPP5_NODE@plt>
    c078:      	ldr	x8, [x19]
    c07c:      	mov	x0, x8
    c080:      	bl	0x12f40 <free@plt>
    c084:      	str	xzr, [x19]
    c088:      	ldp	x20, x19, [sp, #0x10]
    c08c:      	ldp	x29, x30, [sp], #0x20
    c090:      	ret

000000000000c094 <_ZN10CQuantizerD0Ev>:
    c094:      	stp	x29, x30, [sp, #-0x20]!
    c098:      	str	x19, [sp, #0x10]
    c09c:      	mov	x29, sp
    c0a0:      	mov	x19, x0
    c0a4:      	bl	0x13230 <_ZN10CQuantizerD1Ev@plt>
    c0a8:      	mov	x0, x19
    c0ac:      	ldr	x19, [sp, #0x10]
    c0b0:      	ldp	x29, x30, [sp], #0x20
    c0b4:      	b	0x12c80 <_ZdlPv@plt>

000000000000c0b8 <_ZN10CQuantizer13ProcessImage2EPhii>:
    c0b8:      	sub	sp, sp, #0x90
    c0bc:      	stp	x29, x30, [sp, #0x30]
    c0c0:      	stp	x28, x27, [sp, #0x40]
    c0c4:      	stp	x26, x25, [sp, #0x50]
    c0c8:      	stp	x24, x23, [sp, #0x60]
    c0cc:      	stp	x22, x21, [sp, #0x70]
    c0d0:      	stp	x20, x19, [sp, #0x80]
    c0d4:      	add	x29, sp, #0x30
    c0d8:      	str	w3, [sp, #0x8]
    c0dc:      	str	w2, [sp, #0x18]
    c0e0:      	str	x1, [sp]
    c0e4:      	cbz	x1, 0xc298 <_ZN10CQuantizer13ProcessImage2EPhii+0x1e0>
    c0e8:      	ldr	w8, [sp, #0x8]
    c0ec:      	cmp	w8, #0x1
    c0f0:      	b.lt	0xc298 <_ZN10CQuantizer13ProcessImage2EPhii+0x1e0>
    c0f4:      	ldr	w8, [sp, #0x18]
    c0f8:      	cmp	w8, #0x1
    c0fc:      	b.lt	0xc298 <_ZN10CQuantizer13ProcessImage2EPhii+0x1e0>
    c100:      	ldur	w20, [x0, #0x10]
    c104:      	ldr	x10, [sp]
    c108:      	mov	x22, x0
    c10c:      	mov	w9, wzr
    c110:      	add	x8, x0, #0x8
    c114:      	add	x23, x0, #0x18
    c118:      	mov	w26, #0x7               // =7
    c11c:      	nop
    c120:      	adr	x27, 0x55d0
    c124:      	str	x8, [sp, #0x10]
    c128:      	b	0xc13c <_ZN10CQuantizer13ProcessImage2EPhii+0x84>
    c12c:      	ldp	w8, w9, [sp, #0x8]
    c130:      	add	w9, w9, #0x1
    c134:      	cmp	w9, w8
    c138:      	b.eq	0xc298 <_ZN10CQuantizer13ProcessImage2EPhii+0x1e0>
    c13c:      	str	w9, [sp, #0xc]
    c140:      	mov	w9, wzr
    c144:      	b	0xc164 <_ZN10CQuantizer13ProcessImage2EPhii+0xac>
    c148:      	ldur	w9, [x29, #-0x14]
    c14c:      	ldr	w8, [sp, #0x18]
    c150:      	ldur	x10, [x29, #-0x10]
    c154:      	add	w9, w9, #0x1
    c158:      	add	x10, x10, #0x4
    c15c:      	cmp	w9, w8
    c160:      	b.eq	0xc12c <_ZN10CQuantizer13ProcessImage2EPhii+0x74>
    c164:      	ldrb	w19, [x10]
    c168:      	ldrb	w21, [x10, #0x1]
    c16c:      	mov	w25, wzr
    c170:      	ldrb	w24, [x10, #0x2]
    c174:      	ldr	w8, [x22, #0x68]
    c178:      	ldr	x28, [sp, #0x10]
    c17c:      	stur	w9, [x29, #-0x14]
    c180:      	stur	x10, [x29, #-0x10]
    c184:      	stur	w8, [x29, #-0x4]
    c188:      	ldr	x0, [x28]
    c18c:      	cbz	x0, 0xc19c <_ZN10CQuantizer13ProcessImage2EPhii+0xe4>
    c190:      	ldrb	w8, [x0]
    c194:      	cbz	w8, 0xc204 <_ZN10CQuantizer13ProcessImage2EPhii+0x14c>
    c198:      	b	0xc248 <_ZN10CQuantizer13ProcessImage2EPhii+0x190>
    c19c:      	mov	w0, #0x1                // =1
    c1a0:      	mov	w1, #0x60               // =96
    c1a4:      	bl	0x13240 <calloc@plt>
    c1a8:      	cbz	x0, 0xc1d8 <_ZN10CQuantizer13ProcessImage2EPhii+0x120>
    c1ac:      	ldur	w8, [x29, #-0x4]
    c1b0:      	cmp	w25, w8
    c1b4:      	cset	w8, eq
    c1b8:      	strb	w8, [x0]
    c1bc:      	b.ne	0xc1e8 <_ZN10CQuantizer13ProcessImage2EPhii+0x130>
    c1c0:      	add	w20, w20, #0x1
    c1c4:      	mov	w8, #0x1                // =1
    c1c8:      	stur	w20, [x22, #0x10]
    c1cc:      	str	x0, [x28]
    c1d0:      	cbz	w8, 0xc204 <_ZN10CQuantizer13ProcessImage2EPhii+0x14c>
    c1d4:      	b	0xc248 <_ZN10CQuantizer13ProcessImage2EPhii+0x190>
    c1d8:      	mov	w8, wzr
    c1dc:      	str	x0, [x28]
    c1e0:      	cbz	wzr, 0xc204 <_ZN10CQuantizer13ProcessImage2EPhii+0x14c>
    c1e4:      	b	0xc248 <_ZN10CQuantizer13ProcessImage2EPhii+0x190>
    c1e8:      	ubfiz	x9, x25, #3, #32
    c1ec:      	mov	w8, wzr
    c1f0:      	ldr	x10, [x23, x9]
    c1f4:      	str	x0, [x23, x9]
    c1f8:      	str	x10, [x0, #0x58]
    c1fc:      	str	x0, [x28]
    c200:      	cbnz	wzr, 0xc248 <_ZN10CQuantizer13ProcessImage2EPhii+0x190>
    c204:      	ldrb	w8, [x27, w25, uxtw]
    c208:      	sub	w9, w26, w25
    c20c:      	add	w25, w25, #0x1
    c210:      	and	w10, w8, w21
    c214:      	and	w11, w8, w24
    c218:      	and	w8, w8, w19
    c21c:      	lsr	x10, x10, x9
    c220:      	lsr	x11, x11, x9
    c224:      	lsr	x8, x8, x9
    c228:      	lsl	x10, x10, #4
    c22c:      	orr	x9, x10, x11, lsl #3
    c230:      	orr	x8, x9, x8, lsl #5
    c234:      	add	x8, x0, x8
    c238:      	add	x28, x8, #0x18
    c23c:      	ldr	x0, [x28]
    c240:      	cbnz	x0, 0xc190 <_ZN10CQuantizer13ProcessImage2EPhii+0xd8>
    c244:      	b	0xc19c <_ZN10CQuantizer13ProcessImage2EPhii+0xe4>
    c248:      	movi	v0.4s, #0x1
    c24c:      	ldur	q1, [x0, #0x4]
    c250:      	mov	v0.s[1], w19
    c254:      	mov	v0.s[2], w21
    c258:      	mov	v0.s[3], w24
    c25c:      	add	v0.4s, v1.4s, v0.4s
    c260:      	stur	q0, [x0, #0x4]
    c264:      	ldr	w20, [x22, #0x10]
    c268:      	ldr	w8, [x22, #0x60]
    c26c:      	cmp	w20, w8
    c270:      	b.ls	0xc148 <_ZN10CQuantizer13ProcessImage2EPhii+0x90>
    c274:      	ldr	w1, [x22, #0x68]
    c278:      	add	x2, x22, #0x10
    c27c:      	mov	x3, x23
    c280:      	bl	0x13250 <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE@plt>
    c284:      	ldr	w20, [x22, #0x10]
    c288:      	ldr	w8, [x22, #0x60]
    c28c:      	cmp	w20, w8
    c290:      	b.hi	0xc274 <_ZN10CQuantizer13ProcessImage2EPhii+0x1bc>
    c294:      	b	0xc148 <_ZN10CQuantizer13ProcessImage2EPhii+0x90>
    c298:      	ldr	x8, [sp]
    c29c:      	cmp	x8, #0x0
    c2a0:      	cset	w0, ne
    c2a4:      	ldp	x20, x19, [sp, #0x80]
    c2a8:      	ldp	x22, x21, [sp, #0x70]
    c2ac:      	ldp	x24, x23, [sp, #0x60]
    c2b0:      	ldp	x26, x25, [sp, #0x50]
    c2b4:      	ldp	x28, x27, [sp, #0x40]
    c2b8:      	ldp	x29, x30, [sp, #0x30]
    c2bc:      	add	sp, sp, #0x90
    c2c0:      	ret

000000000000c2c4 <_ZN10CQuantizer8AddColorEPP5_NODEhhhjjPjS2_>:
    c2c4:      	stp	x29, x30, [sp, #-0x60]!
    c2c8:      	stp	x28, x27, [sp, #0x10]
    c2cc:      	stp	x26, x25, [sp, #0x20]
    c2d0:      	stp	x24, x23, [sp, #0x30]
    c2d4:      	stp	x22, x21, [sp, #0x40]
    c2d8:      	stp	x20, x19, [sp, #0x50]
    c2dc:      	mov	x29, sp
    c2e0:      	ldr	x26, [x29, #0x60]
    c2e4:      	mov	x22, x7
    c2e8:      	mov	w23, w6
    c2ec:      	mov	w24, w5
    c2f0:      	mov	w19, w4
    c2f4:      	mov	w20, w3
    c2f8:      	mov	w21, w2
    c2fc:      	mov	x25, x1
    c300:      	mov	w27, #0x7               // =7
    c304:      	nop
    c308:      	adr	x28, 0x55d0
    c30c:      	ldr	x0, [x1]
    c310:      	cbz	x0, 0xc320 <_ZN10CQuantizer8AddColorEPP5_NODEhhhjjPjS2_+0x5c>
    c314:      	ldrb	w8, [x0]
    c318:      	cbz	w8, 0xc388 <_ZN10CQuantizer8AddColorEPP5_NODEhhhjjPjS2_+0xc4>
    c31c:      	b	0xc3d8 <_ZN10CQuantizer8AddColorEPP5_NODEhhhjjPjS2_+0x114>
    c320:      	mov	w0, #0x1                // =1
    c324:      	mov	w1, #0x60               // =96
    c328:      	bl	0x13240 <calloc@plt>
    c32c:      	cbz	x0, 0xc35c <_ZN10CQuantizer8AddColorEPP5_NODEhhhjjPjS2_+0x98>
    c330:      	cmp	w23, w24
    c334:      	cset	w8, eq
    c338:      	strb	w8, [x0]
    c33c:      	b.ne	0xc36c <_ZN10CQuantizer8AddColorEPP5_NODEhhhjjPjS2_+0xa8>
    c340:      	ldr	w8, [x22]
    c344:      	add	w8, w8, #0x1
    c348:      	str	w8, [x22]
    c34c:      	mov	w8, #0x1                // =1
    c350:      	str	x0, [x25]
    c354:      	cbz	w8, 0xc388 <_ZN10CQuantizer8AddColorEPP5_NODEhhhjjPjS2_+0xc4>
    c358:      	b	0xc3d8 <_ZN10CQuantizer8AddColorEPP5_NODEhhhjjPjS2_+0x114>
    c35c:      	mov	w8, wzr
    c360:      	str	x0, [x25]
    c364:      	cbz	wzr, 0xc388 <_ZN10CQuantizer8AddColorEPP5_NODEhhhjjPjS2_+0xc4>
    c368:      	b	0xc3d8 <_ZN10CQuantizer8AddColorEPP5_NODEhhhjjPjS2_+0x114>
    c36c:      	ubfiz	x9, x23, #3, #32
    c370:      	mov	w8, wzr
    c374:      	ldr	x10, [x26, x9]
    c378:      	str	x0, [x26, x9]
    c37c:      	str	x10, [x0, #0x58]
    c380:      	str	x0, [x25]
    c384:      	cbnz	wzr, 0xc3d8 <_ZN10CQuantizer8AddColorEPP5_NODEhhhjjPjS2_+0x114>
    c388:      	ldrb	w8, [x28, w23, uxtw]
    c38c:      	sub	w10, w27, w23
    c390:      	add	w23, w23, #0x1
    c394:      	and	w9, w8, w20
    c398:      	and	w11, w8, w19
    c39c:      	and	w8, w8, w21
    c3a0:      	and	x9, x9, #0xff
    c3a4:      	and	x11, x11, #0xff
    c3a8:      	and	x8, x8, #0xff
    c3ac:      	lsr	x9, x9, x10
    c3b0:      	lsr	x11, x11, x10
    c3b4:      	lsr	x8, x8, x10
    c3b8:      	lsl	x9, x9, #4
    c3bc:      	orr	x9, x9, x11, lsl #3
    c3c0:      	orr	x8, x9, x8, lsl #5
    c3c4:      	add	x8, x0, x8
    c3c8:      	add	x25, x8, #0x18
    c3cc:      	ldr	x0, [x25]
    c3d0:      	cbnz	x0, 0xc314 <_ZN10CQuantizer8AddColorEPP5_NODEhhhjjPjS2_+0x50>
    c3d4:      	b	0xc320 <_ZN10CQuantizer8AddColorEPP5_NODEhhhjjPjS2_+0x5c>
    c3d8:      	movi	v0.4s, #0x1
    c3dc:      	and	w8, w21, #0xff
    c3e0:      	ldur	q1, [x0, #0x4]
    c3e4:      	mov	v0.s[1], w8
    c3e8:      	and	w8, w20, #0xff
    c3ec:      	mov	v0.s[2], w8
    c3f0:      	and	w8, w19, #0xff
    c3f4:      	mov	v0.s[3], w8
    c3f8:      	add	v0.4s, v1.4s, v0.4s
    c3fc:      	stur	q0, [x0, #0x4]
    c400:      	ldp	x20, x19, [sp, #0x50]
    c404:      	ldp	x22, x21, [sp, #0x40]
    c408:      	ldp	x24, x23, [sp, #0x30]
    c40c:      	ldp	x26, x25, [sp, #0x20]
    c410:      	ldp	x28, x27, [sp, #0x10]
    c414:      	ldp	x29, x30, [sp], #0x60
    c418:      	ret

000000000000c41c <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE>:
    c41c:      	sub	sp, sp, #0x40
    c420:      	stp	x29, x30, [sp, #0x10]
    c424:      	stp	x22, x21, [sp, #0x20]
    c428:      	stp	x20, x19, [sp, #0x30]
    c42c:      	add	x29, sp, #0x10
    c430:      	sub	w8, w1, #0x1
    c434:      	mov	x19, x2
    c438:      	mov	w9, w1
    c43c:      	and	w8, w8, w8, asr #31
    c440:      	sub	x9, x9, #0x1
    c444:      	cmp	w9, #0x1
    c448:      	b.lt	0xc458 <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE+0x3c>
    c44c:      	ldr	x10, [x3, w9, uxtw #3]
    c450:      	cbz	x10, 0xc440 <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE+0x24>
    c454:      	mov	w8, w9
    c458:      	sbfiz	x8, x8, #3, #32
    c45c:      	ldr	x20, [x3, x8]
    c460:      	ldr	x9, [x20, #0x58]
    c464:      	str	x9, [x3, x8]
    c468:      	ldr	x0, [x20, #0x18]
    c46c:      	cbz	x0, 0xc644 <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE+0x228>
    c470:      	ldr	w8, [x0, #0x4]
    c474:      	ldr	w9, [x20, #0x4]
    c478:      	ldr	d0, [x0, #0x8]
    c47c:      	ldr	w21, [x0, #0x10]
    c480:      	add	w8, w9, w8
    c484:      	str	q0, [sp]
    c488:      	str	w8, [x20, #0x4]
    c48c:      	bl	0x12f40 <free@plt>
    c490:      	mov	w22, #0x1               // =1
    c494:      	str	xzr, [x20, #0x18]
    c498:      	ldr	x0, [x20, #0x20]
    c49c:      	cbz	x0, 0xc4d4 <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE+0xb8>
    c4a0:      	ldr	d0, [x0, #0x8]
    c4a4:      	ldr	q1, [sp]
    c4a8:      	ldr	w8, [x0, #0x4]
    c4ac:      	ldr	w9, [x20, #0x4]
    c4b0:      	ldr	w10, [x0, #0x10]
    c4b4:      	add	v1.2s, v0.2s, v1.2s
    c4b8:      	add	w8, w9, w8
    c4bc:      	add	w21, w10, w21
    c4c0:      	str	w8, [x20, #0x4]
    c4c4:      	str	q1, [sp]
    c4c8:      	bl	0x12f40 <free@plt>
    c4cc:      	add	w22, w22, #0x1
    c4d0:      	str	xzr, [x20, #0x20]
    c4d4:      	ldr	x0, [x20, #0x28]
    c4d8:      	cbz	x0, 0xc510 <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE+0xf4>
    c4dc:      	ldr	d0, [x0, #0x8]
    c4e0:      	ldr	q1, [sp]
    c4e4:      	ldr	w8, [x0, #0x4]
    c4e8:      	ldr	w9, [x20, #0x4]
    c4ec:      	ldr	w10, [x0, #0x10]
    c4f0:      	add	v1.2s, v0.2s, v1.2s
    c4f4:      	add	w8, w9, w8
    c4f8:      	add	w21, w10, w21
    c4fc:      	str	w8, [x20, #0x4]
    c500:      	str	q1, [sp]
    c504:      	bl	0x12f40 <free@plt>
    c508:      	add	w22, w22, #0x1
    c50c:      	str	xzr, [x20, #0x28]
    c510:      	ldr	x0, [x20, #0x30]
    c514:      	cbz	x0, 0xc54c <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE+0x130>
    c518:      	ldr	d0, [x0, #0x8]
    c51c:      	ldr	q1, [sp]
    c520:      	ldr	w8, [x0, #0x4]
    c524:      	ldr	w9, [x20, #0x4]
    c528:      	ldr	w10, [x0, #0x10]
    c52c:      	add	v1.2s, v0.2s, v1.2s
    c530:      	add	w8, w9, w8
    c534:      	add	w21, w10, w21
    c538:      	str	w8, [x20, #0x4]
    c53c:      	str	q1, [sp]
    c540:      	bl	0x12f40 <free@plt>
    c544:      	add	w22, w22, #0x1
    c548:      	str	xzr, [x20, #0x30]
    c54c:      	ldr	x0, [x20, #0x38]
    c550:      	cbz	x0, 0xc588 <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE+0x16c>
    c554:      	ldr	d0, [x0, #0x8]
    c558:      	ldr	q1, [sp]
    c55c:      	ldr	w8, [x0, #0x4]
    c560:      	ldr	w9, [x20, #0x4]
    c564:      	ldr	w10, [x0, #0x10]
    c568:      	add	v1.2s, v0.2s, v1.2s
    c56c:      	add	w8, w9, w8
    c570:      	add	w21, w10, w21
    c574:      	str	w8, [x20, #0x4]
    c578:      	str	q1, [sp]
    c57c:      	bl	0x12f40 <free@plt>
    c580:      	add	w22, w22, #0x1
    c584:      	str	xzr, [x20, #0x38]
    c588:      	ldr	x0, [x20, #0x40]
    c58c:      	cbz	x0, 0xc5c4 <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE+0x1a8>
    c590:      	ldr	d0, [x0, #0x8]
    c594:      	ldr	q1, [sp]
    c598:      	ldr	w8, [x0, #0x4]
    c59c:      	ldr	w9, [x20, #0x4]
    c5a0:      	ldr	w10, [x0, #0x10]
    c5a4:      	add	v1.2s, v0.2s, v1.2s
    c5a8:      	add	w8, w9, w8
    c5ac:      	add	w21, w10, w21
    c5b0:      	str	w8, [x20, #0x4]
    c5b4:      	str	q1, [sp]
    c5b8:      	bl	0x12f40 <free@plt>
    c5bc:      	add	w22, w22, #0x1
    c5c0:      	str	xzr, [x20, #0x40]
    c5c4:      	ldr	x0, [x20, #0x48]
    c5c8:      	cbz	x0, 0xc600 <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE+0x1e4>
    c5cc:      	ldr	d0, [x0, #0x8]
    c5d0:      	ldr	q1, [sp]
    c5d4:      	ldr	w8, [x0, #0x4]
    c5d8:      	ldr	w9, [x20, #0x4]
    c5dc:      	ldr	w10, [x0, #0x10]
    c5e0:      	add	v1.2s, v0.2s, v1.2s
    c5e4:      	add	w8, w9, w8
    c5e8:      	add	w21, w10, w21
    c5ec:      	str	w8, [x20, #0x4]
    c5f0:      	str	q1, [sp]
    c5f4:      	bl	0x12f40 <free@plt>
    c5f8:      	add	w22, w22, #0x1
    c5fc:      	str	xzr, [x20, #0x48]
    c600:      	ldr	x0, [x20, #0x50]
    c604:      	cbz	x0, 0xc660 <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE+0x244>
    c608:      	ldr	d0, [x0, #0x8]
    c60c:      	ldr	q1, [sp]
    c610:      	ldr	w8, [x0, #0x4]
    c614:      	ldr	w9, [x20, #0x4]
    c618:      	ldr	w10, [x0, #0x10]
    c61c:      	add	v1.2s, v0.2s, v1.2s
    c620:      	add	w8, w9, w8
    c624:      	add	w21, w10, w21
    c628:      	str	w8, [x20, #0x4]
    c62c:      	str	q1, [sp]
    c630:      	bl	0x12f40 <free@plt>
    c634:      	ldr	q0, [sp]
    c638:      	add	w22, w22, #0x1
    c63c:      	str	xzr, [x20, #0x50]
    c640:      	b	0xc664 <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE+0x248>
    c644:      	movi	v0.2d, #0000000000000000
    c648:      	mov	w21, wzr
    c64c:      	mov	w22, wzr
    c650:      	str	q0, [sp]
    c654:      	ldr	x0, [x20, #0x20]
    c658:      	cbnz	x0, 0xc4a0 <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE+0x84>
    c65c:      	b	0xc4d4 <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE+0xb8>
    c660:      	ldr	q0, [sp]
    c664:      	str	d0, [x20, #0x8]
    c668:      	mov	w9, #0x1                // =1
    c66c:      	str	w21, [x20, #0x10]
    c670:      	ldr	w8, [x19]
    c674:      	strb	w9, [x20]
    c678:      	sub	w8, w8, w22
    c67c:      	add	w8, w8, #0x1
    c680:      	str	w8, [x19]
    c684:      	ldp	x20, x19, [sp, #0x30]
    c688:      	ldp	x22, x21, [sp, #0x20]
    c68c:      	ldp	x29, x30, [sp, #0x10]
    c690:      	add	sp, sp, #0x40
    c694:      	ret

000000000000c698 <_ZN10CQuantizer10CreateNodeEjjPjPP5_NODE>:
    c698:      	stp	x29, x30, [sp, #-0x30]!
    c69c:      	stp	x22, x21, [sp, #0x10]
    c6a0:      	stp	x20, x19, [sp, #0x20]
    c6a4:      	mov	x29, sp
    c6a8:      	mov	w21, w1
    c6ac:      	mov	w0, #0x1                // =1
    c6b0:      	mov	w1, #0x60               // =96
    c6b4:      	mov	x19, x4
    c6b8:      	mov	x20, x3
    c6bc:      	mov	w22, w2
    c6c0:      	bl	0x13240 <calloc@plt>
    c6c4:      	cbz	x0, 0xc6e4 <_ZN10CQuantizer10CreateNodeEjjPjPP5_NODE+0x4c>
    c6c8:      	cmp	w21, w22
    c6cc:      	cset	w8, eq
    c6d0:      	strb	w8, [x0]
    c6d4:      	b.ne	0xc6f4 <_ZN10CQuantizer10CreateNodeEjjPjPP5_NODE+0x5c>
    c6d8:      	ldr	w8, [x20]
    c6dc:      	add	w8, w8, #0x1
    c6e0:      	str	w8, [x20]
    c6e4:      	ldp	x20, x19, [sp, #0x20]
    c6e8:      	ldp	x22, x21, [sp, #0x10]
    c6ec:      	ldp	x29, x30, [sp], #0x30
    c6f0:      	ret
    c6f4:      	ubfiz	x8, x21, #3, #32
    c6f8:      	ldr	x9, [x19, x8]
    c6fc:      	str	x0, [x19, x8]
    c700:      	str	x9, [x0, #0x58]
    c704:      	ldp	x20, x19, [sp, #0x20]
    c708:      	ldp	x22, x21, [sp, #0x10]
    c70c:      	ldp	x29, x30, [sp], #0x30
    c710:      	ret

000000000000c714 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj>:
    c714:      	stp	x29, x30, [sp, #-0x30]!
    c718:      	stp	x22, x21, [sp, #0x10]
    c71c:      	stp	x20, x19, [sp, #0x20]
    c720:      	mov	x29, sp
    c724:      	mov	x19, x3
    c728:      	mov	x20, x2
    c72c:      	mov	x21, x1
    c730:      	mov	x22, x0
    c734:      	b	0xc740 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj+0x2c>
    c738:      	ldr	x21, [x21, #0x50]
    c73c:      	cbz	x21, 0xc88c <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj+0x178>
    c740:      	cbz	x21, 0xc88c <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj+0x178>
    c744:      	ldrb	w8, [x21]
    c748:      	cbnz	w8, 0xc7f8 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj+0xe4>
    c74c:      	ldr	x1, [x21, #0x18]
    c750:      	cbz	x1, 0xc764 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj+0x50>
    c754:      	mov	x0, x22
    c758:      	mov	x2, x20
    c75c:      	mov	x3, x19
    c760:      	bl	0x13260 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj@plt>
    c764:      	ldr	x1, [x21, #0x20]
    c768:      	cbz	x1, 0xc77c <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj+0x68>
    c76c:      	mov	x0, x22
    c770:      	mov	x2, x20
    c774:      	mov	x3, x19
    c778:      	bl	0x13260 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj@plt>
    c77c:      	ldr	x1, [x21, #0x28]
    c780:      	cbz	x1, 0xc794 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj+0x80>
    c784:      	mov	x0, x22
    c788:      	mov	x2, x20
    c78c:      	mov	x3, x19
    c790:      	bl	0x13260 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj@plt>
    c794:      	ldr	x1, [x21, #0x30]
    c798:      	cbz	x1, 0xc7ac <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj+0x98>
    c79c:      	mov	x0, x22
    c7a0:      	mov	x2, x20
    c7a4:      	mov	x3, x19
    c7a8:      	bl	0x13260 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj@plt>
    c7ac:      	ldr	x1, [x21, #0x38]
    c7b0:      	cbz	x1, 0xc7c4 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj+0xb0>
    c7b4:      	mov	x0, x22
    c7b8:      	mov	x2, x20
    c7bc:      	mov	x3, x19
    c7c0:      	bl	0x13260 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj@plt>
    c7c4:      	ldr	x1, [x21, #0x40]
    c7c8:      	cbz	x1, 0xc7dc <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj+0xc8>
    c7cc:      	mov	x0, x22
    c7d0:      	mov	x2, x20
    c7d4:      	mov	x3, x19
    c7d8:      	bl	0x13260 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj@plt>
    c7dc:      	ldr	x1, [x21, #0x48]
    c7e0:      	cbz	x1, 0xc738 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj+0x24>
    c7e4:      	mov	x0, x22
    c7e8:      	mov	x2, x20
    c7ec:      	mov	x3, x19
    c7f0:      	bl	0x13260 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj@plt>
    c7f4:      	b	0xc738 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj+0x24>
    c7f8:      	ldp	s1, s0, [x21, #0x4]
    c7fc:      	mov	w8, #0x437f0000         // =1132396544
    c800:      	fmov	s2, w8
    c804:      	ldr	w9, [x19]
    c808:      	ucvtf	s0, s0
    c80c:      	ucvtf	s1, s1
    c810:      	fdiv	s0, s0, s1
    c814:      	fmov	s1, #0.50000000
    c818:      	fadd	s0, s0, s1
    c81c:      	fminnm	s0, s0, s2
    c820:      	fcvtzs	w8, s0
    c824:      	strb	w8, [x20, x9]
    c828:      	ldr	s0, [x21, #0xc]
    c82c:      	ldr	s3, [x21, #0x4]
    c830:      	ldr	w9, [x19]
    c834:      	ucvtf	s0, s0
    c838:      	ucvtf	s3, s3
    c83c:      	add	w9, w9, #0x1
    c840:      	fdiv	s0, s0, s3
    c844:      	fadd	s0, s0, s1
    c848:      	fminnm	s0, s0, s2
    c84c:      	fcvtzs	w8, s0
    c850:      	strb	w8, [x20, w9, uxtw]
    c854:      	ldr	s0, [x21, #0x10]
    c858:      	ldr	s3, [x21, #0x4]
    c85c:      	ldr	w9, [x19]
    c860:      	ucvtf	s0, s0
    c864:      	ucvtf	s3, s3
    c868:      	add	w9, w9, #0x2
    c86c:      	fdiv	s0, s0, s3
    c870:      	fadd	s0, s0, s1
    c874:      	fminnm	s0, s0, s2
    c878:      	fcvtzs	w8, s0
    c87c:      	strb	w8, [x20, w9, uxtw]
    c880:      	ldr	w8, [x19]
    c884:      	add	w8, w8, #0x3
    c888:      	str	w8, [x19]
    c88c:      	ldp	x20, x19, [sp, #0x20]
    c890:      	ldp	x22, x21, [sp, #0x10]
    c894:      	ldp	x29, x30, [sp], #0x30
    c898:      	ret

000000000000c89c <_ZN10CQuantizer13SetColorTableEPh>:
    c89c:      	sub	sp, sp, #0x30
    c8a0:      	stp	x29, x30, [sp, #0x10]
    c8a4:      	str	x19, [sp, #0x20]
    c8a8:      	add	x29, sp, #0x10
    c8ac:      	mrs	x19, TPIDR_EL0
    c8b0:      	ldr	x8, [x19, #0x28]
    c8b4:      	str	x8, [sp, #0x8]
    c8b8:      	ldr	w8, [x0, #0x64]
    c8bc:      	str	wzr, [sp, #0x4]
    c8c0:      	cmp	w8, #0x10
    c8c4:      	b.lo	0xc8d8 <_ZN10CQuantizer13SetColorTableEPh+0x3c>
    c8c8:      	mov	x2, x1
    c8cc:      	ldr	x1, [x0, #0x8]
    c8d0:      	add	x3, sp, #0x4
    c8d4:      	bl	0x13260 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj@plt>
    c8d8:      	ldr	x8, [x19, #0x28]
    c8dc:      	ldr	x9, [sp, #0x8]
    c8e0:      	cmp	x8, x9
    c8e4:      	b.ne	0xc8f8 <_ZN10CQuantizer13SetColorTableEPh+0x5c>
    c8e8:      	ldp	x29, x30, [sp, #0x10]
    c8ec:      	ldr	x19, [sp, #0x20]
    c8f0:      	add	sp, sp, #0x30
    c8f4:      	ret
    c8f8:      	bl	0x12bc0 <__stack_chk_fail@plt>

000000000000c8fc <_ZN7CGif89aC2Ev>:
    c8fc:      	movi	v0.2d, #0000000000000000
    c900:      	strh	wzr, [x0, #0x1c]
    c904:      	str	xzr, [x0]
    c908:      	str	q0, [x0, #0x320]
    c90c:      	ret

000000000000c910 <_ZN7CGif89aC2EPcb>:
    c910:      	stp	x29, x30, [sp, #-0x30]!
    c914:      	stp	x22, x21, [sp, #0x10]
    c918:      	stp	x20, x19, [sp, #0x20]
    c91c:      	mov	x29, sp
    c920:      	movi	v0.2d, #0000000000000000
    c924:      	mov	x21, x0
    c928:      	mov	w19, w2
    c92c:      	mov	x20, x1
    c930:      	str	q0, [x0, #0x320]
    c934:      	mov	x0, x1
    c938:      	bl	0x12dc0 <strlen@plt>
    c93c:      	mov	x22, x0
    c940:      	add	x0, x0, #0x1
    c944:      	bl	0x130e0 <_Znam@plt>
    c948:      	mov	x1, x20
    c94c:      	str	x0, [x21]
    c950:      	bl	0x13270 <strcpy@plt>
    c954:      	strb	wzr, [x0, x22]
    c958:      	mov	x0, x21
    c95c:      	mov	x1, x20
    c960:      	mov	w2, w19
    c964:      	bl	0x13280 <_ZN7CGif89a4openEPcb@plt>
    c968:      	mov	w8, #0x1                // =1
    c96c:      	and	w9, w0, #0x1
    c970:      	bic	w8, w8, w0
    c974:      	strb	w9, [x21, #0x1d]
    c978:      	strb	w8, [x21, #0x1c]
    c97c:      	ldp	x20, x19, [sp, #0x20]
    c980:      	ldp	x22, x21, [sp, #0x10]
    c984:      	ldp	x29, x30, [sp], #0x30
    c988:      	ret

000000000000c98c <_ZN7CGif89a4openEPcb>:
    c98c:      	sub	sp, sp, #0x40
    c990:      	stp	x29, x30, [sp, #0x10]
    c994:      	str	x21, [sp, #0x20]
    c998:      	stp	x20, x19, [sp, #0x30]
    c99c:      	add	x29, sp, #0x10
    c9a0:      	mrs	x21, TPIDR_EL0
    c9a4:      	mov	x8, x1
    c9a8:      	mov	x19, x0
    c9ac:      	ldr	x9, [x21, #0x28]
    c9b0:      	str	x9, [sp, #0x8]
    c9b4:      	strb	w2, [x0, #0x1e]
    c9b8:      	str	xzr, [x0, #0x330]
    c9bc:      	str	wzr, [x0, #0x338]
    c9c0:      	strb	wzr, [x0, #0x398]
    c9c4:      	str	xzr, [x0, #0x380]
    c9c8:      	str	xzr, [x0, #0x378]
    c9cc:      	str	x1, [x0, #0x10]
    c9d0:      	nop
    c9d4:      	adr	x1, 0x5b12
    c9d8:      	mov	x0, x8
    c9dc:      	bl	0x13110 <fopen@plt>
    c9e0:      	str	x0, [x19, #0x8]
    c9e4:      	cbz	x0, 0xcbb0 <_ZN7CGif89a4openEPcb+0x224>
    c9e8:      	mov	x3, x0
    c9ec:      	add	x0, sp, #0x4
    c9f0:      	mov	w1, #0x1                // =1
    c9f4:      	mov	w2, #0x3                // =3
    c9f8:      	bl	0x13180 <fread@plt>
    c9fc:      	ldrh	w8, [sp, #0x4]
    ca00:      	ldrb	w9, [sp, #0x6]
    ca04:      	mov	w10, #0x4947            // =18759
    ca08:      	cmp	w8, w10
    ca0c:      	mov	w8, #0x46               // =70
    ca10:      	ccmp	w9, w8, #0x0, eq
    ca14:      	b.ne	0xcba4 <_ZN7CGif89a4openEPcb+0x218>
    ca18:      	ldr	x3, [x19, #0x8]
    ca1c:      	add	x0, x19, #0x18
    ca20:      	mov	w1, #0x1                // =1
    ca24:      	mov	w2, #0x3                // =3
    ca28:      	bl	0x13180 <fread@plt>
    ca2c:      	ldrb	w8, [x19, #0x1a]
    ca30:      	ldrh	w9, [x19, #0x18]
    ca34:      	strb	wzr, [x19, #0x1b]
    ca38:      	orr	w8, w9, w8, lsl #16
    ca3c:      	mov	w9, #0x6101             // =24833
    ca40:      	movk	w9, #0x3839, lsl #16
    ca44:      	rev	w8, w8
    ca48:      	cmp	w8, w9
    ca4c:      	b.hs	0xcba4 <_ZN7CGif89a4openEPcb+0x218>
    ca50:      	ldr	x3, [x19, #0x8]
    ca54:      	add	x0, x19, #0x344
    ca58:      	mov	w1, #0x1                // =1
    ca5c:      	mov	w2, #0x2                // =2
    ca60:      	mov	w20, #0x1               // =1
    ca64:      	bl	0x13180 <fread@plt>
    ca68:      	ldr	x3, [x19, #0x8]
    ca6c:      	add	x0, x19, #0x346
    ca70:      	mov	w1, #0x1                // =1
    ca74:      	mov	w2, #0x2                // =2
    ca78:      	bl	0x13180 <fread@plt>
    ca7c:      	ldr	x3, [x19, #0x8]
    ca80:      	mov	x0, sp
    ca84:      	mov	w1, #0x1                // =1
    ca88:      	mov	w2, #0x1                // =1
    ca8c:      	bl	0x13180 <fread@plt>
    ca90:      	ldrb	w8, [sp]
    ca94:      	tbnz	w8, #0x7, 0xcaac <_ZN7CGif89a4openEPcb+0x120>
    ca98:      	lsr	w8, w8, #4
    ca9c:      	strb	wzr, [x19, #0x348]
    caa0:      	add	w8, w8, #0x1
    caa4:      	str	w8, [x19, #0x34c]
    caa8:      	b	0xcad4 <_ZN7CGif89a4openEPcb+0x148>
    caac:      	and	w10, w8, #0x7
    cab0:      	ubfx	w9, w8, #4, #3
    cab4:      	ubfx	w8, w8, #3, #1
    cab8:      	add	w10, w10, #0x1
    cabc:      	strb	w20, [x19, #0x348]
    cac0:      	lsl	w10, w20, w10
    cac4:      	add	w9, w9, #0x1
    cac8:      	strb	w8, [x19, #0x350]
    cacc:      	str	w9, [x19, #0x34c]
    cad0:      	str	w10, [x19, #0x354]
    cad4:      	ldr	x3, [x19, #0x8]
    cad8:      	mov	x0, sp
    cadc:      	mov	w1, #0x1                // =1
    cae0:      	mov	w2, #0x1                // =1
    cae4:      	bl	0x13180 <fread@plt>
    cae8:      	ldrb	w8, [sp]
    caec:      	ldr	x3, [x19, #0x8]
    caf0:      	mov	x0, sp
    caf4:      	mov	w1, #0x1                // =1
    caf8:      	mov	w2, #0x1                // =1
    cafc:      	str	w8, [x19, #0x358]
    cb00:      	bl	0x13180 <fread@plt>
    cb04:      	ldrb	w8, [sp]
    cb08:      	ldrb	w9, [x19, #0x348]
    cb0c:      	str	w8, [x19, #0x35c]
    cb10:      	cbz	w9, 0xcb34 <_ZN7CGif89a4openEPcb+0x1a8>
    cb14:      	ldr	w8, [x19, #0x354]
    cb18:      	ldr	x3, [x19, #0x8]
    cb1c:      	add	x20, x19, #0x1f
    cb20:      	mov	x0, x20
    cb24:      	mov	w1, #0x1                // =1
    cb28:      	add	w2, w8, w8, lsl #1
    cb2c:      	bl	0x13180 <fread@plt>
    cb30:      	b	0xcb38 <_ZN7CGif89a4openEPcb+0x1ac>
    cb34:      	mov	x20, xzr
    cb38:      	ldr	x0, [x19, #0x8]
    cb3c:      	str	x20, [x19, #0x360]
    cb40:      	bl	0x131b0 <ftell@plt>
    cb44:      	str	x0, [x19, #0x328]
    cb48:      	mov	x0, x19
    cb4c:      	str	xzr, [x19, #0x320]
    cb50:      	bl	0x13290 <_ZN7CGif89a11checkFramesEv@plt>
    cb54:      	str	w0, [x19, #0x340]
    cb58:      	cbz	w0, 0xcba4 <_ZN7CGif89a4openEPcb+0x218>
    cb5c:      	ldrb	w8, [x19, #0x1e]
    cb60:      	cbz	w8, 0xcb98 <_ZN7CGif89a4openEPcb+0x20c>
    cb64:      	mov	w8, #0x30               // =48
    cb68:      	umull	x20, w0, w8
    cb6c:      	mov	x0, x20
    cb70:      	bl	0x130e0 <_Znam@plt>
    cb74:      	mov	w1, wzr
    cb78:      	mov	x2, x20
    cb7c:      	str	x0, [x19, #0x330]
    cb80:      	bl	0x130b0 <memset@plt>
    cb84:      	mov	x0, x19
    cb88:      	bl	0x132a0 <_ZN7CGif89a12getAllFramesEv@plt>
    cb8c:      	tbz	w0, #0x0, 0xcbd4 <_ZN7CGif89a4openEPcb+0x248>
    cb90:      	ldr	x0, [x19, #0x8]
    cb94:      	bl	0x13080 <fclose@plt>
    cb98:      	mov	w0, #0x1                // =1
    cb9c:      	strb	w0, [x19, #0x1d]
    cba0:      	b	0xcbb0 <_ZN7CGif89a4openEPcb+0x224>
    cba4:      	ldr	x0, [x19, #0x8]
    cba8:      	bl	0x13080 <fclose@plt>
    cbac:      	mov	w0, wzr
    cbb0:      	ldr	x8, [x21, #0x28]
    cbb4:      	ldr	x9, [sp, #0x8]
    cbb8:      	cmp	x8, x9
    cbbc:      	b.ne	0xcbec <_ZN7CGif89a4openEPcb+0x260>
    cbc0:      	ldp	x20, x19, [sp, #0x30]
    cbc4:      	ldr	x21, [sp, #0x20]
    cbc8:      	ldp	x29, x30, [sp, #0x10]
    cbcc:      	add	sp, sp, #0x40
    cbd0:      	ret
    cbd4:      	ldr	x0, [x19, #0x330]
    cbd8:      	cbz	x0, 0xcbe0 <_ZN7CGif89a4openEPcb+0x254>
    cbdc:      	bl	0x130f0 <_ZdaPv@plt>
    cbe0:      	ldr	x0, [x19, #0x8]
    cbe4:      	str	xzr, [x19, #0x330]
    cbe8:      	b	0xcba8 <_ZN7CGif89a4openEPcb+0x21c>
    cbec:      	bl	0x12bc0 <__stack_chk_fail@plt>

000000000000cbf0 <_ZN7CGif89aD2Ev>:
    cbf0:      	stp	x29, x30, [sp, #-0x20]!
    cbf4:      	str	x19, [sp, #0x10]
    cbf8:      	mov	x29, sp
    cbfc:      	mov	x19, x0
    cc00:      	bl	0x132b0 <_ZN7CGif89a5closeEv@plt>
    cc04:      	ldr	x0, [x19]
    cc08:      	cbz	x0, 0xcc14 <_ZN7CGif89aD2Ev+0x24>
    cc0c:      	bl	0x12c80 <_ZdlPv@plt>
    cc10:      	str	xzr, [x19]
    cc14:      	ldr	x19, [sp, #0x10]
    cc18:      	ldp	x29, x30, [sp], #0x20
    cc1c:      	ret

000000000000cc20 <_ZN7CGif89a5closeEv>:
    cc20:      	stp	x29, x30, [sp, #-0x30]!
    cc24:      	str	x21, [sp, #0x10]
    cc28:      	stp	x20, x19, [sp, #0x20]
    cc2c:      	mov	x29, sp
    cc30:      	ldrb	w8, [x0, #0x1d]
    cc34:      	cbz	w8, 0xccb0 <_ZN7CGif89a5closeEv+0x90>
    cc38:      	ldrb	w8, [x0, #0x1e]
    cc3c:      	mov	x19, x0
    cc40:      	strb	wzr, [x0, #0x1d]
    cc44:      	cbz	w8, 0xccc0 <_ZN7CGif89a5closeEv+0xa0>
    cc48:      	ldr	x20, [x19, #0x330]
    cc4c:      	cbz	x20, 0xccb0 <_ZN7CGif89a5closeEv+0x90>
    cc50:      	ldr	w8, [x19, #0x340]
    cc54:      	cbz	w8, 0xcc9c <_ZN7CGif89a5closeEv+0x7c>
    cc58:      	mov	w21, wzr
    cc5c:      	b	0xcc70 <_ZN7CGif89a5closeEv+0x50>
    cc60:      	ldr	w8, [x19, #0x340]
    cc64:      	add	w21, w21, #0x1
    cc68:      	cmp	w21, w8
    cc6c:      	b.hs	0xcc94 <_ZN7CGif89a5closeEv+0x74>
    cc70:      	ldr	x0, [x20, #0x10]
    cc74:      	cbz	x0, 0xcc80 <_ZN7CGif89a5closeEv+0x60>
    cc78:      	bl	0x130f0 <_ZdaPv@plt>
    cc7c:      	str	xzr, [x20, #0x10]
    cc80:      	ldr	x0, [x20, #0x18]
    cc84:      	cbz	x0, 0xcc60 <_ZN7CGif89a5closeEv+0x40>
    cc88:      	bl	0x130f0 <_ZdaPv@plt>
    cc8c:      	str	xzr, [x20, #0x18]
    cc90:      	b	0xcc60 <_ZN7CGif89a5closeEv+0x40>
    cc94:      	ldr	x20, [x19, #0x330]
    cc98:      	cbz	x20, 0xcca4 <_ZN7CGif89a5closeEv+0x84>
    cc9c:      	mov	x0, x20
    cca0:      	bl	0x130f0 <_ZdaPv@plt>
    cca4:      	ldrb	w8, [x19, #0x1e]
    cca8:      	str	xzr, [x19, #0x330]
    ccac:      	cbz	w8, 0xccc0 <_ZN7CGif89a5closeEv+0xa0>
    ccb0:      	ldp	x20, x19, [sp, #0x20]
    ccb4:      	ldr	x21, [sp, #0x10]
    ccb8:      	ldp	x29, x30, [sp], #0x30
    ccbc:      	ret
    ccc0:      	ldr	x0, [x19, #0x378]
    ccc4:      	cbz	x0, 0xccd0 <_ZN7CGif89a5closeEv+0xb0>
    ccc8:      	bl	0x130f0 <_ZdaPv@plt>
    cccc:      	str	xzr, [x19, #0x378]
    ccd0:      	ldr	x0, [x19, #0x380]
    ccd4:      	cbz	x0, 0xcce0 <_ZN7CGif89a5closeEv+0xc0>
    ccd8:      	bl	0x130f0 <_ZdaPv@plt>
    ccdc:      	str	xzr, [x19, #0x380]
    cce0:      	ldr	x0, [x19, #0x8]
    cce4:      	ldp	x20, x19, [sp, #0x20]
    cce8:      	ldr	x21, [sp, #0x10]
    ccec:      	ldp	x29, x30, [sp], #0x30
    ccf0:      	b	0x13080 <fclose@plt>

000000000000ccf4 <_ZN7CGif89antEv>:
    ccf4:      	ldrb	w0, [x0, #0x1c]
    ccf8:      	ret

000000000000ccfc <_ZN7CGif89a11checkFramesEv>:
    ccfc:      	sub	sp, sp, #0x60
    cd00:      	stp	x29, x30, [sp, #0x10]
    cd04:      	stp	x26, x25, [sp, #0x20]
    cd08:      	stp	x24, x23, [sp, #0x30]
    cd0c:      	stp	x22, x21, [sp, #0x40]
    cd10:      	stp	x20, x19, [sp, #0x50]
    cd14:      	add	x29, sp, #0x10
    cd18:      	mrs	x21, TPIDR_EL0
    cd1c:      	mov	x19, x0
    cd20:      	ldr	x8, [x21, #0x28]
    cd24:      	str	x8, [sp, #0x8]
    cd28:      	ldr	x0, [x0, #0x8]
    cd2c:      	bl	0x131b0 <ftell@plt>
    cd30:      	ldr	x8, [x19, #0x8]
    cd34:      	mov	x20, x0
    cd38:      	mov	x0, x8
    cd3c:      	bl	0x131d0 <feof@plt>
    cd40:      	mov	w22, wzr
    cd44:      	cbz	w0, 0xcd88 <_ZN7CGif89a11checkFramesEv+0x8c>
    cd48:      	ldr	x0, [x19, #0x8]
    cd4c:      	mov	x1, x20
    cd50:      	mov	w2, wzr
    cd54:      	bl	0x131a0 <fseek@plt>
    cd58:      	mov	w0, w22
    cd5c:      	ldr	x8, [x21, #0x28]
    cd60:      	ldr	x9, [sp, #0x8]
    cd64:      	cmp	x8, x9
    cd68:      	b.ne	0xcf3c <_ZN7CGif89a11checkFramesEv+0x240>
    cd6c:      	ldp	x20, x19, [sp, #0x50]
    cd70:      	ldp	x22, x21, [sp, #0x40]
    cd74:      	ldp	x24, x23, [sp, #0x30]
    cd78:      	ldp	x26, x25, [sp, #0x20]
    cd7c:      	ldp	x29, x30, [sp, #0x10]
    cd80:      	add	sp, sp, #0x60
    cd84:      	ret
    cd88:      	mov	w23, #0x1               // =1
    cd8c:      	mov	w24, #0x61              // =97
    cd90:      	mov	w25, #0x3               // =3
    cd94:      	b	0xcdac <_ZN7CGif89a11checkFramesEv+0xb0>
    cd98:      	mov	w26, wzr
    cd9c:      	ldr	x0, [x19, #0x8]
    cda0:      	bl	0x131d0 <feof@plt>
    cda4:      	cbnz	w0, 0xcd48 <_ZN7CGif89a11checkFramesEv+0x4c>
    cda8:      	cbnz	w26, 0xcd48 <_ZN7CGif89a11checkFramesEv+0x4c>
    cdac:      	ldr	x3, [x19, #0x8]
    cdb0:      	add	x0, sp, #0x4
    cdb4:      	mov	w1, #0x1                // =1
    cdb8:      	mov	w2, #0x1                // =1
    cdbc:      	bl	0x13180 <fread@plt>
    cdc0:      	ldrb	w8, [sp, #0x4]
    cdc4:      	cmp	w8, #0x2b
    cdc8:      	b.gt	0xce58 <_ZN7CGif89a11checkFramesEv+0x15c>
    cdcc:      	cbz	w8, 0xcd98 <_ZN7CGif89a11checkFramesEv+0x9c>
    cdd0:      	cmp	w8, #0x21
    cdd4:      	mov	w0, wzr
    cdd8:      	b.ne	0xcd5c <_ZN7CGif89a11checkFramesEv+0x60>
    cddc:      	ldr	x3, [x19, #0x8]
    cde0:      	add	x0, sp, #0x4
    cde4:      	mov	w1, #0x1                // =1
    cde8:      	mov	w2, #0x1                // =1
    cdec:      	bl	0x13180 <fread@plt>
    cdf0:      	ldrb	w8, [sp, #0x4]
    cdf4:      	sub	w9, w8, #0xf9
    cdf8:      	cmp	w9, #0x6
    cdfc:      	b.hi	0xce0c <_ZN7CGif89a11checkFramesEv+0x110>
    ce00:      	lsl	w9, w23, w9
    ce04:      	tst	w9, w24
    ce08:      	b.ne	0xce14 <_ZN7CGif89a11checkFramesEv+0x118>
    ce0c:      	cmp	w8, #0x1
    ce10:      	b.ne	0xcf34 <_ZN7CGif89a11checkFramesEv+0x238>
    ce14:      	ldr	x0, [x19, #0x8]
    ce18:      	bl	0x131d0 <feof@plt>
    ce1c:      	cbnz	w0, 0xcd98 <_ZN7CGif89a11checkFramesEv+0x9c>
    ce20:      	ldr	x3, [x19, #0x8]
    ce24:      	add	x0, sp, #0x4
    ce28:      	mov	w1, #0x1                // =1
    ce2c:      	mov	w2, #0x1                // =1
    ce30:      	bl	0x13180 <fread@plt>
    ce34:      	ldrb	w1, [sp, #0x4]
    ce38:      	cbz	x1, 0xcd98 <_ZN7CGif89a11checkFramesEv+0x9c>
    ce3c:      	ldr	x0, [x19, #0x8]
    ce40:      	mov	w2, #0x1                // =1
    ce44:      	bl	0x131a0 <fseek@plt>
    ce48:      	ldr	x0, [x19, #0x8]
    ce4c:      	bl	0x131d0 <feof@plt>
    ce50:      	cbz	w0, 0xce20 <_ZN7CGif89a11checkFramesEv+0x124>
    ce54:      	b	0xcd98 <_ZN7CGif89a11checkFramesEv+0x9c>
    ce58:      	cmp	w8, #0x2c
    ce5c:      	b.eq	0xce80 <_ZN7CGif89a11checkFramesEv+0x184>
    ce60:      	cmp	w8, #0x3b
    ce64:      	mov	w0, wzr
    ce68:      	b.ne	0xcd5c <_ZN7CGif89a11checkFramesEv+0x60>
    ce6c:      	mov	w26, #0x1               // =1
    ce70:      	ldr	x0, [x19, #0x8]
    ce74:      	bl	0x131d0 <feof@plt>
    ce78:      	cbz	w0, 0xcda8 <_ZN7CGif89a11checkFramesEv+0xac>
    ce7c:      	b	0xcd48 <_ZN7CGif89a11checkFramesEv+0x4c>
    ce80:      	ldr	x0, [x19, #0x8]
    ce84:      	mov	w1, #0x8                // =8
    ce88:      	mov	w2, #0x1                // =1
    ce8c:      	bl	0x131a0 <fseek@plt>
    ce90:      	ldr	x3, [x19, #0x8]
    ce94:      	mov	x0, sp
    ce98:      	mov	w1, #0x1                // =1
    ce9c:      	mov	w2, #0x1                // =1
    cea0:      	bl	0x13180 <fread@plt>
    cea4:      	ldrsb	w8, [sp]
    cea8:      	tbz	w8, #0x1f, 0xcec8 <_ZN7CGif89a11checkFramesEv+0x1cc>
    ceac:      	and	x8, x8, #0xff
    ceb0:      	ldr	x0, [x19, #0x8]
    ceb4:      	mov	w2, #0x1                // =1
    ceb8:      	and	x8, x8, #0x7
    cebc:      	add	x8, x8, #0x1
    cec0:      	lsl	x1, x25, x8
    cec4:      	bl	0x131a0 <fseek@plt>
    cec8:      	ldr	x3, [x19, #0x8]
    cecc:      	add	x0, sp, #0x4
    ced0:      	mov	w1, #0x1                // =1
    ced4:      	mov	w2, #0x1                // =1
    ced8:      	bl	0x13180 <fread@plt>
    cedc:      	ldr	x0, [x19, #0x8]
    cee0:      	bl	0x131d0 <feof@plt>
    cee4:      	cbnz	w0, 0xcf1c <_ZN7CGif89a11checkFramesEv+0x220>
    cee8:      	ldr	x3, [x19, #0x8]
    ceec:      	add	x0, sp, #0x4
    cef0:      	mov	w1, #0x1                // =1
    cef4:      	mov	w2, #0x1                // =1
    cef8:      	bl	0x13180 <fread@plt>
    cefc:      	ldrb	w1, [sp, #0x4]
    cf00:      	cbz	x1, 0xcf1c <_ZN7CGif89a11checkFramesEv+0x220>
    cf04:      	ldr	x0, [x19, #0x8]
    cf08:      	mov	w2, #0x1                // =1
    cf0c:      	bl	0x131a0 <fseek@plt>
    cf10:      	ldr	x0, [x19, #0x8]
    cf14:      	bl	0x131d0 <feof@plt>
    cf18:      	cbz	w0, 0xcee8 <_ZN7CGif89a11checkFramesEv+0x1ec>
    cf1c:      	mov	w26, wzr
    cf20:      	add	w22, w22, #0x1
    cf24:      	ldr	x0, [x19, #0x8]
    cf28:      	bl	0x131d0 <feof@plt>
    cf2c:      	cbz	w0, 0xcda8 <_ZN7CGif89a11checkFramesEv+0xac>
    cf30:      	b	0xcd48 <_ZN7CGif89a11checkFramesEv+0x4c>
    cf34:      	mov	w0, wzr
    cf38:      	b	0xcd5c <_ZN7CGif89a11checkFramesEv+0x60>
    cf3c:      	bl	0x12bc0 <__stack_chk_fail@plt>

000000000000cf40 <_ZN7CGif89a12getAllFramesEv>:
    cf40:      	sub	sp, sp, #0x60
    cf44:      	stp	x29, x30, [sp, #0x10]
    cf48:      	stp	x26, x25, [sp, #0x20]
    cf4c:      	stp	x24, x23, [sp, #0x30]
    cf50:      	stp	x22, x21, [sp, #0x40]
    cf54:      	stp	x20, x19, [sp, #0x50]
    cf58:      	add	x29, sp, #0x10
    cf5c:      	mrs	x22, TPIDR_EL0
    cf60:      	mov	x19, x0
    cf64:      	ldr	x8, [x22, #0x28]
    cf68:      	str	x8, [sp, #0x8]
    cf6c:      	ldr	x20, [x0, #0x330]
    cf70:      	ldr	x0, [x0, #0x8]
    cf74:      	bl	0x131b0 <ftell@plt>
    cf78:      	ldr	x8, [x19, #0x8]
    cf7c:      	mov	x21, x0
    cf80:      	mov	x0, x8
    cf84:      	bl	0x131d0 <feof@plt>
    cf88:      	cbz	w0, 0xcfcc <_ZN7CGif89a12getAllFramesEv+0x8c>
    cf8c:      	ldr	x0, [x19, #0x8]
    cf90:      	mov	x1, x21
    cf94:      	mov	w2, wzr
    cf98:      	bl	0x131a0 <fseek@plt>
    cf9c:      	mov	w0, #0x1                // =1
    cfa0:      	ldr	x8, [x22, #0x28]
    cfa4:      	ldr	x9, [sp, #0x8]
    cfa8:      	cmp	x8, x9
    cfac:      	b.ne	0xd2f0 <_ZN7CGif89a12getAllFramesEv+0x3b0>
    cfb0:      	ldp	x20, x19, [sp, #0x50]
    cfb4:      	ldp	x22, x21, [sp, #0x40]
    cfb8:      	ldp	x24, x23, [sp, #0x30]
    cfbc:      	ldp	x26, x25, [sp, #0x20]
    cfc0:      	ldp	x29, x30, [sp, #0x10]
    cfc4:      	add	sp, sp, #0x60
    cfc8:      	ret
    cfcc:      	add	x23, x19, #0x398
    cfd0:      	mov	w24, #0x1               // =1
    cfd4:      	mov	w25, #0x3               // =3
    cfd8:      	b	0xcffc <_ZN7CGif89a12getAllFramesEv+0xbc>
    cfdc:      	ldr	x0, [x19, #0x8]
    cfe0:      	bl	0x131d0 <feof@plt>
    cfe4:      	cbz	w0, 0xd06c <_ZN7CGif89a12getAllFramesEv+0x12c>
    cfe8:      	mov	w26, wzr
    cfec:      	ldr	x0, [x19, #0x8]
    cff0:      	bl	0x131d0 <feof@plt>
    cff4:      	cbnz	w0, 0xcf8c <_ZN7CGif89a12getAllFramesEv+0x4c>
    cff8:      	cbnz	w26, 0xcf8c <_ZN7CGif89a12getAllFramesEv+0x4c>
    cffc:      	ldr	x3, [x19, #0x8]
    d000:      	add	x0, sp, #0x4
    d004:      	mov	w1, #0x1                // =1
    d008:      	mov	w2, #0x1                // =1
    d00c:      	bl	0x13180 <fread@plt>
    d010:      	ldrb	w8, [sp, #0x4]
    d014:      	cmp	w8, #0x2b
    d018:      	b.gt	0xd0a4 <_ZN7CGif89a12getAllFramesEv+0x164>
    d01c:      	cbz	w8, 0xcfe8 <_ZN7CGif89a12getAllFramesEv+0xa8>
    d020:      	cmp	w8, #0x21
    d024:      	b.ne	0xd290 <_ZN7CGif89a12getAllFramesEv+0x350>
    d028:      	ldr	x3, [x19, #0x8]
    d02c:      	add	x0, sp, #0x4
    d030:      	mov	w1, #0x1                // =1
    d034:      	mov	w2, #0x1                // =1
    d038:      	bl	0x13180 <fread@plt>
    d03c:      	ldrb	w8, [sp, #0x4]
    d040:      	sub	w9, w8, #0xfe
    d044:      	cmp	w9, #0x2
    d048:      	b.lo	0xcfdc <_ZN7CGif89a12getAllFramesEv+0x9c>
    d04c:      	cmp	w8, #0x1
    d050:      	b.eq	0xcfdc <_ZN7CGif89a12getAllFramesEv+0x9c>
    d054:      	cmp	w8, #0xf9
    d058:      	b.ne	0xd290 <_ZN7CGif89a12getAllFramesEv+0x350>
    d05c:      	ldr	x0, [x19, #0x8]
    d060:      	bl	0x131d0 <feof@plt>
    d064:      	cbnz	w0, 0xcfe8 <_ZN7CGif89a12getAllFramesEv+0xa8>
    d068:      	b	0xd220 <_ZN7CGif89a12getAllFramesEv+0x2e0>
    d06c:      	ldr	x3, [x19, #0x8]
    d070:      	add	x0, sp, #0x4
    d074:      	mov	w1, #0x1                // =1
    d078:      	mov	w2, #0x1                // =1
    d07c:      	bl	0x13180 <fread@plt>
    d080:      	ldrb	w1, [sp, #0x4]
    d084:      	cbz	x1, 0xcfe8 <_ZN7CGif89a12getAllFramesEv+0xa8>
    d088:      	ldr	x0, [x19, #0x8]
    d08c:      	mov	w2, #0x1                // =1
    d090:      	bl	0x131a0 <fseek@plt>
    d094:      	ldr	x0, [x19, #0x8]
    d098:      	bl	0x131d0 <feof@plt>
    d09c:      	cbz	w0, 0xd06c <_ZN7CGif89a12getAllFramesEv+0x12c>
    d0a0:      	b	0xcfe8 <_ZN7CGif89a12getAllFramesEv+0xa8>
    d0a4:      	cmp	w8, #0x2c
    d0a8:      	b.eq	0xd0c8 <_ZN7CGif89a12getAllFramesEv+0x188>
    d0ac:      	cmp	w8, #0x3b
    d0b0:      	b.ne	0xd290 <_ZN7CGif89a12getAllFramesEv+0x350>
    d0b4:      	mov	w26, #0x1               // =1
    d0b8:      	ldr	x0, [x19, #0x8]
    d0bc:      	bl	0x131d0 <feof@plt>
    d0c0:      	cbz	w0, 0xcff8 <_ZN7CGif89a12getAllFramesEv+0xb8>
    d0c4:      	b	0xcf8c <_ZN7CGif89a12getAllFramesEv+0x4c>
    d0c8:      	ldr	x3, [x19, #0x8]
    d0cc:      	mov	x0, x20
    d0d0:      	mov	w1, #0x1                // =1
    d0d4:      	mov	w2, #0x2                // =2
    d0d8:      	bl	0x13180 <fread@plt>
    d0dc:      	ldr	x3, [x19, #0x8]
    d0e0:      	add	x0, x20, #0x2
    d0e4:      	mov	w1, #0x1                // =1
    d0e8:      	mov	w2, #0x2                // =2
    d0ec:      	bl	0x13180 <fread@plt>
    d0f0:      	ldr	x3, [x19, #0x8]
    d0f4:      	add	x0, x20, #0x4
    d0f8:      	mov	w1, #0x1                // =1
    d0fc:      	mov	w2, #0x2                // =2
    d100:      	bl	0x13180 <fread@plt>
    d104:      	ldr	x3, [x19, #0x8]
    d108:      	add	x0, x20, #0x6
    d10c:      	mov	w1, #0x1                // =1
    d110:      	mov	w2, #0x2                // =2
    d114:      	bl	0x13180 <fread@plt>
    d118:      	ldr	x3, [x19, #0x8]
    d11c:      	mov	x0, sp
    d120:      	mov	w1, #0x1                // =1
    d124:      	mov	w2, #0x1                // =1
    d128:      	bl	0x13180 <fread@plt>
    d12c:      	ldrb	w8, [sp]
    d130:      	tbnz	w8, #0x7, 0xd260 <_ZN7CGif89a12getAllFramesEv+0x320>
    d134:      	tbnz	w8, #0x6, 0xd268 <_ZN7CGif89a12getAllFramesEv+0x328>
    d138:      	tbnz	w8, #0x5, 0xd270 <_ZN7CGif89a12getAllFramesEv+0x330>
    d13c:      	and	x8, x8, #0x7
    d140:      	ldrb	w10, [x20, #0x8]
    d144:      	add	x8, x8, #0x1
    d148:      	lsl	w9, w24, w8
    d14c:      	str	w9, [x20, #0xc]
    d150:      	cbz	w10, 0xd174 <_ZN7CGif89a12getAllFramesEv+0x234>
    d154:      	lsl	x0, x25, x8
    d158:      	bl	0x130e0 <_Znam@plt>
    d15c:      	ldr	w8, [x20, #0xc]
    d160:      	ldr	x3, [x19, #0x8]
    d164:      	mov	w1, #0x1                // =1
    d168:      	str	x0, [x20, #0x10]
    d16c:      	add	w2, w8, w8, lsl #1
    d170:      	bl	0x13180 <fread@plt>
    d174:      	mov	x0, x19
    d178:      	mov	x1, x20
    d17c:      	bl	0x132c0 <_ZN7CGif89a11extractDataEP5FRAME@plt>
    d180:      	tbz	w0, #0x0, 0xd290 <_ZN7CGif89a12getAllFramesEv+0x350>
    d184:      	ldrb	w8, [x23]
    d188:      	cbz	w8, 0xd198 <_ZN7CGif89a12getAllFramesEv+0x258>
    d18c:      	ldr	q0, [x23]
    d190:      	str	q0, [x20, #0x20]
    d194:      	strb	wzr, [x23]
    d198:      	mov	w26, wzr
    d19c:      	add	x20, x20, #0x30
    d1a0:      	ldr	x0, [x19, #0x8]
    d1a4:      	bl	0x131d0 <feof@plt>
    d1a8:      	cbz	w0, 0xcff8 <_ZN7CGif89a12getAllFramesEv+0xb8>
    d1ac:      	b	0xcf8c <_ZN7CGif89a12getAllFramesEv+0x4c>
    d1b0:      	ldr	x3, [x19, #0x8]
    d1b4:      	add	x0, sp, #0x4
    d1b8:      	mov	w1, #0x1                // =1
    d1bc:      	mov	w2, #0x1                // =1
    d1c0:      	strb	w24, [x19, #0x398]
    d1c4:      	bl	0x13180 <fread@plt>
    d1c8:      	ldrb	w8, [sp, #0x4]
    d1cc:      	ldr	x3, [x19, #0x8]
    d1d0:      	add	x0, x19, #0x3a2
    d1d4:      	mov	w1, #0x1                // =1
    d1d8:      	mov	w2, #0x2                // =2
    d1dc:      	ubfx	w9, w8, #2, #3
    d1e0:      	ubfx	w10, w8, #1, #1
    d1e4:      	and	w8, w8, #0x1
    d1e8:      	strb	w8, [x19, #0x3a1]
    d1ec:      	str	w9, [x19, #0x39c]
    d1f0:      	strb	w10, [x19, #0x3a0]
    d1f4:      	bl	0x13180 <fread@plt>
    d1f8:      	ldr	x3, [x19, #0x8]
    d1fc:      	add	x0, sp, #0x4
    d200:      	mov	w1, #0x1                // =1
    d204:      	mov	w2, #0x1                // =1
    d208:      	bl	0x13180 <fread@plt>
    d20c:      	ldrb	w8, [sp, #0x4]
    d210:      	str	w8, [x19, #0x3a4]
    d214:      	ldr	x0, [x19, #0x8]
    d218:      	bl	0x131d0 <feof@plt>
    d21c:      	cbnz	w0, 0xcfe8 <_ZN7CGif89a12getAllFramesEv+0xa8>
    d220:      	ldr	x3, [x19, #0x8]
    d224:      	add	x0, sp, #0x4
    d228:      	mov	w1, #0x1                // =1
    d22c:      	mov	w2, #0x1                // =1
    d230:      	bl	0x13180 <fread@plt>
    d234:      	ldrb	w1, [sp, #0x4]
    d238:      	cmp	w1, #0x4
    d23c:      	b.eq	0xd1b0 <_ZN7CGif89a12getAllFramesEv+0x270>
    d240:      	cbz	w1, 0xcfe8 <_ZN7CGif89a12getAllFramesEv+0xa8>
    d244:      	ldr	x0, [x19, #0x8]
    d248:      	mov	w2, #0x1                // =1
    d24c:      	bl	0x131a0 <fseek@plt>
    d250:      	ldr	x0, [x19, #0x8]
    d254:      	bl	0x131d0 <feof@plt>
    d258:      	cbz	w0, 0xd220 <_ZN7CGif89a12getAllFramesEv+0x2e0>
    d25c:      	b	0xcfe8 <_ZN7CGif89a12getAllFramesEv+0xa8>
    d260:      	strb	w24, [x20, #0x8]
    d264:      	tbz	w8, #0x6, 0xd138 <_ZN7CGif89a12getAllFramesEv+0x1f8>
    d268:      	strb	w24, [x20, #0x9]
    d26c:      	tbz	w8, #0x5, 0xd13c <_ZN7CGif89a12getAllFramesEv+0x1fc>
    d270:      	strb	w24, [x20, #0xa]
    d274:      	and	x8, x8, #0x7
    d278:      	ldrb	w10, [x20, #0x8]
    d27c:      	add	x8, x8, #0x1
    d280:      	lsl	w9, w24, w8
    d284:      	str	w9, [x20, #0xc]
    d288:      	cbnz	w10, 0xd154 <_ZN7CGif89a12getAllFramesEv+0x214>
    d28c:      	b	0xd174 <_ZN7CGif89a12getAllFramesEv+0x234>
    d290:      	ldr	w8, [x19, #0x340]
    d294:      	cmp	w8, #0x1
    d298:      	b.lt	0xd2dc <_ZN7CGif89a12getAllFramesEv+0x39c>
    d29c:      	ldr	x20, [x19, #0x330]
    d2a0:      	mov	w21, wzr
    d2a4:      	b	0xd2b8 <_ZN7CGif89a12getAllFramesEv+0x378>
    d2a8:      	ldr	w8, [x19, #0x340]
    d2ac:      	add	w21, w21, #0x1
    d2b0:      	cmp	w21, w8
    d2b4:      	b.ge	0xd2dc <_ZN7CGif89a12getAllFramesEv+0x39c>
    d2b8:      	ldr	x0, [x20, #0x10]
    d2bc:      	cbz	x0, 0xd2c8 <_ZN7CGif89a12getAllFramesEv+0x388>
    d2c0:      	bl	0x130f0 <_ZdaPv@plt>
    d2c4:      	str	xzr, [x20, #0x10]
    d2c8:      	ldr	x0, [x20, #0x18]
    d2cc:      	cbz	x0, 0xd2a8 <_ZN7CGif89a12getAllFramesEv+0x368>
    d2d0:      	bl	0x130f0 <_ZdaPv@plt>
    d2d4:      	str	xzr, [x20, #0x18]
    d2d8:      	b	0xd2a8 <_ZN7CGif89a12getAllFramesEv+0x368>
    d2dc:      	mov	w0, wzr
    d2e0:      	ldr	x8, [x22, #0x28]
    d2e4:      	ldr	x9, [sp, #0x8]
    d2e8:      	cmp	x8, x9
    d2ec:      	b.eq	0xcfb0 <_ZN7CGif89a12getAllFramesEv+0x70>
    d2f0:      	bl	0x12bc0 <__stack_chk_fail@plt>

000000000000d2f4 <_ZN7CGif89a11extractDataEP5FRAME>:
    d2f4:      	stp	x29, x30, [sp, #-0x60]!
    d2f8:      	stp	x28, x27, [sp, #0x10]
    d2fc:      	stp	x26, x25, [sp, #0x20]
    d300:      	stp	x24, x23, [sp, #0x30]
    d304:      	stp	x22, x21, [sp, #0x40]
    d308:      	stp	x20, x19, [sp, #0x50]
    d30c:      	mov	x29, sp
    d310:      	sub	sp, sp, #0x1a0
    d314:      	mrs	x8, TPIDR_EL0
    d318:      	mov	x22, x0
    d31c:      	mov	w0, #0x10000            // =65536
    d320:      	str	x8, [sp, #0x28]
    d324:      	mov	x19, x1
    d328:      	ldr	x8, [x8, #0x28]
    d32c:      	stur	x8, [x29, #-0x10]
    d330:      	ldrh	w8, [x1, #0x4]
    d334:      	ldrh	w9, [x1, #0x6]
    d338:      	umull	x21, w9, w8
    d33c:      	bl	0x130e0 <_Znam@plt>
    d340:      	mov	w1, wzr
    d344:      	mov	w2, #0x10000            // =65536
    d348:      	mov	x20, x0
    d34c:      	bl	0x130b0 <memset@plt>
    d350:      	mov	x0, x21
    d354:      	str	x21, [sp, #0x38]
    d358:      	bl	0x130e0 <_Znam@plt>
    d35c:      	ldr	x3, [x22, #0x8]
    d360:      	mov	x23, x0
    d364:      	str	x0, [x19, #0x18]
    d368:      	add	x0, sp, #0x84
    d36c:      	mov	w1, #0x1                // =1
    d370:      	mov	w2, #0x1                // =1
    d374:      	str	x22, [sp, #0x60]
    d378:      	str	x19, [sp, #0x20]
    d37c:      	mov	w19, #0x1               // =1
    d380:      	bl	0x13180 <fread@plt>
    d384:      	ldrb	w8, [sp, #0x84]
    d388:      	mov	x21, xzr
    d38c:      	add	x22, x20, #0x8
    d390:      	lsl	x27, x19, x8
    d394:      	str	x8, [sp, #0x58]
    d398:      	mov	w0, #0x2                // =2
    d39c:      	bl	0x130e0 <_Znam@plt>
    d3a0:      	strb	w21, [x0]
    d3a4:      	add	x21, x21, #0x1
    d3a8:      	cmp	x27, x21
    d3ac:      	stur	w19, [x22, #-0x8]
    d3b0:      	str	x0, [x22], #0x10
    d3b4:      	strb	wzr, [x0, #0x1]
    d3b8:      	b.ne	0xd398 <_ZN7CGif89a11extractDataEP5FRAME+0xa4>
    d3bc:      	ldr	x11, [sp, #0x58]
    d3c0:      	mov	w8, w27
    d3c4:      	mov	w9, #0x1f               // =31
    d3c8:      	sxtw	x8, w8
    d3cc:      	add	x10, x20, w27, sxtw #4
    d3d0:      	mov	w28, wzr
    d3d4:      	sub	w9, w9, w11
    d3d8:      	add	w12, w11, #0x1
    d3dc:      	mov	w25, wzr
    d3e0:      	str	x9, [sp, #0x70]
    d3e4:      	add	w9, w27, #0x1
    d3e8:      	mov	w21, wzr
    d3ec:      	mov	w26, wzr
    d3f0:      	mov	w19, wzr
    d3f4:      	str	w12, [sp, #0x6c]
    d3f8:      	add	w12, w27, #0x2
    d3fc:      	str	x9, [sp, #0x78]
    d400:      	add	x9, x10, #0x8
    d404:      	add	x8, x8, #0x1
    d408:      	add	x11, sp, #0x88
    d40c:      	str	w12, [sp, #0x1c]
    d410:      	stp	x8, x9, [sp, #0x8]
    d414:      	cmp	w28, #0x4
    d418:      	b.gt	0xd4b4 <_ZN7CGif89a11extractDataEP5FRAME+0x1c0>
    d41c:      	tbnz	w19, #0x0, 0xd4b4 <_ZN7CGif89a11extractDataEP5FRAME+0x1c0>
    d420:      	cmp	w28, #0x1
    d424:      	b.lt	0xd468 <_ZN7CGif89a11extractDataEP5FRAME+0x174>
    d428:      	ldrb	w8, [x11, w25, uxtw]
    d42c:      	strb	w8, [sp, #0x88]
    d430:      	b.eq	0xd468 <_ZN7CGif89a11extractDataEP5FRAME+0x174>
    d434:      	add	w8, w25, #0x1
    d438:      	cmp	w28, #0x2
    d43c:      	ldrb	w8, [x11, w8, uxtw]
    d440:      	strb	w8, [sp, #0x89]
    d444:      	b.eq	0xd468 <_ZN7CGif89a11extractDataEP5FRAME+0x174>
    d448:      	add	w8, w25, #0x2
    d44c:      	cmp	w28, #0x3
    d450:      	ldrb	w8, [x11, w8, uxtw]
    d454:      	strb	w8, [sp, #0x8a]
    d458:      	b.eq	0xd468 <_ZN7CGif89a11extractDataEP5FRAME+0x174>
    d45c:      	add	w8, w25, #0x3
    d460:      	ldrb	w8, [x11, w8, uxtw]
    d464:      	strb	w8, [sp, #0x8b]
    d468:      	ldr	x22, [sp, #0x60]
    d46c:      	add	x0, sp, #0x84
    d470:      	mov	w1, #0x1                // =1
    d474:      	mov	w2, #0x1                // =1
    d478:      	mov	w19, #0x1               // =1
    d47c:      	ldr	x3, [x22, #0x8]
    d480:      	bl	0x13180 <fread@plt>
    d484:      	ldrb	w24, [sp, #0x84]
    d488:      	cbz	x24, 0xd51c <_ZN7CGif89a11extractDataEP5FRAME+0x228>
    d48c:      	add	x8, sp, #0x88
    d490:      	ldr	x3, [x22, #0x8]
    d494:      	mov	w1, #0x1                // =1
    d498:      	add	x0, x8, w28, sxtw
    d49c:      	mov	x2, x24
    d4a0:      	bl	0x13180 <fread@plt>
    d4a4:      	add	x11, sp, #0x88
    d4a8:      	mov	w25, wzr
    d4ac:      	mov	w19, wzr
    d4b0:      	add	w28, w28, w24
    d4b4:      	cmp	w28, #0x4
    d4b8:      	b.gt	0xd4d8 <_ZN7CGif89a11extractDataEP5FRAME+0x1e4>
    d4bc:      	cmp	w28, #0x1
    d4c0:      	b.lt	0xdaa8 <_ZN7CGif89a11extractDataEP5FRAME+0x7b4>
    d4c4:      	lsl	w8, w28, #3
    d4c8:      	ldr	x9, [sp, #0x58]
    d4cc:      	sub	w8, w8, w26
    d4d0:      	cmp	w8, w9
    d4d4:      	b.ls	0xdaa8 <_ZN7CGif89a11extractDataEP5FRAME+0x7b4>
    d4d8:      	ldr	x10, [sp, #0x70]
    d4dc:      	ldr	x8, [x11, w25, uxtw]
    d4e0:      	sub	w9, w10, w26
    d4e4:      	lsl	x8, x8, x9
    d4e8:      	lsr	x24, x8, x10
    d4ec:      	ldr	x8, [sp, #0x78]
    d4f0:      	cmp	x24, x8
    d4f4:      	b.hs	0xdae8 <_ZN7CGif89a11extractDataEP5FRAME+0x7f4>
    d4f8:      	ldr	w8, [sp, #0x6c]
    d4fc:      	cmp	x24, x27
    d500:      	add	w8, w26, w8
    d504:      	lsr	w9, w8, #3
    d508:      	and	w26, w8, #0x7
    d50c:      	sub	w28, w28, w9
    d510:      	add	w25, w25, w9
    d514:      	b.eq	0xd414 <_ZN7CGif89a11extractDataEP5FRAME+0x120>
    d518:      	b	0xd530 <_ZN7CGif89a11extractDataEP5FRAME+0x23c>
    d51c:      	mov	w25, wzr
    d520:      	add	x11, sp, #0x88
    d524:      	cmp	w28, #0x4
    d528:      	b.le	0xd4bc <_ZN7CGif89a11extractDataEP5FRAME+0x1c8>
    d52c:      	b	0xd4d8 <_ZN7CGif89a11extractDataEP5FRAME+0x1e4>
    d530:      	add	x8, x20, x24, lsl #4
    d534:      	ldr	w22, [sp, #0x1c]
    d538:      	ldr	w17, [sp, #0x6c]
    d53c:      	ldr	x8, [x8, #0x8]
    d540:      	ldrb	w8, [x8]
    d544:      	strb	w8, [x23, w21, uxtw]
    d548:      	add	w21, w21, #0x1
    d54c:      	b	0xd59c <_ZN7CGif89a11extractDataEP5FRAME+0x2a8>
    d550:      	ldr	w17, [sp, #0x54]
    d554:      	ldr	x24, [sp, #0x40]
    d558:      	mov	x8, xzr
    d55c:      	ldr	w14, [sp, #0x34]
    d560:      	mov	w10, #0x1               // =1
    d564:      	add	x9, x20, w22, uxtw #4
    d568:      	add	w22, w22, #0x1
    d56c:      	lsl	w10, w10, w17
    d570:      	cmp	w17, #0xc
    d574:      	strb	w14, [x0, x8]
    d578:      	add	w8, w21, #0x1
    d57c:      	mov	w21, w19
    d580:      	ldr	x19, [sp, #0x48]
    d584:      	ccmp	w22, w10, #0x0, ne
    d588:      	strb	wzr, [x0, w8, uxtw]
    d58c:      	add	x11, sp, #0x88
    d590:      	str	x0, [x9, #0x8]
    d594:      	cinc	w17, w17, eq
    d598:      	str	w8, [x9]
    d59c:      	cmp	w28, #0x4
    d5a0:      	str	w17, [sp, #0x54]
    d5a4:      	b.gt	0xd654 <_ZN7CGif89a11extractDataEP5FRAME+0x360>
    d5a8:      	tbnz	w19, #0x0, 0xd654 <_ZN7CGif89a11extractDataEP5FRAME+0x360>
    d5ac:      	cmp	w28, #0x1
    d5b0:      	str	w22, [sp, #0x40]
    d5b4:      	b.lt	0xd5f8 <_ZN7CGif89a11extractDataEP5FRAME+0x304>
    d5b8:      	ldrb	w8, [x11, w25, uxtw]
    d5bc:      	strb	w8, [sp, #0x88]
    d5c0:      	b.eq	0xd5f8 <_ZN7CGif89a11extractDataEP5FRAME+0x304>
    d5c4:      	add	w8, w25, #0x1
    d5c8:      	cmp	w28, #0x2
    d5cc:      	ldrb	w8, [x11, w8, uxtw]
    d5d0:      	strb	w8, [sp, #0x89]
    d5d4:      	b.eq	0xd5f8 <_ZN7CGif89a11extractDataEP5FRAME+0x304>
    d5d8:      	add	w8, w25, #0x2
    d5dc:      	cmp	w28, #0x3
    d5e0:      	ldrb	w8, [x11, w8, uxtw]
    d5e4:      	strb	w8, [sp, #0x8a]
    d5e8:      	b.eq	0xd5f8 <_ZN7CGif89a11extractDataEP5FRAME+0x304>
    d5ec:      	add	w8, w25, #0x3
    d5f0:      	ldrb	w8, [x11, w8, uxtw]
    d5f4:      	strb	w8, [sp, #0x8b]
    d5f8:      	ldr	x19, [sp, #0x60]
    d5fc:      	add	x0, sp, #0x84
    d600:      	mov	w1, #0x1                // =1
    d604:      	mov	w2, #0x1                // =1
    d608:      	ldr	x3, [x19, #0x8]
    d60c:      	bl	0x13180 <fread@plt>
    d610:      	ldrb	w22, [sp, #0x84]
    d614:      	cbz	x22, 0xd664 <_ZN7CGif89a11extractDataEP5FRAME+0x370>
    d618:      	add	x8, sp, #0x88
    d61c:      	ldr	x3, [x19, #0x8]
    d620:      	mov	w1, #0x1                // =1
    d624:      	add	x0, x8, w28, sxtw
    d628:      	mov	x2, x22
    d62c:      	bl	0x13180 <fread@plt>
    d630:      	add	x11, sp, #0x88
    d634:      	mov	w25, wzr
    d638:      	add	w28, w28, w22
    d63c:      	str	xzr, [sp, #0x48]
    d640:      	ldr	w22, [sp, #0x40]
    d644:      	ldr	w17, [sp, #0x54]
    d648:      	cmp	w28, #0x4
    d64c:      	b.gt	0xd69c <_ZN7CGif89a11extractDataEP5FRAME+0x3a8>
    d650:      	b	0xd684 <_ZN7CGif89a11extractDataEP5FRAME+0x390>
    d654:      	str	x19, [sp, #0x48]
    d658:      	cmp	w28, #0x4
    d65c:      	b.le	0xd684 <_ZN7CGif89a11extractDataEP5FRAME+0x390>
    d660:      	b	0xd69c <_ZN7CGif89a11extractDataEP5FRAME+0x3a8>
    d664:      	mov	w8, #0x1                // =1
    d668:      	mov	w25, wzr
    d66c:      	add	x11, sp, #0x88
    d670:      	str	x8, [sp, #0x48]
    d674:      	ldr	w22, [sp, #0x40]
    d678:      	ldr	w17, [sp, #0x54]
    d67c:      	cmp	w28, #0x4
    d680:      	b.gt	0xd69c <_ZN7CGif89a11extractDataEP5FRAME+0x3a8>
    d684:      	cmp	w28, #0x1
    d688:      	b.lt	0xdaa8 <_ZN7CGif89a11extractDataEP5FRAME+0x7b4>
    d68c:      	lsl	w8, w28, #3
    d690:      	sub	w8, w8, w26
    d694:      	cmp	w17, w8
    d698:      	b.hi	0xdaa8 <_ZN7CGif89a11extractDataEP5FRAME+0x7b4>
    d69c:      	mov	w9, #0x20               // =32
    d6a0:      	ldr	x8, [x11, w25, uxtw]
    d6a4:      	sub	w9, w9, w17
    d6a8:      	sub	w10, w9, w26
    d6ac:      	lsl	x8, x8, x10
    d6b0:      	lsr	x0, x8, x9
    d6b4:      	add	w8, w17, w26
    d6b8:      	lsr	w9, w8, #3
    d6bc:      	and	w26, w8, #0x7
    d6c0:      	cmp	x0, x27
    d6c4:      	add	w25, w25, w9
    d6c8:      	sub	w28, w28, w9
    d6cc:      	b.eq	0xda60 <_ZN7CGif89a11extractDataEP5FRAME+0x76c>
    d6d0:      	ldr	x8, [sp, #0x78]
    d6d4:      	cmp	x0, x8
    d6d8:      	b.eq	0xdaa8 <_ZN7CGif89a11extractDataEP5FRAME+0x7b4>
    d6dc:      	add	x8, x20, x0, lsl #4
    d6e0:      	str	x0, [sp, #0x40]
    d6e4:      	ldr	x11, [x8, #0x8]
    d6e8:      	cbz	x11, 0xd760 <_ZN7CGif89a11extractDataEP5FRAME+0x46c>
    d6ec:      	ldr	w8, [x8]
    d6f0:      	ldr	x10, [sp, #0x38]
    d6f4:      	add	w9, w8, w21
    d6f8:      	cmp	w9, w10
    d6fc:      	b.hi	0xdae8 <_ZN7CGif89a11extractDataEP5FRAME+0x7f4>
    d700:      	ldrb	w14, [x11]
    d704:      	cmp	w8, #0x1
    d708:      	b.lt	0xd840 <_ZN7CGif89a11extractDataEP5FRAME+0x54c>
    d70c:      	cmp	w8, #0x20
    d710:      	b.lo	0xd730 <_ZN7CGif89a11extractDataEP5FRAME+0x43c>
    d714:      	neg	w9, w8
    d718:      	cmp	w21, w9
    d71c:      	b.hi	0xd730 <_ZN7CGif89a11extractDataEP5FRAME+0x43c>
    d720:      	add	x9, x23, w21, uxtw
    d724:      	sub	x9, x9, x11
    d728:      	cmp	x9, #0x20
    d72c:      	b.hs	0xd8a4 <_ZN7CGif89a11extractDataEP5FRAME+0x5b0>
    d730:      	mov	w10, wzr
    d734:      	mov	x9, x11
    d738:      	mov	w19, w21
    d73c:      	sub	w8, w8, w10
    d740:      	mov	w10, w19
    d744:      	ldrb	w11, [x9], #0x1
    d748:      	add	w19, w10, #0x1
    d74c:      	subs	w8, w8, #0x1
    d750:      	strb	w11, [x23, w10, uxtw]
    d754:      	mov	w10, w19
    d758:      	b.ne	0xd744 <_ZN7CGif89a11extractDataEP5FRAME+0x450>
    d75c:      	b	0xd844 <_ZN7CGif89a11extractDataEP5FRAME+0x550>
    d760:      	add	x9, x20, x24, lsl #4
    d764:      	add	w19, w21, #0x1
    d768:      	ldr	x11, [sp, #0x38]
    d76c:      	ldr	w8, [x9]
    d770:      	add	w10, w19, w8
    d774:      	cmp	w10, w11
    d778:      	b.hi	0xdae8 <_ZN7CGif89a11extractDataEP5FRAME+0x7f4>
    d77c:      	ldr	x9, [x9, #0x8]
    d780:      	cmp	w8, #0x1
    d784:      	ldrb	w1, [x9]
    d788:      	b.lt	0xd7dc <_ZN7CGif89a11extractDataEP5FRAME+0x4e8>
    d78c:      	cmp	w8, #0x20
    d790:      	b.lo	0xd7b0 <_ZN7CGif89a11extractDataEP5FRAME+0x4bc>
    d794:      	neg	w10, w8
    d798:      	cmp	w21, w10
    d79c:      	b.hi	0xd7b0 <_ZN7CGif89a11extractDataEP5FRAME+0x4bc>
    d7a0:      	add	x10, x23, w21, uxtw
    d7a4:      	sub	x10, x10, x9
    d7a8:      	cmp	x10, #0x20
    d7ac:      	b.hs	0xd974 <_ZN7CGif89a11extractDataEP5FRAME+0x680>
    d7b0:      	mov	w11, wzr
    d7b4:      	sub	w8, w8, w11
    d7b8:      	mov	w10, w21
    d7bc:      	ldrb	w11, [x9], #0x1
    d7c0:      	subs	w8, w8, #0x1
    d7c4:      	strb	w11, [x23, w10, uxtw]
    d7c8:      	add	w10, w10, #0x1
    d7cc:      	b.ne	0xd7bc <_ZN7CGif89a11extractDataEP5FRAME+0x4c8>
    d7d0:      	sub	w8, w10, #0x1
    d7d4:      	add	w19, w8, #0x2
    d7d8:      	mov	w21, w10
    d7dc:      	cmp	w22, #0xfff
    d7e0:      	strb	w1, [x23, w21, uxtw]
    d7e4:      	b.hi	0xdae8 <_ZN7CGif89a11extractDataEP5FRAME+0x7f4>
    d7e8:      	and	x24, x24, #0xffffffff
    d7ec:      	str	w1, [sp, #0x34]
    d7f0:      	lsl	x8, x24, #4
    d7f4:      	ldr	w21, [x20, x8]
    d7f8:      	add	w0, w21, #0x2
    d7fc:      	bl	0x130e0 <_Znam@plt>
    d800:      	cbz	w21, 0xd550 <_ZN7CGif89a11extractDataEP5FRAME+0x25c>
    d804:      	add	x8, x20, x24, lsl #4
    d808:      	cmp	w21, #0x8
    d80c:      	mov	x9, xzr
    d810:      	ldr	x8, [x8, #0x8]
    d814:      	b.lo	0xd9bc <_ZN7CGif89a11extractDataEP5FRAME+0x6c8>
    d818:      	sub	x10, x0, x8
    d81c:      	ldr	w17, [sp, #0x54]
    d820:      	ldr	x24, [sp, #0x40]
    d824:      	ldr	w14, [sp, #0x34]
    d828:      	cmp	x10, #0x20
    d82c:      	b.lo	0xda30 <_ZN7CGif89a11extractDataEP5FRAME+0x73c>
    d830:      	cmp	w21, #0x20
    d834:      	b.hs	0xd9cc <_ZN7CGif89a11extractDataEP5FRAME+0x6d8>
    d838:      	mov	x9, xzr
    d83c:      	b	0xda04 <_ZN7CGif89a11extractDataEP5FRAME+0x710>
    d840:      	mov	w19, w21
    d844:      	cmp	w22, #0xfff
    d848:      	b.hi	0xdae8 <_ZN7CGif89a11extractDataEP5FRAME+0x7f4>
    d84c:      	and	x24, x24, #0xffffffff
    d850:      	str	w14, [sp, #0x34]
    d854:      	lsl	x8, x24, #4
    d858:      	ldr	w21, [x20, x8]
    d85c:      	add	w0, w21, #0x2
    d860:      	bl	0x130e0 <_Znam@plt>
    d864:      	cbz	w21, 0xd550 <_ZN7CGif89a11extractDataEP5FRAME+0x25c>
    d868:      	add	x8, x20, x24, lsl #4
    d86c:      	cmp	w21, #0x8
    d870:      	mov	x9, xzr
    d874:      	ldr	x8, [x8, #0x8]
    d878:      	b.lo	0xd8e0 <_ZN7CGif89a11extractDataEP5FRAME+0x5ec>
    d87c:      	sub	x10, x0, x8
    d880:      	ldr	w17, [sp, #0x54]
    d884:      	ldr	x24, [sp, #0x40]
    d888:      	ldr	w14, [sp, #0x34]
    d88c:      	cmp	x10, #0x20
    d890:      	b.lo	0xd954 <_ZN7CGif89a11extractDataEP5FRAME+0x660>
    d894:      	cmp	w21, #0x20
    d898:      	b.hs	0xd8f0 <_ZN7CGif89a11extractDataEP5FRAME+0x5fc>
    d89c:      	mov	x9, xzr
    d8a0:      	b	0xd928 <_ZN7CGif89a11extractDataEP5FRAME+0x634>
    d8a4:      	and	x10, x8, #0x7fffffe0
    d8a8:      	add	x9, x11, x10
    d8ac:      	add	w19, w21, w10
    d8b0:      	add	x11, x11, #0x10
    d8b4:      	mov	x12, x10
    d8b8:      	ldp	q0, q1, [x11, #-0x10]
    d8bc:      	add	x13, x23, w21, uxtw
    d8c0:      	subs	x12, x12, #0x20
    d8c4:      	add	x11, x11, #0x20
    d8c8:      	add	w21, w21, #0x20
    d8cc:      	stp	q0, q1, [x13]
    d8d0:      	b.ne	0xd8b8 <_ZN7CGif89a11extractDataEP5FRAME+0x5c4>
    d8d4:      	cmp	x10, x8
    d8d8:      	b.ne	0xd73c <_ZN7CGif89a11extractDataEP5FRAME+0x448>
    d8dc:      	b	0xd844 <_ZN7CGif89a11extractDataEP5FRAME+0x550>
    d8e0:      	ldr	w17, [sp, #0x54]
    d8e4:      	ldr	x24, [sp, #0x40]
    d8e8:      	ldr	w14, [sp, #0x34]
    d8ec:      	b	0xd954 <_ZN7CGif89a11extractDataEP5FRAME+0x660>
    d8f0:      	and	x9, x21, #0xffffffe0
    d8f4:      	add	x10, x8, #0x10
    d8f8:      	add	x11, x0, #0x10
    d8fc:      	mov	x12, x9
    d900:      	ldp	q0, q1, [x10, #-0x10]
    d904:      	subs	x12, x12, #0x20
    d908:      	add	x10, x10, #0x20
    d90c:      	stp	q0, q1, [x11, #-0x10]
    d910:      	add	x11, x11, #0x20
    d914:      	b.ne	0xd900 <_ZN7CGif89a11extractDataEP5FRAME+0x60c>
    d918:      	cmp	x9, x21
    d91c:      	b.eq	0xda4c <_ZN7CGif89a11extractDataEP5FRAME+0x758>
    d920:      	tst	x21, #0x18
    d924:      	b.eq	0xd954 <_ZN7CGif89a11extractDataEP5FRAME+0x660>
    d928:      	mov	x12, x9
    d92c:      	and	x9, x21, #0xfffffff8
    d930:      	add	x10, x8, x12
    d934:      	add	x11, x0, x12
    d938:      	sub	x12, x12, x9
    d93c:      	ldr	d0, [x10], #0x8
    d940:      	adds	x12, x12, #0x8
    d944:      	str	d0, [x11], #0x8
    d948:      	b.ne	0xd93c <_ZN7CGif89a11extractDataEP5FRAME+0x648>
    d94c:      	cmp	x9, x21
    d950:      	b.eq	0xda4c <_ZN7CGif89a11extractDataEP5FRAME+0x758>
    d954:      	sub	x10, x21, x9
    d958:      	add	x11, x0, x9
    d95c:      	add	x8, x8, x9
    d960:      	ldrb	w9, [x8], #0x1
    d964:      	subs	x10, x10, #0x1
    d968:      	strb	w9, [x11], #0x1
    d96c:      	b.ne	0xd960 <_ZN7CGif89a11extractDataEP5FRAME+0x66c>
    d970:      	b	0xda4c <_ZN7CGif89a11extractDataEP5FRAME+0x758>
    d974:      	and	x11, x8, #0x7fffffe0
    d978:      	mov	w13, w21
    d97c:      	add	x12, x9, x11
    d980:      	add	w10, w21, w11
    d984:      	add	x9, x9, #0x10
    d988:      	mov	x14, x11
    d98c:      	ldp	q0, q1, [x9, #-0x10]
    d990:      	add	x15, x23, w13, uxtw
    d994:      	subs	x14, x14, #0x20
    d998:      	add	x9, x9, #0x20
    d99c:      	add	w13, w13, #0x20
    d9a0:      	stp	q0, q1, [x15]
    d9a4:      	b.ne	0xd98c <_ZN7CGif89a11extractDataEP5FRAME+0x698>
    d9a8:      	cmp	x11, x8
    d9ac:      	b.ne	0xda54 <_ZN7CGif89a11extractDataEP5FRAME+0x760>
    d9b0:      	add	w8, w11, w21
    d9b4:      	sub	w8, w8, #0x1
    d9b8:      	b	0xd7d4 <_ZN7CGif89a11extractDataEP5FRAME+0x4e0>
    d9bc:      	ldr	w17, [sp, #0x54]
    d9c0:      	ldr	x24, [sp, #0x40]
    d9c4:      	ldr	w14, [sp, #0x34]
    d9c8:      	b	0xda30 <_ZN7CGif89a11extractDataEP5FRAME+0x73c>
    d9cc:      	and	x9, x21, #0xffffffe0
    d9d0:      	add	x10, x8, #0x10
    d9d4:      	add	x11, x0, #0x10
    d9d8:      	mov	x12, x9
    d9dc:      	ldp	q0, q1, [x10, #-0x10]
    d9e0:      	subs	x12, x12, #0x20
    d9e4:      	add	x10, x10, #0x20
    d9e8:      	stp	q0, q1, [x11, #-0x10]
    d9ec:      	add	x11, x11, #0x20
    d9f0:      	b.ne	0xd9dc <_ZN7CGif89a11extractDataEP5FRAME+0x6e8>
    d9f4:      	cmp	x9, x21
    d9f8:      	b.eq	0xda4c <_ZN7CGif89a11extractDataEP5FRAME+0x758>
    d9fc:      	tst	x21, #0x18
    da00:      	b.eq	0xda30 <_ZN7CGif89a11extractDataEP5FRAME+0x73c>
    da04:      	mov	x12, x9
    da08:      	and	x9, x21, #0xfffffff8
    da0c:      	add	x10, x8, x12
    da10:      	add	x11, x0, x12
    da14:      	sub	x12, x12, x9
    da18:      	ldr	d0, [x10], #0x8
    da1c:      	adds	x12, x12, #0x8
    da20:      	str	d0, [x11], #0x8
    da24:      	b.ne	0xda18 <_ZN7CGif89a11extractDataEP5FRAME+0x724>
    da28:      	cmp	x9, x21
    da2c:      	b.eq	0xda4c <_ZN7CGif89a11extractDataEP5FRAME+0x758>
    da30:      	sub	x10, x21, x9
    da34:      	add	x11, x0, x9
    da38:      	add	x8, x8, x9
    da3c:      	ldrb	w9, [x8], #0x1
    da40:      	subs	x10, x10, #0x1
    da44:      	strb	w9, [x11], #0x1
    da48:      	b.ne	0xda3c <_ZN7CGif89a11extractDataEP5FRAME+0x748>
    da4c:      	mov	x8, x21
    da50:      	b	0xd560 <_ZN7CGif89a11extractDataEP5FRAME+0x26c>
    da54:      	mov	x9, x12
    da58:      	mov	w21, w10
    da5c:      	b	0xd7b4 <_ZN7CGif89a11extractDataEP5FRAME+0x4c0>
    da60:      	ldr	x19, [sp, #0x48]
    da64:      	cmp	w27, #0xfff
    da68:      	b.gt	0xd414 <_ZN7CGif89a11extractDataEP5FRAME+0x120>
    da6c:      	ldp	x22, x19, [sp, #0x8]
    da70:      	b	0xda84 <_ZN7CGif89a11extractDataEP5FRAME+0x790>
    da74:      	cmp	w22, #0x1, lsl #12      // =0x1000
    da78:      	add	x22, x22, #0x1
    da7c:      	add	x19, x19, #0x10
    da80:      	b.eq	0xda9c <_ZN7CGif89a11extractDataEP5FRAME+0x7a8>
    da84:      	ldr	x0, [x19]
    da88:      	cbz	x0, 0xda74 <_ZN7CGif89a11extractDataEP5FRAME+0x780>
    da8c:      	bl	0x12c80 <_ZdlPv@plt>
    da90:      	str	xzr, [x19]
    da94:      	stur	wzr, [x19, #-0x8]
    da98:      	b	0xda74 <_ZN7CGif89a11extractDataEP5FRAME+0x780>
    da9c:      	ldr	x19, [sp, #0x48]
    daa0:      	add	x11, sp, #0x88
    daa4:      	b	0xd414 <_ZN7CGif89a11extractDataEP5FRAME+0x120>
    daa8:      	mov	w21, #0x8               // =8
    daac:      	mov	w19, #0x8               // =8
    dab0:      	movk	w21, #0x1, lsl #16
    dab4:      	b	0xdac4 <_ZN7CGif89a11extractDataEP5FRAME+0x7d0>
    dab8:      	add	x19, x19, #0x10
    dabc:      	cmp	x19, x21
    dac0:      	b.eq	0xdad8 <_ZN7CGif89a11extractDataEP5FRAME+0x7e4>
    dac4:      	ldr	x0, [x20, x19]
    dac8:      	cbz	x0, 0xdab8 <_ZN7CGif89a11extractDataEP5FRAME+0x7c4>
    dacc:      	bl	0x12c80 <_ZdlPv@plt>
    dad0:      	str	xzr, [x20, x19]
    dad4:      	b	0xdab8 <_ZN7CGif89a11extractDataEP5FRAME+0x7c4>
    dad8:      	mov	x0, x20
    dadc:      	bl	0x130f0 <_ZdaPv@plt>
    dae0:      	mov	w0, #0x1                // =1
    dae4:      	b	0xdb38 <_ZN7CGif89a11extractDataEP5FRAME+0x844>
    dae8:      	mov	w21, #0x8               // =8
    daec:      	mov	w19, #0x8               // =8
    daf0:      	movk	w21, #0x1, lsl #16
    daf4:      	b	0xdb04 <_ZN7CGif89a11extractDataEP5FRAME+0x810>
    daf8:      	add	x19, x19, #0x10
    dafc:      	cmp	x19, x21
    db00:      	b.eq	0xdb18 <_ZN7CGif89a11extractDataEP5FRAME+0x824>
    db04:      	ldr	x0, [x20, x19]
    db08:      	cbz	x0, 0xdaf8 <_ZN7CGif89a11extractDataEP5FRAME+0x804>
    db0c:      	bl	0x12c80 <_ZdlPv@plt>
    db10:      	str	xzr, [x20, x19]
    db14:      	b	0xdaf8 <_ZN7CGif89a11extractDataEP5FRAME+0x804>
    db18:      	mov	x0, x20
    db1c:      	bl	0x130f0 <_ZdaPv@plt>
    db20:      	ldr	x19, [sp, #0x20]
    db24:      	ldr	x0, [x19, #0x18]
    db28:      	cbz	x0, 0xdb30 <_ZN7CGif89a11extractDataEP5FRAME+0x83c>
    db2c:      	bl	0x130f0 <_ZdaPv@plt>
    db30:      	mov	w0, wzr
    db34:      	str	xzr, [x19, #0x18]
    db38:      	ldr	x8, [sp, #0x28]
    db3c:      	ldr	x8, [x8, #0x28]
    db40:      	ldur	x9, [x29, #-0x10]
    db44:      	cmp	x8, x9
    db48:      	b.ne	0xdb6c <_ZN7CGif89a11extractDataEP5FRAME+0x878>
    db4c:      	add	sp, sp, #0x1a0
    db50:      	ldp	x20, x19, [sp, #0x50]
    db54:      	ldp	x22, x21, [sp, #0x40]
    db58:      	ldp	x24, x23, [sp, #0x30]
    db5c:      	ldp	x26, x25, [sp, #0x20]
    db60:      	ldp	x28, x27, [sp, #0x10]
    db64:      	ldp	x29, x30, [sp], #0x60
    db68:      	ret
    db6c:      	bl	0x12bc0 <__stack_chk_fail@plt>

000000000000db70 <_ZN7CGif89a13getNextFrameTEPi>:
    db70:      	stp	x29, x30, [sp, #-0x40]!
    db74:      	stp	x24, x23, [sp, #0x10]
    db78:      	stp	x22, x21, [sp, #0x20]
    db7c:      	stp	x20, x19, [sp, #0x30]
    db80:      	mov	x29, sp
    db84:      	mov	x20, x1
    db88:      	bl	0x132d0 <_ZN7CGif89a12getNextFrameEv@plt>
    db8c:      	cbz	x0, 0xdc4c <_ZN7CGif89a13getNextFrameTEPi+0xdc>
    db90:      	ldrh	w22, [x0, #0x4]
    db94:      	ldrh	w23, [x0, #0x6]
    db98:      	mov	x19, x0
    db9c:      	ldrh	w9, [x0, #0x2a]
    dba0:      	ldp	x24, x21, [x0, #0x10]
    dba4:      	mul	w8, w22, w23
    dba8:      	str	w9, [x20]
    dbac:      	lsl	w0, w8, #2
    dbb0:      	bl	0x130e0 <_Znam@plt>
    dbb4:      	mov	x20, x0
    dbb8:      	cbz	w23, 0xdc14 <_ZN7CGif89a13getNextFrameTEPi+0xa4>
    dbbc:      	cbz	w22, 0xdc14 <_ZN7CGif89a13getNextFrameTEPi+0xa4>
    dbc0:      	mov	w8, wzr
    dbc4:      	mov	w9, #0xff               // =255
    dbc8:      	mov	x10, x20
    dbcc:      	mov	w11, w22
    dbd0:      	ldrb	w12, [x21], #0x1
    dbd4:      	strb	w9, [x10, #0x3]
    dbd8:      	subs	w11, w11, #0x1
    dbdc:      	add	x12, x12, x12, lsl #1
    dbe0:      	add	x12, x24, x12
    dbe4:      	ldrb	w13, [x12]
    dbe8:      	strb	w13, [x10]
    dbec:      	ldrb	w13, [x12, #0x1]
    dbf0:      	strb	w13, [x10, #0x1]
    dbf4:      	ldrb	w12, [x12, #0x2]
    dbf8:      	strb	w12, [x10, #0x2]
    dbfc:      	add	x10, x10, #0x4
    dc00:      	b.ne	0xdbd0 <_ZN7CGif89a13getNextFrameTEPi+0x60>
    dc04:      	add	w8, w8, #0x1
    dc08:      	cmp	w8, w23
    dc0c:      	b.ne	0xdbcc <_ZN7CGif89a13getNextFrameTEPi+0x5c>
    dc10:      	ldr	x21, [x19, #0x18]
    dc14:      	cbz	x21, 0xdc20 <_ZN7CGif89a13getNextFrameTEPi+0xb0>
    dc18:      	mov	x0, x21
    dc1c:      	bl	0x130f0 <_ZdaPv@plt>
    dc20:      	ldr	x0, [x19, #0x10]
    dc24:      	str	xzr, [x19, #0x18]
    dc28:      	cbz	x0, 0xdc30 <_ZN7CGif89a13getNextFrameTEPi+0xc0>
    dc2c:      	bl	0x130f0 <_ZdaPv@plt>
    dc30:      	str	xzr, [x19, #0x10]
    dc34:      	mov	x0, x20
    dc38:      	ldp	x20, x19, [sp, #0x30]
    dc3c:      	ldp	x22, x21, [sp, #0x20]
    dc40:      	ldp	x24, x23, [sp, #0x10]
    dc44:      	ldp	x29, x30, [sp], #0x40
    dc48:      	ret
    dc4c:      	mov	x20, xzr
    dc50:      	mov	x0, x20
    dc54:      	ldp	x20, x19, [sp, #0x30]
    dc58:      	ldp	x22, x21, [sp, #0x20]
    dc5c:      	ldp	x24, x23, [sp, #0x10]
    dc60:      	ldp	x29, x30, [sp], #0x40
    dc64:      	ret

000000000000dc68 <_ZN7CGif89a12getNextFrameEv>:
    dc68:      	sub	sp, sp, #0x50
    dc6c:      	stp	x29, x30, [sp, #0x10]
    dc70:      	str	x23, [sp, #0x20]
    dc74:      	stp	x22, x21, [sp, #0x30]
    dc78:      	stp	x20, x19, [sp, #0x40]
    dc7c:      	add	x29, sp, #0x10
    dc80:      	mrs	x22, TPIDR_EL0
    dc84:      	mov	x19, x0
    dc88:      	ldr	x8, [x22, #0x28]
    dc8c:      	str	x8, [sp, #0x8]
    dc90:      	ldrb	w8, [x0, #0x1e]
    dc94:      	cbz	w8, 0xdcd0 <_ZN7CGif89a12getNextFrameEv+0x68>
    dc98:      	ldr	w8, [x19, #0x338]
    dc9c:      	ldr	w9, [x19, #0x340]
    dca0:      	mov	w10, #0x30              // =48
    dca4:      	ldr	x12, [x19, #0x330]
    dca8:      	add	w11, w8, #0x1
    dcac:      	umaddl	x20, w8, w10, x12
    dcb0:      	cmp	w11, w9
    dcb4:      	csinc	w8, wzr, w8, hs
    dcb8:      	str	w8, [x19, #0x338]
    dcbc:      	ldr	x8, [x22, #0x28]
    dcc0:      	ldr	x9, [sp, #0x8]
    dcc4:      	cmp	x8, x9
    dcc8:      	b.eq	0xdfa4 <_ZN7CGif89a12getNextFrameEv+0x33c>
    dccc:      	b	0xdfd4 <_ZN7CGif89a12getNextFrameEv+0x36c>
    dcd0:      	ldr	x0, [x19, #0x378]
    dcd4:      	cbz	x0, 0xdce0 <_ZN7CGif89a12getNextFrameEv+0x78>
    dcd8:      	bl	0x130f0 <_ZdaPv@plt>
    dcdc:      	str	xzr, [x19, #0x378]
    dce0:      	ldr	x0, [x19, #0x380]
    dce4:      	add	x20, x19, #0x368
    dce8:      	cbz	x0, 0xdcf0 <_ZN7CGif89a12getNextFrameEv+0x88>
    dcec:      	bl	0x130f0 <_ZdaPv@plt>
    dcf0:      	movi	v0.2d, #0000000000000000
    dcf4:      	add	x23, x19, #0x398
    dcf8:      	mov	w21, #0x1               // =1
    dcfc:      	stp	q0, q0, [x20, #0x10]
    dd00:      	str	q0, [x20]
    dd04:      	ldr	x3, [x19, #0x8]
    dd08:      	add	x0, sp, #0x4
    dd0c:      	mov	w1, #0x1                // =1
    dd10:      	mov	w2, #0x1                // =1
    dd14:      	bl	0x13180 <fread@plt>
    dd18:      	ldrb	w8, [sp, #0x4]
    dd1c:      	cmp	w8, #0x2b
    dd20:      	b.gt	0xdda0 <_ZN7CGif89a12getNextFrameEv+0x138>
    dd24:      	cbz	w8, 0xdd04 <_ZN7CGif89a12getNextFrameEv+0x9c>
    dd28:      	cmp	w8, #0x21
    dd2c:      	b.ne	0xdf70 <_ZN7CGif89a12getNextFrameEv+0x308>
    dd30:      	ldr	x3, [x19, #0x8]
    dd34:      	add	x0, sp, #0x4
    dd38:      	mov	w1, #0x1                // =1
    dd3c:      	mov	w2, #0x1                // =1
    dd40:      	bl	0x13180 <fread@plt>
    dd44:      	ldrb	w8, [sp, #0x4]
    dd48:      	sub	w9, w8, #0xfe
    dd4c:      	cmp	w9, #0x2
    dd50:      	b.lo	0xdd74 <_ZN7CGif89a12getNextFrameEv+0x10c>
    dd54:      	cmp	w8, #0x1
    dd58:      	b.eq	0xdd74 <_ZN7CGif89a12getNextFrameEv+0x10c>
    dd5c:      	cmp	w8, #0xf9
    dd60:      	b.eq	0xde20 <_ZN7CGif89a12getNextFrameEv+0x1b8>
    dd64:      	b	0xdf70 <_ZN7CGif89a12getNextFrameEv+0x308>
    dd68:      	ldr	x0, [x19, #0x8]
    dd6c:      	mov	w2, #0x1                // =1
    dd70:      	bl	0x131a0 <fseek@plt>
    dd74:      	ldr	x0, [x19, #0x8]
    dd78:      	bl	0x131d0 <feof@plt>
    dd7c:      	cbnz	w0, 0xdd04 <_ZN7CGif89a12getNextFrameEv+0x9c>
    dd80:      	ldr	x3, [x19, #0x8]
    dd84:      	add	x0, sp, #0x4
    dd88:      	mov	w1, #0x1                // =1
    dd8c:      	mov	w2, #0x1                // =1
    dd90:      	bl	0x13180 <fread@plt>
    dd94:      	ldrb	w1, [sp, #0x4]
    dd98:      	cbnz	x1, 0xdd68 <_ZN7CGif89a12getNextFrameEv+0x100>
    dd9c:      	b	0xdd04 <_ZN7CGif89a12getNextFrameEv+0x9c>
    dda0:      	cmp	w8, #0x3b
    dda4:      	b.ne	0xde6c <_ZN7CGif89a12getNextFrameEv+0x204>
    dda8:      	ldr	x0, [x19, #0x8]
    ddac:      	ldr	x1, [x19, #0x328]
    ddb0:      	mov	w2, wzr
    ddb4:      	bl	0x131a0 <fseek@plt>
    ddb8:      	b	0xdd04 <_ZN7CGif89a12getNextFrameEv+0x9c>
    ddbc:      	ldr	x3, [x19, #0x8]
    ddc0:      	add	x0, sp, #0x4
    ddc4:      	mov	w1, #0x1                // =1
    ddc8:      	mov	w2, #0x1                // =1
    ddcc:      	strb	w21, [x19, #0x398]
    ddd0:      	bl	0x13180 <fread@plt>
    ddd4:      	ldrb	w8, [sp, #0x4]
    ddd8:      	ldr	x3, [x19, #0x8]
    dddc:      	add	x0, x19, #0x3a2
    dde0:      	mov	w1, #0x1                // =1
    dde4:      	mov	w2, #0x2                // =2
    dde8:      	ubfx	w9, w8, #2, #3
    ddec:      	ubfx	w10, w8, #1, #1
    ddf0:      	and	w8, w8, #0x1
    ddf4:      	strb	w8, [x19, #0x3a1]
    ddf8:      	str	w9, [x19, #0x39c]
    ddfc:      	strb	w10, [x19, #0x3a0]
    de00:      	bl	0x13180 <fread@plt>
    de04:      	ldr	x3, [x19, #0x8]
    de08:      	add	x0, sp, #0x4
    de0c:      	mov	w1, #0x1                // =1
    de10:      	mov	w2, #0x1                // =1
    de14:      	bl	0x13180 <fread@plt>
    de18:      	ldrb	w8, [sp, #0x4]
    de1c:      	str	w8, [x19, #0x3a4]
    de20:      	ldr	x0, [x19, #0x8]
    de24:      	bl	0x131d0 <feof@plt>
    de28:      	cbnz	w0, 0xdd04 <_ZN7CGif89a12getNextFrameEv+0x9c>
    de2c:      	ldr	x3, [x19, #0x8]
    de30:      	add	x0, sp, #0x4
    de34:      	mov	w1, #0x1                // =1
    de38:      	mov	w2, #0x1                // =1
    de3c:      	bl	0x13180 <fread@plt>
    de40:      	ldrb	w1, [sp, #0x4]
    de44:      	cmp	w1, #0x4
    de48:      	b.eq	0xddbc <_ZN7CGif89a12getNextFrameEv+0x154>
    de4c:      	cbz	w1, 0xdd04 <_ZN7CGif89a12getNextFrameEv+0x9c>
    de50:      	ldr	x0, [x19, #0x8]
    de54:      	mov	w2, #0x1                // =1
    de58:      	bl	0x131a0 <fseek@plt>
    de5c:      	ldr	x0, [x19, #0x8]
    de60:      	bl	0x131d0 <feof@plt>
    de64:      	cbz	w0, 0xde2c <_ZN7CGif89a12getNextFrameEv+0x1c4>
    de68:      	b	0xdd04 <_ZN7CGif89a12getNextFrameEv+0x9c>
    de6c:      	cmp	w8, #0x2c
    de70:      	b.ne	0xdf70 <_ZN7CGif89a12getNextFrameEv+0x308>
    de74:      	ldr	x3, [x19, #0x8]
    de78:      	mov	x0, x20
    de7c:      	mov	w1, #0x1                // =1
    de80:      	mov	w2, #0x2                // =2
    de84:      	mov	w21, #0x1               // =1
    de88:      	bl	0x13180 <fread@plt>
    de8c:      	ldr	x3, [x19, #0x8]
    de90:      	add	x0, x19, #0x36a
    de94:      	mov	w1, #0x1                // =1
    de98:      	mov	w2, #0x2                // =2
    de9c:      	bl	0x13180 <fread@plt>
    dea0:      	ldr	x3, [x19, #0x8]
    dea4:      	add	x0, x19, #0x36c
    dea8:      	mov	w1, #0x1                // =1
    deac:      	mov	w2, #0x2                // =2
    deb0:      	bl	0x13180 <fread@plt>
    deb4:      	ldr	x3, [x19, #0x8]
    deb8:      	add	x0, x19, #0x36e
    debc:      	mov	w1, #0x1                // =1
    dec0:      	mov	w2, #0x2                // =2
    dec4:      	bl	0x13180 <fread@plt>
    dec8:      	ldr	x3, [x19, #0x8]
    decc:      	mov	x0, sp
    ded0:      	mov	w1, #0x1                // =1
    ded4:      	mov	w2, #0x1                // =1
    ded8:      	bl	0x13180 <fread@plt>
    dedc:      	ldrb	w8, [sp]
    dee0:      	tbnz	w8, #0x7, 0xdfd8 <_ZN7CGif89a12getNextFrameEv+0x370>
    dee4:      	tbnz	w8, #0x6, 0xdfe0 <_ZN7CGif89a12getNextFrameEv+0x378>
    dee8:      	tbz	w8, #0x5, 0xdef4 <_ZN7CGif89a12getNextFrameEv+0x28c>
    deec:      	mov	w9, #0x1                // =1
    def0:      	strb	w9, [x19, #0x372]
    def4:      	and	x8, x8, #0x7
    def8:      	mov	w10, #0x3               // =3
    defc:      	mov	w9, #0x1                // =1
    df00:      	add	x8, x8, #0x1
    df04:      	lsl	x21, x10, x8
    df08:      	lsl	w9, w9, w8
    df0c:      	mov	x0, x21
    df10:      	str	w9, [x19, #0x374]
    df14:      	bl	0x130e0 <_Znam@plt>
    df18:      	ldrb	w8, [x19, #0x370]
    df1c:      	str	x0, [x19, #0x378]
    df20:      	cbz	w8, 0xdff0 <_ZN7CGif89a12getNextFrameEv+0x388>
    df24:      	ldr	x3, [x19, #0x8]
    df28:      	mov	w1, #0x1                // =1
    df2c:      	mov	x2, x21
    df30:      	bl	0x13180 <fread@plt>
    df34:      	mov	x0, x19
    df38:      	mov	x1, x20
    df3c:      	bl	0x132c0 <_ZN7CGif89a11extractDataEP5FRAME@plt>
    df40:      	tbz	w0, #0x0, 0xdf70 <_ZN7CGif89a12getNextFrameEv+0x308>
    df44:      	ldr	q0, [x23]
    df48:      	ldrb	w8, [x19, #0x398]
    df4c:      	add	x9, x19, #0x388
    df50:      	str	q0, [x9]
    df54:      	cbz	w8, 0xdf94 <_ZN7CGif89a12getNextFrameEv+0x32c>
    df58:      	strb	wzr, [x23]
    df5c:      	ldr	x8, [x22, #0x28]
    df60:      	ldr	x9, [sp, #0x8]
    df64:      	cmp	x8, x9
    df68:      	b.eq	0xdfa4 <_ZN7CGif89a12getNextFrameEv+0x33c>
    df6c:      	b	0xdfd4 <_ZN7CGif89a12getNextFrameEv+0x36c>
    df70:      	ldr	x0, [x19, #0x378]
    df74:      	cbz	x0, 0xdf80 <_ZN7CGif89a12getNextFrameEv+0x318>
    df78:      	bl	0x130f0 <_ZdaPv@plt>
    df7c:      	str	xzr, [x19, #0x378]
    df80:      	ldr	x0, [x19, #0x380]
    df84:      	cbz	x0, 0xdfc0 <_ZN7CGif89a12getNextFrameEv+0x358>
    df88:      	bl	0x130f0 <_ZdaPv@plt>
    df8c:      	mov	x20, xzr
    df90:      	str	xzr, [x19, #0x380]
    df94:      	ldr	x8, [x22, #0x28]
    df98:      	ldr	x9, [sp, #0x8]
    df9c:      	cmp	x8, x9
    dfa0:      	b.ne	0xdfd4 <_ZN7CGif89a12getNextFrameEv+0x36c>
    dfa4:      	mov	x0, x20
    dfa8:      	ldp	x20, x19, [sp, #0x40]
    dfac:      	ldr	x23, [sp, #0x20]
    dfb0:      	ldp	x22, x21, [sp, #0x30]
    dfb4:      	ldp	x29, x30, [sp, #0x10]
    dfb8:      	add	sp, sp, #0x50
    dfbc:      	ret
    dfc0:      	mov	x20, xzr
    dfc4:      	ldr	x8, [x22, #0x28]
    dfc8:      	ldr	x9, [sp, #0x8]
    dfcc:      	cmp	x8, x9
    dfd0:      	b.eq	0xdfa4 <_ZN7CGif89a12getNextFrameEv+0x33c>
    dfd4:      	bl	0x12bc0 <__stack_chk_fail@plt>
    dfd8:      	strb	w21, [x19, #0x370]
    dfdc:      	tbz	w8, #0x6, 0xdee8 <_ZN7CGif89a12getNextFrameEv+0x280>
    dfe0:      	mov	w9, #0x1                // =1
    dfe4:      	strb	w9, [x19, #0x371]
    dfe8:      	tbnz	w8, #0x5, 0xdeec <_ZN7CGif89a12getNextFrameEv+0x284>
    dfec:      	b	0xdef4 <_ZN7CGif89a12getNextFrameEv+0x28c>
    dff0:      	ldr	x8, [x19, #0x330]
    dff4:      	cbz	x8, 0xdf34 <_ZN7CGif89a12getNextFrameEv+0x2cc>
    dff8:      	ldr	x1, [x8, #0x10]
    dffc:      	cbz	x1, 0xdf34 <_ZN7CGif89a12getNextFrameEv+0x2cc>
    e000:      	mov	x2, x21
    e004:      	bl	0x12e70 <memcpy@plt>
    e008:      	b	0xdf34 <_ZN7CGif89a12getNextFrameEv+0x2cc>

000000000000e00c <_ZN7CGif89a12initStrTableEP18STRING_TABLE_ENTRYj>:
    e00c:      	cbz	w2, 0xe060 <_ZN7CGif89a12initStrTableEP18STRING_TABLE_ENTRYj+0x54>
    e010:      	stp	x29, x30, [sp, #-0x30]!
    e014:      	stp	x22, x21, [sp, #0x10]
    e018:      	stp	x20, x19, [sp, #0x20]
    e01c:      	mov	x29, sp
    e020:      	mov	x19, xzr
    e024:      	mov	w20, w2
    e028:      	add	x21, x1, #0x8
    e02c:      	mov	w22, #0x1               // =1
    e030:      	mov	w0, #0x2                // =2
    e034:      	bl	0x130e0 <_Znam@plt>
    e038:      	strb	w19, [x0]
    e03c:      	add	x19, x19, #0x1
    e040:      	cmp	x20, x19
    e044:      	stur	w22, [x21, #-0x8]
    e048:      	str	x0, [x21], #0x10
    e04c:      	strb	wzr, [x0, #0x1]
    e050:      	b.ne	0xe030 <_ZN7CGif89a12initStrTableEP18STRING_TABLE_ENTRYj+0x24>
    e054:      	ldp	x20, x19, [sp, #0x20]
    e058:      	ldp	x22, x21, [sp, #0x10]
    e05c:      	ldp	x29, x30, [sp], #0x30
    e060:      	mov	w0, #0x1                // =1
    e064:      	ret

000000000000e068 <_ZN7CGif89a11addStrTableEP18STRING_TABLE_ENTRYjjh>:
    e068:      	stp	x29, x30, [sp, #-0x40]!
    e06c:      	str	x23, [sp, #0x10]
    e070:      	stp	x22, x21, [sp, #0x20]
    e074:      	stp	x20, x19, [sp, #0x30]
    e078:      	mov	x29, sp
    e07c:      	mov	w19, w2
    e080:      	cmp	w2, #0xfff
    e084:      	b.hi	0xe188 <_ZN7CGif89a11addStrTableEP18STRING_TABLE_ENTRYjjh+0x120>
    e088:      	mov	w22, w3
    e08c:      	mov	w20, w4
    e090:      	mov	x21, x1
    e094:      	ubfiz	x8, x22, #4, #32
    e098:      	ldr	w23, [x1, x8]
    e09c:      	add	w0, w23, #0x2
    e0a0:      	bl	0x130e0 <_Znam@plt>
    e0a4:      	cbz	w23, 0xe0dc <_ZN7CGif89a11addStrTableEP18STRING_TABLE_ENTRYjjh+0x74>
    e0a8:      	mov	w8, w22
    e0ac:      	cmp	w23, #0x8
    e0b0:      	mov	x9, xzr
    e0b4:      	add	x8, x21, x8, lsl #4
    e0b8:      	ldr	x8, [x8, #0x8]
    e0bc:      	b.lo	0xe150 <_ZN7CGif89a11addStrTableEP18STRING_TABLE_ENTRYjjh+0xe8>
    e0c0:      	sub	x10, x0, x8
    e0c4:      	cmp	x10, #0x20
    e0c8:      	b.lo	0xe150 <_ZN7CGif89a11addStrTableEP18STRING_TABLE_ENTRYjjh+0xe8>
    e0cc:      	cmp	w23, #0x20
    e0d0:      	b.hs	0xe0e4 <_ZN7CGif89a11addStrTableEP18STRING_TABLE_ENTRYjjh+0x7c>
    e0d4:      	mov	x9, xzr
    e0d8:      	b	0xe120 <_ZN7CGif89a11addStrTableEP18STRING_TABLE_ENTRYjjh+0xb8>
    e0dc:      	mov	x10, xzr
    e0e0:      	b	0xe170 <_ZN7CGif89a11addStrTableEP18STRING_TABLE_ENTRYjjh+0x108>
    e0e4:      	and	x9, x23, #0xffffffe0
    e0e8:      	add	x10, x8, #0x10
    e0ec:      	add	x11, x0, #0x10
    e0f0:      	mov	x12, x9
    e0f4:      	ldp	q0, q1, [x10, #-0x10]
    e0f8:      	subs	x12, x12, #0x20
    e0fc:      	add	x10, x10, #0x20
    e100:      	stp	q0, q1, [x11, #-0x10]
    e104:      	add	x11, x11, #0x20
    e108:      	b.ne	0xe0f4 <_ZN7CGif89a11addStrTableEP18STRING_TABLE_ENTRYjjh+0x8c>
    e10c:      	cmp	x9, x23
    e110:      	mov	x10, x23
    e114:      	b.eq	0xe170 <_ZN7CGif89a11addStrTableEP18STRING_TABLE_ENTRYjjh+0x108>
    e118:      	tst	x23, #0x18
    e11c:      	b.eq	0xe150 <_ZN7CGif89a11addStrTableEP18STRING_TABLE_ENTRYjjh+0xe8>
    e120:      	mov	x12, x9
    e124:      	and	x9, x23, #0xfffffff8
    e128:      	add	x10, x8, x12
    e12c:      	add	x11, x0, x12
    e130:      	sub	x12, x12, x9
    e134:      	ldr	d0, [x10], #0x8
    e138:      	adds	x12, x12, #0x8
    e13c:      	str	d0, [x11], #0x8
    e140:      	b.ne	0xe134 <_ZN7CGif89a11addStrTableEP18STRING_TABLE_ENTRYjjh+0xcc>
    e144:      	cmp	x9, x23
    e148:      	mov	x10, x23
    e14c:      	b.eq	0xe170 <_ZN7CGif89a11addStrTableEP18STRING_TABLE_ENTRYjjh+0x108>
    e150:      	add	x8, x8, x9
    e154:      	add	x10, x0, x9
    e158:      	sub	x9, x23, x9
    e15c:      	ldrb	w11, [x8], #0x1
    e160:      	subs	x9, x9, #0x1
    e164:      	strb	w11, [x10], #0x1
    e168:      	b.ne	0xe15c <_ZN7CGif89a11addStrTableEP18STRING_TABLE_ENTRYjjh+0xf4>
    e16c:      	mov	x10, x23
    e170:      	add	x9, x21, w19, uxtw #4
    e174:      	add	w8, w23, #0x1
    e178:      	strb	w20, [x0, x10]
    e17c:      	strb	wzr, [x0, w8, uxtw]
    e180:      	str	x0, [x9, #0x8]
    e184:      	str	w8, [x9]
    e188:      	cmp	w19, #0x1, lsl #12      // =0x1000
    e18c:      	cset	w0, lo
    e190:      	ldp	x20, x19, [sp, #0x30]
    e194:      	ldr	x23, [sp, #0x10]
    e198:      	ldp	x22, x21, [sp, #0x20]
    e19c:      	ldp	x29, x30, [sp], #0x40
    e1a0:      	ret

000000000000e1a4 <_ZN7CGif89a13getGlobalInfoEv>:
    e1a4:      	add	x0, x0, #0x340
    e1a8:      	ret

000000000000e1ac <_ZN7CGif89a6getVerEv>:
    e1ac:      	add	x0, x0, #0x18
    e1b0:      	ret

000000000000e1b4 <_ZN7CGif89a8getWidthEv>:
    e1b4:      	ldrh	w0, [x0, #0x344]
    e1b8:      	ret

000000000000e1bc <_ZN7CGif89a9getHeightEv>:
    e1bc:      	ldrh	w0, [x0, #0x346]
    e1c0:      	ret

000000000000e1c4 <_ZN7CGif89a11getFrameNumEv>:
    e1c4:      	ldr	w0, [x0, #0x340]
    e1c8:      	ret

000000000000e1cc <_ZN7CGif89a8getDelayEi>:
    e1cc:      	mov	x8, x0
    e1d0:      	mov	w0, wzr
    e1d4:      	tbnz	w1, #0x1f, 0xe200 <_ZN7CGif89a8getDelayEi+0x34>
    e1d8:      	ldr	w9, [x8, #0x340]
    e1dc:      	cmp	w9, w1
    e1e0:      	b.ls	0xe200 <_ZN7CGif89a8getDelayEi+0x34>
    e1e4:      	ldr	x8, [x8, #0x330]
    e1e8:      	cbz	x8, 0xe1fc <_ZN7CGif89a8getDelayEi+0x30>
    e1ec:      	mov	w9, #0x30               // =48
    e1f0:      	umaddl	x8, w1, w9, x8
    e1f4:      	ldrh	w0, [x8, #0x2a]
    e1f8:      	ret
    e1fc:      	mov	w0, wzr
    e200:      	ret

000000000000e204 <JNI_OnLoad>:
    e204:      	sub	sp, sp, #0x40
    e208:      	stp	x29, x30, [sp, #0x10]
    e20c:      	str	x21, [sp, #0x20]
    e210:      	stp	x20, x19, [sp, #0x30]
    e214:      	add	x29, sp, #0x10
    e218:      	mrs	x21, TPIDR_EL0
    e21c:      	mov	w2, #0x6                // =6
    e220:      	mov	w19, #0x6               // =6
    e224:      	ldr	x8, [x21, #0x28]
    e228:      	mov	x1, sp
    e22c:      	movk	w2, #0x1, lsl #16
    e230:      	movk	w19, #0x1, lsl #16
    e234:      	str	x8, [sp, #0x8]
    e238:      	ldr	x8, [x0]
    e23c:      	str	xzr, [sp]
    e240:      	ldr	x8, [x8, #0x30]
    e244:      	blr	x8
    e248:      	cbz	w0, 0xe278 <JNI_OnLoad+0x74>
    e24c:      	mov	w19, #-0x1              // =-1
    e250:      	ldr	x8, [x21, #0x28]
    e254:      	ldr	x9, [sp, #0x8]
    e258:      	cmp	x8, x9
    e25c:      	b.ne	0xe2c4 <JNI_OnLoad+0xc0>
    e260:      	mov	w0, w19
    e264:      	ldp	x20, x19, [sp, #0x30]
    e268:      	ldr	x21, [sp, #0x20]
    e26c:      	ldp	x29, x30, [sp, #0x10]
    e270:      	add	sp, sp, #0x40
    e274:      	ret
    e278:      	ldr	x20, [sp]
    e27c:      	cbz	x20, 0xe24c <JNI_OnLoad+0x48>
    e280:      	ldr	x8, [x20]
    e284:      	nop
    e288:      	adr	x1, 0x606b
    e28c:      	mov	x0, x20
    e290:      	ldr	x8, [x8, #0x30]
    e294:      	blr	x8
    e298:      	cbz	x0, 0xe24c <JNI_OnLoad+0x48>
    e29c:      	ldr	x8, [x20]
    e2a0:      	mov	x1, x0
    e2a4:      	nop
    e2a8:      	adr	x2, 0x1bce8 <_ZN13FormatConvert18VideoFormatTranser18MaxFrameBufferSizeE+0xc>
    e2ac:      	mov	x0, x20
    e2b0:      	mov	w3, #0x1                // =1
    e2b4:      	ldr	x8, [x8, #0x6b8]
    e2b8:      	blr	x8
    e2bc:      	tbz	w0, #0x1f, 0xe250 <JNI_OnLoad+0x4c>
    e2c0:      	b	0xe24c <JNI_OnLoad+0x48>
    e2c4:      	bl	0x12bc0 <__stack_chk_fail@plt>

000000000000e2c8 <_Z18registerJNIMethodsP7_JNIEnvPv>:
    e2c8:      	stp	x29, x30, [sp, #-0x20]!
    e2cc:      	str	x19, [sp, #0x10]
    e2d0:      	mov	x29, sp
    e2d4:      	ldr	x8, [x0]
    e2d8:      	nop
    e2dc:      	adr	x1, 0x606b
    e2e0:      	mov	x19, x0
    e2e4:      	ldr	x8, [x8, #0x30]
    e2e8:      	blr	x8
    e2ec:      	cbz	x0, 0xe320 <_Z18registerJNIMethodsP7_JNIEnvPv+0x58>
    e2f0:      	ldr	x8, [x19]
    e2f4:      	mov	x1, x0
    e2f8:      	nop
    e2fc:      	adr	x2, 0x1bce8 <_ZN13FormatConvert18VideoFormatTranser18MaxFrameBufferSizeE+0xc>
    e300:      	mov	x0, x19
    e304:      	mov	w3, #0x1                // =1
    e308:      	ldr	x8, [x8, #0x6b8]
    e30c:      	blr	x8
    e310:      	asr	w0, w0, #31
    e314:      	ldr	x19, [sp, #0x10]
    e318:      	ldp	x29, x30, [sp], #0x20
    e31c:      	ret
    e320:      	mov	w0, #-0x1               // =-1
    e324:      	ldr	x19, [sp, #0x10]
    e328:      	ldp	x29, x30, [sp], #0x20
    e32c:      	ret

000000000000e330 <JNI_OnUnload>:
    e330:      	sub	sp, sp, #0x30
    e334:      	stp	x29, x30, [sp, #0x10]
    e338:      	str	x19, [sp, #0x20]
    e33c:      	add	x29, sp, #0x10
    e340:      	mrs	x19, TPIDR_EL0
    e344:      	mov	w2, #0x6                // =6
    e348:      	mov	x1, sp
    e34c:      	ldr	x8, [x19, #0x28]
    e350:      	movk	w2, #0x1, lsl #16
    e354:      	str	x8, [sp, #0x8]
    e358:      	ldr	x8, [x0]
    e35c:      	str	xzr, [sp]
    e360:      	ldr	x8, [x8, #0x30]
    e364:      	blr	x8
    e368:      	ldr	x8, [x19, #0x28]
    e36c:      	ldr	x9, [sp, #0x8]
    e370:      	cmp	x8, x9
    e374:      	b.ne	0xe388 <JNI_OnUnload+0x58>
    e378:      	ldp	x29, x30, [sp, #0x10]
    e37c:      	ldr	x19, [sp, #0x20]
    e380:      	add	sp, sp, #0x30
    e384:      	ret
    e388:      	bl	0x12bc0 <__stack_chk_fail@plt>

000000000000e38c <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif>:
    e38c:      	sub	sp, sp, #0xc0
    e390:      	str	d8, [sp, #0x50]
    e394:      	stp	x29, x30, [sp, #0x60]
    e398:      	stp	x28, x27, [sp, #0x70]
    e39c:      	stp	x26, x25, [sp, #0x80]
    e3a0:      	stp	x24, x23, [sp, #0x90]
    e3a4:      	stp	x22, x21, [sp, #0xa0]
    e3a8:      	stp	x20, x19, [sp, #0xb0]
    e3ac:      	add	x29, sp, #0x60
    e3b0:      	str	w4, [sp, #0xc]
    e3b4:      	mrs	x25, TPIDR_EL0
    e3b8:      	mov	x21, x2
    e3bc:      	ldr	x8, [x25, #0x28]
    e3c0:      	mov	x1, x2
    e3c4:      	mov	x2, xzr
    e3c8:      	fmov	s8, s0
    e3cc:      	mov	w26, w6
    e3d0:      	mov	w27, w5
    e3d4:      	stur	x8, [x29, #-0x18]
    e3d8:      	mov	x19, x0
    e3dc:      	mov	x20, x3
    e3e0:      	ldr	x8, [x0]
    e3e4:      	ldr	x8, [x8, #0x548]
    e3e8:      	blr	x8
    e3ec:      	ldr	x8, [x19]
    e3f0:      	mov	x23, x0
    e3f4:      	mov	x0, x19
    e3f8:      	mov	x1, x20
    e3fc:      	mov	x2, xzr
    e400:      	ldr	x8, [x8, #0x548]
    e404:      	blr	x8
    e408:      	mov	x22, x0
    e40c:      	mov	w0, #0x58               // =88
    e410:      	bl	0x12b60 <_Znwm@plt>
    e414:      	mov	x24, x0
    e418:      	str	x25, [sp, #0x10]
    e41c:      	bl	0x132e0 <_ZN5mtgif9Video2GifC1Ev@plt>
    e420:      	mov	x0, x23
    e424:      	bl	0x12dc0 <strlen@plt>
    e428:      	cmn	x0, #0x10
    e42c:      	b.hs	0xe660 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x2d4>
    e430:      	mov	x28, x0
    e434:      	cmp	x0, #0x17
    e438:      	b.hs	0xe454 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0xc8>
    e43c:      	lsl	w8, w28, #1
    e440:      	add	x9, sp, #0x30
    e444:      	orr	x25, x9, #0x1
    e448:      	strb	w8, [sp, #0x30]
    e44c:      	cbnz	x28, 0xe4a8 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x11c>
    e450:      	b	0xe4b8 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x12c>
    e454:      	str	x24, [sp]
    e458:      	mov	x24, x23
    e45c:      	mov	x23, x22
    e460:      	mov	x22, x21
    e464:      	mov	x21, x20
    e468:      	mov	w20, w27
    e46c:      	mov	w27, w26
    e470:      	orr	x26, x28, #0xf
    e474:      	add	x0, x26, #0x1
    e478:      	bl	0x12b60 <_Znwm@plt>
    e47c:      	add	x8, x26, #0x2
    e480:      	mov	w26, w27
    e484:      	mov	w27, w20
    e488:      	mov	x20, x21
    e48c:      	mov	x21, x22
    e490:      	mov	x22, x23
    e494:      	mov	x23, x24
    e498:      	ldr	x24, [sp]
    e49c:      	mov	x25, x0
    e4a0:      	stp	x28, x0, [sp, #0x38]
    e4a4:      	str	x8, [sp, #0x30]
    e4a8:      	mov	x0, x25
    e4ac:      	mov	x1, x23
    e4b0:      	mov	x2, x28
    e4b4:      	bl	0x132f0 <memmove@plt>
    e4b8:      	mov	x0, x22
    e4bc:      	strb	wzr, [x25, x28]
    e4c0:      	bl	0x12dc0 <strlen@plt>
    e4c4:      	cmn	x0, #0x10
    e4c8:      	b.hs	0xe678 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x2ec>
    e4cc:      	mov	x28, x0
    e4d0:      	cmp	x0, #0x17
    e4d4:      	b.hs	0xe4f0 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x164>
    e4d8:      	lsl	w8, w28, #1
    e4dc:      	add	x9, sp, #0x18
    e4e0:      	orr	x25, x9, #0x1
    e4e4:      	strb	w8, [sp, #0x18]
    e4e8:      	cbnz	x28, 0xe540 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x1b4>
    e4ec:      	b	0xe550 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x1c4>
    e4f0:      	orr	x8, x28, #0xf
    e4f4:      	str	x23, [sp]
    e4f8:      	mov	x23, x22
    e4fc:      	mov	x22, x21
    e500:      	mov	x21, x20
    e504:      	mov	w20, w27
    e508:      	mov	w27, w26
    e50c:      	add	x26, x8, #0x1
    e510:      	mov	x0, x26
    e514:      	bl	0x12b60 <_Znwm@plt>
    e518:      	orr	x8, x26, #0x1
    e51c:      	mov	w26, w27
    e520:      	mov	w27, w20
    e524:      	mov	x20, x21
    e528:      	mov	x21, x22
    e52c:      	mov	x22, x23
    e530:      	ldr	x23, [sp]
    e534:      	mov	x25, x0
    e538:      	stp	x28, x0, [sp, #0x20]
    e53c:      	str	x8, [sp, #0x18]
    e540:      	mov	x0, x25
    e544:      	mov	x1, x22
    e548:      	mov	x2, x28
    e54c:      	bl	0x132f0 <memmove@plt>
    e550:      	strb	wzr, [x25, x28]
    e554:      	fmov	s0, s8
    e558:      	ldr	w3, [sp, #0xc]
    e55c:      	add	x1, sp, #0x30
    e560:      	add	x2, sp, #0x18
    e564:      	mov	x0, x24
    e568:      	mov	w4, w27
    e56c:      	mov	w5, w26
    e570:      	bl	0x13300 <_ZN5mtgif9Video2Gif4initENSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES7_iiif@plt>
    e574:      	ldrb	w8, [sp, #0x18]
    e578:      	mov	w25, w0
    e57c:      	tbnz	w8, #0x0, 0xe5a0 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x214>
    e580:      	ldrb	w8, [sp, #0x30]
    e584:      	tbnz	w8, #0x0, 0xe5b0 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x224>
    e588:      	tbz	w25, #0x0, 0xe5bc <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x230>
    e58c:      	mov	x0, x24
    e590:      	bl	0x13310 <_ZN5mtgif9Video2Gif3runEv@plt>
    e594:      	tbz	w0, #0x0, 0xe5c8 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x23c>
    e598:      	mov	w25, #0x1               // =1
    e59c:      	b	0xe5e4 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x258>
    e5a0:      	ldr	x0, [sp, #0x28]
    e5a4:      	bl	0x12c80 <_ZdlPv@plt>
    e5a8:      	ldrb	w8, [sp, #0x30]
    e5ac:      	tbz	w8, #0x0, 0xe588 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x1fc>
    e5b0:      	ldr	x0, [sp, #0x40]
    e5b4:      	bl	0x12c80 <_ZdlPv@plt>
    e5b8:      	tbnz	w25, #0x0, 0xe58c <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x200>
    e5bc:      	adrp	x2, 0x5000
    e5c0:      	add	x2, x2, #0xeb5
    e5c4:      	b	0xe5d0 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x244>
    e5c8:      	adrp	x2, 0x5000
    e5cc:      	add	x2, x2, #0x884
    e5d0:      	adrp	x1, 0x5000
    e5d4:      	add	x1, x1, #0xa3b
    e5d8:      	mov	w0, #0x6                // =6
    e5dc:      	bl	0x13320 <__android_log_print@plt>
    e5e0:      	mov	w25, wzr
    e5e4:      	mov	x0, x24
    e5e8:      	bl	0x13330 <_ZN5mtgif9Video2GifD1Ev@plt>
    e5ec:      	mov	x0, x24
    e5f0:      	bl	0x12c80 <_ZdlPv@plt>
    e5f4:      	ldr	x8, [x19]
    e5f8:      	mov	x0, x19
    e5fc:      	mov	x1, x21
    e600:      	mov	x2, x23
    e604:      	ldr	x8, [x8, #0x550]
    e608:      	blr	x8
    e60c:      	ldr	x8, [x19]
    e610:      	mov	x0, x19
    e614:      	mov	x1, x20
    e618:      	mov	x2, x22
    e61c:      	ldr	x8, [x8, #0x550]
    e620:      	blr	x8
    e624:      	ldr	x8, [sp, #0x10]
    e628:      	ldr	x8, [x8, #0x28]
    e62c:      	ldur	x9, [x29, #-0x18]
    e630:      	cmp	x8, x9
    e634:      	b.ne	0xe70c <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x380>
    e638:      	mov	w0, w25
    e63c:      	ldp	x20, x19, [sp, #0xb0]
    e640:      	ldr	d8, [sp, #0x50]
    e644:      	ldp	x22, x21, [sp, #0xa0]
    e648:      	ldp	x24, x23, [sp, #0x90]
    e64c:      	ldp	x26, x25, [sp, #0x80]
    e650:      	ldp	x28, x27, [sp, #0x70]
    e654:      	ldp	x29, x30, [sp, #0x60]
    e658:      	add	sp, sp, #0xc0
    e65c:      	ret
    e660:      	ldr	x8, [x25, #0x28]
    e664:      	ldur	x9, [x29, #-0x18]
    e668:      	cmp	x8, x9
    e66c:      	b.ne	0xe70c <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x380>
    e670:      	add	x0, sp, #0x30
    e674:      	bl	0xe710 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x384>
    e678:      	ldr	x8, [sp, #0x10]
    e67c:      	ldr	x8, [x8, #0x28]
    e680:      	ldur	x9, [x29, #-0x18]
    e684:      	cmp	x8, x9
    e688:      	b.ne	0xe70c <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x380>
    e68c:      	add	x0, sp, #0x18
    e690:      	bl	0xe710 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x384>
    e694:      	ldrb	w8, [sp, #0x18]
    e698:      	mov	x19, x0
    e69c:      	tbnz	w8, #0x0, 0xe6c4 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x338>
    e6a0:      	ldrb	w8, [sp, #0x30]
    e6a4:      	tbnz	w8, #0x0, 0xe6f0 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x364>
    e6a8:      	ldr	x8, [sp, #0x10]
    e6ac:      	ldr	x8, [x8, #0x28]
    e6b0:      	ldur	x9, [x29, #-0x18]
    e6b4:      	cmp	x8, x9
    e6b8:      	b.ne	0xe70c <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x380>
    e6bc:      	mov	x0, x19
    e6c0:      	bl	0xeda0 <_ZN5mtgif9Video2Gif3runEv+0x3c8>
    e6c4:      	ldr	x0, [sp, #0x28]
    e6c8:      	bl	0x12c80 <_ZdlPv@plt>
    e6cc:      	ldrb	w8, [sp, #0x30]
    e6d0:      	tbz	w8, #0x0, 0xe6a8 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x31c>
    e6d4:      	b	0xe6f0 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x364>
    e6d8:      	mov	x19, x0
    e6dc:      	mov	x0, x24
    e6e0:      	b	0xe6f4 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x368>
    e6e4:      	mov	x19, x0
    e6e8:      	ldrb	w8, [sp, #0x30]
    e6ec:      	tbz	w8, #0x0, 0xe6a8 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x31c>
    e6f0:      	ldr	x0, [sp, #0x40]
    e6f4:      	bl	0x12c80 <_ZdlPv@plt>
    e6f8:      	ldr	x8, [sp, #0x10]
    e6fc:      	ldr	x8, [x8, #0x28]
    e700:      	ldur	x9, [x29, #-0x18]
    e704:      	cmp	x8, x9
    e708:      	b.eq	0xe6bc <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x330>
    e70c:      	bl	0x12bc0 <__stack_chk_fail@plt>
    e710:      	stp	x29, x30, [sp, #-0x10]!
    e714:      	mov	x29, sp
    e718:      	adrp	x0, 0x5000
    e71c:      	add	x0, x0, #0xecd
    e720:      	bl	0xe724 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x398>
    e724:      	stp	x29, x30, [sp, #-0x20]!
    e728:      	stp	x20, x19, [sp, #0x10]
    e72c:      	mov	x29, sp
    e730:      	mov	x20, x0
    e734:      	mov	w0, #0x10               // =16
    e738:      	bl	0x13340 <__cxa_allocate_exception@plt>
    e73c:      	mov	x19, x0
    e740:      	mov	x1, x20
    e744:      	bl	0xe774 <_ZN8MTGifJNI22nativeconvertVideo2GifEP7_JNIEnvP8_jobjectP8_jstringS5_iiif+0x3e8>
    e748:      	adrp	x1, 0x17000 <syscall@plt+0x3bf0>
    e74c:      	adrp	x2, 0x17000 <syscall@plt+0x3bf0>
    e750:      	mov	x0, x19
    e754:      	ldr	x1, [x1, #0x7d0]
    e758:      	ldr	x2, [x2, #0x7d8]
    e75c:      	bl	0x13350 <__cxa_throw@plt>
    e760:      	mov	x20, x0
    e764:      	mov	x0, x19
    e768:      	bl	0x13360 <__cxa_free_exception@plt>
    e76c:      	mov	x0, x20
    e770:      	bl	0xeda0 <_ZN5mtgif9Video2Gif3runEv+0x3c8>
    e774:      	stp	x29, x30, [sp, #-0x20]!
    e778:      	str	x19, [sp, #0x10]
    e77c:      	mov	x29, sp
    e780:      	mov	x19, x0
    e784:      	bl	0x13370 <_ZNSt11logic_errorC2EPKc@plt>
    e788:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
    e78c:      	ldr	x8, [x8, #0x7e0]
    e790:      	add	x8, x8, #0x10
    e794:      	str	x8, [x19]
    e798:      	ldr	x19, [sp, #0x10]
    e79c:      	ldp	x29, x30, [sp], #0x20
    e7a0:      	ret

000000000000e7a4 <_ZN5mtgif9Video2GifC2Ev>:
    e7a4:      	stp	x29, x30, [sp, #-0x30]!
    e7a8:      	str	x21, [sp, #0x10]
    e7ac:      	stp	x20, x19, [sp, #0x20]
    e7b0:      	mov	x29, sp
    e7b4:      	movi	v0.2d, #0000000000000000
    e7b8:      	mov	x19, x0
    e7bc:      	mov	x20, x0
    e7c0:      	str	q0, [x20, #0x10]!
    e7c4:      	stp	q0, q0, [x20, #0x10]
    e7c8:      	mov	w0, #0x128              // =296
    e7cc:      	bl	0x12b60 <_Znwm@plt>
    e7d0:      	mov	x21, x0
    e7d4:      	bl	0x12fb0 <_ZN13FormatConvert18VideoFormatTranserC1Ev@plt>
    e7d8:      	str	x21, [x19]
    e7dc:      	mov	w0, #0x8                // =8
    e7e0:      	bl	0x12b60 <_Znwm@plt>
    e7e4:      	mov	x21, x0
    e7e8:      	bl	0x13050 <_ZN5MTGifC1Ev@plt>
    e7ec:      	str	x21, [x19, #0x8]
    e7f0:      	nop
    e7f4:      	adr	x1, 0x5825
    e7f8:      	mov	x0, x20
    e7fc:      	bl	0x13380 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6assignEPKc@plt>
    e800:      	nop
    e804:      	adr	x1, 0x5825
    e808:      	add	x0, x20, #0x18
    e80c:      	bl	0x13380 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6assignEPKc@plt>
    e810:      	mov	x8, #0x3                // =3
    e814:      	movk	x8, #0x3f80, lsl #48
    e818:      	stp	xzr, x8, [x19, #0x40]
    e81c:      	str	wzr, [x19, #0x50]
    e820:      	ldp	x20, x19, [sp, #0x20]
    e824:      	ldr	x21, [sp, #0x10]
    e828:      	ldp	x29, x30, [sp], #0x30
    e82c:      	ret
    e830:      	b	0xe834 <_ZN5mtgif9Video2GifC2Ev+0x90>
    e834:      	mov	x8, x21
    e838:      	mov	x21, x0
    e83c:      	mov	x0, x8
    e840:      	bl	0x12c80 <_ZdlPv@plt>
    e844:      	b	0xe84c <_ZN5mtgif9Video2GifC2Ev+0xa8>
    e848:      	mov	x21, x0
    e84c:      	ldurb	w8, [x20, #0x18]
    e850:      	tbnz	w8, #0x0, 0xe864 <_ZN5mtgif9Video2GifC2Ev+0xc0>
    e854:      	ldrb	w8, [x20]
    e858:      	tbnz	w8, #0x0, 0xe874 <_ZN5mtgif9Video2GifC2Ev+0xd0>
    e85c:      	mov	x0, x21
    e860:      	bl	0xeda0 <_ZN5mtgif9Video2Gif3runEv+0x3c8>
    e864:      	ldr	x0, [x19, #0x38]
    e868:      	bl	0x12c80 <_ZdlPv@plt>
    e86c:      	ldrb	w8, [x20]
    e870:      	tbz	w8, #0x0, 0xe85c <_ZN5mtgif9Video2GifC2Ev+0xb8>
    e874:      	ldr	x0, [x19, #0x20]
    e878:      	bl	0x12c80 <_ZdlPv@plt>
    e87c:      	mov	x0, x21
    e880:      	bl	0xeda0 <_ZN5mtgif9Video2Gif3runEv+0x3c8>

000000000000e884 <_ZN5mtgif9Video2GifD2Ev>:
    e884:      	stp	x29, x30, [sp, #-0x20]!
    e888:      	stp	x20, x19, [sp, #0x10]
    e88c:      	mov	x29, sp
    e890:      	ldr	x20, [x0]
    e894:      	mov	x19, x0
    e898:      	cbz	x20, 0xe8ac <_ZN5mtgif9Video2GifD2Ev+0x28>
    e89c:      	mov	x0, x20
    e8a0:      	bl	0x12fc0 <_ZN13FormatConvert18VideoFormatTranserD1Ev@plt>
    e8a4:      	mov	x0, x20
    e8a8:      	bl	0x12c80 <_ZdlPv@plt>
    e8ac:      	ldr	x20, [x19, #0x8]
    e8b0:      	str	xzr, [x19]
    e8b4:      	cbz	x20, 0xe8c8 <_ZN5mtgif9Video2GifD2Ev+0x44>
    e8b8:      	mov	x0, x20
    e8bc:      	bl	0x13060 <_ZN5MTGifD1Ev@plt>
    e8c0:      	mov	x0, x20
    e8c4:      	bl	0x12c80 <_ZdlPv@plt>
    e8c8:      	ldrb	w8, [x19, #0x28]
    e8cc:      	str	xzr, [x19, #0x8]
    e8d0:      	tbz	w8, #0x0, 0xe8dc <_ZN5mtgif9Video2GifD2Ev+0x58>
    e8d4:      	ldr	x0, [x19, #0x38]
    e8d8:      	bl	0x12c80 <_ZdlPv@plt>
    e8dc:      	ldrb	w8, [x19, #0x10]
    e8e0:      	tbnz	w8, #0x0, 0xe8f0 <_ZN5mtgif9Video2GifD2Ev+0x6c>
    e8e4:      	ldp	x20, x19, [sp, #0x10]
    e8e8:      	ldp	x29, x30, [sp], #0x20
    e8ec:      	ret
    e8f0:      	ldr	x0, [x19, #0x20]
    e8f4:      	ldp	x20, x19, [sp, #0x10]
    e8f8:      	ldp	x29, x30, [sp], #0x20
    e8fc:      	b	0x12c80 <_ZdlPv@plt>

000000000000e900 <_ZN5mtgif9Video2Gif4initENSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES7_iiif>:
    e900:      	str	d8, [sp, #-0x40]!
    e904:      	stp	x29, x30, [sp, #0x8]
    e908:      	str	x23, [sp, #0x18]
    e90c:      	stp	x22, x21, [sp, #0x20]
    e910:      	stp	x20, x19, [sp, #0x30]
    e914:      	add	x29, sp, #0x8
    e918:      	mov	x23, x0
    e91c:      	add	x0, x0, #0x10
    e920:      	fmov	s8, s0
    e924:      	mov	w19, w5
    e928:      	mov	w20, w4
    e92c:      	mov	w21, w3
    e930:      	mov	x22, x2
    e934:      	bl	0x13390 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_@plt>
    e938:      	add	x0, x23, #0x28
    e93c:      	mov	x1, x22
    e940:      	bl	0x13390 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_@plt>
    e944:      	fmov	s0, #1.00000000
    e948:      	ldrb	w8, [x23, #0x10]
    e94c:      	ldr	x9, [x23, #0x20]
    e950:      	ldr	x0, [x23]
    e954:      	add	x10, x23, #0x11
    e958:      	stp	w21, w20, [x23, #0x40]
    e95c:      	tst	w8, #0x1
    e960:      	str	w19, [x23, #0x48]
    e964:      	fdiv	s0, s0, s8
    e968:      	csel	x1, x10, x9, eq
    e96c:      	str	s0, [x23, #0x4c]
    e970:      	bl	0x12f70 <_ZN13FormatConvert18VideoFormatTranser22setInputVideoMediaFileEPc@plt>
    e974:      	ldp	w1, w2, [x23, #0x40]
    e978:      	ldr	x0, [x23]
    e97c:      	bl	0x12fa0 <_ZN13FormatConvert18VideoFormatTranser18setVideoOutputSizeEii@plt>
    e980:      	ldr	x0, [x23]
    e984:      	mov	w1, #0x7                // =7
    e988:      	bl	0x12f90 <_ZN13FormatConvert18VideoFormatTranser23setVideoOutputPixFormatENS_16IMAGE_PIX_FORMATE@plt>
    e98c:      	ldr	x0, [x23]
    e990:      	bl	0x12c90 <_ZN13FormatConvert18VideoFormatTranser7prepareEv@plt>
    e994:      	mov	w19, w0
    e998:      	cmn	w0, #0x1
    e99c:      	b.ne	0xe9b8 <_ZN5mtgif9Video2Gif4initENSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES7_iiif+0xb8>
    e9a0:      	adrp	x1, 0x5000
    e9a4:      	add	x1, x1, #0xa3b
    e9a8:      	adrp	x2, 0x5000
    e9ac:      	add	x2, x2, #0x99f
    e9b0:      	mov	w0, #0x6                // =6
    e9b4:      	bl	0x13320 <__android_log_print@plt>
    e9b8:      	cmn	w19, #0x1
    e9bc:      	cset	w0, ne
    e9c0:      	ldp	x20, x19, [sp, #0x30]
    e9c4:      	ldr	x23, [sp, #0x18]
    e9c8:      	ldp	x22, x21, [sp, #0x20]
    e9cc:      	ldp	x29, x30, [sp, #0x8]
    e9d0:      	ldr	d8, [sp], #0x40
    e9d4:      	ret

000000000000e9d8 <_ZN5mtgif9Video2Gif3runEv>:
    e9d8:      	sub	sp, sp, #0x90
    e9dc:      	str	d8, [sp, #0x20]
    e9e0:      	stp	x29, x30, [sp, #0x30]
    e9e4:      	stp	x28, x27, [sp, #0x40]
    e9e8:      	stp	x26, x25, [sp, #0x50]
    e9ec:      	stp	x24, x23, [sp, #0x60]
    e9f0:      	stp	x22, x21, [sp, #0x70]
    e9f4:      	stp	x20, x19, [sp, #0x80]
    e9f8:      	add	x29, sp, #0x30
    e9fc:      	mrs	x25, TPIDR_EL0
    ea00:      	mov	x19, x0
    ea04:      	ldr	x8, [x25, #0x28]
    ea08:      	str	x8, [sp, #0x18]
    ea0c:      	ldr	x0, [x0]
    ea10:      	bl	0x12ed0 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv@plt>
    ea14:      	cmn	w0, #0x1
    ea18:      	b.eq	0xeb8c <_ZN5mtgif9Video2Gif3runEv+0x1b4>
    ea1c:      	fmov	s8, #1.00000000
    ea20:      	mov	x28, #0x6666666666666666 // =7378697629483820646
    ea24:      	mov	w23, wzr
    ea28:      	mov	w20, wzr
    ea2c:      	mov	x26, xzr
    ea30:      	adrp	x21, 0x5000
    ea34:      	add	x21, x21, #0xa3b
    ea38:      	add	x27, x19, #0x29
    ea3c:      	adrp	x22, 0x5000
    ea40:      	add	x22, x22, #0xce0
    ea44:      	movk	x28, #0x6667
    ea48:      	stp	xzr, xzr, [sp, #0x8]
    ea4c:      	ldr	x0, [x19]
    ea50:      	add	x1, sp, #0x10
    ea54:      	add	x2, sp, #0x8
    ea58:      	bl	0x12e50 <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl@plt>
    ea5c:      	cbz	w0, 0xea74 <_ZN5mtgif9Video2Gif3runEv+0x9c>
    ea60:      	cmn	w0, #0x2
    ea64:      	b.eq	0xeba0 <_ZN5mtgif9Video2Gif3runEv+0x1c8>
    ea68:      	ldr	x0, [sp, #0x10]
    ea6c:      	cbnz	x0, 0xeb4c <_ZN5mtgif9Video2Gif3runEv+0x174>
    ea70:      	b	0xea4c <_ZN5mtgif9Video2Gif3runEv+0x74>
    ea74:      	ldr	x4, [sp, #0x8]
    ea78:      	add	w24, w23, #0x1
    ea7c:      	mov	w0, #0x4                // =4
    ea80:      	mov	x1, x21
    ea84:      	mov	x2, x22
    ea88:      	mov	w3, w24
    ea8c:      	bl	0x13320 <__android_log_print@plt>
    ea90:      	ldr	x8, [sp, #0x8]
    ea94:      	cmp	w24, #0x2
    ea98:      	csel	x26, x8, x26, eq
    ea9c:      	cmp	w24, #0x3
    eaa0:      	b.ne	0xeaf0 <_ZN5mtgif9Video2Gif3runEv+0x118>
    eaa4:      	sub	x8, x8, x26
    eaa8:      	ldr	x0, [x19, #0x8]
    eaac:      	ldr	w3, [x19, #0x40]
    eab0:      	smulh	x8, x8, x28
    eab4:      	mov	w2, wzr
    eab8:      	ldp	w4, w10, [x19, #0x44]
    eabc:      	sxtw	x10, w10
    eac0:      	asr	x9, x8, #2
    eac4:      	add	x8, x9, x8, lsr #63
    eac8:      	ldrb	w9, [x19, #0x28]
    eacc:      	add	x8, x8, x10
    ead0:      	ldr	x10, [x19, #0x38]
    ead4:      	cmp	x8, #0x1
    ead8:      	csinc	x5, x8, xzr, gt
    eadc:      	tst	w9, #0x1
    eae0:      	csel	x1, x27, x10, eq
    eae4:      	bl	0x12fe0 <_ZN5MTGif13SaveGifHeaderEPKciiii@plt>
    eae8:      	tbnz	w0, #0x0, 0xeaf8 <_ZN5mtgif9Video2Gif3runEv+0x120>
    eaec:      	b	0xec0c <_ZN5mtgif9Video2Gif3runEv+0x234>
    eaf0:      	cmp	w23, #0x2
    eaf4:      	b.lt	0xeb40 <_ZN5mtgif9Video2Gif3runEv+0x168>
    eaf8:      	ldr	s0, [x19, #0x4c]
    eafc:      	fcmp	s0, s8
    eb00:      	b.le	0xeb28 <_ZN5mtgif9Video2Gif3runEv+0x150>
    eb04:      	add	w8, w23, #0x2
    eb08:      	scvtf	s2, w24
    eb0c:      	scvtf	s1, w8
    eb10:      	fdiv	s1, s1, s0
    eb14:      	fdiv	s0, s2, s0
    eb18:      	fcvtzs	w8, s1
    eb1c:      	fcvtzs	w9, s0
    eb20:      	cmp	w8, w9
    eb24:      	b.le	0xeb58 <_ZN5mtgif9Video2Gif3runEv+0x180>
    eb28:      	ldr	x0, [x19, #0x8]
    eb2c:      	ldr	x1, [sp, #0x10]
    eb30:      	mov	w2, w20
    eb34:      	bl	0x13010 <_ZN5MTGif12SaveGifFrameEPhi@plt>
    eb38:      	tbz	w0, #0x0, 0xebcc <_ZN5mtgif9Video2Gif3runEv+0x1f4>
    eb3c:      	mov	w20, wzr
    eb40:      	mov	w23, w24
    eb44:      	ldr	x0, [sp, #0x10]
    eb48:      	cbz	x0, 0xea4c <_ZN5mtgif9Video2Gif3runEv+0x74>
    eb4c:      	bl	0x12f40 <free@plt>
    eb50:      	str	xzr, [sp, #0x10]
    eb54:      	b	0xea4c <_ZN5mtgif9Video2Gif3runEv+0x74>
    eb58:      	mov	w0, #0x4                // =4
    eb5c:      	mov	x1, x21
    eb60:      	adrp	x2, 0x5000
    eb64:      	add	x2, x2, #0xd02
    eb68:      	bl	0x13320 <__android_log_print@plt>
    eb6c:      	ldr	x0, [sp, #0x10]
    eb70:      	add	w20, w20, #0x1
    eb74:      	mov	w23, w24
    eb78:      	cbz	x0, 0xea4c <_ZN5mtgif9Video2Gif3runEv+0x74>
    eb7c:      	bl	0x12f40 <free@plt>
    eb80:      	str	xzr, [sp, #0x10]
    eb84:      	mov	w23, w24
    eb88:      	b	0xea4c <_ZN5mtgif9Video2Gif3runEv+0x74>
    eb8c:      	adrp	x1, 0x5000
    eb90:      	add	x1, x1, #0xa3b
    eb94:      	adrp	x2, 0x5000
    eb98:      	add	x2, x2, #0xfce
    eb9c:      	b	0xec00 <_ZN5mtgif9Video2Gif3runEv+0x228>
    eba0:      	ldr	x0, [sp, #0x10]
    eba4:      	cbz	x0, 0xebb0 <_ZN5mtgif9Video2Gif3runEv+0x1d8>
    eba8:      	bl	0x12f40 <free@plt>
    ebac:      	str	xzr, [sp, #0x10]
    ebb0:      	ldr	x0, [x19]
    ebb4:      	bl	0x12e90 <_ZN13FormatConvert18VideoFormatTranser4stopEv@plt>
    ebb8:      	ldr	x0, [x19, #0x8]
    ebbc:      	bl	0x13020 <_ZN5MTGif9SaveCloseEv@plt>
    ebc0:      	tbz	w0, #0x0, 0xebf0 <_ZN5mtgif9Video2Gif3runEv+0x218>
    ebc4:      	mov	w0, #0x1                // =1
    ebc8:      	b	0xec34 <_ZN5mtgif9Video2Gif3runEv+0x25c>
    ebcc:      	adrp	x1, 0x5000
    ebd0:      	add	x1, x1, #0xa3b
    ebd4:      	adrp	x2, 0x5000
    ebd8:      	add	x2, x2, #0xeda
    ebdc:      	mov	w0, #0x6                // =6
    ebe0:      	bl	0x13320 <__android_log_print@plt>
    ebe4:      	ldr	x0, [sp, #0x10]
    ebe8:      	cbnz	x0, 0xec2c <_ZN5mtgif9Video2Gif3runEv+0x254>
    ebec:      	b	0xec34 <_ZN5mtgif9Video2Gif3runEv+0x25c>
    ebf0:      	adrp	x1, 0x5000
    ebf4:      	add	x1, x1, #0xa3b
    ebf8:      	adrp	x2, 0x5000
    ebfc:      	add	x2, x2, #0xeda
    ec00:      	mov	w0, #0x6                // =6
    ec04:      	bl	0x13320 <__android_log_print@plt>
    ec08:      	b	0xec30 <_ZN5mtgif9Video2Gif3runEv+0x258>
    ec0c:      	adrp	x1, 0x5000
    ec10:      	add	x1, x1, #0xa3b
    ec14:      	adrp	x2, 0x5000
    ec18:      	add	x2, x2, #0xe25
    ec1c:      	mov	w0, #0x6                // =6
    ec20:      	bl	0x13320 <__android_log_print@plt>
    ec24:      	ldr	x0, [sp, #0x10]
    ec28:      	cbz	x0, 0xec34 <_ZN5mtgif9Video2Gif3runEv+0x25c>
    ec2c:      	bl	0x12f40 <free@plt>
    ec30:      	mov	w0, wzr
    ec34:      	ldr	x8, [x25, #0x28]
    ec38:      	ldr	x9, [sp, #0x18]
    ec3c:      	cmp	x8, x9
    ec40:      	b.ne	0xec68 <_ZN5mtgif9Video2Gif3runEv+0x290>
    ec44:      	ldp	x20, x19, [sp, #0x80]
    ec48:      	ldr	d8, [sp, #0x20]
    ec4c:      	ldp	x22, x21, [sp, #0x70]
    ec50:      	ldp	x24, x23, [sp, #0x60]
    ec54:      	ldp	x26, x25, [sp, #0x50]
    ec58:      	ldp	x28, x27, [sp, #0x40]
    ec5c:      	ldp	x29, x30, [sp, #0x30]
    ec60:      	add	sp, sp, #0x90
    ec64:      	ret
    ec68:      	bl	0x12bc0 <__stack_chk_fail@plt>
    ec6c:      	paciasp
    ec70:      	sub	sp, sp, #0x80
    ec74:      	stp	x29, x30, [sp, #0x50]
    ec78:      	stp	x22, x21, [sp, #0x60]
    ec7c:      	stp	x20, x19, [sp, #0x70]
    ec80:      	add	x29, sp, #0x50
    ec84:      	mov	x19, x1
    ec88:      	mov	x1, x0
    ec8c:      	mov	x20, x2
    ec90:      	mov	x0, x19
    ec94:      	bl	0xef18 <_ZN5mtgif9Video2Gif3runEv+0x540>
    ec98:      	mov	x0, x19
    ec9c:      	bl	0xf03c <_ZN5mtgif9Video2Gif3runEv+0x664>
    eca0:      	cbz	w0, 0xed58 <_ZN5mtgif9Video2Gif3runEv+0x380>
    eca4:      	mov	w21, #0x2               // =2
    eca8:      	mov	w22, #0x6               // =6
    ecac:      	b	0xecbc <_ZN5mtgif9Video2Gif3runEv+0x2e4>
    ecb0:      	mov	x0, x19
    ecb4:      	bl	0xf03c <_ZN5mtgif9Video2Gif3runEv+0x664>
    ecb8:      	cbz	w0, 0xed58 <_ZN5mtgif9Video2Gif3runEv+0x380>
    ecbc:      	tbnz	w0, #0x1f, 0xed84 <_ZN5mtgif9Video2Gif3runEv+0x3ac>
    ecc0:      	sub	x2, x29, #0x8
    ecc4:      	mov	x0, x19
    ecc8:      	mov	w1, #-0x2               // =-2
    eccc:      	bl	0xefc0 <_ZN5mtgif9Video2Gif3runEv+0x5e8>
    ecd0:      	mov	x1, sp
    ecd4:      	mov	x0, x19
    ecd8:      	bl	0xf050 <_ZN5mtgif9Video2Gif3runEv+0x678>
    ecdc:      	cbnz	w0, 0xed84 <_ZN5mtgif9Video2Gif3runEv+0x3ac>
    ece0:      	ldr	x8, [sp, #0x18]
    ece4:      	cbz	x8, 0xecb0 <_ZN5mtgif9Video2Gif3runEv+0x2d8>
    ece8:      	ldur	x9, [x29, #-0x8]
    ecec:      	ldr	x10, [x20, #0x18]
    ecf0:      	mov	w0, #0x1                // =1
    ecf4:      	ldr	x2, [x20]
    ecf8:      	mov	x3, x20
    ecfc:      	mov	x4, x19
    ed00:      	cmp	x9, x10
    ed04:      	csel	w1, w22, w21, eq
    ed08:      	blr	x8
    ed0c:      	cmp	w0, #0x8
    ed10:      	b.ne	0xed74 <_ZN5mtgif9Video2Gif3runEv+0x39c>
    ed14:      	ldur	x8, [x29, #-0x8]
    ed18:      	ldr	x9, [x20, #0x18]
    ed1c:      	cmp	x8, x9
    ed20:      	b.ne	0xecb0 <_ZN5mtgif9Video2Gif3runEv+0x2d8>
    ed24:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
    ed28:      	nop
    ed2c:      	adr	x1, 0x55ec
    ed30:      	ldr	x19, [x19, #0x7e8]
    ed34:      	adrp	x2, 0x5000
    ed38:      	add	x2, x2, #0x9d9
    ed3c:      	adrp	x3, 0x5000
    ed40:      	add	x3, x3, #0xbfe
    ed44:      	add	x0, x19, #0x130
    ed48:      	bl	0x133b0 <fprintf@plt>
    ed4c:      	add	x0, x19, #0x130
    ed50:      	bl	0x131c0 <fflush@plt>
    ed54:      	bl	0x133c0 <abort@plt>
    ed58:      	mov	w0, #0x5                // =5
    ed5c:      	ldp	x20, x19, [sp, #0x70]
    ed60:      	ldp	x22, x21, [sp, #0x60]
    ed64:      	ldp	x29, x30, [sp, #0x50]
    ed68:      	add	sp, sp, #0x80
    ed6c:      	autiasp
    ed70:      	ret
    ed74:      	cmp	w0, #0x7
    ed78:      	b.ne	0xed84 <_ZN5mtgif9Video2Gif3runEv+0x3ac>
    ed7c:      	mov	x0, x19
    ed80:      	bl	0xf090 <_ZN5mtgif9Video2Gif3runEv+0x6b8>
    ed84:      	mov	w0, #0x2                // =2
    ed88:      	ldp	x20, x19, [sp, #0x70]
    ed8c:      	ldp	x22, x21, [sp, #0x60]
    ed90:      	ldp	x29, x30, [sp, #0x50]
    ed94:      	add	sp, sp, #0x80
    ed98:      	autiasp
    ed9c:      	ret
    eda0:      	paciasp
    eda4:      	stp	x29, x30, [sp, #-0x20]!
    eda8:      	stp	x28, x19, [sp, #0x10]
    edac:      	mov	x29, sp
    edb0:      	sub	sp, sp, #0x480
    edb4:      	mov	x19, x0
    edb8:      	add	x0, sp, #0x270
    edbc:      	bl	0x129c4 <_ZN5mtgif9Video2Gif3runEv+0x3fec>
    edc0:      	ldr	x3, [x19, #0x10]
    edc4:      	cbnz	x3, 0xeddc <_ZN5mtgif9Video2Gif3runEv+0x404>
    edc8:      	add	x0, sp, #0x270
    edcc:      	mov	x1, sp
    edd0:      	mov	x2, x19
    edd4:      	bl	0xec6c <_ZN5mtgif9Video2Gif3runEv+0x294>
    edd8:      	b	0xedf0 <_ZN5mtgif9Video2Gif3runEv+0x418>
    eddc:      	ldr	x4, [x19, #0x18]
    ede0:      	add	x0, sp, #0x270
    ede4:      	mov	x1, sp
    ede8:      	mov	x2, x19
    edec:      	bl	0xee24 <_ZN5mtgif9Video2Gif3runEv+0x44c>
    edf0:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
    edf4:      	nop
    edf8:      	adr	x1, 0x55ec
    edfc:      	ldr	x19, [x19, #0x7e8]
    ee00:      	adrp	x2, 0x5000
    ee04:      	add	x2, x2, #0xfdf
    ee08:      	adrp	x3, 0x5000
    ee0c:      	add	x3, x3, #0x76f
    ee10:      	add	x0, x19, #0x130
    ee14:      	bl	0x133b0 <fprintf@plt>
    ee18:      	add	x0, x19, #0x130
    ee1c:      	bl	0x131c0 <fflush@plt>
    ee20:      	bl	0x133c0 <abort@plt>
    ee24:      	paciasp
    ee28:      	sub	sp, sp, #0x80
    ee2c:      	stp	x29, x30, [sp, #0x50]
    ee30:      	stp	x22, x21, [sp, #0x60]
    ee34:      	stp	x20, x19, [sp, #0x70]
    ee38:      	add	x29, sp, #0x50
    ee3c:      	mov	x21, x1
    ee40:      	mov	x1, x0
    ee44:      	mov	x20, x4
    ee48:      	mov	x0, x21
    ee4c:      	mov	x19, x3
    ee50:      	mov	x22, x2
    ee54:      	bl	0xef18 <_ZN5mtgif9Video2Gif3runEv+0x540>
    ee58:      	mov	x0, x21
    ee5c:      	bl	0xf03c <_ZN5mtgif9Video2Gif3runEv+0x664>
    ee60:      	cmp	w0, #0x1
    ee64:      	b.ge	0xeeac <_ZN5mtgif9Video2Gif3runEv+0x4d4>
    ee68:      	ldr	x2, [x22]
    ee6c:      	mov	w0, #0x1                // =1
    ee70:      	mov	w1, #0x1a               // =26
    ee74:      	mov	x3, x22
    ee78:      	mov	x4, x21
    ee7c:      	mov	x5, x20
    ee80:      	blr	x19
    ee84:      	ldp	x20, x19, [sp, #0x70]
    ee88:      	ldp	x22, x21, [sp, #0x60]
    ee8c:      	ldp	x29, x30, [sp, #0x50]
    ee90:      	add	sp, sp, #0x80
    ee94:      	autiasp
    ee98:      	ret
    ee9c:      	mov	x0, x21
    eea0:      	bl	0xf03c <_ZN5mtgif9Video2Gif3runEv+0x664>
    eea4:      	cmp	w0, #0x0
    eea8:      	b.le	0xee68 <_ZN5mtgif9Video2Gif3runEv+0x490>
    eeac:      	add	x1, sp, #0x8
    eeb0:      	mov	x0, x21
    eeb4:      	bl	0xf050 <_ZN5mtgif9Video2Gif3runEv+0x678>
    eeb8:      	cbnz	w0, 0xee84 <_ZN5mtgif9Video2Gif3runEv+0x4ac>
    eebc:      	ldr	x2, [x22]
    eec0:      	mov	w0, #0x1                // =1
    eec4:      	mov	w1, #0xa                // =10
    eec8:      	mov	x3, x22
    eecc:      	mov	x4, x21
    eed0:      	mov	x5, x20
    eed4:      	blr	x19
    eed8:      	cbnz	w0, 0xee84 <_ZN5mtgif9Video2Gif3runEv+0x4ac>
    eedc:      	ldr	x8, [sp, #0x20]
    eee0:      	cbz	x8, 0xee9c <_ZN5mtgif9Video2Gif3runEv+0x4c4>
    eee4:      	ldr	x2, [x22]
    eee8:      	mov	w0, #0x1                // =1
    eeec:      	mov	w1, #0xa                // =10
    eef0:      	mov	x3, x22
    eef4:      	mov	x4, x21
    eef8:      	blr	x8
    eefc:      	cmp	w0, #0x8
    ef00:      	b.eq	0xee9c <_ZN5mtgif9Video2Gif3runEv+0x4c4>
    ef04:      	cmp	w0, #0x7
    ef08:      	b.ne	0xee84 <_ZN5mtgif9Video2Gif3runEv+0x4ac>
    ef0c:      	mov	x0, x21
    ef10:      	bl	0xf090 <_ZN5mtgif9Video2Gif3runEv+0x6b8>
    ef14:      	b	0xee9c <_ZN5mtgif9Video2Gif3runEv+0x4c4>
    ef18:      	paciasp
    ef1c:      	stp	x29, x30, [sp, #-0x20]!
    ef20:      	stp	x20, x19, [sp, #0x10]
    ef24:      	mov	x29, sp
    ef28:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
    ef2c:      	add	x8, x8, #0x548
    ef30:      	nop
    ef34:      	adr	x9, 0x1bd28 <g_gifReader+0x8>
    ef38:      	mov	w2, #0x110              // =272
    ef3c:      	mov	x20, x1
    ef40:      	mov	x19, x0
    ef44:      	stp	x8, x9, [x0], #0x10
    ef48:      	bl	0x12e70 <memcpy@plt>
    ef4c:      	ldp	q1, q0, [x20, #0x130]
    ef50:      	add	x8, x19, #0x220
    ef54:      	ldp	q3, q2, [x20, #0x110]
    ef58:      	mov	x0, x19
    ef5c:      	mov	w1, wzr
    ef60:      	stp	q1, q0, [x19, #0x140]
    ef64:      	stp	q3, q2, [x19, #0x120]
    ef68:      	ldp	q1, q0, [x20, #0x170]
    ef6c:      	ldp	q3, q2, [x20, #0x150]
    ef70:      	stp	q1, q0, [x19, #0x180]
    ef74:      	stp	q3, q2, [x19, #0x160]
    ef78:      	ldp	q1, q0, [x20, #0x1b0]
    ef7c:      	ldp	q3, q2, [x20, #0x190]
    ef80:      	stp	q1, q0, [x19, #0x1c0]
    ef84:      	stp	q3, q2, [x19, #0x1a0]
    ef88:      	movi	v2.2d, #0000000000000000
    ef8c:      	ldp	q1, q0, [x20, #0x1f0]
    ef90:      	ldp	q4, q3, [x20, #0x1d0]
    ef94:      	stp	q1, q0, [x19, #0x200]
    ef98:      	stp	q4, q3, [x19, #0x1e0]
    ef9c:      	stur	q2, [x8, #0x3b]
    efa0:      	stp	q2, q2, [x19, #0x220]
    efa4:      	stp	q2, q2, [x19, #0x240]
    efa8:      	bl	0xf8e0 <_ZN5mtgif9Video2Gif3runEv+0xf08>
    efac:      	mov	w0, wzr
    efb0:      	ldp	x20, x19, [sp, #0x10]
    efb4:      	ldp	x29, x30, [sp], #0x20
    efb8:      	autiasp
    efbc:      	ret
    efc0:      	paciasp
    efc4:      	stp	x29, x30, [sp, #-0x30]!
    efc8:      	str	x21, [sp, #0x10]
    efcc:      	stp	x20, x19, [sp, #0x20]
    efd0:      	mov	x29, sp
    efd4:      	ldr	x8, [x0]
    efd8:      	mov	x19, x2
    efdc:      	mov	x20, x0
    efe0:      	mov	w21, w1
    efe4:      	ldr	x8, [x8, #0x10]
    efe8:      	blr	x8
    efec:      	tbz	w0, #0x0, 0xf024 <_ZN5mtgif9Video2Gif3runEv+0x64c>
    eff0:      	ldr	x8, [x20]
    eff4:      	mov	x0, x20
    eff8:      	mov	w1, w21
    effc:      	ldr	x8, [x8, #0x18]
    f000:      	blr	x8
    f004:      	mov	x8, x0
    f008:      	mov	w0, wzr
    f00c:      	str	x8, [x19]
    f010:      	ldp	x20, x19, [sp, #0x20]
    f014:      	ldr	x21, [sp, #0x10]
    f018:      	ldp	x29, x30, [sp], #0x30
    f01c:      	autiasp
    f020:      	ret
    f024:      	mov	w0, #-0x198e            // =-6542
    f028:      	ldp	x20, x19, [sp, #0x20]
    f02c:      	ldr	x21, [sp, #0x10]
    f030:      	ldp	x29, x30, [sp], #0x30
    f034:      	autiasp
    f038:      	ret
    f03c:      	bti	c
    f040:      	ldr	x8, [x0]
    f044:      	mov	w1, #0x1                // =1
    f048:      	ldr	x16, [x8, #0x40]
    f04c:      	br	x16
    f050:      	paciasp
    f054:      	stp	x29, x30, [sp, #-0x20]!
    f058:      	str	x19, [sp, #0x10]
    f05c:      	mov	x29, sp
    f060:      	ldr	x8, [x0]
    f064:      	mov	x19, x1
    f068:      	ldr	x8, [x8, #0x48]
    f06c:      	blr	x8
    f070:      	ldr	x8, [x19, #0x8]
    f074:      	cmp	x8, #0x0
    f078:      	mov	w8, #-0x1995            // =-6549
    f07c:      	csel	w0, w8, wzr, eq
    f080:      	ldr	x19, [sp, #0x10]
    f084:      	ldp	x29, x30, [sp], #0x20
    f088:      	autiasp
    f08c:      	ret
    f090:      	paciasp
    f094:      	stp	x29, x30, [sp, #-0x10]!
    f098:      	mov	x29, sp
    f09c:      	ldr	x8, [x0]
    f0a0:      	ldr	x8, [x8, #0x50]
    f0a4:      	blr	x8
    f0a8:      	mov	w0, #-0x198c            // =-6540
    f0ac:      	ldp	x29, x30, [sp], #0x10
    f0b0:      	autiasp
    f0b4:      	ret
    f0b8:      	paciasp
    f0bc:      	stp	x29, x30, [sp, #-0x60]!
    f0c0:      	str	x27, [sp, #0x10]
    f0c4:      	stp	x26, x25, [sp, #0x20]
    f0c8:      	stp	x24, x23, [sp, #0x30]
    f0cc:      	stp	x22, x21, [sp, #0x40]
    f0d0:      	stp	x20, x19, [sp, #0x50]
    f0d4:      	mov	x29, sp
    f0d8:      	mov	x23, x1
    f0dc:      	mov	x20, x3
    f0e0:      	mov	x19, x2
    f0e4:      	ldr	w22, [x23], #0x4
    f0e8:      	mov	x21, x0
    f0ec:      	cmn	w22, #0x1
    f0f0:      	b.eq	0xf124 <_ZN5mtgif9Video2Gif3runEv+0x74c>
    f0f4:      	cbz	x22, 0xf130 <_ZN5mtgif9Video2Gif3runEv+0x758>
    f0f8:      	ldr	w8, [x23]
    f0fc:      	cbz	w8, 0xf13c <_ZN5mtgif9Video2Gif3runEv+0x764>
    f100:      	mov	x25, x1
    f104:      	sub	x1, x23, x8
    f108:      	tbz	w4, #0x0, 0xf148 <_ZN5mtgif9Video2Gif3runEv+0x770>
    f10c:      	ldr	x8, [x20]
    f110:      	cmp	x8, x1
    f114:      	b.eq	0xf158 <_ZN5mtgif9Video2Gif3runEv+0x780>
    f118:      	adrp	x0, 0x6000
    f11c:      	add	x0, x0, #0x45
    f120:      	b	0xf228 <_ZN5mtgif9Video2Gif3runEv+0x850>
    f124:      	ldur	x22, [x1, #0x4]
    f128:      	add	x23, x1, #0xc
    f12c:      	cbnz	x22, 0xf0f8 <_ZN5mtgif9Video2Gif3runEv+0x720>
    f130:      	adrp	x0, 0x5000
    f134:      	add	x0, x0, #0x870
    f138:      	b	0xf228 <_ZN5mtgif9Video2Gif3runEv+0x850>
    f13c:      	adrp	x0, 0x5000
    f140:      	add	x0, x0, #0xaf7
    f144:      	b	0xf228 <_ZN5mtgif9Video2Gif3runEv+0x850>
    f148:      	mov	x0, x21
    f14c:      	mov	x2, x20
    f150:      	bl	0xf248 <_ZN5mtgif9Video2Gif3runEv+0x870>
    f154:      	cbnz	x0, 0xf228 <_ZN5mtgif9Video2Gif3runEv+0x850>
    f158:      	ldrb	w3, [x20, #0x18]
    f15c:      	add	x22, x23, x22
    f160:      	add	x8, x23, #0x4
    f164:      	add	x1, x29, #0x18
    f168:      	mov	x0, x21
    f16c:      	mov	x2, x22
    f170:      	mov	x4, xzr
    f174:      	str	x8, [x29, #0x18]
    f178:      	bl	0x110a0 <_ZN5mtgif9Video2Gif3runEv+0x26c8>
    f17c:      	ldrb	w8, [x20, #0x18]
    f180:      	mov	x23, x0
    f184:      	add	x1, x29, #0x18
    f188:      	mov	x0, x21
    f18c:      	mov	x2, x22
    f190:      	mov	x4, xzr
    f194:      	and	w3, w8, #0xf
    f198:      	bl	0x110a0 <_ZN5mtgif9Video2Gif3runEv+0x26c8>
    f19c:      	ldrb	w8, [x20, #0x31]
    f1a0:      	mov	x24, x0
    f1a4:      	str	xzr, [x19, #0x28]
    f1a8:      	cbz	w8, 0xf20c <_ZN5mtgif9Video2Gif3runEv+0x834>
    f1ac:      	add	x0, x29, #0x18
    f1b0:      	mov	x1, x22
    f1b4:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
    f1b8:      	ldrb	w8, [x20, #0x19]
    f1bc:      	ldr	x27, [x29, #0x18]
    f1c0:      	cmp	w8, #0xff
    f1c4:      	add	x26, x27, x0
    f1c8:      	b.eq	0xf210 <_ZN5mtgif9Video2Gif3runEv+0x838>
    f1cc:      	add	x1, x29, #0x18
    f1d0:      	and	w3, w8, #0xf
    f1d4:      	mov	x0, x21
    f1d8:      	mov	x2, x22
    f1dc:      	mov	x4, xzr
    f1e0:      	bl	0x110a0 <_ZN5mtgif9Video2Gif3runEv+0x26c8>
    f1e4:      	cbz	x0, 0xf210 <_ZN5mtgif9Video2Gif3runEv+0x838>
    f1e8:      	ldrb	w3, [x20, #0x19]
    f1ec:      	add	x1, x29, #0x18
    f1f0:      	mov	x0, x21
    f1f4:      	mov	x2, x22
    f1f8:      	mov	x4, xzr
    f1fc:      	str	x27, [x29, #0x18]
    f200:      	bl	0x110a0 <_ZN5mtgif9Video2Gif3runEv+0x26c8>
    f204:      	str	x0, [x19, #0x28]
    f208:      	b	0xf210 <_ZN5mtgif9Video2Gif3runEv+0x838>
    f20c:      	ldr	x26, [x29, #0x18]
    f210:      	sub	x8, x22, x25
    f214:      	mov	x0, xzr
    f218:      	stp	x26, x23, [x19, #0x10]
    f21c:      	stp	x25, x8, [x19]
    f220:      	add	x8, x24, x23
    f224:      	str	x8, [x19, #0x20]
    f228:      	ldp	x20, x19, [sp, #0x50]
    f22c:      	ldr	x27, [sp, #0x10]
    f230:      	ldp	x22, x21, [sp, #0x40]
    f234:      	ldp	x24, x23, [sp, #0x30]
    f238:      	ldp	x26, x25, [sp, #0x20]
    f23c:      	ldp	x29, x30, [sp], #0x60
    f240:      	autiasp
    f244:      	ret
    f248:      	paciasp
    f24c:      	sub	sp, sp, #0x50
    f250:      	stp	x29, x30, [sp, #0x10]
    f254:      	stp	x24, x23, [sp, #0x20]
    f258:      	stp	x22, x21, [sp, #0x30]
    f25c:      	stp	x20, x19, [sp, #0x40]
    f260:      	add	x29, sp, #0x10
    f264:      	movi	d0, #0x00ff000000ff00
    f268:      	sturh	wzr, [x2, #0x33]
    f26c:      	mov	x8, x1
    f270:      	stp	xzr, xzr, [x2, #0x20]
    f274:      	mov	x19, x2
    f278:      	mov	x20, x1
    f27c:      	strh	wzr, [x2, #0x30]
    f280:      	mov	x21, x0
    f284:      	str	x1, [x2]
    f288:      	str	s0, [x2, #0x18]
    f28c:      	ldr	w9, [x8], #0x4
    f290:      	cmn	w9, #0x1
    f294:      	b.eq	0xf2b4 <_ZN5mtgif9Video2Gif3runEv+0x8dc>
    f298:      	add	x22, x8, x9
    f29c:      	cbz	x9, 0xf2c4 <_ZN5mtgif9Video2Gif3runEv+0x8ec>
    f2a0:      	ldr	w9, [x8]
    f2a4:      	cbz	w9, 0xf2cc <_ZN5mtgif9Video2Gif3runEv+0x8f4>
    f2a8:      	adrp	x0, 0x6000
    f2ac:      	add	x0, x0, #0x32
    f2b0:      	b	0xf4c0 <_ZN5mtgif9Video2Gif3runEv+0xae8>
    f2b4:      	ldur	x9, [x20, #0x4]
    f2b8:      	add	x8, x20, #0xc
    f2bc:      	add	x22, x9, x8
    f2c0:      	cbnz	x9, 0xf2a0 <_ZN5mtgif9Video2Gif3runEv+0x8c8>
    f2c4:      	mov	x0, xzr
    f2c8:      	b	0xf4c0 <_ZN5mtgif9Video2Gif3runEv+0xae8>
    f2cc:      	ldrb	w24, [x8, #0x4]
    f2d0:      	and	w9, w24, #0xfffffffd
    f2d4:      	cmp	w9, #0x1
    f2d8:      	b.ne	0xf384 <_ZN5mtgif9Video2Gif3runEv+0x9ac>
    f2dc:      	add	x23, x8, #0x5
    f2e0:      	mov	x8, x23
    f2e4:      	ldrb	w9, [x8], #0x1
    f2e8:      	cbnz	w9, 0xf2e4 <_ZN5mtgif9Video2Gif3runEv+0x90c>
    f2ec:      	add	x0, sp, #0x8
    f2f0:      	mov	x1, x22
    f2f4:      	str	x8, [sp, #0x8]
    f2f8:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
    f2fc:      	ldr	x8, [sp, #0x8]
    f300:      	mov	x11, xzr
    f304:      	mov	x9, xzr
    f308:      	str	w0, [x19, #0x28]
    f30c:      	mov	x10, x8
    f310:      	cmp	x10, x22
    f314:      	b.eq	0xf4dc <_ZN5mtgif9Video2Gif3runEv+0xb04>
    f318:      	ldrb	w12, [x10], #0x1
    f31c:      	add	x8, x8, #0x1
    f320:      	and	x13, x12, #0x7f
    f324:      	lsl	x13, x13, x11
    f328:      	add	x11, x11, #0x7
    f32c:      	orr	x9, x13, x9
    f330:      	tbnz	w12, #0x7, 0xf310 <_ZN5mtgif9Video2Gif3runEv+0x938>
    f334:      	sub	w13, w11, #0x7
    f338:      	mov	x14, #-0x1              // =-1
    f33c:      	str	x8, [sp, #0x8]
    f340:      	cmp	w13, #0x39
    f344:      	mov	w13, #0x3f              // =63
    f348:      	lsl	x11, x14, x11
    f34c:      	ccmp	w12, w13, #0x0, lo
    f350:      	csel	w11, w11, wzr, hi
    f354:      	cmp	w24, #0x1
    f358:      	orr	w9, w9, w11
    f35c:      	str	w9, [x19, #0x2c]
    f360:      	b.ne	0xf390 <_ZN5mtgif9Video2Gif3runEv+0x9b8>
    f364:      	add	x8, x8, #0x1
    f368:      	str	x8, [sp, #0x8]
    f36c:      	ldrb	w0, [x10]
    f370:      	strb	w0, [x19, #0x32]
    f374:      	ldrb	w8, [x23]
    f378:      	cmp	w8, #0x7a
    f37c:      	b.eq	0xf3ac <_ZN5mtgif9Video2Gif3runEv+0x9d4>
    f380:      	b	0xf4ac <_ZN5mtgif9Video2Gif3runEv+0xad4>
    f384:      	adrp	x0, 0x5000
    f388:      	add	x0, x0, #0x749
    f38c:      	b	0xf4c0 <_ZN5mtgif9Video2Gif3runEv+0xae8>
    f390:      	add	x0, sp, #0x8
    f394:      	mov	x1, x22
    f398:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
    f39c:      	strb	w0, [x19, #0x32]
    f3a0:      	ldrb	w8, [x23]
    f3a4:      	cmp	w8, #0x7a
    f3a8:      	b.ne	0xf4ac <_ZN5mtgif9Video2Gif3runEv+0xad4>
    f3ac:      	add	x0, sp, #0x8
    f3b0:      	mov	x1, x22
    f3b4:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
    f3b8:      	mov	w24, #0x1               // =1
    f3bc:      	b	0xf3c8 <_ZN5mtgif9Video2Gif3runEv+0x9f0>
    f3c0:      	strb	w24, [x19, #0x30]
    f3c4:      	add	x23, x23, #0x1
    f3c8:      	ldrb	w8, [x23]
    f3cc:      	cmp	w8, #0x4f
    f3d0:      	b.le	0xf404 <_ZN5mtgif9Video2Gif3runEv+0xa2c>
    f3d4:      	cmp	w8, #0x52
    f3d8:      	b.gt	0xf434 <_ZN5mtgif9Video2Gif3runEv+0xa5c>
    f3dc:      	cmp	w8, #0x50
    f3e0:      	b.eq	0xf470 <_ZN5mtgif9Video2Gif3runEv+0xa98>
    f3e4:      	cmp	w8, #0x52
    f3e8:      	b.ne	0xf468 <_ZN5mtgif9Video2Gif3runEv+0xa90>
    f3ec:      	ldr	x8, [sp, #0x8]
    f3f0:      	add	x23, x23, #0x1
    f3f4:      	ldrb	w9, [x8], #0x1
    f3f8:      	str	x8, [sp, #0x8]
    f3fc:      	strb	w9, [x19, #0x18]
    f400:      	b	0xf3c8 <_ZN5mtgif9Video2Gif3runEv+0x9f0>
    f404:      	cmp	w8, #0x46
    f408:      	b.le	0xf450 <_ZN5mtgif9Video2Gif3runEv+0xa78>
    f40c:      	cmp	w8, #0x47
    f410:      	b.eq	0xf464 <_ZN5mtgif9Video2Gif3runEv+0xa8c>
    f414:      	cmp	w8, #0x4c
    f418:      	b.ne	0xf468 <_ZN5mtgif9Video2Gif3runEv+0xa90>
    f41c:      	ldr	x8, [sp, #0x8]
    f420:      	add	x23, x23, #0x1
    f424:      	ldrb	w9, [x8], #0x1
    f428:      	str	x8, [sp, #0x8]
    f42c:      	strb	w9, [x19, #0x19]
    f430:      	b	0xf3c8 <_ZN5mtgif9Video2Gif3runEv+0x9f0>
    f434:      	cmp	w8, #0x53
    f438:      	b.eq	0xf3c0 <_ZN5mtgif9Video2Gif3runEv+0x9e8>
    f43c:      	cmp	w8, #0x7a
    f440:      	b.ne	0xf468 <_ZN5mtgif9Video2Gif3runEv+0xa90>
    f444:      	strb	w24, [x19, #0x31]
    f448:      	add	x23, x23, #0x1
    f44c:      	b	0xf3c8 <_ZN5mtgif9Video2Gif3runEv+0x9f0>
    f450:      	cmp	w8, #0x42
    f454:      	b.ne	0xf4a8 <_ZN5mtgif9Video2Gif3runEv+0xad0>
    f458:      	strb	w24, [x19, #0x33]
    f45c:      	add	x23, x23, #0x1
    f460:      	b	0xf3c8 <_ZN5mtgif9Video2Gif3runEv+0x9f0>
    f464:      	strb	w24, [x19, #0x34]
    f468:      	add	x23, x23, #0x1
    f46c:      	b	0xf3c8 <_ZN5mtgif9Video2Gif3runEv+0x9f0>
    f470:      	ldr	x8, [sp, #0x8]
    f474:      	add	x1, sp, #0x8
    f478:      	mov	x0, x21
    f47c:      	mov	x2, x22
    f480:      	mov	x4, xzr
    f484:      	ldrb	w3, [x8], #0x1
    f488:      	str	x8, [sp, #0x8]
    f48c:      	sub	w8, w8, w20
    f490:      	strb	w3, [x19, #0x1a]
    f494:      	strb	w8, [x19, #0x1b]
    f498:      	bl	0x110a0 <_ZN5mtgif9Video2Gif3runEv+0x26c8>
    f49c:      	str	x0, [x19, #0x20]
    f4a0:      	add	x23, x23, #0x1
    f4a4:      	b	0xf3c8 <_ZN5mtgif9Video2Gif3runEv+0x9f0>
    f4a8:      	cbnz	w8, 0xf468 <_ZN5mtgif9Video2Gif3runEv+0xa90>
    f4ac:      	ldr	x8, [x19]
    f4b0:      	ldr	x9, [sp, #0x8]
    f4b4:      	mov	x0, xzr
    f4b8:      	sub	x8, x22, x8
    f4bc:      	stp	x8, x9, [x19, #0x8]
    f4c0:      	ldp	x20, x19, [sp, #0x40]
    f4c4:      	ldp	x22, x21, [sp, #0x30]
    f4c8:      	ldp	x24, x23, [sp, #0x20]
    f4cc:      	ldp	x29, x30, [sp, #0x10]
    f4d0:      	add	sp, sp, #0x50
    f4d4:      	autiasp
    f4d8:      	ret
    f4dc:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
    f4e0:      	nop
    f4e4:      	adr	x1, 0x55ec
    f4e8:      	ldr	x19, [x19, #0x7e8]
    f4ec:      	adrp	x2, 0x5000
    f4f0:      	add	x2, x2, #0xbcd
    f4f4:      	adrp	x3, 0x5000
    f4f8:      	add	x3, x3, #0x958
    f4fc:      	add	x0, x19, #0x130
    f500:      	bl	0x133b0 <fprintf@plt>
    f504:      	add	x0, x19, #0x130
    f508:      	bl	0x131c0 <fflush@plt>
    f50c:      	bl	0x133c0 <abort@plt>
    f510:      	bti	c
    f514:      	ret
    f518:      	bti	c
    f51c:      	ret
    f520:      	bti	c
    f524:      	cmn	w1, #0x3
    f528:      	b.ls	0xf534 <_ZN5mtgif9Video2Gif3runEv+0xb5c>
    f52c:      	mov	w0, #0x1                // =1
    f530:      	ret
    f534:      	cmp	w1, #0x5f
    f538:      	b.ls	0xf544 <_ZN5mtgif9Video2Gif3runEv+0xb6c>
    f53c:      	mov	w0, wzr
    f540:      	ret
    f544:      	cmp	w1, #0x22
    f548:      	b.ne	0xf554 <_ZN5mtgif9Video2Gif3runEv+0xb7c>
    f54c:      	mov	w0, #0x1                // =1
    f550:      	ret
    f554:      	sub	w8, w1, #0x40
    f558:      	cmn	w8, #0x1f
    f55c:      	cset	w0, lo
    f560:      	ret
    f564:      	bti	c
    f568:      	cmp	w1, #0x1d
    f56c:      	b.le	0xf58c <_ZN5mtgif9Video2Gif3runEv+0xbb4>
    f570:      	cmp	w1, #0x1f
    f574:      	b.gt	0xf5b0 <_ZN5mtgif9Video2Gif3runEv+0xbd8>
    f578:      	cmp	w1, #0x1e
    f57c:      	b.eq	0xf5f0 <_ZN5mtgif9Video2Gif3runEv+0xc18>
    f580:      	cmp	w1, #0x1f
    f584:      	b.eq	0xf5cc <_ZN5mtgif9Video2Gif3runEv+0xbf4>
    f588:      	b	0xf5d8 <_ZN5mtgif9Video2Gif3runEv+0xc00>
    f58c:      	cmn	w1, #0x2
    f590:      	b.eq	0xf5cc <_ZN5mtgif9Video2Gif3runEv+0xbf4>
    f594:      	cmn	w1, #0x1
    f598:      	b.eq	0xf5c0 <_ZN5mtgif9Video2Gif3runEv+0xbe8>
    f59c:      	cmp	w1, #0x1d
    f5a0:      	b.ne	0xf5d8 <_ZN5mtgif9Video2Gif3runEv+0xc00>
    f5a4:      	add	x8, x0, #0xf8
    f5a8:      	ldr	x0, [x8]
    f5ac:      	ret
    f5b0:      	cmp	w1, #0x22
    f5b4:      	b.eq	0xf5fc <_ZN5mtgif9Video2Gif3runEv+0xc24>
    f5b8:      	cmp	w1, #0x20
    f5bc:      	b.ne	0xf5d8 <_ZN5mtgif9Video2Gif3runEv+0xc00>
    f5c0:      	add	x8, x0, #0x110
    f5c4:      	ldr	x0, [x8]
    f5c8:      	ret
    f5cc:      	add	x8, x0, #0x108
    f5d0:      	ldr	x0, [x8]
    f5d4:      	ret
    f5d8:      	cmp	w1, #0x1c
    f5dc:      	b.hi	0xf608 <_ZN5mtgif9Video2Gif3runEv+0xc30>
    f5e0:      	add	x8, x0, #0x10
    f5e4:      	add	x8, x8, w1, uxtw #3
    f5e8:      	ldr	x0, [x8]
    f5ec:      	ret
    f5f0:      	add	x8, x0, #0x100
    f5f4:      	ldr	x0, [x8]
    f5f8:      	ret
    f5fc:      	add	x8, x0, #0x118
    f600:      	ldr	x0, [x8]
    f604:      	ret
    f608:      	paciasp
    f60c:      	stp	x29, x30, [sp, #-0x20]!
    f610:      	str	x19, [sp, #0x10]
    f614:      	mov	x29, sp
    f618:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
    f61c:      	nop
    f620:      	adr	x1, 0x55ec
    f624:      	ldr	x19, [x19, #0x7e8]
    f628:      	adrp	x2, 0x5000
    f62c:      	add	x2, x2, #0xae3
    f630:      	adrp	x3, 0x5000
    f634:      	add	x3, x3, #0x901
    f638:      	add	x0, x19, #0x130
    f63c:      	bl	0x133b0 <fprintf@plt>
    f640:      	add	x0, x19, #0x130
    f644:      	bl	0x131c0 <fflush@plt>
    f648:      	bl	0x133c0 <abort@plt>
    f64c:      	bti	c
    f650:      	cmp	w1, #0x1d
    f654:      	b.le	0xf674 <_ZN5mtgif9Video2Gif3runEv+0xc9c>
    f658:      	cmp	w1, #0x1f
    f65c:      	b.gt	0xf698 <_ZN5mtgif9Video2Gif3runEv+0xcc0>
    f660:      	cmp	w1, #0x1e
    f664:      	b.eq	0xf6d8 <_ZN5mtgif9Video2Gif3runEv+0xd00>
    f668:      	cmp	w1, #0x1f
    f66c:      	b.eq	0xf6b4 <_ZN5mtgif9Video2Gif3runEv+0xcdc>
    f670:      	b	0xf6c0 <_ZN5mtgif9Video2Gif3runEv+0xce8>
    f674:      	cmn	w1, #0x2
    f678:      	b.eq	0xf6b4 <_ZN5mtgif9Video2Gif3runEv+0xcdc>
    f67c:      	cmn	w1, #0x1
    f680:      	b.eq	0xf6a8 <_ZN5mtgif9Video2Gif3runEv+0xcd0>
    f684:      	cmp	w1, #0x1d
    f688:      	b.ne	0xf6c0 <_ZN5mtgif9Video2Gif3runEv+0xce8>
    f68c:      	add	x8, x0, #0xf8
    f690:      	str	x2, [x8]
    f694:      	ret
    f698:      	cmp	w1, #0x22
    f69c:      	b.eq	0xf6e4 <_ZN5mtgif9Video2Gif3runEv+0xd0c>
    f6a0:      	cmp	w1, #0x20
    f6a4:      	b.ne	0xf6c0 <_ZN5mtgif9Video2Gif3runEv+0xce8>
    f6a8:      	add	x8, x0, #0x110
    f6ac:      	str	x2, [x8]
    f6b0:      	ret
    f6b4:      	add	x8, x0, #0x108
    f6b8:      	str	x2, [x8]
    f6bc:      	ret
    f6c0:      	cmp	w1, #0x1c
    f6c4:      	b.hi	0xf6f0 <_ZN5mtgif9Video2Gif3runEv+0xd18>
    f6c8:      	add	x8, x0, #0x10
    f6cc:      	add	x8, x8, w1, uxtw #3
    f6d0:      	str	x2, [x8]
    f6d4:      	ret
    f6d8:      	add	x8, x0, #0x100
    f6dc:      	str	x2, [x8]
    f6e0:      	ret
    f6e4:      	add	x8, x0, #0x118
    f6e8:      	str	x2, [x8]
    f6ec:      	ret
    f6f0:      	paciasp
    f6f4:      	stp	x29, x30, [sp, #-0x20]!
    f6f8:      	str	x19, [sp, #0x10]
    f6fc:      	mov	x29, sp
    f700:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
    f704:      	nop
    f708:      	adr	x1, 0x55ec
    f70c:      	ldr	x19, [x19, #0x7e8]
    f710:      	adrp	x2, 0x5000
    f714:      	add	x2, x2, #0xcc9
    f718:      	adrp	x3, 0x5000
    f71c:      	add	x3, x3, #0x901
    f720:      	add	x0, x19, #0x130
    f724:      	bl	0x133b0 <fprintf@plt>
    f728:      	add	x0, x19, #0x130
    f72c:      	bl	0x131c0 <fflush@plt>
    f730:      	bl	0x133c0 <abort@plt>
    f734:      	bti	c
    f738:      	and	w8, w1, #0xffffffe0
    f73c:      	cmp	w8, #0x40
    f740:      	cset	w0, eq
    f744:      	ret
    f748:      	bti	c
    f74c:      	add	x8, x0, w1, sxtw #3
    f750:      	ldur	d0, [x8, #-0xe0]
    f754:      	ret
    f758:      	bti	c
    f75c:      	add	x8, x0, w1, sxtw #3
    f760:      	stur	d0, [x8, #-0xe0]
    f764:      	ret
    f768:      	bti	c
    f76c:      	ldrb	w8, [x0, #0x268]
    f770:      	cbz	w8, 0xf77c <_ZN5mtgif9Video2Gif3runEv+0xda4>
    f774:      	mov	w0, wzr
    f778:      	ret
    f77c:      	paciasp
    f780:      	stp	x29, x30, [sp, #-0x30]!
    f784:      	stp	x28, x21, [sp, #0x10]
    f788:      	stp	x20, x19, [sp, #0x20]
    f78c:      	mov	x29, sp
    f790:      	sub	sp, sp, #0x210
    f794:      	ldrb	w8, [x0, #0x26a]
    f798:      	mov	x19, x0
    f79c:      	cbz	w8, 0xf7dc <_ZN5mtgif9Video2Gif3runEv+0xe04>
    f7a0:      	mov	x0, sp
    f7a4:      	mov	w1, wzr
    f7a8:      	mov	w2, #0x210              // =528
    f7ac:      	bl	0x130b0 <memset@plt>
    f7b0:      	mov	x1, sp
    f7b4:      	mov	x0, x19
    f7b8:      	bl	0xfb6c <_ZN5mtgif9Video2Gif3runEv+0x1194>
    f7bc:      	cmp	w0, #0x1
    f7c0:      	b.eq	0xf818 <_ZN5mtgif9Video2Gif3runEv+0xe40>
    f7c4:      	add	sp, sp, #0x210
    f7c8:      	ldp	x20, x19, [sp, #0x20]
    f7cc:      	ldp	x28, x21, [sp, #0x10]
    f7d0:      	ldp	x29, x30, [sp], #0x30
    f7d4:      	autiasp
    f7d8:      	ret
    f7dc:      	ldp	x8, x20, [x19]
    f7e0:      	mov	x0, x19
    f7e4:      	mov	w21, w1
    f7e8:      	mov	w1, #-0x1               // =-1
    f7ec:      	ldr	x8, [x8, #0x18]
    f7f0:      	blr	x8
    f7f4:      	ldr	x2, [x19, #0x258]
    f7f8:      	mov	x1, x0
    f7fc:      	add	x3, x19, #0x10
    f800:      	add	x4, x19, #0x269
    f804:      	and	w5, w21, #0x1
    f808:      	mov	x0, x20
    f80c:      	bl	0xfc8c <_ZN5mtgif9Video2Gif3runEv+0x12b4>
    f810:      	cmp	w0, #0x1
    f814:      	b.ne	0xf7c4 <_ZN5mtgif9Video2Gif3runEv+0xdec>
    f818:      	ldr	x8, [x19]
    f81c:      	mov	w20, w0
    f820:      	mov	x0, x19
    f824:      	mov	w1, #0x1                // =1
    f828:      	ldr	x8, [x8, #0x68]
    f82c:      	blr	x8
    f830:      	ldrb	w8, [x19, #0x268]
    f834:      	mov	w0, w20
    f838:      	cbz	w8, 0xf7c4 <_ZN5mtgif9Video2Gif3runEv+0xdec>
    f83c:      	mov	w0, wzr
    f840:      	add	sp, sp, #0x210
    f844:      	ldp	x20, x19, [sp, #0x20]
    f848:      	ldp	x28, x21, [sp, #0x10]
    f84c:      	ldp	x29, x30, [sp], #0x30
    f850:      	autiasp
    f854:      	ret
    f858:      	bti	c
    f85c:      	ldrb	w8, [x0, #0x268]
    f860:      	cbz	w8, 0xf878 <_ZN5mtgif9Video2Gif3runEv+0xea0>
    f864:      	movi	v0.2d, #0000000000000000
    f868:      	str	xzr, [x1, #0x40]
    f86c:      	stp	q0, q0, [x1]
    f870:      	stp	q0, q0, [x1, #0x20]
    f874:      	ret
    f878:      	ldr	q0, [x0, #0x220]
    f87c:      	str	q0, [x1]
    f880:      	ldp	q2, q0, [x0, #0x240]
    f884:      	ldr	x8, [x0, #0x260]
    f888:      	ldr	q1, [x0, #0x230]
    f88c:      	str	x8, [x1, #0x40]
    f890:      	stp	q2, q0, [x1, #0x20]
    f894:      	str	q1, [x1, #0x10]
    f898:      	ret
    f89c:      	bti	c
    f8a0:      	add	x0, x0, #0x10
    f8a4:      	b	0x12934 <_ZN5mtgif9Video2Gif3runEv+0x3f5c>
    f8a8:      	bti	c
    f8ac:      	ldrb	w0, [x0, #0x269]
    f8b0:      	ret
    f8b4:      	paciasp
    f8b8:      	stp	x29, x30, [sp, #-0x10]!
    f8bc:      	mov	x29, sp
    f8c0:      	ldr	x8, [x0]
    f8c4:      	mov	w1, #-0x1               // =-1
    f8c8:      	ldr	x8, [x8, #0x18]
    f8cc:      	blr	x8
    f8d0:      	mov	w0, wzr
    f8d4:      	ldp	x29, x30, [sp], #0x10
    f8d8:      	autiasp
    f8dc:      	ret
    f8e0:      	paciasp
    f8e4:      	stp	x29, x30, [sp, #-0x30]!
    f8e8:      	stp	x28, x21, [sp, #0x10]
    f8ec:      	stp	x20, x19, [sp, #0x20]
    f8f0:      	mov	x29, sp
    f8f4:      	sub	sp, sp, #0x6b0
    f8f8:      	ldr	x8, [x0]
    f8fc:      	strb	wzr, [x0, #0x26a]
    f900:      	mov	w20, w1
    f904:      	mov	w1, #-0x1               // =-1
    f908:      	mov	x19, x0
    f90c:      	ldr	x8, [x8, #0x18]
    f910:      	blr	x8
    f914:      	cbz	x0, 0xfb24 <_ZN5mtgif9Video2Gif3runEv+0x114c>
    f918:      	ldr	x8, [x19, #0x8]
    f91c:      	and	x9, x20, #0x1
    f920:      	add	x10, sp, #0x68
    f924:      	sub	x20, x0, x9
    f928:      	nop
    f92c:      	adr	x0, 0x12284 <_ZN5mtgif9Video2Gif3runEv+0x38ac>
    f930:      	add	x1, sp, #0x98
    f934:      	stp	x8, x10, [sp, #0x98]
    f938:      	str	x20, [sp, #0xa8]
    f93c:      	bl	0x133a0 <dl_iterate_phdr@plt>
    f940:      	cbz	w0, 0xf964 <_ZN5mtgif9Video2Gif3runEv+0xf8c>
    f944:      	ldr	x8, [sp, #0x78]
    f948:      	cbz	x8, 0xf964 <_ZN5mtgif9Video2Gif3runEv+0xf8c>
    f94c:      	add	x2, sp, #0x68
    f950:      	mov	x0, x19
    f954:      	mov	x1, x20
    f958:      	mov	w3, wzr
    f95c:      	bl	0x11fb0 <_ZN5mtgif9Video2Gif3runEv+0x35d8>
    f960:      	tbnz	w0, #0x0, 0xfb0c <_ZN5mtgif9Video2Gif3runEv+0x1134>
    f964:      	nop
    f968:      	adr	x0, 0x1bd2c <g_gifReader+0xc>
    f96c:      	bl	0x133f0 <pthread_rwlock_rdlock@plt>
    f970:      	adrp	x8, 0x1b000
    f974:      	adrp	x9, 0x1b000
    f978:      	ldr	x8, [x8, #0xd00]
    f97c:      	ldr	x9, [x9, #0xd08]
    f980:      	b	0xf988 <_ZN5mtgif9Video2Gif3runEv+0xfb0>
    f984:      	add	x8, x8, #0x20
    f988:      	cmp	x8, x9
    f98c:      	b.hs	0xfa5c <_ZN5mtgif9Video2Gif3runEv+0x1084>
    f990:      	ldr	x10, [x8, #0x8]
    f994:      	cmp	x10, x20
    f998:      	b.hi	0xf984 <_ZN5mtgif9Video2Gif3runEv+0xfac>
    f99c:      	ldr	x10, [x8, #0x10]
    f9a0:      	cmp	x10, x20
    f9a4:      	b.ls	0xf984 <_ZN5mtgif9Video2Gif3runEv+0xfac>
    f9a8:      	ldr	x21, [x8, #0x18]
    f9ac:      	nop
    f9b0:      	adr	x0, 0x1bd2c <g_gifReader+0xc>
    f9b4:      	bl	0x133e0 <pthread_rwlock_unlock@plt>
    f9b8:      	cbz	x21, 0xfa68 <_ZN5mtgif9Video2Gif3runEv+0x1090>
    f9bc:      	ldr	x0, [x19, #0x8]
    f9c0:      	add	x2, sp, #0x38
    f9c4:      	mov	x3, sp
    f9c8:      	mov	x1, x21
    f9cc:      	mov	w4, wzr
    f9d0:      	bl	0xf0b8 <_ZN5mtgif9Video2Gif3runEv+0x6e0>
    f9d4:      	cbnz	x0, 0xfa68 <_ZN5mtgif9Video2Gif3runEv+0x1090>
    f9d8:      	add	x0, sp, #0x98
    f9dc:      	mov	w1, wzr
    f9e0:      	mov	w2, #0x618              // =1560
    f9e4:      	bl	0x130b0 <memset@plt>
    f9e8:      	ldr	x0, [x19, #0x8]
    f9ec:      	add	x1, sp, #0x38
    f9f0:      	mov	x2, sp
    f9f4:      	add	x5, sp, #0x98
    f9f8:      	mov	x3, x20
    f9fc:      	mov	w4, #0x4                // =4
    fa00:      	bl	0x10114 <_ZN5mtgif9Video2Gif3runEv+0x173c>
    fa04:      	tbz	w0, #0x0, 0xfa68 <_ZN5mtgif9Video2Gif3runEv+0x1090>
    fa08:      	ldr	x8, [sp, #0x60]
    fa0c:      	ldr	x9, [sp, #0x20]
    fa10:      	ldur	q0, [sp, #0x50]
    fa14:      	str	xzr, [x19, #0x248]
    fa18:      	str	x8, [x19, #0x230]
    fa1c:      	ldr	w8, [sp, #0xa8]
    fa20:      	str	x9, [x19, #0x238]
    fa24:      	mov	w9, #0x3000000          // =50331648
    fa28:      	str	x8, [x19, #0x240]
    fa2c:      	str	w9, [x19, #0x250]
    fa30:      	ldp	x8, x9, [sp, #0x38]
    fa34:      	str	q0, [x19, #0x220]
    fa38:      	str	xzr, [x19, #0x260]
    fa3c:      	str	x8, [x19, #0x258]
    fa40:      	str	w9, [x19, #0x254]
    fa44:      	add	sp, sp, #0x6b0
    fa48:      	ldp	x20, x19, [sp, #0x20]
    fa4c:      	ldp	x28, x21, [sp, #0x10]
    fa50:      	ldp	x29, x30, [sp], #0x30
    fa54:      	autiasp
    fa58:      	ret
    fa5c:      	nop
    fa60:      	adr	x0, 0x1bd2c <g_gifReader+0xc>
    fa64:      	bl	0x133e0 <pthread_rwlock_unlock@plt>
    fa68:      	ldr	x8, [x19]
    fa6c:      	mov	x0, x19
    fa70:      	mov	w1, #-0x1               // =-1
    fa74:      	ldr	x8, [x8, #0x18]
    fa78:      	blr	x8
    fa7c:      	add	x8, sp, #0x38
    fa80:      	mov	w9, #0x8                // =8
    fa84:      	mov	x20, x0
    fa88:      	stp	x8, x9, [sp, #0x98]
    fa8c:      	stp	x0, x9, [sp]
    fa90:      	bl	0x13400 <getpid@plt>
    fa94:      	mov	w1, w0
    fa98:      	add	x2, sp, #0x98
    fa9c:      	mov	x4, sp
    faa0:      	mov	w0, #0x10e              // =270
    faa4:      	mov	w3, #0x1                // =1
    faa8:      	mov	w5, #0x1                // =1
    faac:      	mov	w6, wzr
    fab0:      	mov	w21, #0x1               // =1
    fab4:      	bl	0x13410 <syscall@plt>
    fab8:      	cmp	x0, #0x8
    fabc:      	b.ne	0xfb44 <_ZN5mtgif9Video2Gif3runEv+0x116c>
    fac0:      	ldr	w8, [sp, #0x38]
    fac4:      	mov	w9, #0x1168             // =4456
    fac8:      	movk	w9, #0xd280, lsl #16
    facc:      	cmp	w8, w9
    fad0:      	b.ne	0xfb44 <_ZN5mtgif9Video2Gif3runEv+0x116c>
    fad4:      	ldr	w8, [sp, #0x3c]
    fad8:      	mov	w9, #0x1                // =1
    fadc:      	movk	w9, #0xd400, lsl #16
    fae0:      	cmp	w8, w9
    fae4:      	b.ne	0xfb44 <_ZN5mtgif9Video2Gif3runEv+0x116c>
    fae8:      	movi	v0.2d, #0000000000000000
    faec:      	add	x8, x20, #0x4
    faf0:      	str	xzr, [x19, #0x260]
    faf4:      	str	x8, [x19, #0x228]
    faf8:      	mov	w8, #0x1                // =1
    fafc:      	str	x20, [x19, #0x220]
    fb00:      	strb	w8, [x19, #0x26a]
    fb04:      	stp	q0, q0, [x19, #0x240]
    fb08:      	str	q0, [x19, #0x230]
    fb0c:      	add	sp, sp, #0x6b0
    fb10:      	ldp	x20, x19, [sp, #0x20]
    fb14:      	ldp	x28, x21, [sp, #0x10]
    fb18:      	ldp	x29, x30, [sp], #0x30
    fb1c:      	autiasp
    fb20:      	ret
    fb24:      	mov	w8, #0x1                // =1
    fb28:      	strb	w8, [x19, #0x268]
    fb2c:      	add	sp, sp, #0x6b0
    fb30:      	ldp	x20, x19, [sp, #0x20]
    fb34:      	ldp	x28, x21, [sp, #0x10]
    fb38:      	ldp	x29, x30, [sp], #0x30
    fb3c:      	autiasp
    fb40:      	ret
    fb44:      	strb	w21, [x19, #0x268]
    fb48:      	add	sp, sp, #0x6b0
    fb4c:      	ldp	x20, x19, [sp, #0x20]
    fb50:      	ldp	x28, x21, [sp, #0x10]
    fb54:      	ldp	x29, x30, [sp], #0x30
    fb58:      	autiasp
    fb5c:      	ret
    fb60:      	bti	c
    fb64:      	mov	w0, w1
    fb68:      	b	0x12904 <_ZN5mtgif9Video2Gif3runEv+0x3f2c>
    fb6c:      	bti	c
    fb70:      	ldr	x10, [x0, #0x108]
    fb74:      	mov	w9, #0x1                // =1
    fb78:      	ldr	x11, [x10, #0x138]
    fb7c:      	str	x11, [x0, #0x10]
    fb80:      	ldr	x11, [x10, #0x140]
    fb84:      	str	x11, [x0, #0x18]
    fb88:      	ldr	x11, [x10, #0x148]
    fb8c:      	str	x11, [x0, #0x20]
    fb90:      	ldr	x11, [x10, #0x150]
    fb94:      	str	x11, [x0, #0x28]
    fb98:      	ldr	x11, [x10, #0x158]
    fb9c:      	str	x11, [x0, #0x30]
    fba0:      	ldr	x11, [x10, #0x160]
    fba4:      	str	x11, [x0, #0x38]
    fba8:      	ldr	x11, [x10, #0x168]
    fbac:      	str	x11, [x0, #0x40]
    fbb0:      	ldr	x11, [x10, #0x170]
    fbb4:      	str	x11, [x0, #0x48]
    fbb8:      	ldr	x11, [x10, #0x178]
    fbbc:      	str	x11, [x0, #0x50]
    fbc0:      	ldr	x11, [x10, #0x180]
    fbc4:      	str	x11, [x0, #0x58]
    fbc8:      	ldr	x11, [x10, #0x188]
    fbcc:      	str	x11, [x0, #0x60]
    fbd0:      	ldr	x11, [x10, #0x190]
    fbd4:      	str	x11, [x0, #0x68]
    fbd8:      	ldr	x11, [x10, #0x198]
    fbdc:      	str	x11, [x0, #0x70]
    fbe0:      	ldr	x11, [x10, #0x1a0]
    fbe4:      	str	x11, [x0, #0x78]
    fbe8:      	ldr	x11, [x10, #0x1a8]
    fbec:      	str	x11, [x0, #0x80]
    fbf0:      	ldr	x11, [x10, #0x1b0]
    fbf4:      	str	x11, [x0, #0x88]
    fbf8:      	ldr	x11, [x10, #0x1b8]
    fbfc:      	str	x11, [x0, #0x90]
    fc00:      	ldr	x11, [x10, #0x1c0]
    fc04:      	str	x11, [x0, #0x98]
    fc08:      	ldr	x11, [x10, #0x1c8]
    fc0c:      	str	x11, [x0, #0xa0]
    fc10:      	ldr	x11, [x10, #0x1d0]
    fc14:      	str	x11, [x0, #0xa8]
    fc18:      	ldr	x11, [x10, #0x1d8]
    fc1c:      	str	x11, [x0, #0xb0]
    fc20:      	ldr	x11, [x10, #0x1e0]
    fc24:      	str	x11, [x0, #0xb8]
    fc28:      	ldr	x11, [x10, #0x1e8]
    fc2c:      	str	x11, [x0, #0xc0]
    fc30:      	ldr	x11, [x10, #0x1f0]
    fc34:      	str	x11, [x0, #0xc8]
    fc38:      	ldr	x11, [x10, #0x1f8]
    fc3c:      	str	x11, [x0, #0xd0]
    fc40:      	ldr	x11, [x10, #0x200]
    fc44:      	str	x11, [x0, #0xd8]
    fc48:      	ldr	x11, [x10, #0x208]
    fc4c:      	str	x11, [x0, #0xe0]
    fc50:      	ldr	x11, [x10, #0x210]
    fc54:      	str	x11, [x0, #0xe8]
    fc58:      	ldr	x11, [x10, #0x218]
    fc5c:      	str	x11, [x0, #0xf0]
    fc60:      	ldr	x11, [x10, #0x220]
    fc64:      	str	x11, [x0, #0xf8]
    fc68:      	ldr	x11, [x10, #0x228]
    fc6c:      	str	x11, [x0, #0x100]
    fc70:      	ldr	x11, [x10, #0x230]
    fc74:      	str	x11, [x0, #0x108]
    fc78:      	ldr	x10, [x10, #0x238]
    fc7c:      	strb	w9, [x0, #0x269]
    fc80:      	str	x10, [x0, #0x110]
    fc84:      	mov	w0, #0x1                // =1
    fc88:      	ret
    fc8c:      	paciasp
    fc90:      	stp	x29, x30, [sp, #-0x60]!
    fc94:      	stp	x28, x27, [sp, #0x10]
    fc98:      	stp	x26, x25, [sp, #0x20]
    fc9c:      	stp	x24, x23, [sp, #0x30]
    fca0:      	stp	x22, x21, [sp, #0x40]
    fca4:      	stp	x20, x19, [sp, #0x50]
    fca8:      	mov	x29, sp
    fcac:      	sub	sp, sp, #0xb10
    fcb0:      	mov	x8, x2
    fcb4:      	mov	x21, x4
    fcb8:      	mov	x19, x3
    fcbc:      	mov	x22, x1
    fcc0:      	sub	x2, x29, #0x50
    fcc4:      	sub	x3, x29, #0x88
    fcc8:      	mov	x1, x8
    fccc:      	mov	w4, wzr
    fcd0:      	mov	w23, w5
    fcd4:      	mov	x20, x0
    fcd8:      	bl	0xf0b8 <_ZN5mtgif9Video2Gif3runEv+0x6e0>
    fcdc:      	cbnz	x0, 0xfdbc <_ZN5mtgif9Video2Gif3runEv+0x13e4>
    fce0:      	add	x0, sp, #0x470
    fce4:      	mov	w1, wzr
    fce8:      	mov	w2, #0x618              // =1560
    fcec:      	bl	0x130b0 <memset@plt>
    fcf0:      	sub	x1, x29, #0x50
    fcf4:      	sub	x2, x29, #0x88
    fcf8:      	add	x5, sp, #0x470
    fcfc:      	mov	x0, x20
    fd00:      	mov	x3, x22
    fd04:      	mov	w4, #0x4                // =4
    fd08:      	bl	0x10114 <_ZN5mtgif9Video2Gif3runEv+0x173c>
    fd0c:      	tbz	w0, #0x0, 0xfdbc <_ZN5mtgif9Video2Gif3runEv+0x13e4>
    fd10:      	add	x1, sp, #0x470
    fd14:      	mov	x0, x20
    fd18:      	mov	x2, x19
    fd1c:      	add	x24, sp, #0x470
    fd20:      	bl	0x10d5c <_ZN5mtgif9Video2Gif3runEv+0x2384>
    fd24:      	mov	x22, x0
    fd28:      	tbz	w23, #0x0, 0xfd54 <_ZN5mtgif9Video2Gif3runEv+0x137c>
    fd2c:      	ldurb	w8, [x29, #-0x54]
    fd30:      	cbz	w8, 0xfd54 <_ZN5mtgif9Video2Gif3runEv+0x137c>
    fd34:      	ldr	x8, [x19, #0xf8]
    fd38:      	and	x8, x8, #0xfffffffffffffff0
    fd3c:      	cmp	x8, x22
    fd40:      	b.hs	0xfd54 <_ZN5mtgif9Video2Gif3runEv+0x137c>
    fd44:      	stg	x8, [x8]
    fd48:      	add	x8, x8, #0x10
    fd4c:      	cmp	x8, x22
    fd50:      	b.lo	0xfd44 <_ZN5mtgif9Video2Gif3runEv+0x136c>
    fd54:      	add	x0, sp, #0x260
    fd58:      	mov	x1, x19
    fd5c:      	mov	w2, #0x210              // =528
    fd60:      	add	x25, sp, #0x260
    fd64:      	bl	0x12e70 <memcpy@plt>
    fd68:      	add	x9, x25, #0xf8
    fd6c:      	add	x8, x25, #0xe8
    fd70:      	add	x10, x19, #0xf8
    fd74:      	stp	x8, x9, [sp, #0x18]
    fd78:      	add	x9, x25, #0x100
    fd7c:      	add	x8, x25, #0xf0
    fd80:      	stp	x8, x9, [sp, #0x8]
    fd84:      	add	x9, x25, #0x108
    fd88:      	add	x8, x19, #0xe8
    fd8c:      	stp	x8, x9, [sp, #0x40]
    fd90:      	add	x8, x19, #0x100
    fd94:      	mov	x26, xzr
    fd98:      	mov	x23, xzr
    fd9c:      	add	x28, x19, #0x108
    fda0:      	stp	x10, x8, [sp, #0x30]
    fda4:      	add	x8, x19, #0xf0
    fda8:      	add	x24, x24, #0x18
    fdac:      	add	x27, sp, #0x260
    fdb0:      	str	x22, [sp, #0x358]
    fdb4:      	str	x8, [sp, #0x28]
    fdb8:      	b	0xfe14 <_ZN5mtgif9Video2Gif3runEv+0x143c>
    fdbc:      	mov	w0, #-0x1992            // =-6546
    fdc0:      	add	sp, sp, #0xb10
    fdc4:      	ldp	x20, x19, [sp, #0x50]
    fdc8:      	ldp	x22, x21, [sp, #0x40]
    fdcc:      	ldp	x24, x23, [sp, #0x30]
    fdd0:      	ldp	x26, x25, [sp, #0x20]
    fdd4:      	ldp	x28, x27, [sp, #0x10]
    fdd8:      	ldp	x29, x30, [sp], #0x60
    fddc:      	autiasp
    fde0:      	ret
    fde4:      	ldr	x8, [x24, #0x8]
    fde8:      	mov	x9, #-0x4000000000      // =-274877906944
    fdec:      	add	x8, x9, x8, lsl #32
    fdf0:      	add	x8, x19, x8, asr #29
    fdf4:      	ldr	d0, [x8, #0x110]
    fdf8:      	add	x8, x25, x26, lsl #3
    fdfc:      	stur	d0, [x8, #-0xf0]
    fe00:      	add	x26, x26, #0x1
    fe04:      	add	x24, x24, #0x10
    fe08:      	add	x27, x27, #0x8
    fe0c:      	cmp	x26, #0x60
    fe10:      	b.eq	0xffd4 <_ZN5mtgif9Video2Gif3runEv+0x15fc>
    fe14:      	ldr	w8, [x24]
    fe18:      	cbz	w8, 0xfe50 <_ZN5mtgif9Video2Gif3runEv+0x1478>
    fe1c:      	and	w9, w26, #0x60
    fe20:      	cmp	w9, #0x40
    fe24:      	b.ne	0xfe8c <_ZN5mtgif9Video2Gif3runEv+0x14b4>
    fe28:      	cmp	w8, #0x4
    fe2c:      	b.gt	0xfeb4 <_ZN5mtgif9Video2Gif3runEv+0x14dc>
    fe30:      	movi	d0, #0000000000000000
    fe34:      	cmp	w8, #0x1
    fe38:      	b.eq	0xfdf8 <_ZN5mtgif9Video2Gif3runEv+0x1420>
    fe3c:      	cmp	w8, #0x2
    fe40:      	b.ne	0x10078 <_ZN5mtgif9Video2Gif3runEv+0x16a0>
    fe44:      	ldr	x8, [x24, #0x8]
    fe48:      	ldr	d0, [x8, x22]
    fe4c:      	b	0xfdf8 <_ZN5mtgif9Video2Gif3runEv+0x1420>
    fe50:      	ldurb	w8, [x29, #-0x56]
    fe54:      	cmp	x26, x8
    fe58:      	b.ne	0xfe00 <_ZN5mtgif9Video2Gif3runEv+0x1428>
    fe5c:      	cmp	w8, #0x1e
    fe60:      	b.le	0xff54 <_ZN5mtgif9Video2Gif3runEv+0x157c>
    fe64:      	cmp	w8, #0x22
    fe68:      	mov	x9, x28
    fe6c:      	b.eq	0xff78 <_ZN5mtgif9Video2Gif3runEv+0x15a0>
    fe70:      	ldr	x9, [sp, #0x38]
    fe74:      	cmp	w8, #0x20
    fe78:      	b.eq	0xff78 <_ZN5mtgif9Video2Gif3runEv+0x15a0>
    fe7c:      	ldr	x9, [sp, #0x30]
    fe80:      	cmp	w8, #0x1f
    fe84:      	b.eq	0xff78 <_ZN5mtgif9Video2Gif3runEv+0x15a0>
    fe88:      	b	0xff6c <_ZN5mtgif9Video2Gif3runEv+0x1594>
    fe8c:      	ldurb	w8, [x29, #-0x56]
    fe90:      	cmp	x26, x8
    fe94:      	b.ne	0xfee0 <_ZN5mtgif9Video2Gif3runEv+0x1508>
    fe98:      	mov	x0, x20
    fe9c:      	mov	x1, x19
    fea0:      	mov	x2, x22
    fea4:      	mov	x3, x24
    fea8:      	bl	0x10e90 <_ZN5mtgif9Video2Gif3runEv+0x24b8>
    feac:      	mov	x23, x0
    feb0:      	b	0xfe00 <_ZN5mtgif9Video2Gif3runEv+0x1428>
    feb4:      	cmp	w8, #0x5
    feb8:      	b.eq	0xfde4 <_ZN5mtgif9Video2Gif3runEv+0x140c>
    febc:      	cmp	w8, #0x6
    fec0:      	b.ne	0x10078 <_ZN5mtgif9Video2Gif3runEv+0x16a0>
    fec4:      	ldr	x0, [x24, #0x8]
    fec8:      	mov	x1, x20
    fecc:      	mov	x2, x19
    fed0:      	mov	x3, x22
    fed4:      	bl	0x115f4 <_ZN5mtgif9Video2Gif3runEv+0x2c1c>
    fed8:      	ldr	d0, [x0]
    fedc:      	b	0xfdf8 <_ZN5mtgif9Video2Gif3runEv+0x1420>
    fee0:      	cmp	x26, #0x22
    fee4:      	b.ne	0xff08 <_ZN5mtgif9Video2Gif3runEv+0x1530>
    fee8:      	mov	x0, x20
    feec:      	mov	x1, x19
    fef0:      	mov	x2, x22
    fef4:      	mov	x3, x24
    fef8:      	bl	0x10e90 <_ZN5mtgif9Video2Gif3runEv+0x24b8>
    fefc:      	ldr	x8, [sp, #0x48]
    ff00:      	str	x0, [x8]
    ff04:      	b	0xfe00 <_ZN5mtgif9Video2Gif3runEv+0x1428>
    ff08:      	sub	w8, w26, #0x40
    ff0c:      	cmn	w8, #0x20
    ff10:      	b.hi	0x10070 <_ZN5mtgif9Video2Gif3runEv+0x1698>
    ff14:      	mov	x0, x20
    ff18:      	mov	x1, x19
    ff1c:      	mov	x2, x22
    ff20:      	mov	x3, x24
    ff24:      	bl	0x10e90 <_ZN5mtgif9Video2Gif3runEv+0x24b8>
    ff28:      	cmp	w26, #0x1e
    ff2c:      	b.le	0xff80 <_ZN5mtgif9Video2Gif3runEv+0x15a8>
    ff30:      	cmp	w26, #0x1f
    ff34:      	b.eq	0xff9c <_ZN5mtgif9Video2Gif3runEv+0x15c4>
    ff38:      	cmp	w26, #0x22
    ff3c:      	b.eq	0xffa8 <_ZN5mtgif9Video2Gif3runEv+0x15d0>
    ff40:      	cmp	w26, #0x20
    ff44:      	b.ne	0xffc0 <_ZN5mtgif9Video2Gif3runEv+0x15e8>
    ff48:      	ldr	x8, [sp, #0x10]
    ff4c:      	str	x0, [x8]
    ff50:      	b	0xfe00 <_ZN5mtgif9Video2Gif3runEv+0x1428>
    ff54:      	ldr	x9, [sp, #0x40]
    ff58:      	cmp	w8, #0x1d
    ff5c:      	b.eq	0xff78 <_ZN5mtgif9Video2Gif3runEv+0x15a0>
    ff60:      	ldr	x9, [sp, #0x28]
    ff64:      	cmp	w8, #0x1e
    ff68:      	b.eq	0xff78 <_ZN5mtgif9Video2Gif3runEv+0x15a0>
    ff6c:      	cmp	w8, #0x1c
    ff70:      	b.hi	0x100ac <_ZN5mtgif9Video2Gif3runEv+0x16d4>
    ff74:      	add	x9, x19, x8, lsl #3
    ff78:      	ldr	x23, [x9]
    ff7c:      	b	0xfe00 <_ZN5mtgif9Video2Gif3runEv+0x1428>
    ff80:      	cmp	w26, #0x1d
    ff84:      	b.eq	0xffb4 <_ZN5mtgif9Video2Gif3runEv+0x15dc>
    ff88:      	cmp	w26, #0x1e
    ff8c:      	b.ne	0xffc0 <_ZN5mtgif9Video2Gif3runEv+0x15e8>
    ff90:      	ldr	x8, [sp, #0x8]
    ff94:      	str	x0, [x8]
    ff98:      	b	0xfe00 <_ZN5mtgif9Video2Gif3runEv+0x1428>
    ff9c:      	ldr	x8, [sp, #0x20]
    ffa0:      	str	x0, [x8]
    ffa4:      	b	0xfe00 <_ZN5mtgif9Video2Gif3runEv+0x1428>
    ffa8:      	ldr	x8, [sp, #0x48]
    ffac:      	str	x0, [x8]
    ffb0:      	b	0xfe00 <_ZN5mtgif9Video2Gif3runEv+0x1428>
    ffb4:      	ldr	x8, [sp, #0x18]
    ffb8:      	str	x0, [x8]
    ffbc:      	b	0xfe00 <_ZN5mtgif9Video2Gif3runEv+0x1428>
    ffc0:      	cmp	x26, #0x1d
    ffc4:      	mov	x8, x27
    ffc8:      	b.hs	0x100e0 <_ZN5mtgif9Video2Gif3runEv+0x1708>
    ffcc:      	str	x0, [x8]
    ffd0:      	b	0xfe00 <_ZN5mtgif9Video2Gif3runEv+0x1428>
    ffd4:      	ldurb	w8, [x29, #-0x58]
    ffd8:      	add	x0, sp, #0x50
    ffdc:      	mov	x1, x19
    ffe0:      	mov	w2, #0x210              // =528
    ffe4:      	strb	w8, [x21]
    ffe8:      	bl	0x12e70 <memcpy@plt>
    ffec:      	add	x8, sp, #0x470
    fff0:      	add	x8, x8, #0x238
    fff4:      	ldr	q0, [x8]
    fff8:      	stur	q0, [x29, #-0x20]
    fffc:      	ldur	w8, [x29, #-0x20]
   10000:      	cbz	w8, 0x10020 <_ZN5mtgif9Video2Gif3runEv+0x1648>
   10004:      	add	x1, sp, #0x50
   10008:      	sub	x3, x29, #0x20
   1000c:      	mov	x0, x20
   10010:      	mov	x2, x22
   10014:      	bl	0x10e90 <_ZN5mtgif9Video2Gif3runEv+0x24b8>
   10018:      	tbnz	w0, #0x0, 0x10028 <_ZN5mtgif9Video2Gif3runEv+0x1650>
   1001c:      	b	0x10054 <_ZN5mtgif9Video2Gif3runEv+0x167c>
   10020:      	ldur	x0, [x29, #-0x18]
   10024:      	tbz	w0, #0x0, 0x10054 <_ZN5mtgif9Video2Gif3runEv+0x167c>
   10028:      	cbz	x23, 0x10054 <_ZN5mtgif9Video2Gif3runEv+0x167c>
   1002c:      	ldurb	w8, [x29, #-0x55]
   10030:      	cbz	w8, 0x10044 <_ZN5mtgif9Video2Gif3runEv+0x166c>
   10034:      	mov	x17, x23
   10038:      	mov	x16, x22
   1003c:      	autib1716
   10040:      	b	0x10050 <_ZN5mtgif9Video2Gif3runEv+0x1678>
   10044:      	mov	x17, x23
   10048:      	mov	x16, x22
   1004c:      	autia1716
   10050:      	mov	x23, x17
   10054:      	add	x1, sp, #0x260
   10058:      	mov	x0, x19
   1005c:      	mov	w2, #0x210              // =528
   10060:      	str	x23, [sp, #0x360]
   10064:      	bl	0x12e70 <memcpy@plt>
   10068:      	mov	w0, #0x1                // =1
   1006c:      	b	0xfdc0 <_ZN5mtgif9Video2Gif3runEv+0x13e8>
   10070:      	mov	w0, #-0x198e            // =-6542
   10074:      	b	0xfdc0 <_ZN5mtgif9Video2Gif3runEv+0x13e8>
   10078:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   1007c:      	nop
   10080:      	adr	x1, 0x55ec
   10084:      	ldr	x19, [x19, #0x7e8]
   10088:      	adrp	x2, 0x5000
   1008c:      	add	x2, x2, #0x675
   10090:      	adrp	x3, 0x5000
   10094:      	add	x3, x3, #0xa04
   10098:      	add	x0, x19, #0x130
   1009c:      	bl	0x133b0 <fprintf@plt>
   100a0:      	add	x0, x19, #0x130
   100a4:      	bl	0x131c0 <fflush@plt>
   100a8:      	bl	0x133c0 <abort@plt>
   100ac:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   100b0:      	nop
   100b4:      	adr	x1, 0x55ec
   100b8:      	ldr	x19, [x19, #0x7e8]
   100bc:      	adrp	x2, 0x5000
   100c0:      	add	x2, x2, #0xae3
   100c4:      	adrp	x3, 0x5000
   100c8:      	add	x3, x3, #0x901
   100cc:      	add	x0, x19, #0x130
   100d0:      	bl	0x133b0 <fprintf@plt>
   100d4:      	add	x0, x19, #0x130
   100d8:      	bl	0x131c0 <fflush@plt>
   100dc:      	bl	0x133c0 <abort@plt>
   100e0:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   100e4:      	nop
   100e8:      	adr	x1, 0x55ec
   100ec:      	ldr	x19, [x19, #0x7e8]
   100f0:      	adrp	x2, 0x5000
   100f4:      	add	x2, x2, #0xcc9
   100f8:      	adrp	x3, 0x5000
   100fc:      	add	x3, x3, #0x901
   10100:      	add	x0, x19, #0x130
   10104:      	bl	0x133b0 <fprintf@plt>
   10108:      	add	x0, x19, #0x130
   1010c:      	bl	0x131c0 <fflush@plt>
   10110:      	bl	0x133c0 <abort@plt>
   10114:      	paciasp
   10118:      	stp	x29, x30, [sp, #-0x60]!
   1011c:      	stp	x28, x27, [sp, #0x10]
   10120:      	stp	x26, x25, [sp, #0x20]
   10124:      	stp	x24, x23, [sp, #0x30]
   10128:      	stp	x22, x21, [sp, #0x40]
   1012c:      	stp	x20, x19, [sp, #0x50]
   10130:      	mov	x29, sp
   10134:      	sub	sp, sp, #0x680
   10138:      	ldp	x10, x8, [x2, #0x8]
   1013c:      	mov	x19, sp
   10140:      	ldr	x9, [x2]
   10144:      	ldp	x11, x12, [x1, #0x10]
   10148:      	mov	x20, x5
   1014c:      	mov	w28, w4
   10150:      	mov	x22, x2
   10154:      	add	x9, x10, x9
   10158:      	mov	x27, xzr
   1015c:      	nop
   10160:      	adr	x23, 0x6236 <_ZTS10CQuantizer+0xe>
   10164:      	stp	x8, x9, [x29, #-0x38]
   10168:      	mov	x8, #-0x1               // =-1
   1016c:      	ldp	x9, x10, [x1]
   10170:      	stp	x8, x11, [x29, #-0x28]
   10174:      	stp	x0, xzr, [x19, #0x18]
   10178:      	add	x8, x10, x9
   1017c:      	sub	x9, x3, x12
   10180:      	stp	x8, x9, [x29, #-0x18]
   10184:      	add	x8, x19, #0x28
   10188:      	add	x9, x5, #0x238
   1018c:      	add	x8, x8, #0x238
   10190:      	stp	x8, x9, [x19, #0x8]
   10194:      	b	0x101a4 <_ZN5mtgif9Video2Gif3runEv+0x17cc>
   10198:      	add	x27, x27, #0x18
   1019c:      	cmp	x27, #0x30
   101a0:      	b.eq	0x10ad0 <_ZN5mtgif9Video2Gif3runEv+0x20f8>
   101a4:      	sub	x8, x29, #0x38
   101a8:      	add	x8, x8, x27
   101ac:      	ldp	x9, x24, [x8]
   101b0:      	ldr	x21, [x8, #0x10]
   101b4:      	cmp	x9, x24
   101b8:      	stur	x9, [x29, #-0x40]
   101bc:      	ccmp	x21, #0x0, #0x4, lo
   101c0:      	b.eq	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   101c4:      	mov	x25, xzr
   101c8:      	mov	x8, x9
   101cc:      	ldrb	w10, [x8], #0x1
   101d0:      	stur	x8, [x29, #-0x40]
   101d4:      	cmp	w10, #0x2f
   101d8:      	b.hi	0x107c8 <_ZN5mtgif9Video2Gif3runEv+0x1df0>
   101dc:      	adr	x11, 0x101ec <_ZN5mtgif9Video2Gif3runEv+0x1814>
   101e0:      	ldrh	w12, [x23, x10, lsl #1]
   101e4:      	add	x11, x11, x12, lsl #2
   101e8:      	br	x11
   101ec:      	bti	j
   101f0:      	ldrb	w3, [x22, #0x18]
   101f4:      	ldr	x0, [x19, #0x18]
   101f8:      	sub	x1, x29, #0x40
   101fc:      	mov	x2, x24
   10200:      	mov	x4, xzr
   10204:      	bl	0x110a0 <_ZN5mtgif9Video2Gif3runEv+0x26c8>
   10208:      	mov	x25, x0
   1020c:      	ldur	x9, [x29, #-0x40]
   10210:      	cmp	x9, x24
   10214:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   10218:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   1021c:      	bti	j
   10220:      	sub	x0, x29, #0x40
   10224:      	mov	x1, x24
   10228:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   1022c:      	ldur	x10, [x29, #-0x40]
   10230:      	mov	x9, xzr
   10234:      	mov	x8, xzr
   10238:      	mov	x12, x10
   1023c:      	cmp	x12, x24
   10240:      	b.eq	0x10cc0 <_ZN5mtgif9Video2Gif3runEv+0x22e8>
   10244:      	ldrb	w11, [x12], #0x1
   10248:      	add	x10, x10, #0x1
   1024c:      	and	x13, x11, #0x7f
   10250:      	lsl	x13, x13, x9
   10254:      	add	x9, x9, #0x7
   10258:      	orr	x8, x13, x8
   1025c:      	tbnz	w11, #0x7, 0x1023c <_ZN5mtgif9Video2Gif3runEv+0x1864>
   10260:      	cmp	x0, #0x60
   10264:      	stur	x10, [x29, #-0x40]
   10268:      	b.hs	0x10c18 <_ZN5mtgif9Video2Gif3runEv+0x2240>
   1026c:      	sub	w10, w9, #0x7
   10270:      	mov	x12, #-0x1              // =-1
   10274:      	cmp	w10, #0x39
   10278:      	mov	w10, #0x3f              // =63
   1027c:      	lsl	x9, x12, x9
   10280:      	ccmp	w11, w10, #0x0, lo
   10284:      	ldr	w10, [x22, #0x2c]
   10288:      	csel	w9, w9, wzr, hi
   1028c:      	orr	w8, w8, w9
   10290:      	mul	w8, w10, w8
   10294:      	stp	w0, w8, [x20]
   10298:      	ldur	x9, [x29, #-0x40]
   1029c:      	cmp	x9, x24
   102a0:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   102a4:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   102a8:      	bti	j
   102ac:      	sub	x0, x29, #0x40
   102b0:      	mov	x1, x24
   102b4:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   102b8:      	cmp	x0, #0x60
   102bc:      	b.hs	0x10b04 <_ZN5mtgif9Video2Gif3runEv+0x212c>
   102c0:      	ldur	x9, [x29, #-0x40]
   102c4:      	mov	x10, xzr
   102c8:      	mov	x8, xzr
   102cc:      	mov	x12, x9
   102d0:      	cmp	x12, x24
   102d4:      	b.eq	0x10d28 <_ZN5mtgif9Video2Gif3runEv+0x2350>
   102d8:      	ldrb	w11, [x12], #0x1
   102dc:      	add	x9, x9, #0x1
   102e0:      	and	x13, x11, #0x7f
   102e4:      	lsl	x13, x13, x10
   102e8:      	add	x10, x10, #0x7
   102ec:      	orr	x8, x13, x8
   102f0:      	tbnz	w11, #0x7, 0x102d0 <_ZN5mtgif9Video2Gif3runEv+0x18f8>
   102f4:      	add	x12, x20, x0, lsl #4
   102f8:      	sub	w13, w10, #0x7
   102fc:      	mov	x15, #-0x1              // =-1
   10300:      	cmp	w13, #0x39
   10304:      	mov	w14, #0x3f              // =63
   10308:      	lsl	x15, x15, x10
   1030c:      	mov	x13, x12
   10310:      	ccmp	w11, w14, #0x0, lo
   10314:      	ldrsw	x10, [x22, #0x2c]
   10318:      	ldrb	w16, [x13, #0x1c]!
   1031c:      	csel	x11, x15, xzr, hi
   10320:      	stur	x9, [x29, #-0x40]
   10324:      	cbnz	w16, 0x10348 <_ZN5mtgif9Video2Gif3runEv+0x1970>
   10328:      	lsl	x9, x0, #4
   1032c:      	add	x15, x19, #0x28
   10330:      	add	x14, x20, x9
   10334:      	add	x9, x15, x9
   10338:      	ldur	q0, [x14, #0x18]
   1033c:      	mov	w14, #0x1               // =1
   10340:      	strb	w14, [x13]
   10344:      	stur	q0, [x9, #0x18]
   10348:      	orr	x8, x8, x11
   1034c:      	mov	w9, #0x4                // =4
   10350:      	b	0x1095c <_ZN5mtgif9Video2Gif3runEv+0x1f84>
   10354:      	bti	j
   10358:      	sub	x0, x29, #0x40
   1035c:      	mov	x1, x24
   10360:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   10364:      	cmp	x0, #0x60
   10368:      	b.hs	0x10ad8 <_ZN5mtgif9Video2Gif3runEv+0x2100>
   1036c:      	str	w0, [x20]
   10370:      	ldur	x9, [x29, #-0x40]
   10374:      	cmp	x9, x24
   10378:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   1037c:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   10380:      	bti	j
   10384:      	sub	x0, x29, #0x40
   10388:      	mov	x1, x24
   1038c:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   10390:      	cmp	x0, #0x60
   10394:      	b.hs	0x10b68 <_ZN5mtgif9Video2Gif3runEv+0x2190>
   10398:      	mov	x26, x0
   1039c:      	sub	x0, x29, #0x40
   103a0:      	mov	x1, x24
   103a4:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   103a8:      	add	x8, x20, x26, lsl #4
   103ac:      	ldrsw	x9, [x22, #0x2c]
   103b0:      	mov	x10, x8
   103b4:      	ldrb	w11, [x10, #0x1c]!
   103b8:      	cbnz	w11, 0x103dc <_ZN5mtgif9Video2Gif3runEv+0x1a04>
   103bc:      	lsl	x11, x26, #4
   103c0:      	add	x13, x19, #0x28
   103c4:      	add	x12, x20, x11
   103c8:      	add	x11, x13, x11
   103cc:      	ldur	q0, [x12, #0x18]
   103d0:      	mov	w12, #0x1               // =1
   103d4:      	strb	w12, [x10]
   103d8:      	stur	q0, [x11, #0x18]
   103dc:      	mneg	x9, x0, x9
   103e0:      	b	0x105ec <_ZN5mtgif9Video2Gif3runEv+0x1c14>
   103e4:      	bti	j
   103e8:      	cmp	w28, #0x4
   103ec:      	b.ne	0x10a98 <_ZN5mtgif9Video2Gif3runEv+0x20c0>
   103f0:      	ldrb	w8, [x20, #0x23c]
   103f4:      	cbnz	w8, 0x1040c <_ZN5mtgif9Video2Gif3runEv+0x1a34>
   103f8:      	ldp	x9, x8, [x19, #0x8]
   103fc:      	ldr	q0, [x8]
   10400:      	mov	w8, #0x1                // =1
   10404:      	strb	w8, [x20, #0x23c]
   10408:      	str	q0, [x9]
   1040c:      	ldr	x8, [x20, #0x240]
   10410:      	eor	x8, x8, #0x1
   10414:      	str	x8, [x20, #0x240]
   10418:      	ldur	x9, [x29, #-0x40]
   1041c:      	cmp	x9, x24
   10420:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   10424:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   10428:      	bti	j
   1042c:      	sub	x26, sp, #0x620
   10430:      	mov	sp, x26
   10434:      	ldr	x8, [x19, #0x20]
   10438:      	mov	x0, x26
   1043c:      	mov	x1, x20
   10440:      	mov	w2, #0x618              // =1560
   10444:      	str	x8, [x0], #0x8
   10448:      	bl	0x12e70 <memcpy@plt>
   1044c:      	str	x26, [x19, #0x20]
   10450:      	ldur	x9, [x29, #-0x40]
   10454:      	cmp	x9, x24
   10458:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   1045c:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   10460:      	bti	j
   10464:      	ldrb	w8, [x9, #0x1]
   10468:      	ldr	w10, [x22, #0x28]
   1046c:      	add	x9, x9, #0x2
   10470:      	b	0x10650 <_ZN5mtgif9Video2Gif3runEv+0x1c78>
   10474:      	bti	j
   10478:      	ldur	w8, [x9, #0x1]
   1047c:      	ldr	w10, [x22, #0x28]
   10480:      	add	x9, x9, #0x5
   10484:      	b	0x10650 <_ZN5mtgif9Video2Gif3runEv+0x1c78>
   10488:      	bti	j
   1048c:      	sub	x0, x29, #0x40
   10490:      	mov	x1, x24
   10494:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   10498:      	cmp	x0, #0x60
   1049c:      	b.hs	0x10ae8 <_ZN5mtgif9Video2Gif3runEv+0x2110>
   104a0:      	add	x8, x20, x0, lsl #4
   104a4:      	mov	x9, x8
   104a8:      	ldrb	w10, [x9, #0x1c]!
   104ac:      	cbnz	w10, 0x104d0 <_ZN5mtgif9Video2Gif3runEv+0x1af8>
   104b0:      	lsl	x10, x0, #4
   104b4:      	add	x12, x19, #0x28
   104b8:      	add	x11, x20, x10
   104bc:      	add	x10, x12, x10
   104c0:      	ldur	q0, [x11, #0x18]
   104c4:      	mov	w11, #0x1               // =1
   104c8:      	strb	w11, [x9]
   104cc:      	stur	q0, [x10, #0x18]
   104d0:      	ldur	x9, [x29, #-0x40]
   104d4:      	mov	w10, #0x7               // =7
   104d8:      	b	0x109c8 <_ZN5mtgif9Video2Gif3runEv+0x1ff0>
   104dc:      	bti	j
   104e0:      	sub	x0, x29, #0x40
   104e4:      	mov	x1, x24
   104e8:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   104ec:      	mov	x26, x0
   104f0:      	sub	x0, x29, #0x40
   104f4:      	mov	x1, x24
   104f8:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   104fc:      	cmp	x26, #0x60
   10500:      	b.hs	0x10b84 <_ZN5mtgif9Video2Gif3runEv+0x21ac>
   10504:      	stp	w26, w0, [x20]
   10508:      	ldur	x9, [x29, #-0x40]
   1050c:      	cmp	x9, x24
   10510:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   10514:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   10518:      	bti	j
   1051c:      	mov	x10, xzr
   10520:      	mov	x9, xzr
   10524:      	mov	x11, x8
   10528:      	cmp	x11, x24
   1052c:      	b.eq	0x10c8c <_ZN5mtgif9Video2Gif3runEv+0x22b4>
   10530:      	ldrb	w12, [x11], #0x1
   10534:      	add	x8, x8, #0x1
   10538:      	and	x13, x12, #0x7f
   1053c:      	lsl	x13, x13, x10
   10540:      	add	x10, x10, #0x7
   10544:      	orr	x9, x13, x9
   10548:      	tbnz	w12, #0x7, 0x10528 <_ZN5mtgif9Video2Gif3runEv+0x1b50>
   1054c:      	sub	w11, w10, #0x7
   10550:      	mov	x13, #-0x1              // =-1
   10554:      	stur	x8, [x29, #-0x40]
   10558:      	cmp	w11, #0x39
   1055c:      	mov	w11, #0x3f              // =63
   10560:      	lsl	x10, x13, x10
   10564:      	ccmp	w12, w11, #0x0, lo
   10568:      	ldr	w11, [x22, #0x2c]
   1056c:      	csel	w10, w10, wzr, hi
   10570:      	orr	w9, w9, w10
   10574:      	mul	w9, w11, w9
   10578:      	str	w9, [x20, #0x4]
   1057c:      	mov	x9, x8
   10580:      	cmp	x8, x24
   10584:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   10588:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   1058c:      	bti	j
   10590:      	sub	x0, x29, #0x40
   10594:      	mov	x1, x24
   10598:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   1059c:      	mov	x26, x0
   105a0:      	sub	x0, x29, #0x40
   105a4:      	mov	x1, x24
   105a8:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   105ac:      	cmp	x26, #0x60
   105b0:      	b.hs	0x10b4c <_ZN5mtgif9Video2Gif3runEv+0x2174>
   105b4:      	add	x8, x20, x26, lsl #4
   105b8:      	ldrsw	x9, [x22, #0x2c]
   105bc:      	mov	x10, x8
   105c0:      	ldrb	w11, [x10, #0x1c]!
   105c4:      	cbnz	w11, 0x105e8 <_ZN5mtgif9Video2Gif3runEv+0x1c10>
   105c8:      	lsl	x11, x26, #4
   105cc:      	add	x13, x19, #0x28
   105d0:      	add	x12, x20, x11
   105d4:      	add	x11, x13, x11
   105d8:      	ldur	q0, [x12, #0x18]
   105dc:      	mov	w12, #0x1               // =1
   105e0:      	strb	w12, [x10]
   105e4:      	stur	q0, [x11, #0x18]
   105e8:      	mul	x9, x0, x9
   105ec:      	mov	w10, #0x2               // =2
   105f0:      	str	w10, [x8, #0x18]
   105f4:      	str	x9, [x8, #0x20]
   105f8:      	ldur	x9, [x29, #-0x40]
   105fc:      	cmp	x9, x24
   10600:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   10604:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   10608:      	bti	j
   1060c:      	ldr	x8, [x19, #0x20]
   10610:      	cbz	x8, 0x10c64 <_ZN5mtgif9Video2Gif3runEv+0x228c>
   10614:      	add	x1, x8, #0x8
   10618:      	mov	x0, x20
   1061c:      	mov	w2, #0x618              // =1560
   10620:      	mov	x26, x8
   10624:      	bl	0x12e70 <memcpy@plt>
   10628:      	ldr	x26, [x26]
   1062c:      	str	x26, [x19, #0x20]
   10630:      	ldur	x9, [x29, #-0x40]
   10634:      	cmp	x9, x24
   10638:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   1063c:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   10640:      	bti	j
   10644:      	ldurh	w8, [x9, #0x1]
   10648:      	ldr	w10, [x22, #0x28]
   1064c:      	add	x9, x9, #0x3
   10650:      	mul	w8, w10, w8
   10654:      	add	x25, x25, x8
   10658:      	stur	x9, [x29, #-0x40]
   1065c:      	cmp	x9, x24
   10660:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   10664:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   10668:      	bti	j
   1066c:      	sub	x0, x29, #0x40
   10670:      	mov	x1, x24
   10674:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   10678:      	str	w0, [x20, #0x10]
   1067c:      	ldur	x9, [x29, #-0x40]
   10680:      	cmp	x9, x24
   10684:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   10688:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   1068c:      	bti	j
   10690:      	sub	x0, x29, #0x40
   10694:      	mov	x1, x24
   10698:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   1069c:      	cmp	x0, #0x60
   106a0:      	b.hs	0x10b30 <_ZN5mtgif9Video2Gif3runEv+0x2158>
   106a4:      	add	x8, x20, x0, lsl #4
   106a8:      	ldrb	w8, [x8, #0x1c]
   106ac:      	cbz	w8, 0x10a98 <_ZN5mtgif9Video2Gif3runEv+0x20c0>
   106b0:      	lsl	x8, x0, #4
   106b4:      	b	0x10a84 <_ZN5mtgif9Video2Gif3runEv+0x20ac>
   106b8:      	bti	j
   106bc:      	sub	x0, x29, #0x40
   106c0:      	mov	x1, x24
   106c4:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   106c8:      	cmp	x0, #0x60
   106cc:      	b.hs	0x10ba0 <_ZN5mtgif9Video2Gif3runEv+0x21c8>
   106d0:      	add	x8, x20, x0, lsl #4
   106d4:      	mov	x9, x8
   106d8:      	ldrb	w10, [x9, #0x1c]!
   106dc:      	cbnz	w10, 0x10700 <_ZN5mtgif9Video2Gif3runEv+0x1d28>
   106e0:      	lsl	x10, x0, #4
   106e4:      	add	x12, x19, #0x28
   106e8:      	add	x11, x20, x10
   106ec:      	add	x10, x12, x10
   106f0:      	ldur	q0, [x11, #0x18]
   106f4:      	mov	w11, #0x1               // =1
   106f8:      	strb	w11, [x9]
   106fc:      	stur	q0, [x10, #0x18]
   10700:      	mov	w9, #0x1                // =1
   10704:      	str	w9, [x8, #0x18]
   10708:      	ldur	x9, [x29, #-0x40]
   1070c:      	cmp	x9, x24
   10710:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   10714:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   10718:      	bti	j
   1071c:      	sub	x0, x29, #0x40
   10720:      	mov	x1, x24
   10724:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   10728:      	str	w0, [x20, #0x4]
   1072c:      	ldur	x9, [x29, #-0x40]
   10730:      	cmp	x9, x24
   10734:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   10738:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   1073c:      	bti	j
   10740:      	str	wzr, [x20]
   10744:      	str	x8, [x20, #0x8]
   10748:      	b	0x109d0 <_ZN5mtgif9Video2Gif3runEv+0x1ff8>
   1074c:      	bti	j
   10750:      	sub	x0, x29, #0x40
   10754:      	mov	x1, x24
   10758:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   1075c:      	mov	x26, x0
   10760:      	sub	x0, x29, #0x40
   10764:      	mov	x1, x24
   10768:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   1076c:      	cmp	x26, #0x60
   10770:      	b.hs	0x10bec <_ZN5mtgif9Video2Gif3runEv+0x2214>
   10774:      	cmp	x0, #0x60
   10778:      	b.hs	0x10c34 <_ZN5mtgif9Video2Gif3runEv+0x225c>
   1077c:      	add	x8, x20, x26, lsl #4
   10780:      	mov	x9, x8
   10784:      	ldrb	w10, [x9, #0x1c]!
   10788:      	cbnz	w10, 0x107ac <_ZN5mtgif9Video2Gif3runEv+0x1dd4>
   1078c:      	lsl	x10, x26, #4
   10790:      	add	x12, x19, #0x28
   10794:      	add	x11, x20, x10
   10798:      	add	x10, x12, x10
   1079c:      	ldur	q0, [x11, #0x18]
   107a0:      	mov	w11, #0x1               // =1
   107a4:      	strb	w11, [x9]
   107a8:      	stur	q0, [x10, #0x18]
   107ac:      	mov	w9, #0x5                // =5
   107b0:      	str	x0, [x8, #0x20]
   107b4:      	str	w9, [x8, #0x18]
   107b8:      	ldur	x9, [x29, #-0x40]
   107bc:      	cmp	x9, x24
   107c0:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   107c4:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   107c8:      	bti	j
   107cc:      	and	w8, w10, #0xc0
   107d0:      	and	x26, x10, #0x3f
   107d4:      	cmp	w8, #0x40
   107d8:      	b.eq	0x10ab4 <_ZN5mtgif9Video2Gif3runEv+0x20dc>
   107dc:      	cmp	w8, #0xc0
   107e0:      	b.eq	0x10a74 <_ZN5mtgif9Video2Gif3runEv+0x209c>
   107e4:      	cmp	w8, #0x80
   107e8:      	b.ne	0x10c64 <_ZN5mtgif9Video2Gif3runEv+0x228c>
   107ec:      	sub	x0, x29, #0x40
   107f0:      	mov	x1, x24
   107f4:      	str	w28, [x19, #0x4]
   107f8:      	mov	w28, w26
   107fc:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   10800:      	add	x8, x20, w26, uxtw #4
   10804:      	ldrsw	x9, [x22, #0x2c]
   10808:      	ldrb	w10, [x8, #0x1c]!
   1080c:      	cbnz	w10, 0x10830 <_ZN5mtgif9Video2Gif3runEv+0x1e58>
   10810:      	lsl	x10, x28, #4
   10814:      	add	x11, x20, x10
   10818:      	ldur	q0, [x11, #0x18]
   1081c:      	add	x11, x19, #0x28
   10820:      	add	x10, x11, x10
   10824:      	stur	q0, [x10, #0x18]
   10828:      	mov	w10, #0x1               // =1
   1082c:      	strb	w10, [x8]
   10830:      	mul	x8, x0, x9
   10834:      	add	x9, x20, x28, lsl #4
   10838:      	mov	w10, #0x2               // =2
   1083c:      	ldr	w28, [x19, #0x4]
   10840:      	str	w10, [x9, #0x18]
   10844:      	str	x8, [x9, #0x20]
   10848:      	ldur	x9, [x29, #-0x40]
   1084c:      	cmp	x9, x24
   10850:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   10854:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   10858:      	bti	j
   1085c:      	sub	x0, x29, #0x40
   10860:      	mov	x1, x24
   10864:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   10868:      	cmp	x0, #0x60
   1086c:      	b.hs	0x10b20 <_ZN5mtgif9Video2Gif3runEv+0x2148>
   10870:      	add	x8, x20, x0, lsl #4
   10874:      	mov	x9, x8
   10878:      	ldrb	w10, [x9, #0x1c]!
   1087c:      	cbnz	w10, 0x108a0 <_ZN5mtgif9Video2Gif3runEv+0x1ec8>
   10880:      	lsl	x10, x0, #4
   10884:      	add	x12, x19, #0x28
   10888:      	add	x11, x20, x10
   1088c:      	add	x10, x12, x10
   10890:      	ldur	q0, [x11, #0x18]
   10894:      	mov	w11, #0x1               // =1
   10898:      	strb	w11, [x9]
   1089c:      	stur	q0, [x10, #0x18]
   108a0:      	str	wzr, [x8, #0x18]
   108a4:      	ldur	x9, [x29, #-0x40]
   108a8:      	cmp	x9, x24
   108ac:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   108b0:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   108b4:      	bti	j
   108b8:      	sub	x0, x29, #0x40
   108bc:      	mov	x1, x24
   108c0:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   108c4:      	cmp	x0, #0x60
   108c8:      	b.hs	0x10bd0 <_ZN5mtgif9Video2Gif3runEv+0x21f8>
   108cc:      	ldur	x9, [x29, #-0x40]
   108d0:      	mov	x10, xzr
   108d4:      	mov	x8, xzr
   108d8:      	mov	x12, x9
   108dc:      	cmp	x12, x24
   108e0:      	b.eq	0x10cf4 <_ZN5mtgif9Video2Gif3runEv+0x231c>
   108e4:      	ldrb	w11, [x12], #0x1
   108e8:      	add	x9, x9, #0x1
   108ec:      	and	x13, x11, #0x7f
   108f0:      	lsl	x13, x13, x10
   108f4:      	add	x10, x10, #0x7
   108f8:      	orr	x8, x13, x8
   108fc:      	tbnz	w11, #0x7, 0x108dc <_ZN5mtgif9Video2Gif3runEv+0x1f04>
   10900:      	add	x12, x20, x0, lsl #4
   10904:      	sub	w13, w10, #0x7
   10908:      	mov	x15, #-0x1              // =-1
   1090c:      	cmp	w13, #0x39
   10910:      	mov	w14, #0x3f              // =63
   10914:      	lsl	x15, x15, x10
   10918:      	mov	x13, x12
   1091c:      	ccmp	w11, w14, #0x0, lo
   10920:      	ldrsw	x10, [x22, #0x2c]
   10924:      	ldrb	w16, [x13, #0x1c]!
   10928:      	csel	x11, x15, xzr, hi
   1092c:      	stur	x9, [x29, #-0x40]
   10930:      	cbnz	w16, 0x10954 <_ZN5mtgif9Video2Gif3runEv+0x1f7c>
   10934:      	lsl	x9, x0, #4
   10938:      	add	x15, x19, #0x28
   1093c:      	add	x14, x20, x9
   10940:      	add	x9, x15, x9
   10944:      	ldur	q0, [x14, #0x18]
   10948:      	mov	w14, #0x1               // =1
   1094c:      	strb	w14, [x13]
   10950:      	stur	q0, [x9, #0x18]
   10954:      	orr	x8, x8, x11
   10958:      	mov	w9, #0x2                // =2
   1095c:      	mul	x8, x8, x10
   10960:      	str	w9, [x12, #0x18]
   10964:      	str	x8, [x12, #0x20]
   10968:      	ldur	x9, [x29, #-0x40]
   1096c:      	cmp	x9, x24
   10970:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   10974:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   10978:      	bti	j
   1097c:      	sub	x0, x29, #0x40
   10980:      	mov	x1, x24
   10984:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   10988:      	cmp	x0, #0x60
   1098c:      	b.hs	0x10c08 <_ZN5mtgif9Video2Gif3runEv+0x2230>
   10990:      	add	x8, x20, x0, lsl #4
   10994:      	mov	x9, x8
   10998:      	ldrb	w10, [x9, #0x1c]!
   1099c:      	cbnz	w10, 0x109c0 <_ZN5mtgif9Video2Gif3runEv+0x1fe8>
   109a0:      	lsl	x10, x0, #4
   109a4:      	add	x12, x19, #0x28
   109a8:      	add	x11, x20, x10
   109ac:      	add	x10, x12, x10
   109b0:      	ldur	q0, [x11, #0x18]
   109b4:      	mov	w11, #0x1               // =1
   109b8:      	strb	w11, [x9]
   109bc:      	stur	q0, [x10, #0x18]
   109c0:      	ldur	x9, [x29, #-0x40]
   109c4:      	mov	w10, #0x6               // =6
   109c8:      	str	w10, [x8, #0x18]
   109cc:      	str	x9, [x8, #0x20]
   109d0:      	sub	x0, x29, #0x40
   109d4:      	mov	x1, x24
   109d8:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   109dc:      	ldur	x8, [x29, #-0x40]
   109e0:      	add	x8, x8, x0
   109e4:      	stur	x8, [x29, #-0x40]
   109e8:      	mov	x9, x8
   109ec:      	cmp	x8, x24
   109f0:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   109f4:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   109f8:      	bti	j
   109fc:      	sub	x0, x29, #0x40
   10a00:      	mov	x1, x24
   10a04:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   10a08:      	mov	x26, x0
   10a0c:      	cmp	x0, #0x60
   10a10:      	b.hs	0x10bb0 <_ZN5mtgif9Video2Gif3runEv+0x21d8>
   10a14:      	sub	x0, x29, #0x40
   10a18:      	mov	x1, x24
   10a1c:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   10a20:      	add	x8, x20, x26, lsl #4
   10a24:      	ldrsw	x9, [x22, #0x2c]
   10a28:      	mov	x10, x8
   10a2c:      	ldrb	w11, [x10, #0x1c]!
   10a30:      	cbnz	w11, 0x10a54 <_ZN5mtgif9Video2Gif3runEv+0x207c>
   10a34:      	lsl	x11, x26, #4
   10a38:      	add	x13, x19, #0x28
   10a3c:      	add	x12, x20, x11
   10a40:      	add	x11, x13, x11
   10a44:      	ldur	q0, [x12, #0x18]
   10a48:      	mov	w12, #0x1               // =1
   10a4c:      	strb	w12, [x10]
   10a50:      	stur	q0, [x11, #0x18]
   10a54:      	mul	x9, x0, x9
   10a58:      	mov	w10, #0x4               // =4
   10a5c:      	str	w10, [x8, #0x18]
   10a60:      	str	x9, [x8, #0x20]
   10a64:      	ldur	x9, [x29, #-0x40]
   10a68:      	cmp	x9, x24
   10a6c:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   10a70:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   10a74:      	add	x8, x20, x26, lsl #4
   10a78:      	ldrb	w8, [x8, #0x1c]
   10a7c:      	cbz	w8, 0x10a98 <_ZN5mtgif9Video2Gif3runEv+0x20c0>
   10a80:      	lsl	x8, x26, #4
   10a84:      	add	x9, x19, #0x28
   10a88:      	add	x9, x9, x8
   10a8c:      	add	x8, x20, x8
   10a90:      	ldur	q0, [x9, #0x18]
   10a94:      	stur	q0, [x8, #0x18]
   10a98:      	bti	j
   10a9c:      	ldur	x9, [x29, #-0x40]
   10aa0:      	cmp	x9, x24
   10aa4:      	b.hs	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   10aa8:      	cmp	x25, x21
   10aac:      	b.lo	0x101c8 <_ZN5mtgif9Video2Gif3runEv+0x17f0>
   10ab0:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   10ab4:      	ldr	w8, [x22, #0x28]
   10ab8:      	mul	w8, w8, w26
   10abc:      	add	x25, x25, x8
   10ac0:      	ldur	x9, [x29, #-0x40]
   10ac4:      	cmp	x9, x24
   10ac8:      	b.lo	0x10aa8 <_ZN5mtgif9Video2Gif3runEv+0x20d0>
   10acc:      	b	0x10198 <_ZN5mtgif9Video2Gif3runEv+0x17c0>
   10ad0:      	mov	w0, #0x1                // =1
   10ad4:      	b	0x10c68 <_ZN5mtgif9Video2Gif3runEv+0x2290>
   10ad8:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10adc:      	adrp	x0, 0x5000
   10ae0:      	add	x0, x0, #0xf82
   10ae4:      	b	0x10b3c <_ZN5mtgif9Video2Gif3runEv+0x2164>
   10ae8:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10aec:      	adrp	x0, 0x5000
   10af0:      	add	x0, x0, #0xdab
   10af4:      	ldr	x8, [x8, #0x7e8]
   10af8:      	mov	w1, #0x45               // =69
   10afc:      	add	x3, x8, #0x130
   10b00:      	b	0x10c4c <_ZN5mtgif9Video2Gif3runEv+0x2274>
   10b04:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10b08:      	adrp	x0, 0x6000
   10b0c:      	add	x0, x0, #0x86
   10b10:      	ldr	x8, [x8, #0x7e8]
   10b14:      	mov	w1, #0x44               // =68
   10b18:      	add	x3, x8, #0x130
   10b1c:      	b	0x10c4c <_ZN5mtgif9Video2Gif3runEv+0x2274>
   10b20:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10b24:      	adrp	x0, 0x6000
   10b28:      	add	x0, x0, #0xff
   10b2c:      	b	0x10c24 <_ZN5mtgif9Video2Gif3runEv+0x224c>
   10b30:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10b34:      	adrp	x0, 0x5000
   10b38:      	add	x0, x0, #0xd0b
   10b3c:      	ldr	x8, [x8, #0x7e8]
   10b40:      	add	x3, x8, #0x130
   10b44:      	mov	w1, #0x47               // =71
   10b48:      	b	0x10c4c <_ZN5mtgif9Video2Gif3runEv+0x2274>
   10b4c:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10b50:      	adrp	x0, 0x5000
   10b54:      	add	x0, x0, #0x826
   10b58:      	ldr	x8, [x8, #0x7e8]
   10b5c:      	mov	w1, #0x46               // =70
   10b60:      	add	x3, x8, #0x130
   10b64:      	b	0x10c4c <_ZN5mtgif9Video2Gif3runEv+0x2274>
   10b68:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10b6c:      	adrp	x0, 0x5000
   10b70:      	add	x0, x0, #0xeee
   10b74:      	ldr	x8, [x8, #0x7e8]
   10b78:      	mov	w1, #0x53               // =83
   10b7c:      	add	x3, x8, #0x130
   10b80:      	b	0x10c4c <_ZN5mtgif9Video2Gif3runEv+0x2274>
   10b84:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10b88:      	adrp	x0, 0x5000
   10b8c:      	add	x0, x0, #0x696
   10b90:      	ldr	x8, [x8, #0x7e8]
   10b94:      	mov	w1, #0x3e               // =62
   10b98:      	add	x3, x8, #0x130
   10b9c:      	b	0x10c4c <_ZN5mtgif9Video2Gif3runEv+0x2274>
   10ba0:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10ba4:      	adrp	x0, 0x5000
   10ba8:      	add	x0, x0, #0xfee
   10bac:      	b	0x10c40 <_ZN5mtgif9Video2Gif3runEv+0x2268>
   10bb0:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10bb4:      	adrp	x1, 0x5000
   10bb8:      	add	x1, x1, #0x6e3
   10bbc:      	ldr	x8, [x8, #0x7e8]
   10bc0:      	mov	x2, x26
   10bc4:      	add	x0, x8, #0x130
   10bc8:      	bl	0x133b0 <fprintf@plt>
   10bcc:      	b	0x10c54 <_ZN5mtgif9Video2Gif3runEv+0x227c>
   10bd0:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10bd4:      	adrp	x0, 0x5000
   10bd8:      	add	x0, x0, #0xb5f
   10bdc:      	ldr	x8, [x8, #0x7e8]
   10be0:      	mov	w1, #0x49               // =73
   10be4:      	add	x3, x8, #0x130
   10be8:      	b	0x10c4c <_ZN5mtgif9Video2Gif3runEv+0x2274>
   10bec:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10bf0:      	adrp	x0, 0x5000
   10bf4:      	add	x0, x0, #0xf42
   10bf8:      	ldr	x8, [x8, #0x7e8]
   10bfc:      	mov	w1, #0x3f               // =63
   10c00:      	add	x3, x8, #0x130
   10c04:      	b	0x10c4c <_ZN5mtgif9Video2Gif3runEv+0x2274>
   10c08:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10c0c:      	adrp	x0, 0x5000
   10c10:      	add	x0, x0, #0xb19
   10c14:      	b	0x10c24 <_ZN5mtgif9Video2Gif3runEv+0x224c>
   10c18:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10c1c:      	adrp	x0, 0x5000
   10c20:      	add	x0, x0, #0x78d
   10c24:      	ldr	x8, [x8, #0x7e8]
   10c28:      	add	x3, x8, #0x130
   10c2c:      	mov	w1, #0x41               // =65
   10c30:      	b	0x10c4c <_ZN5mtgif9Video2Gif3runEv+0x2274>
   10c34:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10c38:      	adrp	x0, 0x5000
   10c3c:      	add	x0, x0, #0xa41
   10c40:      	ldr	x8, [x8, #0x7e8]
   10c44:      	add	x3, x8, #0x130
   10c48:      	mov	w1, #0x40               // =64
   10c4c:      	mov	w2, #0x1                // =1
   10c50:      	bl	0x13190 <fwrite@plt>
   10c54:      	adrp	x8, 0x17000 <syscall@plt+0x3bf0>
   10c58:      	ldr	x8, [x8, #0x7e8]
   10c5c:      	add	x0, x8, #0x130
   10c60:      	bl	0x131c0 <fflush@plt>
   10c64:      	mov	w0, wzr
   10c68:      	mov	sp, x29
   10c6c:      	ldp	x20, x19, [sp, #0x50]
   10c70:      	ldp	x22, x21, [sp, #0x40]
   10c74:      	ldp	x24, x23, [sp, #0x30]
   10c78:      	ldp	x26, x25, [sp, #0x20]
   10c7c:      	ldp	x28, x27, [sp, #0x10]
   10c80:      	ldp	x29, x30, [sp], #0x60
   10c84:      	autiasp
   10c88:      	ret
   10c8c:      	adrp	x20, 0x17000 <syscall@plt+0x3bf0>
   10c90:      	nop
   10c94:      	adr	x1, 0x55ec
   10c98:      	ldr	x20, [x20, #0x7e8]
   10c9c:      	adrp	x2, 0x5000
   10ca0:      	add	x2, x2, #0xbcd
   10ca4:      	adrp	x3, 0x5000
   10ca8:      	add	x3, x3, #0x958
   10cac:      	add	x0, x20, #0x130
   10cb0:      	bl	0x133b0 <fprintf@plt>
   10cb4:      	add	x0, x20, #0x130
   10cb8:      	bl	0x131c0 <fflush@plt>
   10cbc:      	bl	0x133c0 <abort@plt>
   10cc0:      	adrp	x20, 0x17000 <syscall@plt+0x3bf0>
   10cc4:      	nop
   10cc8:      	adr	x1, 0x55ec
   10ccc:      	ldr	x20, [x20, #0x7e8]
   10cd0:      	adrp	x2, 0x5000
   10cd4:      	add	x2, x2, #0xbcd
   10cd8:      	adrp	x3, 0x5000
   10cdc:      	add	x3, x3, #0x958
   10ce0:      	add	x0, x20, #0x130
   10ce4:      	bl	0x133b0 <fprintf@plt>
   10ce8:      	add	x0, x20, #0x130
   10cec:      	bl	0x131c0 <fflush@plt>
   10cf0:      	bl	0x133c0 <abort@plt>
   10cf4:      	adrp	x20, 0x17000 <syscall@plt+0x3bf0>
   10cf8:      	nop
   10cfc:      	adr	x1, 0x55ec
   10d00:      	ldr	x20, [x20, #0x7e8]
   10d04:      	adrp	x2, 0x5000
   10d08:      	add	x2, x2, #0xbcd
   10d0c:      	adrp	x3, 0x5000
   10d10:      	add	x3, x3, #0x958
   10d14:      	add	x0, x20, #0x130
   10d18:      	bl	0x133b0 <fprintf@plt>
   10d1c:      	add	x0, x20, #0x130
   10d20:      	bl	0x131c0 <fflush@plt>
   10d24:      	bl	0x133c0 <abort@plt>
   10d28:      	adrp	x20, 0x17000 <syscall@plt+0x3bf0>
   10d2c:      	nop
   10d30:      	adr	x1, 0x55ec
   10d34:      	ldr	x20, [x20, #0x7e8]
   10d38:      	adrp	x2, 0x5000
   10d3c:      	add	x2, x2, #0xbcd
   10d40:      	adrp	x3, 0x5000
   10d44:      	add	x3, x3, #0x958
   10d48:      	add	x0, x20, #0x130
   10d4c:      	bl	0x133b0 <fprintf@plt>
   10d50:      	add	x0, x20, #0x130
   10d54:      	bl	0x131c0 <fflush@plt>
   10d58:      	bl	0x133c0 <abort@plt>
   10d5c:      	bti	c
   10d60:      	ldr	w8, [x1]
   10d64:      	cmp	w8, #0x1d
   10d68:      	b.gt	0x10d84 <_ZN5mtgif9Video2Gif3runEv+0x23ac>
   10d6c:      	tbz	w8, #0x1f, 0x10db0 <_ZN5mtgif9Video2Gif3runEv+0x23d8>
   10d70:      	cmn	w8, #0x2
   10d74:      	b.eq	0x10d9c <_ZN5mtgif9Video2Gif3runEv+0x23c4>
   10d78:      	cmn	w8, #0x1
   10d7c:      	b.eq	0x10de0 <_ZN5mtgif9Video2Gif3runEv+0x2408>
   10d80:      	b	0x10e30 <_ZN5mtgif9Video2Gif3runEv+0x2458>
   10d84:      	cmp	w8, #0x1f
   10d88:      	b.gt	0x10dd0 <_ZN5mtgif9Video2Gif3runEv+0x23f8>
   10d8c:      	cmp	w8, #0x1e
   10d90:      	b.eq	0x10df4 <_ZN5mtgif9Video2Gif3runEv+0x241c>
   10d94:      	cmp	w8, #0x1f
   10d98:      	b.ne	0x10e30 <_ZN5mtgif9Video2Gif3runEv+0x2458>
   10d9c:      	add	x8, x2, #0xf8
   10da0:      	ldr	x8, [x8]
   10da4:      	ldrsw	x9, [x1, #0x4]
   10da8:      	add	x0, x8, x9
   10dac:      	ret
   10db0:      	cbz	w8, 0x10e08 <_ZN5mtgif9Video2Gif3runEv+0x2430>
   10db4:      	cmp	w8, #0x1d
   10db8:      	b.ne	0x10e30 <_ZN5mtgif9Video2Gif3runEv+0x2458>
   10dbc:      	add	x8, x2, #0xe8
   10dc0:      	ldr	x8, [x8]
   10dc4:      	ldrsw	x9, [x1, #0x4]
   10dc8:      	add	x0, x8, x9
   10dcc:      	ret
   10dd0:      	cmp	w8, #0x22
   10dd4:      	b.eq	0x10e1c <_ZN5mtgif9Video2Gif3runEv+0x2444>
   10dd8:      	cmp	w8, #0x20
   10ddc:      	b.ne	0x10e30 <_ZN5mtgif9Video2Gif3runEv+0x2458>
   10de0:      	add	x8, x2, #0x100
   10de4:      	ldr	x8, [x8]
   10de8:      	ldrsw	x9, [x1, #0x4]
   10dec:      	add	x0, x8, x9
   10df0:      	ret
   10df4:      	add	x8, x2, #0xf0
   10df8:      	ldr	x8, [x8]
   10dfc:      	ldrsw	x9, [x1, #0x4]
   10e00:      	add	x0, x8, x9
   10e04:      	ret
   10e08:      	ldr	x8, [x1, #0x8]
   10e0c:      	mov	x1, x0
   10e10:      	mov	x3, xzr
   10e14:      	mov	x0, x8
   10e18:      	b	0x115f4 <_ZN5mtgif9Video2Gif3runEv+0x2c1c>
   10e1c:      	add	x8, x2, #0x108
   10e20:      	ldr	x8, [x8]
   10e24:      	ldrsw	x9, [x1, #0x4]
   10e28:      	add	x0, x8, x9
   10e2c:      	ret
   10e30:      	cmp	w8, #0x1c
   10e34:      	b.hi	0x10e4c <_ZN5mtgif9Video2Gif3runEv+0x2474>
   10e38:      	add	x8, x2, x8, lsl #3
   10e3c:      	ldr	x8, [x8]
   10e40:      	ldrsw	x9, [x1, #0x4]
   10e44:      	add	x0, x8, x9
   10e48:      	ret
   10e4c:      	paciasp
   10e50:      	stp	x29, x30, [sp, #-0x20]!
   10e54:      	str	x19, [sp, #0x10]
   10e58:      	mov	x29, sp
   10e5c:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   10e60:      	nop
   10e64:      	adr	x1, 0x55ec
   10e68:      	ldr	x19, [x19, #0x7e8]
   10e6c:      	adrp	x2, 0x5000
   10e70:      	add	x2, x2, #0xae3
   10e74:      	adrp	x3, 0x5000
   10e78:      	add	x3, x3, #0x901
   10e7c:      	add	x0, x19, #0x130
   10e80:      	bl	0x133b0 <fprintf@plt>
   10e84:      	add	x0, x19, #0x130
   10e88:      	bl	0x131c0 <fflush@plt>
   10e8c:      	bl	0x133c0 <abort@plt>
   10e90:      	paciasp
   10e94:      	stp	x29, x30, [sp, #-0x20]!
   10e98:      	str	x19, [sp, #0x10]
   10e9c:      	mov	x29, sp
   10ea0:      	ldr	w9, [x3]
   10ea4:      	mov	x8, x2
   10ea8:      	cmp	w9, #0x4
   10eac:      	b.gt	0x10ee0 <_ZN5mtgif9Video2Gif3runEv+0x2508>
   10eb0:      	cmp	w9, #0x1
   10eb4:      	b.eq	0x10f38 <_ZN5mtgif9Video2Gif3runEv+0x2560>
   10eb8:      	cmp	w9, #0x2
   10ebc:      	b.eq	0x10ec8 <_ZN5mtgif9Video2Gif3runEv+0x24f0>
   10ec0:      	cmp	w9, #0x3
   10ec4:      	b.ne	0x11038 <_ZN5mtgif9Video2Gif3runEv+0x2660>
   10ec8:      	ldr	x9, [x3, #0x8]
   10ecc:      	ldr	x0, [x9, x8]
   10ed0:      	ldr	x19, [sp, #0x10]
   10ed4:      	ldp	x29, x30, [sp], #0x20
   10ed8:      	autiasp
   10edc:      	ret
   10ee0:      	mov	x2, x1
   10ee4:      	cmp	w9, #0x5
   10ee8:      	b.eq	0x10f4c <_ZN5mtgif9Video2Gif3runEv+0x2574>
   10eec:      	mov	x1, x0
   10ef0:      	cmp	w9, #0x6
   10ef4:      	b.eq	0x10f18 <_ZN5mtgif9Video2Gif3runEv+0x2540>
   10ef8:      	cmp	w9, #0x7
   10efc:      	b.ne	0x11038 <_ZN5mtgif9Video2Gif3runEv+0x2660>
   10f00:      	ldr	x0, [x3, #0x8]
   10f04:      	mov	x3, x8
   10f08:      	ldr	x19, [sp, #0x10]
   10f0c:      	ldp	x29, x30, [sp], #0x20
   10f10:      	autiasp
   10f14:      	b	0x115f4 <_ZN5mtgif9Video2Gif3runEv+0x2c1c>
   10f18:      	ldr	x0, [x3, #0x8]
   10f1c:      	mov	x3, x8
   10f20:      	bl	0x115f4 <_ZN5mtgif9Video2Gif3runEv+0x2c1c>
   10f24:      	ldr	x0, [x0]
   10f28:      	ldr	x19, [sp, #0x10]
   10f2c:      	ldp	x29, x30, [sp], #0x20
   10f30:      	autiasp
   10f34:      	ret
   10f38:      	mov	x0, xzr
   10f3c:      	ldr	x19, [sp, #0x10]
   10f40:      	ldp	x29, x30, [sp], #0x20
   10f44:      	autiasp
   10f48:      	ret
   10f4c:      	ldr	x8, [x3, #0x8]
   10f50:      	cmp	w8, #0x1d
   10f54:      	b.le	0x10f74 <_ZN5mtgif9Video2Gif3runEv+0x259c>
   10f58:      	cmp	w8, #0x1f
   10f5c:      	b.gt	0x10fa4 <_ZN5mtgif9Video2Gif3runEv+0x25cc>
   10f60:      	cmp	w8, #0x1e
   10f64:      	b.eq	0x11008 <_ZN5mtgif9Video2Gif3runEv+0x2630>
   10f68:      	cmp	w8, #0x1f
   10f6c:      	b.eq	0x10fcc <_ZN5mtgif9Video2Gif3runEv+0x25f4>
   10f70:      	b	0x10fe4 <_ZN5mtgif9Video2Gif3runEv+0x260c>
   10f74:      	cmn	w8, #0x2
   10f78:      	b.eq	0x10fcc <_ZN5mtgif9Video2Gif3runEv+0x25f4>
   10f7c:      	cmn	w8, #0x1
   10f80:      	b.eq	0x10fb4 <_ZN5mtgif9Video2Gif3runEv+0x25dc>
   10f84:      	cmp	w8, #0x1d
   10f88:      	b.ne	0x10fe4 <_ZN5mtgif9Video2Gif3runEv+0x260c>
   10f8c:      	add	x8, x2, #0xe8
   10f90:      	ldr	x0, [x8]
   10f94:      	ldr	x19, [sp, #0x10]
   10f98:      	ldp	x29, x30, [sp], #0x20
   10f9c:      	autiasp
   10fa0:      	ret
   10fa4:      	cmp	w8, #0x22
   10fa8:      	b.eq	0x11020 <_ZN5mtgif9Video2Gif3runEv+0x2648>
   10fac:      	cmp	w8, #0x20
   10fb0:      	b.ne	0x10fe4 <_ZN5mtgif9Video2Gif3runEv+0x260c>
   10fb4:      	add	x8, x2, #0x100
   10fb8:      	ldr	x0, [x8]
   10fbc:      	ldr	x19, [sp, #0x10]
   10fc0:      	ldp	x29, x30, [sp], #0x20
   10fc4:      	autiasp
   10fc8:      	ret
   10fcc:      	add	x8, x2, #0xf8
   10fd0:      	ldr	x0, [x8]
   10fd4:      	ldr	x19, [sp, #0x10]
   10fd8:      	ldp	x29, x30, [sp], #0x20
   10fdc:      	autiasp
   10fe0:      	ret
   10fe4:      	cmp	w8, #0x1c
   10fe8:      	b.hi	0x1106c <_ZN5mtgif9Video2Gif3runEv+0x2694>
   10fec:      	and	x8, x8, #0xffffffff
   10ff0:      	add	x8, x2, x8, lsl #3
   10ff4:      	ldr	x0, [x8]
   10ff8:      	ldr	x19, [sp, #0x10]
   10ffc:      	ldp	x29, x30, [sp], #0x20
   11000:      	autiasp
   11004:      	ret
   11008:      	add	x8, x2, #0xf0
   1100c:      	ldr	x0, [x8]
   11010:      	ldr	x19, [sp, #0x10]
   11014:      	ldp	x29, x30, [sp], #0x20
   11018:      	autiasp
   1101c:      	ret
   11020:      	add	x8, x2, #0x108
   11024:      	ldr	x0, [x8]
   11028:      	ldr	x19, [sp, #0x10]
   1102c:      	ldp	x29, x30, [sp], #0x20
   11030:      	autiasp
   11034:      	ret
   11038:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   1103c:      	nop
   11040:      	adr	x1, 0x55ec
   11044:      	ldr	x19, [x19, #0x7e8]
   11048:      	adrp	x2, 0x5000
   1104c:      	add	x2, x2, #0xab2
   11050:      	adrp	x3, 0x5000
   11054:      	add	x3, x3, #0x91c
   11058:      	add	x0, x19, #0x130
   1105c:      	bl	0x133b0 <fprintf@plt>
   11060:      	add	x0, x19, #0x130
   11064:      	bl	0x131c0 <fflush@plt>
   11068:      	bl	0x133c0 <abort@plt>
   1106c:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   11070:      	nop
   11074:      	adr	x1, 0x55ec
   11078:      	ldr	x19, [x19, #0x7e8]
   1107c:      	adrp	x2, 0x5000
   11080:      	add	x2, x2, #0xae3
   11084:      	adrp	x3, 0x5000
   11088:      	add	x3, x3, #0x901
   1108c:      	add	x0, x19, #0x130
   11090:      	bl	0x133b0 <fprintf@plt>
   11094:      	add	x0, x19, #0x130
   11098:      	bl	0x131c0 <fflush@plt>
   1109c:      	bl	0x133c0 <abort@plt>
   110a0:      	paciasp
   110a4:      	stp	x29, x30, [sp, #-0x30]!
   110a8:      	str	x21, [sp, #0x10]
   110ac:      	stp	x20, x19, [sp, #0x20]
   110b0:      	mov	x29, sp
   110b4:      	and	w8, w3, #0xf
   110b8:      	ldr	x19, [x1]
   110bc:      	cmp	w8, #0x3
   110c0:      	b.le	0x110e8 <_ZN5mtgif9Video2Gif3runEv+0x2710>
   110c4:      	cmp	w8, #0x9
   110c8:      	b.le	0x1115c <_ZN5mtgif9Video2Gif3runEv+0x2784>
   110cc:      	cmp	w8, #0xa
   110d0:      	b.eq	0x1122c <_ZN5mtgif9Video2Gif3runEv+0x2854>
   110d4:      	cmp	w8, #0xb
   110d8:      	b.eq	0x1124c <_ZN5mtgif9Video2Gif3runEv+0x2874>
   110dc:      	cmp	w8, #0xc
   110e0:      	b.eq	0x111ec <_ZN5mtgif9Video2Gif3runEv+0x2814>
   110e4:      	b	0x113f8 <_ZN5mtgif9Video2Gif3runEv+0x2a20>
   110e8:      	cmp	w8, #0x1
   110ec:      	b.gt	0x1112c <_ZN5mtgif9Video2Gif3runEv+0x2754>
   110f0:      	cbz	w8, 0x111ec <_ZN5mtgif9Video2Gif3runEv+0x2814>
   110f4:      	cmp	w8, #0x1
   110f8:      	b.ne	0x113f8 <_ZN5mtgif9Video2Gif3runEv+0x2a20>
   110fc:      	mov	x0, x1
   11100:      	mov	x1, x2
   11104:      	mov	w20, w3
   11108:      	mov	x21, x4
   1110c:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   11110:      	mov	x4, x21
   11114:      	mov	w3, w20
   11118:      	and	w8, w20, #0xff
   1111c:      	ubfx	w8, w8, #4, #3
   11120:      	cmp	w8, #0x1
   11124:      	b.le	0x11268 <_ZN5mtgif9Video2Gif3runEv+0x2890>
   11128:      	b	0x111d4 <_ZN5mtgif9Video2Gif3runEv+0x27fc>
   1112c:      	cmp	w8, #0x2
   11130:      	b.eq	0x1120c <_ZN5mtgif9Video2Gif3runEv+0x2834>
   11134:      	cmp	w8, #0x3
   11138:      	b.ne	0x113f8 <_ZN5mtgif9Video2Gif3runEv+0x2a20>
   1113c:      	mov	x8, x19
   11140:      	ldr	w0, [x8], #0x4
   11144:      	str	x8, [x1]
   11148:      	and	w8, w3, #0xff
   1114c:      	ubfx	w8, w8, #4, #3
   11150:      	cmp	w8, #0x1
   11154:      	b.le	0x11268 <_ZN5mtgif9Video2Gif3runEv+0x2890>
   11158:      	b	0x111d4 <_ZN5mtgif9Video2Gif3runEv+0x27fc>
   1115c:      	cmp	w8, #0x4
   11160:      	b.eq	0x111ec <_ZN5mtgif9Video2Gif3runEv+0x2814>
   11164:      	cmp	w8, #0x9
   11168:      	b.ne	0x113f8 <_ZN5mtgif9Video2Gif3runEv+0x2a20>
   1116c:      	mov	x10, xzr
   11170:      	mov	x8, xzr
   11174:      	mov	x9, x19
   11178:      	mov	x11, x19
   1117c:      	cmp	x11, x2
   11180:      	b.eq	0x112a8 <_ZN5mtgif9Video2Gif3runEv+0x28d0>
   11184:      	ldrb	w12, [x11], #0x1
   11188:      	add	x9, x9, #0x1
   1118c:      	and	x13, x12, #0x7f
   11190:      	lsl	x13, x13, x10
   11194:      	add	x10, x10, #0x7
   11198:      	orr	x8, x13, x8
   1119c:      	tbnz	w12, #0x7, 0x1117c <_ZN5mtgif9Video2Gif3runEv+0x27a4>
   111a0:      	sub	w11, w10, #0x7
   111a4:      	mov	x13, #-0x1              // =-1
   111a8:      	str	x9, [x1]
   111ac:      	cmp	w11, #0x39
   111b0:      	mov	w11, #0x3f              // =63
   111b4:      	lsl	x10, x13, x10
   111b8:      	ccmp	w12, w11, #0x0, lo
   111bc:      	csel	x10, x10, xzr, hi
   111c0:      	orr	x0, x8, x10
   111c4:      	and	w8, w3, #0xff
   111c8:      	ubfx	w8, w8, #4, #3
   111cc:      	cmp	w8, #0x1
   111d0:      	b.le	0x11268 <_ZN5mtgif9Video2Gif3runEv+0x2890>
   111d4:      	cmp	w8, #0x3
   111d8:      	b.gt	0x112dc <_ZN5mtgif9Video2Gif3runEv+0x2904>
   111dc:      	b.ne	0x11320 <_ZN5mtgif9Video2Gif3runEv+0x2948>
   111e0:      	cbz	x4, 0x11390 <_ZN5mtgif9Video2Gif3runEv+0x29b8>
   111e4:      	add	x0, x0, x4
   111e8:      	b	0x11278 <_ZN5mtgif9Video2Gif3runEv+0x28a0>
   111ec:      	mov	x8, x19
   111f0:      	ldr	x0, [x8], #0x8
   111f4:      	str	x8, [x1]
   111f8:      	and	w8, w3, #0xff
   111fc:      	ubfx	w8, w8, #4, #3
   11200:      	cmp	w8, #0x1
   11204:      	b.le	0x11268 <_ZN5mtgif9Video2Gif3runEv+0x2890>
   11208:      	b	0x111d4 <_ZN5mtgif9Video2Gif3runEv+0x27fc>
   1120c:      	mov	x8, x19
   11210:      	ldrh	w0, [x8], #0x2
   11214:      	str	x8, [x1]
   11218:      	and	w8, w3, #0xff
   1121c:      	ubfx	w8, w8, #4, #3
   11220:      	cmp	w8, #0x1
   11224:      	b.le	0x11268 <_ZN5mtgif9Video2Gif3runEv+0x2890>
   11228:      	b	0x111d4 <_ZN5mtgif9Video2Gif3runEv+0x27fc>
   1122c:      	mov	x8, x19
   11230:      	ldrsh	x0, [x8], #0x2
   11234:      	str	x8, [x1]
   11238:      	and	w8, w3, #0xff
   1123c:      	ubfx	w8, w8, #4, #3
   11240:      	cmp	w8, #0x1
   11244:      	b.le	0x11268 <_ZN5mtgif9Video2Gif3runEv+0x2890>
   11248:      	b	0x111d4 <_ZN5mtgif9Video2Gif3runEv+0x27fc>
   1124c:      	mov	x8, x19
   11250:      	ldrsw	x0, [x8], #0x4
   11254:      	str	x8, [x1]
   11258:      	and	w8, w3, #0xff
   1125c:      	ubfx	w8, w8, #4, #3
   11260:      	cmp	w8, #0x1
   11264:      	b.gt	0x111d4 <_ZN5mtgif9Video2Gif3runEv+0x27fc>
   11268:      	cbz	w8, 0x11278 <_ZN5mtgif9Video2Gif3runEv+0x28a0>
   1126c:      	cmp	w8, #0x1
   11270:      	b.ne	0x113c4 <_ZN5mtgif9Video2Gif3runEv+0x29ec>
   11274:      	add	x0, x0, x19
   11278:      	tbnz	w3, #0x7, 0x11290 <_ZN5mtgif9Video2Gif3runEv+0x28b8>
   1127c:      	ldp	x20, x19, [sp, #0x20]
   11280:      	ldr	x21, [sp, #0x10]
   11284:      	ldp	x29, x30, [sp], #0x30
   11288:      	autiasp
   1128c:      	ret
   11290:      	ldr	x0, [x0]
   11294:      	ldp	x20, x19, [sp, #0x20]
   11298:      	ldr	x21, [sp, #0x10]
   1129c:      	ldp	x29, x30, [sp], #0x30
   112a0:      	autiasp
   112a4:      	ret
   112a8:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   112ac:      	nop
   112b0:      	adr	x1, 0x55ec
   112b4:      	ldr	x19, [x19, #0x7e8]
   112b8:      	adrp	x2, 0x5000
   112bc:      	add	x2, x2, #0xbcd
   112c0:      	adrp	x3, 0x5000
   112c4:      	add	x3, x3, #0x958
   112c8:      	add	x0, x19, #0x130
   112cc:      	bl	0x133b0 <fprintf@plt>
   112d0:      	add	x0, x19, #0x130
   112d4:      	bl	0x131c0 <fflush@plt>
   112d8:      	bl	0x133c0 <abort@plt>
   112dc:      	cmp	w8, #0x4
   112e0:      	b.eq	0x1135c <_ZN5mtgif9Video2Gif3runEv+0x2984>
   112e4:      	cmp	w8, #0x5
   112e8:      	b.ne	0x113c4 <_ZN5mtgif9Video2Gif3runEv+0x29ec>
   112ec:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   112f0:      	nop
   112f4:      	adr	x1, 0x55ec
   112f8:      	ldr	x19, [x19, #0x7e8]
   112fc:      	adrp	x2, 0x6000
   11300:      	add	x2, x2, #0xcb
   11304:      	adrp	x3, 0x5000
   11308:      	add	x3, x3, #0xa82
   1130c:      	add	x0, x19, #0x130
   11310:      	bl	0x133b0 <fprintf@plt>
   11314:      	add	x0, x19, #0x130
   11318:      	bl	0x131c0 <fflush@plt>
   1131c:      	bl	0x133c0 <abort@plt>
   11320:      	cmp	w8, #0x2
   11324:      	b.ne	0x113c4 <_ZN5mtgif9Video2Gif3runEv+0x29ec>
   11328:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   1132c:      	nop
   11330:      	adr	x1, 0x55ec
   11334:      	ldr	x19, [x19, #0x7e8]
   11338:      	adrp	x2, 0x6000
   1133c:      	add	x2, x2, #0xcb
   11340:      	adrp	x3, 0x5000
   11344:      	add	x3, x3, #0xd53
   11348:      	add	x0, x19, #0x130
   1134c:      	bl	0x133b0 <fprintf@plt>
   11350:      	add	x0, x19, #0x130
   11354:      	bl	0x131c0 <fflush@plt>
   11358:      	bl	0x133c0 <abort@plt>
   1135c:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   11360:      	nop
   11364:      	adr	x1, 0x55ec
   11368:      	ldr	x19, [x19, #0x7e8]
   1136c:      	adrp	x2, 0x6000
   11370:      	add	x2, x2, #0xcb
   11374:      	adrp	x3, 0x5000
   11378:      	add	x3, x3, #0x600
   1137c:      	add	x0, x19, #0x130
   11380:      	bl	0x133b0 <fprintf@plt>
   11384:      	add	x0, x19, #0x130
   11388:      	bl	0x131c0 <fflush@plt>
   1138c:      	bl	0x133c0 <abort@plt>
   11390:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   11394:      	nop
   11398:      	adr	x1, 0x55ec
   1139c:      	ldr	x19, [x19, #0x7e8]
   113a0:      	adrp	x2, 0x6000
   113a4:      	add	x2, x2, #0xcb
   113a8:      	adrp	x3, 0x5000
   113ac:      	add	x3, x3, #0xe4a
   113b0:      	add	x0, x19, #0x130
   113b4:      	bl	0x133b0 <fprintf@plt>
   113b8:      	add	x0, x19, #0x130
   113bc:      	bl	0x131c0 <fflush@plt>
   113c0:      	bl	0x133c0 <abort@plt>
   113c4:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   113c8:      	nop
   113cc:      	adr	x1, 0x55ec
   113d0:      	ldr	x19, [x19, #0x7e8]
   113d4:      	adrp	x2, 0x6000
   113d8:      	add	x2, x2, #0xcb
   113dc:      	adrp	x3, 0x5000
   113e0:      	add	x3, x3, #0xbb4
   113e4:      	add	x0, x19, #0x130
   113e8:      	bl	0x133b0 <fprintf@plt>
   113ec:      	add	x0, x19, #0x130
   113f0:      	bl	0x131c0 <fflush@plt>
   113f4:      	bl	0x133c0 <abort@plt>
   113f8:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   113fc:      	nop
   11400:      	adr	x1, 0x55ec
   11404:      	ldr	x19, [x19, #0x7e8]
   11408:      	adrp	x2, 0x6000
   1140c:      	add	x2, x2, #0xcb
   11410:      	adrp	x3, 0x5000
   11414:      	add	x3, x3, #0xbb4
   11418:      	add	x0, x19, #0x130
   1141c:      	bl	0x133b0 <fprintf@plt>
   11420:      	add	x0, x19, #0x130
   11424:      	bl	0x131c0 <fflush@plt>
   11428:      	bl	0x133c0 <abort@plt>
   1142c:      	paciasp
   11430:      	stp	x29, x30, [sp, #-0x20]!
   11434:      	str	x19, [sp, #0x10]
   11438:      	mov	x29, sp
   1143c:      	ldr	x9, [x0]
   11440:      	cmp	x9, x1
   11444:      	b.eq	0x1158c <_ZN5mtgif9Video2Gif3runEv+0x2bb4>
   11448:      	mov	x10, x9
   1144c:      	mov	x8, x0
   11450:      	ldrb	w11, [x10], #0x1
   11454:      	and	x0, x11, #0x7f
   11458:      	tbnz	w11, #0x7, 0x11470 <_ZN5mtgif9Video2Gif3runEv+0x2a98>
   1145c:      	str	x10, [x8]
   11460:      	ldr	x19, [sp, #0x10]
   11464:      	ldp	x29, x30, [sp], #0x20
   11468:      	autiasp
   1146c:      	ret
   11470:      	cmp	x10, x1
   11474:      	b.eq	0x1158c <_ZN5mtgif9Video2Gif3runEv+0x2bb4>
   11478:      	ldrsb	w11, [x9, #0x1]
   1147c:      	and	w10, w11, #0x7f
   11480:      	orr	x0, x0, x10, lsl #7
   11484:      	add	x10, x9, #0x2
   11488:      	tbz	w11, #0x1f, 0x1145c <_ZN5mtgif9Video2Gif3runEv+0x2a84>
   1148c:      	cmp	x10, x1
   11490:      	b.eq	0x1158c <_ZN5mtgif9Video2Gif3runEv+0x2bb4>
   11494:      	ldrsb	w11, [x9, #0x2]
   11498:      	and	w10, w11, #0x7f
   1149c:      	orr	x0, x0, x10, lsl #14
   114a0:      	add	x10, x9, #0x3
   114a4:      	tbz	w11, #0x1f, 0x1145c <_ZN5mtgif9Video2Gif3runEv+0x2a84>
   114a8:      	cmp	x10, x1
   114ac:      	b.eq	0x1158c <_ZN5mtgif9Video2Gif3runEv+0x2bb4>
   114b0:      	ldrsb	w11, [x9, #0x3]
   114b4:      	and	w10, w11, #0x7f
   114b8:      	orr	x0, x0, x10, lsl #21
   114bc:      	add	x10, x9, #0x4
   114c0:      	tbz	w11, #0x1f, 0x1145c <_ZN5mtgif9Video2Gif3runEv+0x2a84>
   114c4:      	cmp	x10, x1
   114c8:      	b.eq	0x1158c <_ZN5mtgif9Video2Gif3runEv+0x2bb4>
   114cc:      	ldrsb	w11, [x9, #0x4]
   114d0:      	and	w10, w11, #0x7f
   114d4:      	orr	x0, x0, x10, lsl #28
   114d8:      	add	x10, x9, #0x5
   114dc:      	tbz	w11, #0x1f, 0x1145c <_ZN5mtgif9Video2Gif3runEv+0x2a84>
   114e0:      	cmp	x10, x1
   114e4:      	b.eq	0x1158c <_ZN5mtgif9Video2Gif3runEv+0x2bb4>
   114e8:      	ldrsb	w11, [x9, #0x5]
   114ec:      	and	w10, w11, #0x7f
   114f0:      	orr	x0, x0, x10, lsl #35
   114f4:      	add	x10, x9, #0x6
   114f8:      	tbz	w11, #0x1f, 0x1145c <_ZN5mtgif9Video2Gif3runEv+0x2a84>
   114fc:      	cmp	x10, x1
   11500:      	b.eq	0x1158c <_ZN5mtgif9Video2Gif3runEv+0x2bb4>
   11504:      	ldrsb	w11, [x9, #0x6]
   11508:      	and	w10, w11, #0x7f
   1150c:      	orr	x0, x0, x10, lsl #42
   11510:      	add	x10, x9, #0x7
   11514:      	tbz	w11, #0x1f, 0x1145c <_ZN5mtgif9Video2Gif3runEv+0x2a84>
   11518:      	cmp	x10, x1
   1151c:      	b.eq	0x1158c <_ZN5mtgif9Video2Gif3runEv+0x2bb4>
   11520:      	ldrsb	w11, [x9, #0x7]
   11524:      	and	w10, w11, #0x7f
   11528:      	orr	x0, x0, x10, lsl #49
   1152c:      	add	x10, x9, #0x8
   11530:      	tbz	w11, #0x1f, 0x1145c <_ZN5mtgif9Video2Gif3runEv+0x2a84>
   11534:      	cmp	x10, x1
   11538:      	b.eq	0x1158c <_ZN5mtgif9Video2Gif3runEv+0x2bb4>
   1153c:      	ldrsb	w11, [x9, #0x8]
   11540:      	and	w10, w11, #0x7f
   11544:      	orr	x0, x0, x10, lsl #56
   11548:      	add	x10, x9, #0x9
   1154c:      	tbz	w11, #0x1f, 0x1145c <_ZN5mtgif9Video2Gif3runEv+0x2a84>
   11550:      	cmp	x10, x1
   11554:      	b.eq	0x1158c <_ZN5mtgif9Video2Gif3runEv+0x2bb4>
   11558:      	ldrb	w11, [x10]
   1155c:      	tst	w11, #0x7e
   11560:      	b.ne	0x115c0 <_ZN5mtgif9Video2Gif3runEv+0x2be8>
   11564:      	add	x10, x9, #0xa
   11568:      	tbnz	w11, #0x7, 0x11584 <_ZN5mtgif9Video2Gif3runEv+0x2bac>
   1156c:      	orr	x0, x0, x11, lsl #63
   11570:      	str	x10, [x8]
   11574:      	ldr	x19, [sp, #0x10]
   11578:      	ldp	x29, x30, [sp], #0x20
   1157c:      	autiasp
   11580:      	ret
   11584:      	cmp	x10, x1
   11588:      	b.ne	0x115c0 <_ZN5mtgif9Video2Gif3runEv+0x2be8>
   1158c:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   11590:      	nop
   11594:      	adr	x1, 0x55ec
   11598:      	ldr	x19, [x19, #0x7e8]
   1159c:      	adrp	x2, 0x5000
   115a0:      	add	x2, x2, #0x80c
   115a4:      	adrp	x3, 0x5000
   115a8:      	add	x3, x3, #0x89b
   115ac:      	add	x0, x19, #0x130
   115b0:      	bl	0x133b0 <fprintf@plt>
   115b4:      	add	x0, x19, #0x130
   115b8:      	bl	0x131c0 <fflush@plt>
   115bc:      	bl	0x133c0 <abort@plt>
   115c0:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   115c4:      	nop
   115c8:      	adr	x1, 0x55ec
   115cc:      	ldr	x19, [x19, #0x7e8]
   115d0:      	adrp	x2, 0x5000
   115d4:      	add	x2, x2, #0x80c
   115d8:      	adrp	x3, 0x5000
   115dc:      	add	x3, x3, #0x9e7
   115e0:      	add	x0, x19, #0x130
   115e4:      	bl	0x133b0 <fprintf@plt>
   115e8:      	add	x0, x19, #0x130
   115ec:      	bl	0x131c0 <fflush@plt>
   115f0:      	bl	0x133c0 <abort@plt>
   115f4:      	paciasp
   115f8:      	stp	x29, x30, [sp, #-0x60]!
   115fc:      	stp	x28, x27, [sp, #0x10]
   11600:      	stp	x26, x25, [sp, #0x20]
   11604:      	stp	x24, x23, [sp, #0x30]
   11608:      	stp	x22, x21, [sp, #0x40]
   1160c:      	stp	x20, x19, [sp, #0x50]
   11610:      	mov	x29, sp
   11614:      	sub	sp, sp, #0x330
   11618:      	mov	x8, x0
   1161c:      	stur	x0, [x29, #-0x8]
   11620:      	sub	x0, x29, #0x8
   11624:      	add	x1, x8, #0x14
   11628:      	mov	x21, x3
   1162c:      	mov	x19, x2
   11630:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   11634:      	ldur	x10, [x29, #-0x8]
   11638:      	str	x21, [sp, #0x10]
   1163c:      	add	x20, x10, x0
   11640:      	cmp	x10, x20
   11644:      	b.hs	0x11d74 <_ZN5mtgif9Video2Gif3runEv+0x339c>
   11648:      	add	x8, sp, #0x8
   1164c:      	add	x21, x19, #0xf0
   11650:      	add	x22, x19, #0xe8
   11654:      	add	x23, x19, #0x108
   11658:      	add	x24, x19, #0xf8
   1165c:      	add	x27, x8, #0x8
   11660:      	add	x25, x19, #0x100
   11664:      	nop
   11668:      	adr	x26, 0x6296 <_ZTS10CQuantizer+0x6e>
   1166c:      	b	0x11684 <_ZN5mtgif9Video2Gif3runEv+0x2cac>
   11670:      	ldr	x8, [x8]
   11674:      	str	x8, [x27, #0x8]!
   11678:      	ldur	x10, [x29, #-0x8]
   1167c:      	cmp	x10, x20
   11680:      	b.hs	0x11d70 <_ZN5mtgif9Video2Gif3runEv+0x3398>
   11684:      	add	x8, x10, #0x1
   11688:      	stur	x8, [x29, #-0x8]
   1168c:      	ldrb	w9, [x10]
   11690:      	sub	w11, w9, #0x3
   11694:      	cmp	w11, #0x91
   11698:      	b.hi	0x11e6c <_ZN5mtgif9Video2Gif3runEv+0x3494>
   1169c:      	adr	x12, 0x116ac <_ZN5mtgif9Video2Gif3runEv+0x2cd4>
   116a0:      	ldrh	w13, [x26, x11, lsl #1]
   116a4:      	add	x12, x12, x13, lsl #2
   116a8:      	br	x12
   116ac:      	bti	j
   116b0:      	sub	w8, w9, #0x30
   116b4:      	b	0x11674 <_ZN5mtgif9Video2Gif3runEv+0x2c9c>
   116b8:      	bti	j
   116bc:      	mov	x12, xzr
   116c0:      	mov	x10, xzr
   116c4:      	sub	w11, w9, #0x70
   116c8:      	mov	x13, x8
   116cc:      	cmp	x13, x20
   116d0:      	b.eq	0x11d9c <_ZN5mtgif9Video2Gif3runEv+0x33c4>
   116d4:      	ldrb	w14, [x13], #0x1
   116d8:      	add	x8, x8, #0x1
   116dc:      	and	x15, x14, #0x7f
   116e0:      	lsl	x15, x15, x12
   116e4:      	add	x12, x12, #0x7
   116e8:      	orr	x10, x15, x10
   116ec:      	tbnz	w14, #0x7, 0x116cc <_ZN5mtgif9Video2Gif3runEv+0x2cf4>
   116f0:      	sub	w13, w12, #0x7
   116f4:      	mov	x15, #-0x1              // =-1
   116f8:      	stur	x8, [x29, #-0x8]
   116fc:      	cmp	w13, #0x39
   11700:      	mov	w13, #0x3f              // =63
   11704:      	lsl	x12, x15, x12
   11708:      	ccmp	w14, w13, #0x0, lo
   1170c:      	csel	x12, x12, xzr, hi
   11710:      	cmp	w9, #0x8d
   11714:      	b.le	0x11770 <_ZN5mtgif9Video2Gif3runEv+0x2d98>
   11718:      	cmp	w9, #0x8f
   1171c:      	b.gt	0x11798 <_ZN5mtgif9Video2Gif3runEv+0x2dc0>
   11720:      	cmp	w9, #0x8e
   11724:      	mov	x8, x21
   11728:      	b.eq	0x117bc <_ZN5mtgif9Video2Gif3runEv+0x2de4>
   1172c:      	cmp	w9, #0x8f
   11730:      	mov	x8, x24
   11734:      	b.eq	0x117bc <_ZN5mtgif9Video2Gif3runEv+0x2de4>
   11738:      	b	0x117b0 <_ZN5mtgif9Video2Gif3runEv+0x2dd8>
   1173c:      	bti	j
   11740:      	cmp	w9, #0x6f
   11744:      	mov	x8, x24
   11748:      	b.eq	0x11670 <_ZN5mtgif9Video2Gif3runEv+0x2c98>
   1174c:      	cmp	w9, #0x6e
   11750:      	mov	x8, x21
   11754:      	b.eq	0x11670 <_ZN5mtgif9Video2Gif3runEv+0x2c98>
   11758:      	cmp	w9, #0x6d
   1175c:      	mov	x8, x22
   11760:      	b.eq	0x11670 <_ZN5mtgif9Video2Gif3runEv+0x2c98>
   11764:      	sub	w8, w9, #0x50
   11768:      	add	x8, x19, w8, uxtw #3
   1176c:      	b	0x11670 <_ZN5mtgif9Video2Gif3runEv+0x2c98>
   11770:      	cmp	w9, #0x6e
   11774:      	mov	x8, x24
   11778:      	b.eq	0x117bc <_ZN5mtgif9Video2Gif3runEv+0x2de4>
   1177c:      	cmp	w9, #0x6f
   11780:      	mov	x8, x25
   11784:      	b.eq	0x117bc <_ZN5mtgif9Video2Gif3runEv+0x2de4>
   11788:      	cmp	w9, #0x8d
   1178c:      	mov	x8, x22
   11790:      	b.eq	0x117bc <_ZN5mtgif9Video2Gif3runEv+0x2de4>
   11794:      	b	0x117b0 <_ZN5mtgif9Video2Gif3runEv+0x2dd8>
   11798:      	cmp	w9, #0x90
   1179c:      	mov	x8, x25
   117a0:      	b.eq	0x117bc <_ZN5mtgif9Video2Gif3runEv+0x2de4>
   117a4:      	cmp	w9, #0x92
   117a8:      	mov	x8, x23
   117ac:      	b.eq	0x117bc <_ZN5mtgif9Video2Gif3runEv+0x2de4>
   117b0:      	cmp	w11, #0x1c
   117b4:      	b.hi	0x11e38 <_ZN5mtgif9Video2Gif3runEv+0x3460>
   117b8:      	add	x8, x19, w11, uxtw #3
   117bc:      	ldr	x8, [x8]
   117c0:      	orr	x9, x10, x12
   117c4:      	add	x8, x8, x9
   117c8:      	b	0x11674 <_ZN5mtgif9Video2Gif3runEv+0x2c9c>
   117cc:      	bti	j
   117d0:      	ldur	x8, [x10, #0x1]
   117d4:      	add	x9, x10, #0x9
   117d8:      	b	0x11adc <_ZN5mtgif9Video2Gif3runEv+0x3104>
   117dc:      	bti	j
   117e0:      	sub	x0, x29, #0x8
   117e4:      	mov	x1, x20
   117e8:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   117ec:      	ldur	x10, [x29, #-0x8]
   117f0:      	mov	x9, xzr
   117f4:      	mov	x8, xzr
   117f8:      	mov	x11, x10
   117fc:      	cmp	x11, x20
   11800:      	b.eq	0x11dd0 <_ZN5mtgif9Video2Gif3runEv+0x33f8>
   11804:      	ldrb	w12, [x11], #0x1
   11808:      	add	x10, x10, #0x1
   1180c:      	and	x13, x12, #0x7f
   11810:      	lsl	x13, x13, x9
   11814:      	add	x9, x9, #0x7
   11818:      	orr	x8, x13, x8
   1181c:      	tbnz	w12, #0x7, 0x117fc <_ZN5mtgif9Video2Gif3runEv+0x2e24>
   11820:      	sub	w11, w9, #0x7
   11824:      	mov	x13, #-0x1              // =-1
   11828:      	stur	x10, [x29, #-0x8]
   1182c:      	cmp	w11, #0x39
   11830:      	mov	w11, #0x3f              // =63
   11834:      	lsl	x9, x13, x9
   11838:      	ccmp	w12, w11, #0x0, lo
   1183c:      	csel	x9, x9, xzr, hi
   11840:      	cmp	w0, #0x1d
   11844:      	b.le	0x11cd4 <_ZN5mtgif9Video2Gif3runEv+0x32fc>
   11848:      	cmp	w0, #0x1f
   1184c:      	b.gt	0x11d24 <_ZN5mtgif9Video2Gif3runEv+0x334c>
   11850:      	cmp	w0, #0x1e
   11854:      	mov	x10, x21
   11858:      	b.eq	0x11d48 <_ZN5mtgif9Video2Gif3runEv+0x3370>
   1185c:      	cmp	w0, #0x1f
   11860:      	mov	x10, x24
   11864:      	b.eq	0x11d48 <_ZN5mtgif9Video2Gif3runEv+0x3370>
   11868:      	b	0x11d3c <_ZN5mtgif9Video2Gif3runEv+0x3364>
   1186c:      	bti	j
   11870:      	mov	x8, x27
   11874:      	ldr	x9, [x27]
   11878:      	ldr	x10, [x8, #-0x8]!
   1187c:      	cmp	x10, x9
   11880:      	cset	w9, lo
   11884:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   11888:      	bti	j
   1188c:      	mov	x8, x27
   11890:      	ldr	x9, [x27]
   11894:      	ldr	x10, [x8, #-0x8]!
   11898:      	cmp	x10, x9
   1189c:      	cset	w9, ls
   118a0:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   118a4:      	bti	j
   118a8:      	mov	x8, x27
   118ac:      	ldr	x9, [x27]
   118b0:      	ldr	x10, [x8, #-0x8]!
   118b4:      	sdiv	x11, x10, x9
   118b8:      	msub	x9, x11, x9, x10
   118bc:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   118c0:      	bti	j
   118c4:      	mov	x8, x27
   118c8:      	ldr	x9, [x27]
   118cc:      	ldr	x10, [x8, #-0x8]!
   118d0:      	cmp	x10, x9
   118d4:      	cset	w9, eq
   118d8:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   118dc:      	bti	j
   118e0:      	ldursh	x8, [x10, #0x1]
   118e4:      	add	x9, x10, #0x3
   118e8:      	b	0x11adc <_ZN5mtgif9Video2Gif3runEv+0x3104>
   118ec:      	bti	j
   118f0:      	ldr	x11, [x27], #-0x8
   118f4:      	ldursh	x8, [x10, #0x1]
   118f8:      	add	x9, x10, #0x3
   118fc:      	stur	x9, [x29, #-0x8]
   11900:      	cbz	x11, 0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11904:      	add	x8, x9, x8
   11908:      	stur	x8, [x29, #-0x8]
   1190c:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11910:      	bti	j
   11914:      	mov	x8, x27
   11918:      	ldr	x9, [x27]
   1191c:      	ldr	x10, [x8, #-0x8]!
   11920:      	cmp	x10, x9
   11924:      	cset	w9, hs
   11928:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   1192c:      	bti	j
   11930:      	mov	x10, xzr
   11934:      	mov	x9, xzr
   11938:      	mov	x11, x8
   1193c:      	cmp	x11, x20
   11940:      	b.eq	0x11e04 <_ZN5mtgif9Video2Gif3runEv+0x342c>
   11944:      	ldrb	w12, [x11], #0x1
   11948:      	add	x8, x8, #0x1
   1194c:      	and	x13, x12, #0x7f
   11950:      	lsl	x13, x13, x10
   11954:      	add	x10, x10, #0x7
   11958:      	orr	x9, x13, x9
   1195c:      	tbnz	w12, #0x7, 0x1193c <_ZN5mtgif9Video2Gif3runEv+0x2f64>
   11960:      	sub	w11, w10, #0x7
   11964:      	mov	x13, #-0x1              // =-1
   11968:      	stur	x8, [x29, #-0x8]
   1196c:      	cmp	w11, #0x39
   11970:      	mov	w11, #0x3f              // =63
   11974:      	lsl	x10, x13, x10
   11978:      	ccmp	w12, w11, #0x0, lo
   1197c:      	csel	x10, x10, xzr, hi
   11980:      	orr	x9, x9, x10
   11984:      	str	x9, [x27, #0x8]!
   11988:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   1198c:      	bti	j
   11990:      	mov	x8, x27
   11994:      	ldr	x9, [x27]
   11998:      	ldr	x10, [x8, #-0x8]!
   1199c:      	and	x9, x10, x9
   119a0:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   119a4:      	bti	j
   119a8:      	mov	x8, x27
   119ac:      	ldr	x9, [x27]
   119b0:      	ldr	x10, [x8, #-0x8]!
   119b4:      	cmp	x10, x9
   119b8:      	cset	w9, hi
   119bc:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   119c0:      	bti	j
   119c4:      	ldursw	x8, [x10, #0x1]
   119c8:      	add	x9, x10, #0x5
   119cc:      	b	0x11adc <_ZN5mtgif9Video2Gif3runEv+0x3104>
   119d0:      	bti	j
   119d4:      	mov	x8, x27
   119d8:      	ldr	x9, [x27]
   119dc:      	ldr	x10, [x8, #-0x8]!
   119e0:      	eor	x9, x10, x9
   119e4:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   119e8:      	bti	j
   119ec:      	ldr	x8, [x27]
   119f0:      	tbz	x8, #0x3f, 0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   119f4:      	b	0x11c14 <_ZN5mtgif9Video2Gif3runEv+0x323c>
   119f8:      	bti	j
   119fc:      	ldrsb	x8, [x10, #0x1]
   11a00:      	b	0x11a40 <_ZN5mtgif9Video2Gif3runEv+0x3068>
   11a04:      	bti	j
   11a08:      	ldr	x8, [x27]
   11a0c:      	b	0x11674 <_ZN5mtgif9Video2Gif3runEv+0x2c9c>
   11a10:      	bti	j
   11a14:      	sub	x0, x29, #0x8
   11a18:      	mov	x1, x20
   11a1c:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   11a20:      	str	x0, [x27, #0x8]!
   11a24:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11a28:      	bti	j
   11a2c:      	ldur	w8, [x10, #0x1]
   11a30:      	add	x9, x10, #0x5
   11a34:      	b	0x11adc <_ZN5mtgif9Video2Gif3runEv+0x3104>
   11a38:      	bti	j
   11a3c:      	ldrb	w8, [x10, #0x1]
   11a40:      	add	x9, x10, #0x2
   11a44:      	b	0x11adc <_ZN5mtgif9Video2Gif3runEv+0x3104>
   11a48:      	bti	j
   11a4c:      	sub	x27, x27, #0x8
   11a50:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11a54:      	bti	j
   11a58:      	ldurh	w8, [x10, #0x1]
   11a5c:      	add	x9, x10, #0x3
   11a60:      	b	0x11adc <_ZN5mtgif9Video2Gif3runEv+0x3104>
   11a64:      	bti	j
   11a68:      	ldr	x8, [x27]
   11a6c:      	ldr	x8, [x8]
   11a70:      	str	x8, [x27]
   11a74:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11a78:      	bti	j
   11a7c:      	ldur	q0, [x27, #-0x10]
   11a80:      	ldr	x8, [x27]
   11a84:      	stur	q0, [x27, #-0x8]
   11a88:      	stur	x8, [x27, #-0x10]
   11a8c:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11a90:      	bti	j
   11a94:      	mov	x8, x27
   11a98:      	ldr	x9, [x27]
   11a9c:      	ldr	x10, [x8, #-0x8]!
   11aa0:      	sdiv	x9, x10, x9
   11aa4:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   11aa8:      	bti	j
   11aac:      	ldur	x8, [x27, #-0x8]
   11ab0:      	b	0x11674 <_ZN5mtgif9Video2Gif3runEv+0x2c9c>
   11ab4:      	bti	j
   11ab8:      	ldur	q0, [x27, #-0x8]
   11abc:      	ext	v0.16b, v0.16b, v0.16b, #0x8
   11ac0:      	stur	q0, [x27, #-0x8]
   11ac4:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11ac8:      	bti	j
   11acc:      	ldrb	w8, [x10, #0x1]
   11ad0:      	add	x9, x10, #0x2
   11ad4:      	sub	x8, x27, x8, lsl #3
   11ad8:      	ldr	x8, [x8]
   11adc:      	stur	x9, [x29, #-0x8]
   11ae0:      	b	0x11674 <_ZN5mtgif9Video2Gif3runEv+0x2c9c>
   11ae4:      	bti	j
   11ae8:      	ldr	x8, [x27]
   11aec:      	mvn	x8, x8
   11af0:      	str	x8, [x27]
   11af4:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11af8:      	bti	j
   11afc:      	mov	x8, x27
   11b00:      	ldr	x9, [x27]
   11b04:      	ldr	x10, [x8, #-0x8]!
   11b08:      	lsl	x9, x10, x9
   11b0c:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   11b10:      	bti	j
   11b14:      	mov	x8, x27
   11b18:      	ldr	x9, [x27]
   11b1c:      	ldr	x10, [x8, #-0x8]!
   11b20:      	lsr	x9, x10, x9
   11b24:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   11b28:      	bti	j
   11b2c:      	mov	x8, x27
   11b30:      	ldr	x9, [x27]
   11b34:      	ldr	x10, [x8, #-0x8]!
   11b38:      	add	x9, x10, x9
   11b3c:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   11b40:      	bti	j
   11b44:      	add	x8, x10, #0x2
   11b48:      	stur	x8, [x29, #-0x8]
   11b4c:      	ldr	x8, [x27]
   11b50:      	ldrb	w9, [x10, #0x1]
   11b54:      	cmp	w9, #0x3
   11b58:      	b.gt	0x11c98 <_ZN5mtgif9Video2Gif3runEv+0x32c0>
   11b5c:      	cmp	w9, #0x1
   11b60:      	b.eq	0x11d58 <_ZN5mtgif9Video2Gif3runEv+0x3380>
   11b64:      	cmp	w9, #0x2
   11b68:      	b.ne	0x11f14 <_ZN5mtgif9Video2Gif3runEv+0x353c>
   11b6c:      	ldrh	w8, [x8]
   11b70:      	str	x8, [x27]
   11b74:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11b78:      	bti	j
   11b7c:      	sub	x0, x29, #0x8
   11b80:      	mov	x1, x20
   11b84:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   11b88:      	ldr	x8, [x27]
   11b8c:      	add	x8, x8, x0
   11b90:      	str	x8, [x27]
   11b94:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11b98:      	bti	j
   11b9c:      	mov	x8, x27
   11ba0:      	ldr	x9, [x27]
   11ba4:      	ldr	x10, [x8, #-0x8]!
   11ba8:      	asr	x9, x10, x9
   11bac:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   11bb0:      	bti	j
   11bb4:      	ldr	x8, [x27]
   11bb8:      	ldr	x8, [x8]
   11bbc:      	str	x8, [x27, #-0x8]!
   11bc0:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11bc4:      	bti	j
   11bc8:      	mov	x8, x27
   11bcc:      	ldr	x9, [x27]
   11bd0:      	ldr	x10, [x8, #-0x8]!
   11bd4:      	mul	x9, x10, x9
   11bd8:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   11bdc:      	bti	j
   11be0:      	mov	x8, x27
   11be4:      	ldr	x9, [x27]
   11be8:      	ldr	x10, [x8, #-0x8]!
   11bec:      	sub	x9, x10, x9
   11bf0:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   11bf4:      	bti	j
   11bf8:      	mov	x8, x27
   11bfc:      	ldr	x9, [x27]
   11c00:      	ldr	x10, [x8, #-0x8]!
   11c04:      	orr	x9, x10, x9
   11c08:      	b	0x11c38 <_ZN5mtgif9Video2Gif3runEv+0x3260>
   11c0c:      	bti	j
   11c10:      	ldr	x8, [x27]
   11c14:      	neg	x8, x8
   11c18:      	str	x8, [x27]
   11c1c:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11c20:      	bti	j
   11c24:      	mov	x8, x27
   11c28:      	ldr	x9, [x27]
   11c2c:      	ldr	x10, [x8, #-0x8]!
   11c30:      	cmp	x10, x9
   11c34:      	cset	w9, ne
   11c38:      	str	x9, [x8]
   11c3c:      	mov	x27, x8
   11c40:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11c44:      	bti	j
   11c48:      	ldursh	x8, [x10, #0x1]
   11c4c:      	add	x8, x10, x8
   11c50:      	add	x8, x8, #0x3
   11c54:      	stur	x8, [x29, #-0x8]
   11c58:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11c5c:      	bti	j
   11c60:      	sub	x0, x29, #0x8
   11c64:      	mov	x1, x20
   11c68:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   11c6c:      	cmp	w0, #0x1d
   11c70:      	b.le	0x11cac <_ZN5mtgif9Video2Gif3runEv+0x32d4>
   11c74:      	cmp	w0, #0x1f
   11c78:      	b.gt	0x11cfc <_ZN5mtgif9Video2Gif3runEv+0x3324>
   11c7c:      	cmp	w0, #0x1e
   11c80:      	mov	x8, x21
   11c84:      	b.eq	0x11670 <_ZN5mtgif9Video2Gif3runEv+0x2c98>
   11c88:      	cmp	w0, #0x1f
   11c8c:      	mov	x8, x24
   11c90:      	b.eq	0x11670 <_ZN5mtgif9Video2Gif3runEv+0x2c98>
   11c94:      	b	0x11d14 <_ZN5mtgif9Video2Gif3runEv+0x333c>
   11c98:      	cmp	w9, #0x4
   11c9c:      	b.eq	0x11d64 <_ZN5mtgif9Video2Gif3runEv+0x338c>
   11ca0:      	cmp	w9, #0x8
   11ca4:      	b.eq	0x11a6c <_ZN5mtgif9Video2Gif3runEv+0x3094>
   11ca8:      	b	0x11f14 <_ZN5mtgif9Video2Gif3runEv+0x353c>
   11cac:      	cmn	w0, #0x2
   11cb0:      	mov	x8, x24
   11cb4:      	b.eq	0x11670 <_ZN5mtgif9Video2Gif3runEv+0x2c98>
   11cb8:      	cmn	w0, #0x1
   11cbc:      	mov	x8, x25
   11cc0:      	b.eq	0x11670 <_ZN5mtgif9Video2Gif3runEv+0x2c98>
   11cc4:      	cmp	w0, #0x1d
   11cc8:      	mov	x8, x22
   11ccc:      	b.eq	0x11670 <_ZN5mtgif9Video2Gif3runEv+0x2c98>
   11cd0:      	b	0x11d14 <_ZN5mtgif9Video2Gif3runEv+0x333c>
   11cd4:      	cmn	w0, #0x2
   11cd8:      	mov	x10, x24
   11cdc:      	b.eq	0x11d48 <_ZN5mtgif9Video2Gif3runEv+0x3370>
   11ce0:      	cmn	w0, #0x1
   11ce4:      	mov	x10, x25
   11ce8:      	b.eq	0x11d48 <_ZN5mtgif9Video2Gif3runEv+0x3370>
   11cec:      	cmp	w0, #0x1d
   11cf0:      	mov	x10, x22
   11cf4:      	b.eq	0x11d48 <_ZN5mtgif9Video2Gif3runEv+0x3370>
   11cf8:      	b	0x11d3c <_ZN5mtgif9Video2Gif3runEv+0x3364>
   11cfc:      	cmp	w0, #0x20
   11d00:      	mov	x8, x25
   11d04:      	b.eq	0x11670 <_ZN5mtgif9Video2Gif3runEv+0x2c98>
   11d08:      	cmp	w0, #0x22
   11d0c:      	mov	x8, x23
   11d10:      	b.eq	0x11670 <_ZN5mtgif9Video2Gif3runEv+0x2c98>
   11d14:      	cmp	w0, #0x1c
   11d18:      	b.hi	0x11f7c <_ZN5mtgif9Video2Gif3runEv+0x35a4>
   11d1c:      	add	x8, x19, w0, uxtw #3
   11d20:      	b	0x11670 <_ZN5mtgif9Video2Gif3runEv+0x2c98>
   11d24:      	cmp	w0, #0x20
   11d28:      	mov	x10, x25
   11d2c:      	b.eq	0x11d48 <_ZN5mtgif9Video2Gif3runEv+0x3370>
   11d30:      	cmp	w0, #0x22
   11d34:      	mov	x10, x23
   11d38:      	b.eq	0x11d48 <_ZN5mtgif9Video2Gif3runEv+0x3370>
   11d3c:      	cmp	w0, #0x1c
   11d40:      	b.hi	0x11f48 <_ZN5mtgif9Video2Gif3runEv+0x3570>
   11d44:      	add	x10, x19, w0, uxtw #3
   11d48:      	ldr	x10, [x10]
   11d4c:      	orr	x8, x8, x9
   11d50:      	add	x8, x10, x8
   11d54:      	b	0x11674 <_ZN5mtgif9Video2Gif3runEv+0x2c9c>
   11d58:      	ldrb	w8, [x8]
   11d5c:      	str	x8, [x27]
   11d60:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11d64:      	ldr	w8, [x8]
   11d68:      	str	x8, [x27]
   11d6c:      	b	0x11678 <_ZN5mtgif9Video2Gif3runEv+0x2ca0>
   11d70:      	ldr	x21, [x27]
   11d74:      	mov	x0, x21
   11d78:      	add	sp, sp, #0x330
   11d7c:      	ldp	x20, x19, [sp, #0x50]
   11d80:      	ldp	x22, x21, [sp, #0x40]
   11d84:      	ldp	x24, x23, [sp, #0x30]
   11d88:      	ldp	x26, x25, [sp, #0x20]
   11d8c:      	ldp	x28, x27, [sp, #0x10]
   11d90:      	ldp	x29, x30, [sp], #0x60
   11d94:      	autiasp
   11d98:      	ret
   11d9c:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   11da0:      	nop
   11da4:      	adr	x1, 0x55ec
   11da8:      	ldr	x19, [x19, #0x7e8]
   11dac:      	adrp	x2, 0x5000
   11db0:      	add	x2, x2, #0xbcd
   11db4:      	adrp	x3, 0x5000
   11db8:      	add	x3, x3, #0x958
   11dbc:      	add	x0, x19, #0x130
   11dc0:      	bl	0x133b0 <fprintf@plt>
   11dc4:      	add	x0, x19, #0x130
   11dc8:      	bl	0x131c0 <fflush@plt>
   11dcc:      	bl	0x133c0 <abort@plt>
   11dd0:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   11dd4:      	nop
   11dd8:      	adr	x1, 0x55ec
   11ddc:      	ldr	x19, [x19, #0x7e8]
   11de0:      	adrp	x2, 0x5000
   11de4:      	add	x2, x2, #0xbcd
   11de8:      	adrp	x3, 0x5000
   11dec:      	add	x3, x3, #0x958
   11df0:      	add	x0, x19, #0x130
   11df4:      	bl	0x133b0 <fprintf@plt>
   11df8:      	add	x0, x19, #0x130
   11dfc:      	bl	0x131c0 <fflush@plt>
   11e00:      	bl	0x133c0 <abort@plt>
   11e04:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   11e08:      	nop
   11e0c:      	adr	x1, 0x55ec
   11e10:      	ldr	x19, [x19, #0x7e8]
   11e14:      	adrp	x2, 0x5000
   11e18:      	add	x2, x2, #0xbcd
   11e1c:      	adrp	x3, 0x5000
   11e20:      	add	x3, x3, #0x958
   11e24:      	add	x0, x19, #0x130
   11e28:      	bl	0x133b0 <fprintf@plt>
   11e2c:      	add	x0, x19, #0x130
   11e30:      	bl	0x131c0 <fflush@plt>
   11e34:      	bl	0x133c0 <abort@plt>
   11e38:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   11e3c:      	nop
   11e40:      	adr	x1, 0x55ec
   11e44:      	ldr	x19, [x19, #0x7e8]
   11e48:      	adrp	x2, 0x5000
   11e4c:      	add	x2, x2, #0xae3
   11e50:      	adrp	x3, 0x5000
   11e54:      	add	x3, x3, #0x901
   11e58:      	add	x0, x19, #0x130
   11e5c:      	bl	0x133b0 <fprintf@plt>
   11e60:      	add	x0, x19, #0x130
   11e64:      	bl	0x131c0 <fflush@plt>
   11e68:      	bl	0x133c0 <abort@plt>
   11e6c:      	bti	j
   11e70:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   11e74:      	nop
   11e78:      	adr	x1, 0x55ec
   11e7c:      	ldr	x19, [x19, #0x7e8]
   11e80:      	adrp	x2, 0x5000
   11e84:      	add	x2, x2, #0x9c3
   11e88:      	adrp	x3, 0x5000
   11e8c:      	add	x3, x3, #0xd83
   11e90:      	add	x0, x19, #0x130
   11e94:      	bl	0x133b0 <fprintf@plt>
   11e98:      	add	x0, x19, #0x130
   11e9c:      	bl	0x131c0 <fflush@plt>
   11ea0:      	bl	0x133c0 <abort@plt>
   11ea4:      	bti	j
   11ea8:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   11eac:      	nop
   11eb0:      	adr	x1, 0x55ec
   11eb4:      	ldr	x19, [x19, #0x7e8]
   11eb8:      	adrp	x2, 0x5000
   11ebc:      	add	x2, x2, #0x9c3
   11ec0:      	adrp	x3, 0x5000
   11ec4:      	add	x3, x3, #0x975
   11ec8:      	add	x0, x19, #0x130
   11ecc:      	bl	0x133b0 <fprintf@plt>
   11ed0:      	add	x0, x19, #0x130
   11ed4:      	bl	0x131c0 <fflush@plt>
   11ed8:      	bl	0x133c0 <abort@plt>
   11edc:      	bti	j
   11ee0:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   11ee4:      	nop
   11ee8:      	adr	x1, 0x55ec
   11eec:      	ldr	x19, [x19, #0x7e8]
   11ef0:      	adrp	x2, 0x5000
   11ef4:      	add	x2, x2, #0x9c3
   11ef8:      	adrp	x3, 0x6000
   11efc:      	add	x3, x3, #0xd7
   11f00:      	add	x0, x19, #0x130
   11f04:      	bl	0x133b0 <fprintf@plt>
   11f08:      	add	x0, x19, #0x130
   11f0c:      	bl	0x131c0 <fflush@plt>
   11f10:      	bl	0x133c0 <abort@plt>
   11f14:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   11f18:      	nop
   11f1c:      	adr	x1, 0x55ec
   11f20:      	ldr	x19, [x19, #0x7e8]
   11f24:      	adrp	x2, 0x5000
   11f28:      	add	x2, x2, #0x9c3
   11f2c:      	adrp	x3, 0x5000
   11f30:      	add	x3, x3, #0xbd8
   11f34:      	add	x0, x19, #0x130
   11f38:      	bl	0x133b0 <fprintf@plt>
   11f3c:      	add	x0, x19, #0x130
   11f40:      	bl	0x131c0 <fflush@plt>
   11f44:      	bl	0x133c0 <abort@plt>
   11f48:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   11f4c:      	nop
   11f50:      	adr	x1, 0x55ec
   11f54:      	ldr	x19, [x19, #0x7e8]
   11f58:      	adrp	x2, 0x5000
   11f5c:      	add	x2, x2, #0xae3
   11f60:      	adrp	x3, 0x5000
   11f64:      	add	x3, x3, #0x901
   11f68:      	add	x0, x19, #0x130
   11f6c:      	bl	0x133b0 <fprintf@plt>
   11f70:      	add	x0, x19, #0x130
   11f74:      	bl	0x131c0 <fflush@plt>
   11f78:      	bl	0x133c0 <abort@plt>
   11f7c:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   11f80:      	nop
   11f84:      	adr	x1, 0x55ec
   11f88:      	ldr	x19, [x19, #0x7e8]
   11f8c:      	adrp	x2, 0x5000
   11f90:      	add	x2, x2, #0xae3
   11f94:      	adrp	x3, 0x5000
   11f98:      	add	x3, x3, #0x901
   11f9c:      	add	x0, x19, #0x130
   11fa0:      	bl	0x133b0 <fprintf@plt>
   11fa4:      	add	x0, x19, #0x130
   11fa8:      	bl	0x131c0 <fflush@plt>
   11fac:      	bl	0x133c0 <abort@plt>
   11fb0:      	paciasp
   11fb4:      	stp	x29, x30, [sp, #-0x60]!
   11fb8:      	stp	x28, x27, [sp, #0x10]
   11fbc:      	stp	x26, x25, [sp, #0x20]
   11fc0:      	stp	x24, x23, [sp, #0x30]
   11fc4:      	stp	x22, x21, [sp, #0x40]
   11fc8:      	stp	x20, x19, [sp, #0x50]
   11fcc:      	mov	x29, sp
   11fd0:      	sub	sp, sp, #0x6a0
   11fd4:      	mov	w21, w3
   11fd8:      	mov	x19, x2
   11fdc:      	mov	x22, x1
   11fe0:      	mov	x20, x0
   11fe4:      	cbz	w3, 0x12008 <_ZN5mtgif9Video2Gif3runEv+0x3630>
   11fe8:      	ldp	x2, x3, [x19, #0x10]
   11fec:      	add	x5, sp, #0x50
   11ff0:      	ldr	x0, [x20, #0x8]
   11ff4:      	add	x6, sp, #0x18
   11ff8:      	mov	x1, x22
   11ffc:      	add	x4, x2, w21, uxtw
   12000:      	bl	0x124d8 <_ZN5mtgif9Video2Gif3runEv+0x3b00>
   12004:      	tbnz	w0, #0x0, 0x12120 <_ZN5mtgif9Video2Gif3runEv+0x3748>
   12008:      	ldr	x2, [x19, #0x20]
   1200c:      	cbz	x2, 0x1202c <_ZN5mtgif9Video2Gif3runEv+0x3654>
   12010:      	ldr	x0, [x20, #0x8]
   12014:      	ldr	w3, [x19, #0x28]
   12018:      	add	x4, sp, #0x50
   1201c:      	add	x5, sp, #0x18
   12020:      	mov	x1, x22
   12024:      	bl	0x126a0 <_ZN5mtgif9Video2Gif3runEv+0x3cc8>
   12028:      	tbnz	w0, #0x0, 0x12120 <_ZN5mtgif9Video2Gif3runEv+0x3748>
   1202c:      	ldr	x23, [x19]
   12030:      	nop
   12034:      	adr	x0, 0x1bd2c <g_gifReader+0xc>
   12038:      	bl	0x133f0 <pthread_rwlock_rdlock@plt>
   1203c:      	adrp	x8, 0x1b000
   12040:      	adrp	x9, 0x1b000
   12044:      	ldr	x8, [x8, #0xd00]
   12048:      	ldr	x9, [x9, #0xd08]
   1204c:      	cmp	x8, x9
   12050:      	b.hs	0x120f4 <_ZN5mtgif9Video2Gif3runEv+0x371c>
   12054:      	cmn	x23, #0x1
   12058:      	b.ne	0x1206c <_ZN5mtgif9Video2Gif3runEv+0x3694>
   1205c:      	b	0x120a0 <_ZN5mtgif9Video2Gif3runEv+0x36c8>
   12060:      	add	x8, x8, #0x20
   12064:      	cmp	x8, x9
   12068:      	b.hs	0x120f4 <_ZN5mtgif9Video2Gif3runEv+0x371c>
   1206c:      	ldr	x10, [x8]
   12070:      	cmp	x10, x23
   12074:      	b.ne	0x12060 <_ZN5mtgif9Video2Gif3runEv+0x3688>
   12078:      	ldr	x10, [x8, #0x8]
   1207c:      	cmp	x10, x22
   12080:      	b.hi	0x12060 <_ZN5mtgif9Video2Gif3runEv+0x3688>
   12084:      	ldr	x10, [x8, #0x10]
   12088:      	cmp	x10, x22
   1208c:      	b.ls	0x12060 <_ZN5mtgif9Video2Gif3runEv+0x3688>
   12090:      	b	0x120b8 <_ZN5mtgif9Video2Gif3runEv+0x36e0>
   12094:      	add	x8, x8, #0x20
   12098:      	cmp	x8, x9
   1209c:      	b.hs	0x120f4 <_ZN5mtgif9Video2Gif3runEv+0x371c>
   120a0:      	ldr	x10, [x8, #0x8]
   120a4:      	cmp	x10, x22
   120a8:      	b.hi	0x12094 <_ZN5mtgif9Video2Gif3runEv+0x36bc>
   120ac:      	ldr	x10, [x8, #0x10]
   120b0:      	cmp	x10, x22
   120b4:      	b.ls	0x12094 <_ZN5mtgif9Video2Gif3runEv+0x36bc>
   120b8:      	ldr	x23, [x8, #0x18]
   120bc:      	nop
   120c0:      	adr	x0, 0x1bd2c <g_gifReader+0xc>
   120c4:      	bl	0x133e0 <pthread_rwlock_unlock@plt>
   120c8:      	cbz	x23, 0x12100 <_ZN5mtgif9Video2Gif3runEv+0x3728>
   120cc:      	ldp	x2, x3, [x19, #0x10]
   120d0:      	add	x5, sp, #0x50
   120d4:      	ldr	x0, [x20, #0x8]
   120d8:      	add	x6, sp, #0x18
   120dc:      	mov	x1, x22
   120e0:      	mov	x4, x23
   120e4:      	bl	0x124d8 <_ZN5mtgif9Video2Gif3runEv+0x3b00>
   120e8:      	tbz	w0, #0x0, 0x12100 <_ZN5mtgif9Video2Gif3runEv+0x3728>
   120ec:      	mov	w24, wzr
   120f0:      	b	0x12124 <_ZN5mtgif9Video2Gif3runEv+0x374c>
   120f4:      	nop
   120f8:      	adr	x0, 0x1bd2c <g_gifReader+0xc>
   120fc:      	bl	0x133e0 <pthread_rwlock_unlock@plt>
   12100:      	ldp	x2, x3, [x19, #0x10]
   12104:      	add	x5, sp, #0x50
   12108:      	ldr	x0, [x20, #0x8]
   1210c:      	add	x6, sp, #0x18
   12110:      	mov	x1, x22
   12114:      	mov	x4, xzr
   12118:      	bl	0x124d8 <_ZN5mtgif9Video2Gif3runEv+0x3b00>
   1211c:      	tbz	w0, #0x0, 0x1225c <_ZN5mtgif9Video2Gif3runEv+0x3884>
   12120:      	mov	w24, #0x1               // =1
   12124:      	ldr	x25, [x19]
   12128:      	add	x0, sp, #0x80
   1212c:      	mov	w1, wzr
   12130:      	mov	w2, #0x618              // =1560
   12134:      	bl	0x130b0 <memset@plt>
   12138:      	ldr	x0, [x20, #0x8]
   1213c:      	add	x1, sp, #0x50
   12140:      	add	x2, sp, #0x18
   12144:      	add	x5, sp, #0x80
   12148:      	mov	x3, x22
   1214c:      	mov	w4, #0x4                // =4
   12150:      	bl	0x10114 <_ZN5mtgif9Video2Gif3runEv+0x173c>
   12154:      	tbz	w0, #0x0, 0x1225c <_ZN5mtgif9Video2Gif3runEv+0x3884>
   12158:      	ldr	q0, [sp, #0x70]
   1215c:      	add	x8, x20, #0x220
   12160:      	ldr	x9, [sp, #0x38]
   12164:      	ldr	x22, [sp, #0x68]
   12168:      	cmp	w21, #0x0
   1216c:      	mov	w0, #0x1                // =1
   12170:      	stur	q0, [x8, #0x8]
   12174:      	ldr	w8, [sp, #0x90]
   12178:      	str	x9, [x20, #0x238]
   1217c:      	eor	w9, w24, #0x1
   12180:      	str	x8, [x20, #0x240]
   12184:      	mov	w8, #0x3000000          // =50331648
   12188:      	str	w8, [x20, #0x250]
   1218c:      	ldp	x23, x8, [sp, #0x50]
   12190:      	str	x22, [x20, #0x220]
   12194:      	str	xzr, [x20, #0x248]
   12198:      	str	w8, [x20, #0x254]
   1219c:      	csinc	w8, w9, wzr, eq
   121a0:      	str	x23, [x20, #0x258]
   121a4:      	str	x25, [x20, #0x260]
   121a8:      	tbnz	w8, #0x0, 0x12260 <_ZN5mtgif9Video2Gif3runEv+0x3888>
   121ac:      	ldr	x8, [x19, #0x20]
   121b0:      	cbnz	x8, 0x12260 <_ZN5mtgif9Video2Gif3runEv+0x3888>
   121b4:      	ldr	x24, [x19]
   121b8:      	nop
   121bc:      	adr	x0, 0x1bd2c <g_gifReader+0xc>
   121c0:      	str	q0, [sp]
   121c4:      	bl	0x133d0 <pthread_rwlock_wrlock@plt>
   121c8:      	adrp	x25, 0x1b000
   121cc:      	adrp	x26, 0x1b000
   121d0:      	ldr	x8, [x25, #0xd08]
   121d4:      	ldr	x9, [x26, #0xd10]
   121d8:      	cmp	x8, x9
   121dc:      	b.lo	0x12230 <_ZN5mtgif9Video2Gif3runEv+0x3858>
   121e0:      	adrp	x27, 0x1b000
   121e4:      	ldr	x21, [x27, #0xd00]
   121e8:      	sub	x19, x9, x21
   121ec:      	lsl	x0, x19, #2
   121f0:      	asr	x28, x19, #3
   121f4:      	bl	0x12aa0 <malloc@plt>
   121f8:      	mov	x1, x21
   121fc:      	mov	x2, x19
   12200:      	mov	x20, x0
   12204:      	bl	0x12e70 <memcpy@plt>
   12208:      	nop
   1220c:      	adr	x8, 0x1bd68 <g_gifReader+0x48>
   12210:      	cmp	x21, x8
   12214:      	b.eq	0x12220 <_ZN5mtgif9Video2Gif3runEv+0x3848>
   12218:      	mov	x0, x21
   1221c:      	bl	0x12f40 <free@plt>
   12220:      	add	x9, x20, x28, lsl #5
   12224:      	add	x8, x20, x19
   12228:      	str	x20, [x27, #0xd00]
   1222c:      	str	x9, [x26, #0xd10]
   12230:      	ldr	q0, [sp]
   12234:      	stp	x24, x22, [x8]
   12238:      	nop
   1223c:      	adr	x0, 0x1bd2c <g_gifReader+0xc>
   12240:      	str	x23, [x8, #0x18]
   12244:      	str	d0, [x8, #0x10]
   12248:      	add	x8, x8, #0x20
   1224c:      	str	x8, [x25, #0xd08]
   12250:      	bl	0x133e0 <pthread_rwlock_unlock@plt>
   12254:      	mov	w0, #0x1                // =1
   12258:      	b	0x12260 <_ZN5mtgif9Video2Gif3runEv+0x3888>
   1225c:      	mov	w0, wzr
   12260:      	add	sp, sp, #0x6a0
   12264:      	ldp	x20, x19, [sp, #0x50]
   12268:      	ldp	x22, x21, [sp, #0x40]
   1226c:      	ldp	x24, x23, [sp, #0x30]
   12270:      	ldp	x26, x25, [sp, #0x20]
   12274:      	ldp	x28, x27, [sp, #0x10]
   12278:      	ldp	x29, x30, [sp], #0x60
   1227c:      	autiasp
   12280:      	ret
   12284:      	paciasp
   12288:      	sub	sp, sp, #0x70
   1228c:      	stp	x29, x30, [sp, #0x20]
   12290:      	str	x25, [sp, #0x30]
   12294:      	stp	x24, x23, [sp, #0x40]
   12298:      	stp	x22, x21, [sp, #0x50]
   1229c:      	stp	x20, x19, [sp, #0x60]
   122a0:      	add	x29, sp, #0x20
   122a4:      	ldrh	w21, [x0, #0x18]
   122a8:      	cbz	x21, 0x122c4 <_ZN5mtgif9Video2Gif3runEv+0x38ec>
   122ac:      	ldr	x8, [x2, #0x10]
   122b0:      	ldr	x22, [x0]
   122b4:      	mov	x20, x0
   122b8:      	mov	x19, x2
   122bc:      	cmp	x8, x22
   122c0:      	b.hs	0x122e8 <_ZN5mtgif9Video2Gif3runEv+0x3910>
   122c4:      	mov	w0, wzr
   122c8:      	ldp	x20, x19, [sp, #0x60]
   122cc:      	ldr	x25, [sp, #0x30]
   122d0:      	ldp	x22, x21, [sp, #0x50]
   122d4:      	ldp	x24, x23, [sp, #0x40]
   122d8:      	ldp	x29, x30, [sp, #0x20]
   122dc:      	add	sp, sp, #0x70
   122e0:      	autiasp
   122e4:      	ret
   122e8:      	ldr	x11, [x20, #0x10]
   122ec:      	mov	x9, x21
   122f0:      	mov	x10, x11
   122f4:      	b	0x12304 <_ZN5mtgif9Video2Gif3runEv+0x392c>
   122f8:      	subs	x9, x9, #0x1
   122fc:      	mov	x11, x10
   12300:      	b.eq	0x122c4 <_ZN5mtgif9Video2Gif3runEv+0x38ec>
   12304:      	ldr	w12, [x10], #0x38
   12308:      	cmp	w12, #0x1
   1230c:      	b.ne	0x122f8 <_ZN5mtgif9Video2Gif3runEv+0x3920>
   12310:      	ldr	x12, [x11, #0x10]
   12314:      	add	x12, x12, x22
   12318:      	cmp	x8, x12
   1231c:      	b.lo	0x122f8 <_ZN5mtgif9Video2Gif3runEv+0x3920>
   12320:      	ldr	x11, [x11, #0x28]
   12324:      	add	x13, x11, x12
   12328:      	cmp	x8, x13
   1232c:      	b.hs	0x122f8 <_ZN5mtgif9Video2Gif3runEv+0x3920>
   12330:      	ldr	x8, [x19, #0x8]
   12334:      	mov	w9, #-0x1               // =-1
   12338:      	mov	w25, #0xe550            // =58704
   1233c:      	add	x23, x21, x9
   12340:      	mov	w24, #0x38              // =56
   12344:      	movk	w25, #0x6474, lsl #16
   12348:      	stp	x12, x11, [x8]
   1234c:      	b	0x12360 <_ZN5mtgif9Video2Gif3runEv+0x3988>
   12350:      	sub	w21, w21, #0x1
   12354:      	sub	x23, x23, #0x1
   12358:      	and	w8, w21, #0xffff
   1235c:      	cbz	w8, 0x122c4 <_ZN5mtgif9Video2Gif3runEv+0x38ec>
   12360:      	and	x8, x23, #0xffffffff
   12364:      	ldr	x9, [x20, #0x10]
   12368:      	umull	x10, w8, w24
   1236c:      	ldr	w10, [x9, x10]
   12370:      	cmp	w10, w25
   12374:      	b.ne	0x12350 <_ZN5mtgif9Video2Gif3runEv+0x3978>
   12378:      	umaddl	x8, w8, w24, x9
   1237c:      	ldp	x0, x10, [x19]
   12380:      	mov	x3, sp
   12384:      	ldr	x9, [x8, #0x10]
   12388:      	ldr	x8, [x8, #0x28]
   1238c:      	add	x1, x9, x22
   12390:      	add	x2, x8, x1
   12394:      	stp	x1, x8, [x10, #0x20]
   12398:      	bl	0x123b8 <_ZN5mtgif9Video2Gif3runEv+0x39e0>
   1239c:      	tbz	w0, #0x0, 0x12350 <_ZN5mtgif9Video2Gif3runEv+0x3978>
   123a0:      	ldr	x8, [sp]
   123a4:      	ldr	x9, [x19, #0x8]
   123a8:      	mov	x10, #-0x1              // =-1
   123ac:      	mov	w0, #0x1                // =1
   123b0:      	stp	x8, x10, [x9, #0x10]
   123b4:      	b	0x122c8 <_ZN5mtgif9Video2Gif3runEv+0x38f0>
   123b8:      	paciasp
   123bc:      	stp	x29, x30, [sp, #-0x40]!
   123c0:      	str	x23, [sp, #0x10]
   123c4:      	stp	x22, x21, [sp, #0x20]
   123c8:      	stp	x20, x19, [sp, #0x30]
   123cc:      	mov	x29, sp
   123d0:      	mov	x20, x3
   123d4:      	sub	x3, x2, x1
   123d8:      	mov	x19, x1
   123dc:      	cmp	x3, #0x3
   123e0:      	b.hi	0x1240c <_ZN5mtgif9Video2Gif3runEv+0x3a34>
   123e4:      	cmp	x2, x19
   123e8:      	b.eq	0x12494 <_ZN5mtgif9Video2Gif3runEv+0x3abc>
   123ec:      	adrp	x20, 0x17000 <syscall@plt+0x3bf0>
   123f0:      	adrp	x1, 0x5000
   123f4:      	add	x1, x1, #0xc61
   123f8:      	ldr	x20, [x20, #0x7e8]
   123fc:      	mov	x2, x19
   12400:      	add	x0, x20, #0x130
   12404:      	bl	0x133b0 <fprintf@plt>
   12408:      	b	0x1248c <_ZN5mtgif9Video2Gif3runEv+0x3ab4>
   1240c:      	ldrb	w8, [x19]
   12410:      	cmp	w8, #0x1
   12414:      	b.ne	0x1246c <_ZN5mtgif9Video2Gif3runEv+0x3a94>
   12418:      	add	x8, x19, #0x4
   1241c:      	ldrb	w21, [x19, #0x2]
   12420:      	ldrb	w3, [x19, #0x1]
   12424:      	str	x8, [x29, #0x18]
   12428:      	add	x1, x29, #0x18
   1242c:      	mov	x4, x19
   12430:      	ldrb	w8, [x19, #0x3]
   12434:      	mov	x23, x0
   12438:      	mov	x22, x2
   1243c:      	strb	w8, [x20, #0x18]
   12440:      	bl	0x110a0 <_ZN5mtgif9Video2Gif3runEv+0x26c8>
   12444:      	cmp	w21, #0xff
   12448:      	str	x0, [x20]
   1244c:      	b.eq	0x124b0 <_ZN5mtgif9Video2Gif3runEv+0x3ad8>
   12450:      	add	x1, x29, #0x18
   12454:      	mov	x0, x23
   12458:      	mov	x2, x22
   1245c:      	mov	w3, w21
   12460:      	mov	x4, x19
   12464:      	bl	0x110a0 <_ZN5mtgif9Video2Gif3runEv+0x26c8>
   12468:      	b	0x124b4 <_ZN5mtgif9Video2Gif3runEv+0x3adc>
   1246c:      	adrp	x20, 0x17000 <syscall@plt+0x3bf0>
   12470:      	adrp	x1, 0x5000
   12474:      	add	x1, x1, #0x8b8
   12478:      	ldr	x20, [x20, #0x7e8]
   1247c:      	mov	w2, w8
   12480:      	mov	x3, x19
   12484:      	add	x0, x20, #0x130
   12488:      	bl	0x133b0 <fprintf@plt>
   1248c:      	add	x0, x20, #0x130
   12490:      	bl	0x131c0 <fflush@plt>
   12494:      	mov	w0, wzr
   12498:      	ldp	x20, x19, [sp, #0x30]
   1249c:      	ldr	x23, [sp, #0x10]
   124a0:      	ldp	x22, x21, [sp, #0x20]
   124a4:      	ldp	x29, x30, [sp], #0x40
   124a8:      	autiasp
   124ac:      	ret
   124b0:      	mov	x0, xzr
   124b4:      	ldr	x8, [x29, #0x18]
   124b8:      	stp	x0, x8, [x20, #0x8]
   124bc:      	mov	w0, #0x1                // =1
   124c0:      	ldp	x20, x19, [sp, #0x30]
   124c4:      	ldr	x23, [sp, #0x10]
   124c8:      	ldp	x22, x21, [sp, #0x20]
   124cc:      	ldp	x29, x30, [sp], #0x40
   124d0:      	autiasp
   124d4:      	ret
   124d8:      	paciasp
   124dc:      	sub	sp, sp, #0x70
   124e0:      	stp	x29, x30, [sp, #0x10]
   124e4:      	stp	x28, x27, [sp, #0x20]
   124e8:      	stp	x26, x25, [sp, #0x30]
   124ec:      	stp	x24, x23, [sp, #0x40]
   124f0:      	stp	x22, x21, [sp, #0x50]
   124f4:      	stp	x20, x19, [sp, #0x60]
   124f8:      	add	x29, sp, #0x10
   124fc:      	cmp	x4, #0x0
   12500:      	add	x8, x3, x2
   12504:      	csel	x22, x2, x4, eq
   12508:      	cmn	x3, #0x1
   1250c:      	csinv	x27, x8, xzr, ne
   12510:      	str	x22, [sp, #0x8]
   12514:      	cmp	x22, x27
   12518:      	b.hs	0x1265c <_ZN5mtgif9Video2Gif3runEv+0x3c84>
   1251c:      	mov	x21, x6
   12520:      	mov	x19, x5
   12524:      	mov	x23, x2
   12528:      	mov	x24, x1
   1252c:      	mov	x20, x0
   12530:      	b	0x12540 <_ZN5mtgif9Video2Gif3runEv+0x3b68>
   12534:      	cmp	x22, x27
   12538:      	str	x22, [sp, #0x8]
   1253c:      	b.hs	0x1265c <_ZN5mtgif9Video2Gif3runEv+0x3c84>
   12540:      	mov	x8, x22
   12544:      	mov	x26, x22
   12548:      	ldr	w9, [x8], #0x4
   1254c:      	str	x8, [sp, #0x8]
   12550:      	cmn	w9, #0x1
   12554:      	b.ne	0x12564 <_ZN5mtgif9Video2Gif3runEv+0x3b8c>
   12558:      	ldur	x9, [x26, #0x4]
   1255c:      	add	x8, x26, #0xc
   12560:      	str	x8, [sp, #0x8]
   12564:      	cbz	x9, 0x1265c <_ZN5mtgif9Video2Gif3runEv+0x3c84>
   12568:      	ldr	w10, [x8]
   1256c:      	add	x22, x8, x9
   12570:      	cbz	w10, 0x12534 <_ZN5mtgif9Video2Gif3runEv+0x3b5c>
   12574:      	sub	x1, x8, x10
   12578:      	cmp	x1, x23
   1257c:      	b.lo	0x12534 <_ZN5mtgif9Video2Gif3runEv+0x3b5c>
   12580:      	cmp	x1, x27
   12584:      	b.hs	0x12534 <_ZN5mtgif9Video2Gif3runEv+0x3b5c>
   12588:      	mov	x0, x20
   1258c:      	mov	x2, x21
   12590:      	bl	0xf248 <_ZN5mtgif9Video2Gif3runEv+0x870>
   12594:      	cbnz	x0, 0x12534 <_ZN5mtgif9Video2Gif3runEv+0x3b5c>
   12598:      	ldr	x8, [sp, #0x8]
   1259c:      	ldrb	w3, [x21, #0x18]
   125a0:      	add	x1, sp, #0x8
   125a4:      	mov	x0, x20
   125a8:      	mov	x2, x22
   125ac:      	mov	x4, xzr
   125b0:      	add	x8, x8, #0x4
   125b4:      	str	x8, [sp, #0x8]
   125b8:      	bl	0x110a0 <_ZN5mtgif9Video2Gif3runEv+0x26c8>
   125bc:      	ldrb	w8, [x21, #0x18]
   125c0:      	mov	x25, x0
   125c4:      	add	x1, sp, #0x8
   125c8:      	mov	x0, x20
   125cc:      	mov	x2, x22
   125d0:      	mov	x4, xzr
   125d4:      	and	w3, w8, #0xf
   125d8:      	bl	0x110a0 <_ZN5mtgif9Video2Gif3runEv+0x26c8>
   125dc:      	cmp	x25, x24
   125e0:      	b.hs	0x12534 <_ZN5mtgif9Video2Gif3runEv+0x3b5c>
   125e4:      	add	x28, x0, x25
   125e8:      	cmp	x28, x24
   125ec:      	b.lo	0x12534 <_ZN5mtgif9Video2Gif3runEv+0x3b5c>
   125f0:      	ldrb	w8, [x21, #0x31]
   125f4:      	str	xzr, [x19, #0x28]
   125f8:      	cbz	w8, 0x12684 <_ZN5mtgif9Video2Gif3runEv+0x3cac>
   125fc:      	add	x0, sp, #0x8
   12600:      	mov	x1, x22
   12604:      	bl	0x1142c <_ZN5mtgif9Video2Gif3runEv+0x2a54>
   12608:      	ldrb	w8, [x21, #0x19]
   1260c:      	ldr	x24, [sp, #0x8]
   12610:      	cmp	w8, #0xff
   12614:      	add	x23, x24, x0
   12618:      	b.eq	0x12688 <_ZN5mtgif9Video2Gif3runEv+0x3cb0>
   1261c:      	add	x1, sp, #0x8
   12620:      	and	w3, w8, #0xf
   12624:      	mov	x0, x20
   12628:      	mov	x2, x22
   1262c:      	mov	x4, xzr
   12630:      	bl	0x110a0 <_ZN5mtgif9Video2Gif3runEv+0x26c8>
   12634:      	cbz	x0, 0x12688 <_ZN5mtgif9Video2Gif3runEv+0x3cb0>
   12638:      	ldrb	w3, [x21, #0x19]
   1263c:      	add	x1, sp, #0x8
   12640:      	mov	x0, x20
   12644:      	mov	x2, x22
   12648:      	mov	x4, xzr
   1264c:      	str	x24, [sp, #0x8]
   12650:      	bl	0x110a0 <_ZN5mtgif9Video2Gif3runEv+0x26c8>
   12654:      	str	x0, [x19, #0x28]
   12658:      	b	0x12688 <_ZN5mtgif9Video2Gif3runEv+0x3cb0>
   1265c:      	mov	w0, wzr
   12660:      	ldp	x20, x19, [sp, #0x60]
   12664:      	ldp	x22, x21, [sp, #0x50]
   12668:      	ldp	x24, x23, [sp, #0x40]
   1266c:      	ldp	x26, x25, [sp, #0x30]
   12670:      	ldp	x28, x27, [sp, #0x20]
   12674:      	ldp	x29, x30, [sp, #0x10]
   12678:      	add	sp, sp, #0x70
   1267c:      	autiasp
   12680:      	ret
   12684:      	ldr	x23, [sp, #0x8]
   12688:      	sub	x8, x22, x26
   1268c:      	stp	x23, x25, [x19, #0x10]
   12690:      	mov	w0, #0x1                // =1
   12694:      	stp	x26, x8, [x19]
   12698:      	str	x28, [x19, #0x20]
   1269c:      	b	0x12660 <_ZN5mtgif9Video2Gif3runEv+0x3c88>
   126a0:      	paciasp
   126a4:      	sub	sp, sp, #0xa0
   126a8:      	stp	x29, x30, [sp, #0x40]
   126ac:      	stp	x28, x27, [sp, #0x50]
   126b0:      	stp	x26, x25, [sp, #0x60]
   126b4:      	stp	x24, x23, [sp, #0x70]
   126b8:      	stp	x22, x21, [sp, #0x80]
   126bc:      	stp	x20, x19, [sp, #0x90]
   126c0:      	add	x29, sp, #0x40
   126c4:      	add	x24, x2, w3, uxtw
   126c8:      	mov	x23, x2
   126cc:      	mov	x20, x1
   126d0:      	add	x3, sp, #0x20
   126d4:      	mov	x1, x2
   126d8:      	mov	x21, x5
   126dc:      	mov	x2, x24
   126e0:      	mov	x19, x4
   126e4:      	mov	x22, x0
   126e8:      	bl	0x123b8 <_ZN5mtgif9Video2Gif3runEv+0x39e0>
   126ec:      	tbz	w0, #0x0, 0x127e0 <_ZN5mtgif9Video2Gif3runEv+0x3e08>
   126f0:      	ldr	x8, [sp, #0x28]
   126f4:      	cbz	x8, 0x127e0 <_ZN5mtgif9Video2Gif3runEv+0x3e08>
   126f8:      	ldrb	w0, [sp, #0x38]
   126fc:      	stp	x21, x19, [sp, #0x8]
   12700:      	bl	0x12808 <_ZN5mtgif9Video2Gif3runEv+0x3e30>
   12704:      	ldr	x27, [sp, #0x28]
   12708:      	mov	x25, x0
   1270c:      	mov	x26, xzr
   12710:      	cmp	x27, #0x1
   12714:      	b.ls	0x12760 <_ZN5mtgif9Video2Gif3runEv+0x3d88>
   12718:      	lsr	x21, x27, #1
   1271c:      	ldr	x8, [sp, #0x30]
   12720:      	ldrb	w3, [sp, #0x38]
   12724:      	add	x1, sp, #0x18
   12728:      	mov	x0, x22
   1272c:      	mov	x2, x24
   12730:      	add	x19, x21, x26
   12734:      	mov	x4, x23
   12738:      	mul	x28, x19, x25
   1273c:      	add	x8, x8, x28
   12740:      	str	x8, [sp, #0x18]
   12744:      	bl	0x110a0 <_ZN5mtgif9Video2Gif3runEv+0x26c8>
   12748:      	sub	x8, x27, x21
   1274c:      	cmp	x0, x20
   12750:      	csel	x26, x26, x19, hs
   12754:      	csel	x27, x21, x8, hs
   12758:      	b.ne	0x12710 <_ZN5mtgif9Video2Gif3runEv+0x3d38>
   1275c:      	b	0x12764 <_ZN5mtgif9Video2Gif3runEv+0x3d8c>
   12760:      	mul	x28, x26, x25
   12764:      	ldr	x8, [sp, #0x30]
   12768:      	ldrb	w25, [sp, #0x38]
   1276c:      	add	x1, sp, #0x18
   12770:      	mov	x0, x22
   12774:      	mov	x2, x24
   12778:      	mov	x4, x23
   1277c:      	add	x8, x8, x28
   12780:      	mov	w3, w25
   12784:      	str	x8, [sp, #0x18]
   12788:      	bl	0x110a0 <_ZN5mtgif9Video2Gif3runEv+0x26c8>
   1278c:      	add	x1, sp, #0x18
   12790:      	mov	x0, x22
   12794:      	mov	x2, x24
   12798:      	mov	w3, w25
   1279c:      	mov	x4, x23
   127a0:      	bl	0x110a0 <_ZN5mtgif9Video2Gif3runEv+0x26c8>
   127a4:      	ldp	x3, x19, [sp, #0x8]
   127a8:      	mov	x1, x0
   127ac:      	mov	x0, x22
   127b0:      	mov	w4, wzr
   127b4:      	mov	x2, x19
   127b8:      	bl	0xf0b8 <_ZN5mtgif9Video2Gif3runEv+0x6e0>
   127bc:      	cbnz	x0, 0x127e0 <_ZN5mtgif9Video2Gif3runEv+0x3e08>
   127c0:      	ldr	x8, [x19, #0x18]
   127c4:      	cmp	x8, x20
   127c8:      	b.hi	0x127e0 <_ZN5mtgif9Video2Gif3runEv+0x3e08>
   127cc:      	ldr	x8, [x19, #0x20]
   127d0:      	cmp	x8, x20
   127d4:      	b.ls	0x127e0 <_ZN5mtgif9Video2Gif3runEv+0x3e08>
   127d8:      	mov	w0, #0x1                // =1
   127dc:      	b	0x127e4 <_ZN5mtgif9Video2Gif3runEv+0x3e0c>
   127e0:      	mov	w0, wzr
   127e4:      	ldp	x20, x19, [sp, #0x90]
   127e8:      	ldp	x22, x21, [sp, #0x80]
   127ec:      	ldp	x24, x23, [sp, #0x70]
   127f0:      	ldp	x26, x25, [sp, #0x60]
   127f4:      	ldp	x28, x27, [sp, #0x50]
   127f8:      	ldp	x29, x30, [sp, #0x40]
   127fc:      	add	sp, sp, #0xa0
   12800:      	autiasp
   12804:      	ret
   12808:      	paciasp
   1280c:      	stp	x29, x30, [sp, #-0x20]!
   12810:      	str	x19, [sp, #0x10]
   12814:      	mov	x29, sp
   12818:      	and	w8, w0, #0xf
   1281c:      	mov	w0, #0x4                // =4
   12820:      	cmp	w8, #0x8
   12824:      	b.gt	0x12844 <_ZN5mtgif9Video2Gif3runEv+0x3e6c>
   12828:      	cmp	w8, #0x2
   1282c:      	b.le	0x12884 <_ZN5mtgif9Video2Gif3runEv+0x3eac>
   12830:      	cmp	w8, #0x3
   12834:      	b.eq	0x1285c <_ZN5mtgif9Video2Gif3runEv+0x3e84>
   12838:      	cmp	w8, #0x4
   1283c:      	b.eq	0x12870 <_ZN5mtgif9Video2Gif3runEv+0x3e98>
   12840:      	b	0x12890 <_ZN5mtgif9Video2Gif3runEv+0x3eb8>
   12844:      	cmp	w8, #0xa
   12848:      	b.le	0x128c4 <_ZN5mtgif9Video2Gif3runEv+0x3eec>
   1284c:      	cmp	w8, #0xc
   12850:      	b.eq	0x12870 <_ZN5mtgif9Video2Gif3runEv+0x3e98>
   12854:      	cmp	w8, #0xb
   12858:      	b.ne	0x12890 <_ZN5mtgif9Video2Gif3runEv+0x3eb8>
   1285c:      	mov	w0, #0x8                // =8
   12860:      	ldr	x19, [sp, #0x10]
   12864:      	ldp	x29, x30, [sp], #0x20
   12868:      	autiasp
   1286c:      	ret
   12870:      	mov	w0, #0x10               // =16
   12874:      	ldr	x19, [sp, #0x10]
   12878:      	ldp	x29, x30, [sp], #0x20
   1287c:      	autiasp
   12880:      	ret
   12884:      	b.eq	0x12860 <_ZN5mtgif9Video2Gif3runEv+0x3e88>
   12888:      	cmp	w8, #0x1
   1288c:      	b.eq	0x128d0 <_ZN5mtgif9Video2Gif3runEv+0x3ef8>
   12890:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   12894:      	nop
   12898:      	adr	x1, 0x55ec
   1289c:      	ldr	x19, [x19, #0x7e8]
   128a0:      	adrp	x2, 0x5000
   128a4:      	add	x2, x2, #0x946
   128a8:      	adrp	x3, 0x5000
   128ac:      	add	x3, x3, #0xe7e
   128b0:      	add	x0, x19, #0x130
   128b4:      	bl	0x133b0 <fprintf@plt>
   128b8:      	add	x0, x19, #0x130
   128bc:      	bl	0x131c0 <fflush@plt>
   128c0:      	bl	0x133c0 <abort@plt>
   128c4:      	b.eq	0x12860 <_ZN5mtgif9Video2Gif3runEv+0x3e88>
   128c8:      	cmp	w8, #0x9
   128cc:      	b.ne	0x12890 <_ZN5mtgif9Video2Gif3runEv+0x3eb8>
   128d0:      	adrp	x19, 0x17000 <syscall@plt+0x3bf0>
   128d4:      	nop
   128d8:      	adr	x1, 0x55ec
   128dc:      	ldr	x19, [x19, #0x7e8]
   128e0:      	adrp	x2, 0x5000
   128e4:      	add	x2, x2, #0x946
   128e8:      	adrp	x3, 0x5000
   128ec:      	add	x3, x3, #0x7cf
   128f0:      	add	x0, x19, #0x130
   128f4:      	bl	0x133b0 <fprintf@plt>
   128f8:      	add	x0, x19, #0x130
   128fc:      	bl	0x131c0 <fflush@plt>
   12900:      	bl	0x133c0 <abort@plt>
   12904:      	bti	c
   12908:      	add	w8, w0, #0x2
   1290c:      	cmp	w8, #0x61
   12910:      	b.hi	0x12928 <_ZN5mtgif9Video2Gif3runEv+0x3f50>
   12914:      	nop
   12918:      	adr	x9, 0x63bc <_ZTS10CQuantizer+0x194>
   1291c:      	ldrsw	x8, [x9, w8, uxtw #2]
   12920:      	add	x0, x9, x8
   12924:      	ret
   12928:      	adrp	x0, 0x5000
   1292c:      	add	x0, x0, #0xe14
   12930:      	ret
   12934:      	bti	c
   12938:      	ldp	x2, x3, [x0, #0x10]
   1293c:      	ldp	x4, x5, [x0, #0x20]
   12940:      	ldp	x6, x7, [x0, #0x30]
   12944:      	ldp	x8, x9, [x0, #0x40]
   12948:      	ldp	x10, x11, [x0, #0x50]
   1294c:      	ldp	x12, x13, [x0, #0x60]
   12950:      	ldp	x14, x15, [x0, #0x70]
   12954:      	ldp	x18, x19, [x0, #0x90]
   12958:      	ldp	x20, x21, [x0, #0xa0]
   1295c:      	ldp	x22, x23, [x0, #0xb0]
   12960:      	ldp	x24, x25, [x0, #0xc0]
   12964:      	ldp	x26, x27, [x0, #0xd0]
   12968:      	ldp	x28, x29, [x0, #0xe0]
   1296c:      	ldr	x30, [x0, #0x100]
   12970:      	ldp	d0, d1, [x0, #0x110]
   12974:      	ldp	d2, d3, [x0, #0x120]
   12978:      	ldp	d4, d5, [x0, #0x130]
   1297c:      	ldp	d6, d7, [x0, #0x140]
   12980:      	ldp	d8, d9, [x0, #0x150]
   12984:      	ldp	d10, d11, [x0, #0x160]
   12988:      	ldp	d12, d13, [x0, #0x170]
   1298c:      	ldp	d14, d15, [x0, #0x180]
   12990:      	ldp	d16, d17, [x0, #0x190]
   12994:      	ldp	d18, d19, [x0, #0x1a0]
   12998:      	ldp	d20, d21, [x0, #0x1b0]
   1299c:      	ldp	d22, d23, [x0, #0x1c0]
   129a0:      	ldp	d24, d25, [x0, #0x1d0]
   129a4:      	ldp	d26, d27, [x0, #0x1e0]
   129a8:      	ldp	d28, d29, [x0, #0x1f0]
   129ac:      	ldr	d30, [x0, #0x200]
   129b0:      	ldr	d31, [x0, #0x208]
   129b4:      	ldr	x16, [x0, #0xf8]
   129b8:      	ldp	x0, x1, [x0]
   129bc:      	mov	sp, x16
   129c0:      	ret
   129c4:      	bti	c
   129c8:      	stp	x0, x1, [x0]
   129cc:      	stp	x2, x3, [x0, #0x10]
   129d0:      	stp	x4, x5, [x0, #0x20]
   129d4:      	stp	x6, x7, [x0, #0x30]
   129d8:      	stp	x8, x9, [x0, #0x40]
   129dc:      	stp	x10, x11, [x0, #0x50]
   129e0:      	stp	x12, x13, [x0, #0x60]
   129e4:      	stp	x14, x15, [x0, #0x70]
   129e8:      	stp	x16, x17, [x0, #0x80]
   129ec:      	stp	x18, x19, [x0, #0x90]
   129f0:      	stp	x20, x21, [x0, #0xa0]
   129f4:      	stp	x22, x23, [x0, #0xb0]
   129f8:      	stp	x24, x25, [x0, #0xc0]
   129fc:      	stp	x26, x27, [x0, #0xd0]
   12a00:      	stp	x28, x29, [x0, #0xe0]
   12a04:      	str	x30, [x0, #0xf0]
   12a08:      	mov	x1, sp
   12a0c:      	str	x1, [x0, #0xf8]
   12a10:      	str	x30, [x0, #0x100]
   12a14:      	stp	d0, d1, [x0, #0x110]
   12a18:      	stp	d2, d3, [x0, #0x120]
   12a1c:      	stp	d4, d5, [x0, #0x130]
   12a20:      	stp	d6, d7, [x0, #0x140]
   12a24:      	stp	d8, d9, [x0, #0x150]
   12a28:      	stp	d10, d11, [x0, #0x160]
   12a2c:      	stp	d12, d13, [x0, #0x170]
   12a30:      	stp	d14, d15, [x0, #0x180]
   12a34:      	stp	d16, d17, [x0, #0x190]
   12a38:      	stp	d18, d19, [x0, #0x1a0]
   12a3c:      	stp	d20, d21, [x0, #0x1b0]
   12a40:      	stp	d22, d23, [x0, #0x1c0]
   12a44:      	stp	d24, d25, [x0, #0x1d0]
   12a48:      	stp	d26, d27, [x0, #0x1e0]
   12a4c:      	stp	d28, d29, [x0, #0x1f0]
   12a50:      	str	d30, [x0, #0x200]
   12a54:      	str	d31, [x0, #0x208]
   12a58:      	mov	x0, #0x0                // =0
   12a5c:      	ret

Disassembly of section .plt:

0000000000012a60 <.plt>:
   12a60:      	stp	x16, x30, [sp, #-0x10]!
   12a64:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12a68:      	ldr	x17, [x16, #0x800]
   12a6c:      	add	x16, x16, #0x800
   12a70:      	br	x17
   12a74:      	nop
   12a78:      	nop
   12a7c:      	nop

0000000000012a80 <__cxa_finalize@plt>:
   12a80:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12a84:      	ldr	x17, [x16, #0x808]
   12a88:      	add	x16, x16, #0x808
   12a8c:      	br	x17

0000000000012a90 <__cxa_atexit@plt>:
   12a90:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12a94:      	ldr	x17, [x16, #0x810]
   12a98:      	add	x16, x16, #0x810
   12a9c:      	br	x17

0000000000012aa0 <malloc@plt>:
   12aa0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12aa4:      	ldr	x17, [x16, #0x818]
   12aa8:      	add	x16, x16, #0x818
   12aac:      	br	x17

0000000000012ab0 <av_packet_alloc@plt>:
   12ab0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12ab4:      	ldr	x17, [x16, #0x820]
   12ab8:      	add	x16, x16, #0x820
   12abc:      	br	x17

0000000000012ac0 <pthread_mutex_unlock@plt>:
   12ac0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12ac4:      	ldr	x17, [x16, #0x828]
   12ac8:      	add	x16, x16, #0x828
   12acc:      	br	x17

0000000000012ad0 <pthread_mutex_lock@plt>:
   12ad0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12ad4:      	ldr	x17, [x16, #0x830]
   12ad8:      	add	x16, x16, #0x830
   12adc:      	br	x17

0000000000012ae0 <pthread_cond_wait@plt>:
   12ae0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12ae4:      	ldr	x17, [x16, #0x838]
   12ae8:      	add	x16, x16, #0x838
   12aec:      	br	x17

0000000000012af0 <av_read_frame@plt>:
   12af0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12af4:      	ldr	x17, [x16, #0x840]
   12af8:      	add	x16, x16, #0x840
   12afc:      	br	x17

0000000000012b00 <avcodec_send_packet@plt>:
   12b00:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12b04:      	ldr	x17, [x16, #0x848]
   12b08:      	add	x16, x16, #0x848
   12b0c:      	br	x17

0000000000012b10 <av_packet_unref@plt>:
   12b10:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12b14:      	ldr	x17, [x16, #0x850]
   12b18:      	add	x16, x16, #0x850
   12b1c:      	br	x17

0000000000012b20 <av_frame_alloc@plt>:
   12b20:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12b24:      	ldr	x17, [x16, #0x858]
   12b28:      	add	x16, x16, #0x858
   12b2c:      	br	x17

0000000000012b30 <avcodec_receive_frame@plt>:
   12b30:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12b34:      	ldr	x17, [x16, #0x860]
   12b38:      	add	x16, x16, #0x860
   12b3c:      	br	x17

0000000000012b40 <av_frame_get_best_effort_timestamp@plt>:
   12b40:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12b44:      	ldr	x17, [x16, #0x868]
   12b48:      	add	x16, x16, #0x868
   12b4c:      	br	x17

0000000000012b50 <_ZN13FormatConvert18VideoFormatTranser13_ImageConvertEPP7AVFrame@plt>:
   12b50:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12b54:      	ldr	x17, [x16, #0x870]
   12b58:      	add	x16, x16, #0x870
   12b5c:      	br	x17

0000000000012b60 <_Znwm@plt>:
   12b60:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12b64:      	ldr	x17, [x16, #0x878]
   12b68:      	add	x16, x16, #0x878
   12b6c:      	br	x17

0000000000012b70 <pthread_cond_signal@plt>:
   12b70:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12b74:      	ldr	x17, [x16, #0x880]
   12b78:      	add	x16, x16, #0x880
   12b7c:      	br	x17

0000000000012b80 <av_frame_free@plt>:
   12b80:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12b84:      	ldr	x17, [x16, #0x888]
   12b88:      	add	x16, x16, #0x888
   12b8c:      	br	x17

0000000000012b90 <av_packet_free@plt>:
   12b90:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12b94:      	ldr	x17, [x16, #0x890]
   12b98:      	add	x16, x16, #0x890
   12b9c:      	br	x17

0000000000012ba0 <_ZN13FormatConvert18VideoFormatTranser6_flushEv@plt>:
   12ba0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12ba4:      	ldr	x17, [x16, #0x898]
   12ba8:      	add	x16, x16, #0x898
   12bac:      	br	x17

0000000000012bb0 <_ZN13FormatConvert18VideoFormatTranser8_releaseEv@plt>:
   12bb0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12bb4:      	ldr	x17, [x16, #0x8a0]
   12bb8:      	add	x16, x16, #0x8a0
   12bbc:      	br	x17

0000000000012bc0 <__stack_chk_fail@plt>:
   12bc0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12bc4:      	ldr	x17, [x16, #0x8a8]
   12bc8:      	add	x16, x16, #0x8a8
   12bcc:      	br	x17

0000000000012bd0 <av_image_alloc@plt>:
   12bd0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12bd4:      	ldr	x17, [x16, #0x8b0]
   12bd8:      	add	x16, x16, #0x8b0
   12bdc:      	br	x17

0000000000012be0 <sws_scale@plt>:
   12be0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12be4:      	ldr	x17, [x16, #0x8b8]
   12be8:      	add	x16, x16, #0x8b8
   12bec:      	br	x17

0000000000012bf0 <av_freep@plt>:
   12bf0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12bf4:      	ldr	x17, [x16, #0x8c0]
   12bf8:      	add	x16, x16, #0x8c0
   12bfc:      	br	x17

0000000000012c00 <exit@plt>:
   12c00:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12c04:      	ldr	x17, [x16, #0x8c8]
   12c08:      	add	x16, x16, #0x8c8
   12c0c:      	br	x17

0000000000012c10 <avcodec_is_open@plt>:
   12c10:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12c14:      	ldr	x17, [x16, #0x8d0]
   12c18:      	add	x16, x16, #0x8d0
   12c1c:      	br	x17

0000000000012c20 <avcodec_close@plt>:
   12c20:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12c24:      	ldr	x17, [x16, #0x8d8]
   12c28:      	add	x16, x16, #0x8d8
   12c2c:      	br	x17

0000000000012c30 <avcodec_free_context@plt>:
   12c30:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12c34:      	ldr	x17, [x16, #0x8e0]
   12c38:      	add	x16, x16, #0x8e0
   12c3c:      	br	x17

0000000000012c40 <avformat_close_input@plt>:
   12c40:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12c44:      	ldr	x17, [x16, #0x8e8]
   12c48:      	add	x16, x16, #0x8e8
   12c4c:      	br	x17

0000000000012c50 <sws_freeContext@plt>:
   12c50:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12c54:      	ldr	x17, [x16, #0x8f0]
   12c58:      	add	x16, x16, #0x8f0
   12c5c:      	br	x17

0000000000012c60 <pthread_cond_init@plt>:
   12c60:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12c64:      	ldr	x17, [x16, #0x8f8]
   12c68:      	add	x16, x16, #0x8f8
   12c6c:      	br	x17

0000000000012c70 <pthread_mutex_init@plt>:
   12c70:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12c74:      	ldr	x17, [x16, #0x900]
   12c78:      	add	x16, x16, #0x900
   12c7c:      	br	x17

0000000000012c80 <_ZdlPv@plt>:
   12c80:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12c84:      	ldr	x17, [x16, #0x908]
   12c88:      	add	x16, x16, #0x908
   12c8c:      	br	x17

0000000000012c90 <_ZN13FormatConvert18VideoFormatTranser7prepareEv@plt>:
   12c90:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12c94:      	ldr	x17, [x16, #0x910]
   12c98:      	add	x16, x16, #0x910
   12c9c:      	br	x17

0000000000012ca0 <av_register_all@plt>:
   12ca0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12ca4:      	ldr	x17, [x16, #0x918]
   12ca8:      	add	x16, x16, #0x918
   12cac:      	br	x17

0000000000012cb0 <avformat_network_init@plt>:
   12cb0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12cb4:      	ldr	x17, [x16, #0x920]
   12cb8:      	add	x16, x16, #0x920
   12cbc:      	br	x17

0000000000012cc0 <_ZN13FormatConvert18VideoFormatTranser18_InputMediaInitialEv@plt>:
   12cc0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12cc4:      	ldr	x17, [x16, #0x928]
   12cc8:      	add	x16, x16, #0x928
   12ccc:      	br	x17

0000000000012cd0 <_ZN13FormatConvert18VideoFormatTranser19_OutputMediaInitialEv@plt>:
   12cd0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12cd4:      	ldr	x17, [x16, #0x930]
   12cd8:      	add	x16, x16, #0x930
   12cdc:      	br	x17

0000000000012ce0 <_ZN13FormatConvert18VideoFormatTranser16_SwsMediaInitialEv@plt>:
   12ce0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12ce4:      	ldr	x17, [x16, #0x938]
   12ce8:      	add	x16, x16, #0x938
   12cec:      	br	x17

0000000000012cf0 <avformat_open_input@plt>:
   12cf0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12cf4:      	ldr	x17, [x16, #0x940]
   12cf8:      	add	x16, x16, #0x940
   12cfc:      	br	x17

0000000000012d00 <avformat_find_stream_info@plt>:
   12d00:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12d04:      	ldr	x17, [x16, #0x948]
   12d08:      	add	x16, x16, #0x948
   12d0c:      	br	x17

0000000000012d10 <av_find_best_stream@plt>:
   12d10:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12d14:      	ldr	x17, [x16, #0x950]
   12d18:      	add	x16, x16, #0x950
   12d1c:      	br	x17

0000000000012d20 <avcodec_find_decoder@plt>:
   12d20:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12d24:      	ldr	x17, [x16, #0x958]
   12d28:      	add	x16, x16, #0x958
   12d2c:      	br	x17

0000000000012d30 <avcodec_alloc_context3@plt>:
   12d30:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12d34:      	ldr	x17, [x16, #0x960]
   12d38:      	add	x16, x16, #0x960
   12d3c:      	br	x17

0000000000012d40 <avcodec_parameters_to_context@plt>:
   12d40:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12d44:      	ldr	x17, [x16, #0x968]
   12d48:      	add	x16, x16, #0x968
   12d4c:      	br	x17

0000000000012d50 <av_dict_get@plt>:
   12d50:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12d54:      	ldr	x17, [x16, #0x970]
   12d58:      	add	x16, x16, #0x970
   12d5c:      	br	x17

0000000000012d60 <atoi@plt>:
   12d60:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12d64:      	ldr	x17, [x16, #0x978]
   12d68:      	add	x16, x16, #0x978
   12d6c:      	br	x17

0000000000012d70 <av_image_get_buffer_size@plt>:
   12d70:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12d74:      	ldr	x17, [x16, #0x980]
   12d78:      	add	x16, x16, #0x980
   12d7c:      	br	x17

0000000000012d80 <av_dump_format@plt>:
   12d80:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12d84:      	ldr	x17, [x16, #0x988]
   12d88:      	add	x16, x16, #0x988
   12d8c:      	br	x17

0000000000012d90 <avcodec_open2@plt>:
   12d90:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12d94:      	ldr	x17, [x16, #0x990]
   12d98:      	add	x16, x16, #0x990
   12d9c:      	br	x17

0000000000012da0 <avformat_alloc_output_context2@plt>:
   12da0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12da4:      	ldr	x17, [x16, #0x998]
   12da8:      	add	x16, x16, #0x998
   12dac:      	br	x17

0000000000012db0 <avio_open@plt>:
   12db0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12db4:      	ldr	x17, [x16, #0x9a0]
   12db8:      	add	x16, x16, #0x9a0
   12dbc:      	br	x17

0000000000012dc0 <strlen@plt>:
   12dc0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12dc4:      	ldr	x17, [x16, #0x9a8]
   12dc8:      	add	x16, x16, #0x9a8
   12dcc:      	br	x17

0000000000012dd0 <__strncpy_chk@plt>:
   12dd0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12dd4:      	ldr	x17, [x16, #0x9b0]
   12dd8:      	add	x16, x16, #0x9b0
   12ddc:      	br	x17

0000000000012de0 <avcodec_find_encoder_by_name@plt>:
   12de0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12de4:      	ldr	x17, [x16, #0x9b8]
   12de8:      	add	x16, x16, #0x9b8
   12dec:      	br	x17

0000000000012df0 <avformat_new_stream@plt>:
   12df0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12df4:      	ldr	x17, [x16, #0x9c0]
   12df8:      	add	x16, x16, #0x9c0
   12dfc:      	br	x17

0000000000012e00 <av_opt_set@plt>:
   12e00:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12e04:      	ldr	x17, [x16, #0x9c8]
   12e08:      	add	x16, x16, #0x9c8
   12e0c:      	br	x17

0000000000012e10 <av_dict_set@plt>:
   12e10:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12e14:      	ldr	x17, [x16, #0x9d0]
   12e18:      	add	x16, x16, #0x9d0
   12e1c:      	br	x17

0000000000012e20 <av_dict_free@plt>:
   12e20:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12e24:      	ldr	x17, [x16, #0x9d8]
   12e28:      	add	x16, x16, #0x9d8
   12e2c:      	br	x17

0000000000012e30 <avcodec_parameters_from_context@plt>:
   12e30:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12e34:      	ldr	x17, [x16, #0x9e0]
   12e38:      	add	x16, x16, #0x9e0
   12e3c:      	br	x17

0000000000012e40 <sws_getContext@plt>:
   12e40:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12e44:      	ldr	x17, [x16, #0x9e8]
   12e48:      	add	x16, x16, #0x9e8
   12e4c:      	br	x17

0000000000012e50 <_ZN13FormatConvert18VideoFormatTranser12receiveFrameEPPhPl@plt>:
   12e50:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12e54:      	ldr	x17, [x16, #0x9f0]
   12e58:      	add	x16, x16, #0x9f0
   12e5c:      	br	x17

0000000000012e60 <av_mallocz@plt>:
   12e60:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12e64:      	ldr	x17, [x16, #0x9f8]
   12e68:      	add	x16, x16, #0x9f8
   12e6c:      	br	x17

0000000000012e70 <memcpy@plt>:
   12e70:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12e74:      	ldr	x17, [x16, #0xa00]
   12e78:      	add	x16, x16, #0xa00
   12e7c:      	br	x17

0000000000012e80 <av_rescale_q@plt>:
   12e80:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12e84:      	ldr	x17, [x16, #0xa08]
   12e88:      	add	x16, x16, #0xa08
   12e8c:      	br	x17

0000000000012e90 <_ZN13FormatConvert18VideoFormatTranser4stopEv@plt>:
   12e90:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12e94:      	ldr	x17, [x16, #0xa10]
   12e98:      	add	x16, x16, #0xa10
   12e9c:      	br	x17

0000000000012ea0 <pthread_join@plt>:
   12ea0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12ea4:      	ldr	x17, [x16, #0xa18]
   12ea8:      	add	x16, x16, #0xa18
   12eac:      	br	x17

0000000000012eb0 <pthread_cond_destroy@plt>:
   12eb0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12eb4:      	ldr	x17, [x16, #0xa20]
   12eb8:      	add	x16, x16, #0xa20
   12ebc:      	br	x17

0000000000012ec0 <pthread_mutex_destroy@plt>:
   12ec0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12ec4:      	ldr	x17, [x16, #0xa28]
   12ec8:      	add	x16, x16, #0xa28
   12ecc:      	br	x17

0000000000012ed0 <_ZN13FormatConvert18VideoFormatTranser9doConvertEv@plt>:
   12ed0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12ed4:      	ldr	x17, [x16, #0xa30]
   12ed8:      	add	x16, x16, #0xa30
   12edc:      	br	x17

0000000000012ee0 <avformat_write_header@plt>:
   12ee0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12ee4:      	ldr	x17, [x16, #0xa38]
   12ee8:      	add	x16, x16, #0xa38
   12eec:      	br	x17

0000000000012ef0 <pthread_create@plt>:
   12ef0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12ef4:      	ldr	x17, [x16, #0xa40]
   12ef8:      	add	x16, x16, #0xa40
   12efc:      	br	x17

0000000000012f00 <_ZN13FormatConvert18VideoFormatTranser11_TransMediaEPP8AVPacket@plt>:
   12f00:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12f04:      	ldr	x17, [x16, #0xa48]
   12f08:      	add	x16, x16, #0xa48
   12f0c:      	br	x17

0000000000012f10 <av_interleaved_write_frame@plt>:
   12f10:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12f14:      	ldr	x17, [x16, #0xa50]
   12f18:      	add	x16, x16, #0xa50
   12f1c:      	br	x17

0000000000012f20 <avcodec_send_frame@plt>:
   12f20:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12f24:      	ldr	x17, [x16, #0xa58]
   12f28:      	add	x16, x16, #0xa58
   12f2c:      	br	x17

0000000000012f30 <avcodec_receive_packet@plt>:
   12f30:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12f34:      	ldr	x17, [x16, #0xa60]
   12f38:      	add	x16, x16, #0xa60
   12f3c:      	br	x17

0000000000012f40 <free@plt>:
   12f40:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12f44:      	ldr	x17, [x16, #0xa68]
   12f48:      	add	x16, x16, #0xa68
   12f4c:      	br	x17

0000000000012f50 <__cxa_begin_catch@plt>:
   12f50:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12f54:      	ldr	x17, [x16, #0xa70]
   12f58:      	add	x16, x16, #0xa70
   12f5c:      	br	x17

0000000000012f60 <_ZSt9terminatev@plt>:
   12f60:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12f64:      	ldr	x17, [x16, #0xa78]
   12f68:      	add	x16, x16, #0xa78
   12f6c:      	br	x17

0000000000012f70 <_ZN13FormatConvert18VideoFormatTranser22setInputVideoMediaFileEPc@plt>:
   12f70:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12f74:      	ldr	x17, [x16, #0xa80]
   12f78:      	add	x16, x16, #0xa80
   12f7c:      	br	x17

0000000000012f80 <av_strdup@plt>:
   12f80:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12f84:      	ldr	x17, [x16, #0xa88]
   12f88:      	add	x16, x16, #0xa88
   12f8c:      	br	x17

0000000000012f90 <_ZN13FormatConvert18VideoFormatTranser23setVideoOutputPixFormatENS_16IMAGE_PIX_FORMATE@plt>:
   12f90:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12f94:      	ldr	x17, [x16, #0xa90]
   12f98:      	add	x16, x16, #0xa90
   12f9c:      	br	x17

0000000000012fa0 <_ZN13FormatConvert18VideoFormatTranser18setVideoOutputSizeEii@plt>:
   12fa0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12fa4:      	ldr	x17, [x16, #0xa98]
   12fa8:      	add	x16, x16, #0xa98
   12fac:      	br	x17

0000000000012fb0 <_ZN13FormatConvert18VideoFormatTranserC1Ev@plt>:
   12fb0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12fb4:      	ldr	x17, [x16, #0xaa0]
   12fb8:      	add	x16, x16, #0xaa0
   12fbc:      	br	x17

0000000000012fc0 <_ZN13FormatConvert18VideoFormatTranserD1Ev@plt>:
   12fc0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12fc4:      	ldr	x17, [x16, #0xaa8]
   12fc8:      	add	x16, x16, #0xaa8
   12fcc:      	br	x17

0000000000012fd0 <_ZN11CMTImageGifC1Ev@plt>:
   12fd0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12fd4:      	ldr	x17, [x16, #0xab0]
   12fd8:      	add	x16, x16, #0xab0
   12fdc:      	br	x17

0000000000012fe0 <_ZN5MTGif13SaveGifHeaderEPKciiii@plt>:
   12fe0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12fe4:      	ldr	x17, [x16, #0xab8]
   12fe8:      	add	x16, x16, #0xab8
   12fec:      	br	x17

0000000000012ff0 <_ZN11CMTImageGif13SaveGifHeaderEPKciiii@plt>:
   12ff0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   12ff4:      	ldr	x17, [x16, #0xac0]
   12ff8:      	add	x16, x16, #0xac0
   12ffc:      	br	x17

0000000000013000 <_ZN11CMTImageGif12SaveGifFrameEPhi@plt>:
   13000:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13004:      	ldr	x17, [x16, #0xac8]
   13008:      	add	x16, x16, #0xac8
   1300c:      	br	x17

0000000000013010 <_ZN5MTGif12SaveGifFrameEPhi@plt>:
   13010:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13014:      	ldr	x17, [x16, #0xad0]
   13018:      	add	x16, x16, #0xad0
   1301c:      	br	x17

0000000000013020 <_ZN5MTGif9SaveCloseEv@plt>:
   13020:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13024:      	ldr	x17, [x16, #0xad8]
   13028:      	add	x16, x16, #0xad8
   1302c:      	br	x17

0000000000013030 <_ZN11CMTImageGif9SaveCloseEv@plt>:
   13030:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13034:      	ldr	x17, [x16, #0xae0]
   13038:      	add	x16, x16, #0xae0
   1303c:      	br	x17

0000000000013040 <_ZN11CMTImageGif12SetThreadNumEi@plt>:
   13040:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13044:      	ldr	x17, [x16, #0xae8]
   13048:      	add	x16, x16, #0xae8
   1304c:      	br	x17

0000000000013050 <_ZN5MTGifC1Ev@plt>:
   13050:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13054:      	ldr	x17, [x16, #0xaf0]
   13058:      	add	x16, x16, #0xaf0
   1305c:      	br	x17

0000000000013060 <_ZN5MTGifD1Ev@plt>:
   13060:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13064:      	ldr	x17, [x16, #0xaf8]
   13068:      	add	x16, x16, #0xaf8
   1306c:      	br	x17

0000000000013070 <get_nearest_index@plt>:
   13070:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13074:      	ldr	x17, [x16, #0xb00]
   13078:      	add	x16, x16, #0xb00
   1307c:      	br	x17

0000000000013080 <fclose@plt>:
   13080:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13084:      	ldr	x17, [x16, #0xb08]
   13088:      	add	x16, x16, #0xb08
   1308c:      	br	x17

0000000000013090 <_ZN11CMTImageGifD1Ev@plt>:
   13090:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13094:      	ldr	x17, [x16, #0xb10]
   13098:      	add	x16, x16, #0xb10
   1309c:      	br	x17

00000000000130a0 <_ZN11CMTImageGif11compressLZWEiPhP6CxFile@plt>:
   130a0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   130a4:      	ldr	x17, [x16, #0xb18]
   130a8:      	add	x16, x16, #0xb18
   130ac:      	br	x17

00000000000130b0 <memset@plt>:
   130b0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   130b4:      	ldr	x17, [x16, #0xb20]
   130b8:      	add	x16, x16, #0xb20
   130bc:      	br	x17

00000000000130c0 <_ZN11CMTImageGif6outputEs@plt>:
   130c0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   130c4:      	ldr	x17, [x16, #0xb28]
   130c8:      	add	x16, x16, #0xb28
   130cc:      	br	x17

00000000000130d0 <_ZN11CMTImageGif12DecreaseBpp2EPv@plt>:
   130d0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   130d4:      	ldr	x17, [x16, #0xb30]
   130d8:      	add	x16, x16, #0xb30
   130dc:      	br	x17

00000000000130e0 <_Znam@plt>:
   130e0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   130e4:      	ldr	x17, [x16, #0xb38]
   130e8:      	add	x16, x16, #0xb38
   130ec:      	br	x17

00000000000130f0 <_ZdaPv@plt>:
   130f0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   130f4:      	ldr	x17, [x16, #0xb40]
   130f8:      	add	x16, x16, #0xb40
   130fc:      	br	x17

0000000000013100 <pthread_exit@plt>:
   13100:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13104:      	ldr	x17, [x16, #0xb48]
   13108:      	add	x16, x16, #0xb48
   1310c:      	br	x17

0000000000013110 <fopen@plt>:
   13110:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13114:      	ldr	x17, [x16, #0xb50]
   13118:      	add	x16, x16, #0xb50
   1311c:      	br	x17

0000000000013120 <_ZN10CQuantizerC1Ejj@plt>:
   13120:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13124:      	ldr	x17, [x16, #0xb58]
   13128:      	add	x16, x16, #0xb58
   1312c:      	br	x17

0000000000013130 <_ZN10CQuantizer13SetColorTableEPh@plt>:
   13130:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13134:      	ldr	x17, [x16, #0xb60]
   13138:      	add	x16, x16, #0xb60
   1313c:      	br	x17

0000000000013140 <_ZN10CQuantizer13ProcessImage2EPhii@plt>:
   13140:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13144:      	ldr	x17, [x16, #0xb68]
   13148:      	add	x16, x16, #0xb68
   1314c:      	br	x17

0000000000013150 <sysconf@plt>:
   13150:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13154:      	ldr	x17, [x16, #0xb70]
   13158:      	add	x16, x16, #0xb70
   1315c:      	br	x17

0000000000013160 <pthread_attr_init@plt>:
   13160:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13164:      	ldr	x17, [x16, #0xb78]
   13168:      	add	x16, x16, #0xb78
   1316c:      	br	x17

0000000000013170 <fputc@plt>:
   13170:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13174:      	ldr	x17, [x16, #0xb80]
   13178:      	add	x16, x16, #0xb80
   1317c:      	br	x17

0000000000013180 <fread@plt>:
   13180:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13184:      	ldr	x17, [x16, #0xb88]
   13188:      	add	x16, x16, #0xb88
   1318c:      	br	x17

0000000000013190 <fwrite@plt>:
   13190:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13194:      	ldr	x17, [x16, #0xb90]
   13198:      	add	x16, x16, #0xb90
   1319c:      	br	x17

00000000000131a0 <fseek@plt>:
   131a0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   131a4:      	ldr	x17, [x16, #0xb98]
   131a8:      	add	x16, x16, #0xb98
   131ac:      	br	x17

00000000000131b0 <ftell@plt>:
   131b0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   131b4:      	ldr	x17, [x16, #0xba0]
   131b8:      	add	x16, x16, #0xba0
   131bc:      	br	x17

00000000000131c0 <fflush@plt>:
   131c0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   131c4:      	ldr	x17, [x16, #0xba8]
   131c8:      	add	x16, x16, #0xba8
   131cc:      	br	x17

00000000000131d0 <feof@plt>:
   131d0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   131d4:      	ldr	x17, [x16, #0xbb0]
   131d8:      	add	x16, x16, #0xbb0
   131dc:      	br	x17

00000000000131e0 <ferror@plt>:
   131e0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   131e4:      	ldr	x17, [x16, #0xbb8]
   131e8:      	add	x16, x16, #0xbb8
   131ec:      	br	x17

00000000000131f0 <getc@plt>:
   131f0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   131f4:      	ldr	x17, [x16, #0xbc0]
   131f8:      	add	x16, x16, #0xbc0
   131fc:      	br	x17

0000000000013200 <fgets@plt>:
   13200:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13204:      	ldr	x17, [x16, #0xbc8]
   13208:      	add	x16, x16, #0xbc8
   1320c:      	br	x17

0000000000013210 <fscanf@plt>:
   13210:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13214:      	ldr	x17, [x16, #0xbd0]
   13218:      	add	x16, x16, #0xbd0
   1321c:      	br	x17

0000000000013220 <_ZN10CQuantizer10DeleteTreeEPP5_NODE@plt>:
   13220:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13224:      	ldr	x17, [x16, #0xbd8]
   13228:      	add	x16, x16, #0xbd8
   1322c:      	br	x17

0000000000013230 <_ZN10CQuantizerD1Ev@plt>:
   13230:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13234:      	ldr	x17, [x16, #0xbe0]
   13238:      	add	x16, x16, #0xbe0
   1323c:      	br	x17

0000000000013240 <calloc@plt>:
   13240:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13244:      	ldr	x17, [x16, #0xbe8]
   13248:      	add	x16, x16, #0xbe8
   1324c:      	br	x17

0000000000013250 <_ZN10CQuantizer10ReduceTreeEjPjPP5_NODE@plt>:
   13250:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13254:      	ldr	x17, [x16, #0xbf0]
   13258:      	add	x16, x16, #0xbf0
   1325c:      	br	x17

0000000000013260 <_ZN10CQuantizer16GetPaletteColorsEP5_NODEPhPj@plt>:
   13260:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13264:      	ldr	x17, [x16, #0xbf8]
   13268:      	add	x16, x16, #0xbf8
   1326c:      	br	x17

0000000000013270 <strcpy@plt>:
   13270:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13274:      	ldr	x17, [x16, #0xc00]
   13278:      	add	x16, x16, #0xc00
   1327c:      	br	x17

0000000000013280 <_ZN7CGif89a4openEPcb@plt>:
   13280:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13284:      	ldr	x17, [x16, #0xc08]
   13288:      	add	x16, x16, #0xc08
   1328c:      	br	x17

0000000000013290 <_ZN7CGif89a11checkFramesEv@plt>:
   13290:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13294:      	ldr	x17, [x16, #0xc10]
   13298:      	add	x16, x16, #0xc10
   1329c:      	br	x17

00000000000132a0 <_ZN7CGif89a12getAllFramesEv@plt>:
   132a0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   132a4:      	ldr	x17, [x16, #0xc18]
   132a8:      	add	x16, x16, #0xc18
   132ac:      	br	x17

00000000000132b0 <_ZN7CGif89a5closeEv@plt>:
   132b0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   132b4:      	ldr	x17, [x16, #0xc20]
   132b8:      	add	x16, x16, #0xc20
   132bc:      	br	x17

00000000000132c0 <_ZN7CGif89a11extractDataEP5FRAME@plt>:
   132c0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   132c4:      	ldr	x17, [x16, #0xc28]
   132c8:      	add	x16, x16, #0xc28
   132cc:      	br	x17

00000000000132d0 <_ZN7CGif89a12getNextFrameEv@plt>:
   132d0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   132d4:      	ldr	x17, [x16, #0xc30]
   132d8:      	add	x16, x16, #0xc30
   132dc:      	br	x17

00000000000132e0 <_ZN5mtgif9Video2GifC1Ev@plt>:
   132e0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   132e4:      	ldr	x17, [x16, #0xc38]
   132e8:      	add	x16, x16, #0xc38
   132ec:      	br	x17

00000000000132f0 <memmove@plt>:
   132f0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   132f4:      	ldr	x17, [x16, #0xc40]
   132f8:      	add	x16, x16, #0xc40
   132fc:      	br	x17

0000000000013300 <_ZN5mtgif9Video2Gif4initENSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES7_iiif@plt>:
   13300:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13304:      	ldr	x17, [x16, #0xc48]
   13308:      	add	x16, x16, #0xc48
   1330c:      	br	x17

0000000000013310 <_ZN5mtgif9Video2Gif3runEv@plt>:
   13310:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13314:      	ldr	x17, [x16, #0xc50]
   13318:      	add	x16, x16, #0xc50
   1331c:      	br	x17

0000000000013320 <__android_log_print@plt>:
   13320:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13324:      	ldr	x17, [x16, #0xc58]
   13328:      	add	x16, x16, #0xc58
   1332c:      	br	x17

0000000000013330 <_ZN5mtgif9Video2GifD1Ev@plt>:
   13330:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13334:      	ldr	x17, [x16, #0xc60]
   13338:      	add	x16, x16, #0xc60
   1333c:      	br	x17

0000000000013340 <__cxa_allocate_exception@plt>:
   13340:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13344:      	ldr	x17, [x16, #0xc68]
   13348:      	add	x16, x16, #0xc68
   1334c:      	br	x17

0000000000013350 <__cxa_throw@plt>:
   13350:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13354:      	ldr	x17, [x16, #0xc70]
   13358:      	add	x16, x16, #0xc70
   1335c:      	br	x17

0000000000013360 <__cxa_free_exception@plt>:
   13360:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13364:      	ldr	x17, [x16, #0xc78]
   13368:      	add	x16, x16, #0xc78
   1336c:      	br	x17

0000000000013370 <_ZNSt11logic_errorC2EPKc@plt>:
   13370:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13374:      	ldr	x17, [x16, #0xc80]
   13378:      	add	x16, x16, #0xc80
   1337c:      	br	x17

0000000000013380 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6assignEPKc@plt>:
   13380:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13384:      	ldr	x17, [x16, #0xc88]
   13388:      	add	x16, x16, #0xc88
   1338c:      	br	x17

0000000000013390 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_@plt>:
   13390:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13394:      	ldr	x17, [x16, #0xc90]
   13398:      	add	x16, x16, #0xc90
   1339c:      	br	x17

00000000000133a0 <dl_iterate_phdr@plt>:
   133a0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   133a4:      	ldr	x17, [x16, #0xc98]
   133a8:      	add	x16, x16, #0xc98
   133ac:      	br	x17

00000000000133b0 <fprintf@plt>:
   133b0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   133b4:      	ldr	x17, [x16, #0xca0]
   133b8:      	add	x16, x16, #0xca0
   133bc:      	br	x17

00000000000133c0 <abort@plt>:
   133c0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   133c4:      	ldr	x17, [x16, #0xca8]
   133c8:      	add	x16, x16, #0xca8
   133cc:      	br	x17

00000000000133d0 <pthread_rwlock_wrlock@plt>:
   133d0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   133d4:      	ldr	x17, [x16, #0xcb0]
   133d8:      	add	x16, x16, #0xcb0
   133dc:      	br	x17

00000000000133e0 <pthread_rwlock_unlock@plt>:
   133e0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   133e4:      	ldr	x17, [x16, #0xcb8]
   133e8:      	add	x16, x16, #0xcb8
   133ec:      	br	x17

00000000000133f0 <pthread_rwlock_rdlock@plt>:
   133f0:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   133f4:      	ldr	x17, [x16, #0xcc0]
   133f8:      	add	x16, x16, #0xcc0
   133fc:      	br	x17

0000000000013400 <getpid@plt>:
   13400:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13404:      	ldr	x17, [x16, #0xcc8]
   13408:      	add	x16, x16, #0xcc8
   1340c:      	br	x17

0000000000013410 <syscall@plt>:
   13410:      	adrp	x16, 0x17000 <syscall@plt+0x3bf0>
   13414:      	ldr	x17, [x16, #0xcd0]
   13418:      	add	x16, x16, #0xcd0
   1341c:      	br	x17
