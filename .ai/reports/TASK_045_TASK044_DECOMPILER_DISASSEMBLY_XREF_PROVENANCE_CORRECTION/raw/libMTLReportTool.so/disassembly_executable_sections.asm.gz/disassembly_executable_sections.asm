
F:\CONVERT\com.mt.mtxx.mtxx\SOURCE\extracted_native_libs\lib\arm64-v8a\libMTLReportTool.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000007d90 <.text>:
    7d90:      	bti	c
    7d94:      	nop
    7d98:      	adr	x0, 0x14de0
    7d9c:      	b	0x10730 <__cxa_finalize@plt>
    7da0:      	bti	c
    7da4:      	ret
    7da8:      	bti	c
    7dac:      	b	0x7da0 <.text+0x10>
    7db0:      	bti	c
    7db4:      	cbz	x0, 0x7dc0 <.text+0x30>
    7db8:      	mov	x16, x0
    7dbc:      	br	x16
    7dc0:      	ret
    7dc4:      	bti	c
    7dc8:      	mov	x1, x0
    7dcc:      	nop
    7dd0:      	adr	x0, 0x7db0 <.text+0x20>
    7dd4:      	nop
    7dd8:      	adr	x2, 0x14de0
    7ddc:      	b	0x10740 <__cxa_atexit@plt>
    7de0:      	bti	c
    7de4:      	nop
    7de8:      	adr	x3, 0x14de0
    7dec:      	b	0x10750 <__register_atfork@plt>
    7df0:      	stp	x29, x30, [sp, #-0x30]!
    7df4:      	stp	x22, x21, [sp, #0x10]
    7df8:      	stp	x20, x19, [sp, #0x20]
    7dfc:      	mov	x29, sp
    7e00:      	mov	x19, x0
    7e04:      	mov	x0, x1
    7e08:      	mov	x21, x1
    7e0c:      	bl	0x10760 <strlen@plt>
    7e10:      	cmn	x0, #0x10
    7e14:      	b.hs	0x7e74 <.text+0xe4>
    7e18:      	mov	x20, x0
    7e1c:      	cmp	x0, #0x17
    7e20:      	b.hs	0x7e34 <.text+0xa4>
    7e24:      	lsl	w8, w20, #1
    7e28:      	strb	w8, [x19], #0x1
    7e2c:      	cbnz	x20, 0x7e50 <.text+0xc0>
    7e30:      	b	0x7e60 <.text+0xd0>
    7e34:      	orr	x22, x20, #0xf
    7e38:      	add	x0, x22, #0x1
    7e3c:      	bl	0x10770 <_Znwm@plt>
    7e40:      	add	x8, x22, #0x2
    7e44:      	stp	x20, x0, [x19, #0x8]
    7e48:      	str	x8, [x19]
    7e4c:      	mov	x19, x0
    7e50:      	mov	x0, x19
    7e54:      	mov	x1, x21
    7e58:      	mov	x2, x20
    7e5c:      	bl	0x10780 <memmove@plt>
    7e60:      	strb	wzr, [x19, x20]
    7e64:      	ldp	x20, x19, [sp, #0x20]
    7e68:      	ldp	x22, x21, [sp, #0x10]
    7e6c:      	ldp	x29, x30, [sp], #0x30
    7e70:      	ret
    7e74:      	mov	x0, x19
    7e78:      	bl	0x7eac <.text+0x11c>
    7e7c:      	ldr	x9, [x0, #0x20]
    7e80:      	cmp	x9, x0
    7e84:      	b.eq	0x7e98 <.text+0x108>
    7e88:      	cbz	x9, 0x7ea8 <.text+0x118>
    7e8c:      	mov	w8, #0x5                // =5
    7e90:      	mov	x0, x9
    7e94:      	b	0x7e9c <.text+0x10c>
    7e98:      	mov	w8, #0x4                // =4
    7e9c:      	ldr	x9, [x0]
    7ea0:      	ldr	x1, [x9, x8, lsl #3]
    7ea4:      	br	x1
    7ea8:      	ret
    7eac:      	stp	x29, x30, [sp, #-0x10]!
    7eb0:      	mov	x29, sp
    7eb4:      	adrp	x0, 0x5000
    7eb8:      	add	x0, x0, #0x608
    7ebc:      	bl	0x7ec0 <.text+0x130>
    7ec0:      	stp	x29, x30, [sp, #-0x20]!
    7ec4:      	stp	x20, x19, [sp, #0x10]
    7ec8:      	mov	x29, sp
    7ecc:      	mov	x20, x0
    7ed0:      	mov	w0, #0x10               // =16
    7ed4:      	bl	0x107b0 <__cxa_allocate_exception@plt>
    7ed8:      	mov	x19, x0
    7edc:      	mov	x1, x20
    7ee0:      	bl	0x7f10 <.text+0x180>
    7ee4:      	adrp	x1, 0x15000
    7ee8:      	adrp	x2, 0x15000
    7eec:      	mov	x0, x19
    7ef0:      	ldr	x1, [x1, #0x180]
    7ef4:      	ldr	x2, [x2, #0x188]
    7ef8:      	bl	0x107c0 <__cxa_throw@plt>
    7efc:      	mov	x20, x0
    7f00:      	mov	x0, x19
    7f04:      	bl	0x107d0 <__cxa_free_exception@plt>
    7f08:      	mov	x0, x20
    7f0c:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    7f10:      	stp	x29, x30, [sp, #-0x20]!
    7f14:      	str	x19, [sp, #0x10]
    7f18:      	mov	x29, sp
    7f1c:      	mov	x19, x0
    7f20:      	bl	0x107e0 <_ZNSt11logic_errorC2EPKc@plt>
    7f24:      	adrp	x8, 0x15000
    7f28:      	ldr	x8, [x8, #0x190]
    7f2c:      	add	x8, x8, #0x10
    7f30:      	str	x8, [x19]
    7f34:      	ldr	x19, [sp, #0x10]
    7f38:      	ldp	x29, x30, [sp], #0x20
    7f3c:      	ret
    7f40:      	stp	x29, x30, [sp, #-0x30]!
    7f44:      	stp	x22, x21, [sp, #0x10]
    7f48:      	stp	x20, x19, [sp, #0x20]
    7f4c:      	mov	x29, sp
    7f50:      	mov	x20, x2
    7f54:      	mov	x19, x1
    7f58:      	cmp	x2, #0x16
    7f5c:      	mov	x21, x0
    7f60:      	b.hi	0x7f70 <.text+0x1e0>
    7f64:      	lsl	w8, w20, #1
    7f68:      	strb	w8, [x21], #0x1
    7f6c:      	b	0x7f94 <.text+0x204>
    7f70:      	cmn	x20, #0x10
    7f74:      	b.hs	0x7fb0 <.text+0x220>
    7f78:      	orr	x22, x20, #0xf
    7f7c:      	add	x0, x22, #0x1
    7f80:      	bl	0x10770 <_Znwm@plt>
    7f84:      	add	x8, x22, #0x2
    7f88:      	stp	x20, x0, [x21, #0x8]
    7f8c:      	str	x8, [x21]
    7f90:      	mov	x21, x0
    7f94:      	add	x2, x20, #0x1
    7f98:      	mov	x0, x21
    7f9c:      	mov	x1, x19
    7fa0:      	ldp	x20, x19, [sp, #0x20]
    7fa4:      	ldp	x22, x21, [sp, #0x10]
    7fa8:      	ldp	x29, x30, [sp], #0x30
    7fac:      	b	0x10780 <memmove@plt>
    7fb0:      	mov	x0, x21
    7fb4:      	bl	0x7eac <.text+0x11c>
    7fb8:      	stp	x29, x30, [sp, #-0x20]!
    7fbc:      	stp	x20, x19, [sp, #0x10]
    7fc0:      	mov	x29, sp
    7fc4:      	nop
    7fc8:      	adr	x19, 0x19680
    7fcc:      	nop
    7fd0:      	adr	x1, 0x4f86
    7fd4:      	mov	x0, x19
    7fd8:      	bl	0x7df0 <.text+0x60>
    7fdc:      	adrp	x0, 0x15000
    7fe0:      	nop
    7fe4:      	adr	x20, 0x14de0
    7fe8:      	ldr	x0, [x0, #0x198]
    7fec:      	mov	x1, x19
    7ff0:      	mov	x2, x20
    7ff4:      	bl	0x10740 <__cxa_atexit@plt>
    7ff8:      	nop
    7ffc:      	adr	x1, 0x196a0
    8000:      	nop
    8004:      	adr	x0, 0x7e7c <.text+0xec>
    8008:      	mov	x2, x20
    800c:      	str	xzr, [x1, #0x20]
    8010:      	ldp	x20, x19, [sp, #0x10]
    8014:      	ldp	x29, x30, [sp], #0x20
    8018:      	b	0x10740 <__cxa_atexit@plt>

000000000000801c <_ZN13MTLReportTool9Interface4ImplC2Ev>:
    801c:      	ret

0000000000008020 <_ZN13MTLReportTool9Interface4ImplD2Ev>:
    8020:      	ret

0000000000008024 <_ZN13MTLReportTool9InterfaceC2Ev>:
    8024:      	stp	x29, x30, [sp, #-0x20]!
    8028:      	stp	x20, x19, [sp, #0x10]
    802c:      	mov	x29, sp
    8030:      	mov	x19, x0
    8034:      	str	xzr, [x0]
    8038:      	mov	w0, #0x1                // =1
    803c:      	bl	0x10770 <_Znwm@plt>
    8040:      	mov	x20, x0
    8044:      	bl	0x107f0 <_ZN13MTLReportTool9Interface4ImplC1Ev@plt>
    8048:      	str	x20, [x19]
    804c:      	ldp	x20, x19, [sp, #0x10]
    8050:      	ldp	x29, x30, [sp], #0x20
    8054:      	ret
    8058:      	mov	x19, x0
    805c:      	mov	x0, x20
    8060:      	bl	0x10790 <_ZdlPv@plt>
    8064:      	mov	x0, x19
    8068:      	bl	0xca4c <JNI_OnUnload+0x1cc>

000000000000806c <_ZN13MTLReportTool9InterfaceD2Ev>:
    806c:      	stp	x29, x30, [sp, #-0x20]!
    8070:      	stp	x20, x19, [sp, #0x10]
    8074:      	mov	x29, sp
    8078:      	ldr	x20, [x0]
    807c:      	cbz	x20, 0x8098 <_ZN13MTLReportTool9InterfaceD2Ev+0x2c>
    8080:      	mov	x19, x0
    8084:      	mov	x0, x20
    8088:      	bl	0x10800 <_ZN13MTLReportTool9Interface4ImplD1Ev@plt>
    808c:      	mov	x0, x20
    8090:      	bl	0x10790 <_ZdlPv@plt>
    8094:      	str	xzr, [x19]
    8098:      	ldp	x20, x19, [sp, #0x10]
    809c:      	ldp	x29, x30, [sp], #0x20
    80a0:      	ret

00000000000080a4 <_ZN13MTLReportTool9Interface7versionEv>:
    80a4:      	nop
    80a8:      	adr	x0, 0x5716
    80ac:      	ret
    80b0:      	stp	x29, x30, [sp, #-0x10]!
    80b4:      	mov	x29, sp
    80b8:      	bl	0x10860 <__cxa_begin_catch@plt>
    80bc:      	bl	0x10870 <_ZSt9terminatev@plt>
    80c0:      	stp	x29, x30, [sp, #-0x50]!
    80c4:      	stp	x26, x25, [sp, #0x10]
    80c8:      	stp	x24, x23, [sp, #0x20]
    80cc:      	stp	x22, x21, [sp, #0x30]
    80d0:      	stp	x20, x19, [sp, #0x40]
    80d4:      	mov	x29, sp
    80d8:      	adrp	x23, 0x15000
    80dc:      	adrp	x22, 0x15000
    80e0:      	mov	x20, x0
    80e4:      	ldr	x23, [x23, #0x1b0]
    80e8:      	ldr	x22, [x22, #0x1a0]
    80ec:      	mov	x26, x0
    80f0:      	mov	x19, x0
    80f4:      	ldr	x8, [x22, #0x10]
    80f8:      	add	x24, x23, #0x68
    80fc:      	add	x25, x23, #0x40
    8100:      	str	x24, [x20, #0x80]!
    8104:      	ldr	x9, [x22, #0x18]
    8108:      	str	x25, [x26, #0x10]!
    810c:      	str	x8, [x0]
    8110:      	ldur	x8, [x8, #-0x18]
    8114:      	str	xzr, [x0, #0x8]
    8118:      	str	x9, [x0, x8]
    811c:      	ldr	x8, [x0]
    8120:      	ldur	x8, [x8, #-0x18]
    8124:      	add	x21, x0, x8
    8128:      	add	x1, x0, #0x18
    812c:      	mov	x0, x21
    8130:      	bl	0x10900 <_ZNSt6__ndk18ios_base4initEPv@plt>
    8134:      	ldr	x9, [x22, #0x20]
    8138:      	mov	w8, #-0x1               // =-1
    813c:      	str	xzr, [x21, #0x88]
    8140:      	str	w8, [x21, #0x90]
    8144:      	ldr	x10, [x22, #0x8]
    8148:      	ldr	x8, [x22, #0x28]
    814c:      	str	x9, [x19, #0x10]
    8150:      	ldur	x9, [x9, #-0x18]
    8154:      	str	x8, [x26, x9]
    8158:      	ldr	x9, [x22, #0x30]
    815c:      	str	x10, [x19]
    8160:      	ldur	x8, [x10, #-0x18]
    8164:      	add	x10, x23, #0x18
    8168:      	str	x9, [x19, x8]
    816c:      	str	x10, [x19]
    8170:      	str	x24, [x19, #0x80]
    8174:      	str	x25, [x19, #0x10]
    8178:      	add	x0, x19, #0x18
    817c:      	bl	0x10910 <_ZNSt6__ndk115basic_streambufIcNS_11char_traitsIcEEEC2Ev@plt>
    8180:      	adrp	x8, 0x15000
    8184:      	movi	v0.2d, #0000000000000000
    8188:      	ldr	x8, [x8, #0x1a8]
    818c:      	add	x8, x8, #0x10
    8190:      	str	x8, [x19, #0x18]
    8194:      	mov	w8, #0x18               // =24
    8198:      	stur	q0, [x19, #0x58]
    819c:      	stur	q0, [x19, #0x68]
    81a0:      	str	w8, [x19, #0x78]
    81a4:      	ldp	x20, x19, [sp, #0x40]
    81a8:      	ldp	x22, x21, [sp, #0x30]
    81ac:      	ldp	x24, x23, [sp, #0x20]
    81b0:      	ldp	x26, x25, [sp, #0x10]
    81b4:      	ldp	x29, x30, [sp], #0x50
    81b8:      	ret
    81bc:      	mov	x21, x0
    81c0:      	add	x1, x22, #0x8
    81c4:      	mov	x0, x19
    81c8:      	bl	0x108d0 <_ZNSt6__ndk114basic_iostreamIcNS_11char_traitsIcEEED2Ev@plt>
    81cc:      	b	0x81d4 <_ZN13MTLReportTool9Interface7versionEv+0x130>
    81d0:      	mov	x21, x0
    81d4:      	mov	x0, x20
    81d8:      	bl	0x108e0 <_ZNSt6__ndk19basic_iosIcNS_11char_traitsIcEEED2Ev@plt>
    81dc:      	mov	x0, x21
    81e0:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    81e4:      	stp	x29, x30, [sp, #-0x30]!
    81e8:      	str	x21, [sp, #0x10]
    81ec:      	stp	x20, x19, [sp, #0x20]
    81f0:      	mov	x29, sp
    81f4:      	adrp	x21, 0x15000
    81f8:      	adrp	x9, 0x15000
    81fc:      	mov	x20, x0
    8200:      	ldr	x21, [x21, #0x1a0]
    8204:      	mov	x19, x0
    8208:      	ldr	x8, [x21]
    820c:      	ldp	x10, x11, [x21, #0x40]
    8210:      	str	x8, [x0]
    8214:      	ldur	x8, [x8, #-0x18]
    8218:      	ldr	x9, [x9, #0x1a8]
    821c:      	str	x10, [x0, x8]
    8220:      	add	x8, x9, #0x10
    8224:      	str	x8, [x20, #0x18]!
    8228:      	ldrb	w8, [x20, #0x40]
    822c:      	stur	x11, [x20, #-0x8]
    8230:      	tbz	w8, #0x0, 0x823c <_ZN13MTLReportTool9Interface7versionEv+0x198>
    8234:      	ldr	x0, [x19, #0x68]
    8238:      	bl	0x10790 <_ZdlPv@plt>
    823c:      	mov	x0, x20
    8240:      	bl	0x108c0 <_ZNSt6__ndk115basic_streambufIcNS_11char_traitsIcEEED2Ev@plt>
    8244:      	add	x1, x21, #0x8
    8248:      	mov	x0, x19
    824c:      	bl	0x108d0 <_ZNSt6__ndk114basic_iostreamIcNS_11char_traitsIcEEED2Ev@plt>
    8250:      	add	x0, x19, #0x80
    8254:      	ldp	x20, x19, [sp, #0x20]
    8258:      	ldr	x21, [sp, #0x10]
    825c:      	ldp	x29, x30, [sp], #0x30
    8260:      	b	0x108e0 <_ZNSt6__ndk19basic_iosIcNS_11char_traitsIcEEED2Ev@plt>
    8264:      	sub	sp, sp, #0x70
    8268:      	stp	x29, x30, [sp, #0x20]
    826c:      	stp	x26, x25, [sp, #0x30]
    8270:      	stp	x24, x23, [sp, #0x40]
    8274:      	stp	x22, x21, [sp, #0x50]
    8278:      	stp	x20, x19, [sp, #0x60]
    827c:      	add	x29, sp, #0x20
    8280:      	mrs	x25, TPIDR_EL0
    8284:      	mov	x21, x2
    8288:      	mov	x20, x1
    828c:      	ldr	x8, [x25, #0x28]
    8290:      	mov	x19, x0
    8294:      	stur	x8, [x29, #-0x8]
    8298:      	mov	x0, sp
    829c:      	mov	x1, x19
    82a0:      	bl	0x10950 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEE6sentryC1ERS3_@plt>
    82a4:      	ldrb	w8, [sp]
    82a8:      	cbz	w8, 0x8350 <_ZN13MTLReportTool9Interface7versionEv+0x2ac>
    82ac:      	ldr	x8, [x19]
    82b0:      	ldur	x8, [x8, #-0x18]
    82b4:      	add	x22, x19, x8
    82b8:      	ldr	w5, [x22, #0x90]
    82bc:      	ldr	x23, [x22, #0x28]
    82c0:      	ldr	w26, [x22, #0x8]
    82c4:      	cmn	w5, #0x1
    82c8:      	b.ne	0x830c <_ZN13MTLReportTool9Interface7versionEv+0x268>
    82cc:      	add	x8, sp, #0x10
    82d0:      	mov	x0, x22
    82d4:      	bl	0x10920 <_ZNKSt6__ndk18ios_base6getlocEv@plt>
    82d8:      	adrp	x1, 0x15000
    82dc:      	add	x0, sp, #0x10
    82e0:      	ldr	x1, [x1, #0x1b8]
    82e4:      	bl	0x10930 <_ZNKSt6__ndk16locale9use_facetERNS0_2idE@plt>
    82e8:      	ldr	x8, [x0]
    82ec:      	ldr	x8, [x8, #0x38]
    82f0:      	mov	w1, #0x20               // =32
    82f4:      	blr	x8
    82f8:      	mov	w24, w0
    82fc:      	add	x0, sp, #0x10
    8300:      	bl	0x10940 <_ZNSt6__ndk16localeD1Ev@plt>
    8304:      	and	w5, w24, #0xff
    8308:      	str	w5, [x22, #0x90]
    830c:      	mov	w8, #0xb0               // =176
    8310:      	add	x3, x20, x21
    8314:      	and	w8, w26, w8
    8318:      	cmp	w8, #0x20
    831c:      	csel	x2, x3, x20, eq
    8320:      	mov	x0, x23
    8324:      	mov	x1, x20
    8328:      	mov	x4, x22
    832c:      	bl	0x83f8 <_ZN13MTLReportTool9Interface7versionEv+0x354>
    8330:      	cbnz	x0, 0x8350 <_ZN13MTLReportTool9Interface7versionEv+0x2ac>
    8334:      	ldr	x8, [x19]
    8338:      	mov	w9, #0x5                // =5
    833c:      	ldur	x8, [x8, #-0x18]
    8340:      	add	x0, x19, x8
    8344:      	ldr	w8, [x0, #0x20]
    8348:      	orr	w1, w8, w9
    834c:      	bl	0x10960 <_ZNSt6__ndk18ios_base5clearEj@plt>
    8350:      	mov	x0, sp
    8354:      	bl	0x10970 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEE6sentryD1Ev@plt>
    8358:      	ldr	x8, [x25, #0x28]
    835c:      	ldur	x9, [x29, #-0x8]
    8360:      	cmp	x8, x9
    8364:      	b.ne	0x83f0 <_ZN13MTLReportTool9Interface7versionEv+0x34c>
    8368:      	mov	x0, x19
    836c:      	ldp	x20, x19, [sp, #0x60]
    8370:      	ldp	x22, x21, [sp, #0x50]
    8374:      	ldp	x24, x23, [sp, #0x40]
    8378:      	ldp	x26, x25, [sp, #0x30]
    837c:      	ldp	x29, x30, [sp, #0x20]
    8380:      	add	sp, sp, #0x70
    8384:      	ret
    8388:      	b	0x839c <_ZN13MTLReportTool9Interface7versionEv+0x2f8>
    838c:      	mov	x20, x0
    8390:      	add	x0, sp, #0x10
    8394:      	bl	0x10940 <_ZNSt6__ndk16localeD1Ev@plt>
    8398:      	b	0x83a0 <_ZN13MTLReportTool9Interface7versionEv+0x2fc>
    839c:      	mov	x20, x0
    83a0:      	mov	x0, sp
    83a4:      	bl	0x10970 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEE6sentryD1Ev@plt>
    83a8:      	b	0x83b0 <_ZN13MTLReportTool9Interface7versionEv+0x30c>
    83ac:      	mov	x20, x0
    83b0:      	mov	x0, x20
    83b4:      	bl	0x10860 <__cxa_begin_catch@plt>
    83b8:      	ldr	x8, [x19]
    83bc:      	ldur	x8, [x8, #-0x18]
    83c0:      	add	x0, x19, x8
    83c4:      	bl	0x10980 <_ZNSt6__ndk18ios_base33__set_badbit_and_consider_rethrowEv@plt>
    83c8:      	bl	0x10990 <__cxa_end_catch@plt>
    83cc:      	b	0x8358 <_ZN13MTLReportTool9Interface7versionEv+0x2b4>
    83d0:      	mov	x19, x0
    83d4:      	bl	0x10990 <__cxa_end_catch@plt>
    83d8:      	ldr	x8, [x25, #0x28]
    83dc:      	ldur	x9, [x29, #-0x8]
    83e0:      	cmp	x8, x9
    83e4:      	b.ne	0x83f0 <_ZN13MTLReportTool9Interface7versionEv+0x34c>
    83e8:      	mov	x0, x19
    83ec:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    83f0:      	bl	0x10840 <__stack_chk_fail@plt>
    83f4:      	bl	0x80b0 <_ZN13MTLReportTool9Interface7versionEv+0xc>
    83f8:      	sub	sp, sp, #0x70
    83fc:      	stp	x29, x30, [sp, #0x20]
    8400:      	stp	x26, x25, [sp, #0x30]
    8404:      	stp	x24, x23, [sp, #0x40]
    8408:      	stp	x22, x21, [sp, #0x50]
    840c:      	stp	x20, x19, [sp, #0x60]
    8410:      	add	x29, sp, #0x20
    8414:      	mrs	x26, TPIDR_EL0
    8418:      	mov	x19, x0
    841c:      	ldr	x8, [x26, #0x28]
    8420:      	stur	x8, [x29, #-0x8]
    8424:      	cbz	x0, 0x8508 <_ZN13MTLReportTool9Interface7versionEv+0x464>
    8428:      	ldr	x8, [x4, #0x18]
    842c:      	sub	x9, x3, x1
    8430:      	sub	x25, x2, x1
    8434:      	mov	w24, w5
    8438:      	mov	x20, x4
    843c:      	mov	x22, x3
    8440:      	subs	x8, x8, x9
    8444:      	mov	x21, x2
    8448:      	csel	x23, x8, xzr, gt
    844c:      	cmp	x25, #0x1
    8450:      	b.lt	0x8470 <_ZN13MTLReportTool9Interface7versionEv+0x3cc>
    8454:      	ldr	x8, [x19]
    8458:      	mov	x0, x19
    845c:      	mov	x2, x25
    8460:      	ldr	x8, [x8, #0x60]
    8464:      	blr	x8
    8468:      	cmp	x0, x25
    846c:      	b.ne	0x8504 <_ZN13MTLReportTool9Interface7versionEv+0x460>
    8470:      	cmp	x23, #0x1
    8474:      	b.lt	0x84d0 <_ZN13MTLReportTool9Interface7versionEv+0x42c>
    8478:      	mov	x0, sp
    847c:      	mov	x1, x23
    8480:      	mov	w2, w24
    8484:      	mov	x24, sp
    8488:      	bl	0x8568 <_ZN13MTLReportTool9Interface7versionEv+0x4c4>
    848c:      	ldrb	w8, [sp]
    8490:      	ldr	x9, [x19]
    8494:      	orr	x11, x24, #0x1
    8498:      	ldr	x10, [sp, #0x10]
    849c:      	tst	w8, #0x1
    84a0:      	ldr	x8, [x9, #0x60]
    84a4:      	csel	x1, x11, x10, eq
    84a8:      	mov	x0, x19
    84ac:      	mov	x2, x23
    84b0:      	blr	x8
    84b4:      	ldrb	w8, [sp]
    84b8:      	mov	x24, x0
    84bc:      	tbz	w8, #0x0, 0x84c8 <_ZN13MTLReportTool9Interface7versionEv+0x424>
    84c0:      	ldr	x0, [sp, #0x10]
    84c4:      	bl	0x10790 <_ZdlPv@plt>
    84c8:      	cmp	x24, x23
    84cc:      	b.ne	0x8504 <_ZN13MTLReportTool9Interface7versionEv+0x460>
    84d0:      	sub	x22, x22, x21
    84d4:      	cmp	x22, #0x1
    84d8:      	b.lt	0x84fc <_ZN13MTLReportTool9Interface7versionEv+0x458>
    84dc:      	ldr	x8, [x19]
    84e0:      	mov	x0, x19
    84e4:      	mov	x1, x21
    84e8:      	mov	x2, x22
    84ec:      	ldr	x8, [x8, #0x60]
    84f0:      	blr	x8
    84f4:      	cmp	x0, x22
    84f8:      	b.ne	0x8504 <_ZN13MTLReportTool9Interface7versionEv+0x460>
    84fc:      	str	xzr, [x20, #0x18]
    8500:      	b	0x8508 <_ZN13MTLReportTool9Interface7versionEv+0x464>
    8504:      	mov	x19, xzr
    8508:      	ldr	x8, [x26, #0x28]
    850c:      	ldur	x9, [x29, #-0x8]
    8510:      	cmp	x8, x9
    8514:      	b.ne	0x8564 <_ZN13MTLReportTool9Interface7versionEv+0x4c0>
    8518:      	mov	x0, x19
    851c:      	ldp	x20, x19, [sp, #0x60]
    8520:      	ldp	x22, x21, [sp, #0x50]
    8524:      	ldp	x24, x23, [sp, #0x40]
    8528:      	ldp	x26, x25, [sp, #0x30]
    852c:      	ldp	x29, x30, [sp, #0x20]
    8530:      	add	sp, sp, #0x70
    8534:      	ret
    8538:      	ldrb	w8, [sp]
    853c:      	mov	x19, x0
    8540:      	tbz	w8, #0x0, 0x854c <_ZN13MTLReportTool9Interface7versionEv+0x4a8>
    8544:      	ldr	x0, [sp, #0x10]
    8548:      	bl	0x10790 <_ZdlPv@plt>
    854c:      	ldr	x8, [x26, #0x28]
    8550:      	ldur	x9, [x29, #-0x8]
    8554:      	cmp	x8, x9
    8558:      	b.ne	0x8564 <_ZN13MTLReportTool9Interface7versionEv+0x4c0>
    855c:      	mov	x0, x19
    8560:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    8564:      	bl	0x10840 <__stack_chk_fail@plt>
    8568:      	stp	x29, x30, [sp, #-0x30]!
    856c:      	stp	x22, x21, [sp, #0x10]
    8570:      	stp	x20, x19, [sp, #0x20]
    8574:      	mov	x29, sp
    8578:      	cmn	x1, #0x10
    857c:      	mov	x20, x0
    8580:      	b.hs	0x85e4 <_ZN13MTLReportTool9Interface7versionEv+0x540>
    8584:      	mov	w21, w2
    8588:      	mov	x19, x1
    858c:      	cmp	x1, #0x17
    8590:      	b.hs	0x85a4 <_ZN13MTLReportTool9Interface7versionEv+0x500>
    8594:      	lsl	w8, w19, #1
    8598:      	strb	w8, [x20], #0x1
    859c:      	cbnz	x19, 0x85c0 <_ZN13MTLReportTool9Interface7versionEv+0x51c>
    85a0:      	b	0x85d0 <_ZN13MTLReportTool9Interface7versionEv+0x52c>
    85a4:      	orr	x22, x19, #0xf
    85a8:      	add	x0, x22, #0x1
    85ac:      	bl	0x10770 <_Znwm@plt>
    85b0:      	add	x8, x22, #0x2
    85b4:      	stp	x19, x0, [x20, #0x8]
    85b8:      	str	x8, [x20]
    85bc:      	mov	x20, x0
    85c0:      	mov	x0, x20
    85c4:      	mov	w1, w21
    85c8:      	mov	x2, x19
    85cc:      	bl	0x109a0 <memset@plt>
    85d0:      	strb	wzr, [x20, x19]
    85d4:      	ldp	x20, x19, [sp, #0x20]
    85d8:      	ldp	x22, x21, [sp, #0x10]
    85dc:      	ldp	x29, x30, [sp], #0x30
    85e0:      	ret
    85e4:      	mov	x0, x20
    85e8:      	bl	0x7eac <.text+0x11c>
    85ec:      	stp	x29, x30, [sp, #-0x20]!
    85f0:      	str	x19, [sp, #0x10]
    85f4:      	mov	x29, sp
    85f8:      	ldrb	w8, [x1]
    85fc:      	mov	x19, x0
    8600:      	tbnz	w8, #0x0, 0x8618 <_ZN13MTLReportTool9Interface7versionEv+0x574>
    8604:      	ldr	x8, [x1, #0x10]
    8608:      	ldr	q0, [x1]
    860c:      	str	x8, [x19, #0x10]
    8610:      	str	q0, [x19]
    8614:      	b	0x8628 <_ZN13MTLReportTool9Interface7versionEv+0x584>
    8618:      	ldp	x2, x8, [x1, #0x8]
    861c:      	mov	x0, x19
    8620:      	mov	x1, x8
    8624:      	bl	0x7f40 <.text+0x1b0>
    8628:      	str	xzr, [x19, #0x18]
    862c:      	strb	wzr, [x19, #0x20]
    8630:      	ldr	x19, [sp, #0x10]
    8634:      	ldp	x29, x30, [sp], #0x20
    8638:      	ret
    863c:      	stp	x29, x30, [sp, #-0x20]!
    8640:      	str	x19, [sp, #0x10]
    8644:      	mov	x29, sp
    8648:      	mov	x19, x0
    864c:      	ldr	x0, [x0, #0x18]
    8650:      	cbz	x0, 0x865c <_ZN13MTLReportTool9Interface7versionEv+0x5b8>
    8654:      	bl	0x109b0 <fclose@plt>
    8658:      	str	xzr, [x19, #0x18]
    865c:      	ldrb	w8, [x19]
    8660:      	tbnz	w8, #0x0, 0x8670 <_ZN13MTLReportTool9Interface7versionEv+0x5cc>
    8664:      	ldr	x19, [sp, #0x10]
    8668:      	ldp	x29, x30, [sp], #0x20
    866c:      	ret
    8670:      	ldr	x0, [x19, #0x10]
    8674:      	ldr	x19, [sp, #0x10]
    8678:      	ldp	x29, x30, [sp], #0x20
    867c:      	b	0x10790 <_ZdlPv@plt>
    8680:      	stp	x29, x30, [sp, #-0x20]!
    8684:      	str	x19, [sp, #0x10]
    8688:      	mov	x29, sp
    868c:      	mov	x19, x0
    8690:      	ldr	x0, [x0, #0x18]
    8694:      	cbz	x0, 0x86a0 <_ZN13MTLReportTool9Interface7versionEv+0x5fc>
    8698:      	bl	0x109b0 <fclose@plt>
    869c:      	str	xzr, [x19, #0x18]
    86a0:      	ldr	x19, [sp, #0x10]
    86a4:      	ldp	x29, x30, [sp], #0x20
    86a8:      	ret
    86ac:      	stp	x29, x30, [sp, #-0x30]!
    86b0:      	stp	x22, x21, [sp, #0x10]
    86b4:      	stp	x20, x19, [sp, #0x20]
    86b8:      	mov	x29, sp
    86bc:      	mov	x19, x0
    86c0:      	mov	x20, x8
    86c4:      	bl	0x8714 <_ZN13MTLReportTool9Interface7versionEv+0x670>
    86c8:      	mov	x21, x0
    86cc:      	add	w8, w21, #0x1
    86d0:      	sxtw	x22, w8
    86d4:      	mov	x0, x22
    86d8:      	bl	0x109c0 <_Znam@plt>
    86dc:      	ldr	x3, [x19, #0x18]
    86e0:      	mov	x1, x22
    86e4:      	mov	w2, #0x1                // =1
    86e8:      	mov	x19, x0
    86ec:      	bl	0x109d0 <fread@plt>
    86f0:      	mov	x0, x20
    86f4:      	mov	x1, x19
    86f8:      	strb	wzr, [x19, w21, sxtw]
    86fc:      	bl	0x7df0 <.text+0x60>
    8700:      	mov	x0, x19
    8704:      	ldp	x20, x19, [sp, #0x20]
    8708:      	ldp	x22, x21, [sp, #0x10]
    870c:      	ldp	x29, x30, [sp], #0x30
    8710:      	b	0x109e0 <_ZdaPv@plt>
    8714:      	stp	x29, x30, [sp, #-0x20]!
    8718:      	str	x19, [sp, #0x10]
    871c:      	mov	x29, sp
    8720:      	mov	x19, x0
    8724:      	ldr	x0, [x0, #0x18]
    8728:      	cbz	x0, 0x8760 <_ZN13MTLReportTool9Interface7versionEv+0x6bc>
    872c:      	mov	x1, xzr
    8730:      	mov	w2, #0x2                // =2
    8734:      	bl	0x109f0 <fseek@plt>
    8738:      	ldr	x0, [x19, #0x18]
    873c:      	bl	0x10a00 <ftell@plt>
    8740:      	ldr	x8, [x19, #0x18]
    8744:      	mov	x19, x0
    8748:      	mov	x1, xzr
    874c:      	mov	w2, wzr
    8750:      	mov	x0, x8
    8754:      	bl	0x109f0 <fseek@plt>
    8758:      	mov	x0, x19
    875c:      	b	0x8764 <_ZN13MTLReportTool9Interface7versionEv+0x6c0>
    8760:      	mov	x0, #-0x1               // =-1
    8764:      	ldr	x19, [sp, #0x10]
    8768:      	ldp	x29, x30, [sp], #0x20
    876c:      	ret
    8770:      	ldrb	w8, [x0, #0x20]
    8774:      	cbz	w8, 0x8780 <_ZN13MTLReportTool9Interface7versionEv+0x6dc>
    8778:      	mov	w0, #0x1                // =1
    877c:      	ret
    8780:      	stp	x29, x30, [sp, #-0x20]!
    8784:      	str	x19, [sp, #0x10]
    8788:      	mov	x29, sp
    878c:      	ldrb	w8, [x0]
    8790:      	ldr	x9, [x0, #0x10]
    8794:      	mov	x19, x0
    8798:      	ldrb	w10, [x1]
    879c:      	tst	w8, #0x1
    87a0:      	ldr	x8, [x1, #0x10]
    87a4:      	csinc	x0, x9, x0, ne
    87a8:      	tst	w10, #0x1
    87ac:      	csinc	x1, x8, x1, ne
    87b0:      	bl	0x10a10 <fopen@plt>
    87b4:      	cmp	x0, #0x0
    87b8:      	str	x0, [x19, #0x18]
    87bc:      	cset	w0, ne
    87c0:      	strb	w0, [x19, #0x20]
    87c4:      	ldr	x19, [sp, #0x10]
    87c8:      	ldp	x29, x30, [sp], #0x20
    87cc:      	ret
    87d0:      	ldr	x3, [x0, #0x18]
    87d4:      	cbz	x3, 0x87f8 <_ZN13MTLReportTool9Interface7versionEv+0x754>
    87d8:      	ldrb	w8, [x1]
    87dc:      	ldp	x10, x9, [x1, #0x8]
    87e0:      	mov	w2, #0x1                // =1
    87e4:      	tst	w8, #0x1
    87e8:      	lsr	x8, x8, #1
    87ec:      	csinc	x0, x9, x1, ne
    87f0:      	csel	x1, x8, x10, eq
    87f4:      	b	0x10a20 <fwrite@plt>
    87f8:      	mov	x0, xzr
    87fc:      	ret
    8800:      	b	0x8898 <_ZN13MTLReportTool9Interface7versionEv+0x7f4>
    8804:      	sub	sp, sp, #0x40
    8808:      	stp	x29, x30, [sp, #0x20]
    880c:      	stp	x20, x19, [sp, #0x30]
    8810:      	add	x29, sp, #0x20
    8814:      	mrs	x20, TPIDR_EL0
    8818:      	ldr	x8, [x20, #0x28]
    881c:      	stur	x8, [x29, #-0x8]
    8820:      	mov	x8, sp
    8824:      	bl	0x8ac4 <_ZN13MTLReportTool9Interface7versionEv+0xa20>
    8828:      	mov	x0, sp
    882c:      	bl	0x88c8 <_ZN13MTLReportTool9Interface7versionEv+0x824>
    8830:      	ldrb	w8, [sp]
    8834:      	mov	w19, w0
    8838:      	tbz	w8, #0x0, 0x8844 <_ZN13MTLReportTool9Interface7versionEv+0x7a0>
    883c:      	ldr	x0, [sp, #0x10]
    8840:      	bl	0x10790 <_ZdlPv@plt>
    8844:      	ldr	x8, [x20, #0x28]
    8848:      	ldur	x9, [x29, #-0x8]
    884c:      	cmp	x8, x9
    8850:      	b.ne	0x8894 <_ZN13MTLReportTool9Interface7versionEv+0x7f0>
    8854:      	and	w0, w19, #0x1
    8858:      	ldp	x20, x19, [sp, #0x30]
    885c:      	ldp	x29, x30, [sp, #0x20]
    8860:      	add	sp, sp, #0x40
    8864:      	ret
    8868:      	ldrb	w8, [sp]
    886c:      	mov	x19, x0
    8870:      	tbz	w8, #0x0, 0x887c <_ZN13MTLReportTool9Interface7versionEv+0x7d8>
    8874:      	ldr	x0, [sp, #0x10]
    8878:      	bl	0x10790 <_ZdlPv@plt>
    887c:      	ldr	x8, [x20, #0x28]
    8880:      	ldur	x9, [x29, #-0x8]
    8884:      	cmp	x8, x9
    8888:      	b.ne	0x8894 <_ZN13MTLReportTool9Interface7versionEv+0x7f0>
    888c:      	mov	x0, x19
    8890:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    8894:      	bl	0x10840 <__stack_chk_fail@plt>
    8898:      	stp	x29, x30, [sp, #-0x10]!
    889c:      	mov	x29, sp
    88a0:      	ldrb	w8, [x0]
    88a4:      	ldr	x9, [x0, #0x10]
    88a8:      	mov	w1, wzr
    88ac:      	tst	w8, #0x1
    88b0:      	csinc	x0, x9, x0, ne
    88b4:      	bl	0x10a40 <access@plt>
    88b8:      	cmp	w0, #0x0
    88bc:      	cset	w0, eq
    88c0:      	ldp	x29, x30, [sp], #0x10
    88c4:      	ret
    88c8:      	sub	sp, sp, #0x40
    88cc:      	stp	x29, x30, [sp, #0x20]
    88d0:      	stp	x20, x19, [sp, #0x30]
    88d4:      	add	x29, sp, #0x20
    88d8:      	mrs	x20, TPIDR_EL0
    88dc:      	ldr	x8, [x20, #0x28]
    88e0:      	stur	x8, [x29, #-0x8]
    88e4:      	ldrb	w8, [x0]
    88e8:      	ldr	x9, [x0, #0x8]
    88ec:      	lsr	x10, x8, #1
    88f0:      	tst	w8, #0x1
    88f4:      	csel	x9, x10, x9, eq
    88f8:      	cbz	x9, 0x8934 <_ZN13MTLReportTool9Interface7versionEv+0x890>
    88fc:      	ldr	x9, [x0, #0x10]
    8900:      	tst	w8, #0x1
    8904:      	mov	x19, x0
    8908:      	mov	w1, wzr
    890c:      	csinc	x0, x9, x0, ne
    8910:      	bl	0x10a40 <access@plt>
    8914:      	cbz	w0, 0x893c <_ZN13MTLReportTool9Interface7versionEv+0x898>
    8918:      	ldrb	w8, [x19]
    891c:      	tbnz	w8, #0x0, 0x8944 <_ZN13MTLReportTool9Interface7versionEv+0x8a0>
    8920:      	ldr	q0, [x19]
    8924:      	ldr	x8, [x19, #0x10]
    8928:      	str	q0, [sp]
    892c:      	str	x8, [sp, #0x10]
    8930:      	b	0x8950 <_ZN13MTLReportTool9Interface7versionEv+0x8ac>
    8934:      	mov	w19, wzr
    8938:      	b	0x89d0 <_ZN13MTLReportTool9Interface7versionEv+0x92c>
    893c:      	mov	w19, #0x1               // =1
    8940:      	b	0x89d0 <_ZN13MTLReportTool9Interface7versionEv+0x92c>
    8944:      	ldp	x2, x1, [x19, #0x8]
    8948:      	mov	x0, sp
    894c:      	bl	0x7f40 <.text+0x1b0>
    8950:      	ldrb	w11, [sp]
    8954:      	ldp	x9, x8, [sp, #0x8]
    8958:      	mov	x12, sp
    895c:      	lsr	x10, x11, #1
    8960:      	ands	w11, w11, #0x1
    8964:      	orr	x19, x12, #0x1
    8968:      	csel	x12, x19, x8, eq
    896c:      	csel	x13, x10, x9, eq
    8970:      	add	x12, x12, x13
    8974:      	ldurb	w12, [x12, #-0x1]
    8978:      	cmp	w12, #0x2f
    897c:      	b.eq	0x89a8 <_ZN13MTLReportTool9Interface7versionEv+0x904>
    8980:      	cmp	w12, #0x5c
    8984:      	b.eq	0x89a8 <_ZN13MTLReportTool9Interface7versionEv+0x904>
    8988:      	adrp	x1, 0x4000
    898c:      	add	x1, x1, #0x9c5
    8990:      	mov	x0, sp
    8994:      	bl	0x108f0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>
    8998:      	ldrb	w11, [sp]
    899c:      	ldp	x9, x8, [sp, #0x8]
    89a0:      	lsr	x10, x11, #1
    89a4:      	and	w11, w11, #0x1
    89a8:      	cmp	w11, #0x0
    89ac:      	csel	x0, x19, x8, eq
    89b0:      	csel	x8, x10, x9, eq
    89b4:      	add	x1, x0, x8
    89b8:      	bl	0x8a24 <_ZN13MTLReportTool9Interface7versionEv+0x980>
    89bc:      	ldrb	w8, [sp]
    89c0:      	mov	w19, w0
    89c4:      	tbz	w8, #0x0, 0x89d0 <_ZN13MTLReportTool9Interface7versionEv+0x92c>
    89c8:      	ldr	x0, [sp, #0x10]
    89cc:      	bl	0x10790 <_ZdlPv@plt>
    89d0:      	ldr	x8, [x20, #0x28]
    89d4:      	ldur	x9, [x29, #-0x8]
    89d8:      	cmp	x8, x9
    89dc:      	b.ne	0x8a20 <_ZN13MTLReportTool9Interface7versionEv+0x97c>
    89e0:      	and	w0, w19, #0x1
    89e4:      	ldp	x20, x19, [sp, #0x30]
    89e8:      	ldp	x29, x30, [sp, #0x20]
    89ec:      	add	sp, sp, #0x40
    89f0:      	ret
    89f4:      	ldrb	w8, [sp]
    89f8:      	mov	x19, x0
    89fc:      	tbz	w8, #0x0, 0x8a08 <_ZN13MTLReportTool9Interface7versionEv+0x964>
    8a00:      	ldr	x0, [sp, #0x10]
    8a04:      	bl	0x10790 <_ZdlPv@plt>
    8a08:      	ldr	x8, [x20, #0x28]
    8a0c:      	ldur	x9, [x29, #-0x8]
    8a10:      	cmp	x8, x9
    8a14:      	b.ne	0x8a20 <_ZN13MTLReportTool9Interface7versionEv+0x97c>
    8a18:      	mov	x0, x19
    8a1c:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    8a20:      	bl	0x10840 <__stack_chk_fail@plt>
    8a24:      	stp	x29, x30, [sp, #-0x30]!
    8a28:      	str	x21, [sp, #0x10]
    8a2c:      	stp	x20, x19, [sp, #0x20]
    8a30:      	mov	x29, sp
    8a34:      	mov	x19, x1
    8a38:      	mov	x20, x0
    8a3c:      	sub	x19, x19, #0x1
    8a40:      	cmp	x19, x20
    8a44:      	b.eq	0x8aa8 <_ZN13MTLReportTool9Interface7versionEv+0xa04>
    8a48:      	ldrb	w21, [x19]
    8a4c:      	cmp	w21, #0x5c
    8a50:      	b.eq	0x8a5c <_ZN13MTLReportTool9Interface7versionEv+0x9b8>
    8a54:      	cmp	w21, #0x2f
    8a58:      	b.ne	0x8a3c <_ZN13MTLReportTool9Interface7versionEv+0x998>
    8a5c:      	mov	x0, x20
    8a60:      	mov	w1, wzr
    8a64:      	strb	wzr, [x19]
    8a68:      	bl	0x10a40 <access@plt>
    8a6c:      	cbz	w0, 0x8a98 <_ZN13MTLReportTool9Interface7versionEv+0x9f4>
    8a70:      	mov	x0, x20
    8a74:      	mov	x1, x19
    8a78:      	bl	0x8a24 <_ZN13MTLReportTool9Interface7versionEv+0x980>
    8a7c:      	tbz	w0, #0x0, 0x8aa0 <_ZN13MTLReportTool9Interface7versionEv+0x9fc>
    8a80:      	mov	x0, x20
    8a84:      	mov	w1, #0x1ed              // =493
    8a88:      	bl	0x10a50 <mkdir@plt>
    8a8c:      	cmn	w0, #0x1
    8a90:      	cset	w8, ne
    8a94:      	b	0x8aa4 <_ZN13MTLReportTool9Interface7versionEv+0xa00>
    8a98:      	mov	w8, #0x1                // =1
    8a9c:      	b	0x8aa4 <_ZN13MTLReportTool9Interface7versionEv+0xa00>
    8aa0:      	mov	w8, wzr
    8aa4:      	strb	w21, [x19]
    8aa8:      	cmp	x19, x20
    8aac:      	cset	w9, ne
    8ab0:      	and	w0, w9, w8
    8ab4:      	ldp	x20, x19, [sp, #0x20]
    8ab8:      	ldr	x21, [sp, #0x10]
    8abc:      	ldp	x29, x30, [sp], #0x30
    8ac0:      	ret
    8ac4:      	sub	sp, sp, #0x80
    8ac8:      	stp	x29, x30, [sp, #0x50]
    8acc:      	stp	x22, x21, [sp, #0x60]
    8ad0:      	stp	x20, x19, [sp, #0x70]
    8ad4:      	add	x29, sp, #0x50
    8ad8:      	mrs	x22, TPIDR_EL0
    8adc:      	mov	x19, x8
    8ae0:      	ldr	x9, [x22, #0x28]
    8ae4:      	stur	x9, [x29, #-0x8]
    8ae8:      	ldrb	w9, [x0]
    8aec:      	ldr	x2, [x0, #0x8]
    8af0:      	lsr	x10, x9, #1
    8af4:      	tst	w9, #0x1
    8af8:      	csel	x10, x10, x2, eq
    8afc:      	cbz	x10, 0x8b1c <_ZN13MTLReportTool9Interface7versionEv+0xa78>
    8b00:      	mov	x20, x0
    8b04:      	tbnz	w9, #0x0, 0x8b38 <_ZN13MTLReportTool9Interface7versionEv+0xa94>
    8b08:      	ldr	q0, [x20]
    8b0c:      	ldr	x8, [x20, #0x10]
    8b10:      	str	q0, [sp, #0x20]
    8b14:      	str	x8, [sp, #0x30]
    8b18:      	b	0x8b44 <_ZN13MTLReportTool9Interface7versionEv+0xaa0>
    8b1c:      	ldr	x8, [x22, #0x28]
    8b20:      	ldur	x9, [x29, #-0x8]
    8b24:      	cmp	x8, x9
    8b28:      	b.ne	0x8c94 <_ZN13MTLReportTool9Interface7versionEv+0xbf0>
    8b2c:      	stp	xzr, xzr, [x19]
    8b30:      	str	xzr, [x19, #0x10]
    8b34:      	b	0x8c50 <_ZN13MTLReportTool9Interface7versionEv+0xbac>
    8b38:      	ldr	x1, [x20, #0x10]
    8b3c:      	add	x0, sp, #0x20
    8b40:      	bl	0x7f40 <.text+0x1b0>
    8b44:      	add	x8, sp, #0x20
    8b48:      	orr	x21, x8, #0x1
    8b4c:      	ldrb	w8, [sp, #0x20]
    8b50:      	ldp	x10, x9, [sp, #0x28]
    8b54:      	lsr	x11, x8, #1
    8b58:      	tst	w8, #0x1
    8b5c:      	csel	x9, x21, x9, eq
    8b60:      	csel	x8, x11, x10, eq
    8b64:      	add	x9, x9, x8
    8b68:      	ldurb	w9, [x9, #-0x1]
    8b6c:      	cmp	w9, #0x5c
    8b70:      	b.eq	0x8b7c <_ZN13MTLReportTool9Interface7versionEv+0xad8>
    8b74:      	cmp	w9, #0x2f
    8b78:      	b.ne	0x8bb8 <_ZN13MTLReportTool9Interface7versionEv+0xb14>
    8b7c:      	sub	x3, x8, #0x1
    8b80:      	add	x0, sp, #0x8
    8b84:      	add	x1, sp, #0x20
    8b88:      	sub	x4, x29, #0x9
    8b8c:      	mov	x2, xzr
    8b90:      	bl	0x108a0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEC2ERKS5_mmRKS4_@plt>
    8b94:      	ldrb	w8, [sp, #0x20]
    8b98:      	tbz	w8, #0x0, 0x8ba4 <_ZN13MTLReportTool9Interface7versionEv+0xb00>
    8b9c:      	ldr	x0, [sp, #0x30]
    8ba0:      	bl	0x10790 <_ZdlPv@plt>
    8ba4:      	ldur	q0, [sp, #0x8]
    8ba8:      	ldr	x8, [sp, #0x18]
    8bac:      	str	q0, [sp, #0x20]
    8bb0:      	str	x8, [sp, #0x30]
    8bb4:      	b	0x8b4c <_ZN13MTLReportTool9Interface7versionEv+0xaa8>
    8bb8:      	mov	x0, x20
    8bbc:      	mov	w1, #0x2f               // =47
    8bc0:      	mov	x2, #-0x1               // =-1
    8bc4:      	bl	0x10a30 <_ZNKSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE5rfindEcm@plt>
    8bc8:      	mov	x21, x0
    8bcc:      	mov	x0, x20
    8bd0:      	mov	w1, #0x5c               // =92
    8bd4:      	mov	x2, #-0x1               // =-1
    8bd8:      	bl	0x10a30 <_ZNKSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE5rfindEcm@plt>
    8bdc:      	and	x8, x0, x21
    8be0:      	cmn	x8, #0x1
    8be4:      	b.eq	0x8c28 <_ZN13MTLReportTool9Interface7versionEv+0xb84>
    8be8:      	mov	x3, x0
    8bec:      	cmn	x21, #0x1
    8bf0:      	b.eq	0x8c08 <_ZN13MTLReportTool9Interface7versionEv+0xb64>
    8bf4:      	cmp	x21, x3
    8bf8:      	csel	x8, x21, x3, hi
    8bfc:      	cmn	x3, #0x1
    8c00:      	csel	x3, x21, x8, eq
    8c04:      	b	0x8c10 <_ZN13MTLReportTool9Interface7versionEv+0xb6c>
    8c08:      	cmn	x3, #0x1
    8c0c:      	b.eq	0x8c28 <_ZN13MTLReportTool9Interface7versionEv+0xb84>
    8c10:      	add	x4, sp, #0x8
    8c14:      	mov	x0, x19
    8c18:      	mov	x1, x20
    8c1c:      	mov	x2, xzr
    8c20:      	bl	0x108a0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEC2ERKS5_mmRKS4_@plt>
    8c24:      	b	0x8c30 <_ZN13MTLReportTool9Interface7versionEv+0xb8c>
    8c28:      	stp	xzr, xzr, [x19]
    8c2c:      	str	xzr, [x19, #0x10]
    8c30:      	ldrb	w8, [sp, #0x20]
    8c34:      	tbz	w8, #0x0, 0x8c40 <_ZN13MTLReportTool9Interface7versionEv+0xb9c>
    8c38:      	ldr	x0, [sp, #0x30]
    8c3c:      	bl	0x10790 <_ZdlPv@plt>
    8c40:      	ldr	x8, [x22, #0x28]
    8c44:      	ldur	x9, [x29, #-0x8]
    8c48:      	cmp	x8, x9
    8c4c:      	b.ne	0x8c94 <_ZN13MTLReportTool9Interface7versionEv+0xbf0>
    8c50:      	ldp	x20, x19, [sp, #0x70]
    8c54:      	ldp	x22, x21, [sp, #0x60]
    8c58:      	ldp	x29, x30, [sp, #0x50]
    8c5c:      	add	sp, sp, #0x80
    8c60:      	ret
    8c64:      	b	0x8c68 <_ZN13MTLReportTool9Interface7versionEv+0xbc4>
    8c68:      	ldrb	w8, [sp, #0x20]
    8c6c:      	mov	x19, x0
    8c70:      	tbz	w8, #0x0, 0x8c7c <_ZN13MTLReportTool9Interface7versionEv+0xbd8>
    8c74:      	ldr	x0, [sp, #0x30]
    8c78:      	bl	0x10790 <_ZdlPv@plt>
    8c7c:      	ldr	x8, [x22, #0x28]
    8c80:      	ldur	x9, [x29, #-0x8]
    8c84:      	cmp	x8, x9
    8c88:      	b.ne	0x8c94 <_ZN13MTLReportTool9Interface7versionEv+0xbf0>
    8c8c:      	mov	x0, x19
    8c90:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    8c94:      	bl	0x10840 <__stack_chk_fail@plt>
    8c98:      	stp	x29, x30, [sp, #-0x20]!
    8c9c:      	str	x19, [sp, #0x10]
    8ca0:      	mov	x29, sp
    8ca4:      	mov	w0, #0x8                // =8
    8ca8:      	bl	0x107b0 <__cxa_allocate_exception@plt>
    8cac:      	mov	x19, x0
    8cb0:      	bl	0x10a60 <_ZNSt20bad_array_new_lengthC1Ev@plt>
    8cb4:      	adrp	x1, 0x15000
    8cb8:      	adrp	x2, 0x15000
    8cbc:      	mov	x0, x19
    8cc0:      	ldr	x1, [x1, #0x1c0]
    8cc4:      	ldr	x2, [x2, #0x1c8]
    8cc8:      	bl	0x107c0 <__cxa_throw@plt>
    8ccc:      	stp	x29, x30, [sp, #-0x30]!
    8cd0:      	str	x21, [sp, #0x10]
    8cd4:      	stp	x20, x19, [sp, #0x20]
    8cd8:      	mov	x29, sp
    8cdc:      	cmn	x2, #0x10
    8ce0:      	mov	x19, x0
    8ce4:      	b.hs	0x8d30 <_ZN13MTLReportTool9Interface7versionEv+0xc8c>
    8ce8:      	mov	x20, x2
    8cec:      	cmp	x2, #0x16
    8cf0:      	b.hi	0x8d08 <_ZN13MTLReportTool9Interface7versionEv+0xc64>
    8cf4:      	lsl	w8, w20, #1
    8cf8:      	stp	xzr, xzr, [x19]
    8cfc:      	str	xzr, [x19, #0x10]
    8d00:      	strb	w8, [x19]
    8d04:      	b	0x8d20 <_ZN13MTLReportTool9Interface7versionEv+0xc7c>
    8d08:      	orr	x21, x20, #0xf
    8d0c:      	add	x0, x21, #0x1
    8d10:      	bl	0x10770 <_Znwm@plt>
    8d14:      	add	x8, x21, #0x2
    8d18:      	stp	x20, x0, [x19, #0x8]
    8d1c:      	str	x8, [x19]
    8d20:      	ldp	x20, x19, [sp, #0x20]
    8d24:      	ldr	x21, [sp, #0x10]
    8d28:      	ldp	x29, x30, [sp], #0x30
    8d2c:      	ret
    8d30:      	mov	x0, x19
    8d34:      	bl	0x7eac <.text+0x11c>
    8d38:      	stp	x29, x30, [sp, #-0x30]!
    8d3c:      	stp	x22, x21, [sp, #0x10]
    8d40:      	stp	x20, x19, [sp, #0x20]
    8d44:      	mov	x29, sp
    8d48:      	stp	xzr, xzr, [x0]
    8d4c:      	str	xzr, [x0, #0x10]
    8d50:      	cbz	x1, 0x8d80 <_ZN13MTLReportTool9Interface7versionEv+0xcdc>
    8d54:      	mov	x21, x2
    8d58:      	mov	x20, x1
    8d5c:      	mov	x19, x0
    8d60:      	bl	0x8db0 <_ZN13MTLReportTool9Interface7versionEv+0xd0c>
    8d64:      	ldr	x22, [x19, #0x8]
    8d68:      	ldrb	w1, [x21]
    8d6c:      	mov	x2, x20
    8d70:      	mov	x0, x22
    8d74:      	bl	0x109a0 <memset@plt>
    8d78:      	add	x8, x22, x20
    8d7c:      	str	x8, [x19, #0x8]
    8d80:      	ldp	x20, x19, [sp, #0x20]
    8d84:      	ldp	x22, x21, [sp, #0x10]
    8d88:      	ldp	x29, x30, [sp], #0x30
    8d8c:      	ret
    8d90:      	ldr	x8, [x19]
    8d94:      	mov	x20, x0
    8d98:      	cbz	x8, 0x8da8 <_ZN13MTLReportTool9Interface7versionEv+0xd04>
    8d9c:      	mov	x0, x8
    8da0:      	str	x8, [x19, #0x8]
    8da4:      	bl	0x10790 <_ZdlPv@plt>
    8da8:      	mov	x0, x20
    8dac:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    8db0:      	stp	x29, x30, [sp, #-0x20]!
    8db4:      	stp	x20, x19, [sp, #0x10]
    8db8:      	mov	x29, sp
    8dbc:      	mov	x19, x0
    8dc0:      	tbnz	x1, #0x3f, 0x8de8 <_ZN13MTLReportTool9Interface7versionEv+0xd44>
    8dc4:      	mov	x0, x1
    8dc8:      	mov	x20, x1
    8dcc:      	bl	0x10770 <_Znwm@plt>
    8dd0:      	add	x8, x0, x20
    8dd4:      	stp	x0, x0, [x19]
    8dd8:      	str	x8, [x19, #0x10]
    8ddc:      	ldp	x20, x19, [sp, #0x10]
    8de0:      	ldp	x29, x30, [sp], #0x20
    8de4:      	ret
    8de8:      	mov	x0, x19
    8dec:      	bl	0x8df0 <_ZN13MTLReportTool9Interface7versionEv+0xd4c>
    8df0:      	stp	x29, x30, [sp, #-0x10]!
    8df4:      	mov	x29, sp
    8df8:      	adrp	x0, 0x5000
    8dfc:      	add	x0, x0, #0x4ea
    8e00:      	bl	0x7ec0 <.text+0x130>

0000000000008e04 <_ZN5utils8TimeCostC2Ev>:
    8e04:      	stp	x29, x30, [sp, #-0x20]!
    8e08:      	stp	x20, x19, [sp, #0x10]
    8e0c:      	mov	x29, sp
    8e10:      	mov	x19, x0
    8e14:      	mov	w0, #0x8                // =8
    8e18:      	bl	0x10770 <_Znwm@plt>
    8e1c:      	mov	x20, x0
    8e20:      	bl	0x10a90 <_ZNSt6__ndk16chrono12steady_clock3nowEv@plt>
    8e24:      	str	x20, [x19]
    8e28:      	str	x0, [x20]
    8e2c:      	bl	0x10a90 <_ZNSt6__ndk16chrono12steady_clock3nowEv@plt>
    8e30:      	str	x0, [x20]
    8e34:      	ldp	x20, x19, [sp, #0x10]
    8e38:      	ldp	x29, x30, [sp], #0x20
    8e3c:      	ret

0000000000008e40 <_ZN5utils8TimeCostD2Ev>:
    8e40:      	ldr	x0, [x0]
    8e44:      	cbz	x0, 0x8e4c <_ZN5utils8TimeCostD2Ev+0xc>
    8e48:      	b	0x10790 <_ZdlPv@plt>
    8e4c:      	ret

0000000000008e50 <_ZN5utils8TimeCost5startEv>:
    8e50:      	stp	x29, x30, [sp, #-0x20]!
    8e54:      	str	x19, [sp, #0x10]
    8e58:      	mov	x29, sp
    8e5c:      	ldr	x19, [x0]
    8e60:      	bl	0x10a90 <_ZNSt6__ndk16chrono12steady_clock3nowEv@plt>
    8e64:      	str	x0, [x19]
    8e68:      	ldr	x19, [sp, #0x10]
    8e6c:      	ldp	x29, x30, [sp], #0x20
    8e70:      	ret

0000000000008e74 <_ZNK5utils8TimeCost8durationENS0_4UnitE>:
    8e74:      	ldr	x0, [x0]
    8e78:      	b	0x8e7c <_ZNK5utils8TimeCost8durationENS0_4UnitE+0x8>
    8e7c:      	stp	x29, x30, [sp, #-0x20]!
    8e80:      	stp	x20, x19, [sp, #0x10]
    8e84:      	mov	x29, sp
    8e88:      	mov	w19, w1
    8e8c:      	mov	x20, x0
    8e90:      	bl	0x10a90 <_ZNSt6__ndk16chrono12steady_clock3nowEv@plt>
    8e94:      	ldr	x8, [x20]
    8e98:      	cmp	w19, #0x1
    8e9c:      	sub	x0, x0, x8
    8ea0:      	b.gt	0x8eb0 <_ZNK5utils8TimeCost8durationENS0_4UnitE+0x3c>
    8ea4:      	cbz	w19, 0x8edc <_ZNK5utils8TimeCost8durationENS0_4UnitE+0x68>
    8ea8:      	cmp	w19, #0x1
    8eac:      	b	0x8ec0 <_ZNK5utils8TimeCost8durationENS0_4UnitE+0x4c>
    8eb0:      	cmp	w19, #0x2
    8eb4:      	b.eq	0x8ef8 <_ZNK5utils8TimeCost8durationENS0_4UnitE+0x84>
    8eb8:      	cmp	w19, #0x3
    8ebc:      	b.eq	0x8f14 <_ZNK5utils8TimeCost8durationENS0_4UnitE+0xa0>
    8ec0:      	mov	x8, #0x34db             // =13531
    8ec4:      	movk	x8, #0xd7b6, lsl #16
    8ec8:      	movk	x8, #0xde82, lsl #32
    8ecc:      	movk	x8, #0x431b, lsl #48
    8ed0:      	smulh	x8, x0, x8
    8ed4:      	asr	x9, x8, #18
    8ed8:      	b	0x8f10 <_ZNK5utils8TimeCost8durationENS0_4UnitE+0x9c>
    8edc:      	mov	x8, #0x94b3             // =38067
    8ee0:      	movk	x8, #0x26d6, lsl #16
    8ee4:      	movk	x8, #0xbe8, lsl #32
    8ee8:      	movk	x8, #0x112e, lsl #48
    8eec:      	smulh	x8, x0, x8
    8ef0:      	asr	x9, x8, #26
    8ef4:      	b	0x8f10 <_ZNK5utils8TimeCost8durationENS0_4UnitE+0x9c>
    8ef8:      	mov	x8, #0xf7cf             // =63439
    8efc:      	movk	x8, #0xe353, lsl #16
    8f00:      	movk	x8, #0x9ba5, lsl #32
    8f04:      	movk	x8, #0x20c4, lsl #48
    8f08:      	smulh	x8, x0, x8
    8f0c:      	asr	x9, x8, #7
    8f10:      	add	x0, x9, x8, lsr #63
    8f14:      	ldp	x20, x19, [sp, #0x10]
    8f18:      	ldp	x29, x30, [sp], #0x20
    8f1c:      	ret

0000000000008f20 <_ZN5utils8TimeCost5resetEv>:
    8f20:      	stp	x29, x30, [sp, #-0x20]!
    8f24:      	str	x19, [sp, #0x10]
    8f28:      	mov	x29, sp
    8f2c:      	ldr	x19, [x0]
    8f30:      	bl	0x10a90 <_ZNSt6__ndk16chrono12steady_clock3nowEv@plt>
    8f34:      	str	x0, [x19]
    8f38:      	ldr	x19, [sp, #0x10]
    8f3c:      	ldp	x29, x30, [sp], #0x20
    8f40:      	ret

0000000000008f44 <_ZN5utils11LogTimeCostC2EPKcz>:
    8f44:      	sub	sp, sp, #0x160
    8f48:      	stp	x29, x30, [sp, #0x120]
    8f4c:      	str	x28, [sp, #0x130]
    8f50:      	stp	x22, x21, [sp, #0x140]
    8f54:      	stp	x20, x19, [sp, #0x150]
    8f58:      	add	x29, sp, #0x120
    8f5c:      	stp	x2, x3, [sp, #0x88]
    8f60:      	mov	x19, x0
    8f64:      	mov	w0, #0x8                // =8
    8f68:      	stp	x4, x5, [sp, #0x98]
    8f6c:      	mov	x20, x1
    8f70:      	stp	x6, x7, [sp, #0xa8]
    8f74:      	stp	q0, q1, [sp]
    8f78:      	stp	q2, q3, [sp, #0x20]
    8f7c:      	stp	q4, q5, [sp, #0x40]
    8f80:      	stp	q6, q7, [sp, #0x60]
    8f84:      	mrs	x22, TPIDR_EL0
    8f88:      	ldr	x8, [x22, #0x28]
    8f8c:      	stur	x8, [x29, #-0x8]
    8f90:      	bl	0x10770 <_Znwm@plt>
    8f94:      	mov	x21, x0
    8f98:      	bl	0x10aa0 <_ZN5utils8TimeCostC1Ev@plt>
    8f9c:      	fmov	d0, xzr
    8fa0:      	movi	v1.2s, #0x1
    8fa4:      	str	x21, [x19]
    8fa8:      	mov	x21, x19
    8fac:      	str	xzr, [x21, #0x8]!
    8fb0:      	mov	v0.d[1], v0.d[0]
    8fb4:      	str	d1, [x19, #0x20]
    8fb8:      	str	q0, [x19, #0x10]
    8fbc:      	cbz	x20, 0x90a8 <_ZN5utils11LogTimeCostC2EPKcz+0x164>
    8fc0:      	add	x9, sp, #0x88
    8fc4:      	add	x8, x29, #0x40
    8fc8:      	mov	x10, sp
    8fcc:      	add	x9, x9, #0x30
    8fd0:      	stp	x8, x9, [x29, #-0x50]
    8fd4:      	mov	x8, #-0x30              // =-48
    8fd8:      	add	x9, x10, #0x80
    8fdc:      	movk	x8, #0xff80, lsl #32
    8fe0:      	stp	x9, x8, [x29, #-0x40]
    8fe4:      	ldp	q0, q1, [x29, #-0x50]
    8fe8:      	stp	q0, q1, [x29, #-0x30]
    8fec:      	sub	x5, x29, #0x30
    8ff0:      	mov	x0, xzr
    8ff4:      	mov	x1, xzr
    8ff8:      	mov	w2, wzr
    8ffc:      	mov	x3, #-0x1               // =-1
    9000:      	mov	x4, x20
    9004:      	bl	0x10a80 <__vsnprintf_chk@plt>
    9008:      	cmp	w0, #0x1
    900c:      	b.lt	0x90a8 <_ZN5utils11LogTimeCostC2EPKcz+0x164>
    9010:      	add	w1, w0, #0x1
    9014:      	sturb	wzr, [x29, #-0x30]
    9018:      	sub	x0, x29, #0x68
    901c:      	sub	x2, x29, #0x30
    9020:      	bl	0x8d38 <_ZN13MTLReportTool9Interface7versionEv+0xc94>
    9024:      	add	x9, sp, #0x88
    9028:      	add	x8, x29, #0x40
    902c:      	add	x9, x9, #0x30
    9030:      	stp	x8, x9, [x29, #-0x50]
    9034:      	mov	x8, #-0x30              // =-48
    9038:      	mov	x9, sp
    903c:      	movk	x8, #0xff80, lsl #32
    9040:      	add	x9, x9, #0x80
    9044:      	stp	x9, x8, [x29, #-0x40]
    9048:      	ldp	x0, x8, [x29, #-0x68]
    904c:      	ldp	q0, q1, [x29, #-0x50]
    9050:      	sub	x1, x8, x0
    9054:      	stp	q0, q1, [x29, #-0x30]
    9058:      	sub	x5, x29, #0x30
    905c:      	mov	w2, wzr
    9060:      	mov	x3, #-0x1               // =-1
    9064:      	mov	x4, x20
    9068:      	bl	0x10a80 <__vsnprintf_chk@plt>
    906c:      	ldur	x1, [x29, #-0x68]
    9070:      	sub	x0, x29, #0x30
    9074:      	bl	0x7df0 <.text+0x60>
    9078:      	ldrb	w8, [x21]
    907c:      	tbz	w8, #0x0, 0x9088 <_ZN5utils11LogTimeCostC2EPKcz+0x144>
    9080:      	ldr	x0, [x19, #0x18]
    9084:      	bl	0x10790 <_ZdlPv@plt>
    9088:      	ldur	q0, [x29, #-0x30]
    908c:      	ldur	x8, [x29, #-0x20]
    9090:      	ldur	x0, [x29, #-0x68]
    9094:      	str	q0, [x21]
    9098:      	str	x8, [x21, #0x10]
    909c:      	cbz	x0, 0x90a8 <_ZN5utils11LogTimeCostC2EPKcz+0x164>
    90a0:      	stur	x0, [x29, #-0x60]
    90a4:      	bl	0x10790 <_ZdlPv@plt>
    90a8:      	ldr	x8, [x22, #0x28]
    90ac:      	ldur	x9, [x29, #-0x8]
    90b0:      	cmp	x8, x9
    90b4:      	b.ne	0x9140 <_ZN5utils11LogTimeCostC2EPKcz+0x1fc>
    90b8:      	ldp	x20, x19, [sp, #0x150]
    90bc:      	ldr	x28, [sp, #0x130]
    90c0:      	ldp	x22, x21, [sp, #0x140]
    90c4:      	ldp	x29, x30, [sp, #0x120]
    90c8:      	add	sp, sp, #0x160
    90cc:      	ret
    90d0:      	b	0x90d4 <_ZN5utils11LogTimeCostC2EPKcz+0x190>
    90d4:      	mov	x20, x0
    90d8:      	ldur	x0, [x29, #-0x68]
    90dc:      	cbz	x0, 0x90f4 <_ZN5utils11LogTimeCostC2EPKcz+0x1b0>
    90e0:      	stur	x0, [x29, #-0x60]
    90e4:      	bl	0x10790 <_ZdlPv@plt>
    90e8:      	b	0x90f4 <_ZN5utils11LogTimeCostC2EPKcz+0x1b0>
    90ec:      	b	0x90f0 <_ZN5utils11LogTimeCostC2EPKcz+0x1ac>
    90f0:      	mov	x20, x0
    90f4:      	ldrb	w8, [x21]
    90f8:      	tbz	w8, #0x0, 0x9104 <_ZN5utils11LogTimeCostC2EPKcz+0x1c0>
    90fc:      	ldr	x0, [x19, #0x18]
    9100:      	bl	0x10790 <_ZdlPv@plt>
    9104:      	ldr	x21, [x19]
    9108:      	str	xzr, [x19]
    910c:      	cbz	x21, 0x9128 <_ZN5utils11LogTimeCostC2EPKcz+0x1e4>
    9110:      	mov	x0, x21
    9114:      	bl	0x10ab0 <_ZN5utils8TimeCostD1Ev@plt>
    9118:      	b	0x9120 <_ZN5utils11LogTimeCostC2EPKcz+0x1dc>
    911c:      	mov	x20, x0
    9120:      	mov	x0, x21
    9124:      	bl	0x10790 <_ZdlPv@plt>
    9128:      	ldr	x8, [x22, #0x28]
    912c:      	ldur	x9, [x29, #-0x8]
    9130:      	cmp	x8, x9
    9134:      	b.ne	0x9140 <_ZN5utils11LogTimeCostC2EPKcz+0x1fc>
    9138:      	mov	x0, x20
    913c:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    9140:      	bl	0x10840 <__stack_chk_fail@plt>

0000000000009144 <_ZN5utils11LogTimeCostC2ERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEN16NS_MTLREPORTTOOL8LogLevelENS_8TimeCost4UnitE>:
    9144:      	stp	x29, x30, [sp, #-0x40]!
    9148:      	str	x23, [sp, #0x10]
    914c:      	stp	x22, x21, [sp, #0x20]
    9150:      	stp	x20, x19, [sp, #0x30]
    9154:      	mov	x29, sp
    9158:      	mov	x19, x0
    915c:      	mov	w0, #0x8                // =8
    9160:      	mov	w21, w3
    9164:      	mov	w20, w2
    9168:      	mov	x23, x1
    916c:      	bl	0x10770 <_Znwm@plt>
    9170:      	mov	x22, x0
    9174:      	bl	0x10aa0 <_ZN5utils8TimeCostC1Ev@plt>
    9178:      	mov	x0, x19
    917c:      	str	x22, [x0], #0x8
    9180:      	ldrb	w8, [x23]
    9184:      	tbnz	w8, #0x0, 0x919c <_ZN5utils11LogTimeCostC2ERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEN16NS_MTLREPORTTOOL8LogLevelENS_8TimeCost4UnitE+0x58>
    9188:      	ldr	x8, [x23, #0x10]
    918c:      	ldr	q0, [x23]
    9190:      	str	x8, [x0, #0x10]
    9194:      	str	q0, [x0]
    9198:      	b	0x91a4 <_ZN5utils11LogTimeCostC2ERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEN16NS_MTLREPORTTOOL8LogLevelENS_8TimeCost4UnitE+0x60>
    919c:      	ldp	x2, x1, [x23, #0x8]
    91a0:      	bl	0x7f40 <.text+0x1b0>
    91a4:      	stp	w21, w20, [x19, #0x20]
    91a8:      	ldp	x20, x19, [sp, #0x30]
    91ac:      	ldr	x23, [sp, #0x10]
    91b0:      	ldp	x22, x21, [sp, #0x20]
    91b4:      	ldp	x29, x30, [sp], #0x40
    91b8:      	ret
    91bc:      	ldr	x22, [x19]
    91c0:      	mov	x20, x0
    91c4:      	str	xzr, [x19]
    91c8:      	cbz	x22, 0x91e4 <_ZN5utils11LogTimeCostC2ERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEN16NS_MTLREPORTTOOL8LogLevelENS_8TimeCost4UnitE+0xa0>
    91cc:      	mov	x0, x22
    91d0:      	bl	0x10ab0 <_ZN5utils8TimeCostD1Ev@plt>
    91d4:      	b	0x91dc <_ZN5utils11LogTimeCostC2ERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEN16NS_MTLREPORTTOOL8LogLevelENS_8TimeCost4UnitE+0x98>
    91d8:      	mov	x20, x0
    91dc:      	mov	x0, x22
    91e0:      	bl	0x10790 <_ZdlPv@plt>
    91e4:      	mov	x0, x20
    91e8:      	bl	0xca4c <JNI_OnUnload+0x1cc>

00000000000091ec <_ZN5utils11LogTimeCostD2Ev>:
    91ec:      	stp	x29, x30, [sp, #-0x20]!
    91f0:      	stp	x20, x19, [sp, #0x10]
    91f4:      	mov	x29, sp
    91f8:      	mov	x19, x0
    91fc:      	nop
    9200:      	adr	x1, 0x4a82
    9204:      	bl	0x10ac0 <_ZNK5utils11LogTimeCost3logEPKcz@plt>
    9208:      	ldrb	w8, [x19, #0x8]
    920c:      	tbz	w8, #0x0, 0x9218 <_ZN5utils11LogTimeCostD2Ev+0x2c>
    9210:      	ldr	x0, [x19, #0x18]
    9214:      	bl	0x10790 <_ZdlPv@plt>
    9218:      	ldr	x20, [x19]
    921c:      	str	xzr, [x19]
    9220:      	cbz	x20, 0x923c <_ZN5utils11LogTimeCostD2Ev+0x50>
    9224:      	mov	x0, x20
    9228:      	bl	0x10ab0 <_ZN5utils8TimeCostD1Ev@plt>
    922c:      	mov	x0, x20
    9230:      	ldp	x20, x19, [sp, #0x10]
    9234:      	ldp	x29, x30, [sp], #0x20
    9238:      	b	0x10790 <_ZdlPv@plt>
    923c:      	ldp	x20, x19, [sp, #0x10]
    9240:      	ldp	x29, x30, [sp], #0x20
    9244:      	ret
    9248:      	bl	0x80b0 <_ZN13MTLReportTool9Interface7versionEv+0xc>

000000000000924c <_ZNK5utils11LogTimeCost3logEPKcz>:
    924c:      	stp	x29, x30, [sp, #-0x40]!
    9250:      	stp	x28, x23, [sp, #0x10]
    9254:      	stp	x22, x21, [sp, #0x20]
    9258:      	stp	x20, x19, [sp, #0x30]
    925c:      	mov	x29, sp
    9260:      	sub	sp, sp, #0x520
    9264:      	stp	x2, x3, [sp, #0x88]
    9268:      	mov	x19, x0
    926c:      	stp	x4, x5, [sp, #0x98]
    9270:      	stp	x6, x7, [sp, #0xa8]
    9274:      	stp	q0, q1, [sp]
    9278:      	stp	q2, q3, [sp, #0x20]
    927c:      	stp	q4, q5, [sp, #0x40]
    9280:      	stp	q6, q7, [sp, #0x60]
    9284:      	mrs	x22, TPIDR_EL0
    9288:      	ldr	x8, [x22, #0x28]
    928c:      	stur	x8, [x29, #-0x8]
    9290:      	stp	xzr, xzr, [sp, #0xf0]
    9294:      	str	xzr, [sp, #0x100]
    9298:      	cbz	x1, 0x9384 <_ZNK5utils11LogTimeCost3logEPKcz+0x138>
    929c:      	add	x9, sp, #0x88
    92a0:      	add	x8, x29, #0x40
    92a4:      	mov	x10, sp
    92a8:      	add	x9, x9, #0x30
    92ac:      	mov	x20, x1
    92b0:      	stp	x8, x9, [sp, #0xd0]
    92b4:      	mov	x8, #-0x30              // =-48
    92b8:      	add	x9, x10, #0x80
    92bc:      	movk	x8, #0xff80, lsl #32
    92c0:      	stp	x9, x8, [sp, #0xe0]
    92c4:      	ldp	q0, q1, [sp, #0xd0]
    92c8:      	stp	q0, q1, [sp, #0x110]
    92cc:      	add	x5, sp, #0x110
    92d0:      	mov	x0, xzr
    92d4:      	mov	x1, xzr
    92d8:      	mov	w2, wzr
    92dc:      	mov	x3, #-0x1               // =-1
    92e0:      	mov	x4, x20
    92e4:      	bl	0x10a80 <__vsnprintf_chk@plt>
    92e8:      	cmp	w0, #0x1
    92ec:      	b.lt	0x9384 <_ZNK5utils11LogTimeCost3logEPKcz+0x138>
    92f0:      	add	w1, w0, #0x1
    92f4:      	strb	wzr, [sp, #0x110]
    92f8:      	add	x0, sp, #0xb8
    92fc:      	add	x2, sp, #0x110
    9300:      	bl	0x8d38 <_ZN13MTLReportTool9Interface7versionEv+0xc94>
    9304:      	add	x9, sp, #0x88
    9308:      	add	x8, x29, #0x40
    930c:      	add	x9, x9, #0x30
    9310:      	stp	x8, x9, [sp, #0xd0]
    9314:      	mov	x8, #-0x30              // =-48
    9318:      	mov	x9, sp
    931c:      	movk	x8, #0xff80, lsl #32
    9320:      	add	x9, x9, #0x80
    9324:      	stp	x9, x8, [sp, #0xe0]
    9328:      	ldp	x0, x8, [sp, #0xb8]
    932c:      	ldp	q0, q1, [sp, #0xd0]
    9330:      	sub	x1, x8, x0
    9334:      	stp	q0, q1, [sp, #0x110]
    9338:      	add	x5, sp, #0x110
    933c:      	mov	w2, wzr
    9340:      	mov	x3, #-0x1               // =-1
    9344:      	mov	x4, x20
    9348:      	bl	0x10a80 <__vsnprintf_chk@plt>
    934c:      	ldr	x1, [sp, #0xb8]
    9350:      	add	x0, sp, #0x110
    9354:      	bl	0x7df0 <.text+0x60>
    9358:      	ldr	q0, [sp, #0x110]
    935c:      	ldr	x0, [sp, #0xb8]
    9360:      	ldr	x8, [sp, #0x120]
    9364:      	str	q0, [sp, #0xf0]
    9368:      	str	x8, [sp, #0x100]
    936c:      	cbz	x0, 0x9378 <_ZNK5utils11LogTimeCost3logEPKcz+0x12c>
    9370:      	str	x0, [sp, #0xc0]
    9374:      	bl	0x10790 <_ZdlPv@plt>
    9378:      	ldrb	w23, [sp, #0xf0]
    937c:      	ldr	x8, [sp, #0xf8]
    9380:      	b	0x938c <_ZNK5utils11LogTimeCost3logEPKcz+0x140>
    9384:      	mov	x8, xzr
    9388:      	mov	w23, wzr
    938c:      	lsr	w9, w23, #1
    9390:      	ldrb	w10, [x19, #0x8]
    9394:      	ands	w21, w23, #0x1
    9398:      	ldr	x11, [x19, #0x18]
    939c:      	csel	x8, x9, x8, eq
    93a0:      	add	x9, x19, #0x9
    93a4:      	tst	w10, #0x1
    93a8:      	csel	x20, x9, x11, eq
    93ac:      	cbz	x8, 0x93f4 <_ZNK5utils11LogTimeCost3logEPKcz+0x1a8>
    93b0:      	ldr	x9, [x19]
    93b4:      	add	x8, sp, #0xf0
    93b8:      	ldr	x10, [sp, #0x100]
    93bc:      	orr	x8, x8, #0x1
    93c0:      	cmp	w21, #0x0
    93c4:      	ldr	w1, [x19, #0x20]
    93c8:      	ldr	x0, [x9]
    93cc:      	csel	x21, x8, x10, eq
    93d0:      	bl	0x8e7c <_ZNK5utils8TimeCost8durationENS0_4UnitE+0x8>
    93d4:      	ldr	w8, [x19, #0x20]
    93d8:      	mov	x6, x0
    93dc:      	cmp	w8, #0x3
    93e0:      	b.hi	0x9424 <_ZNK5utils11LogTimeCost3logEPKcz+0x1d8>
    93e4:      	nop
    93e8:      	adr	x9, 0x14e58 <_ZTISt20bad_array_new_length+0x18>
    93ec:      	ldr	x7, [x9, x8, lsl #3]
    93f0:      	b	0x942c <_ZNK5utils11LogTimeCost3logEPKcz+0x1e0>
    93f4:      	ldr	x8, [x19]
    93f8:      	ldr	w1, [x19, #0x20]
    93fc:      	ldr	x0, [x8]
    9400:      	bl	0x8e7c <_ZNK5utils8TimeCost8durationENS0_4UnitE+0x8>
    9404:      	ldr	w8, [x19, #0x20]
    9408:      	mov	x5, x0
    940c:      	cmp	w8, #0x3
    9410:      	b.hi	0x9480 <_ZNK5utils11LogTimeCost3logEPKcz+0x234>
    9414:      	nop
    9418:      	adr	x9, 0x14e58 <_ZTISt20bad_array_new_length+0x18>
    941c:      	ldr	x6, [x9, x8, lsl #3]
    9420:      	b	0x9488 <_ZNK5utils11LogTimeCost3logEPKcz+0x23c>
    9424:      	nop
    9428:      	adr	x7, 0x4a82
    942c:      	adrp	x3, 0x5000
    9430:      	add	x3, x3, #0x923
    9434:      	add	x0, sp, #0x110
    9438:      	mov	x4, x20
    943c:      	mov	x5, x21
    9440:      	bl	0x9500 <_ZNK5utils11LogTimeCost8durationENS_8TimeCost4UnitE+0xc>
    9444:      	ldrb	w8, [sp, #0xf0]
    9448:      	and	w21, w8, #0x1
    944c:      	cbz	w21, 0x9458 <_ZNK5utils11LogTimeCost3logEPKcz+0x20c>
    9450:      	ldr	x0, [sp, #0x100]
    9454:      	bl	0x10790 <_ZdlPv@plt>
    9458:      	ldr	x8, [x22, #0x28]
    945c:      	ldur	x9, [x29, #-0x8]
    9460:      	cmp	x8, x9
    9464:      	b.ne	0x94f0 <_ZNK5utils11LogTimeCost3logEPKcz+0x2a4>
    9468:      	add	sp, sp, #0x520
    946c:      	ldp	x20, x19, [sp, #0x30]
    9470:      	ldp	x22, x21, [sp, #0x20]
    9474:      	ldp	x28, x23, [sp, #0x10]
    9478:      	ldp	x29, x30, [sp], #0x40
    947c:      	ret
    9480:      	nop
    9484:      	adr	x6, 0x4a82
    9488:      	adrp	x3, 0x4000
    948c:      	add	x3, x3, #0x5fb
    9490:      	add	x0, sp, #0x110
    9494:      	mov	x4, x20
    9498:      	bl	0x9500 <_ZNK5utils11LogTimeCost8durationENS_8TimeCost4UnitE+0xc>
    949c:      	cbnz	w21, 0x9450 <_ZNK5utils11LogTimeCost3logEPKcz+0x204>
    94a0:      	b	0x9458 <_ZNK5utils11LogTimeCost3logEPKcz+0x20c>
    94a4:      	b	0x94a8 <_ZNK5utils11LogTimeCost3logEPKcz+0x25c>
    94a8:      	mov	x19, x0
    94ac:      	ldr	x0, [sp, #0xb8]
    94b0:      	cbz	x0, 0x94d8 <_ZNK5utils11LogTimeCost3logEPKcz+0x28c>
    94b4:      	str	x0, [sp, #0xc0]
    94b8:      	b	0x94d4 <_ZNK5utils11LogTimeCost3logEPKcz+0x288>
    94bc:      	b	0x94c0 <_ZNK5utils11LogTimeCost3logEPKcz+0x274>
    94c0:      	mov	x19, x0
    94c4:      	b	0x94d8 <_ZNK5utils11LogTimeCost3logEPKcz+0x28c>
    94c8:      	mov	x19, x0
    94cc:      	tbz	w23, #0x0, 0x94d8 <_ZNK5utils11LogTimeCost3logEPKcz+0x28c>
    94d0:      	ldr	x0, [sp, #0x100]
    94d4:      	bl	0x10790 <_ZdlPv@plt>
    94d8:      	ldr	x8, [x22, #0x28]
    94dc:      	ldur	x9, [x29, #-0x8]
    94e0:      	cmp	x8, x9
    94e4:      	b.ne	0x94f0 <_ZNK5utils11LogTimeCost3logEPKcz+0x2a4>
    94e8:      	mov	x0, x19
    94ec:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    94f0:      	bl	0x10840 <__stack_chk_fail@plt>

00000000000094f4 <_ZNK5utils11LogTimeCost8durationENS_8TimeCost4UnitE>:
    94f4:      	ldr	x8, [x0]
    94f8:      	ldr	x0, [x8]
    94fc:      	b	0x8e7c <_ZNK5utils8TimeCost8durationENS0_4UnitE+0x8>
    9500:      	sub	sp, sp, #0x110
    9504:      	stp	x29, x30, [sp, #0xf0]
    9508:      	stp	x28, x19, [sp, #0x100]
    950c:      	add	x29, sp, #0xf0
    9510:      	stp	x4, x5, [x29, #-0x70]
    9514:      	sub	x9, x29, #0x70
    9518:      	sub	x10, x29, #0x28
    951c:      	stp	x6, x7, [x29, #-0x60]
    9520:      	mov	x2, x3
    9524:      	sub	x3, x29, #0x50
    9528:      	stp	q0, q1, [sp]
    952c:      	mov	w1, #0x400              // =1024
    9530:      	stp	q2, q3, [sp, #0x20]
    9534:      	stp	q4, q5, [sp, #0x40]
    9538:      	stp	q6, q7, [sp, #0x60]
    953c:      	mrs	x19, TPIDR_EL0
    9540:      	ldr	x8, [x19, #0x28]
    9544:      	stur	x8, [x29, #-0x8]
    9548:      	add	x8, x9, #0x20
    954c:      	add	x9, x29, #0x20
    9550:      	stp	x9, x8, [x29, #-0x28]
    9554:      	mov	x8, #-0x20              // =-32
    9558:      	mov	x9, sp
    955c:      	movk	x8, #0xff80, lsl #32
    9560:      	add	x9, x9, #0x80
    9564:      	stp	x9, x8, [x29, #-0x18]
    9568:      	ldp	q0, q1, [x10]
    956c:      	stp	q0, q1, [x29, #-0x50]
    9570:      	bl	0x10a70 <vsnprintf@plt>
    9574:      	ldr	x8, [x19, #0x28]
    9578:      	ldur	x9, [x29, #-0x8]
    957c:      	cmp	x8, x9
    9580:      	b.ne	0x9594 <_ZNK5utils11LogTimeCost8durationENS_8TimeCost4UnitE+0xa0>
    9584:      	ldp	x28, x19, [sp, #0x100]
    9588:      	ldp	x29, x30, [sp, #0xf0]
    958c:      	add	sp, sp, #0x110
    9590:      	ret
    9594:      	bl	0x10840 <__stack_chk_fail@plt>

0000000000009598 <_ZN5utils11LogTimeCost5resetEv>:
    9598:      	stp	x29, x30, [sp, #-0x20]!
    959c:      	str	x19, [sp, #0x10]
    95a0:      	mov	x29, sp
    95a4:      	ldr	x8, [x0]
    95a8:      	ldr	x19, [x8]
    95ac:      	bl	0x10a90 <_ZNSt6__ndk16chrono12steady_clock3nowEv@plt>
    95b0:      	str	x0, [x19]
    95b4:      	ldr	x19, [sp, #0x10]
    95b8:      	ldp	x29, x30, [sp], #0x20
    95bc:      	ret

00000000000095c0 <_ZN13VLLogMediator11getInstanceEv>:
    95c0:      	stp	x29, x30, [sp, #-0x10]!
    95c4:      	mov	x29, sp
    95c8:      	nop
    95cc:      	adr	x8, 0x19840
    95d0:      	ldarb	w8, [x8]
    95d4:      	tbz	w8, #0x0, 0x95e8 <_ZN13VLLogMediator11getInstanceEv+0x28>
    95d8:      	nop
    95dc:      	adr	x0, 0x196f0
    95e0:      	ldp	x29, x30, [sp], #0x10
    95e4:      	ret
    95e8:      	nop
    95ec:      	adr	x0, 0x19840
    95f0:      	bl	0x10ae0 <__cxa_guard_acquire@plt>
    95f4:      	cbz	w0, 0x95d8 <_ZN13VLLogMediator11getInstanceEv+0x18>
    95f8:      	movi	v0.2d, #0000000000000000
    95fc:      	nop
    9600:      	adr	x1, 0x196f0
    9604:      	strb	wzr, [x1]
    9608:      	adrp	x0, 0x15000
    960c:      	nop
    9610:      	adr	x2, 0x14de0
    9614:      	str	xzr, [x1, #0xb0]
    9618:      	strb	wzr, [x1, #0x140]
    961c:      	stur	q0, [x1, #0x8]
    9620:      	stur	q0, [x1, #0x18]
    9624:      	stur	q0, [x1, #0x28]
    9628:      	stur	q0, [x1, #0x38]
    962c:      	stur	q0, [x1, #0x48]
    9630:      	stur	q0, [x1, #0x58]
    9634:      	stur	q0, [x1, #0x68]
    9638:      	stur	q0, [x1, #0x78]
    963c:      	stp	q0, q0, [x1, #0xc0]
    9640:      	stp	q0, q0, [x1, #0xe0]
    9644:      	stur	q0, [x1, #0xfe]
    9648:      	stp	q0, q0, [x1, #0x110]
    964c:      	str	q0, [x1, #0x130]
    9650:      	ldr	x0, [x0, #0x1d0]
    9654:      	bl	0x10740 <__cxa_atexit@plt>
    9658:      	nop
    965c:      	adr	x0, 0x19840
    9660:      	bl	0x10af0 <__cxa_guard_release@plt>
    9664:      	b	0x95d8 <_ZN13VLLogMediator11getInstanceEv+0x18>

0000000000009668 <_ZN13VLLogMediatorD2Ev>:
    9668:      	stp	x29, x30, [sp, #-0x20]!
    966c:      	str	x19, [sp, #0x10]
    9670:      	mov	x29, sp
    9674:      	mov	x19, x0
    9678:      	bl	0x10b00 <_ZN13VLLogMediator3endEv@plt>
    967c:      	add	x0, x19, #0x110
    9680:      	bl	0x10b10 <_ZNSt6__ndk118condition_variableD1Ev@plt>
    9684:      	ldrb	w8, [x19, #0xf0]
    9688:      	tbz	w8, #0x0, 0x9694 <_ZN13VLLogMediatorD2Ev+0x2c>
    968c:      	ldr	x0, [x19, #0x100]
    9690:      	bl	0x10790 <_ZdlPv@plt>
    9694:      	ldrb	w8, [x19, #0xd8]
    9698:      	tbz	w8, #0x0, 0x96a4 <_ZN13VLLogMediatorD2Ev+0x3c>
    969c:      	ldr	x0, [x19, #0xe8]
    96a0:      	bl	0x10790 <_ZdlPv@plt>
    96a4:      	ldrb	w8, [x19, #0xc0]
    96a8:      	tbz	w8, #0x0, 0x96b4 <_ZN13VLLogMediatorD2Ev+0x4c>
    96ac:      	ldr	x0, [x19, #0xd0]
    96b0:      	bl	0x10790 <_ZdlPv@plt>
    96b4:      	ldr	x0, [x19, #0xb0]
    96b8:      	add	x9, x19, #0x90
    96bc:      	cmp	x0, x9
    96c0:      	b.eq	0x96d0 <_ZN13VLLogMediatorD2Ev+0x68>
    96c4:      	cbz	x0, 0x96e4 <_ZN13VLLogMediatorD2Ev+0x7c>
    96c8:      	mov	w8, #0x5                // =5
    96cc:      	b	0x96d8 <_ZN13VLLogMediatorD2Ev+0x70>
    96d0:      	mov	w8, #0x4                // =4
    96d4:      	mov	x0, x9
    96d8:      	ldr	x9, [x0]
    96dc:      	ldr	x8, [x9, x8, lsl #3]
    96e0:      	blr	x8
    96e4:      	add	x0, x19, #0x60
    96e8:      	bl	0x10b20 <_ZNSt6__ndk15mutexD1Ev@plt>
    96ec:      	add	x0, x19, #0x38
    96f0:      	bl	0x10b20 <_ZNSt6__ndk15mutexD1Ev@plt>
    96f4:      	add	x0, x19, #0x10
    96f8:      	bl	0x10b20 <_ZNSt6__ndk15mutexD1Ev@plt>
    96fc:      	add	x0, x19, #0x8
    9700:      	ldr	x19, [sp, #0x10]
    9704:      	ldp	x29, x30, [sp], #0x20
    9708:      	b	0x10b30 <_ZNSt6__ndk16threadD1Ev@plt>
    970c:      	bl	0x80b0 <_ZN13MTLReportTool9Interface7versionEv+0xc>

0000000000009710 <_ZN13VLLogMediator3endEv>:
    9710:      	sub	sp, sp, #0x40
    9714:      	stp	x29, x30, [sp, #0x10]
    9718:      	str	x21, [sp, #0x20]
    971c:      	stp	x20, x19, [sp, #0x30]
    9720:      	add	x29, sp, #0x10
    9724:      	mrs	x20, TPIDR_EL0
    9728:      	mov	x19, x0
    972c:      	ldr	x8, [x20, #0x28]
    9730:      	str	x8, [sp, #0x8]
    9734:      	str	xzr, [sp]
    9738:      	add	x0, x0, #0x10
    973c:      	bl	0x10b40 <_ZNSt6__ndk15mutex4lockEv@plt>
    9740:      	ldrb	w8, [x19, #0x10c]
    9744:      	ldrb	w9, [x19, #0x10d]
    9748:      	orr	w9, w8, w9
    974c:      	ldr	x8, [x19, #0x8]
    9750:      	stlrb	wzr, [x19]
    9754:      	cmp	w9, #0x0
    9758:      	add	x9, x19, #0x140
    975c:      	ccmp	x8, #0x0, #0x0, eq
    9760:      	stlrb	wzr, [x9]
    9764:      	cset	w21, ne
    9768:      	cbz	x8, 0x9798 <_ZN13VLLogMediator3endEv+0x88>
    976c:      	add	x0, x19, #0x10
    9770:      	str	x8, [sp]
    9774:      	str	xzr, [x19, #0x8]
    9778:      	strh	wzr, [x19, #0x10c]
    977c:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    9780:      	add	x0, x19, #0x110
    9784:      	bl	0x10b60 <_ZNSt6__ndk118condition_variable10notify_oneEv@plt>
    9788:      	mov	x0, sp
    978c:      	bl	0x10b70 <_ZNSt6__ndk16thread4joinEv@plt>
    9790:      	cbnz	w21, 0x97b0 <_ZN13VLLogMediator3endEv+0xa0>
    9794:      	b	0x97b4 <_ZN13VLLogMediator3endEv+0xa4>
    9798:      	add	x0, x19, #0x10
    979c:      	strh	wzr, [x19, #0x10c]
    97a0:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    97a4:      	add	x0, x19, #0x110
    97a8:      	bl	0x10b60 <_ZNSt6__ndk118condition_variable10notify_oneEv@plt>
    97ac:      	cbz	w21, 0x97b4 <_ZN13VLLogMediator3endEv+0xa4>
    97b0:      	bl	0x10b80 <_Z15vlcollect_resetv@plt>
    97b4:      	mov	x0, sp
    97b8:      	bl	0x10b30 <_ZNSt6__ndk16threadD1Ev@plt>
    97bc:      	ldr	x8, [x20, #0x28]
    97c0:      	ldr	x9, [sp, #0x8]
    97c4:      	cmp	x8, x9
    97c8:      	b.ne	0x9808 <_ZN13VLLogMediator3endEv+0xf8>
    97cc:      	ldp	x20, x19, [sp, #0x30]
    97d0:      	ldr	x21, [sp, #0x20]
    97d4:      	ldp	x29, x30, [sp, #0x10]
    97d8:      	add	sp, sp, #0x40
    97dc:      	ret
    97e0:      	b	0x97e4 <_ZN13VLLogMediator3endEv+0xd4>
    97e4:      	mov	x19, x0
    97e8:      	mov	x0, sp
    97ec:      	bl	0x10b30 <_ZNSt6__ndk16threadD1Ev@plt>
    97f0:      	ldr	x8, [x20, #0x28]
    97f4:      	ldr	x9, [sp, #0x8]
    97f8:      	cmp	x8, x9
    97fc:      	b.ne	0x9808 <_ZN13VLLogMediator3endEv+0xf8>
    9800:      	mov	x0, x19
    9804:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    9808:      	bl	0x10840 <__stack_chk_fail@plt>

000000000000980c <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE>:
    980c:      	sub	sp, sp, #0xb0
    9810:      	stp	x29, x30, [sp, #0x80]
    9814:      	str	x21, [sp, #0x90]
    9818:      	stp	x20, x19, [sp, #0xa0]
    981c:      	add	x29, sp, #0x80
    9820:      	mrs	x21, TPIDR_EL0
    9824:      	mov	x9, x1
    9828:      	mov	x19, x0
    982c:      	ldr	x8, [x21, #0x28]
    9830:      	nop
    9834:      	adr	x1, 0x196d0
    9838:      	mov	x0, x9
    983c:      	stur	x8, [x29, #-0x8]
    9840:      	add	x8, sp, #0x38
    9844:      	bl	0x9a00 <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1f4>
    9848:      	add	x0, x19, #0x10
    984c:      	bl	0x10b40 <_ZNSt6__ndk15mutex4lockEv@plt>
    9850:      	ldrb	w8, [x19, #0x10c]
    9854:      	cbnz	w8, 0x9934 <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x128>
    9858:      	add	x0, x19, #0xc0
    985c:      	add	x1, sp, #0x38
    9860:      	bl	0x107a0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_@plt>
    9864:      	sub	x0, x29, #0x30
    9868:      	add	x1, x19, #0xc0
    986c:      	bl	0x85ec <_ZN13MTLReportTool9Interface7versionEv+0x548>
    9870:      	adrp	x1, 0x4000
    9874:      	add	x1, x1, #0xa82
    9878:      	add	x0, sp, #0x20
    987c:      	bl	0x7df0 <.text+0x60>
    9880:      	sub	x0, x29, #0x30
    9884:      	bl	0x8800 <_ZN13MTLReportTool9Interface7versionEv+0x75c>
    9888:      	tbz	w0, #0x0, 0x98f4 <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0xe8>
    988c:      	adrp	x1, 0x5000
    9890:      	add	x1, x1, #0x42b
    9894:      	add	x0, sp, #0x8
    9898:      	bl	0x7df0 <.text+0x60>
    989c:      	sub	x0, x29, #0x30
    98a0:      	add	x1, sp, #0x8
    98a4:      	bl	0x8770 <_ZN13MTLReportTool9Interface7versionEv+0x6cc>
    98a8:      	ldrb	w8, [sp, #0x8]
    98ac:      	mov	w20, w0
    98b0:      	tbz	w8, #0x0, 0x98bc <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0xb0>
    98b4:      	ldr	x0, [sp, #0x18]
    98b8:      	bl	0x10790 <_ZdlPv@plt>
    98bc:      	tbz	w20, #0x0, 0x98f4 <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0xe8>
    98c0:      	add	x8, sp, #0x8
    98c4:      	sub	x0, x29, #0x30
    98c8:      	bl	0x86ac <_ZN13MTLReportTool9Interface7versionEv+0x608>
    98cc:      	ldrb	w8, [sp, #0x20]
    98d0:      	tbz	w8, #0x0, 0x98dc <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0xd0>
    98d4:      	ldr	x0, [sp, #0x30]
    98d8:      	bl	0x10790 <_ZdlPv@plt>
    98dc:      	ldur	q0, [sp, #0x8]
    98e0:      	ldr	x8, [sp, #0x18]
    98e4:      	str	q0, [sp, #0x20]
    98e8:      	str	x8, [sp, #0x30]
    98ec:      	sub	x0, x29, #0x30
    98f0:      	bl	0x8680 <_ZN13MTLReportTool9Interface7versionEv+0x5dc>
    98f4:      	ldrb	w8, [sp, #0x20]
    98f8:      	ldr	x9, [sp, #0x30]
    98fc:      	add	x10, sp, #0x20
    9900:      	orr	x10, x10, #0x1
    9904:      	tst	w8, #0x1
    9908:      	csel	x0, x10, x9, eq
    990c:      	bl	0x10ba0 <_Z14vlcollect_initPKc@plt>
    9910:      	cbz	w0, 0x991c <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x110>
    9914:      	mov	w8, #0x1                // =1
    9918:      	strh	w8, [x19, #0x10c]
    991c:      	ldrb	w8, [sp, #0x20]
    9920:      	tbz	w8, #0x0, 0x992c <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x120>
    9924:      	ldr	x0, [sp, #0x30]
    9928:      	bl	0x10790 <_ZdlPv@plt>
    992c:      	sub	x0, x29, #0x30
    9930:      	bl	0x863c <_ZN13MTLReportTool9Interface7versionEv+0x598>
    9934:      	add	x0, x19, #0x10
    9938:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    993c:      	ldrb	w8, [sp, #0x38]
    9940:      	tbz	w8, #0x0, 0x994c <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x140>
    9944:      	ldr	x0, [sp, #0x48]
    9948:      	bl	0x10790 <_ZdlPv@plt>
    994c:      	ldr	x8, [x21, #0x28]
    9950:      	ldur	x9, [x29, #-0x8]
    9954:      	cmp	x8, x9
    9958:      	b.ne	0x99fc <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1f0>
    995c:      	ldp	x20, x19, [sp, #0xa0]
    9960:      	ldr	x21, [sp, #0x90]
    9964:      	ldp	x29, x30, [sp, #0x80]
    9968:      	add	sp, sp, #0xb0
    996c:      	ret
    9970:      	b	0x99a8 <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x19c>
    9974:      	ldrb	w8, [sp, #0x8]
    9978:      	mov	x20, x0
    997c:      	tbz	w8, #0x0, 0x99ac <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1a0>
    9980:      	ldr	x0, [sp, #0x18]
    9984:      	bl	0x10790 <_ZdlPv@plt>
    9988:      	b	0x99ac <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1a0>
    998c:      	b	0x99a8 <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x19c>
    9990:      	b	0x99a8 <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x19c>
    9994:      	mov	x20, x0
    9998:      	b	0x99bc <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1b0>
    999c:      	b	0x99a0 <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x194>
    99a0:      	mov	x20, x0
    99a4:      	b	0x99c4 <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1b8>
    99a8:      	mov	x20, x0
    99ac:      	ldrb	w8, [sp, #0x20]
    99b0:      	tbz	w8, #0x0, 0x99bc <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1b0>
    99b4:      	ldr	x0, [sp, #0x30]
    99b8:      	bl	0x10790 <_ZdlPv@plt>
    99bc:      	sub	x0, x29, #0x30
    99c0:      	bl	0x863c <_ZN13MTLReportTool9Interface7versionEv+0x598>
    99c4:      	add	x0, x19, #0x10
    99c8:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    99cc:      	b	0x99d4 <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1c8>
    99d0:      	mov	x20, x0
    99d4:      	ldrb	w8, [sp, #0x38]
    99d8:      	tbz	w8, #0x0, 0x99e4 <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1d8>
    99dc:      	ldr	x0, [sp, #0x48]
    99e0:      	bl	0x10790 <_ZdlPv@plt>
    99e4:      	ldr	x8, [x21, #0x28]
    99e8:      	ldur	x9, [x29, #-0x8]
    99ec:      	cmp	x8, x9
    99f0:      	b.ne	0x99fc <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1f0>
    99f4:      	mov	x0, x20
    99f8:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    99fc:      	bl	0x10840 <__stack_chk_fail@plt>
    9a00:      	sub	sp, sp, #0x50
    9a04:      	stp	x29, x30, [sp, #0x10]
    9a08:      	stp	x24, x23, [sp, #0x20]
    9a0c:      	stp	x22, x21, [sp, #0x30]
    9a10:      	stp	x20, x19, [sp, #0x40]
    9a14:      	add	x29, sp, #0x10
    9a18:      	mrs	x24, TPIDR_EL0
    9a1c:      	mov	x23, x8
    9a20:      	mov	x21, x0
    9a24:      	ldr	x8, [x24, #0x28]
    9a28:      	add	x3, sp, #0x7
    9a2c:      	mov	x19, x1
    9a30:      	str	x8, [sp, #0x8]
    9a34:      	ldrb	w8, [x0]
    9a38:      	ldrb	w9, [x1]
    9a3c:      	ldr	x10, [x0, #0x8]
    9a40:      	mov	x0, x23
    9a44:      	lsr	x11, x8, #1
    9a48:      	tst	w8, #0x1
    9a4c:      	ldr	x8, [x1, #0x8]
    9a50:      	lsr	x12, x9, #1
    9a54:      	csel	x22, x11, x10, eq
    9a58:      	tst	w9, #0x1
    9a5c:      	csel	x20, x12, x8, eq
    9a60:      	add	x2, x20, x22
    9a64:      	bl	0x8ccc <_ZN13MTLReportTool9Interface7versionEv+0xc28>
    9a68:      	ldrb	w8, [x23]
    9a6c:      	ldr	x9, [x23, #0x10]
    9a70:      	tst	w8, #0x1
    9a74:      	csinc	x23, x9, x23, ne
    9a78:      	cbz	x22, 0x9a98 <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x28c>
    9a7c:      	ldrb	w8, [x21]
    9a80:      	ldr	x9, [x21, #0x10]
    9a84:      	mov	x0, x23
    9a88:      	mov	x2, x22
    9a8c:      	tst	w8, #0x1
    9a90:      	csinc	x1, x9, x21, ne
    9a94:      	bl	0x10780 <memmove@plt>
    9a98:      	add	x21, x23, x22
    9a9c:      	cbz	x20, 0x9abc <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x2b0>
    9aa0:      	ldrb	w8, [x19]
    9aa4:      	ldr	x9, [x19, #0x10]
    9aa8:      	mov	x0, x21
    9aac:      	mov	x2, x20
    9ab0:      	tst	w8, #0x1
    9ab4:      	csinc	x1, x9, x19, ne
    9ab8:      	bl	0x10780 <memmove@plt>
    9abc:      	strb	wzr, [x21, x20]
    9ac0:      	ldr	x8, [x24, #0x28]
    9ac4:      	ldr	x9, [sp, #0x8]
    9ac8:      	cmp	x8, x9
    9acc:      	b.ne	0x9ae8 <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x2dc>
    9ad0:      	ldp	x20, x19, [sp, #0x40]
    9ad4:      	ldp	x22, x21, [sp, #0x30]
    9ad8:      	ldp	x24, x23, [sp, #0x20]
    9adc:      	ldp	x29, x30, [sp, #0x10]
    9ae0:      	add	sp, sp, #0x50
    9ae4:      	ret
    9ae8:      	bl	0x10840 <__stack_chk_fail@plt>

0000000000009aec <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE>:
    9aec:      	sub	sp, sp, #0x80
    9af0:      	stp	x29, x30, [sp, #0x50]
    9af4:      	stp	x22, x21, [sp, #0x60]
    9af8:      	stp	x20, x19, [sp, #0x70]
    9afc:      	add	x29, sp, #0x50
    9b00:      	mrs	x22, TPIDR_EL0
    9b04:      	mov	x19, x0
    9b08:      	add	x0, x0, #0x10
    9b0c:      	ldr	x8, [x22, #0x28]
    9b10:      	mov	x20, x1
    9b14:      	stur	x8, [x29, #-0x8]
    9b18:      	bl	0x10b40 <_ZNSt6__ndk15mutex4lockEv@plt>
    9b1c:      	ldrb	w8, [x19, #0x10c]
    9b20:      	cbz	w8, 0x9c54 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x168>
    9b24:      	ldrb	w8, [x19, #0x10d]
    9b28:      	cbnz	w8, 0x9c54 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x168>
    9b2c:      	ldarb	w8, [x19]
    9b30:      	tbnz	w8, #0x0, 0x9c54 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x168>
    9b34:      	ldr	x8, [x19, #0x8]
    9b38:      	cbnz	x8, 0x9c54 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x168>
    9b3c:      	add	x0, x19, #0xd8
    9b40:      	mov	x1, x20
    9b44:      	bl	0x107a0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_@plt>
    9b48:      	ldrb	w8, [x19, #0xd8]
    9b4c:      	ldr	x9, [x19, #0xe8]
    9b50:      	add	x10, x19, #0xd9
    9b54:      	tst	w8, #0x1
    9b58:      	csel	x0, x10, x9, eq
    9b5c:      	bl	0x10bc0 <_Z20vlcollect_set_configPKc@plt>
    9b60:      	cbz	w0, 0x9c54 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x168>
    9b64:      	mov	x1, x19
    9b68:      	ldrb	w8, [x1, #0xc0]!
    9b6c:      	ldr	x9, [x1, #0x8]
    9b70:      	lsr	x10, x8, #1
    9b74:      	tst	w8, #0x1
    9b78:      	csel	x8, x10, x9, eq
    9b7c:      	cbz	x8, 0x9be0 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0xf4>
    9b80:      	add	x0, sp, #0x20
    9b84:      	bl	0x85ec <_ZN13MTLReportTool9Interface7versionEv+0x548>
    9b88:      	add	x0, sp, #0x20
    9b8c:      	bl	0x8804 <_ZN13MTLReportTool9Interface7versionEv+0x760>
    9b90:      	adrp	x1, 0x5000
    9b94:      	add	x1, x1, #0x71d
    9b98:      	add	x0, sp, #0x8
    9b9c:      	bl	0x7df0 <.text+0x60>
    9ba0:      	add	x0, sp, #0x20
    9ba4:      	add	x1, sp, #0x8
    9ba8:      	bl	0x8770 <_ZN13MTLReportTool9Interface7versionEv+0x6cc>
    9bac:      	ldrb	w8, [sp, #0x8]
    9bb0:      	mov	w20, w0
    9bb4:      	tbz	w8, #0x0, 0x9bc0 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0xd4>
    9bb8:      	ldr	x0, [sp, #0x18]
    9bbc:      	bl	0x10790 <_ZdlPv@plt>
    9bc0:      	tbz	w20, #0x0, 0x9bd8 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0xec>
    9bc4:      	add	x0, sp, #0x20
    9bc8:      	add	x1, x19, #0xd8
    9bcc:      	bl	0x87d0 <_ZN13MTLReportTool9Interface7versionEv+0x72c>
    9bd0:      	add	x0, sp, #0x20
    9bd4:      	bl	0x8680 <_ZN13MTLReportTool9Interface7versionEv+0x5dc>
    9bd8:      	add	x0, sp, #0x20
    9bdc:      	bl	0x863c <_ZN13MTLReportTool9Interface7versionEv+0x598>
    9be0:      	mov	w8, #0x1                // =1
    9be4:      	stlrb	w8, [x19]
    9be8:      	mov	w0, #0x8                // =8
    9bec:      	bl	0x10770 <_Znwm@plt>
    9bf0:      	mov	x20, x0
    9bf4:      	bl	0x10bd0 <_ZNSt6__ndk115__thread_structC1Ev@plt>
    9bf8:      	mov	w0, #0x10               // =16
    9bfc:      	bl	0x10770 <_Znwm@plt>
    9c00:      	mov	x3, x0
    9c04:      	stp	x20, x19, [x0]
    9c08:      	str	x0, [sp, #0x20]
    9c0c:      	nop
    9c10:      	adr	x2, 0xac30 <_ZN13VLLogMediator8testDataEv+0xcc>
    9c14:      	add	x0, sp, #0x8
    9c18:      	mov	x1, xzr
    9c1c:      	bl	0x10be0 <pthread_create@plt>
    9c20:      	cbnz	w0, 0x9c80 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x194>
    9c24:      	add	x0, sp, #0x20
    9c28:      	str	xzr, [sp, #0x20]
    9c2c:      	bl	0xacc4 <_ZN13VLLogMediator8testDataEv+0x160>
    9c30:      	ldr	x8, [x19, #0x8]
    9c34:      	cbnz	x8, 0x9c9c <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1b0>
    9c38:      	ldr	x8, [sp, #0x8]
    9c3c:      	add	x0, sp, #0x8
    9c40:      	str	xzr, [sp, #0x8]
    9c44:      	str	x8, [x19, #0x8]
    9c48:      	bl	0x10b30 <_ZNSt6__ndk16threadD1Ev@plt>
    9c4c:      	mov	w8, #0x1                // =1
    9c50:      	strb	w8, [x19, #0x10d]
    9c54:      	add	x0, x19, #0x10
    9c58:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    9c5c:      	ldr	x8, [x22, #0x28]
    9c60:      	ldur	x9, [x29, #-0x8]
    9c64:      	cmp	x8, x9
    9c68:      	b.ne	0x9d5c <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x270>
    9c6c:      	ldp	x20, x19, [sp, #0x70]
    9c70:      	ldp	x22, x21, [sp, #0x60]
    9c74:      	ldp	x29, x30, [sp, #0x50]
    9c78:      	add	sp, sp, #0x80
    9c7c:      	ret
    9c80:      	ldr	x8, [x22, #0x28]
    9c84:      	ldur	x9, [x29, #-0x8]
    9c88:      	cmp	x8, x9
    9c8c:      	b.ne	0x9d5c <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x270>
    9c90:      	adrp	x1, 0x4000
    9c94:      	add	x1, x1, #0x907
    9c98:      	bl	0x10bf0 <_ZNSt6__ndk120__throw_system_errorEiPKc@plt>
    9c9c:      	bl	0x10870 <_ZSt9terminatev@plt>
    9ca0:      	b	0x9cc0 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1d4>
    9ca4:      	ldrb	w8, [sp, #0x8]
    9ca8:      	mov	x20, x0
    9cac:      	tbz	w8, #0x0, 0x9cc4 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1d8>
    9cb0:      	ldr	x0, [sp, #0x18]
    9cb4:      	bl	0x10790 <_ZdlPv@plt>
    9cb8:      	b	0x9cc4 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1d8>
    9cbc:      	b	0x9cc0 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1d4>
    9cc0:      	mov	x20, x0
    9cc4:      	add	x0, sp, #0x20
    9cc8:      	bl	0x863c <_ZN13MTLReportTool9Interface7versionEv+0x598>
    9ccc:      	b	0x9d3c <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x250>
    9cd0:      	b	0x9d00 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x214>
    9cd4:      	mov	x21, x0
    9cd8:      	mov	x0, x20
    9cdc:      	bl	0x10c00 <_ZNSt6__ndk115__thread_structD1Ev@plt>
    9ce0:      	b	0x9ce8 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x1fc>
    9ce4:      	mov	x21, x0
    9ce8:      	mov	x0, x20
    9cec:      	bl	0x10790 <_ZdlPv@plt>
    9cf0:      	b	0x9d14 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x228>
    9cf4:      	mov	x21, x0
    9cf8:      	b	0x9d14 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x228>
    9cfc:      	b	0x9d00 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x214>
    9d00:      	mov	x20, x0
    9d04:      	b	0x9d3c <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x250>
    9d08:      	mov	x21, x0
    9d0c:      	add	x0, sp, #0x20
    9d10:      	bl	0xacc4 <_ZN13VLLogMediator8testDataEv+0x160>
    9d14:      	mov	x0, x21
    9d18:      	bl	0x10860 <__cxa_begin_catch@plt>
    9d1c:      	stlrb	wzr, [x19]
    9d20:      	ldr	x8, [x22, #0x28]
    9d24:      	ldur	x9, [x29, #-0x8]
    9d28:      	cmp	x8, x9
    9d2c:      	b.ne	0x9d5c <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x270>
    9d30:      	bl	0x10c10 <__cxa_rethrow@plt>
    9d34:      	mov	x20, x0
    9d38:      	bl	0x10990 <__cxa_end_catch@plt>
    9d3c:      	add	x0, x19, #0x10
    9d40:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    9d44:      	ldr	x8, [x22, #0x28]
    9d48:      	ldur	x9, [x29, #-0x8]
    9d4c:      	cmp	x8, x9
    9d50:      	b.ne	0x9d5c <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE+0x270>
    9d54:      	mov	x0, x20
    9d58:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    9d5c:      	bl	0x10840 <__stack_chk_fail@plt>
    9d60:      	bl	0x80b0 <_ZN13MTLReportTool9Interface7versionEv+0xc>

0000000000009d64 <_ZN13VLLogMediator14setLogCallbackERKNSt6__ndk18functionIFvRKNS0_6vectorI11vllog_entryNS0_9allocatorIS3_EEEEEEE>:
    9d64:      	stp	x29, x30, [sp, #-0x20]!
    9d68:      	stp	x20, x19, [sp, #0x10]
    9d6c:      	mov	x29, sp
    9d70:      	mov	x19, x0
    9d74:      	add	x0, x0, #0x60
    9d78:      	mov	x20, x1
    9d7c:      	bl	0x10b40 <_ZNSt6__ndk15mutex4lockEv@plt>
    9d80:      	add	x0, x19, #0x90
    9d84:      	mov	x1, x20
    9d88:      	bl	0x9db0 <_ZN13VLLogMediator14setLogCallbackERKNSt6__ndk18functionIFvRKNS0_6vectorI11vllog_entryNS0_9allocatorIS3_EEEEEEE+0x4c>
    9d8c:      	add	x0, x19, #0x60
    9d90:      	ldp	x20, x19, [sp, #0x10]
    9d94:      	ldp	x29, x30, [sp], #0x20
    9d98:      	b	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    9d9c:      	mov	x20, x0
    9da0:      	add	x0, x19, #0x60
    9da4:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    9da8:      	mov	x0, x20
    9dac:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    9db0:      	sub	sp, sp, #0x70
    9db4:      	stp	x29, x30, [sp, #0x40]
    9db8:      	str	x21, [sp, #0x50]
    9dbc:      	stp	x20, x19, [sp, #0x60]
    9dc0:      	add	x29, sp, #0x40
    9dc4:      	mrs	x20, TPIDR_EL0
    9dc8:      	mov	x19, x0
    9dcc:      	mov	x0, sp
    9dd0:      	ldr	x8, [x20, #0x28]
    9dd4:      	mov	x21, sp
    9dd8:      	stur	x8, [x29, #-0x8]
    9ddc:      	bl	0xad40 <_ZN13VLLogMediator8testDataEv+0x1dc>
    9de0:      	mov	x0, sp
    9de4:      	mov	x1, x19
    9de8:      	bl	0xada8 <_ZN13VLLogMediator8testDataEv+0x244>
    9dec:      	ldr	x0, [sp, #0x20]
    9df0:      	cmp	x0, x21
    9df4:      	b.eq	0x9e04 <_ZN13VLLogMediator14setLogCallbackERKNSt6__ndk18functionIFvRKNS0_6vectorI11vllog_entryNS0_9allocatorIS3_EEEEEEE+0xa0>
    9df8:      	cbz	x0, 0x9e18 <_ZN13VLLogMediator14setLogCallbackERKNSt6__ndk18functionIFvRKNS0_6vectorI11vllog_entryNS0_9allocatorIS3_EEEEEEE+0xb4>
    9dfc:      	mov	w8, #0x5                // =5
    9e00:      	b	0x9e0c <_ZN13VLLogMediator14setLogCallbackERKNSt6__ndk18functionIFvRKNS0_6vectorI11vllog_entryNS0_9allocatorIS3_EEEEEEE+0xa8>
    9e04:      	mov	w8, #0x4                // =4
    9e08:      	mov	x0, sp
    9e0c:      	ldr	x9, [x0]
    9e10:      	ldr	x8, [x9, x8, lsl #3]
    9e14:      	blr	x8
    9e18:      	ldr	x8, [x20, #0x28]
    9e1c:      	ldur	x9, [x29, #-0x8]
    9e20:      	cmp	x8, x9
    9e24:      	b.ne	0x9e40 <_ZN13VLLogMediator14setLogCallbackERKNSt6__ndk18functionIFvRKNS0_6vectorI11vllog_entryNS0_9allocatorIS3_EEEEEEE+0xdc>
    9e28:      	mov	x0, x19
    9e2c:      	ldp	x20, x19, [sp, #0x60]
    9e30:      	ldr	x21, [sp, #0x50]
    9e34:      	ldp	x29, x30, [sp, #0x40]
    9e38:      	add	sp, sp, #0x70
    9e3c:      	ret
    9e40:      	bl	0x10840 <__stack_chk_fail@plt>

0000000000009e44 <_ZN13VLLogMediator13setTagExcludeEPKci>:
    9e44:      	mov	x0, x1
    9e48:      	mov	w1, w2
    9e4c:      	b	0x10c40 <_Z26vlcollect_set_tag_excludedPKci@plt>

0000000000009e50 <_ZNK13VLLogMediator14getStateStringEv>:
    9e50:      	sub	sp, sp, #0x1c0
    9e54:      	stp	x29, x30, [sp, #0x180]
    9e58:      	str	x28, [sp, #0x190]
    9e5c:      	stp	x22, x21, [sp, #0x1a0]
    9e60:      	stp	x20, x19, [sp, #0x1b0]
    9e64:      	add	x29, sp, #0x180
    9e68:      	mrs	x21, TPIDR_EL0
    9e6c:      	mov	x19, x8
    9e70:      	mov	x20, x0
    9e74:      	ldr	x8, [x21, #0x28]
    9e78:      	add	x0, x0, #0x10
    9e7c:      	stur	x8, [x29, #-0x8]
    9e80:      	bl	0x10b40 <_ZNSt6__ndk15mutex4lockEv@plt>
    9e84:      	ldrb	w8, [x20, #0x10c]
    9e88:      	cbz	w8, 0x9ffc <_ZNK13VLLogMediator14getStateStringEv+0x1ac>
    9e8c:      	ldrb	w8, [x20, #0x10d]
    9e90:      	cbz	w8, 0x9ffc <_ZNK13VLLogMediator14getStateStringEv+0x1ac>
    9e94:      	add	x0, x20, #0x10
    9e98:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    9e9c:      	movi	v0.2d, #0000000000000000
    9ea0:      	stp	q0, q0, [sp, #0x20]
    9ea4:      	stp	q0, q0, [sp, #0x40]
    9ea8:      	add	x0, sp, #0x20
    9eac:      	bl	0x10c50 <_Z19vlcollect_get_stateP15vlcollect_state@plt>
    9eb0:      	add	x0, sp, #0x60
    9eb4:      	add	x20, sp, #0x60
    9eb8:      	bl	0x80c0 <_ZN13MTLReportTool9Interface7versionEv+0x1c>
    9ebc:      	adrp	x1, 0x4000
    9ec0:      	add	x1, x1, #0x554
    9ec4:      	add	x0, x20, #0x10
    9ec8:      	mov	w2, #0x27               // =39
    9ecc:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    9ed0:      	ldr	x1, [sp, #0x20]
    9ed4:      	bl	0x10c60 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEElsEm@plt>
    9ed8:      	adrp	x1, 0x4000
    9edc:      	add	x1, x1, #0x8df
    9ee0:      	mov	w2, #0x27               // =39
    9ee4:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    9ee8:      	ldr	x1, [sp, #0x28]
    9eec:      	bl	0x10c60 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEElsEm@plt>
    9ef0:      	adrp	x1, 0x4000
    9ef4:      	add	x1, x1, #0x9c7
    9ef8:      	mov	w2, #0x27               // =39
    9efc:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    9f00:      	ldr	x1, [sp, #0x30]
    9f04:      	bl	0x10c60 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEElsEm@plt>
    9f08:      	adrp	x1, 0x5000
    9f0c:      	add	x1, x1, #0x850
    9f10:      	mov	w2, #0x27               // =39
    9f14:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    9f18:      	ldr	x1, [sp, #0x38]
    9f1c:      	bl	0x10c60 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEElsEm@plt>
    9f20:      	adrp	x1, 0x5000
    9f24:      	add	x1, x1, #0x71f
    9f28:      	mov	w2, #0x3f               // =63
    9f2c:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    9f30:      	ldr	x1, [sp, #0x40]
    9f34:      	bl	0x10c60 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEElsEm@plt>
    9f38:      	adrp	x1, 0x4000
    9f3c:      	add	x1, x1, #0xcb9
    9f40:      	mov	w2, #0x4b               // =75
    9f44:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    9f48:      	ldr	x1, [sp, #0x48]
    9f4c:      	bl	0x10c60 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEElsEm@plt>
    9f50:      	add	x20, sp, #0x60
    9f54:      	add	x8, sp, #0x8
    9f58:      	add	x0, x20, #0x18
    9f5c:      	bl	0x108b0 <_ZNKSt6__ndk115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strEv@plt>
    9f60:      	adrp	x22, 0x15000
    9f64:      	ldr	x22, [x22, #0x1a0]
    9f68:      	ldr	x9, [sp, #0x18]
    9f6c:      	ldur	q0, [sp, #0x8]
    9f70:      	ldr	x8, [x22]
    9f74:      	ldp	x10, x11, [x22, #0x40]
    9f78:      	str	x9, [x19, #0x10]
    9f7c:      	str	x8, [sp, #0x60]
    9f80:      	ldur	x8, [x8, #-0x18]
    9f84:      	str	x10, [x20, x8]
    9f88:      	mov	w8, #0x1                // =1
    9f8c:      	strb	w8, [x19, #0x18]
    9f90:      	adrp	x8, 0x15000
    9f94:      	ldr	x8, [x8, #0x1a8]
    9f98:      	ldrb	w9, [sp, #0xb8]
    9f9c:      	str	q0, [x19]
    9fa0:      	add	x8, x8, #0x10
    9fa4:      	stp	x11, x8, [sp, #0x70]
    9fa8:      	tbz	w9, #0x0, 0x9fb4 <_ZNK13VLLogMediator14getStateStringEv+0x164>
    9fac:      	ldr	x0, [sp, #0xc8]
    9fb0:      	bl	0x10790 <_ZdlPv@plt>
    9fb4:      	add	x0, x20, #0x18
    9fb8:      	bl	0x108c0 <_ZNSt6__ndk115basic_streambufIcNS_11char_traitsIcEEED2Ev@plt>
    9fbc:      	add	x0, sp, #0x60
    9fc0:      	add	x1, x22, #0x8
    9fc4:      	add	x19, sp, #0x60
    9fc8:      	bl	0x108d0 <_ZNSt6__ndk114basic_iostreamIcNS_11char_traitsIcEEED2Ev@plt>
    9fcc:      	add	x0, x19, #0x80
    9fd0:      	bl	0x108e0 <_ZNSt6__ndk19basic_iosIcNS_11char_traitsIcEEED2Ev@plt>
    9fd4:      	ldr	x8, [x21, #0x28]
    9fd8:      	ldur	x9, [x29, #-0x8]
    9fdc:      	cmp	x8, x9
    9fe0:      	b.ne	0xa06c <_ZNK13VLLogMediator14getStateStringEv+0x21c>
    9fe4:      	ldp	x20, x19, [sp, #0x1b0]
    9fe8:      	ldr	x28, [sp, #0x190]
    9fec:      	ldp	x22, x21, [sp, #0x1a0]
    9ff0:      	ldp	x29, x30, [sp, #0x180]
    9ff4:      	add	sp, sp, #0x1c0
    9ff8:      	ret
    9ffc:      	strb	wzr, [x19]
    a000:      	strb	wzr, [x19, #0x18]
    a004:      	ldr	x8, [x21, #0x28]
    a008:      	ldur	x9, [x29, #-0x8]
    a00c:      	cmp	x8, x9
    a010:      	b.ne	0xa06c <_ZNK13VLLogMediator14getStateStringEv+0x21c>
    a014:      	add	x0, x20, #0x10
    a018:      	ldp	x20, x19, [sp, #0x1b0]
    a01c:      	ldr	x28, [sp, #0x190]
    a020:      	ldp	x22, x21, [sp, #0x1a0]
    a024:      	ldp	x29, x30, [sp, #0x180]
    a028:      	add	sp, sp, #0x1c0
    a02c:      	b	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    a030:      	b	0xa048 <_ZNK13VLLogMediator14getStateStringEv+0x1f8>
    a034:      	bl	0x10860 <__cxa_begin_catch@plt>
    a038:      	strb	wzr, [x19]
    a03c:      	strb	wzr, [x19, #0x18]
    a040:      	bl	0x10990 <__cxa_end_catch@plt>
    a044:      	b	0x9fd4 <_ZNK13VLLogMediator14getStateStringEv+0x184>
    a048:      	mov	x19, x0
    a04c:      	add	x0, sp, #0x60
    a050:      	bl	0x81e4 <_ZN13MTLReportTool9Interface7versionEv+0x140>
    a054:      	ldr	x8, [x21, #0x28]
    a058:      	ldur	x9, [x29, #-0x8]
    a05c:      	cmp	x8, x9
    a060:      	b.ne	0xa06c <_ZNK13VLLogMediator14getStateStringEv+0x21c>
    a064:      	mov	x0, x19
    a068:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    a06c:      	bl	0x10840 <__stack_chk_fail@plt>

000000000000a070 <_ZN13VLLogMediator17formatMessageSafeERK11vllog_entry>:
    a070:      	sub	sp, sp, #0x180
    a074:      	stp	x29, x30, [sp, #0x130]
    a078:      	stp	x28, x25, [sp, #0x140]
    a07c:      	stp	x24, x23, [sp, #0x150]
    a080:      	stp	x22, x21, [sp, #0x160]
    a084:      	stp	x20, x19, [sp, #0x170]
    a088:      	add	x29, sp, #0x130
    a08c:      	mrs	x23, TPIDR_EL0
    a090:      	mov	x20, x0
    a094:      	mov	x19, x8
    a098:      	ldr	x9, [x23, #0x28]
    a09c:      	add	x21, sp, #0x10
    a0a0:      	stur	x9, [x29, #-0x8]
    a0a4:      	ldr	w24, [x0, #0x10]
    a0a8:      	add	x0, sp, #0x10
    a0ac:      	bl	0x80c0 <_ZN13MTLReportTool9Interface7versionEv+0x1c>
    a0b0:      	mov	w8, #0x5b               // =91
    a0b4:      	strb	w8, [sp, #0xc]
    a0b8:      	add	x0, x21, #0x10
    a0bc:      	add	x1, sp, #0xc
    a0c0:      	mov	w2, #0x1                // =1
    a0c4:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    a0c8:      	ldr	x22, [x20, #0x18]
    a0cc:      	mov	x21, x0
    a0d0:      	mov	x0, x22
    a0d4:      	bl	0x10760 <strlen@plt>
    a0d8:      	mov	x2, x0
    a0dc:      	mov	x0, x21
    a0e0:      	mov	x1, x22
    a0e4:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    a0e8:      	mov	w8, #0x7c               // =124
    a0ec:      	strb	w8, [sp, #0xc]
    a0f0:      	add	x1, sp, #0xc
    a0f4:      	mov	w2, #0x1                // =1
    a0f8:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    a0fc:      	ldr	x1, [x20, #0x20]
    a100:      	bl	0x10c60 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEElsEm@plt>
    a104:      	mov	w8, #0x7c               // =124
    a108:      	strb	w8, [sp, #0xc]
    a10c:      	add	x1, sp, #0xc
    a110:      	mov	w2, #0x1                // =1
    a114:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    a118:      	ldr	x8, [x20]
    a11c:      	adrp	x25, 0x4000
    a120:      	add	x25, x25, #0xa82
    a124:      	mov	x21, x0
    a128:      	cmp	x8, #0x0
    a12c:      	csel	x22, x25, x8, eq
    a130:      	mov	x0, x22
    a134:      	bl	0x10760 <strlen@plt>
    a138:      	mov	x2, x0
    a13c:      	mov	x0, x21
    a140:      	mov	x1, x22
    a144:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    a148:      	mov	w8, #0x7c               // =124
    a14c:      	strb	w8, [sp, #0xc]
    a150:      	add	x1, sp, #0xc
    a154:      	mov	w2, #0x1                // =1
    a158:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    a15c:      	ldr	x8, [x20, #0x8]
    a160:      	mov	x21, x0
    a164:      	cmp	x8, #0x0
    a168:      	csel	x22, x25, x8, eq
    a16c:      	mov	x0, x22
    a170:      	bl	0x10760 <strlen@plt>
    a174:      	mov	x2, x0
    a178:      	mov	x0, x21
    a17c:      	mov	x1, x22
    a180:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    a184:      	mov	w8, #0x7c               // =124
    a188:      	strb	w8, [sp, #0xc]
    a18c:      	add	x1, sp, #0xc
    a190:      	mov	w2, #0x1                // =1
    a194:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    a198:      	sub	w8, w24, #0x7
    a19c:      	sub	w9, w24, #0x1
    a1a0:      	mov	x21, x0
    a1a4:      	cmn	w8, #0x6
    a1a8:      	csel	w8, wzr, w9, lo
    a1ac:      	nop
    a1b0:      	adr	x9, 0x14e78 <_ZTISt20bad_array_new_length+0x38>
    a1b4:      	ldr	x22, [x9, w8, sxtw #3]
    a1b8:      	mov	x0, x22
    a1bc:      	bl	0x10760 <strlen@plt>
    a1c0:      	mov	x2, x0
    a1c4:      	mov	x0, x21
    a1c8:      	mov	x1, x22
    a1cc:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    a1d0:      	adrp	x1, 0x4000
    a1d4:      	add	x1, x1, #0xe0e
    a1d8:      	mov	w2, #0x4                // =4
    a1dc:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    a1e0:      	ldr	x8, [x20, #0x28]
    a1e4:      	mov	x21, x0
    a1e8:      	cmp	x8, #0x0
    a1ec:      	csel	x20, x25, x8, eq
    a1f0:      	mov	x0, x20
    a1f4:      	bl	0x10760 <strlen@plt>
    a1f8:      	mov	x2, x0
    a1fc:      	mov	x0, x21
    a200:      	mov	x1, x20
    a204:      	bl	0x8264 <_ZN13MTLReportTool9Interface7versionEv+0x1c0>
    a208:      	add	x20, sp, #0x10
    a20c:      	add	x0, x20, #0x18
    a210:      	mov	x8, x19
    a214:      	bl	0x108b0 <_ZNKSt6__ndk115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strEv@plt>
    a218:      	adrp	x19, 0x15000
    a21c:      	ldr	x19, [x19, #0x1a0]
    a220:      	ldr	x8, [x19]
    a224:      	ldp	x9, x10, [x19, #0x40]
    a228:      	str	x8, [sp, #0x10]
    a22c:      	ldur	x8, [x8, #-0x18]
    a230:      	str	x9, [x20, x8]
    a234:      	adrp	x8, 0x15000
    a238:      	ldr	x8, [x8, #0x1a8]
    a23c:      	ldrb	w9, [sp, #0x68]
    a240:      	add	x8, x8, #0x10
    a244:      	stp	x10, x8, [sp, #0x20]
    a248:      	tbz	w9, #0x0, 0xa254 <_ZN13VLLogMediator17formatMessageSafeERK11vllog_entry+0x1e4>
    a24c:      	ldr	x0, [sp, #0x78]
    a250:      	bl	0x10790 <_ZdlPv@plt>
    a254:      	add	x0, x20, #0x18
    a258:      	bl	0x108c0 <_ZNSt6__ndk115basic_streambufIcNS_11char_traitsIcEEED2Ev@plt>
    a25c:      	add	x0, sp, #0x10
    a260:      	add	x1, x19, #0x8
    a264:      	add	x19, sp, #0x10
    a268:      	bl	0x108d0 <_ZNSt6__ndk114basic_iostreamIcNS_11char_traitsIcEEED2Ev@plt>
    a26c:      	add	x0, x19, #0x80
    a270:      	bl	0x108e0 <_ZNSt6__ndk19basic_iosIcNS_11char_traitsIcEEED2Ev@plt>
    a274:      	ldr	x8, [x23, #0x28]
    a278:      	ldur	x9, [x29, #-0x8]
    a27c:      	cmp	x8, x9
    a280:      	b.ne	0xa2c4 <_ZN13VLLogMediator17formatMessageSafeERK11vllog_entry+0x254>
    a284:      	ldp	x20, x19, [sp, #0x170]
    a288:      	ldp	x22, x21, [sp, #0x160]
    a28c:      	ldp	x24, x23, [sp, #0x150]
    a290:      	ldp	x28, x25, [sp, #0x140]
    a294:      	ldp	x29, x30, [sp, #0x130]
    a298:      	add	sp, sp, #0x180
    a29c:      	ret
    a2a0:      	mov	x19, x0
    a2a4:      	add	x0, sp, #0x10
    a2a8:      	bl	0x81e4 <_ZN13MTLReportTool9Interface7versionEv+0x140>
    a2ac:      	ldr	x8, [x23, #0x28]
    a2b0:      	ldur	x9, [x29, #-0x8]
    a2b4:      	cmp	x8, x9
    a2b8:      	b.ne	0xa2c4 <_ZN13VLLogMediator17formatMessageSafeERK11vllog_entry+0x254>
    a2bc:      	mov	x0, x19
    a2c0:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    a2c4:      	bl	0x10840 <__stack_chk_fail@plt>

000000000000a2c8 <_ZN13VLLogMediator15getVllogVersionEv>:
    a2c8:      	b	0x10c90 <_Z17vllog_get_versionv@plt>

000000000000a2cc <_ZN13VLLogMediator7runLoopEv>:
    a2cc:      	sub	sp, sp, #0x150
    a2d0:      	stp	x29, x30, [sp, #0xf0]
    a2d4:      	stp	x28, x27, [sp, #0x100]
    a2d8:      	stp	x26, x25, [sp, #0x110]
    a2dc:      	stp	x24, x23, [sp, #0x120]
    a2e0:      	stp	x22, x21, [sp, #0x130]
    a2e4:      	stp	x20, x19, [sp, #0x140]
    a2e8:      	add	x29, sp, #0xf0
    a2ec:      	mrs	x8, TPIDR_EL0
    a2f0:      	str	x8, [sp]
    a2f4:      	ldr	x8, [x8, #0x28]
    a2f8:      	stur	x8, [x29, #-0x18]
    a2fc:      	ldarb	w8, [x0]
    a300:      	tbnz	w8, #0x0, 0xa338 <_ZN13VLLogMediator7runLoopEv+0x6c>
    a304:      	ldr	x8, [sp]
    a308:      	ldr	x8, [x8, #0x28]
    a30c:      	ldur	x9, [x29, #-0x18]
    a310:      	cmp	x8, x9
    a314:      	b.ne	0xaa9c <_ZN13VLLogMediator7runLoopEv+0x7d0>
    a318:      	ldp	x20, x19, [sp, #0x140]
    a31c:      	ldp	x22, x21, [sp, #0x130]
    a320:      	ldp	x24, x23, [sp, #0x120]
    a324:      	ldp	x26, x25, [sp, #0x110]
    a328:      	ldp	x28, x27, [sp, #0x100]
    a32c:      	ldp	x29, x30, [sp, #0xf0]
    a330:      	add	sp, sp, #0x150
    a334:      	ret
    a338:      	mov	x25, #0x5555555555555555 // =6148914691236517205
    a33c:      	mov	x23, #-0x5555555555555556 // =-6148914691236517206
    a340:      	mov	x19, x0
    a344:      	movk	x25, #0x555, lsl #48
    a348:      	add	x8, x0, #0x38
    a34c:      	movk	x23, #0xaaab
    a350:      	mov	w27, #0x30              // =48
    a354:      	str	x8, [sp, #0x8]
    a358:      	ldr	x0, [sp, #0x8]
    a35c:      	mov	w8, #0x1                // =1
    a360:      	strb	w8, [sp, #0x68]
    a364:      	str	x0, [sp, #0x60]
    a368:      	bl	0x10b40 <_ZNSt6__ndk15mutex4lockEv@plt>
    a36c:      	bl	0x10a90 <_ZNSt6__ndk16chrono12steady_clock3nowEv@plt>
    a370:      	mov	x8, #0xf200             // =61952
    a374:      	movk	x8, #0x2a05, lsl #16
    a378:      	movk	x8, #0x1, lsl #32
    a37c:      	add	x20, x0, x8
    a380:      	add	x8, x19, #0x140
    a384:      	ldarb	w8, [x8]
    a388:      	tbnz	w8, #0x0, 0xa45c <_ZN13VLLogMediator7runLoopEv+0x190>
    a38c:      	ldarb	w8, [x19]
    a390:      	tbz	w8, #0x0, 0xa45c <_ZN13VLLogMediator7runLoopEv+0x190>
    a394:      	bl	0x10a90 <_ZNSt6__ndk16chrono12steady_clock3nowEv@plt>
    a398:      	cmp	x0, x20
    a39c:      	b.ge	0xa448 <_ZN13VLLogMediator7runLoopEv+0x17c>
    a3a0:      	bl	0x10a90 <_ZNSt6__ndk16chrono12steady_clock3nowEv@plt>
    a3a4:      	sub	x21, x20, x0
    a3a8:      	cmp	x21, #0x1
    a3ac:      	b.lt	0xa43c <_ZN13VLLogMediator7runLoopEv+0x170>
    a3b0:      	bl	0x10a90 <_ZNSt6__ndk16chrono12steady_clock3nowEv@plt>
    a3b4:      	bl	0x10cb0 <_ZNSt6__ndk16chrono12system_clock3nowEv@plt>
    a3b8:      	cbz	x0, 0xa3e4 <_ZN13VLLogMediator7runLoopEv+0x118>
    a3bc:      	cmp	x0, #0x1
    a3c0:      	b.lt	0xa3ec <_ZN13VLLogMediator7runLoopEv+0x120>
    a3c4:      	mov	x8, #0x53f7             // =21495
    a3c8:      	movk	x8, #0xa5e3, lsl #16
    a3cc:      	movk	x8, #0xc49b, lsl #32
    a3d0:      	movk	x8, #0x20, lsl #48
    a3d4:      	cmp	x0, x8
    a3d8:      	b.ls	0xa40c <_ZN13VLLogMediator7runLoopEv+0x140>
    a3dc:      	mov	x8, #0x7fffffffffffffff // =9223372036854775807
    a3e0:      	b	0xa414 <_ZN13VLLogMediator7runLoopEv+0x148>
    a3e4:      	mov	x8, xzr
    a3e8:      	b	0xa414 <_ZN13VLLogMediator7runLoopEv+0x148>
    a3ec:      	mov	x8, #0xac09             // =44041
    a3f0:      	movk	x8, #0x5a1c, lsl #16
    a3f4:      	movk	x8, #0x3b64, lsl #32
    a3f8:      	movk	x8, #0xffdf, lsl #48
    a3fc:      	cmp	x0, x8
    a400:      	b.hs	0xa40c <_ZN13VLLogMediator7runLoopEv+0x140>
    a404:      	mov	x8, #-0x8000000000000000 // =-9223372036854775808
    a408:      	b	0xa428 <_ZN13VLLogMediator7runLoopEv+0x15c>
    a40c:      	mov	w8, #0x3e8              // =1000
    a410:      	mul	x8, x0, x8
    a414:      	eor	x9, x21, #0x7fffffffffffffff
    a418:      	cmp	x8, x9
    a41c:      	b.le	0xa428 <_ZN13VLLogMediator7runLoopEv+0x15c>
    a420:      	mov	x2, #0x7fffffffffffffff // =9223372036854775807
    a424:      	b	0xa42c <_ZN13VLLogMediator7runLoopEv+0x160>
    a428:      	add	x2, x8, x21
    a42c:      	add	x0, x19, #0x110
    a430:      	add	x1, sp, #0x60
    a434:      	bl	0x10cc0 <_ZNSt6__ndk118condition_variable15__do_timed_waitERNS_11unique_lockINS_5mutexEEENS_6chrono10time_pointINS5_12system_clockENS5_8durationIxNS_5ratioILl1ELl1000000000EEEEEEE@plt>
    a438:      	bl	0x10a90 <_ZNSt6__ndk16chrono12steady_clock3nowEv@plt>
    a43c:      	bl	0x10a90 <_ZNSt6__ndk16chrono12steady_clock3nowEv@plt>
    a440:      	cmp	x0, x20
    a444:      	b.lt	0xa380 <_ZN13VLLogMediator7runLoopEv+0xb4>
    a448:      	add	x8, x19, #0x140
    a44c:      	ldarb	w8, [x8]
    a450:      	tbnz	w8, #0x0, 0xa45c <_ZN13VLLogMediator7runLoopEv+0x190>
    a454:      	ldarb	w8, [x19]
    a458:      	tbnz	w8, #0x0, 0xa474 <_ZN13VLLogMediator7runLoopEv+0x1a8>
    a45c:      	ldarb	w8, [x19]
    a460:      	tbnz	w8, #0x0, 0xa46c <_ZN13VLLogMediator7runLoopEv+0x1a0>
    a464:      	mov	w20, wzr
    a468:      	b	0xa478 <_ZN13VLLogMediator7runLoopEv+0x1ac>
    a46c:      	add	x8, x19, #0x140
    a470:      	stlrb	wzr, [x8]
    a474:      	mov	w20, #0x1               // =1
    a478:      	ldrb	w8, [sp, #0x68]
    a47c:      	cbz	w8, 0xa488 <_ZN13VLLogMediator7runLoopEv+0x1bc>
    a480:      	ldr	x0, [sp, #0x60]
    a484:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    a488:      	cbz	w20, 0xa304 <_ZN13VLLogMediator7runLoopEv+0x38>
    a48c:      	ldarb	w8, [x19]
    a490:      	tbz	w8, #0x0, 0xa304 <_ZN13VLLogMediator7runLoopEv+0x38>
    a494:      	bl	0x10a90 <_ZNSt6__ndk16chrono12steady_clock3nowEv@plt>
    a498:      	movi	v0.2d, #0000000000000000
    a49c:      	stp	q0, q0, [sp, #0x60]
    a4a0:      	stp	q0, q0, [sp, #0x80]
    a4a4:      	add	x0, sp, #0x60
    a4a8:      	bl	0x10c50 <_Z19vlcollect_get_stateP15vlcollect_state@plt>
    a4ac:      	ldr	x21, [sp, #0x78]
    a4b0:      	cmp	x21, #0x1
    a4b4:      	b.lt	0xa8c4 <_ZN13VLLogMediator7runLoopEv+0x5f8>
    a4b8:      	stp	xzr, xzr, [sp, #0x48]
    a4bc:      	str	xzr, [sp, #0x58]
    a4c0:      	add	x0, sp, #0x48
    a4c4:      	mov	x1, x21
    a4c8:      	bl	0xaaa0 <_ZN13VLLogMediator7runLoopEv+0x7d4>
    a4cc:      	mov	x20, xzr
    a4d0:      	ldarb	w8, [x19]
    a4d4:      	tbz	w8, #0x0, 0xa600 <_ZN13VLLogMediator7runLoopEv+0x334>
    a4d8:      	movi	v0.2d, #0000000000000000
    a4dc:      	sub	x8, x29, #0x50
    a4e0:      	stp	q0, q0, [x8, #0x10]
    a4e4:      	str	q0, [x8]
    a4e8:      	sub	x0, x29, #0x50
    a4ec:      	bl	0x10cd0 <_Z19vlcollect_get_entryP11vllog_entry@plt>
    a4f0:      	cmp	w0, #0x1
    a4f4:      	b.ne	0xa600 <_ZN13VLLogMediator7runLoopEv+0x334>
    a4f8:      	ldp	x9, x8, [sp, #0x50]
    a4fc:      	cmp	x9, x8
    a500:      	b.hs	0xa524 <_ZN13VLLogMediator7runLoopEv+0x258>
    a504:      	sub	x8, x29, #0x50
    a508:      	ldp	q2, q0, [x8, #0x10]
    a50c:      	ldr	q1, [x8]
    a510:      	add	x8, x9, #0x30
    a514:      	str	q1, [x9]
    a518:      	stp	q2, q0, [x9, #0x10]
    a51c:      	str	x8, [sp, #0x50]
    a520:      	b	0xa5f4 <_ZN13VLLogMediator7runLoopEv+0x328>
    a524:      	ldr	x0, [sp, #0x48]
    a528:      	sub	x10, x9, x0
    a52c:      	asr	x10, x10, #4
    a530:      	mul	x22, x10, x23
    a534:      	add	x10, x22, #0x1
    a538:      	cmp	x10, x25
    a53c:      	b.hi	0xaa24 <_ZN13VLLogMediator7runLoopEv+0x758>
    a540:      	sub	x8, x8, x0
    a544:      	asr	x8, x8, #4
    a548:      	mul	x8, x8, x23
    a54c:      	lsl	x11, x8, #1
    a550:      	cmp	x11, x10
    a554:      	csel	x10, x11, x10, hi
    a558:      	mov	x11, #-0x5555555555555556 // =-6148914691236517206
    a55c:      	movk	x11, #0x2aa, lsl #48
    a560:      	cmp	x8, x11
    a564:      	csel	x1, x10, x25, lo
    a568:      	cbz	x1, 0xa584 <_ZN13VLLogMediator7runLoopEv+0x2b8>
    a56c:      	add	x8, sp, #0x48
    a570:      	add	x0, x8, #0x10
    a574:      	bl	0xaf24 <_ZN13VLLogMediator8testDataEv+0x3c0>
    a578:      	mov	x8, x0
    a57c:      	ldp	x0, x9, [sp, #0x48]
    a580:      	b	0xa588 <_ZN13VLLogMediator7runLoopEv+0x2bc>
    a584:      	mov	x8, xzr
    a588:      	madd	x10, x22, x27, x8
    a58c:      	sub	x11, x29, #0x50
    a590:      	cmp	x9, x0
    a594:      	ldp	q1, q0, [x11, #0x10]
    a598:      	ldr	q2, [x11]
    a59c:      	stp	q1, q0, [x10, #0x10]
    a5a0:      	str	q2, [x10]
    a5a4:      	b.eq	0xa5d4 <_ZN13VLLogMediator7runLoopEv+0x308>
    a5a8:      	mov	x11, x10
    a5ac:      	ldp	q1, q0, [x9, #-0x20]
    a5b0:      	sub	x12, x11, #0x30
    a5b4:      	ldur	q2, [x9, #-0x30]
    a5b8:      	sub	x9, x9, #0x30
    a5bc:      	cmp	x9, x0
    a5c0:      	stp	q1, q0, [x11, #-0x20]
    a5c4:      	stur	q2, [x11, #-0x30]
    a5c8:      	mov	x11, x12
    a5cc:      	b.ne	0xa5ac <_ZN13VLLogMediator7runLoopEv+0x2e0>
    a5d0:      	b	0xa5d8 <_ZN13VLLogMediator7runLoopEv+0x30c>
    a5d4:      	mov	x12, x10
    a5d8:      	madd	x8, x1, x27, x8
    a5dc:      	add	x22, x10, #0x30
    a5e0:      	stp	x12, x22, [sp, #0x48]
    a5e4:      	str	x8, [sp, #0x58]
    a5e8:      	cbz	x0, 0xa5f0 <_ZN13VLLogMediator7runLoopEv+0x324>
    a5ec:      	bl	0x10790 <_ZdlPv@plt>
    a5f0:      	str	x22, [sp, #0x50]
    a5f4:      	add	x20, x20, #0x1
    a5f8:      	cmp	x20, x21
    a5fc:      	b.ne	0xa4d0 <_ZN13VLLogMediator7runLoopEv+0x204>
    a600:      	ldp	x0, x8, [sp, #0x48]
    a604:      	cmp	x0, x8
    a608:      	b.eq	0xa8b8 <_ZN13VLLogMediator7runLoopEv+0x5ec>
    a60c:      	ldr	x9, [sp, #0x78]
    a610:      	cmp	x9, #0x63
    a614:      	b.hi	0xa628 <_ZN13VLLogMediator7runLoopEv+0x35c>
    a618:      	sub	x8, x8, x0
    a61c:      	asr	x8, x8, #4
    a620:      	mul	x8, x8, x23
    a624:      	b	0xa62c <_ZN13VLLogMediator7runLoopEv+0x360>
    a628:      	mov	w8, #0x64               // =100
    a62c:      	mov	x20, xzr
    a630:      	str	x8, [sp, #0x10]
    a634:      	ldarb	w10, [x19]
    a638:      	ldp	x8, x9, [sp, #0x48]
    a63c:      	tbz	w10, #0x0, 0xa868 <_ZN13VLLogMediator7runLoopEv+0x59c>
    a640:      	sub	x8, x9, x8
    a644:      	neg	x9, x20
    a648:      	stp	xzr, xzr, [sp, #0x30]
    a64c:      	asr	x8, x8, #4
    a650:      	str	xzr, [sp, #0x40]
    a654:      	nop
    a658:      	madd	x8, x8, x23, x9
    a65c:      	ldr	x9, [sp, #0x10]
    a660:      	cmp	x8, x9
    a664:      	csel	x21, x8, x9, lo
    a668:      	add	x0, sp, #0x30
    a66c:      	mov	x1, x21
    a670:      	bl	0xaaa0 <_ZN13VLLogMediator7runLoopEv+0x7d4>
    a674:      	cbz	x21, 0xa788 <_ZN13VLLogMediator7runLoopEv+0x4bc>
    a678:      	ldr	x24, [sp, #0x38]
    a67c:      	mov	x22, xzr
    a680:      	ldr	x8, [sp, #0x48]
    a684:      	nop
    a688:      	madd	x8, x20, x27, x8
    a68c:      	madd	x26, x22, x27, x8
    a690:      	ldr	x8, [sp, #0x40]
    a694:      	cmp	x24, x8
    a698:      	b.hs	0xa6b0 <_ZN13VLLogMediator7runLoopEv+0x3e4>
    a69c:      	ldp	q1, q0, [x26, #0x10]
    a6a0:      	ldr	q2, [x26]
    a6a4:      	stp	q1, q0, [x24, #0x10]
    a6a8:      	str	q2, [x24], #0x30
    a6ac:      	b	0xa778 <_ZN13VLLogMediator7runLoopEv+0x4ac>
    a6b0:      	ldr	x0, [sp, #0x30]
    a6b4:      	sub	x9, x24, x0
    a6b8:      	asr	x9, x9, #4
    a6bc:      	mul	x28, x9, x23
    a6c0:      	add	x9, x28, #0x1
    a6c4:      	cmp	x9, x25
    a6c8:      	b.hi	0xa8d0 <_ZN13VLLogMediator7runLoopEv+0x604>
    a6cc:      	sub	x8, x8, x0
    a6d0:      	asr	x8, x8, #4
    a6d4:      	mul	x8, x8, x23
    a6d8:      	lsl	x10, x8, #1
    a6dc:      	cmp	x10, x9
    a6e0:      	csel	x9, x10, x9, hi
    a6e4:      	mov	x10, #-0x5555555555555556 // =-6148914691236517206
    a6e8:      	movk	x10, #0x2aa, lsl #48
    a6ec:      	cmp	x8, x10
    a6f0:      	csel	x1, x9, x25, lo
    a6f4:      	cbz	x1, 0xa710 <_ZN13VLLogMediator7runLoopEv+0x444>
    a6f8:      	add	x8, sp, #0x30
    a6fc:      	add	x0, x8, #0x10
    a700:      	bl	0xaf24 <_ZN13VLLogMediator8testDataEv+0x3c0>
    a704:      	mov	x8, x0
    a708:      	ldp	x0, x24, [sp, #0x30]
    a70c:      	b	0xa714 <_ZN13VLLogMediator7runLoopEv+0x448>
    a710:      	mov	x8, xzr
    a714:      	madd	x9, x28, x27, x8
    a718:      	ldp	q1, q0, [x26, #0x10]
    a71c:      	ldr	q2, [x26]
    a720:      	cmp	x24, x0
    a724:      	stp	q1, q0, [x9, #0x10]
    a728:      	str	q2, [x9]
    a72c:      	b.eq	0xa75c <_ZN13VLLogMediator7runLoopEv+0x490>
    a730:      	mov	x10, x9
    a734:      	ldp	q1, q0, [x24, #-0x20]
    a738:      	sub	x11, x10, #0x30
    a73c:      	ldur	q2, [x24, #-0x30]
    a740:      	sub	x24, x24, #0x30
    a744:      	cmp	x24, x0
    a748:      	stp	q1, q0, [x10, #-0x20]
    a74c:      	stur	q2, [x10, #-0x30]
    a750:      	mov	x10, x11
    a754:      	b.ne	0xa734 <_ZN13VLLogMediator7runLoopEv+0x468>
    a758:      	b	0xa760 <_ZN13VLLogMediator7runLoopEv+0x494>
    a75c:      	mov	x11, x9
    a760:      	madd	x8, x1, x27, x8
    a764:      	add	x24, x9, #0x30
    a768:      	stp	x11, x24, [sp, #0x30]
    a76c:      	str	x8, [sp, #0x40]
    a770:      	cbz	x0, 0xa778 <_ZN13VLLogMediator7runLoopEv+0x4ac>
    a774:      	bl	0x10790 <_ZdlPv@plt>
    a778:      	add	x22, x22, #0x1
    a77c:      	str	x24, [sp, #0x38]
    a780:      	cmp	x22, x21
    a784:      	b.ne	0xa680 <_ZN13VLLogMediator7runLoopEv+0x3b4>
    a788:      	stur	xzr, [x29, #-0x30]
    a78c:      	add	x0, x19, #0x60
    a790:      	bl	0x10b40 <_ZNSt6__ndk15mutex4lockEv@plt>
    a794:      	sub	x0, x29, #0x50
    a798:      	add	x1, x19, #0x90
    a79c:      	bl	0x9db0 <_ZN13VLLogMediator14setLogCallbackERKNSt6__ndk18functionIFvRKNS0_6vectorI11vllog_entryNS0_9allocatorIS3_EEEEEEE+0x4c>
    a7a0:      	add	x0, x19, #0x60
    a7a4:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    a7a8:      	ldur	x0, [x29, #-0x30]
    a7ac:      	cbz	x0, 0xa7f8 <_ZN13VLLogMediator7runLoopEv+0x52c>
    a7b0:      	ldr	x8, [x0]
    a7b4:      	ldr	x8, [x8, #0x30]
    a7b8:      	add	x1, sp, #0x30
    a7bc:      	blr	x8
    a7c0:      	ldp	x22, x24, [sp, #0x30]
    a7c4:      	cmp	x22, x24
    a7c8:      	b.eq	0xa7dc <_ZN13VLLogMediator7runLoopEv+0x510>
    a7cc:      	mov	x0, x22
    a7d0:      	bl	0x10ce0 <_Z20vlcollect_entry_freeP11vllog_entry@plt>
    a7d4:      	add	x22, x22, #0x30
    a7d8:      	b	0xa7c4 <_ZN13VLLogMediator7runLoopEv+0x4f8>
    a7dc:      	ldur	x0, [x29, #-0x30]
    a7e0:      	sub	x8, x29, #0x50
    a7e4:      	cmp	x0, x8
    a7e8:      	b.eq	0xa828 <_ZN13VLLogMediator7runLoopEv+0x55c>
    a7ec:      	cbz	x0, 0xa83c <_ZN13VLLogMediator7runLoopEv+0x570>
    a7f0:      	mov	w8, #0x5                // =5
    a7f4:      	b	0xa830 <_ZN13VLLogMediator7runLoopEv+0x564>
    a7f8:      	ldp	x22, x24, [sp, #0x30]
    a7fc:      	cmp	x22, x24
    a800:      	b.eq	0xa7c0 <_ZN13VLLogMediator7runLoopEv+0x4f4>
    a804:      	add	x8, sp, #0x18
    a808:      	mov	x0, x22
    a80c:      	bl	0x10c70 <_ZN13VLLogMediator17formatMessageSafeERK11vllog_entry@plt>
    a810:      	ldrb	w8, [sp, #0x18]
    a814:      	tbz	w8, #0x0, 0xa820 <_ZN13VLLogMediator7runLoopEv+0x554>
    a818:      	ldr	x0, [sp, #0x28]
    a81c:      	bl	0x10790 <_ZdlPv@plt>
    a820:      	add	x22, x22, #0x30
    a824:      	b	0xa7fc <_ZN13VLLogMediator7runLoopEv+0x530>
    a828:      	sub	x0, x29, #0x50
    a82c:      	mov	w8, #0x4                // =4
    a830:      	ldr	x9, [x0]
    a834:      	ldr	x8, [x9, x8, lsl #3]
    a838:      	blr	x8
    a83c:      	ldr	x0, [sp, #0x30]
    a840:      	cbz	x0, 0xa84c <_ZN13VLLogMediator7runLoopEv+0x580>
    a844:      	str	x0, [sp, #0x38]
    a848:      	bl	0x10790 <_ZdlPv@plt>
    a84c:      	ldp	x8, x9, [sp, #0x48]
    a850:      	add	x20, x21, x20
    a854:      	sub	x10, x9, x8
    a858:      	asr	x10, x10, #4
    a85c:      	mul	x10, x10, x23
    a860:      	cmp	x20, x10
    a864:      	b.lo	0xa634 <_ZN13VLLogMediator7runLoopEv+0x368>
    a868:      	sub	x9, x9, x8
    a86c:      	asr	x9, x9, #4
    a870:      	mul	x9, x9, x23
    a874:      	cmp	x20, x9
    a878:      	b.hs	0xa8b0 <_ZN13VLLogMediator7runLoopEv+0x5e4>
    a87c:      	add	x9, x20, x20, lsl #1
    a880:      	mov	x22, x20
    a884:      	lsl	x21, x9, #4
    a888:      	add	x0, x8, x21
    a88c:      	bl	0x10ce0 <_Z20vlcollect_entry_freeP11vllog_entry@plt>
    a890:      	ldp	x8, x9, [sp, #0x48]
    a894:      	add	x22, x22, #0x1
    a898:      	add	x21, x21, #0x30
    a89c:      	sub	x9, x9, x8
    a8a0:      	asr	x9, x9, #4
    a8a4:      	mul	x9, x9, x23
    a8a8:      	cmp	x22, x9
    a8ac:      	b.lo	0xa888 <_ZN13VLLogMediator7runLoopEv+0x5bc>
    a8b0:      	bl	0x10a90 <_ZNSt6__ndk16chrono12steady_clock3nowEv@plt>
    a8b4:      	ldr	x0, [sp, #0x48]
    a8b8:      	cbz	x0, 0xa8c4 <_ZN13VLLogMediator7runLoopEv+0x5f8>
    a8bc:      	str	x0, [sp, #0x50]
    a8c0:      	bl	0x10790 <_ZdlPv@plt>
    a8c4:      	ldarb	w8, [x19]
    a8c8:      	tbnz	w8, #0x0, 0xa358 <_ZN13VLLogMediator7runLoopEv+0x8c>
    a8cc:      	b	0xa304 <_ZN13VLLogMediator7runLoopEv+0x38>
    a8d0:      	ldr	x8, [sp]
    a8d4:      	ldr	x8, [x8, #0x28]
    a8d8:      	ldur	x9, [x29, #-0x18]
    a8dc:      	cmp	x8, x9
    a8e0:      	b.ne	0xaa9c <_ZN13VLLogMediator7runLoopEv+0x7d0>
    a8e4:      	add	x0, sp, #0x30
    a8e8:      	bl	0xaf10 <_ZN13VLLogMediator8testDataEv+0x3ac>
    a8ec:      	b	0xaa40 <_ZN13VLLogMediator7runLoopEv+0x774>
    a8f0:      	bl	0x10860 <__cxa_begin_catch@plt>
    a8f4:      	bl	0x10990 <__cxa_end_catch@plt>
    a8f8:      	b	0xa8c4 <_ZN13VLLogMediator7runLoopEv+0x5f8>
    a8fc:      	b	0xa93c <_ZN13VLLogMediator7runLoopEv+0x670>
    a900:      	mov	x22, x0
    a904:      	add	x0, x19, #0x60
    a908:      	mov	x21, x1
    a90c:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    a910:      	b	0xa944 <_ZN13VLLogMediator7runLoopEv+0x678>
    a914:      	b	0xa93c <_ZN13VLLogMediator7runLoopEv+0x670>
    a918:      	b	0xa930 <_ZN13VLLogMediator7runLoopEv+0x664>
    a91c:      	mov	x21, x1
    a920:      	mov	x22, x0
    a924:      	b	0xa984 <_ZN13VLLogMediator7runLoopEv+0x6b8>
    a928:      	b	0xa930 <_ZN13VLLogMediator7runLoopEv+0x664>
    a92c:      	b	0xa93c <_ZN13VLLogMediator7runLoopEv+0x670>
    a930:      	mov	x21, x1
    a934:      	mov	x22, x0
    a938:      	b	0xa974 <_ZN13VLLogMediator7runLoopEv+0x6a8>
    a93c:      	mov	x21, x1
    a940:      	mov	x22, x0
    a944:      	ldur	x0, [x29, #-0x30]
    a948:      	sub	x8, x29, #0x50
    a94c:      	cmp	x0, x8
    a950:      	b.eq	0xa960 <_ZN13VLLogMediator7runLoopEv+0x694>
    a954:      	cbz	x0, 0xa974 <_ZN13VLLogMediator7runLoopEv+0x6a8>
    a958:      	mov	w8, #0x5                // =5
    a95c:      	b	0xa968 <_ZN13VLLogMediator7runLoopEv+0x69c>
    a960:      	sub	x0, x29, #0x50
    a964:      	mov	w8, #0x4                // =4
    a968:      	ldr	x9, [x0]
    a96c:      	ldr	x8, [x9, x8, lsl #3]
    a970:      	blr	x8
    a974:      	ldr	x0, [sp, #0x30]
    a978:      	cbz	x0, 0xa984 <_ZN13VLLogMediator7runLoopEv+0x6b8>
    a97c:      	str	x0, [sp, #0x38]
    a980:      	bl	0x10790 <_ZdlPv@plt>
    a984:      	mov	x0, x22
    a988:      	bl	0x10860 <__cxa_begin_catch@plt>
    a98c:      	ldp	x8, x9, [sp, #0x48]
    a990:      	cmp	w21, #0x2
    a994:      	sub	x9, x9, x8
    a998:      	asr	x9, x9, #4
    a99c:      	mul	x9, x9, x23
    a9a0:      	b.ne	0xa9e4 <_ZN13VLLogMediator7runLoopEv+0x718>
    a9a4:      	cmp	x20, x9
    a9a8:      	b.hs	0xa9dc <_ZN13VLLogMediator7runLoopEv+0x710>
    a9ac:      	add	x9, x20, x20, lsl #1
    a9b0:      	lsl	x21, x9, #4
    a9b4:      	add	x0, x8, x21
    a9b8:      	bl	0x10ce0 <_Z20vlcollect_entry_freeP11vllog_entry@plt>
    a9bc:      	ldp	x8, x9, [sp, #0x48]
    a9c0:      	add	x20, x20, #0x1
    a9c4:      	add	x21, x21, #0x30
    a9c8:      	sub	x9, x9, x8
    a9cc:      	asr	x9, x9, #4
    a9d0:      	mul	x9, x9, x23
    a9d4:      	cmp	x20, x9
    a9d8:      	b.lo	0xa9b4 <_ZN13VLLogMediator7runLoopEv+0x6e8>
    a9dc:      	bl	0x10990 <__cxa_end_catch@plt>
    a9e0:      	b	0xa8b4 <_ZN13VLLogMediator7runLoopEv+0x5e8>
    a9e4:      	cmp	x20, x9
    a9e8:      	b.hs	0xaa1c <_ZN13VLLogMediator7runLoopEv+0x750>
    a9ec:      	add	x9, x20, x20, lsl #1
    a9f0:      	lsl	x21, x9, #4
    a9f4:      	add	x0, x8, x21
    a9f8:      	bl	0x10ce0 <_Z20vlcollect_entry_freeP11vllog_entry@plt>
    a9fc:      	ldp	x8, x9, [sp, #0x48]
    aa00:      	add	x20, x20, #0x1
    aa04:      	add	x21, x21, #0x30
    aa08:      	sub	x9, x9, x8
    aa0c:      	asr	x9, x9, #4
    aa10:      	mul	x9, x9, x23
    aa14:      	cmp	x20, x9
    aa18:      	b.lo	0xa9f4 <_ZN13VLLogMediator7runLoopEv+0x728>
    aa1c:      	bl	0x10990 <__cxa_end_catch@plt>
    aa20:      	b	0xa8b4 <_ZN13VLLogMediator7runLoopEv+0x5e8>
    aa24:      	ldr	x8, [sp]
    aa28:      	ldr	x8, [x8, #0x28]
    aa2c:      	ldur	x9, [x29, #-0x18]
    aa30:      	cmp	x8, x9
    aa34:      	b.ne	0xaa9c <_ZN13VLLogMediator7runLoopEv+0x7d0>
    aa38:      	add	x0, sp, #0x48
    aa3c:      	bl	0xaf10 <_ZN13VLLogMediator8testDataEv+0x3ac>
    aa40:      	b	0xaa6c <_ZN13VLLogMediator7runLoopEv+0x7a0>
    aa44:      	b	0xaa6c <_ZN13VLLogMediator7runLoopEv+0x7a0>
    aa48:      	mov	x19, x0
    aa4c:      	bl	0x10990 <__cxa_end_catch@plt>
    aa50:      	b	0xaa70 <_ZN13VLLogMediator7runLoopEv+0x7a4>
    aa54:      	mov	x19, x0
    aa58:      	bl	0x10990 <__cxa_end_catch@plt>
    aa5c:      	b	0xaa70 <_ZN13VLLogMediator7runLoopEv+0x7a4>
    aa60:      	bl	0x80b0 <_ZN13MTLReportTool9Interface7versionEv+0xc>
    aa64:      	b	0xaa6c <_ZN13VLLogMediator7runLoopEv+0x7a0>
    aa68:      	b	0xaa6c <_ZN13VLLogMediator7runLoopEv+0x7a0>
    aa6c:      	mov	x19, x0
    aa70:      	ldr	x0, [sp, #0x48]
    aa74:      	cbz	x0, 0xaa80 <_ZN13VLLogMediator7runLoopEv+0x7b4>
    aa78:      	str	x0, [sp, #0x50]
    aa7c:      	bl	0x10790 <_ZdlPv@plt>
    aa80:      	ldr	x8, [sp]
    aa84:      	ldr	x8, [x8, #0x28]
    aa88:      	ldur	x9, [x29, #-0x18]
    aa8c:      	cmp	x8, x9
    aa90:      	b.ne	0xaa9c <_ZN13VLLogMediator7runLoopEv+0x7d0>
    aa94:      	mov	x0, x19
    aa98:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    aa9c:      	bl	0x10840 <__stack_chk_fail@plt>
    aaa0:      	stp	x29, x30, [sp, #-0x20]!
    aaa4:      	stp	x20, x19, [sp, #0x10]
    aaa8:      	mov	x29, sp
    aaac:      	mov	x19, x0
    aab0:      	ldr	x9, [x0, #0x10]!
    aab4:      	ldr	x8, [x19]
    aab8:      	mov	x10, #-0x5555555555555556 // =-6148914691236517206
    aabc:      	movk	x10, #0xaaab
    aac0:      	sub	x9, x9, x8
    aac4:      	asr	x9, x9, #4
    aac8:      	mul	x9, x9, x10
    aacc:      	cmp	x9, x1
    aad0:      	b.hs	0xab50 <_ZN13VLLogMediator7runLoopEv+0x884>
    aad4:      	mov	x9, #0x5555555555555555 // =6148914691236517205
    aad8:      	movk	x9, #0x5556
    aadc:      	movk	x9, #0x555, lsl #48
    aae0:      	cmp	x1, x9
    aae4:      	b.hs	0xab5c <_ZN13VLLogMediator7runLoopEv+0x890>
    aae8:      	ldr	x9, [x19, #0x8]
    aaec:      	sub	x20, x9, x8
    aaf0:      	bl	0xaf24 <_ZN13VLLogMediator8testDataEv+0x3c0>
    aaf4:      	mov	w9, #0x30               // =48
    aaf8:      	mov	x8, x0
    aafc:      	madd	x9, x1, x9, x0
    ab00:      	ldp	x10, x0, [x19]
    ab04:      	add	x8, x8, x20
    ab08:      	mov	x11, x8
    ab0c:      	cmp	x0, x10
    ab10:      	b.eq	0xab38 <_ZN13VLLogMediator7runLoopEv+0x86c>
    ab14:      	ldp	q1, q0, [x0, #-0x20]
    ab18:      	ldur	q2, [x0, #-0x30]
    ab1c:      	sub	x0, x0, #0x30
    ab20:      	cmp	x0, x10
    ab24:      	stur	q2, [x11, #-0x30]
    ab28:      	stp	q1, q0, [x11, #-0x20]
    ab2c:      	sub	x11, x11, #0x30
    ab30:      	b.ne	0xab14 <_ZN13VLLogMediator7runLoopEv+0x848>
    ab34:      	ldr	x0, [x19]
    ab38:      	stp	x11, x8, [x19]
    ab3c:      	str	x9, [x19, #0x10]
    ab40:      	cbz	x0, 0xab50 <_ZN13VLLogMediator7runLoopEv+0x884>
    ab44:      	ldp	x20, x19, [sp, #0x10]
    ab48:      	ldp	x29, x30, [sp], #0x20
    ab4c:      	b	0x10790 <_ZdlPv@plt>
    ab50:      	ldp	x20, x19, [sp, #0x10]
    ab54:      	ldp	x29, x30, [sp], #0x20
    ab58:      	ret
    ab5c:      	mov	x0, x19
    ab60:      	bl	0xaf10 <_ZN13VLLogMediator8testDataEv+0x3ac>

000000000000ab64 <_ZN13VLLogMediator8testDataEv>:
    ab64:      	sub	sp, sp, #0x60
    ab68:      	stp	x29, x30, [sp, #0x10]
    ab6c:      	str	x25, [sp, #0x20]
    ab70:      	stp	x24, x23, [sp, #0x30]
    ab74:      	stp	x22, x21, [sp, #0x40]
    ab78:      	stp	x20, x19, [sp, #0x50]
    ab7c:      	add	x29, sp, #0x10
    ab80:      	mrs	x24, TPIDR_EL0
    ab84:      	mov	w25, #0x6500            // =25856
    ab88:      	mov	w19, wzr
    ab8c:      	ldr	x8, [x24, #0x28]
    ab90:      	adrp	x20, 0x5000
    ab94:      	add	x20, x20, #0x1cd
    ab98:      	adrp	x21, 0x4000
    ab9c:      	add	x21, x21, #0xf57
    aba0:      	adrp	x22, 0x5000
    aba4:      	add	x22, x22, #0x75f
    aba8:      	movk	w25, #0x1dcd, lsl #16
    abac:      	adrp	x23, 0x5000
    abb0:      	add	x23, x23, #0x932
    abb4:      	str	x8, [sp, #0x8]
    abb8:      	mov	w0, #0x1                // =1
    abbc:      	mov	x1, x20
    abc0:      	mov	x2, x21
    abc4:      	mov	x3, x22
    abc8:      	mov	w4, w19
    abcc:      	bl	0x10d00 <_Z15vllog_tag_print13vllog_level_tPKcS1_S1_z@plt>
    abd0:      	mov	x0, sp
    abd4:      	str	x25, [sp]
    abd8:      	bl	0x10d10 <_ZNSt6__ndk111this_thread9sleep_forERKNS_6chrono8durationIxNS_5ratioILl1ELl1000000000EEEEE@plt>
    abdc:      	mov	w0, #0x5                // =5
    abe0:      	mov	x1, x20
    abe4:      	mov	x2, x21
    abe8:      	mov	x3, x23
    abec:      	mov	w4, w19
    abf0:      	bl	0x10d00 <_Z15vllog_tag_print13vllog_level_tPKcS1_S1_z@plt>
    abf4:      	add	w19, w19, #0x1
    abf8:      	cmp	w19, #0x6
    abfc:      	b.ne	0xabb8 <_ZN13VLLogMediator8testDataEv+0x54>
    ac00:      	ldr	x8, [x24, #0x28]
    ac04:      	ldr	x9, [sp, #0x8]
    ac08:      	cmp	x8, x9
    ac0c:      	b.ne	0xac2c <_ZN13VLLogMediator8testDataEv+0xc8>
    ac10:      	ldp	x20, x19, [sp, #0x50]
    ac14:      	ldr	x25, [sp, #0x20]
    ac18:      	ldp	x22, x21, [sp, #0x40]
    ac1c:      	ldp	x24, x23, [sp, #0x30]
    ac20:      	ldp	x29, x30, [sp, #0x10]
    ac24:      	add	sp, sp, #0x60
    ac28:      	ret
    ac2c:      	bl	0x10840 <__stack_chk_fail@plt>
    ac30:      	sub	sp, sp, #0x30
    ac34:      	stp	x29, x30, [sp, #0x10]
    ac38:      	stp	x20, x19, [sp, #0x20]
    ac3c:      	add	x29, sp, #0x10
    ac40:      	mrs	x20, TPIDR_EL0
    ac44:      	mov	x19, x0
    ac48:      	ldr	x8, [x20, #0x28]
    ac4c:      	str	x8, [sp, #0x8]
    ac50:      	str	x0, [sp]
    ac54:      	bl	0x10d20 <_ZNSt6__ndk119__thread_local_dataEv@plt>
    ac58:      	ldr	x1, [x19]
    ac5c:      	ldr	w0, [x0]
    ac60:      	str	xzr, [x19]
    ac64:      	bl	0x10d30 <pthread_setspecific@plt>
    ac68:      	ldr	x0, [x19, #0x8]
    ac6c:      	bl	0x10ca0 <_ZN13VLLogMediator7runLoopEv@plt>
    ac70:      	mov	x0, sp
    ac74:      	bl	0xacc4 <_ZN13VLLogMediator8testDataEv+0x160>
    ac78:      	ldr	x8, [x20, #0x28]
    ac7c:      	ldr	x9, [sp, #0x8]
    ac80:      	cmp	x8, x9
    ac84:      	b.ne	0xacc0 <_ZN13VLLogMediator8testDataEv+0x15c>
    ac88:      	mov	x0, xzr
    ac8c:      	ldp	x20, x19, [sp, #0x20]
    ac90:      	ldp	x29, x30, [sp, #0x10]
    ac94:      	add	sp, sp, #0x30
    ac98:      	ret
    ac9c:      	mov	x19, x0
    aca0:      	mov	x0, sp
    aca4:      	bl	0xacc4 <_ZN13VLLogMediator8testDataEv+0x160>
    aca8:      	ldr	x8, [x20, #0x28]
    acac:      	ldr	x9, [sp, #0x8]
    acb0:      	cmp	x8, x9
    acb4:      	b.ne	0xacc0 <_ZN13VLLogMediator8testDataEv+0x15c>
    acb8:      	mov	x0, x19
    acbc:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    acc0:      	bl	0x10840 <__stack_chk_fail@plt>
    acc4:      	stp	x29, x30, [sp, #-0x20]!
    acc8:      	str	x19, [sp, #0x10]
    accc:      	mov	x29, sp
    acd0:      	ldr	x19, [x0]
    acd4:      	str	xzr, [x0]
    acd8:      	cbz	x19, 0xacf8 <_ZN13VLLogMediator8testDataEv+0x194>
    acdc:      	mov	x0, x19
    ace0:      	mov	x1, xzr
    ace4:      	bl	0xad04 <_ZN13VLLogMediator8testDataEv+0x1a0>
    ace8:      	mov	x0, x19
    acec:      	ldr	x19, [sp, #0x10]
    acf0:      	ldp	x29, x30, [sp], #0x20
    acf4:      	b	0x10790 <_ZdlPv@plt>
    acf8:      	ldr	x19, [sp, #0x10]
    acfc:      	ldp	x29, x30, [sp], #0x20
    ad00:      	ret
    ad04:      	stp	x29, x30, [sp, #-0x20]!
    ad08:      	str	x19, [sp, #0x10]
    ad0c:      	mov	x29, sp
    ad10:      	ldr	x19, [x0]
    ad14:      	str	x1, [x0]
    ad18:      	cbz	x19, 0xad34 <_ZN13VLLogMediator8testDataEv+0x1d0>
    ad1c:      	mov	x0, x19
    ad20:      	bl	0x10c00 <_ZNSt6__ndk115__thread_structD1Ev@plt>
    ad24:      	mov	x0, x19
    ad28:      	ldr	x19, [sp, #0x10]
    ad2c:      	ldp	x29, x30, [sp], #0x20
    ad30:      	b	0x10790 <_ZdlPv@plt>
    ad34:      	ldr	x19, [sp, #0x10]
    ad38:      	ldp	x29, x30, [sp], #0x20
    ad3c:      	ret
    ad40:      	stp	x29, x30, [sp, #-0x20]!
    ad44:      	str	x19, [sp, #0x10]
    ad48:      	mov	x29, sp
    ad4c:      	ldr	x8, [x1, #0x20]
    ad50:      	mov	x19, x0
    ad54:      	cbz	x8, 0xad78 <_ZN13VLLogMediator8testDataEv+0x214>
    ad58:      	cmp	x8, x1
    ad5c:      	b.eq	0xad88 <_ZN13VLLogMediator8testDataEv+0x224>
    ad60:      	ldr	x9, [x8]
    ad64:      	mov	x0, x8
    ad68:      	ldr	x9, [x9, #0x10]
    ad6c:      	blr	x9
    ad70:      	str	x0, [x19, #0x20]
    ad74:      	b	0xad7c <_ZN13VLLogMediator8testDataEv+0x218>
    ad78:      	str	xzr, [x19, #0x20]
    ad7c:      	ldr	x19, [sp, #0x10]
    ad80:      	ldp	x29, x30, [sp], #0x20
    ad84:      	ret
    ad88:      	str	x19, [x19, #0x20]
    ad8c:      	ldr	x0, [x1, #0x20]
    ad90:      	ldr	x8, [x0]
    ad94:      	ldr	x2, [x8, #0x18]
    ad98:      	mov	x1, x19
    ad9c:      	ldr	x19, [sp, #0x10]
    ada0:      	ldp	x29, x30, [sp], #0x20
    ada4:      	br	x2
    ada8:      	sub	sp, sp, #0x60
    adac:      	stp	x29, x30, [sp, #0x30]
    adb0:      	str	x21, [sp, #0x40]
    adb4:      	stp	x20, x19, [sp, #0x50]
    adb8:      	add	x29, sp, #0x30
    adbc:      	mrs	x21, TPIDR_EL0
    adc0:      	ldr	x8, [x21, #0x28]
    adc4:      	cmp	x1, x0
    adc8:      	stur	x8, [x29, #-0x8]
    adcc:      	b.eq	0xaee4 <_ZN13VLLogMediator8testDataEv+0x380>
    add0:      	ldr	x8, [x0, #0x20]
    add4:      	ldr	x9, [x1, #0x20]
    add8:      	mov	x19, x1
    addc:      	mov	x20, x0
    ade0:      	cmp	x8, x0
    ade4:      	b.eq	0xadfc <_ZN13VLLogMediator8testDataEv+0x298>
    ade8:      	cmp	x9, x19
    adec:      	b.eq	0xae34 <_ZN13VLLogMediator8testDataEv+0x2d0>
    adf0:      	str	x9, [x20, #0x20]
    adf4:      	str	x8, [x19, #0x20]
    adf8:      	b	0xaee4 <_ZN13VLLogMediator8testDataEv+0x380>
    adfc:      	cmp	x9, x19
    ae00:      	b.eq	0xae68 <_ZN13VLLogMediator8testDataEv+0x304>
    ae04:      	ldr	x8, [x20]
    ae08:      	ldr	x8, [x8, #0x18]
    ae0c:      	mov	x0, x20
    ae10:      	mov	x1, x19
    ae14:      	blr	x8
    ae18:      	ldr	x0, [x20, #0x20]
    ae1c:      	ldr	x8, [x0]
    ae20:      	ldr	x8, [x8, #0x20]
    ae24:      	blr	x8
    ae28:      	ldr	x8, [x19, #0x20]
    ae2c:      	str	x8, [x20, #0x20]
    ae30:      	b	0xaee0 <_ZN13VLLogMediator8testDataEv+0x37c>
    ae34:      	ldr	x8, [x19]
    ae38:      	ldr	x8, [x8, #0x18]
    ae3c:      	mov	x0, x19
    ae40:      	mov	x1, x20
    ae44:      	blr	x8
    ae48:      	ldr	x0, [x19, #0x20]
    ae4c:      	ldr	x8, [x0]
    ae50:      	ldr	x8, [x8, #0x20]
    ae54:      	blr	x8
    ae58:      	ldr	x8, [x20, #0x20]
    ae5c:      	str	x8, [x19, #0x20]
    ae60:      	str	x20, [x20, #0x20]
    ae64:      	b	0xaee4 <_ZN13VLLogMediator8testDataEv+0x380>
    ae68:      	ldr	x8, [x20]
    ae6c:      	ldr	x8, [x8, #0x18]
    ae70:      	mov	x1, sp
    ae74:      	mov	x0, x20
    ae78:      	blr	x8
    ae7c:      	ldr	x0, [x20, #0x20]
    ae80:      	ldr	x8, [x0]
    ae84:      	ldr	x8, [x8, #0x20]
    ae88:      	blr	x8
    ae8c:      	str	xzr, [x20, #0x20]
    ae90:      	ldr	x0, [x19, #0x20]
    ae94:      	ldr	x8, [x0]
    ae98:      	ldr	x8, [x8, #0x18]
    ae9c:      	mov	x1, x20
    aea0:      	blr	x8
    aea4:      	ldr	x0, [x19, #0x20]
    aea8:      	ldr	x8, [x0]
    aeac:      	ldr	x8, [x8, #0x20]
    aeb0:      	blr	x8
    aeb4:      	ldr	x8, [sp]
    aeb8:      	str	xzr, [x19, #0x20]
    aebc:      	str	x20, [x20, #0x20]
    aec0:      	ldr	x8, [x8, #0x18]
    aec4:      	mov	x0, sp
    aec8:      	mov	x1, x19
    aecc:      	blr	x8
    aed0:      	ldr	x8, [sp]
    aed4:      	mov	x0, sp
    aed8:      	ldr	x8, [x8, #0x20]
    aedc:      	blr	x8
    aee0:      	str	x19, [x19, #0x20]
    aee4:      	ldr	x8, [x21, #0x28]
    aee8:      	ldur	x9, [x29, #-0x8]
    aeec:      	cmp	x8, x9
    aef0:      	b.ne	0xaf08 <_ZN13VLLogMediator8testDataEv+0x3a4>
    aef4:      	ldp	x20, x19, [sp, #0x50]
    aef8:      	ldr	x21, [sp, #0x40]
    aefc:      	ldp	x29, x30, [sp, #0x30]
    af00:      	add	sp, sp, #0x60
    af04:      	ret
    af08:      	bl	0x10840 <__stack_chk_fail@plt>
    af0c:      	bl	0x80b0 <_ZN13MTLReportTool9Interface7versionEv+0xc>
    af10:      	stp	x29, x30, [sp, #-0x10]!
    af14:      	mov	x29, sp
    af18:      	adrp	x0, 0x5000
    af1c:      	add	x0, x0, #0x4ea
    af20:      	bl	0x7ec0 <.text+0x130>
    af24:      	stp	x29, x30, [sp, #-0x20]!
    af28:      	str	x19, [sp, #0x10]
    af2c:      	mov	x29, sp
    af30:      	mov	x8, #0x5555555555555555 // =6148914691236517205
    af34:      	movk	x8, #0x5556
    af38:      	movk	x8, #0x555, lsl #48
    af3c:      	cmp	x1, x8
    af40:      	b.hs	0xaf64 <_ZN13VLLogMediator8testDataEv+0x400>
    af44:      	add	x8, x1, x1, lsl #1
    af48:      	mov	x19, x1
    af4c:      	lsl	x0, x8, #4
    af50:      	bl	0x10770 <_Znwm@plt>
    af54:      	mov	x1, x19
    af58:      	ldr	x19, [sp, #0x10]
    af5c:      	ldp	x29, x30, [sp], #0x20
    af60:      	ret
    af64:      	bl	0x8c98 <_ZN13MTLReportTool9Interface7versionEv+0xbf4>
    af68:      	stp	x29, x30, [sp, #-0x20]!
    af6c:      	str	x19, [sp, #0x10]
    af70:      	mov	x29, sp
    af74:      	nop
    af78:      	adr	x19, 0x196d0
    af7c:      	nop
    af80:      	adr	x1, 0x46c3
    af84:      	mov	x0, x19
    af88:      	bl	0x7df0 <.text+0x60>
    af8c:      	adrp	x0, 0x15000
    af90:      	nop
    af94:      	adr	x2, 0x14de0
    af98:      	ldr	x0, [x0, #0x198]
    af9c:      	mov	x1, x19
    afa0:      	ldr	x19, [sp, #0x10]
    afa4:      	ldp	x29, x30, [sp], #0x20
    afa8:      	b	0x10740 <__cxa_atexit@plt>
    afac:      	stp	x29, x30, [sp, #-0x20]!
    afb0:      	stp	x20, x19, [sp, #0x10]
    afb4:      	mov	x29, sp
    afb8:      	ldr	x8, [x0]
    afbc:      	nop
    afc0:      	adr	x1, 0x4ed8
    afc4:      	mov	x19, x0
    afc8:      	ldr	x8, [x8, #0x30]
    afcc:      	blr	x8
    afd0:      	cbz	x0, 0xb038 <_ZN13VLLogMediator8testDataEv+0x4d4>
    afd4:      	ldr	x8, [x19]
    afd8:      	mov	x20, x0
    afdc:      	nop
    afe0:      	adr	x2, 0x19568
    afe4:      	mov	x0, x19
    afe8:      	mov	x1, x20
    afec:      	ldr	x8, [x8, #0x6b8]
    aff0:      	mov	w3, #0xa                // =10
    aff4:      	blr	x8
    aff8:      	tbnz	w0, #0x1f, 0xb04c <_ZN13VLLogMediator8testDataEv+0x4e8>
    affc:      	ldr	x8, [x19]
    b000:      	mov	x0, x19
    b004:      	mov	x1, x20
    b008:      	ldr	x8, [x8, #0xb8]
    b00c:      	blr	x8
    b010:      	adrp	x1, 0x4000
    b014:      	add	x1, x1, #0xc53
    b018:      	adrp	x2, 0x4000
    b01c:      	add	x2, x2, #0x819
    b020:      	nop
    b024:      	adr	x3, 0x4ed8
    b028:      	mov	w0, #0x3                // =3
    b02c:      	bl	0x10d40 <__android_log_print@plt>
    b030:      	mov	w0, wzr
    b034:      	b	0xb070 <_ZN13VLLogMediator8testDataEv+0x50c>
    b038:      	adrp	x1, 0x4000
    b03c:      	add	x1, x1, #0xc53
    b040:      	adrp	x2, 0x5000
    b044:      	add	x2, x2, #0x2cf
    b048:      	b	0xb05c <_ZN13VLLogMediator8testDataEv+0x4f8>
    b04c:      	adrp	x1, 0x4000
    b050:      	add	x1, x1, #0xc53
    b054:      	adrp	x2, 0x4000
    b058:      	add	x2, x2, #0xf63
    b05c:      	nop
    b060:      	adr	x3, 0x4ed8
    b064:      	mov	w0, #0x6                // =6
    b068:      	bl	0x10d40 <__android_log_print@plt>
    b06c:      	mov	w0, #-0x1               // =-1
    b070:      	ldp	x20, x19, [sp, #0x10]
    b074:      	ldp	x29, x30, [sp], #0x20
    b078:      	ret
    b07c:      	stp	x29, x30, [sp, #-0x20]!
    b080:      	stp	x20, x19, [sp, #0x10]
    b084:      	mov	x29, sp
    b088:      	mov	w0, #0x8                // =8
    b08c:      	bl	0x10770 <_Znwm@plt>
    b090:      	mov	x19, x0
    b094:      	bl	0x10820 <_ZN13MTLReportTool9InterfaceC1Ev@plt>
    b098:      	mov	x0, x19
    b09c:      	ldp	x20, x19, [sp, #0x10]
    b0a0:      	ldp	x29, x30, [sp], #0x20
    b0a4:      	ret
    b0a8:      	mov	x20, x0
    b0ac:      	mov	x0, x19
    b0b0:      	bl	0x10790 <_ZdlPv@plt>
    b0b4:      	mov	x0, x20
    b0b8:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    b0bc:      	cbz	x2, 0xb0e8 <_ZN13VLLogMediator8testDataEv+0x584>
    b0c0:      	stp	x29, x30, [sp, #-0x20]!
    b0c4:      	str	x19, [sp, #0x10]
    b0c8:      	mov	x29, sp
    b0cc:      	mov	x0, x2
    b0d0:      	mov	x19, x2
    b0d4:      	bl	0x10830 <_ZN13MTLReportTool9InterfaceD1Ev@plt>
    b0d8:      	mov	x0, x19
    b0dc:      	ldr	x19, [sp, #0x10]
    b0e0:      	ldp	x29, x30, [sp], #0x20
    b0e4:      	b	0x10790 <_ZdlPv@plt>
    b0e8:      	ret
    b0ec:      	stp	x29, x30, [sp, #-0x20]!
    b0f0:      	str	x19, [sp, #0x10]
    b0f4:      	mov	x29, sp
    b0f8:      	mov	x19, x0
    b0fc:      	bl	0x10810 <_ZN13MTLReportTool9Interface7versionEv@plt>
    b100:      	ldr	x8, [x19]
    b104:      	mov	x1, x0
    b108:      	ldr	x2, [x8, #0x538]
    b10c:      	mov	x0, x19
    b110:      	ldr	x19, [sp, #0x10]
    b114:      	ldp	x29, x30, [sp], #0x20
    b118:      	br	x2
    b11c:      	sub	sp, sp, #0x50
    b120:      	stp	x29, x30, [sp, #0x20]
    b124:      	stp	x22, x21, [sp, #0x30]
    b128:      	stp	x20, x19, [sp, #0x40]
    b12c:      	add	x29, sp, #0x20
    b130:      	mrs	x22, TPIDR_EL0
    b134:      	mov	x1, x2
    b138:      	mov	x19, x0
    b13c:      	ldr	x8, [x22, #0x28]
    b140:      	stur	x8, [x29, #-0x8]
    b144:      	mov	x8, sp
    b148:      	mov	x20, sp
    b14c:      	bl	0xbc70 <_ZN13VLLogMediator8testDataEv+0x110c>
    b150:      	ldrb	w8, [sp]
    b154:      	ldr	x9, [sp, #0x10]
    b158:      	orr	x10, x20, #0x1
    b15c:      	tst	w8, #0x1
    b160:      	csel	x3, x10, x9, eq
    b164:      	adrp	x1, 0x4000
    b168:      	add	x1, x1, #0xc53
    b16c:      	adrp	x2, 0x5000
    b170:      	add	x2, x2, #0x33d
    b174:      	mov	w0, #0x3                // =3
    b178:      	bl	0x10d40 <__android_log_print@plt>
    b17c:      	bl	0x10ad0 <_ZN13VLLogMediator11getInstanceEv@plt>
    b180:      	mov	x1, sp
    b184:      	bl	0x10b90 <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE@plt>
    b188:      	adrp	x1, 0x4000
    b18c:      	add	x1, x1, #0xc53
    b190:      	adrp	x2, 0x5000
    b194:      	add	x2, x2, #0x2e8
    b198:      	mov	w0, #0x3                // =3
    b19c:      	bl	0x10d40 <__android_log_print@plt>
    b1a0:      	ldrb	w8, [sp]
    b1a4:      	tbz	w8, #0x0, 0xb1b0 <_ZN13VLLogMediator8testDataEv+0x64c>
    b1a8:      	ldr	x0, [sp, #0x10]
    b1ac:      	bl	0x10790 <_ZdlPv@plt>
    b1b0:      	ldr	x8, [x22, #0x28]
    b1b4:      	ldur	x9, [x29, #-0x8]
    b1b8:      	cmp	x8, x9
    b1bc:      	b.ne	0xb2a0 <_ZN13VLLogMediator8testDataEv+0x73c>
    b1c0:      	ldp	x20, x19, [sp, #0x40]
    b1c4:      	ldp	x22, x21, [sp, #0x30]
    b1c8:      	ldp	x29, x30, [sp, #0x20]
    b1cc:      	add	sp, sp, #0x50
    b1d0:      	ret
    b1d4:      	mov	x21, x1
    b1d8:      	mov	x20, x0
    b1dc:      	b	0xb1f8 <_ZN13VLLogMediator8testDataEv+0x694>
    b1e0:      	ldrb	w8, [sp]
    b1e4:      	mov	x21, x1
    b1e8:      	mov	x20, x0
    b1ec:      	tbz	w8, #0x0, 0xb1f8 <_ZN13VLLogMediator8testDataEv+0x694>
    b1f0:      	ldr	x0, [sp, #0x10]
    b1f4:      	bl	0x10790 <_ZdlPv@plt>
    b1f8:      	cmp	w21, #0x1
    b1fc:      	b.ne	0xb288 <_ZN13VLLogMediator8testDataEv+0x724>
    b200:      	mov	x0, x20
    b204:      	bl	0x10860 <__cxa_begin_catch@plt>
    b208:      	ldr	x8, [x0]
    b20c:      	mov	x20, x0
    b210:      	ldr	x8, [x8, #0x10]
    b214:      	blr	x8
    b218:      	mov	x3, x0
    b21c:      	adrp	x1, 0x4000
    b220:      	add	x1, x1, #0xc53
    b224:      	adrp	x2, 0x5000
    b228:      	add	x2, x2, #0x895
    b22c:      	mov	w0, #0x6                // =6
    b230:      	bl	0x10d40 <__android_log_print@plt>
    b234:      	ldr	x8, [x19]
    b238:      	ldr	x8, [x8, #0x30]
    b23c:      	adrp	x1, 0x5000
    b240:      	add	x1, x1, #0x11c
    b244:      	mov	x0, x19
    b248:      	blr	x8
    b24c:      	ldr	x8, [x20]
    b250:      	mov	x21, x0
    b254:      	mov	x0, x20
    b258:      	ldr	x8, [x8, #0x10]
    b25c:      	blr	x8
    b260:      	ldr	x8, [x19]
    b264:      	mov	x2, x0
    b268:      	ldr	x8, [x8, #0x70]
    b26c:      	mov	x0, x19
    b270:      	mov	x1, x21
    b274:      	blr	x8
    b278:      	bl	0x10990 <__cxa_end_catch@plt>
    b27c:      	b	0xb1b0 <_ZN13VLLogMediator8testDataEv+0x64c>
    b280:      	mov	x20, x0
    b284:      	bl	0x10990 <__cxa_end_catch@plt>
    b288:      	ldr	x8, [x22, #0x28]
    b28c:      	ldur	x9, [x29, #-0x8]
    b290:      	cmp	x8, x9
    b294:      	b.ne	0xb2a0 <_ZN13VLLogMediator8testDataEv+0x73c>
    b298:      	mov	x0, x20
    b29c:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    b2a0:      	bl	0x10840 <__stack_chk_fail@plt>
    b2a4:      	bl	0x80b0 <_ZN13MTLReportTool9Interface7versionEv+0xc>
    b2a8:      	sub	sp, sp, #0x50
    b2ac:      	stp	x29, x30, [sp, #0x20]
    b2b0:      	stp	x22, x21, [sp, #0x30]
    b2b4:      	stp	x20, x19, [sp, #0x40]
    b2b8:      	add	x29, sp, #0x20
    b2bc:      	mrs	x22, TPIDR_EL0
    b2c0:      	mov	x1, x2
    b2c4:      	mov	x19, x0
    b2c8:      	ldr	x8, [x22, #0x28]
    b2cc:      	stur	x8, [x29, #-0x8]
    b2d0:      	mov	x8, sp
    b2d4:      	mov	x20, sp
    b2d8:      	bl	0xbc70 <_ZN13VLLogMediator8testDataEv+0x110c>
    b2dc:      	ldrb	w8, [sp]
    b2e0:      	ldr	x9, [sp, #0x10]
    b2e4:      	orr	x10, x20, #0x1
    b2e8:      	tst	w8, #0x1
    b2ec:      	csel	x3, x10, x9, eq
    b2f0:      	adrp	x1, 0x4000
    b2f4:      	add	x1, x1, #0xc53
    b2f8:      	adrp	x2, 0x4000
    b2fc:      	add	x2, x2, #0x607
    b300:      	mov	w0, #0x3                // =3
    b304:      	bl	0x10d40 <__android_log_print@plt>
    b308:      	bl	0x10ad0 <_ZN13VLLogMediator11getInstanceEv@plt>
    b30c:      	mov	x1, sp
    b310:      	bl	0x10bb0 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE@plt>
    b314:      	adrp	x1, 0x4000
    b318:      	add	x1, x1, #0xc53
    b31c:      	adrp	x2, 0x5000
    b320:      	add	x2, x2, #0x3e
    b324:      	mov	w0, #0x3                // =3
    b328:      	bl	0x10d40 <__android_log_print@plt>
    b32c:      	ldrb	w8, [sp]
    b330:      	tbz	w8, #0x0, 0xb33c <_ZN13VLLogMediator8testDataEv+0x7d8>
    b334:      	ldr	x0, [sp, #0x10]
    b338:      	bl	0x10790 <_ZdlPv@plt>
    b33c:      	ldr	x8, [x22, #0x28]
    b340:      	ldur	x9, [x29, #-0x8]
    b344:      	cmp	x8, x9
    b348:      	b.ne	0xb42c <_ZN13VLLogMediator8testDataEv+0x8c8>
    b34c:      	ldp	x20, x19, [sp, #0x40]
    b350:      	ldp	x22, x21, [sp, #0x30]
    b354:      	ldp	x29, x30, [sp, #0x20]
    b358:      	add	sp, sp, #0x50
    b35c:      	ret
    b360:      	mov	x21, x1
    b364:      	mov	x20, x0
    b368:      	b	0xb384 <_ZN13VLLogMediator8testDataEv+0x820>
    b36c:      	ldrb	w8, [sp]
    b370:      	mov	x21, x1
    b374:      	mov	x20, x0
    b378:      	tbz	w8, #0x0, 0xb384 <_ZN13VLLogMediator8testDataEv+0x820>
    b37c:      	ldr	x0, [sp, #0x10]
    b380:      	bl	0x10790 <_ZdlPv@plt>
    b384:      	cmp	w21, #0x1
    b388:      	b.ne	0xb414 <_ZN13VLLogMediator8testDataEv+0x8b0>
    b38c:      	mov	x0, x20
    b390:      	bl	0x10860 <__cxa_begin_catch@plt>
    b394:      	ldr	x8, [x0]
    b398:      	mov	x20, x0
    b39c:      	ldr	x8, [x8, #0x10]
    b3a0:      	blr	x8
    b3a4:      	mov	x3, x0
    b3a8:      	adrp	x1, 0x4000
    b3ac:      	add	x1, x1, #0xc53
    b3b0:      	adrp	x2, 0x5000
    b3b4:      	add	x2, x2, #0x4f7
    b3b8:      	mov	w0, #0x6                // =6
    b3bc:      	bl	0x10d40 <__android_log_print@plt>
    b3c0:      	ldr	x8, [x19]
    b3c4:      	ldr	x8, [x8, #0x30]
    b3c8:      	adrp	x1, 0x5000
    b3cc:      	add	x1, x1, #0x11c
    b3d0:      	mov	x0, x19
    b3d4:      	blr	x8
    b3d8:      	ldr	x8, [x20]
    b3dc:      	mov	x21, x0
    b3e0:      	mov	x0, x20
    b3e4:      	ldr	x8, [x8, #0x10]
    b3e8:      	blr	x8
    b3ec:      	ldr	x8, [x19]
    b3f0:      	mov	x2, x0
    b3f4:      	ldr	x8, [x8, #0x70]
    b3f8:      	mov	x0, x19
    b3fc:      	mov	x1, x21
    b400:      	blr	x8
    b404:      	bl	0x10990 <__cxa_end_catch@plt>
    b408:      	b	0xb33c <_ZN13VLLogMediator8testDataEv+0x7d8>
    b40c:      	mov	x20, x0
    b410:      	bl	0x10990 <__cxa_end_catch@plt>
    b414:      	ldr	x8, [x22, #0x28]
    b418:      	ldur	x9, [x29, #-0x8]
    b41c:      	cmp	x8, x9
    b420:      	b.ne	0xb42c <_ZN13VLLogMediator8testDataEv+0x8c8>
    b424:      	mov	x0, x20
    b428:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    b42c:      	bl	0x10840 <__stack_chk_fail@plt>
    b430:      	bl	0x80b0 <_ZN13MTLReportTool9Interface7versionEv+0xc>
    b434:      	sub	sp, sp, #0x80
    b438:      	stp	x29, x30, [sp, #0x40]
    b43c:      	str	x23, [sp, #0x50]
    b440:      	stp	x22, x21, [sp, #0x60]
    b444:      	stp	x20, x19, [sp, #0x70]
    b448:      	add	x29, sp, #0x40
    b44c:      	mrs	x22, TPIDR_EL0
    b450:      	mov	x20, x2
    b454:      	mov	x19, x0
    b458:      	ldr	x8, [x22, #0x28]
    b45c:      	stur	x8, [x29, #-0x8]
    b460:      	adrp	x1, 0x4000
    b464:      	add	x1, x1, #0xc53
    b468:      	adrp	x2, 0x5000
    b46c:      	add	x2, x2, #0x360
    b470:      	mov	w0, #0x3                // =3
    b474:      	bl	0x10d40 <__android_log_print@plt>
    b478:      	cbz	x20, 0xb5a8 <_ZN13VLLogMediator8testDataEv+0xa44>
    b47c:      	nop
    b480:      	adr	x0, 0x19870
    b484:      	bl	0x10b40 <_ZNSt6__ndk15mutex4lockEv@plt>
    b488:      	adrp	x23, 0x19000
    b48c:      	ldr	x8, [x23, #0x898]
    b490:      	cbnz	x8, 0xb4f8 <_ZN13VLLogMediator8testDataEv+0x994>
    b494:      	ldr	x8, [x19]
    b498:      	ldr	x8, [x8, #0x30]
    b49c:      	adrp	x1, 0x4000
    b4a0:      	add	x1, x1, #0x9ff
    b4a4:      	mov	x0, x19
    b4a8:      	blr	x8
    b4ac:      	mov	x21, x0
    b4b0:      	cbz	x0, 0xb628 <_ZN13VLLogMediator8testDataEv+0xac4>
    b4b4:      	ldr	x8, [x19]
    b4b8:      	ldr	x8, [x8, #0xa8]
    b4bc:      	mov	x0, x19
    b4c0:      	mov	x1, x21
    b4c4:      	blr	x8
    b4c8:      	str	x0, [x23, #0x898]
    b4cc:      	ldr	x8, [x19]
    b4d0:      	ldr	x8, [x8, #0xb8]
    b4d4:      	mov	x0, x19
    b4d8:      	mov	x1, x21
    b4dc:      	blr	x8
    b4e0:      	adrp	x1, 0x4000
    b4e4:      	add	x1, x1, #0xc53
    b4e8:      	adrp	x2, 0x4000
    b4ec:      	add	x2, x2, #0xf97
    b4f0:      	mov	w0, #0x3                // =3
    b4f4:      	bl	0x10d40 <__android_log_print@plt>
    b4f8:      	nop
    b4fc:      	adr	x0, 0x19870
    b500:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    b504:      	ldr	x8, [x19]
    b508:      	ldr	x8, [x8, #0xa8]
    b50c:      	mov	x0, x19
    b510:      	mov	x1, x20
    b514:      	blr	x8
    b518:      	mov	x20, x0
    b51c:      	cbz	x0, 0xb5c4 <_ZN13VLLogMediator8testDataEv+0xa60>
    b520:      	nop
    b524:      	adr	x0, 0x19848
    b528:      	bl	0x10b40 <_ZNSt6__ndk15mutex4lockEv@plt>
    b52c:      	adrp	x21, 0x19000
    b530:      	ldr	x1, [x21, #0x8a0]
    b534:      	cbz	x1, 0xb560 <_ZN13VLLogMediator8testDataEv+0x9fc>
    b538:      	ldr	x8, [x19]
    b53c:      	ldr	x8, [x8, #0xb0]
    b540:      	mov	x0, x19
    b544:      	blr	x8
    b548:      	adrp	x1, 0x4000
    b54c:      	add	x1, x1, #0xc53
    b550:      	adrp	x2, 0x4000
    b554:      	add	x2, x2, #0x83c
    b558:      	mov	w0, #0x3                // =3
    b55c:      	bl	0x10d40 <__android_log_print@plt>
    b560:      	nop
    b564:      	adr	x0, 0x19848
    b568:      	str	x20, [x21, #0x8a0]
    b56c:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    b570:      	bl	0x10ad0 <_ZN13VLLogMediator11getInstanceEv@plt>
    b574:      	adrp	x8, 0x14000 <syscall@plt+0x3230>
    b578:      	add	x8, x8, #0xeb8
    b57c:      	mov	x20, sp
    b580:      	str	x8, [sp]
    b584:      	str	x20, [sp, #0x20]
    b588:      	mov	x1, sp
    b58c:      	bl	0x10c20 <_ZN13VLLogMediator14setLogCallbackERKNSt6__ndk18functionIFvRKNS0_6vectorI11vllog_entryNS0_9allocatorIS3_EEEEEEE@plt>
    b590:      	ldr	x0, [sp, #0x20]
    b594:      	cmp	x0, x20
    b598:      	b.eq	0xb5d4 <_ZN13VLLogMediator8testDataEv+0xa70>
    b59c:      	cbz	x0, 0xb5e8 <_ZN13VLLogMediator8testDataEv+0xa84>
    b5a0:      	mov	w8, #0x5                // =5
    b5a4:      	b	0xb5dc <_ZN13VLLogMediator8testDataEv+0xa78>
    b5a8:      	adrp	x1, 0x4000
    b5ac:      	add	x1, x1, #0xc53
    b5b0:      	adrp	x2, 0x5000
    b5b4:      	add	x2, x2, #0x941
    b5b8:      	mov	w0, #0x6                // =6
    b5bc:      	bl	0x10d40 <__android_log_print@plt>
    b5c0:      	b	0xb600 <_ZN13VLLogMediator8testDataEv+0xa9c>
    b5c4:      	adrp	x2, 0x4000
    b5c8:      	add	x2, x2, #0x631
    b5cc:      	mov	w0, #0x6                // =6
    b5d0:      	b	0xb5f4 <_ZN13VLLogMediator8testDataEv+0xa90>
    b5d4:      	mov	w8, #0x4                // =4
    b5d8:      	mov	x0, sp
    b5dc:      	ldr	x9, [x0]
    b5e0:      	ldr	x8, [x9, x8, lsl #3]
    b5e4:      	blr	x8
    b5e8:      	adrp	x2, 0x5000
    b5ec:      	add	x2, x2, #0x517
    b5f0:      	mov	w0, #0x3                // =3
    b5f4:      	adrp	x1, 0x4000
    b5f8:      	add	x1, x1, #0xc53
    b5fc:      	bl	0x10d40 <__android_log_print@plt>
    b600:      	ldr	x8, [x22, #0x28]
    b604:      	ldur	x9, [x29, #-0x8]
    b608:      	cmp	x8, x9
    b60c:      	b.ne	0xb7c4 <_ZN13VLLogMediator8testDataEv+0xc60>
    b610:      	ldp	x20, x19, [sp, #0x70]
    b614:      	ldr	x23, [sp, #0x50]
    b618:      	ldp	x22, x21, [sp, #0x60]
    b61c:      	ldp	x29, x30, [sp, #0x40]
    b620:      	add	sp, sp, #0x80
    b624:      	ret
    b628:      	adrp	x1, 0x4000
    b62c:      	add	x1, x1, #0xc53
    b630:      	adrp	x2, 0x4000
    b634:      	add	x2, x2, #0x700
    b638:      	mov	w0, #0x6                // =6
    b63c:      	bl	0x10d40 <__android_log_print@plt>
    b640:      	ldr	x8, [x19]
    b644:      	ldr	x8, [x8, #0x30]
    b648:      	adrp	x1, 0x5000
    b64c:      	add	x1, x1, #0x11c
    b650:      	mov	x0, x19
    b654:      	blr	x8
    b658:      	mov	x1, x0
    b65c:      	ldr	x8, [x19]
    b660:      	ldr	x8, [x8, #0x70]
    b664:      	adrp	x2, 0x4000
    b668:      	add	x2, x2, #0x700
    b66c:      	mov	x0, x19
    b670:      	blr	x8
    b674:      	ldr	x8, [x22, #0x28]
    b678:      	ldur	x9, [x29, #-0x8]
    b67c:      	cmp	x8, x9
    b680:      	b.ne	0xb7c4 <_ZN13VLLogMediator8testDataEv+0xc60>
    b684:      	nop
    b688:      	adr	x0, 0x19870
    b68c:      	ldp	x20, x19, [sp, #0x70]
    b690:      	ldr	x23, [sp, #0x50]
    b694:      	ldp	x22, x21, [sp, #0x60]
    b698:      	ldp	x29, x30, [sp, #0x40]
    b69c:      	add	sp, sp, #0x80
    b6a0:      	b	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    b6a4:      	ldr	x8, [sp, #0x20]
    b6a8:      	mov	x21, x1
    b6ac:      	cmp	x8, x20
    b6b0:      	mov	x20, x0
    b6b4:      	b.eq	0xb6c4 <_ZN13VLLogMediator8testDataEv+0xb60>
    b6b8:      	cbz	x8, 0xb71c <_ZN13VLLogMediator8testDataEv+0xbb8>
    b6bc:      	mov	w9, #0x5                // =5
    b6c0:      	b	0xb6cc <_ZN13VLLogMediator8testDataEv+0xb68>
    b6c4:      	mov	w9, #0x4                // =4
    b6c8:      	mov	x8, sp
    b6cc:      	ldr	x10, [x8]
    b6d0:      	mov	x0, x8
    b6d4:      	ldr	x9, [x10, x9, lsl #3]
    b6d8:      	blr	x9
    b6dc:      	b	0xb71c <_ZN13VLLogMediator8testDataEv+0xbb8>
    b6e0:      	b	0xb714 <_ZN13VLLogMediator8testDataEv+0xbb0>
    b6e4:      	mov	x20, x0
    b6e8:      	nop
    b6ec:      	adr	x0, 0x19848
    b6f0:      	b	0xb704 <_ZN13VLLogMediator8testDataEv+0xba0>
    b6f4:      	b	0xb714 <_ZN13VLLogMediator8testDataEv+0xbb0>
    b6f8:      	mov	x20, x0
    b6fc:      	nop
    b700:      	adr	x0, 0x19870
    b704:      	mov	x21, x1
    b708:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    b70c:      	b	0xb71c <_ZN13VLLogMediator8testDataEv+0xbb8>
    b710:      	b	0xb714 <_ZN13VLLogMediator8testDataEv+0xbb0>
    b714:      	mov	x21, x1
    b718:      	mov	x20, x0
    b71c:      	cmp	w21, #0x1
    b720:      	b.ne	0xb7ac <_ZN13VLLogMediator8testDataEv+0xc48>
    b724:      	mov	x0, x20
    b728:      	bl	0x10860 <__cxa_begin_catch@plt>
    b72c:      	ldr	x8, [x0]
    b730:      	mov	x20, x0
    b734:      	ldr	x8, [x8, #0x10]
    b738:      	blr	x8
    b73c:      	mov	x3, x0
    b740:      	adrp	x1, 0x4000
    b744:      	add	x1, x1, #0xc53
    b748:      	adrp	x2, 0x4000
    b74c:      	add	x2, x2, #0xf0d
    b750:      	mov	w0, #0x6                // =6
    b754:      	bl	0x10d40 <__android_log_print@plt>
    b758:      	ldr	x8, [x19]
    b75c:      	ldr	x8, [x8, #0x30]
    b760:      	adrp	x1, 0x5000
    b764:      	add	x1, x1, #0x11c
    b768:      	mov	x0, x19
    b76c:      	blr	x8
    b770:      	ldr	x8, [x20]
    b774:      	mov	x21, x0
    b778:      	mov	x0, x20
    b77c:      	ldr	x8, [x8, #0x10]
    b780:      	blr	x8
    b784:      	ldr	x8, [x19]
    b788:      	mov	x2, x0
    b78c:      	ldr	x8, [x8, #0x70]
    b790:      	mov	x0, x19
    b794:      	mov	x1, x21
    b798:      	blr	x8
    b79c:      	bl	0x10990 <__cxa_end_catch@plt>
    b7a0:      	b	0xb600 <_ZN13VLLogMediator8testDataEv+0xa9c>
    b7a4:      	mov	x20, x0
    b7a8:      	bl	0x10990 <__cxa_end_catch@plt>
    b7ac:      	ldr	x8, [x22, #0x28]
    b7b0:      	ldur	x9, [x29, #-0x8]
    b7b4:      	cmp	x8, x9
    b7b8:      	b.ne	0xb7c4 <_ZN13VLLogMediator8testDataEv+0xc60>
    b7bc:      	mov	x0, x20
    b7c0:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    b7c4:      	bl	0x10840 <__stack_chk_fail@plt>
    b7c8:      	bl	0x80b0 <_ZN13MTLReportTool9Interface7versionEv+0xc>
    b7cc:      	stp	x29, x30, [sp, #-0x30]!
    b7d0:      	str	x21, [sp, #0x10]
    b7d4:      	stp	x20, x19, [sp, #0x20]
    b7d8:      	mov	x29, sp
    b7dc:      	mov	x19, x0
    b7e0:      	adrp	x1, 0x4000
    b7e4:      	add	x1, x1, #0xc53
    b7e8:      	adrp	x2, 0x4000
    b7ec:      	add	x2, x2, #0x793
    b7f0:      	mov	w0, #0x3                // =3
    b7f4:      	bl	0x10d40 <__android_log_print@plt>
    b7f8:      	nop
    b7fc:      	adr	x0, 0x19848
    b800:      	bl	0x10b40 <_ZNSt6__ndk15mutex4lockEv@plt>
    b804:      	adrp	x20, 0x19000
    b808:      	ldr	x1, [x20, #0x8a0]
    b80c:      	cbz	x1, 0xb83c <_ZN13VLLogMediator8testDataEv+0xcd8>
    b810:      	ldr	x8, [x19]
    b814:      	ldr	x8, [x8, #0xb0]
    b818:      	mov	x0, x19
    b81c:      	blr	x8
    b820:      	str	xzr, [x20, #0x8a0]
    b824:      	adrp	x1, 0x4000
    b828:      	add	x1, x1, #0xc53
    b82c:      	adrp	x2, 0x4000
    b830:      	add	x2, x2, #0xfc6
    b834:      	mov	w0, #0x3                // =3
    b838:      	bl	0x10d40 <__android_log_print@plt>
    b83c:      	nop
    b840:      	adr	x0, 0x19848
    b844:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    b848:      	nop
    b84c:      	adr	x0, 0x19870
    b850:      	bl	0x10b40 <_ZNSt6__ndk15mutex4lockEv@plt>
    b854:      	adrp	x20, 0x19000
    b858:      	ldr	x1, [x20, #0x898]
    b85c:      	cbz	x1, 0xb88c <_ZN13VLLogMediator8testDataEv+0xd28>
    b860:      	ldr	x8, [x19]
    b864:      	ldr	x8, [x8, #0xb0]
    b868:      	mov	x0, x19
    b86c:      	blr	x8
    b870:      	str	xzr, [x20, #0x898]
    b874:      	adrp	x1, 0x4000
    b878:      	add	x1, x1, #0xc53
    b87c:      	adrp	x2, 0x5000
    b880:      	add	x2, x2, #0x1df
    b884:      	mov	w0, #0x3                // =3
    b888:      	bl	0x10d40 <__android_log_print@plt>
    b88c:      	nop
    b890:      	adr	x0, 0x19870
    b894:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    b898:      	adrp	x1, 0x4000
    b89c:      	add	x1, x1, #0xc53
    b8a0:      	adrp	x2, 0x5000
    b8a4:      	add	x2, x2, #0x56b
    b8a8:      	mov	w0, #0x3                // =3
    b8ac:      	bl	0x10d40 <__android_log_print@plt>
    b8b0:      	ldp	x20, x19, [sp, #0x20]
    b8b4:      	ldr	x21, [sp, #0x10]
    b8b8:      	ldp	x29, x30, [sp], #0x30
    b8bc:      	ret
    b8c0:      	b	0xb8f4 <_ZN13VLLogMediator8testDataEv+0xd90>
    b8c4:      	b	0xb8f4 <_ZN13VLLogMediator8testDataEv+0xd90>
    b8c8:      	mov	x21, x1
    b8cc:      	mov	x20, x0
    b8d0:      	nop
    b8d4:      	adr	x0, 0x19870
    b8d8:      	b	0xb8ec <_ZN13VLLogMediator8testDataEv+0xd88>
    b8dc:      	mov	x21, x1
    b8e0:      	mov	x20, x0
    b8e4:      	nop
    b8e8:      	adr	x0, 0x19848
    b8ec:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    b8f0:      	b	0xb8fc <_ZN13VLLogMediator8testDataEv+0xd98>
    b8f4:      	mov	x21, x1
    b8f8:      	mov	x20, x0
    b8fc:      	cmp	w21, #0x1
    b900:      	b.ne	0xb994 <_ZN13VLLogMediator8testDataEv+0xe30>
    b904:      	mov	x0, x20
    b908:      	bl	0x10860 <__cxa_begin_catch@plt>
    b90c:      	ldr	x8, [x0]
    b910:      	mov	x20, x0
    b914:      	ldr	x8, [x8, #0x10]
    b918:      	blr	x8
    b91c:      	mov	x3, x0
    b920:      	adrp	x1, 0x4000
    b924:      	add	x1, x1, #0xc53
    b928:      	adrp	x2, 0x5000
    b92c:      	add	x2, x2, #0x58f
    b930:      	mov	w0, #0x6                // =6
    b934:      	bl	0x10d40 <__android_log_print@plt>
    b938:      	ldr	x8, [x19]
    b93c:      	ldr	x8, [x8, #0x30]
    b940:      	adrp	x1, 0x5000
    b944:      	add	x1, x1, #0x11c
    b948:      	mov	x0, x19
    b94c:      	blr	x8
    b950:      	ldr	x8, [x20]
    b954:      	mov	x21, x0
    b958:      	mov	x0, x20
    b95c:      	ldr	x8, [x8, #0x10]
    b960:      	blr	x8
    b964:      	ldr	x8, [x19]
    b968:      	mov	x2, x0
    b96c:      	ldr	x8, [x8, #0x70]
    b970:      	mov	x0, x19
    b974:      	mov	x1, x21
    b978:      	blr	x8
    b97c:      	ldp	x20, x19, [sp, #0x20]
    b980:      	ldr	x21, [sp, #0x10]
    b984:      	ldp	x29, x30, [sp], #0x30
    b988:      	b	0x10990 <__cxa_end_catch@plt>
    b98c:      	mov	x20, x0
    b990:      	bl	0x10990 <__cxa_end_catch@plt>
    b994:      	mov	x0, x20
    b998:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    b99c:      	bl	0x80b0 <_ZN13MTLReportTool9Interface7versionEv+0xc>
    b9a0:      	stp	x29, x30, [sp, #-0x30]!
    b9a4:      	str	x21, [sp, #0x10]
    b9a8:      	stp	x20, x19, [sp, #0x20]
    b9ac:      	mov	x29, sp
    b9b0:      	mov	x19, x0
    b9b4:      	bl	0x10ad0 <_ZN13VLLogMediator11getInstanceEv@plt>
    b9b8:      	bl	0x10c80 <_ZN13VLLogMediator15getVllogVersionEv@plt>
    b9bc:      	mov	x20, x0
    b9c0:      	adrp	x1, 0x4000
    b9c4:      	add	x1, x1, #0xc53
    b9c8:      	adrp	x2, 0x4000
    b9cc:      	add	x2, x2, #0xe13
    b9d0:      	mov	w0, #0x3                // =3
    b9d4:      	mov	x3, x20
    b9d8:      	bl	0x10d40 <__android_log_print@plt>
    b9dc:      	ldr	x8, [x19]
    b9e0:      	ldr	x8, [x8, #0x538]
    b9e4:      	mov	x0, x19
    b9e8:      	mov	x1, x20
    b9ec:      	blr	x8
    b9f0:      	ldp	x20, x19, [sp, #0x20]
    b9f4:      	ldr	x21, [sp, #0x10]
    b9f8:      	ldp	x29, x30, [sp], #0x30
    b9fc:      	ret
    ba00:      	cmp	w1, #0x1
    ba04:      	mov	x20, x0
    ba08:      	b.ne	0xba98 <_ZN13VLLogMediator8testDataEv+0xf34>
    ba0c:      	mov	x0, x20
    ba10:      	bl	0x10860 <__cxa_begin_catch@plt>
    ba14:      	ldr	x8, [x0]
    ba18:      	mov	x20, x0
    ba1c:      	ldr	x8, [x8, #0x10]
    ba20:      	blr	x8
    ba24:      	mov	x3, x0
    ba28:      	adrp	x1, 0x4000
    ba2c:      	add	x1, x1, #0xc53
    ba30:      	adrp	x2, 0x4000
    ba34:      	add	x2, x2, #0xd0c
    ba38:      	mov	w0, #0x6                // =6
    ba3c:      	bl	0x10d40 <__android_log_print@plt>
    ba40:      	ldr	x8, [x19]
    ba44:      	ldr	x8, [x8, #0x30]
    ba48:      	adrp	x1, 0x5000
    ba4c:      	add	x1, x1, #0x11c
    ba50:      	mov	x0, x19
    ba54:      	blr	x8
    ba58:      	ldr	x8, [x20]
    ba5c:      	mov	x21, x0
    ba60:      	mov	x0, x20
    ba64:      	ldr	x8, [x8, #0x10]
    ba68:      	blr	x8
    ba6c:      	ldr	x8, [x19]
    ba70:      	mov	x2, x0
    ba74:      	ldr	x8, [x8, #0x70]
    ba78:      	mov	x0, x19
    ba7c:      	mov	x1, x21
    ba80:      	blr	x8
    ba84:      	bl	0x10990 <__cxa_end_catch@plt>
    ba88:      	mov	x0, xzr
    ba8c:      	b	0xb9f0 <_ZN13VLLogMediator8testDataEv+0xe8c>
    ba90:      	mov	x20, x0
    ba94:      	bl	0x10990 <__cxa_end_catch@plt>
    ba98:      	mov	x0, x20
    ba9c:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    baa0:      	bl	0x80b0 <_ZN13MTLReportTool9Interface7versionEv+0xc>
    baa4:      	sub	sp, sp, #0x50
    baa8:      	stp	x29, x30, [sp, #0x20]
    baac:      	stp	x22, x21, [sp, #0x30]
    bab0:      	stp	x20, x19, [sp, #0x40]
    bab4:      	add	x29, sp, #0x20
    bab8:      	mrs	x22, TPIDR_EL0
    babc:      	mov	w20, w3
    bac0:      	mov	x1, x2
    bac4:      	ldr	x8, [x22, #0x28]
    bac8:      	mov	x19, x0
    bacc:      	stur	x8, [x29, #-0x8]
    bad0:      	mov	x8, sp
    bad4:      	mov	x21, sp
    bad8:      	bl	0xbc70 <_ZN13VLLogMediator8testDataEv+0x110c>
    badc:      	ldrb	w8, [sp]
    bae0:      	ldr	x9, [sp, #0x10]
    bae4:      	orr	x21, x21, #0x1
    bae8:      	tst	w8, #0x1
    baec:      	csel	x3, x21, x9, eq
    baf0:      	adrp	x1, 0x4000
    baf4:      	add	x1, x1, #0xc53
    baf8:      	adrp	x2, 0x4000
    bafc:      	add	x2, x2, #0x5c2
    bb00:      	mov	w0, #0x3                // =3
    bb04:      	mov	w4, w20
    bb08:      	bl	0x10d40 <__android_log_print@plt>
    bb0c:      	bl	0x10ad0 <_ZN13VLLogMediator11getInstanceEv@plt>
    bb10:      	ldrb	w8, [sp]
    bb14:      	ldr	x9, [sp, #0x10]
    bb18:      	tst	w8, #0x1
    bb1c:      	csel	x1, x21, x9, eq
    bb20:      	mov	w2, w20
    bb24:      	bl	0x10c30 <_ZN13VLLogMediator13setTagExcludeEPKci@plt>
    bb28:      	mov	w20, w0
    bb2c:      	adrp	x1, 0x4000
    bb30:      	add	x1, x1, #0xc53
    bb34:      	adrp	x2, 0x4000
    bb38:      	add	x2, x2, #0xa9b
    bb3c:      	mov	w0, #0x3                // =3
    bb40:      	mov	w3, w20
    bb44:      	bl	0x10d40 <__android_log_print@plt>
    bb48:      	ldrb	w8, [sp]
    bb4c:      	tbz	w8, #0x0, 0xbb58 <_ZN13VLLogMediator8testDataEv+0xff4>
    bb50:      	ldr	x0, [sp, #0x10]
    bb54:      	bl	0x10790 <_ZdlPv@plt>
    bb58:      	ldr	x8, [x22, #0x28]
    bb5c:      	ldur	x9, [x29, #-0x8]
    bb60:      	cmp	x8, x9
    bb64:      	b.ne	0xbc54 <_ZN13VLLogMediator8testDataEv+0x10f0>
    bb68:      	mov	w0, w20
    bb6c:      	ldp	x20, x19, [sp, #0x40]
    bb70:      	ldp	x22, x21, [sp, #0x30]
    bb74:      	ldp	x29, x30, [sp, #0x20]
    bb78:      	add	sp, sp, #0x50
    bb7c:      	ret
    bb80:      	b	0xbb90 <_ZN13VLLogMediator8testDataEv+0x102c>
    bb84:      	mov	x21, x1
    bb88:      	mov	x20, x0
    bb8c:      	b	0xbba8 <_ZN13VLLogMediator8testDataEv+0x1044>
    bb90:      	ldrb	w8, [sp]
    bb94:      	mov	x21, x1
    bb98:      	mov	x20, x0
    bb9c:      	tbz	w8, #0x0, 0xbba8 <_ZN13VLLogMediator8testDataEv+0x1044>
    bba0:      	ldr	x0, [sp, #0x10]
    bba4:      	bl	0x10790 <_ZdlPv@plt>
    bba8:      	cmp	w21, #0x1
    bbac:      	b.ne	0xbc3c <_ZN13VLLogMediator8testDataEv+0x10d8>
    bbb0:      	mov	x0, x20
    bbb4:      	bl	0x10860 <__cxa_begin_catch@plt>
    bbb8:      	ldr	x8, [x0]
    bbbc:      	mov	x20, x0
    bbc0:      	ldr	x8, [x8, #0x10]
    bbc4:      	blr	x8
    bbc8:      	mov	x3, x0
    bbcc:      	adrp	x1, 0x4000
    bbd0:      	add	x1, x1, #0xc53
    bbd4:      	adrp	x2, 0x4000
    bbd8:      	add	x2, x2, #0xd8e
    bbdc:      	mov	w0, #0x6                // =6
    bbe0:      	bl	0x10d40 <__android_log_print@plt>
    bbe4:      	ldr	x8, [x19]
    bbe8:      	ldr	x8, [x8, #0x30]
    bbec:      	adrp	x1, 0x5000
    bbf0:      	add	x1, x1, #0x11c
    bbf4:      	mov	x0, x19
    bbf8:      	blr	x8
    bbfc:      	ldr	x8, [x20]
    bc00:      	mov	x21, x0
    bc04:      	mov	x0, x20
    bc08:      	ldr	x8, [x8, #0x10]
    bc0c:      	blr	x8
    bc10:      	ldr	x8, [x19]
    bc14:      	mov	x2, x0
    bc18:      	ldr	x8, [x8, #0x70]
    bc1c:      	mov	x0, x19
    bc20:      	mov	x1, x21
    bc24:      	blr	x8
    bc28:      	bl	0x10990 <__cxa_end_catch@plt>
    bc2c:      	mov	w20, #-0x1              // =-1
    bc30:      	b	0xbb58 <_ZN13VLLogMediator8testDataEv+0xff4>
    bc34:      	mov	x20, x0
    bc38:      	bl	0x10990 <__cxa_end_catch@plt>
    bc3c:      	ldr	x8, [x22, #0x28]
    bc40:      	ldur	x9, [x29, #-0x8]
    bc44:      	cmp	x8, x9
    bc48:      	b.ne	0xbc54 <_ZN13VLLogMediator8testDataEv+0x10f0>
    bc4c:      	mov	x0, x20
    bc50:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    bc54:      	bl	0x10840 <__stack_chk_fail@plt>
    bc58:      	bl	0x80b0 <_ZN13MTLReportTool9Interface7versionEv+0xc>
    bc5c:      	stp	x29, x30, [sp, #-0x10]!
    bc60:      	mov	x29, sp
    bc64:      	bl	0x10ad0 <_ZN13VLLogMediator11getInstanceEv@plt>
    bc68:      	ldp	x29, x30, [sp], #0x10
    bc6c:      	b	0x10cf0 <_ZN13VLLogMediator8testDataEv@plt>
    bc70:      	stp	x29, x30, [sp, #-0x30]!
    bc74:      	stp	x22, x21, [sp, #0x10]
    bc78:      	stp	x20, x19, [sp, #0x20]
    bc7c:      	mov	x29, sp
    bc80:      	mov	x19, x8
    bc84:      	cbz	x1, 0xbcdc <_ZN13VLLogMediator8testDataEv+0x1178>
    bc88:      	ldr	x8, [x0]
    bc8c:      	mov	x2, xzr
    bc90:      	mov	x20, x1
    bc94:      	mov	x21, x0
    bc98:      	ldr	x8, [x8, #0x548]
    bc9c:      	blr	x8
    bca0:      	cbz	x0, 0xbcdc <_ZN13VLLogMediator8testDataEv+0x1178>
    bca4:      	mov	x22, x0
    bca8:      	mov	x0, x19
    bcac:      	mov	x1, x22
    bcb0:      	bl	0x7df0 <.text+0x60>
    bcb4:      	ldr	x8, [x21]
    bcb8:      	ldr	x8, [x8, #0x550]
    bcbc:      	mov	x0, x21
    bcc0:      	mov	x1, x20
    bcc4:      	mov	x2, x22
    bcc8:      	blr	x8
    bccc:      	ldp	x20, x19, [sp, #0x20]
    bcd0:      	ldp	x22, x21, [sp, #0x10]
    bcd4:      	ldp	x29, x30, [sp], #0x30
    bcd8:      	ret
    bcdc:      	adrp	x1, 0x4000
    bce0:      	add	x1, x1, #0xa82
    bce4:      	mov	x0, x19
    bce8:      	ldp	x20, x19, [sp, #0x20]
    bcec:      	ldp	x22, x21, [sp, #0x10]
    bcf0:      	ldp	x29, x30, [sp], #0x30
    bcf4:      	b	0x7df0 <.text+0x60>
    bcf8:      	ldrb	w8, [x19]
    bcfc:      	mov	x20, x0
    bd00:      	tbz	w8, #0x0, 0xbd0c <_ZN13VLLogMediator8testDataEv+0x11a8>
    bd04:      	ldr	x0, [x19, #0x10]
    bd08:      	bl	0x10790 <_ZdlPv@plt>
    bd0c:      	mov	x0, x20
    bd10:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    bd14:      	ret
    bd18:      	b	0x10790 <_ZdlPv@plt>
    bd1c:      	stp	x29, x30, [sp, #-0x10]!
    bd20:      	mov	x29, sp
    bd24:      	mov	w0, #0x10               // =16
    bd28:      	bl	0x10770 <_Znwm@plt>
    bd2c:      	adrp	x8, 0x14000 <syscall@plt+0x3230>
    bd30:      	add	x8, x8, #0xeb8
    bd34:      	str	x8, [x0]
    bd38:      	ldp	x29, x30, [sp], #0x10
    bd3c:      	ret
    bd40:      	adrp	x8, 0x14000 <syscall@plt+0x3230>
    bd44:      	add	x8, x8, #0xeb8
    bd48:      	str	x8, [x1]
    bd4c:      	ret
    bd50:      	ret
    bd54:      	b	0x10790 <_ZdlPv@plt>
    bd58:      	sub	sp, sp, #0xc0
    bd5c:      	stp	x29, x30, [sp, #0x60]
    bd60:      	stp	x28, x27, [sp, #0x70]
    bd64:      	stp	x26, x25, [sp, #0x80]
    bd68:      	stp	x24, x23, [sp, #0x90]
    bd6c:      	stp	x22, x21, [sp, #0xa0]
    bd70:      	stp	x20, x19, [sp, #0xb0]
    bd74:      	add	x29, sp, #0x60
    bd78:      	mrs	x22, TPIDR_EL0
    bd7c:      	mov	x26, x1
    bd80:      	sub	x0, x29, #0x10
    bd84:      	ldr	x8, [x22, #0x28]
    bd88:      	sub	x1, x29, #0x14
    bd8c:      	stur	x8, [x29, #-0x8]
    bd90:      	stur	xzr, [x29, #-0x10]
    bd94:      	sturb	wzr, [x29, #-0x14]
    bd98:      	bl	0xc690 <_ZN13VLLogMediator8testDataEv+0x1b2c>
    bd9c:      	tbz	w0, #0x0, 0xc1f8 <_ZN13VLLogMediator8testDataEv+0x1694>
    bda0:      	nop
    bda4:      	adr	x0, 0x19848
    bda8:      	bl	0x10b40 <_ZNSt6__ndk15mutex4lockEv@plt>
    bdac:      	adrp	x8, 0x19000
    bdb0:      	ldr	x1, [x8, #0x8a0]
    bdb4:      	cbz	x1, 0xc214 <_ZN13VLLogMediator8testDataEv+0x16b0>
    bdb8:      	ldur	x0, [x29, #-0x10]
    bdbc:      	ldr	x8, [x0]
    bdc0:      	ldr	x8, [x8, #0xc8]
    bdc4:      	blr	x8
    bdc8:      	mov	x19, x0
    bdcc:      	nop
    bdd0:      	adr	x0, 0x19848
    bdd4:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    bdd8:      	cbz	x19, 0xc248 <_ZN13VLLogMediator8testDataEv+0x16e4>
    bddc:      	ldur	x0, [x29, #-0x10]
    bde0:      	adrp	x1, 0x4000
    bde4:      	add	x1, x1, #0xa83
    bde8:      	ldr	x8, [x0]
    bdec:      	ldr	x8, [x8, #0x30]
    bdf0:      	blr	x8
    bdf4:      	cbz	x0, 0xc264 <_ZN13VLLogMediator8testDataEv+0x1700>
    bdf8:      	mov	x20, x0
    bdfc:      	nop
    be00:      	adr	x0, 0x19870
    be04:      	bl	0x10b40 <_ZNSt6__ndk15mutex4lockEv@plt>
    be08:      	adrp	x8, 0x19000
    be0c:      	ldr	x1, [x8, #0x898]
    be10:      	cbz	x1, 0xc280 <_ZN13VLLogMediator8testDataEv+0x171c>
    be14:      	ldur	x0, [x29, #-0x10]
    be18:      	ldr	x8, [x0]
    be1c:      	ldr	x8, [x8, #0xc8]
    be20:      	blr	x8
    be24:      	mov	x23, x0
    be28:      	nop
    be2c:      	adr	x0, 0x19870
    be30:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    be34:      	cbz	x23, 0xc2d8 <_ZN13VLLogMediator8testDataEv+0x1774>
    be38:      	ldur	x0, [x29, #-0x10]
    be3c:      	adrp	x21, 0x5000
    be40:      	add	x21, x21, #0x37b
    be44:      	adrp	x25, 0x4000
    be48:      	add	x25, x25, #0x838
    be4c:      	mov	x1, x20
    be50:      	ldr	x8, [x0]
    be54:      	mov	x2, x21
    be58:      	mov	x3, x25
    be5c:      	str	x22, [sp, #0x8]
    be60:      	ldr	x8, [x8, #0x108]
    be64:      	str	x19, [sp, #0x18]
    be68:      	blr	x8
    be6c:      	ldur	x8, [x29, #-0x10]
    be70:      	mov	x19, x0
    be74:      	adrp	x2, 0x4000
    be78:      	add	x2, x2, #0xa97
    be7c:      	adrp	x3, 0x4000
    be80:      	add	x3, x3, #0xbb0
    be84:      	ldr	x9, [x8]
    be88:      	mov	x0, x8
    be8c:      	mov	x1, x20
    be90:      	ldr	x9, [x9, #0x108]
    be94:      	blr	x9
    be98:      	ldur	x8, [x29, #-0x10]
    be9c:      	mov	x28, x0
    bea0:      	mov	x1, x20
    bea4:      	mov	x2, x19
    bea8:      	str	x20, [sp, #0x10]
    beac:      	mov	x0, x8
    beb0:      	bl	0xc408 <_ZN13VLLogMediator8testDataEv+0x18a4>
    beb4:      	ldur	x8, [x29, #-0x10]
    beb8:      	adrp	x22, 0x4000
    bebc:      	add	x22, x22, #0x5af
    bec0:      	mov	x24, x0
    bec4:      	adrp	x2, 0x5000
    bec8:      	add	x2, x2, #0x1d8
    becc:      	ldr	x9, [x8]
    bed0:      	mov	x0, x8
    bed4:      	mov	x1, x23
    bed8:      	mov	x3, x22
    bedc:      	ldr	x9, [x9, #0x2f0]
    bee0:      	blr	x9
    bee4:      	ldur	x8, [x29, #-0x10]
    bee8:      	stur	x0, [x29, #-0x20]
    beec:      	adrp	x2, 0x4000
    bef0:      	add	x2, x2, #0xd05
    bef4:      	mov	x1, x23
    bef8:      	mov	x3, x22
    befc:      	ldr	x9, [x8]
    bf00:      	mov	x0, x8
    bf04:      	ldr	x9, [x9, #0x2f0]
    bf08:      	blr	x9
    bf0c:      	ldur	x8, [x29, #-0x10]
    bf10:      	stur	x0, [x29, #-0x28]
    bf14:      	adrp	x2, 0x5000
    bf18:      	add	x2, x2, #0x382
    bf1c:      	adrp	x3, 0x5000
    bf20:      	add	x3, x3, #0x835
    bf24:      	ldr	x9, [x8]
    bf28:      	mov	x0, x8
    bf2c:      	mov	x1, x23
    bf30:      	ldr	x9, [x9, #0x2f0]
    bf34:      	blr	x9
    bf38:      	ldur	x8, [x29, #-0x10]
    bf3c:      	str	x0, [sp, #0x30]
    bf40:      	adrp	x2, 0x4000
    bf44:      	add	x2, x2, #0xd86
    bf48:      	mov	x1, x23
    bf4c:      	mov	x3, x22
    bf50:      	ldr	x9, [x8]
    bf54:      	mov	x0, x8
    bf58:      	ldr	x9, [x9, #0x2f0]
    bf5c:      	blr	x9
    bf60:      	ldur	x8, [x29, #-0x10]
    bf64:      	str	x0, [sp, #0x28]
    bf68:      	adrp	x2, 0x4000
    bf6c:      	add	x2, x2, #0xc6c
    bf70:      	adrp	x3, 0x5000
    bf74:      	add	x3, x3, #0x618
    bf78:      	ldr	x9, [x8]
    bf7c:      	mov	x0, x8
    bf80:      	mov	x1, x23
    bf84:      	ldr	x9, [x9, #0x2f0]
    bf88:      	blr	x9
    bf8c:      	ldur	x8, [x29, #-0x10]
    bf90:      	str	x0, [sp, #0x20]
    bf94:      	adrp	x2, 0x5000
    bf98:      	add	x2, x2, #0x87e
    bf9c:      	mov	x1, x23
    bfa0:      	mov	x3, x22
    bfa4:      	ldr	x9, [x8]
    bfa8:      	mov	x0, x8
    bfac:      	ldr	x9, [x9, #0x2f0]
    bfb0:      	blr	x9
    bfb4:      	ldur	x8, [x29, #-0x10]
    bfb8:      	mov	x19, x0
    bfbc:      	adrp	x2, 0x4000
    bfc0:      	add	x2, x2, #0xfbb
    bfc4:      	mov	x1, x23
    bfc8:      	mov	x3, x22
    bfcc:      	ldr	x9, [x8]
    bfd0:      	mov	x0, x8
    bfd4:      	ldr	x9, [x9, #0x2f0]
    bfd8:      	blr	x9
    bfdc:      	ldur	x0, [x29, #-0x10]
    bfe0:      	mov	x1, x23
    bfe4:      	mov	x2, x21
    bfe8:      	mov	x3, x25
    bfec:      	ldr	x8, [x0]
    bff0:      	ldr	x8, [x8, #0x108]
    bff4:      	blr	x8
    bff8:      	ldp	x21, x25, [x26]
    bffc:      	cmp	x21, x25
    c000:      	b.eq	0xc198 <_ZN13VLLogMediator8testDataEv+0x1634>
    c004:      	mov	x26, x0
    c008:      	adrp	x27, 0x4000
    c00c:      	add	x27, x27, #0xa82
    c010:      	ldur	x0, [x29, #-0x10]
    c014:      	mov	x1, x23
    c018:      	mov	x2, x26
    c01c:      	bl	0xc408 <_ZN13VLLogMediator8testDataEv+0x18a4>
    c020:      	mov	x20, x28
    c024:      	mov	x28, x24
    c028:      	mov	x24, x23
    c02c:      	ldur	x23, [x29, #-0x10]
    c030:      	ldr	x8, [x21]
    c034:      	mov	x22, x0
    c038:      	ldr	x9, [x23]
    c03c:      	cmp	x8, #0x0
    c040:      	mov	x0, x23
    c044:      	csel	x1, x27, x8, eq
    c048:      	ldr	x9, [x9, #0x538]
    c04c:      	blr	x9
    c050:      	ldr	x8, [x23]
    c054:      	ldur	x2, [x29, #-0x20]
    c058:      	mov	x3, x0
    c05c:      	mov	x0, x23
    c060:      	mov	x1, x22
    c064:      	ldr	x8, [x8, #0x340]
    c068:      	blr	x8
    c06c:      	ldur	x23, [x29, #-0x10]
    c070:      	ldr	x8, [x21, #0x8]
    c074:      	ldr	x9, [x23]
    c078:      	cmp	x8, #0x0
    c07c:      	mov	x0, x23
    c080:      	csel	x1, x27, x8, eq
    c084:      	ldr	x9, [x9, #0x538]
    c088:      	blr	x9
    c08c:      	ldr	x8, [x23]
    c090:      	ldur	x2, [x29, #-0x28]
    c094:      	mov	x3, x0
    c098:      	mov	x0, x23
    c09c:      	mov	x1, x22
    c0a0:      	ldr	x8, [x8, #0x340]
    c0a4:      	blr	x8
    c0a8:      	ldur	x0, [x29, #-0x10]
    c0ac:      	ldr	w3, [x21, #0x10]
    c0b0:      	mov	x1, x22
    c0b4:      	ldr	x2, [sp, #0x30]
    c0b8:      	ldr	x8, [x0]
    c0bc:      	ldr	x8, [x8, #0x368]
    c0c0:      	blr	x8
    c0c4:      	ldur	x23, [x29, #-0x10]
    c0c8:      	ldr	x8, [x21, #0x18]
    c0cc:      	ldr	x9, [x23]
    c0d0:      	cmp	x8, #0x0
    c0d4:      	mov	x0, x23
    c0d8:      	csel	x1, x27, x8, eq
    c0dc:      	ldr	x9, [x9, #0x538]
    c0e0:      	blr	x9
    c0e4:      	ldr	x8, [x23]
    c0e8:      	ldr	x2, [sp, #0x28]
    c0ec:      	mov	x3, x0
    c0f0:      	mov	x0, x23
    c0f4:      	mov	x1, x22
    c0f8:      	ldr	x8, [x8, #0x340]
    c0fc:      	blr	x8
    c100:      	ldur	x0, [x29, #-0x10]
    c104:      	ldr	x3, [x21, #0x20]
    c108:      	mov	x1, x22
    c10c:      	ldr	x2, [sp, #0x20]
    c110:      	ldr	x8, [x0]
    c114:      	ldr	x8, [x8, #0x370]
    c118:      	blr	x8
    c11c:      	ldur	x23, [x29, #-0x10]
    c120:      	ldr	x8, [x21, #0x28]
    c124:      	ldr	x9, [x23]
    c128:      	cmp	x8, #0x0
    c12c:      	mov	x0, x23
    c130:      	csel	x1, x27, x8, eq
    c134:      	ldr	x9, [x9, #0x538]
    c138:      	blr	x9
    c13c:      	ldr	x8, [x23]
    c140:      	mov	x3, x0
    c144:      	mov	x0, x23
    c148:      	mov	x1, x22
    c14c:      	mov	x2, x19
    c150:      	mov	x23, x24
    c154:      	ldr	x8, [x8, #0x340]
    c158:      	mov	x24, x28
    c15c:      	mov	x28, x20
    c160:      	blr	x8
    c164:      	ldur	x0, [x29, #-0x10]
    c168:      	mov	x1, x24
    c16c:      	mov	x2, x20
    c170:      	mov	x3, x22
    c174:      	bl	0xc4a4 <_ZN13VLLogMediator8testDataEv+0x1940>
    c178:      	ldur	x0, [x29, #-0x10]
    c17c:      	mov	x1, x22
    c180:      	ldr	x8, [x0]
    c184:      	ldr	x8, [x8, #0xb8]
    c188:      	blr	x8
    c18c:      	add	x21, x21, #0x30
    c190:      	cmp	x21, x25
    c194:      	b.ne	0xc010 <_ZN13VLLogMediator8testDataEv+0x14ac>
    c198:      	ldur	x0, [x29, #-0x10]
    c19c:      	ldr	x20, [sp, #0x18]
    c1a0:      	ldr	x8, [x0]
    c1a4:      	mov	x1, x20
    c1a8:      	ldr	x8, [x8, #0xf8]
    c1ac:      	blr	x8
    c1b0:      	ldur	x8, [x29, #-0x10]
    c1b4:      	mov	x19, x0
    c1b8:      	adrp	x2, 0x4000
    c1bc:      	add	x2, x2, #0x921
    c1c0:      	adrp	x3, 0x5000
    c1c4:      	add	x3, x3, #0x15c
    c1c8:      	ldr	x9, [x8]
    c1cc:      	mov	x0, x8
    c1d0:      	mov	x1, x19
    c1d4:      	ldr	x9, [x9, #0x108]
    c1d8:      	blr	x9
    c1dc:      	cbz	x0, 0xc310 <_ZN13VLLogMediator8testDataEv+0x17ac>
    c1e0:      	mov	x2, x0
    c1e4:      	ldur	x0, [x29, #-0x10]
    c1e8:      	mov	x1, x20
    c1ec:      	mov	x3, x24
    c1f0:      	bl	0xc540 <_ZN13VLLogMediator8testDataEv+0x19dc>
    c1f4:      	b	0xc328 <_ZN13VLLogMediator8testDataEv+0x17c4>
    c1f8:      	adrp	x1, 0x4000
    c1fc:      	add	x1, x1, #0xc53
    c200:      	adrp	x2, 0x5000
    c204:      	add	x2, x2, #0x137
    c208:      	mov	w0, #0x6                // =6
    c20c:      	bl	0x10d40 <__android_log_print@plt>
    c210:      	b	0xc39c <_ZN13VLLogMediator8testDataEv+0x1838>
    c214:      	adrp	x1, 0x4000
    c218:      	add	x1, x1, #0xc53
    c21c:      	adrp	x2, 0x5000
    c220:      	add	x2, x2, #0x30f
    c224:      	mov	w0, #0x6                // =6
    c228:      	bl	0x10d40 <__android_log_print@plt>
    c22c:      	ldurb	w8, [x29, #-0x14]
    c230:      	cbz	w8, 0xc238 <_ZN13VLLogMediator8testDataEv+0x16d4>
    c234:      	bl	0xc780 <_ZN13VLLogMediator8testDataEv+0x1c1c>
    c238:      	nop
    c23c:      	adr	x0, 0x19848
    c240:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    c244:      	b	0xc39c <_ZN13VLLogMediator8testDataEv+0x1838>
    c248:      	adrp	x1, 0x4000
    c24c:      	add	x1, x1, #0xc53
    c250:      	adrp	x2, 0x5000
    c254:      	add	x2, x2, #0x435
    c258:      	mov	w0, #0x6                // =6
    c25c:      	bl	0x10d40 <__android_log_print@plt>
    c260:      	b	0xc390 <_ZN13VLLogMediator8testDataEv+0x182c>
    c264:      	adrp	x1, 0x4000
    c268:      	add	x1, x1, #0xc53
    c26c:      	adrp	x2, 0x4000
    c270:      	add	x2, x2, #0x722
    c274:      	mov	w0, #0x6                // =6
    c278:      	bl	0x10d40 <__android_log_print@plt>
    c27c:      	b	0xc304 <_ZN13VLLogMediator8testDataEv+0x17a0>
    c280:      	adrp	x1, 0x4000
    c284:      	add	x1, x1, #0xc53
    c288:      	adrp	x2, 0x4000
    c28c:      	add	x2, x2, #0x660
    c290:      	mov	w0, #0x6                // =6
    c294:      	bl	0x10d40 <__android_log_print@plt>
    c298:      	ldur	x0, [x29, #-0x10]
    c29c:      	ldr	x8, [x0]
    c2a0:      	ldr	x8, [x8, #0xb8]
    c2a4:      	mov	x1, x20
    c2a8:      	blr	x8
    c2ac:      	ldur	x0, [x29, #-0x10]
    c2b0:      	ldr	x8, [x0]
    c2b4:      	ldr	x8, [x8, #0xb8]
    c2b8:      	mov	x1, x19
    c2bc:      	blr	x8
    c2c0:      	ldurb	w8, [x29, #-0x14]
    c2c4:      	cbz	w8, 0xc2cc <_ZN13VLLogMediator8testDataEv+0x1768>
    c2c8:      	bl	0xc780 <_ZN13VLLogMediator8testDataEv+0x1c1c>
    c2cc:      	nop
    c2d0:      	adr	x0, 0x19870
    c2d4:      	b	0xc240 <_ZN13VLLogMediator8testDataEv+0x16dc>
    c2d8:      	adrp	x1, 0x4000
    c2dc:      	add	x1, x1, #0xc53
    c2e0:      	adrp	x2, 0x4000
    c2e4:      	add	x2, x2, #0x741
    c2e8:      	mov	w0, #0x6                // =6
    c2ec:      	bl	0x10d40 <__android_log_print@plt>
    c2f0:      	ldur	x0, [x29, #-0x10]
    c2f4:      	mov	x1, x20
    c2f8:      	ldr	x8, [x0]
    c2fc:      	ldr	x8, [x8, #0xb8]
    c300:      	blr	x8
    c304:      	ldur	x0, [x29, #-0x10]
    c308:      	mov	x1, x19
    c30c:      	b	0xc384 <_ZN13VLLogMediator8testDataEv+0x1820>
    c310:      	adrp	x1, 0x4000
    c314:      	add	x1, x1, #0xc53
    c318:      	adrp	x2, 0x5000
    c31c:      	add	x2, x2, #0x6a
    c320:      	mov	w0, #0x6                // =6
    c324:      	bl	0x10d40 <__android_log_print@plt>
    c328:      	ldur	x0, [x29, #-0x10]
    c32c:      	ldp	x22, x21, [sp, #0x8]
    c330:      	mov	x1, x24
    c334:      	ldr	x8, [x0]
    c338:      	ldr	x8, [x8, #0xb8]
    c33c:      	blr	x8
    c340:      	ldur	x0, [x29, #-0x10]
    c344:      	mov	x1, x21
    c348:      	ldr	x8, [x0]
    c34c:      	ldr	x8, [x8, #0xb8]
    c350:      	blr	x8
    c354:      	ldur	x0, [x29, #-0x10]
    c358:      	mov	x1, x23
    c35c:      	ldr	x8, [x0]
    c360:      	ldr	x8, [x8, #0xb8]
    c364:      	blr	x8
    c368:      	ldur	x0, [x29, #-0x10]
    c36c:      	mov	x1, x19
    c370:      	ldr	x8, [x0]
    c374:      	ldr	x8, [x8, #0xb8]
    c378:      	blr	x8
    c37c:      	ldur	x0, [x29, #-0x10]
    c380:      	mov	x1, x20
    c384:      	ldr	x8, [x0]
    c388:      	ldr	x8, [x8, #0xb8]
    c38c:      	blr	x8
    c390:      	ldurb	w8, [x29, #-0x14]
    c394:      	cbz	w8, 0xc39c <_ZN13VLLogMediator8testDataEv+0x1838>
    c398:      	bl	0xc780 <_ZN13VLLogMediator8testDataEv+0x1c1c>
    c39c:      	ldr	x8, [x22, #0x28]
    c3a0:      	ldur	x9, [x29, #-0x8]
    c3a4:      	cmp	x8, x9
    c3a8:      	b.ne	0xc404 <_ZN13VLLogMediator8testDataEv+0x18a0>
    c3ac:      	ldp	x20, x19, [sp, #0xb0]
    c3b0:      	ldp	x22, x21, [sp, #0xa0]
    c3b4:      	ldp	x24, x23, [sp, #0x90]
    c3b8:      	ldp	x26, x25, [sp, #0x80]
    c3bc:      	ldp	x28, x27, [sp, #0x70]
    c3c0:      	ldp	x29, x30, [sp, #0x60]
    c3c4:      	add	sp, sp, #0xc0
    c3c8:      	ret
    c3cc:      	mov	x19, x0
    c3d0:      	nop
    c3d4:      	adr	x0, 0x19870
    c3d8:      	b	0xc3e8 <_ZN13VLLogMediator8testDataEv+0x1884>
    c3dc:      	mov	x19, x0
    c3e0:      	nop
    c3e4:      	adr	x0, 0x19848
    c3e8:      	bl	0x10b50 <_ZNSt6__ndk15mutex6unlockEv@plt>
    c3ec:      	ldr	x8, [x22, #0x28]
    c3f0:      	ldur	x9, [x29, #-0x8]
    c3f4:      	cmp	x8, x9
    c3f8:      	b.ne	0xc404 <_ZN13VLLogMediator8testDataEv+0x18a0>
    c3fc:      	mov	x0, x19
    c400:      	bl	0xca4c <JNI_OnUnload+0x1cc>
    c404:      	bl	0x10840 <__stack_chk_fail@plt>
    c408:      	sub	sp, sp, #0x120
    c40c:      	stp	x29, x30, [sp, #0x100]
    c410:      	stp	x28, x19, [sp, #0x110]
    c414:      	add	x29, sp, #0x100
    c418:      	stp	x3, x4, [x29, #-0x78]
    c41c:      	sub	x9, x29, #0x78
    c420:      	mov	x10, sp
    c424:      	stp	x5, x6, [x29, #-0x68]
    c428:      	add	x10, x10, #0x80
    c42c:      	sub	x3, x29, #0x50
    c430:      	stur	x7, [x29, #-0x58]
    c434:      	stp	q0, q1, [sp]
    c438:      	stp	q2, q3, [sp, #0x20]
    c43c:      	stp	q4, q5, [sp, #0x40]
    c440:      	stp	q6, q7, [sp, #0x60]
    c444:      	mrs	x19, TPIDR_EL0
    c448:      	ldr	x8, [x19, #0x28]
    c44c:      	stur	x8, [x29, #-0x8]
    c450:      	add	x8, x9, #0x28
    c454:      	add	x9, x29, #0x20
    c458:      	stp	x9, x8, [x29, #-0x28]
    c45c:      	mov	x8, #-0x28              // =-40
    c460:      	sub	x9, x29, #0x28
    c464:      	movk	x8, #0xff80, lsl #32
    c468:      	stp	x10, x8, [x29, #-0x18]
    c46c:      	ldr	x8, [x0]
    c470:      	ldp	q0, q1, [x9]
    c474:      	ldr	x8, [x8, #0xe8]
    c478:      	stp	q0, q1, [x29, #-0x50]
    c47c:      	blr	x8
    c480:      	ldr	x8, [x19, #0x28]
    c484:      	ldur	x9, [x29, #-0x8]
    c488:      	cmp	x8, x9
    c48c:      	b.ne	0xc4a0 <_ZN13VLLogMediator8testDataEv+0x193c>
    c490:      	ldp	x28, x19, [sp, #0x110]
    c494:      	ldp	x29, x30, [sp, #0x100]
    c498:      	add	sp, sp, #0x120
    c49c:      	ret
    c4a0:      	bl	0x10840 <__stack_chk_fail@plt>
    c4a4:      	sub	sp, sp, #0x120
    c4a8:      	stp	x29, x30, [sp, #0x100]
    c4ac:      	stp	x28, x19, [sp, #0x110]
    c4b0:      	add	x29, sp, #0x100
    c4b4:      	stp	x3, x4, [x29, #-0x78]
    c4b8:      	sub	x9, x29, #0x78
    c4bc:      	mov	x10, sp
    c4c0:      	stp	x5, x6, [x29, #-0x68]
    c4c4:      	add	x10, x10, #0x80
    c4c8:      	sub	x3, x29, #0x50
    c4cc:      	stur	x7, [x29, #-0x58]
    c4d0:      	stp	q0, q1, [sp]
    c4d4:      	stp	q2, q3, [sp, #0x20]
    c4d8:      	stp	q4, q5, [sp, #0x40]
    c4dc:      	stp	q6, q7, [sp, #0x60]
    c4e0:      	mrs	x19, TPIDR_EL0
    c4e4:      	ldr	x8, [x19, #0x28]
    c4e8:      	stur	x8, [x29, #-0x8]
    c4ec:      	add	x8, x9, #0x28
    c4f0:      	add	x9, x29, #0x20
    c4f4:      	stp	x9, x8, [x29, #-0x28]
    c4f8:      	mov	x8, #-0x28              // =-40
    c4fc:      	sub	x9, x29, #0x28
    c500:      	movk	x8, #0xff80, lsl #32
    c504:      	stp	x10, x8, [x29, #-0x18]
    c508:      	ldr	x8, [x0]
    c50c:      	ldp	q0, q1, [x9]
    c510:      	ldr	x8, [x8, #0x130]
    c514:      	stp	q0, q1, [x29, #-0x50]
    c518:      	blr	x8
    c51c:      	ldr	x8, [x19, #0x28]
    c520:      	ldur	x9, [x29, #-0x8]
    c524:      	cmp	x8, x9
    c528:      	b.ne	0xc53c <_ZN13VLLogMediator8testDataEv+0x19d8>
    c52c:      	ldp	x28, x19, [sp, #0x110]
    c530:      	ldp	x29, x30, [sp, #0x100]
    c534:      	add	sp, sp, #0x120
    c538:      	ret
    c53c:      	bl	0x10840 <__stack_chk_fail@plt>
    c540:      	sub	sp, sp, #0x120
    c544:      	stp	x29, x30, [sp, #0x100]
    c548:      	stp	x28, x19, [sp, #0x110]
    c54c:      	add	x29, sp, #0x100
    c550:      	stp	x3, x4, [x29, #-0x78]
    c554:      	sub	x9, x29, #0x78
    c558:      	mov	x10, sp
    c55c:      	stp	x5, x6, [x29, #-0x68]
    c560:      	add	x10, x10, #0x80
    c564:      	sub	x3, x29, #0x50
    c568:      	stur	x7, [x29, #-0x58]
    c56c:      	stp	q0, q1, [sp]
    c570:      	stp	q2, q3, [sp, #0x20]
    c574:      	stp	q4, q5, [sp, #0x40]
    c578:      	stp	q6, q7, [sp, #0x60]
    c57c:      	mrs	x19, TPIDR_EL0
    c580:      	ldr	x8, [x19, #0x28]
    c584:      	stur	x8, [x29, #-0x8]
    c588:      	add	x8, x9, #0x28
    c58c:      	add	x9, x29, #0x20
    c590:      	stp	x9, x8, [x29, #-0x28]
    c594:      	mov	x8, #-0x28              // =-40
    c598:      	sub	x9, x29, #0x28
    c59c:      	movk	x8, #0xff80, lsl #32
    c5a0:      	stp	x10, x8, [x29, #-0x18]
    c5a4:      	ldr	x8, [x0]
    c5a8:      	ldp	q0, q1, [x9]
    c5ac:      	ldr	x8, [x8, #0x118]
    c5b0:      	stp	q0, q1, [x29, #-0x50]
    c5b4:      	blr	x8
    c5b8:      	ldr	x8, [x19, #0x28]
    c5bc:      	ldur	x9, [x29, #-0x8]
    c5c0:      	cmp	x8, x9
    c5c4:      	b.ne	0xc5d8 <_ZN13VLLogMediator8testDataEv+0x1a74>
    c5c8:      	ldp	x28, x19, [sp, #0x110]
    c5cc:      	ldp	x29, x30, [sp, #0x100]
    c5d0:      	add	sp, sp, #0x120
    c5d4:      	ret
    c5d8:      	bl	0x10840 <__stack_chk_fail@plt>
    c5dc:      	stp	x29, x30, [sp, #-0x20]!
    c5e0:      	stp	x20, x19, [sp, #0x10]
    c5e4:      	mov	x29, sp
    c5e8:      	adrp	x19, 0x15000
    c5ec:      	nop
    c5f0:      	adr	x20, 0x14de0
    c5f4:      	ldr	x19, [x19, #0x1d8]
    c5f8:      	nop
    c5fc:      	adr	x1, 0x19848
    c600:      	mov	x2, x20
    c604:      	mov	x0, x19
    c608:      	bl	0x10740 <__cxa_atexit@plt>
    c60c:      	nop
    c610:      	adr	x1, 0x19870
    c614:      	mov	x0, x19
    c618:      	mov	x2, x20
    c61c:      	ldp	x20, x19, [sp, #0x10]
    c620:      	ldp	x29, x30, [sp], #0x20
    c624:      	b	0x10740 <__cxa_atexit@plt>
    c628:      	stp	x29, x30, [sp, #-0x10]!
    c62c:      	mov	x29, sp
    c630:      	mov	x0, x2
    c634:      	bl	0xafac <_ZN13VLLogMediator8testDataEv+0x448>
    c638:      	tbnz	w0, #0x1f, 0xc648 <_ZN13VLLogMediator8testDataEv+0x1ae4>
    c63c:      	mov	w0, #0x6                // =6
    c640:      	movk	w0, #0x1, lsl #16
    c644:      	b	0xc664 <_ZN13VLLogMediator8testDataEv+0x1b00>
    c648:      	nop
    c64c:      	adr	x1, 0x4c53
    c650:      	adrp	x2, 0x4000
    c654:      	add	x2, x2, #0xd27
    c658:      	mov	w0, #0x6                // =6
    c65c:      	bl	0x10d40 <__android_log_print@plt>
    c660:      	mov	w0, #-0x1               // =-1
    c664:      	ldp	x29, x30, [sp], #0x10
    c668:      	ret
    c66c:      	mov	x8, x0
    c670:      	nop
    c674:      	adr	x1, 0x4c53
    c678:      	adrp	x9, 0x19000
    c67c:      	adrp	x2, 0x4000
    c680:      	add	x2, x2, #0xa31
    c684:      	mov	w0, #0x3                // =3
    c688:      	str	x8, [x9, #0x8a8]
    c68c:      	b	0x10d40 <__android_log_print@plt>
    c690:      	stp	x29, x30, [sp, #-0x30]!
    c694:      	str	x21, [sp, #0x10]
    c698:      	stp	x20, x19, [sp, #0x20]
    c69c:      	mov	x29, sp
    c6a0:      	adrp	x21, 0x19000
    c6a4:      	str	xzr, [x0]
    c6a8:      	mov	x20, x0
    c6ac:      	ldr	x0, [x21, #0x8a8]
    c6b0:      	strb	wzr, [x1]
    c6b4:      	cbz	x0, 0xc718 <_ZN13VLLogMediator8testDataEv+0x1bb4>
    c6b8:      	ldr	x8, [x0]
    c6bc:      	mov	w2, #0x6                // =6
    c6c0:      	mov	x19, x1
    c6c4:      	mov	x1, x20
    c6c8:      	movk	w2, #0x1, lsl #16
    c6cc:      	ldr	x8, [x8, #0x30]
    c6d0:      	blr	x8
    c6d4:      	cmn	w0, #0x3
    c6d8:      	b.eq	0xc734 <_ZN13VLLogMediator8testDataEv+0x1bd0>
    c6dc:      	cbz	w0, 0xc72c <_ZN13VLLogMediator8testDataEv+0x1bc8>
    c6e0:      	cmn	w0, #0x2
    c6e4:      	b.ne	0xc748 <_ZN13VLLogMediator8testDataEv+0x1be4>
    c6e8:      	ldr	x0, [x21, #0x8a8]
    c6ec:      	mov	x1, x20
    c6f0:      	mov	x2, xzr
    c6f4:      	ldr	x8, [x0]
    c6f8:      	ldr	x8, [x8, #0x20]
    c6fc:      	blr	x8
    c700:      	cbz	w0, 0xc774 <_ZN13VLLogMediator8testDataEv+0x1c10>
    c704:      	nop
    c708:      	adr	x1, 0x4c53
    c70c:      	adrp	x2, 0x4000
    c710:      	add	x2, x2, #0x7a7
    c714:      	b	0xc758 <_ZN13VLLogMediator8testDataEv+0x1bf4>
    c718:      	nop
    c71c:      	adr	x1, 0x4c53
    c720:      	adrp	x2, 0x4000
    c724:      	add	x2, x2, #0xa57
    c728:      	b	0xc758 <_ZN13VLLogMediator8testDataEv+0x1bf4>
    c72c:      	mov	w0, #0x1                // =1
    c730:      	b	0xc764 <_ZN13VLLogMediator8testDataEv+0x1c00>
    c734:      	nop
    c738:      	adr	x1, 0x4c53
    c73c:      	adrp	x2, 0x5000
    c740:      	add	x2, x2, #0x778
    c744:      	b	0xc758 <_ZN13VLLogMediator8testDataEv+0x1bf4>
    c748:      	nop
    c74c:      	adr	x1, 0x4c53
    c750:      	adrp	x2, 0x5000
    c754:      	add	x2, x2, #0x79d
    c758:      	mov	w0, #0x6                // =6
    c75c:      	bl	0x10d40 <__android_log_print@plt>
    c760:      	mov	w0, wzr
    c764:      	ldp	x20, x19, [sp, #0x20]
    c768:      	ldr	x21, [sp, #0x10]
    c76c:      	ldp	x29, x30, [sp], #0x30
    c770:      	ret
    c774:      	mov	w0, #0x1                // =1
    c778:      	strb	w0, [x19]
    c77c:      	b	0xc764 <_ZN13VLLogMediator8testDataEv+0x1c00>
    c780:      	adrp	x8, 0x19000
    c784:      	ldr	x0, [x8, #0x8a8]
    c788:      	cbz	x0, 0xc798 <_ZN13VLLogMediator8testDataEv+0x1c34>
    c78c:      	ldr	x8, [x0]
    c790:      	ldr	x1, [x8, #0x28]
    c794:      	br	x1
    c798:      	ret

000000000000c79c <JNI_OnLoad>:
    c79c:      	sub	sp, sp, #0x40
    c7a0:      	stp	x29, x30, [sp, #0x10]
    c7a4:      	stp	x22, x21, [sp, #0x20]
    c7a8:      	stp	x20, x19, [sp, #0x30]
    c7ac:      	add	x29, sp, #0x10
    c7b0:      	mrs	x22, TPIDR_EL0
    c7b4:      	mov	x20, x1
    c7b8:      	mov	x21, x0
    c7bc:      	ldr	x8, [x22, #0x28]
    c7c0:      	mov	w19, #0x6               // =6
    c7c4:      	nop
    c7c8:      	adr	x1, 0x4c53
    c7cc:      	adrp	x2, 0x5000
    c7d0:      	add	x2, x2, #0x97
    c7d4:      	mov	w0, #0x3                // =3
    c7d8:      	str	x8, [sp, #0x8]
    c7dc:      	movk	w19, #0x1, lsl #16
    c7e0:      	bl	0x10d40 <__android_log_print@plt>
    c7e4:      	mov	x0, x21
    c7e8:      	bl	0xc66c <_ZN13VLLogMediator8testDataEv+0x1b08>
    c7ec:      	ldr	x8, [x21]
    c7f0:      	mov	w2, #0x6                // =6
    c7f4:      	mov	x1, sp
    c7f8:      	mov	x0, x21
    c7fc:      	movk	w2, #0x1, lsl #16
    c800:      	str	xzr, [sp]
    c804:      	ldr	x8, [x8, #0x30]
    c808:      	blr	x8
    c80c:      	cbz	w0, 0xc830 <JNI_OnLoad+0x94>
    c810:      	adrp	x2, 0x5000
    c814:      	add	x2, x2, #0x467
    c818:      	nop
    c81c:      	adr	x1, 0x4c53
    c820:      	mov	w0, #0x6                // =6
    c824:      	bl	0x10d40 <__android_log_print@plt>
    c828:      	mov	w19, #-0x1              // =-1
    c82c:      	b	0xc848 <JNI_OnLoad+0xac>
    c830:      	ldr	x2, [sp]
    c834:      	mov	x0, x21
    c838:      	mov	x1, x20
    c83c:      	bl	0xc628 <_ZN13VLLogMediator8testDataEv+0x1ac4>
    c840:      	cmn	w0, #0x1
    c844:      	b.eq	0xc870 <JNI_OnLoad+0xd4>
    c848:      	ldr	x8, [x22, #0x28]
    c84c:      	ldr	x9, [sp, #0x8]
    c850:      	cmp	x8, x9
    c854:      	b.ne	0xc87c <JNI_OnLoad+0xe0>
    c858:      	mov	w0, w19
    c85c:      	ldp	x20, x19, [sp, #0x30]
    c860:      	ldp	x22, x21, [sp, #0x20]
    c864:      	ldp	x29, x30, [sp, #0x10]
    c868:      	add	sp, sp, #0x40
    c86c:      	ret
    c870:      	adrp	x2, 0x4000
    c874:      	add	x2, x2, #0xe25
    c878:      	b	0xc818 <JNI_OnLoad+0x7c>
    c87c:      	bl	0x10840 <__stack_chk_fail@plt>

000000000000c880 <JNI_OnUnload>:
    c880:      	sub	sp, sp, #0x30
    c884:      	stp	x29, x30, [sp, #0x10]
    c888:      	stp	x20, x19, [sp, #0x20]
    c88c:      	add	x29, sp, #0x10
    c890:      	mrs	x20, TPIDR_EL0
    c894:      	mov	x19, x0
    c898:      	nop
    c89c:      	adr	x1, 0x4c53
    c8a0:      	ldr	x8, [x20, #0x28]
    c8a4:      	adrp	x2, 0x4000
    c8a8:      	add	x2, x2, #0xbc6
    c8ac:      	mov	w0, #0x3                // =3
    c8b0:      	str	x8, [sp, #0x8]
    c8b4:      	bl	0x10d40 <__android_log_print@plt>
    c8b8:      	ldr	x8, [x19]
    c8bc:      	mov	w2, #0x6                // =6
    c8c0:      	mov	x1, sp
    c8c4:      	mov	x0, x19
    c8c8:      	movk	w2, #0x1, lsl #16
    c8cc:      	str	xzr, [sp]
    c8d0:      	ldr	x8, [x8, #0x30]
    c8d4:      	blr	x8
    c8d8:      	cbz	w0, 0xc8f4 <JNI_OnUnload+0x74>
    c8dc:      	nop
    c8e0:      	adr	x1, 0x4c53
    c8e4:      	adrp	x2, 0x5000
    c8e8:      	add	x2, x2, #0x952
    c8ec:      	mov	w0, #0x6                // =6
    c8f0:      	bl	0x10d40 <__android_log_print@plt>
    c8f4:      	ldr	x8, [x20, #0x28]
    c8f8:      	ldr	x9, [sp, #0x8]
    c8fc:      	cmp	x8, x9
    c900:      	b.ne	0xc914 <JNI_OnUnload+0x94>
    c904:      	ldp	x20, x19, [sp, #0x20]
    c908:      	ldp	x29, x30, [sp, #0x10]
    c90c:      	add	sp, sp, #0x30
    c910:      	ret
    c914:      	bl	0x10840 <__stack_chk_fail@plt>
    c918:      	paciasp
    c91c:      	sub	sp, sp, #0x80
    c920:      	stp	x29, x30, [sp, #0x50]
    c924:      	stp	x22, x21, [sp, #0x60]
    c928:      	stp	x20, x19, [sp, #0x70]
    c92c:      	add	x29, sp, #0x50
    c930:      	mov	x19, x1
    c934:      	mov	x1, x0
    c938:      	mov	x20, x2
    c93c:      	mov	x0, x19
    c940:      	bl	0xcbc4 <JNI_OnUnload+0x344>
    c944:      	mov	x0, x19
    c948:      	bl	0xcce8 <JNI_OnUnload+0x468>
    c94c:      	cbz	w0, 0xca04 <JNI_OnUnload+0x184>
    c950:      	mov	w21, #0x2               // =2
    c954:      	mov	w22, #0x6               // =6
    c958:      	b	0xc968 <JNI_OnUnload+0xe8>
    c95c:      	mov	x0, x19
    c960:      	bl	0xcce8 <JNI_OnUnload+0x468>
    c964:      	cbz	w0, 0xca04 <JNI_OnUnload+0x184>
    c968:      	tbnz	w0, #0x1f, 0xca30 <JNI_OnUnload+0x1b0>
    c96c:      	sub	x2, x29, #0x8
    c970:      	mov	x0, x19
    c974:      	mov	w1, #-0x2               // =-2
    c978:      	bl	0xcc6c <JNI_OnUnload+0x3ec>
    c97c:      	mov	x1, sp
    c980:      	mov	x0, x19
    c984:      	bl	0xccfc <JNI_OnUnload+0x47c>
    c988:      	cbnz	w0, 0xca30 <JNI_OnUnload+0x1b0>
    c98c:      	ldr	x8, [sp, #0x18]
    c990:      	cbz	x8, 0xc95c <JNI_OnUnload+0xdc>
    c994:      	ldur	x9, [x29, #-0x8]
    c998:      	ldr	x10, [x20, #0x18]
    c99c:      	mov	w0, #0x1                // =1
    c9a0:      	ldr	x2, [x20]
    c9a4:      	mov	x3, x20
    c9a8:      	mov	x4, x19
    c9ac:      	cmp	x9, x10
    c9b0:      	csel	w1, w22, w21, eq
    c9b4:      	blr	x8
    c9b8:      	cmp	w0, #0x8
    c9bc:      	b.ne	0xca20 <JNI_OnUnload+0x1a0>
    c9c0:      	ldur	x8, [x29, #-0x8]
    c9c4:      	ldr	x9, [x20, #0x18]
    c9c8:      	cmp	x8, x9
    c9cc:      	b.ne	0xc95c <JNI_OnUnload+0xdc>
    c9d0:      	adrp	x19, 0x15000
    c9d4:      	nop
    c9d8:      	adr	x1, 0x4677
    c9dc:      	ldr	x19, [x19, #0x1e0]
    c9e0:      	adrp	x2, 0x4000
    c9e4:      	add	x2, x2, #0xdac
    c9e8:      	adrp	x3, 0x5000
    c9ec:      	add	x3, x3, #0x204
    c9f0:      	add	x0, x19, #0x130
    c9f4:      	bl	0x10d50 <fprintf@plt>
    c9f8:      	add	x0, x19, #0x130
    c9fc:      	bl	0x10d60 <fflush@plt>
    ca00:      	bl	0x10d70 <abort@plt>
    ca04:      	mov	w0, #0x5                // =5
    ca08:      	ldp	x20, x19, [sp, #0x70]
    ca0c:      	ldp	x22, x21, [sp, #0x60]
    ca10:      	ldp	x29, x30, [sp, #0x50]
    ca14:      	add	sp, sp, #0x80
    ca18:      	autiasp
    ca1c:      	ret
    ca20:      	cmp	w0, #0x7
    ca24:      	b.ne	0xca30 <JNI_OnUnload+0x1b0>
    ca28:      	mov	x0, x19
    ca2c:      	bl	0xcd3c <JNI_OnUnload+0x4bc>
    ca30:      	mov	w0, #0x2                // =2
    ca34:      	ldp	x20, x19, [sp, #0x70]
    ca38:      	ldp	x22, x21, [sp, #0x60]
    ca3c:      	ldp	x29, x30, [sp, #0x50]
    ca40:      	add	sp, sp, #0x80
    ca44:      	autiasp
    ca48:      	ret
    ca4c:      	paciasp
    ca50:      	stp	x29, x30, [sp, #-0x20]!
    ca54:      	stp	x28, x19, [sp, #0x10]
    ca58:      	mov	x29, sp
    ca5c:      	sub	sp, sp, #0x480
    ca60:      	mov	x19, x0
    ca64:      	add	x0, sp, #0x270
    ca68:      	bl	0x10670 <JNI_OnUnload+0x3df0>
    ca6c:      	ldr	x3, [x19, #0x10]
    ca70:      	cbnz	x3, 0xca88 <JNI_OnUnload+0x208>
    ca74:      	add	x0, sp, #0x270
    ca78:      	mov	x1, sp
    ca7c:      	mov	x2, x19
    ca80:      	bl	0xc918 <JNI_OnUnload+0x98>
    ca84:      	b	0xca9c <JNI_OnUnload+0x21c>
    ca88:      	ldr	x4, [x19, #0x18]
    ca8c:      	add	x0, sp, #0x270
    ca90:      	mov	x1, sp
    ca94:      	mov	x2, x19
    ca98:      	bl	0xcad0 <JNI_OnUnload+0x250>
    ca9c:      	adrp	x19, 0x15000
    caa0:      	nop
    caa4:      	adr	x1, 0x4677
    caa8:      	ldr	x19, [x19, #0x1e0]
    caac:      	adrp	x2, 0x5000
    cab0:      	add	x2, x2, #0x7ca
    cab4:      	adrp	x3, 0x4000
    cab8:      	add	x3, x3, #0x928
    cabc:      	add	x0, x19, #0x130
    cac0:      	bl	0x10d50 <fprintf@plt>
    cac4:      	add	x0, x19, #0x130
    cac8:      	bl	0x10d60 <fflush@plt>
    cacc:      	bl	0x10d70 <abort@plt>
    cad0:      	paciasp
    cad4:      	sub	sp, sp, #0x80
    cad8:      	stp	x29, x30, [sp, #0x50]
    cadc:      	stp	x22, x21, [sp, #0x60]
    cae0:      	stp	x20, x19, [sp, #0x70]
    cae4:      	add	x29, sp, #0x50
    cae8:      	mov	x21, x1
    caec:      	mov	x1, x0
    caf0:      	mov	x20, x4
    caf4:      	mov	x0, x21
    caf8:      	mov	x19, x3
    cafc:      	mov	x22, x2
    cb00:      	bl	0xcbc4 <JNI_OnUnload+0x344>
    cb04:      	mov	x0, x21
    cb08:      	bl	0xcce8 <JNI_OnUnload+0x468>
    cb0c:      	cmp	w0, #0x1
    cb10:      	b.ge	0xcb58 <JNI_OnUnload+0x2d8>
    cb14:      	ldr	x2, [x22]
    cb18:      	mov	w0, #0x1                // =1
    cb1c:      	mov	w1, #0x1a               // =26
    cb20:      	mov	x3, x22
    cb24:      	mov	x4, x21
    cb28:      	mov	x5, x20
    cb2c:      	blr	x19
    cb30:      	ldp	x20, x19, [sp, #0x70]
    cb34:      	ldp	x22, x21, [sp, #0x60]
    cb38:      	ldp	x29, x30, [sp, #0x50]
    cb3c:      	add	sp, sp, #0x80
    cb40:      	autiasp
    cb44:      	ret
    cb48:      	mov	x0, x21
    cb4c:      	bl	0xcce8 <JNI_OnUnload+0x468>
    cb50:      	cmp	w0, #0x0
    cb54:      	b.le	0xcb14 <JNI_OnUnload+0x294>
    cb58:      	add	x1, sp, #0x8
    cb5c:      	mov	x0, x21
    cb60:      	bl	0xccfc <JNI_OnUnload+0x47c>
    cb64:      	cbnz	w0, 0xcb30 <JNI_OnUnload+0x2b0>
    cb68:      	ldr	x2, [x22]
    cb6c:      	mov	w0, #0x1                // =1
    cb70:      	mov	w1, #0xa                // =10
    cb74:      	mov	x3, x22
    cb78:      	mov	x4, x21
    cb7c:      	mov	x5, x20
    cb80:      	blr	x19
    cb84:      	cbnz	w0, 0xcb30 <JNI_OnUnload+0x2b0>
    cb88:      	ldr	x8, [sp, #0x20]
    cb8c:      	cbz	x8, 0xcb48 <JNI_OnUnload+0x2c8>
    cb90:      	ldr	x2, [x22]
    cb94:      	mov	w0, #0x1                // =1
    cb98:      	mov	w1, #0xa                // =10
    cb9c:      	mov	x3, x22
    cba0:      	mov	x4, x21
    cba4:      	blr	x8
    cba8:      	cmp	w0, #0x8
    cbac:      	b.eq	0xcb48 <JNI_OnUnload+0x2c8>
    cbb0:      	cmp	w0, #0x7
    cbb4:      	b.ne	0xcb30 <JNI_OnUnload+0x2b0>
    cbb8:      	mov	x0, x21
    cbbc:      	bl	0xcd3c <JNI_OnUnload+0x4bc>
    cbc0:      	b	0xcb48 <JNI_OnUnload+0x2c8>
    cbc4:      	paciasp
    cbc8:      	stp	x29, x30, [sp, #-0x20]!
    cbcc:      	stp	x20, x19, [sp, #0x10]
    cbd0:      	mov	x29, sp
    cbd4:      	adrp	x8, 0x14000 <syscall@plt+0x3230>
    cbd8:      	add	x8, x8, #0xf00
    cbdc:      	nop
    cbe0:      	adr	x9, 0x198b0
    cbe4:      	mov	w2, #0x110              // =272
    cbe8:      	mov	x20, x1
    cbec:      	mov	x19, x0
    cbf0:      	stp	x8, x9, [x0], #0x10
    cbf4:      	bl	0x10890 <memcpy@plt>
    cbf8:      	ldp	q1, q0, [x20, #0x130]
    cbfc:      	add	x8, x19, #0x220
    cc00:      	ldp	q3, q2, [x20, #0x110]
    cc04:      	mov	x0, x19
    cc08:      	mov	w1, wzr
    cc0c:      	stp	q1, q0, [x19, #0x140]
    cc10:      	stp	q3, q2, [x19, #0x120]
    cc14:      	ldp	q1, q0, [x20, #0x170]
    cc18:      	ldp	q3, q2, [x20, #0x150]
    cc1c:      	stp	q1, q0, [x19, #0x180]
    cc20:      	stp	q3, q2, [x19, #0x160]
    cc24:      	ldp	q1, q0, [x20, #0x1b0]
    cc28:      	ldp	q3, q2, [x20, #0x190]
    cc2c:      	stp	q1, q0, [x19, #0x1c0]
    cc30:      	stp	q3, q2, [x19, #0x1a0]
    cc34:      	movi	v2.2d, #0000000000000000
    cc38:      	ldp	q1, q0, [x20, #0x1f0]
    cc3c:      	ldp	q4, q3, [x20, #0x1d0]
    cc40:      	stp	q1, q0, [x19, #0x200]
    cc44:      	stp	q4, q3, [x19, #0x1e0]
    cc48:      	stur	q2, [x8, #0x3b]
    cc4c:      	stp	q2, q2, [x19, #0x220]
    cc50:      	stp	q2, q2, [x19, #0x240]
    cc54:      	bl	0xd58c <JNI_OnUnload+0xd0c>
    cc58:      	mov	w0, wzr
    cc5c:      	ldp	x20, x19, [sp, #0x10]
    cc60:      	ldp	x29, x30, [sp], #0x20
    cc64:      	autiasp
    cc68:      	ret
    cc6c:      	paciasp
    cc70:      	stp	x29, x30, [sp, #-0x30]!
    cc74:      	str	x21, [sp, #0x10]
    cc78:      	stp	x20, x19, [sp, #0x20]
    cc7c:      	mov	x29, sp
    cc80:      	ldr	x8, [x0]
    cc84:      	mov	x19, x2
    cc88:      	mov	x20, x0
    cc8c:      	mov	w21, w1
    cc90:      	ldr	x8, [x8, #0x10]
    cc94:      	blr	x8
    cc98:      	tbz	w0, #0x0, 0xccd0 <JNI_OnUnload+0x450>
    cc9c:      	ldr	x8, [x20]
    cca0:      	mov	x0, x20
    cca4:      	mov	w1, w21
    cca8:      	ldr	x8, [x8, #0x18]
    ccac:      	blr	x8
    ccb0:      	mov	x8, x0
    ccb4:      	mov	w0, wzr
    ccb8:      	str	x8, [x19]
    ccbc:      	ldp	x20, x19, [sp, #0x20]
    ccc0:      	ldr	x21, [sp, #0x10]
    ccc4:      	ldp	x29, x30, [sp], #0x30
    ccc8:      	autiasp
    cccc:      	ret
    ccd0:      	mov	w0, #-0x198e            // =-6542
    ccd4:      	ldp	x20, x19, [sp, #0x20]
    ccd8:      	ldr	x21, [sp, #0x10]
    ccdc:      	ldp	x29, x30, [sp], #0x30
    cce0:      	autiasp
    cce4:      	ret
    cce8:      	bti	c
    ccec:      	ldr	x8, [x0]
    ccf0:      	mov	w1, #0x1                // =1
    ccf4:      	ldr	x16, [x8, #0x40]
    ccf8:      	br	x16
    ccfc:      	paciasp
    cd00:      	stp	x29, x30, [sp, #-0x20]!
    cd04:      	str	x19, [sp, #0x10]
    cd08:      	mov	x29, sp
    cd0c:      	ldr	x8, [x0]
    cd10:      	mov	x19, x1
    cd14:      	ldr	x8, [x8, #0x48]
    cd18:      	blr	x8
    cd1c:      	ldr	x8, [x19, #0x8]
    cd20:      	cmp	x8, #0x0
    cd24:      	mov	w8, #-0x1995            // =-6549
    cd28:      	csel	w0, w8, wzr, eq
    cd2c:      	ldr	x19, [sp, #0x10]
    cd30:      	ldp	x29, x30, [sp], #0x20
    cd34:      	autiasp
    cd38:      	ret
    cd3c:      	paciasp
    cd40:      	stp	x29, x30, [sp, #-0x10]!
    cd44:      	mov	x29, sp
    cd48:      	ldr	x8, [x0]
    cd4c:      	ldr	x8, [x8, #0x50]
    cd50:      	blr	x8
    cd54:      	mov	w0, #-0x198c            // =-6540
    cd58:      	ldp	x29, x30, [sp], #0x10
    cd5c:      	autiasp
    cd60:      	ret
    cd64:      	paciasp
    cd68:      	stp	x29, x30, [sp, #-0x60]!
    cd6c:      	str	x27, [sp, #0x10]
    cd70:      	stp	x26, x25, [sp, #0x20]
    cd74:      	stp	x24, x23, [sp, #0x30]
    cd78:      	stp	x22, x21, [sp, #0x40]
    cd7c:      	stp	x20, x19, [sp, #0x50]
    cd80:      	mov	x29, sp
    cd84:      	mov	x23, x1
    cd88:      	mov	x20, x3
    cd8c:      	mov	x19, x2
    cd90:      	ldr	w22, [x23], #0x4
    cd94:      	mov	x21, x0
    cd98:      	cmn	w22, #0x1
    cd9c:      	b.eq	0xcdd0 <JNI_OnUnload+0x550>
    cda0:      	cbz	x22, 0xcddc <JNI_OnUnload+0x55c>
    cda4:      	ldr	w8, [x23]
    cda8:      	cbz	w8, 0xcde8 <JNI_OnUnload+0x568>
    cdac:      	mov	x25, x1
    cdb0:      	sub	x1, x23, x8
    cdb4:      	tbz	w4, #0x0, 0xcdf4 <JNI_OnUnload+0x574>
    cdb8:      	ldr	x8, [x20]
    cdbc:      	cmp	x8, x1
    cdc0:      	b.eq	0xce04 <JNI_OnUnload+0x584>
    cdc4:      	adrp	x0, 0x5000
    cdc8:      	add	x0, x0, #0x837
    cdcc:      	b	0xced4 <JNI_OnUnload+0x654>
    cdd0:      	ldur	x22, [x1, #0x4]
    cdd4:      	add	x23, x1, #0xc
    cdd8:      	cbnz	x22, 0xcda4 <JNI_OnUnload+0x524>
    cddc:      	adrp	x0, 0x4000
    cde0:      	add	x0, x0, #0xb12
    cde4:      	b	0xced4 <JNI_OnUnload+0x654>
    cde8:      	adrp	x0, 0x4000
    cdec:      	add	x0, x0, #0xf40
    cdf0:      	b	0xced4 <JNI_OnUnload+0x654>
    cdf4:      	mov	x0, x21
    cdf8:      	mov	x2, x20
    cdfc:      	bl	0xcef4 <JNI_OnUnload+0x674>
    ce00:      	cbnz	x0, 0xced4 <JNI_OnUnload+0x654>
    ce04:      	ldrb	w3, [x20, #0x18]
    ce08:      	add	x22, x23, x22
    ce0c:      	add	x8, x23, #0x4
    ce10:      	add	x1, x29, #0x18
    ce14:      	mov	x0, x21
    ce18:      	mov	x2, x22
    ce1c:      	mov	x4, xzr
    ce20:      	str	x8, [x29, #0x18]
    ce24:      	bl	0xed4c <JNI_OnUnload+0x24cc>
    ce28:      	ldrb	w8, [x20, #0x18]
    ce2c:      	mov	x23, x0
    ce30:      	add	x1, x29, #0x18
    ce34:      	mov	x0, x21
    ce38:      	mov	x2, x22
    ce3c:      	mov	x4, xzr
    ce40:      	and	w3, w8, #0xf
    ce44:      	bl	0xed4c <JNI_OnUnload+0x24cc>
    ce48:      	ldrb	w8, [x20, #0x31]
    ce4c:      	mov	x24, x0
    ce50:      	str	xzr, [x19, #0x28]
    ce54:      	cbz	w8, 0xceb8 <JNI_OnUnload+0x638>
    ce58:      	add	x0, x29, #0x18
    ce5c:      	mov	x1, x22
    ce60:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    ce64:      	ldrb	w8, [x20, #0x19]
    ce68:      	ldr	x27, [x29, #0x18]
    ce6c:      	cmp	w8, #0xff
    ce70:      	add	x26, x27, x0
    ce74:      	b.eq	0xcebc <JNI_OnUnload+0x63c>
    ce78:      	add	x1, x29, #0x18
    ce7c:      	and	w3, w8, #0xf
    ce80:      	mov	x0, x21
    ce84:      	mov	x2, x22
    ce88:      	mov	x4, xzr
    ce8c:      	bl	0xed4c <JNI_OnUnload+0x24cc>
    ce90:      	cbz	x0, 0xcebc <JNI_OnUnload+0x63c>
    ce94:      	ldrb	w3, [x20, #0x19]
    ce98:      	add	x1, x29, #0x18
    ce9c:      	mov	x0, x21
    cea0:      	mov	x2, x22
    cea4:      	mov	x4, xzr
    cea8:      	str	x27, [x29, #0x18]
    ceac:      	bl	0xed4c <JNI_OnUnload+0x24cc>
    ceb0:      	str	x0, [x19, #0x28]
    ceb4:      	b	0xcebc <JNI_OnUnload+0x63c>
    ceb8:      	ldr	x26, [x29, #0x18]
    cebc:      	sub	x8, x22, x25
    cec0:      	mov	x0, xzr
    cec4:      	stp	x26, x23, [x19, #0x10]
    cec8:      	stp	x25, x8, [x19]
    cecc:      	add	x8, x24, x23
    ced0:      	str	x8, [x19, #0x20]
    ced4:      	ldp	x20, x19, [sp, #0x50]
    ced8:      	ldr	x27, [sp, #0x10]
    cedc:      	ldp	x22, x21, [sp, #0x40]
    cee0:      	ldp	x24, x23, [sp, #0x30]
    cee4:      	ldp	x26, x25, [sp, #0x20]
    cee8:      	ldp	x29, x30, [sp], #0x60
    ceec:      	autiasp
    cef0:      	ret
    cef4:      	paciasp
    cef8:      	sub	sp, sp, #0x50
    cefc:      	stp	x29, x30, [sp, #0x10]
    cf00:      	stp	x24, x23, [sp, #0x20]
    cf04:      	stp	x22, x21, [sp, #0x30]
    cf08:      	stp	x20, x19, [sp, #0x40]
    cf0c:      	add	x29, sp, #0x10
    cf10:      	movi	d0, #0x00ff000000ff00
    cf14:      	sturh	wzr, [x2, #0x33]
    cf18:      	mov	x8, x1
    cf1c:      	stp	xzr, xzr, [x2, #0x20]
    cf20:      	mov	x19, x2
    cf24:      	mov	x20, x1
    cf28:      	strh	wzr, [x2, #0x30]
    cf2c:      	mov	x21, x0
    cf30:      	str	x1, [x2]
    cf34:      	str	s0, [x2, #0x18]
    cf38:      	ldr	w9, [x8], #0x4
    cf3c:      	cmn	w9, #0x1
    cf40:      	b.eq	0xcf60 <JNI_OnUnload+0x6e0>
    cf44:      	add	x22, x8, x9
    cf48:      	cbz	x9, 0xcf70 <JNI_OnUnload+0x6f0>
    cf4c:      	ldr	w9, [x8]
    cf50:      	cbz	w9, 0xcf78 <JNI_OnUnload+0x6f8>
    cf54:      	adrp	x0, 0x5000
    cf58:      	add	x0, x0, #0x81d
    cf5c:      	b	0xd16c <JNI_OnUnload+0x8ec>
    cf60:      	ldur	x9, [x20, #0x4]
    cf64:      	add	x8, x20, #0xc
    cf68:      	add	x22, x9, x8
    cf6c:      	cbnz	x9, 0xcf4c <JNI_OnUnload+0x6cc>
    cf70:      	mov	x0, xzr
    cf74:      	b	0xd16c <JNI_OnUnload+0x8ec>
    cf78:      	ldrb	w24, [x8, #0x4]
    cf7c:      	and	w9, w24, #0xfffffffd
    cf80:      	cmp	w9, #0x1
    cf84:      	b.ne	0xd030 <JNI_OnUnload+0x7b0>
    cf88:      	add	x23, x8, #0x5
    cf8c:      	mov	x8, x23
    cf90:      	ldrb	w9, [x8], #0x1
    cf94:      	cbnz	w9, 0xcf90 <JNI_OnUnload+0x710>
    cf98:      	add	x0, sp, #0x8
    cf9c:      	mov	x1, x22
    cfa0:      	str	x8, [sp, #0x8]
    cfa4:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    cfa8:      	ldr	x8, [sp, #0x8]
    cfac:      	mov	x11, xzr
    cfb0:      	mov	x9, xzr
    cfb4:      	str	w0, [x19, #0x28]
    cfb8:      	mov	x10, x8
    cfbc:      	cmp	x10, x22
    cfc0:      	b.eq	0xd188 <JNI_OnUnload+0x908>
    cfc4:      	ldrb	w12, [x10], #0x1
    cfc8:      	add	x8, x8, #0x1
    cfcc:      	and	x13, x12, #0x7f
    cfd0:      	lsl	x13, x13, x11
    cfd4:      	add	x11, x11, #0x7
    cfd8:      	orr	x9, x13, x9
    cfdc:      	tbnz	w12, #0x7, 0xcfbc <JNI_OnUnload+0x73c>
    cfe0:      	sub	w13, w11, #0x7
    cfe4:      	mov	x14, #-0x1              // =-1
    cfe8:      	str	x8, [sp, #0x8]
    cfec:      	cmp	w13, #0x39
    cff0:      	mov	w13, #0x3f              // =63
    cff4:      	lsl	x11, x14, x11
    cff8:      	ccmp	w12, w13, #0x0, lo
    cffc:      	csel	w11, w11, wzr, hi
    d000:      	cmp	w24, #0x1
    d004:      	orr	w9, w9, w11
    d008:      	str	w9, [x19, #0x2c]
    d00c:      	b.ne	0xd03c <JNI_OnUnload+0x7bc>
    d010:      	add	x8, x8, #0x1
    d014:      	str	x8, [sp, #0x8]
    d018:      	ldrb	w0, [x10]
    d01c:      	strb	w0, [x19, #0x32]
    d020:      	ldrb	w8, [x23]
    d024:      	cmp	w8, #0x7a
    d028:      	b.eq	0xd058 <JNI_OnUnload+0x7d8>
    d02c:      	b	0xd158 <JNI_OnUnload+0x8d8>
    d030:      	adrp	x0, 0x4000
    d034:      	add	x0, x0, #0x8c5
    d038:      	b	0xd16c <JNI_OnUnload+0x8ec>
    d03c:      	add	x0, sp, #0x8
    d040:      	mov	x1, x22
    d044:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    d048:      	strb	w0, [x19, #0x32]
    d04c:      	ldrb	w8, [x23]
    d050:      	cmp	w8, #0x7a
    d054:      	b.ne	0xd158 <JNI_OnUnload+0x8d8>
    d058:      	add	x0, sp, #0x8
    d05c:      	mov	x1, x22
    d060:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    d064:      	mov	w24, #0x1               // =1
    d068:      	b	0xd074 <JNI_OnUnload+0x7f4>
    d06c:      	strb	w24, [x19, #0x30]
    d070:      	add	x23, x23, #0x1
    d074:      	ldrb	w8, [x23]
    d078:      	cmp	w8, #0x4f
    d07c:      	b.le	0xd0b0 <JNI_OnUnload+0x830>
    d080:      	cmp	w8, #0x52
    d084:      	b.gt	0xd0e0 <JNI_OnUnload+0x860>
    d088:      	cmp	w8, #0x50
    d08c:      	b.eq	0xd11c <JNI_OnUnload+0x89c>
    d090:      	cmp	w8, #0x52
    d094:      	b.ne	0xd114 <JNI_OnUnload+0x894>
    d098:      	ldr	x8, [sp, #0x8]
    d09c:      	add	x23, x23, #0x1
    d0a0:      	ldrb	w9, [x8], #0x1
    d0a4:      	str	x8, [sp, #0x8]
    d0a8:      	strb	w9, [x19, #0x18]
    d0ac:      	b	0xd074 <JNI_OnUnload+0x7f4>
    d0b0:      	cmp	w8, #0x46
    d0b4:      	b.le	0xd0fc <JNI_OnUnload+0x87c>
    d0b8:      	cmp	w8, #0x47
    d0bc:      	b.eq	0xd110 <JNI_OnUnload+0x890>
    d0c0:      	cmp	w8, #0x4c
    d0c4:      	b.ne	0xd114 <JNI_OnUnload+0x894>
    d0c8:      	ldr	x8, [sp, #0x8]
    d0cc:      	add	x23, x23, #0x1
    d0d0:      	ldrb	w9, [x8], #0x1
    d0d4:      	str	x8, [sp, #0x8]
    d0d8:      	strb	w9, [x19, #0x19]
    d0dc:      	b	0xd074 <JNI_OnUnload+0x7f4>
    d0e0:      	cmp	w8, #0x53
    d0e4:      	b.eq	0xd06c <JNI_OnUnload+0x7ec>
    d0e8:      	cmp	w8, #0x7a
    d0ec:      	b.ne	0xd114 <JNI_OnUnload+0x894>
    d0f0:      	strb	w24, [x19, #0x31]
    d0f4:      	add	x23, x23, #0x1
    d0f8:      	b	0xd074 <JNI_OnUnload+0x7f4>
    d0fc:      	cmp	w8, #0x42
    d100:      	b.ne	0xd154 <JNI_OnUnload+0x8d4>
    d104:      	strb	w24, [x19, #0x33]
    d108:      	add	x23, x23, #0x1
    d10c:      	b	0xd074 <JNI_OnUnload+0x7f4>
    d110:      	strb	w24, [x19, #0x34]
    d114:      	add	x23, x23, #0x1
    d118:      	b	0xd074 <JNI_OnUnload+0x7f4>
    d11c:      	ldr	x8, [sp, #0x8]
    d120:      	add	x1, sp, #0x8
    d124:      	mov	x0, x21
    d128:      	mov	x2, x22
    d12c:      	mov	x4, xzr
    d130:      	ldrb	w3, [x8], #0x1
    d134:      	str	x8, [sp, #0x8]
    d138:      	sub	w8, w8, w20
    d13c:      	strb	w3, [x19, #0x1a]
    d140:      	strb	w8, [x19, #0x1b]
    d144:      	bl	0xed4c <JNI_OnUnload+0x24cc>
    d148:      	str	x0, [x19, #0x20]
    d14c:      	add	x23, x23, #0x1
    d150:      	b	0xd074 <JNI_OnUnload+0x7f4>
    d154:      	cbnz	w8, 0xd114 <JNI_OnUnload+0x894>
    d158:      	ldr	x8, [x19]
    d15c:      	ldr	x9, [sp, #0x8]
    d160:      	mov	x0, xzr
    d164:      	sub	x8, x22, x8
    d168:      	stp	x8, x9, [x19, #0x8]
    d16c:      	ldp	x20, x19, [sp, #0x40]
    d170:      	ldp	x22, x21, [sp, #0x30]
    d174:      	ldp	x24, x23, [sp, #0x20]
    d178:      	ldp	x29, x30, [sp, #0x10]
    d17c:      	add	sp, sp, #0x50
    d180:      	autiasp
    d184:      	ret
    d188:      	adrp	x19, 0x15000
    d18c:      	nop
    d190:      	adr	x1, 0x4677
    d194:      	ldr	x19, [x19, #0x1e0]
    d198:      	adrp	x2, 0x5000
    d19c:      	add	x2, x2, #0x19c
    d1a0:      	adrp	x3, 0x4000
    d1a4:      	add	x3, x3, #0xc76
    d1a8:      	add	x0, x19, #0x130
    d1ac:      	bl	0x10d50 <fprintf@plt>
    d1b0:      	add	x0, x19, #0x130
    d1b4:      	bl	0x10d60 <fflush@plt>
    d1b8:      	bl	0x10d70 <abort@plt>
    d1bc:      	bti	c
    d1c0:      	ret
    d1c4:      	bti	c
    d1c8:      	ret
    d1cc:      	bti	c
    d1d0:      	cmn	w1, #0x3
    d1d4:      	b.ls	0xd1e0 <JNI_OnUnload+0x960>
    d1d8:      	mov	w0, #0x1                // =1
    d1dc:      	ret
    d1e0:      	cmp	w1, #0x5f
    d1e4:      	b.ls	0xd1f0 <JNI_OnUnload+0x970>
    d1e8:      	mov	w0, wzr
    d1ec:      	ret
    d1f0:      	cmp	w1, #0x22
    d1f4:      	b.ne	0xd200 <JNI_OnUnload+0x980>
    d1f8:      	mov	w0, #0x1                // =1
    d1fc:      	ret
    d200:      	sub	w8, w1, #0x40
    d204:      	cmn	w8, #0x1f
    d208:      	cset	w0, lo
    d20c:      	ret
    d210:      	bti	c
    d214:      	cmp	w1, #0x1d
    d218:      	b.le	0xd238 <JNI_OnUnload+0x9b8>
    d21c:      	cmp	w1, #0x1f
    d220:      	b.gt	0xd25c <JNI_OnUnload+0x9dc>
    d224:      	cmp	w1, #0x1e
    d228:      	b.eq	0xd29c <JNI_OnUnload+0xa1c>
    d22c:      	cmp	w1, #0x1f
    d230:      	b.eq	0xd278 <JNI_OnUnload+0x9f8>
    d234:      	b	0xd284 <JNI_OnUnload+0xa04>
    d238:      	cmn	w1, #0x2
    d23c:      	b.eq	0xd278 <JNI_OnUnload+0x9f8>
    d240:      	cmn	w1, #0x1
    d244:      	b.eq	0xd26c <JNI_OnUnload+0x9ec>
    d248:      	cmp	w1, #0x1d
    d24c:      	b.ne	0xd284 <JNI_OnUnload+0xa04>
    d250:      	add	x8, x0, #0xf8
    d254:      	ldr	x0, [x8]
    d258:      	ret
    d25c:      	cmp	w1, #0x22
    d260:      	b.eq	0xd2a8 <JNI_OnUnload+0xa28>
    d264:      	cmp	w1, #0x20
    d268:      	b.ne	0xd284 <JNI_OnUnload+0xa04>
    d26c:      	add	x8, x0, #0x110
    d270:      	ldr	x0, [x8]
    d274:      	ret
    d278:      	add	x8, x0, #0x108
    d27c:      	ldr	x0, [x8]
    d280:      	ret
    d284:      	cmp	w1, #0x1c
    d288:      	b.hi	0xd2b4 <JNI_OnUnload+0xa34>
    d28c:      	add	x8, x0, #0x10
    d290:      	add	x8, x8, w1, uxtw #3
    d294:      	ldr	x0, [x8]
    d298:      	ret
    d29c:      	add	x8, x0, #0x100
    d2a0:      	ldr	x0, [x8]
    d2a4:      	ret
    d2a8:      	add	x8, x0, #0x118
    d2ac:      	ldr	x0, [x8]
    d2b0:      	ret
    d2b4:      	paciasp
    d2b8:      	stp	x29, x30, [sp, #-0x20]!
    d2bc:      	str	x19, [sp, #0x10]
    d2c0:      	mov	x29, sp
    d2c4:      	adrp	x19, 0x15000
    d2c8:      	nop
    d2cc:      	adr	x1, 0x4677
    d2d0:      	ldr	x19, [x19, #0x1e0]
    d2d4:      	adrp	x2, 0x4000
    d2d8:      	add	x2, x2, #0xf2c
    d2dc:      	adrp	x3, 0x4000
    d2e0:      	add	x3, x3, #0xbfc
    d2e4:      	add	x0, x19, #0x130
    d2e8:      	bl	0x10d50 <fprintf@plt>
    d2ec:      	add	x0, x19, #0x130
    d2f0:      	bl	0x10d60 <fflush@plt>
    d2f4:      	bl	0x10d70 <abort@plt>
    d2f8:      	bti	c
    d2fc:      	cmp	w1, #0x1d
    d300:      	b.le	0xd320 <JNI_OnUnload+0xaa0>
    d304:      	cmp	w1, #0x1f
    d308:      	b.gt	0xd344 <JNI_OnUnload+0xac4>
    d30c:      	cmp	w1, #0x1e
    d310:      	b.eq	0xd384 <JNI_OnUnload+0xb04>
    d314:      	cmp	w1, #0x1f
    d318:      	b.eq	0xd360 <JNI_OnUnload+0xae0>
    d31c:      	b	0xd36c <JNI_OnUnload+0xaec>
    d320:      	cmn	w1, #0x2
    d324:      	b.eq	0xd360 <JNI_OnUnload+0xae0>
    d328:      	cmn	w1, #0x1
    d32c:      	b.eq	0xd354 <JNI_OnUnload+0xad4>
    d330:      	cmp	w1, #0x1d
    d334:      	b.ne	0xd36c <JNI_OnUnload+0xaec>
    d338:      	add	x8, x0, #0xf8
    d33c:      	str	x2, [x8]
    d340:      	ret
    d344:      	cmp	w1, #0x22
    d348:      	b.eq	0xd390 <JNI_OnUnload+0xb10>
    d34c:      	cmp	w1, #0x20
    d350:      	b.ne	0xd36c <JNI_OnUnload+0xaec>
    d354:      	add	x8, x0, #0x110
    d358:      	str	x2, [x8]
    d35c:      	ret
    d360:      	add	x8, x0, #0x108
    d364:      	str	x2, [x8]
    d368:      	ret
    d36c:      	cmp	w1, #0x1c
    d370:      	b.hi	0xd39c <JNI_OnUnload+0xb1c>
    d374:      	add	x8, x0, #0x10
    d378:      	add	x8, x8, w1, uxtw #3
    d37c:      	str	x2, [x8]
    d380:      	ret
    d384:      	add	x8, x0, #0x100
    d388:      	str	x2, [x8]
    d38c:      	ret
    d390:      	add	x8, x0, #0x118
    d394:      	str	x2, [x8]
    d398:      	ret
    d39c:      	paciasp
    d3a0:      	stp	x29, x30, [sp, #-0x20]!
    d3a4:      	str	x19, [sp, #0x10]
    d3a8:      	mov	x29, sp
    d3ac:      	adrp	x19, 0x15000
    d3b0:      	nop
    d3b4:      	adr	x1, 0x4677
    d3b8:      	ldr	x19, [x19, #0x1e0]
    d3bc:      	adrp	x2, 0x5000
    d3c0:      	add	x2, x2, #0x325
    d3c4:      	adrp	x3, 0x4000
    d3c8:      	add	x3, x3, #0xbfc
    d3cc:      	add	x0, x19, #0x130
    d3d0:      	bl	0x10d50 <fprintf@plt>
    d3d4:      	add	x0, x19, #0x130
    d3d8:      	bl	0x10d60 <fflush@plt>
    d3dc:      	bl	0x10d70 <abort@plt>
    d3e0:      	bti	c
    d3e4:      	and	w8, w1, #0xffffffe0
    d3e8:      	cmp	w8, #0x40
    d3ec:      	cset	w0, eq
    d3f0:      	ret
    d3f4:      	bti	c
    d3f8:      	add	x8, x0, w1, sxtw #3
    d3fc:      	ldur	d0, [x8, #-0xe0]
    d400:      	ret
    d404:      	bti	c
    d408:      	add	x8, x0, w1, sxtw #3
    d40c:      	stur	d0, [x8, #-0xe0]
    d410:      	ret
    d414:      	bti	c
    d418:      	ldrb	w8, [x0, #0x268]
    d41c:      	cbz	w8, 0xd428 <JNI_OnUnload+0xba8>
    d420:      	mov	w0, wzr
    d424:      	ret
    d428:      	paciasp
    d42c:      	stp	x29, x30, [sp, #-0x30]!
    d430:      	stp	x28, x21, [sp, #0x10]
    d434:      	stp	x20, x19, [sp, #0x20]
    d438:      	mov	x29, sp
    d43c:      	sub	sp, sp, #0x210
    d440:      	ldrb	w8, [x0, #0x26a]
    d444:      	mov	x19, x0
    d448:      	cbz	w8, 0xd488 <JNI_OnUnload+0xc08>
    d44c:      	mov	x0, sp
    d450:      	mov	w1, wzr
    d454:      	mov	w2, #0x210              // =528
    d458:      	bl	0x109a0 <memset@plt>
    d45c:      	mov	x1, sp
    d460:      	mov	x0, x19
    d464:      	bl	0xd818 <JNI_OnUnload+0xf98>
    d468:      	cmp	w0, #0x1
    d46c:      	b.eq	0xd4c4 <JNI_OnUnload+0xc44>
    d470:      	add	sp, sp, #0x210
    d474:      	ldp	x20, x19, [sp, #0x20]
    d478:      	ldp	x28, x21, [sp, #0x10]
    d47c:      	ldp	x29, x30, [sp], #0x30
    d480:      	autiasp
    d484:      	ret
    d488:      	ldp	x8, x20, [x19]
    d48c:      	mov	x0, x19
    d490:      	mov	w21, w1
    d494:      	mov	w1, #-0x1               // =-1
    d498:      	ldr	x8, [x8, #0x18]
    d49c:      	blr	x8
    d4a0:      	ldr	x2, [x19, #0x258]
    d4a4:      	mov	x1, x0
    d4a8:      	add	x3, x19, #0x10
    d4ac:      	add	x4, x19, #0x269
    d4b0:      	and	w5, w21, #0x1
    d4b4:      	mov	x0, x20
    d4b8:      	bl	0xd938 <JNI_OnUnload+0x10b8>
    d4bc:      	cmp	w0, #0x1
    d4c0:      	b.ne	0xd470 <JNI_OnUnload+0xbf0>
    d4c4:      	ldr	x8, [x19]
    d4c8:      	mov	w20, w0
    d4cc:      	mov	x0, x19
    d4d0:      	mov	w1, #0x1                // =1
    d4d4:      	ldr	x8, [x8, #0x68]
    d4d8:      	blr	x8
    d4dc:      	ldrb	w8, [x19, #0x268]
    d4e0:      	mov	w0, w20
    d4e4:      	cbz	w8, 0xd470 <JNI_OnUnload+0xbf0>
    d4e8:      	mov	w0, wzr
    d4ec:      	add	sp, sp, #0x210
    d4f0:      	ldp	x20, x19, [sp, #0x20]
    d4f4:      	ldp	x28, x21, [sp, #0x10]
    d4f8:      	ldp	x29, x30, [sp], #0x30
    d4fc:      	autiasp
    d500:      	ret
    d504:      	bti	c
    d508:      	ldrb	w8, [x0, #0x268]
    d50c:      	cbz	w8, 0xd524 <JNI_OnUnload+0xca4>
    d510:      	movi	v0.2d, #0000000000000000
    d514:      	str	xzr, [x1, #0x40]
    d518:      	stp	q0, q0, [x1]
    d51c:      	stp	q0, q0, [x1, #0x20]
    d520:      	ret
    d524:      	ldr	q0, [x0, #0x220]
    d528:      	str	q0, [x1]
    d52c:      	ldp	q2, q0, [x0, #0x240]
    d530:      	ldr	x8, [x0, #0x260]
    d534:      	ldr	q1, [x0, #0x230]
    d538:      	str	x8, [x1, #0x40]
    d53c:      	stp	q2, q0, [x1, #0x20]
    d540:      	str	q1, [x1, #0x10]
    d544:      	ret
    d548:      	bti	c
    d54c:      	add	x0, x0, #0x10
    d550:      	b	0x105e0 <JNI_OnUnload+0x3d60>
    d554:      	bti	c
    d558:      	ldrb	w0, [x0, #0x269]
    d55c:      	ret
    d560:      	paciasp
    d564:      	stp	x29, x30, [sp, #-0x10]!
    d568:      	mov	x29, sp
    d56c:      	ldr	x8, [x0]
    d570:      	mov	w1, #-0x1               // =-1
    d574:      	ldr	x8, [x8, #0x18]
    d578:      	blr	x8
    d57c:      	mov	w0, wzr
    d580:      	ldp	x29, x30, [sp], #0x10
    d584:      	autiasp
    d588:      	ret
    d58c:      	paciasp
    d590:      	stp	x29, x30, [sp, #-0x30]!
    d594:      	stp	x28, x21, [sp, #0x10]
    d598:      	stp	x20, x19, [sp, #0x20]
    d59c:      	mov	x29, sp
    d5a0:      	sub	sp, sp, #0x6b0
    d5a4:      	ldr	x8, [x0]
    d5a8:      	strb	wzr, [x0, #0x26a]
    d5ac:      	mov	w20, w1
    d5b0:      	mov	w1, #-0x1               // =-1
    d5b4:      	mov	x19, x0
    d5b8:      	ldr	x8, [x8, #0x18]
    d5bc:      	blr	x8
    d5c0:      	cbz	x0, 0xd7d0 <JNI_OnUnload+0xf50>
    d5c4:      	ldr	x8, [x19, #0x8]
    d5c8:      	and	x9, x20, #0x1
    d5cc:      	add	x10, sp, #0x68
    d5d0:      	sub	x20, x0, x9
    d5d4:      	nop
    d5d8:      	adr	x0, 0xff30 <JNI_OnUnload+0x36b0>
    d5dc:      	add	x1, sp, #0x98
    d5e0:      	stp	x8, x10, [sp, #0x98]
    d5e4:      	str	x20, [sp, #0xa8]
    d5e8:      	bl	0x10da0 <dl_iterate_phdr@plt>
    d5ec:      	cbz	w0, 0xd610 <JNI_OnUnload+0xd90>
    d5f0:      	ldr	x8, [sp, #0x78]
    d5f4:      	cbz	x8, 0xd610 <JNI_OnUnload+0xd90>
    d5f8:      	add	x2, sp, #0x68
    d5fc:      	mov	x0, x19
    d600:      	mov	x1, x20
    d604:      	mov	w3, wzr
    d608:      	bl	0xfc5c <JNI_OnUnload+0x33dc>
    d60c:      	tbnz	w0, #0x0, 0xd7b8 <JNI_OnUnload+0xf38>
    d610:      	nop
    d614:      	adr	x0, 0x198b4
    d618:      	bl	0x10db0 <pthread_rwlock_rdlock@plt>
    d61c:      	adrp	x8, 0x19000
    d620:      	adrp	x9, 0x19000
    d624:      	ldr	x8, [x8, #0x660]
    d628:      	ldr	x9, [x9, #0x668]
    d62c:      	b	0xd634 <JNI_OnUnload+0xdb4>
    d630:      	add	x8, x8, #0x20
    d634:      	cmp	x8, x9
    d638:      	b.hs	0xd708 <JNI_OnUnload+0xe88>
    d63c:      	ldr	x10, [x8, #0x8]
    d640:      	cmp	x10, x20
    d644:      	b.hi	0xd630 <JNI_OnUnload+0xdb0>
    d648:      	ldr	x10, [x8, #0x10]
    d64c:      	cmp	x10, x20
    d650:      	b.ls	0xd630 <JNI_OnUnload+0xdb0>
    d654:      	ldr	x21, [x8, #0x18]
    d658:      	nop
    d65c:      	adr	x0, 0x198b4
    d660:      	bl	0x10d90 <pthread_rwlock_unlock@plt>
    d664:      	cbz	x21, 0xd714 <JNI_OnUnload+0xe94>
    d668:      	ldr	x0, [x19, #0x8]
    d66c:      	add	x2, sp, #0x38
    d670:      	mov	x3, sp
    d674:      	mov	x1, x21
    d678:      	mov	w4, wzr
    d67c:      	bl	0xcd64 <JNI_OnUnload+0x4e4>
    d680:      	cbnz	x0, 0xd714 <JNI_OnUnload+0xe94>
    d684:      	add	x0, sp, #0x98
    d688:      	mov	w1, wzr
    d68c:      	mov	w2, #0x618              // =1560
    d690:      	bl	0x109a0 <memset@plt>
    d694:      	ldr	x0, [x19, #0x8]
    d698:      	add	x1, sp, #0x38
    d69c:      	mov	x2, sp
    d6a0:      	add	x5, sp, #0x98
    d6a4:      	mov	x3, x20
    d6a8:      	mov	w4, #0x4                // =4
    d6ac:      	bl	0xddc0 <JNI_OnUnload+0x1540>
    d6b0:      	tbz	w0, #0x0, 0xd714 <JNI_OnUnload+0xe94>
    d6b4:      	ldr	x8, [sp, #0x60]
    d6b8:      	ldr	x9, [sp, #0x20]
    d6bc:      	ldur	q0, [sp, #0x50]
    d6c0:      	str	xzr, [x19, #0x248]
    d6c4:      	str	x8, [x19, #0x230]
    d6c8:      	ldr	w8, [sp, #0xa8]
    d6cc:      	str	x9, [x19, #0x238]
    d6d0:      	mov	w9, #0x3000000          // =50331648
    d6d4:      	str	x8, [x19, #0x240]
    d6d8:      	str	w9, [x19, #0x250]
    d6dc:      	ldp	x8, x9, [sp, #0x38]
    d6e0:      	str	q0, [x19, #0x220]
    d6e4:      	str	xzr, [x19, #0x260]
    d6e8:      	str	x8, [x19, #0x258]
    d6ec:      	str	w9, [x19, #0x254]
    d6f0:      	add	sp, sp, #0x6b0
    d6f4:      	ldp	x20, x19, [sp, #0x20]
    d6f8:      	ldp	x28, x21, [sp, #0x10]
    d6fc:      	ldp	x29, x30, [sp], #0x30
    d700:      	autiasp
    d704:      	ret
    d708:      	nop
    d70c:      	adr	x0, 0x198b4
    d710:      	bl	0x10d90 <pthread_rwlock_unlock@plt>
    d714:      	ldr	x8, [x19]
    d718:      	mov	x0, x19
    d71c:      	mov	w1, #-0x1               // =-1
    d720:      	ldr	x8, [x8, #0x18]
    d724:      	blr	x8
    d728:      	add	x8, sp, #0x38
    d72c:      	mov	w9, #0x8                // =8
    d730:      	mov	x20, x0
    d734:      	stp	x8, x9, [sp, #0x98]
    d738:      	stp	x0, x9, [sp]
    d73c:      	bl	0x10dc0 <getpid@plt>
    d740:      	mov	w1, w0
    d744:      	add	x2, sp, #0x98
    d748:      	mov	x4, sp
    d74c:      	mov	w0, #0x10e              // =270
    d750:      	mov	w3, #0x1                // =1
    d754:      	mov	w5, #0x1                // =1
    d758:      	mov	w6, wzr
    d75c:      	mov	w21, #0x1               // =1
    d760:      	bl	0x10dd0 <syscall@plt>
    d764:      	cmp	x0, #0x8
    d768:      	b.ne	0xd7f0 <JNI_OnUnload+0xf70>
    d76c:      	ldr	w8, [sp, #0x38]
    d770:      	mov	w9, #0x1168             // =4456
    d774:      	movk	w9, #0xd280, lsl #16
    d778:      	cmp	w8, w9
    d77c:      	b.ne	0xd7f0 <JNI_OnUnload+0xf70>
    d780:      	ldr	w8, [sp, #0x3c]
    d784:      	mov	w9, #0x1                // =1
    d788:      	movk	w9, #0xd400, lsl #16
    d78c:      	cmp	w8, w9
    d790:      	b.ne	0xd7f0 <JNI_OnUnload+0xf70>
    d794:      	movi	v0.2d, #0000000000000000
    d798:      	add	x8, x20, #0x4
    d79c:      	str	xzr, [x19, #0x260]
    d7a0:      	str	x8, [x19, #0x228]
    d7a4:      	mov	w8, #0x1                // =1
    d7a8:      	str	x20, [x19, #0x220]
    d7ac:      	strb	w8, [x19, #0x26a]
    d7b0:      	stp	q0, q0, [x19, #0x240]
    d7b4:      	str	q0, [x19, #0x230]
    d7b8:      	add	sp, sp, #0x6b0
    d7bc:      	ldp	x20, x19, [sp, #0x20]
    d7c0:      	ldp	x28, x21, [sp, #0x10]
    d7c4:      	ldp	x29, x30, [sp], #0x30
    d7c8:      	autiasp
    d7cc:      	ret
    d7d0:      	mov	w8, #0x1                // =1
    d7d4:      	strb	w8, [x19, #0x268]
    d7d8:      	add	sp, sp, #0x6b0
    d7dc:      	ldp	x20, x19, [sp, #0x20]
    d7e0:      	ldp	x28, x21, [sp, #0x10]
    d7e4:      	ldp	x29, x30, [sp], #0x30
    d7e8:      	autiasp
    d7ec:      	ret
    d7f0:      	strb	w21, [x19, #0x268]
    d7f4:      	add	sp, sp, #0x6b0
    d7f8:      	ldp	x20, x19, [sp, #0x20]
    d7fc:      	ldp	x28, x21, [sp, #0x10]
    d800:      	ldp	x29, x30, [sp], #0x30
    d804:      	autiasp
    d808:      	ret
    d80c:      	bti	c
    d810:      	mov	w0, w1
    d814:      	b	0x105b0 <JNI_OnUnload+0x3d30>
    d818:      	bti	c
    d81c:      	ldr	x10, [x0, #0x108]
    d820:      	mov	w9, #0x1                // =1
    d824:      	ldr	x11, [x10, #0x138]
    d828:      	str	x11, [x0, #0x10]
    d82c:      	ldr	x11, [x10, #0x140]
    d830:      	str	x11, [x0, #0x18]
    d834:      	ldr	x11, [x10, #0x148]
    d838:      	str	x11, [x0, #0x20]
    d83c:      	ldr	x11, [x10, #0x150]
    d840:      	str	x11, [x0, #0x28]
    d844:      	ldr	x11, [x10, #0x158]
    d848:      	str	x11, [x0, #0x30]
    d84c:      	ldr	x11, [x10, #0x160]
    d850:      	str	x11, [x0, #0x38]
    d854:      	ldr	x11, [x10, #0x168]
    d858:      	str	x11, [x0, #0x40]
    d85c:      	ldr	x11, [x10, #0x170]
    d860:      	str	x11, [x0, #0x48]
    d864:      	ldr	x11, [x10, #0x178]
    d868:      	str	x11, [x0, #0x50]
    d86c:      	ldr	x11, [x10, #0x180]
    d870:      	str	x11, [x0, #0x58]
    d874:      	ldr	x11, [x10, #0x188]
    d878:      	str	x11, [x0, #0x60]
    d87c:      	ldr	x11, [x10, #0x190]
    d880:      	str	x11, [x0, #0x68]
    d884:      	ldr	x11, [x10, #0x198]
    d888:      	str	x11, [x0, #0x70]
    d88c:      	ldr	x11, [x10, #0x1a0]
    d890:      	str	x11, [x0, #0x78]
    d894:      	ldr	x11, [x10, #0x1a8]
    d898:      	str	x11, [x0, #0x80]
    d89c:      	ldr	x11, [x10, #0x1b0]
    d8a0:      	str	x11, [x0, #0x88]
    d8a4:      	ldr	x11, [x10, #0x1b8]
    d8a8:      	str	x11, [x0, #0x90]
    d8ac:      	ldr	x11, [x10, #0x1c0]
    d8b0:      	str	x11, [x0, #0x98]
    d8b4:      	ldr	x11, [x10, #0x1c8]
    d8b8:      	str	x11, [x0, #0xa0]
    d8bc:      	ldr	x11, [x10, #0x1d0]
    d8c0:      	str	x11, [x0, #0xa8]
    d8c4:      	ldr	x11, [x10, #0x1d8]
    d8c8:      	str	x11, [x0, #0xb0]
    d8cc:      	ldr	x11, [x10, #0x1e0]
    d8d0:      	str	x11, [x0, #0xb8]
    d8d4:      	ldr	x11, [x10, #0x1e8]
    d8d8:      	str	x11, [x0, #0xc0]
    d8dc:      	ldr	x11, [x10, #0x1f0]
    d8e0:      	str	x11, [x0, #0xc8]
    d8e4:      	ldr	x11, [x10, #0x1f8]
    d8e8:      	str	x11, [x0, #0xd0]
    d8ec:      	ldr	x11, [x10, #0x200]
    d8f0:      	str	x11, [x0, #0xd8]
    d8f4:      	ldr	x11, [x10, #0x208]
    d8f8:      	str	x11, [x0, #0xe0]
    d8fc:      	ldr	x11, [x10, #0x210]
    d900:      	str	x11, [x0, #0xe8]
    d904:      	ldr	x11, [x10, #0x218]
    d908:      	str	x11, [x0, #0xf0]
    d90c:      	ldr	x11, [x10, #0x220]
    d910:      	str	x11, [x0, #0xf8]
    d914:      	ldr	x11, [x10, #0x228]
    d918:      	str	x11, [x0, #0x100]
    d91c:      	ldr	x11, [x10, #0x230]
    d920:      	str	x11, [x0, #0x108]
    d924:      	ldr	x10, [x10, #0x238]
    d928:      	strb	w9, [x0, #0x269]
    d92c:      	str	x10, [x0, #0x110]
    d930:      	mov	w0, #0x1                // =1
    d934:      	ret
    d938:      	paciasp
    d93c:      	stp	x29, x30, [sp, #-0x60]!
    d940:      	stp	x28, x27, [sp, #0x10]
    d944:      	stp	x26, x25, [sp, #0x20]
    d948:      	stp	x24, x23, [sp, #0x30]
    d94c:      	stp	x22, x21, [sp, #0x40]
    d950:      	stp	x20, x19, [sp, #0x50]
    d954:      	mov	x29, sp
    d958:      	sub	sp, sp, #0xb10
    d95c:      	mov	x8, x2
    d960:      	mov	x21, x4
    d964:      	mov	x19, x3
    d968:      	mov	x22, x1
    d96c:      	sub	x2, x29, #0x50
    d970:      	sub	x3, x29, #0x88
    d974:      	mov	x1, x8
    d978:      	mov	w4, wzr
    d97c:      	mov	w23, w5
    d980:      	mov	x20, x0
    d984:      	bl	0xcd64 <JNI_OnUnload+0x4e4>
    d988:      	cbnz	x0, 0xda68 <JNI_OnUnload+0x11e8>
    d98c:      	add	x0, sp, #0x470
    d990:      	mov	w1, wzr
    d994:      	mov	w2, #0x618              // =1560
    d998:      	bl	0x109a0 <memset@plt>
    d99c:      	sub	x1, x29, #0x50
    d9a0:      	sub	x2, x29, #0x88
    d9a4:      	add	x5, sp, #0x470
    d9a8:      	mov	x0, x20
    d9ac:      	mov	x3, x22
    d9b0:      	mov	w4, #0x4                // =4
    d9b4:      	bl	0xddc0 <JNI_OnUnload+0x1540>
    d9b8:      	tbz	w0, #0x0, 0xda68 <JNI_OnUnload+0x11e8>
    d9bc:      	add	x1, sp, #0x470
    d9c0:      	mov	x0, x20
    d9c4:      	mov	x2, x19
    d9c8:      	add	x24, sp, #0x470
    d9cc:      	bl	0xea08 <JNI_OnUnload+0x2188>
    d9d0:      	mov	x22, x0
    d9d4:      	tbz	w23, #0x0, 0xda00 <JNI_OnUnload+0x1180>
    d9d8:      	ldurb	w8, [x29, #-0x54]
    d9dc:      	cbz	w8, 0xda00 <JNI_OnUnload+0x1180>
    d9e0:      	ldr	x8, [x19, #0xf8]
    d9e4:      	and	x8, x8, #0xfffffffffffffff0
    d9e8:      	cmp	x8, x22
    d9ec:      	b.hs	0xda00 <JNI_OnUnload+0x1180>
    d9f0:      	stg	x8, [x8]
    d9f4:      	add	x8, x8, #0x10
    d9f8:      	cmp	x8, x22
    d9fc:      	b.lo	0xd9f0 <JNI_OnUnload+0x1170>
    da00:      	add	x0, sp, #0x260
    da04:      	mov	x1, x19
    da08:      	mov	w2, #0x210              // =528
    da0c:      	add	x25, sp, #0x260
    da10:      	bl	0x10890 <memcpy@plt>
    da14:      	add	x9, x25, #0xf8
    da18:      	add	x8, x25, #0xe8
    da1c:      	add	x10, x19, #0xf8
    da20:      	stp	x8, x9, [sp, #0x18]
    da24:      	add	x9, x25, #0x100
    da28:      	add	x8, x25, #0xf0
    da2c:      	stp	x8, x9, [sp, #0x8]
    da30:      	add	x9, x25, #0x108
    da34:      	add	x8, x19, #0xe8
    da38:      	stp	x8, x9, [sp, #0x40]
    da3c:      	add	x8, x19, #0x100
    da40:      	mov	x26, xzr
    da44:      	mov	x23, xzr
    da48:      	add	x28, x19, #0x108
    da4c:      	stp	x10, x8, [sp, #0x30]
    da50:      	add	x8, x19, #0xf0
    da54:      	add	x24, x24, #0x18
    da58:      	add	x27, sp, #0x260
    da5c:      	str	x22, [sp, #0x358]
    da60:      	str	x8, [sp, #0x28]
    da64:      	b	0xdac0 <JNI_OnUnload+0x1240>
    da68:      	mov	w0, #-0x1992            // =-6546
    da6c:      	add	sp, sp, #0xb10
    da70:      	ldp	x20, x19, [sp, #0x50]
    da74:      	ldp	x22, x21, [sp, #0x40]
    da78:      	ldp	x24, x23, [sp, #0x30]
    da7c:      	ldp	x26, x25, [sp, #0x20]
    da80:      	ldp	x28, x27, [sp, #0x10]
    da84:      	ldp	x29, x30, [sp], #0x60
    da88:      	autiasp
    da8c:      	ret
    da90:      	ldr	x8, [x24, #0x8]
    da94:      	mov	x9, #-0x4000000000      // =-274877906944
    da98:      	add	x8, x9, x8, lsl #32
    da9c:      	add	x8, x19, x8, asr #29
    daa0:      	ldr	d0, [x8, #0x110]
    daa4:      	add	x8, x25, x26, lsl #3
    daa8:      	stur	d0, [x8, #-0xf0]
    daac:      	add	x26, x26, #0x1
    dab0:      	add	x24, x24, #0x10
    dab4:      	add	x27, x27, #0x8
    dab8:      	cmp	x26, #0x60
    dabc:      	b.eq	0xdc80 <JNI_OnUnload+0x1400>
    dac0:      	ldr	w8, [x24]
    dac4:      	cbz	w8, 0xdafc <JNI_OnUnload+0x127c>
    dac8:      	and	w9, w26, #0x60
    dacc:      	cmp	w9, #0x40
    dad0:      	b.ne	0xdb38 <JNI_OnUnload+0x12b8>
    dad4:      	cmp	w8, #0x4
    dad8:      	b.gt	0xdb60 <JNI_OnUnload+0x12e0>
    dadc:      	movi	d0, #0000000000000000
    dae0:      	cmp	w8, #0x1
    dae4:      	b.eq	0xdaa4 <JNI_OnUnload+0x1224>
    dae8:      	cmp	w8, #0x2
    daec:      	b.ne	0xdd24 <JNI_OnUnload+0x14a4>
    daf0:      	ldr	x8, [x24, #0x8]
    daf4:      	ldr	d0, [x8, x22]
    daf8:      	b	0xdaa4 <JNI_OnUnload+0x1224>
    dafc:      	ldurb	w8, [x29, #-0x56]
    db00:      	cmp	x26, x8
    db04:      	b.ne	0xdaac <JNI_OnUnload+0x122c>
    db08:      	cmp	w8, #0x1e
    db0c:      	b.le	0xdc00 <JNI_OnUnload+0x1380>
    db10:      	cmp	w8, #0x22
    db14:      	mov	x9, x28
    db18:      	b.eq	0xdc24 <JNI_OnUnload+0x13a4>
    db1c:      	ldr	x9, [sp, #0x38]
    db20:      	cmp	w8, #0x20
    db24:      	b.eq	0xdc24 <JNI_OnUnload+0x13a4>
    db28:      	ldr	x9, [sp, #0x30]
    db2c:      	cmp	w8, #0x1f
    db30:      	b.eq	0xdc24 <JNI_OnUnload+0x13a4>
    db34:      	b	0xdc18 <JNI_OnUnload+0x1398>
    db38:      	ldurb	w8, [x29, #-0x56]
    db3c:      	cmp	x26, x8
    db40:      	b.ne	0xdb8c <JNI_OnUnload+0x130c>
    db44:      	mov	x0, x20
    db48:      	mov	x1, x19
    db4c:      	mov	x2, x22
    db50:      	mov	x3, x24
    db54:      	bl	0xeb3c <JNI_OnUnload+0x22bc>
    db58:      	mov	x23, x0
    db5c:      	b	0xdaac <JNI_OnUnload+0x122c>
    db60:      	cmp	w8, #0x5
    db64:      	b.eq	0xda90 <JNI_OnUnload+0x1210>
    db68:      	cmp	w8, #0x6
    db6c:      	b.ne	0xdd24 <JNI_OnUnload+0x14a4>
    db70:      	ldr	x0, [x24, #0x8]
    db74:      	mov	x1, x20
    db78:      	mov	x2, x19
    db7c:      	mov	x3, x22
    db80:      	bl	0xf2a0 <JNI_OnUnload+0x2a20>
    db84:      	ldr	d0, [x0]
    db88:      	b	0xdaa4 <JNI_OnUnload+0x1224>
    db8c:      	cmp	x26, #0x22
    db90:      	b.ne	0xdbb4 <JNI_OnUnload+0x1334>
    db94:      	mov	x0, x20
    db98:      	mov	x1, x19
    db9c:      	mov	x2, x22
    dba0:      	mov	x3, x24
    dba4:      	bl	0xeb3c <JNI_OnUnload+0x22bc>
    dba8:      	ldr	x8, [sp, #0x48]
    dbac:      	str	x0, [x8]
    dbb0:      	b	0xdaac <JNI_OnUnload+0x122c>
    dbb4:      	sub	w8, w26, #0x40
    dbb8:      	cmn	w8, #0x20
    dbbc:      	b.hi	0xdd1c <JNI_OnUnload+0x149c>
    dbc0:      	mov	x0, x20
    dbc4:      	mov	x1, x19
    dbc8:      	mov	x2, x22
    dbcc:      	mov	x3, x24
    dbd0:      	bl	0xeb3c <JNI_OnUnload+0x22bc>
    dbd4:      	cmp	w26, #0x1e
    dbd8:      	b.le	0xdc2c <JNI_OnUnload+0x13ac>
    dbdc:      	cmp	w26, #0x1f
    dbe0:      	b.eq	0xdc48 <JNI_OnUnload+0x13c8>
    dbe4:      	cmp	w26, #0x22
    dbe8:      	b.eq	0xdc54 <JNI_OnUnload+0x13d4>
    dbec:      	cmp	w26, #0x20
    dbf0:      	b.ne	0xdc6c <JNI_OnUnload+0x13ec>
    dbf4:      	ldr	x8, [sp, #0x10]
    dbf8:      	str	x0, [x8]
    dbfc:      	b	0xdaac <JNI_OnUnload+0x122c>
    dc00:      	ldr	x9, [sp, #0x40]
    dc04:      	cmp	w8, #0x1d
    dc08:      	b.eq	0xdc24 <JNI_OnUnload+0x13a4>
    dc0c:      	ldr	x9, [sp, #0x28]
    dc10:      	cmp	w8, #0x1e
    dc14:      	b.eq	0xdc24 <JNI_OnUnload+0x13a4>
    dc18:      	cmp	w8, #0x1c
    dc1c:      	b.hi	0xdd58 <JNI_OnUnload+0x14d8>
    dc20:      	add	x9, x19, x8, lsl #3
    dc24:      	ldr	x23, [x9]
    dc28:      	b	0xdaac <JNI_OnUnload+0x122c>
    dc2c:      	cmp	w26, #0x1d
    dc30:      	b.eq	0xdc60 <JNI_OnUnload+0x13e0>
    dc34:      	cmp	w26, #0x1e
    dc38:      	b.ne	0xdc6c <JNI_OnUnload+0x13ec>
    dc3c:      	ldr	x8, [sp, #0x8]
    dc40:      	str	x0, [x8]
    dc44:      	b	0xdaac <JNI_OnUnload+0x122c>
    dc48:      	ldr	x8, [sp, #0x20]
    dc4c:      	str	x0, [x8]
    dc50:      	b	0xdaac <JNI_OnUnload+0x122c>
    dc54:      	ldr	x8, [sp, #0x48]
    dc58:      	str	x0, [x8]
    dc5c:      	b	0xdaac <JNI_OnUnload+0x122c>
    dc60:      	ldr	x8, [sp, #0x18]
    dc64:      	str	x0, [x8]
    dc68:      	b	0xdaac <JNI_OnUnload+0x122c>
    dc6c:      	cmp	x26, #0x1d
    dc70:      	mov	x8, x27
    dc74:      	b.hs	0xdd8c <JNI_OnUnload+0x150c>
    dc78:      	str	x0, [x8]
    dc7c:      	b	0xdaac <JNI_OnUnload+0x122c>
    dc80:      	ldurb	w8, [x29, #-0x58]
    dc84:      	add	x0, sp, #0x50
    dc88:      	mov	x1, x19
    dc8c:      	mov	w2, #0x210              // =528
    dc90:      	strb	w8, [x21]
    dc94:      	bl	0x10890 <memcpy@plt>
    dc98:      	add	x8, sp, #0x470
    dc9c:      	add	x8, x8, #0x238
    dca0:      	ldr	q0, [x8]
    dca4:      	stur	q0, [x29, #-0x20]
    dca8:      	ldur	w8, [x29, #-0x20]
    dcac:      	cbz	w8, 0xdccc <JNI_OnUnload+0x144c>
    dcb0:      	add	x1, sp, #0x50
    dcb4:      	sub	x3, x29, #0x20
    dcb8:      	mov	x0, x20
    dcbc:      	mov	x2, x22
    dcc0:      	bl	0xeb3c <JNI_OnUnload+0x22bc>
    dcc4:      	tbnz	w0, #0x0, 0xdcd4 <JNI_OnUnload+0x1454>
    dcc8:      	b	0xdd00 <JNI_OnUnload+0x1480>
    dccc:      	ldur	x0, [x29, #-0x18]
    dcd0:      	tbz	w0, #0x0, 0xdd00 <JNI_OnUnload+0x1480>
    dcd4:      	cbz	x23, 0xdd00 <JNI_OnUnload+0x1480>
    dcd8:      	ldurb	w8, [x29, #-0x55]
    dcdc:      	cbz	w8, 0xdcf0 <JNI_OnUnload+0x1470>
    dce0:      	mov	x17, x23
    dce4:      	mov	x16, x22
    dce8:      	autib1716
    dcec:      	b	0xdcfc <JNI_OnUnload+0x147c>
    dcf0:      	mov	x17, x23
    dcf4:      	mov	x16, x22
    dcf8:      	autia1716
    dcfc:      	mov	x23, x17
    dd00:      	add	x1, sp, #0x260
    dd04:      	mov	x0, x19
    dd08:      	mov	w2, #0x210              // =528
    dd0c:      	str	x23, [sp, #0x360]
    dd10:      	bl	0x10890 <memcpy@plt>
    dd14:      	mov	w0, #0x1                // =1
    dd18:      	b	0xda6c <JNI_OnUnload+0x11ec>
    dd1c:      	mov	w0, #-0x198e            // =-6542
    dd20:      	b	0xda6c <JNI_OnUnload+0x11ec>
    dd24:      	adrp	x19, 0x15000
    dd28:      	nop
    dd2c:      	adr	x1, 0x4677
    dd30:      	ldr	x19, [x19, #0x1e0]
    dd34:      	adrp	x2, 0x4000
    dd38:      	add	x2, x2, #0x779
    dd3c:      	adrp	x3, 0x4000
    dd40:      	add	x3, x3, #0xdd7
    dd44:      	add	x0, x19, #0x130
    dd48:      	bl	0x10d50 <fprintf@plt>
    dd4c:      	add	x0, x19, #0x130
    dd50:      	bl	0x10d60 <fflush@plt>
    dd54:      	bl	0x10d70 <abort@plt>
    dd58:      	adrp	x19, 0x15000
    dd5c:      	nop
    dd60:      	adr	x1, 0x4677
    dd64:      	ldr	x19, [x19, #0x1e0]
    dd68:      	adrp	x2, 0x4000
    dd6c:      	add	x2, x2, #0xf2c
    dd70:      	adrp	x3, 0x4000
    dd74:      	add	x3, x3, #0xbfc
    dd78:      	add	x0, x19, #0x130
    dd7c:      	bl	0x10d50 <fprintf@plt>
    dd80:      	add	x0, x19, #0x130
    dd84:      	bl	0x10d60 <fflush@plt>
    dd88:      	bl	0x10d70 <abort@plt>
    dd8c:      	adrp	x19, 0x15000
    dd90:      	nop
    dd94:      	adr	x1, 0x4677
    dd98:      	ldr	x19, [x19, #0x1e0]
    dd9c:      	adrp	x2, 0x5000
    dda0:      	add	x2, x2, #0x325
    dda4:      	adrp	x3, 0x4000
    dda8:      	add	x3, x3, #0xbfc
    ddac:      	add	x0, x19, #0x130
    ddb0:      	bl	0x10d50 <fprintf@plt>
    ddb4:      	add	x0, x19, #0x130
    ddb8:      	bl	0x10d60 <fflush@plt>
    ddbc:      	bl	0x10d70 <abort@plt>
    ddc0:      	paciasp
    ddc4:      	stp	x29, x30, [sp, #-0x60]!
    ddc8:      	stp	x28, x27, [sp, #0x10]
    ddcc:      	stp	x26, x25, [sp, #0x20]
    ddd0:      	stp	x24, x23, [sp, #0x30]
    ddd4:      	stp	x22, x21, [sp, #0x40]
    ddd8:      	stp	x20, x19, [sp, #0x50]
    dddc:      	mov	x29, sp
    dde0:      	sub	sp, sp, #0x680
    dde4:      	ldp	x10, x8, [x2, #0x8]
    dde8:      	mov	x19, sp
    ddec:      	ldr	x9, [x2]
    ddf0:      	ldp	x11, x12, [x1, #0x10]
    ddf4:      	mov	x20, x5
    ddf8:      	mov	w28, w4
    ddfc:      	mov	x22, x2
    de00:      	add	x9, x10, x9
    de04:      	mov	x27, xzr
    de08:      	nop
    de0c:      	adr	x23, 0x5a16 <_ZTSSt9bad_alloc+0xd>
    de10:      	stp	x8, x9, [x29, #-0x38]
    de14:      	mov	x8, #-0x1               // =-1
    de18:      	ldp	x9, x10, [x1]
    de1c:      	stp	x8, x11, [x29, #-0x28]
    de20:      	stp	x0, xzr, [x19, #0x18]
    de24:      	add	x8, x10, x9
    de28:      	sub	x9, x3, x12
    de2c:      	stp	x8, x9, [x29, #-0x18]
    de30:      	add	x8, x19, #0x28
    de34:      	add	x9, x5, #0x238
    de38:      	add	x8, x8, #0x238
    de3c:      	stp	x8, x9, [x19, #0x8]
    de40:      	b	0xde50 <JNI_OnUnload+0x15d0>
    de44:      	add	x27, x27, #0x18
    de48:      	cmp	x27, #0x30
    de4c:      	b.eq	0xe77c <JNI_OnUnload+0x1efc>
    de50:      	sub	x8, x29, #0x38
    de54:      	add	x8, x8, x27
    de58:      	ldp	x9, x24, [x8]
    de5c:      	ldr	x21, [x8, #0x10]
    de60:      	cmp	x9, x24
    de64:      	stur	x9, [x29, #-0x40]
    de68:      	ccmp	x21, #0x0, #0x4, lo
    de6c:      	b.eq	0xde44 <JNI_OnUnload+0x15c4>
    de70:      	mov	x25, xzr
    de74:      	mov	x8, x9
    de78:      	ldrb	w10, [x8], #0x1
    de7c:      	stur	x8, [x29, #-0x40]
    de80:      	cmp	w10, #0x2f
    de84:      	b.hi	0xe474 <JNI_OnUnload+0x1bf4>
    de88:      	adr	x11, 0xde98 <JNI_OnUnload+0x1618>
    de8c:      	ldrh	w12, [x23, x10, lsl #1]
    de90:      	add	x11, x11, x12, lsl #2
    de94:      	br	x11
    de98:      	bti	j
    de9c:      	ldrb	w3, [x22, #0x18]
    dea0:      	ldr	x0, [x19, #0x18]
    dea4:      	sub	x1, x29, #0x40
    dea8:      	mov	x2, x24
    deac:      	mov	x4, xzr
    deb0:      	bl	0xed4c <JNI_OnUnload+0x24cc>
    deb4:      	mov	x25, x0
    deb8:      	ldur	x9, [x29, #-0x40]
    debc:      	cmp	x9, x24
    dec0:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    dec4:      	b	0xde44 <JNI_OnUnload+0x15c4>
    dec8:      	bti	j
    decc:      	sub	x0, x29, #0x40
    ded0:      	mov	x1, x24
    ded4:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    ded8:      	ldur	x10, [x29, #-0x40]
    dedc:      	mov	x9, xzr
    dee0:      	mov	x8, xzr
    dee4:      	mov	x12, x10
    dee8:      	cmp	x12, x24
    deec:      	b.eq	0xe96c <JNI_OnUnload+0x20ec>
    def0:      	ldrb	w11, [x12], #0x1
    def4:      	add	x10, x10, #0x1
    def8:      	and	x13, x11, #0x7f
    defc:      	lsl	x13, x13, x9
    df00:      	add	x9, x9, #0x7
    df04:      	orr	x8, x13, x8
    df08:      	tbnz	w11, #0x7, 0xdee8 <JNI_OnUnload+0x1668>
    df0c:      	cmp	x0, #0x60
    df10:      	stur	x10, [x29, #-0x40]
    df14:      	b.hs	0xe8c4 <JNI_OnUnload+0x2044>
    df18:      	sub	w10, w9, #0x7
    df1c:      	mov	x12, #-0x1              // =-1
    df20:      	cmp	w10, #0x39
    df24:      	mov	w10, #0x3f              // =63
    df28:      	lsl	x9, x12, x9
    df2c:      	ccmp	w11, w10, #0x0, lo
    df30:      	ldr	w10, [x22, #0x2c]
    df34:      	csel	w9, w9, wzr, hi
    df38:      	orr	w8, w8, w9
    df3c:      	mul	w8, w10, w8
    df40:      	stp	w0, w8, [x20]
    df44:      	ldur	x9, [x29, #-0x40]
    df48:      	cmp	x9, x24
    df4c:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    df50:      	b	0xde44 <JNI_OnUnload+0x15c4>
    df54:      	bti	j
    df58:      	sub	x0, x29, #0x40
    df5c:      	mov	x1, x24
    df60:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    df64:      	cmp	x0, #0x60
    df68:      	b.hs	0xe7b0 <JNI_OnUnload+0x1f30>
    df6c:      	ldur	x9, [x29, #-0x40]
    df70:      	mov	x10, xzr
    df74:      	mov	x8, xzr
    df78:      	mov	x12, x9
    df7c:      	cmp	x12, x24
    df80:      	b.eq	0xe9d4 <JNI_OnUnload+0x2154>
    df84:      	ldrb	w11, [x12], #0x1
    df88:      	add	x9, x9, #0x1
    df8c:      	and	x13, x11, #0x7f
    df90:      	lsl	x13, x13, x10
    df94:      	add	x10, x10, #0x7
    df98:      	orr	x8, x13, x8
    df9c:      	tbnz	w11, #0x7, 0xdf7c <JNI_OnUnload+0x16fc>
    dfa0:      	add	x12, x20, x0, lsl #4
    dfa4:      	sub	w13, w10, #0x7
    dfa8:      	mov	x15, #-0x1              // =-1
    dfac:      	cmp	w13, #0x39
    dfb0:      	mov	w14, #0x3f              // =63
    dfb4:      	lsl	x15, x15, x10
    dfb8:      	mov	x13, x12
    dfbc:      	ccmp	w11, w14, #0x0, lo
    dfc0:      	ldrsw	x10, [x22, #0x2c]
    dfc4:      	ldrb	w16, [x13, #0x1c]!
    dfc8:      	csel	x11, x15, xzr, hi
    dfcc:      	stur	x9, [x29, #-0x40]
    dfd0:      	cbnz	w16, 0xdff4 <JNI_OnUnload+0x1774>
    dfd4:      	lsl	x9, x0, #4
    dfd8:      	add	x15, x19, #0x28
    dfdc:      	add	x14, x20, x9
    dfe0:      	add	x9, x15, x9
    dfe4:      	ldur	q0, [x14, #0x18]
    dfe8:      	mov	w14, #0x1               // =1
    dfec:      	strb	w14, [x13]
    dff0:      	stur	q0, [x9, #0x18]
    dff4:      	orr	x8, x8, x11
    dff8:      	mov	w9, #0x4                // =4
    dffc:      	b	0xe608 <JNI_OnUnload+0x1d88>
    e000:      	bti	j
    e004:      	sub	x0, x29, #0x40
    e008:      	mov	x1, x24
    e00c:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e010:      	cmp	x0, #0x60
    e014:      	b.hs	0xe784 <JNI_OnUnload+0x1f04>
    e018:      	str	w0, [x20]
    e01c:      	ldur	x9, [x29, #-0x40]
    e020:      	cmp	x9, x24
    e024:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e028:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e02c:      	bti	j
    e030:      	sub	x0, x29, #0x40
    e034:      	mov	x1, x24
    e038:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e03c:      	cmp	x0, #0x60
    e040:      	b.hs	0xe814 <JNI_OnUnload+0x1f94>
    e044:      	mov	x26, x0
    e048:      	sub	x0, x29, #0x40
    e04c:      	mov	x1, x24
    e050:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e054:      	add	x8, x20, x26, lsl #4
    e058:      	ldrsw	x9, [x22, #0x2c]
    e05c:      	mov	x10, x8
    e060:      	ldrb	w11, [x10, #0x1c]!
    e064:      	cbnz	w11, 0xe088 <JNI_OnUnload+0x1808>
    e068:      	lsl	x11, x26, #4
    e06c:      	add	x13, x19, #0x28
    e070:      	add	x12, x20, x11
    e074:      	add	x11, x13, x11
    e078:      	ldur	q0, [x12, #0x18]
    e07c:      	mov	w12, #0x1               // =1
    e080:      	strb	w12, [x10]
    e084:      	stur	q0, [x11, #0x18]
    e088:      	mneg	x9, x0, x9
    e08c:      	b	0xe298 <JNI_OnUnload+0x1a18>
    e090:      	bti	j
    e094:      	cmp	w28, #0x4
    e098:      	b.ne	0xe744 <JNI_OnUnload+0x1ec4>
    e09c:      	ldrb	w8, [x20, #0x23c]
    e0a0:      	cbnz	w8, 0xe0b8 <JNI_OnUnload+0x1838>
    e0a4:      	ldp	x9, x8, [x19, #0x8]
    e0a8:      	ldr	q0, [x8]
    e0ac:      	mov	w8, #0x1                // =1
    e0b0:      	strb	w8, [x20, #0x23c]
    e0b4:      	str	q0, [x9]
    e0b8:      	ldr	x8, [x20, #0x240]
    e0bc:      	eor	x8, x8, #0x1
    e0c0:      	str	x8, [x20, #0x240]
    e0c4:      	ldur	x9, [x29, #-0x40]
    e0c8:      	cmp	x9, x24
    e0cc:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e0d0:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e0d4:      	bti	j
    e0d8:      	sub	x26, sp, #0x620
    e0dc:      	mov	sp, x26
    e0e0:      	ldr	x8, [x19, #0x20]
    e0e4:      	mov	x0, x26
    e0e8:      	mov	x1, x20
    e0ec:      	mov	w2, #0x618              // =1560
    e0f0:      	str	x8, [x0], #0x8
    e0f4:      	bl	0x10890 <memcpy@plt>
    e0f8:      	str	x26, [x19, #0x20]
    e0fc:      	ldur	x9, [x29, #-0x40]
    e100:      	cmp	x9, x24
    e104:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e108:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e10c:      	bti	j
    e110:      	ldrb	w8, [x9, #0x1]
    e114:      	ldr	w10, [x22, #0x28]
    e118:      	add	x9, x9, #0x2
    e11c:      	b	0xe2fc <JNI_OnUnload+0x1a7c>
    e120:      	bti	j
    e124:      	ldur	w8, [x9, #0x1]
    e128:      	ldr	w10, [x22, #0x28]
    e12c:      	add	x9, x9, #0x5
    e130:      	b	0xe2fc <JNI_OnUnload+0x1a7c>
    e134:      	bti	j
    e138:      	sub	x0, x29, #0x40
    e13c:      	mov	x1, x24
    e140:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e144:      	cmp	x0, #0x60
    e148:      	b.hs	0xe794 <JNI_OnUnload+0x1f14>
    e14c:      	add	x8, x20, x0, lsl #4
    e150:      	mov	x9, x8
    e154:      	ldrb	w10, [x9, #0x1c]!
    e158:      	cbnz	w10, 0xe17c <JNI_OnUnload+0x18fc>
    e15c:      	lsl	x10, x0, #4
    e160:      	add	x12, x19, #0x28
    e164:      	add	x11, x20, x10
    e168:      	add	x10, x12, x10
    e16c:      	ldur	q0, [x11, #0x18]
    e170:      	mov	w11, #0x1               // =1
    e174:      	strb	w11, [x9]
    e178:      	stur	q0, [x10, #0x18]
    e17c:      	ldur	x9, [x29, #-0x40]
    e180:      	mov	w10, #0x7               // =7
    e184:      	b	0xe674 <JNI_OnUnload+0x1df4>
    e188:      	bti	j
    e18c:      	sub	x0, x29, #0x40
    e190:      	mov	x1, x24
    e194:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e198:      	mov	x26, x0
    e19c:      	sub	x0, x29, #0x40
    e1a0:      	mov	x1, x24
    e1a4:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e1a8:      	cmp	x26, #0x60
    e1ac:      	b.hs	0xe830 <JNI_OnUnload+0x1fb0>
    e1b0:      	stp	w26, w0, [x20]
    e1b4:      	ldur	x9, [x29, #-0x40]
    e1b8:      	cmp	x9, x24
    e1bc:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e1c0:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e1c4:      	bti	j
    e1c8:      	mov	x10, xzr
    e1cc:      	mov	x9, xzr
    e1d0:      	mov	x11, x8
    e1d4:      	cmp	x11, x24
    e1d8:      	b.eq	0xe938 <JNI_OnUnload+0x20b8>
    e1dc:      	ldrb	w12, [x11], #0x1
    e1e0:      	add	x8, x8, #0x1
    e1e4:      	and	x13, x12, #0x7f
    e1e8:      	lsl	x13, x13, x10
    e1ec:      	add	x10, x10, #0x7
    e1f0:      	orr	x9, x13, x9
    e1f4:      	tbnz	w12, #0x7, 0xe1d4 <JNI_OnUnload+0x1954>
    e1f8:      	sub	w11, w10, #0x7
    e1fc:      	mov	x13, #-0x1              // =-1
    e200:      	stur	x8, [x29, #-0x40]
    e204:      	cmp	w11, #0x39
    e208:      	mov	w11, #0x3f              // =63
    e20c:      	lsl	x10, x13, x10
    e210:      	ccmp	w12, w11, #0x0, lo
    e214:      	ldr	w11, [x22, #0x2c]
    e218:      	csel	w10, w10, wzr, hi
    e21c:      	orr	w9, w9, w10
    e220:      	mul	w9, w11, w9
    e224:      	str	w9, [x20, #0x4]
    e228:      	mov	x9, x8
    e22c:      	cmp	x8, x24
    e230:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e234:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e238:      	bti	j
    e23c:      	sub	x0, x29, #0x40
    e240:      	mov	x1, x24
    e244:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e248:      	mov	x26, x0
    e24c:      	sub	x0, x29, #0x40
    e250:      	mov	x1, x24
    e254:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e258:      	cmp	x26, #0x60
    e25c:      	b.hs	0xe7f8 <JNI_OnUnload+0x1f78>
    e260:      	add	x8, x20, x26, lsl #4
    e264:      	ldrsw	x9, [x22, #0x2c]
    e268:      	mov	x10, x8
    e26c:      	ldrb	w11, [x10, #0x1c]!
    e270:      	cbnz	w11, 0xe294 <JNI_OnUnload+0x1a14>
    e274:      	lsl	x11, x26, #4
    e278:      	add	x13, x19, #0x28
    e27c:      	add	x12, x20, x11
    e280:      	add	x11, x13, x11
    e284:      	ldur	q0, [x12, #0x18]
    e288:      	mov	w12, #0x1               // =1
    e28c:      	strb	w12, [x10]
    e290:      	stur	q0, [x11, #0x18]
    e294:      	mul	x9, x0, x9
    e298:      	mov	w10, #0x2               // =2
    e29c:      	str	w10, [x8, #0x18]
    e2a0:      	str	x9, [x8, #0x20]
    e2a4:      	ldur	x9, [x29, #-0x40]
    e2a8:      	cmp	x9, x24
    e2ac:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e2b0:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e2b4:      	bti	j
    e2b8:      	ldr	x8, [x19, #0x20]
    e2bc:      	cbz	x8, 0xe910 <JNI_OnUnload+0x2090>
    e2c0:      	add	x1, x8, #0x8
    e2c4:      	mov	x0, x20
    e2c8:      	mov	w2, #0x618              // =1560
    e2cc:      	mov	x26, x8
    e2d0:      	bl	0x10890 <memcpy@plt>
    e2d4:      	ldr	x26, [x26]
    e2d8:      	str	x26, [x19, #0x20]
    e2dc:      	ldur	x9, [x29, #-0x40]
    e2e0:      	cmp	x9, x24
    e2e4:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e2e8:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e2ec:      	bti	j
    e2f0:      	ldurh	w8, [x9, #0x1]
    e2f4:      	ldr	w10, [x22, #0x28]
    e2f8:      	add	x9, x9, #0x3
    e2fc:      	mul	w8, w10, w8
    e300:      	add	x25, x25, x8
    e304:      	stur	x9, [x29, #-0x40]
    e308:      	cmp	x9, x24
    e30c:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e310:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e314:      	bti	j
    e318:      	sub	x0, x29, #0x40
    e31c:      	mov	x1, x24
    e320:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e324:      	str	w0, [x20, #0x10]
    e328:      	ldur	x9, [x29, #-0x40]
    e32c:      	cmp	x9, x24
    e330:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e334:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e338:      	bti	j
    e33c:      	sub	x0, x29, #0x40
    e340:      	mov	x1, x24
    e344:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e348:      	cmp	x0, #0x60
    e34c:      	b.hs	0xe7dc <JNI_OnUnload+0x1f5c>
    e350:      	add	x8, x20, x0, lsl #4
    e354:      	ldrb	w8, [x8, #0x1c]
    e358:      	cbz	w8, 0xe744 <JNI_OnUnload+0x1ec4>
    e35c:      	lsl	x8, x0, #4
    e360:      	b	0xe730 <JNI_OnUnload+0x1eb0>
    e364:      	bti	j
    e368:      	sub	x0, x29, #0x40
    e36c:      	mov	x1, x24
    e370:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e374:      	cmp	x0, #0x60
    e378:      	b.hs	0xe84c <JNI_OnUnload+0x1fcc>
    e37c:      	add	x8, x20, x0, lsl #4
    e380:      	mov	x9, x8
    e384:      	ldrb	w10, [x9, #0x1c]!
    e388:      	cbnz	w10, 0xe3ac <JNI_OnUnload+0x1b2c>
    e38c:      	lsl	x10, x0, #4
    e390:      	add	x12, x19, #0x28
    e394:      	add	x11, x20, x10
    e398:      	add	x10, x12, x10
    e39c:      	ldur	q0, [x11, #0x18]
    e3a0:      	mov	w11, #0x1               // =1
    e3a4:      	strb	w11, [x9]
    e3a8:      	stur	q0, [x10, #0x18]
    e3ac:      	mov	w9, #0x1                // =1
    e3b0:      	str	w9, [x8, #0x18]
    e3b4:      	ldur	x9, [x29, #-0x40]
    e3b8:      	cmp	x9, x24
    e3bc:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e3c0:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e3c4:      	bti	j
    e3c8:      	sub	x0, x29, #0x40
    e3cc:      	mov	x1, x24
    e3d0:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e3d4:      	str	w0, [x20, #0x4]
    e3d8:      	ldur	x9, [x29, #-0x40]
    e3dc:      	cmp	x9, x24
    e3e0:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e3e4:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e3e8:      	bti	j
    e3ec:      	str	wzr, [x20]
    e3f0:      	str	x8, [x20, #0x8]
    e3f4:      	b	0xe67c <JNI_OnUnload+0x1dfc>
    e3f8:      	bti	j
    e3fc:      	sub	x0, x29, #0x40
    e400:      	mov	x1, x24
    e404:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e408:      	mov	x26, x0
    e40c:      	sub	x0, x29, #0x40
    e410:      	mov	x1, x24
    e414:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e418:      	cmp	x26, #0x60
    e41c:      	b.hs	0xe898 <JNI_OnUnload+0x2018>
    e420:      	cmp	x0, #0x60
    e424:      	b.hs	0xe8e0 <JNI_OnUnload+0x2060>
    e428:      	add	x8, x20, x26, lsl #4
    e42c:      	mov	x9, x8
    e430:      	ldrb	w10, [x9, #0x1c]!
    e434:      	cbnz	w10, 0xe458 <JNI_OnUnload+0x1bd8>
    e438:      	lsl	x10, x26, #4
    e43c:      	add	x12, x19, #0x28
    e440:      	add	x11, x20, x10
    e444:      	add	x10, x12, x10
    e448:      	ldur	q0, [x11, #0x18]
    e44c:      	mov	w11, #0x1               // =1
    e450:      	strb	w11, [x9]
    e454:      	stur	q0, [x10, #0x18]
    e458:      	mov	w9, #0x5                // =5
    e45c:      	str	x0, [x8, #0x20]
    e460:      	str	w9, [x8, #0x18]
    e464:      	ldur	x9, [x29, #-0x40]
    e468:      	cmp	x9, x24
    e46c:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e470:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e474:      	bti	j
    e478:      	and	w8, w10, #0xc0
    e47c:      	and	x26, x10, #0x3f
    e480:      	cmp	w8, #0x40
    e484:      	b.eq	0xe760 <JNI_OnUnload+0x1ee0>
    e488:      	cmp	w8, #0xc0
    e48c:      	b.eq	0xe720 <JNI_OnUnload+0x1ea0>
    e490:      	cmp	w8, #0x80
    e494:      	b.ne	0xe910 <JNI_OnUnload+0x2090>
    e498:      	sub	x0, x29, #0x40
    e49c:      	mov	x1, x24
    e4a0:      	str	w28, [x19, #0x4]
    e4a4:      	mov	w28, w26
    e4a8:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e4ac:      	add	x8, x20, w26, uxtw #4
    e4b0:      	ldrsw	x9, [x22, #0x2c]
    e4b4:      	ldrb	w10, [x8, #0x1c]!
    e4b8:      	cbnz	w10, 0xe4dc <JNI_OnUnload+0x1c5c>
    e4bc:      	lsl	x10, x28, #4
    e4c0:      	add	x11, x20, x10
    e4c4:      	ldur	q0, [x11, #0x18]
    e4c8:      	add	x11, x19, #0x28
    e4cc:      	add	x10, x11, x10
    e4d0:      	stur	q0, [x10, #0x18]
    e4d4:      	mov	w10, #0x1               // =1
    e4d8:      	strb	w10, [x8]
    e4dc:      	mul	x8, x0, x9
    e4e0:      	add	x9, x20, x28, lsl #4
    e4e4:      	mov	w10, #0x2               // =2
    e4e8:      	ldr	w28, [x19, #0x4]
    e4ec:      	str	w10, [x9, #0x18]
    e4f0:      	str	x8, [x9, #0x20]
    e4f4:      	ldur	x9, [x29, #-0x40]
    e4f8:      	cmp	x9, x24
    e4fc:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e500:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e504:      	bti	j
    e508:      	sub	x0, x29, #0x40
    e50c:      	mov	x1, x24
    e510:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e514:      	cmp	x0, #0x60
    e518:      	b.hs	0xe7cc <JNI_OnUnload+0x1f4c>
    e51c:      	add	x8, x20, x0, lsl #4
    e520:      	mov	x9, x8
    e524:      	ldrb	w10, [x9, #0x1c]!
    e528:      	cbnz	w10, 0xe54c <JNI_OnUnload+0x1ccc>
    e52c:      	lsl	x10, x0, #4
    e530:      	add	x12, x19, #0x28
    e534:      	add	x11, x20, x10
    e538:      	add	x10, x12, x10
    e53c:      	ldur	q0, [x11, #0x18]
    e540:      	mov	w11, #0x1               // =1
    e544:      	strb	w11, [x9]
    e548:      	stur	q0, [x10, #0x18]
    e54c:      	str	wzr, [x8, #0x18]
    e550:      	ldur	x9, [x29, #-0x40]
    e554:      	cmp	x9, x24
    e558:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e55c:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e560:      	bti	j
    e564:      	sub	x0, x29, #0x40
    e568:      	mov	x1, x24
    e56c:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e570:      	cmp	x0, #0x60
    e574:      	b.hs	0xe87c <JNI_OnUnload+0x1ffc>
    e578:      	ldur	x9, [x29, #-0x40]
    e57c:      	mov	x10, xzr
    e580:      	mov	x8, xzr
    e584:      	mov	x12, x9
    e588:      	cmp	x12, x24
    e58c:      	b.eq	0xe9a0 <JNI_OnUnload+0x2120>
    e590:      	ldrb	w11, [x12], #0x1
    e594:      	add	x9, x9, #0x1
    e598:      	and	x13, x11, #0x7f
    e59c:      	lsl	x13, x13, x10
    e5a0:      	add	x10, x10, #0x7
    e5a4:      	orr	x8, x13, x8
    e5a8:      	tbnz	w11, #0x7, 0xe588 <JNI_OnUnload+0x1d08>
    e5ac:      	add	x12, x20, x0, lsl #4
    e5b0:      	sub	w13, w10, #0x7
    e5b4:      	mov	x15, #-0x1              // =-1
    e5b8:      	cmp	w13, #0x39
    e5bc:      	mov	w14, #0x3f              // =63
    e5c0:      	lsl	x15, x15, x10
    e5c4:      	mov	x13, x12
    e5c8:      	ccmp	w11, w14, #0x0, lo
    e5cc:      	ldrsw	x10, [x22, #0x2c]
    e5d0:      	ldrb	w16, [x13, #0x1c]!
    e5d4:      	csel	x11, x15, xzr, hi
    e5d8:      	stur	x9, [x29, #-0x40]
    e5dc:      	cbnz	w16, 0xe600 <JNI_OnUnload+0x1d80>
    e5e0:      	lsl	x9, x0, #4
    e5e4:      	add	x15, x19, #0x28
    e5e8:      	add	x14, x20, x9
    e5ec:      	add	x9, x15, x9
    e5f0:      	ldur	q0, [x14, #0x18]
    e5f4:      	mov	w14, #0x1               // =1
    e5f8:      	strb	w14, [x13]
    e5fc:      	stur	q0, [x9, #0x18]
    e600:      	orr	x8, x8, x11
    e604:      	mov	w9, #0x2                // =2
    e608:      	mul	x8, x8, x10
    e60c:      	str	w9, [x12, #0x18]
    e610:      	str	x8, [x12, #0x20]
    e614:      	ldur	x9, [x29, #-0x40]
    e618:      	cmp	x9, x24
    e61c:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e620:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e624:      	bti	j
    e628:      	sub	x0, x29, #0x40
    e62c:      	mov	x1, x24
    e630:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e634:      	cmp	x0, #0x60
    e638:      	b.hs	0xe8b4 <JNI_OnUnload+0x2034>
    e63c:      	add	x8, x20, x0, lsl #4
    e640:      	mov	x9, x8
    e644:      	ldrb	w10, [x9, #0x1c]!
    e648:      	cbnz	w10, 0xe66c <JNI_OnUnload+0x1dec>
    e64c:      	lsl	x10, x0, #4
    e650:      	add	x12, x19, #0x28
    e654:      	add	x11, x20, x10
    e658:      	add	x10, x12, x10
    e65c:      	ldur	q0, [x11, #0x18]
    e660:      	mov	w11, #0x1               // =1
    e664:      	strb	w11, [x9]
    e668:      	stur	q0, [x10, #0x18]
    e66c:      	ldur	x9, [x29, #-0x40]
    e670:      	mov	w10, #0x6               // =6
    e674:      	str	w10, [x8, #0x18]
    e678:      	str	x9, [x8, #0x20]
    e67c:      	sub	x0, x29, #0x40
    e680:      	mov	x1, x24
    e684:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e688:      	ldur	x8, [x29, #-0x40]
    e68c:      	add	x8, x8, x0
    e690:      	stur	x8, [x29, #-0x40]
    e694:      	mov	x9, x8
    e698:      	cmp	x8, x24
    e69c:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e6a0:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e6a4:      	bti	j
    e6a8:      	sub	x0, x29, #0x40
    e6ac:      	mov	x1, x24
    e6b0:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e6b4:      	mov	x26, x0
    e6b8:      	cmp	x0, #0x60
    e6bc:      	b.hs	0xe85c <JNI_OnUnload+0x1fdc>
    e6c0:      	sub	x0, x29, #0x40
    e6c4:      	mov	x1, x24
    e6c8:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    e6cc:      	add	x8, x20, x26, lsl #4
    e6d0:      	ldrsw	x9, [x22, #0x2c]
    e6d4:      	mov	x10, x8
    e6d8:      	ldrb	w11, [x10, #0x1c]!
    e6dc:      	cbnz	w11, 0xe700 <JNI_OnUnload+0x1e80>
    e6e0:      	lsl	x11, x26, #4
    e6e4:      	add	x13, x19, #0x28
    e6e8:      	add	x12, x20, x11
    e6ec:      	add	x11, x13, x11
    e6f0:      	ldur	q0, [x12, #0x18]
    e6f4:      	mov	w12, #0x1               // =1
    e6f8:      	strb	w12, [x10]
    e6fc:      	stur	q0, [x11, #0x18]
    e700:      	mul	x9, x0, x9
    e704:      	mov	w10, #0x4               // =4
    e708:      	str	w10, [x8, #0x18]
    e70c:      	str	x9, [x8, #0x20]
    e710:      	ldur	x9, [x29, #-0x40]
    e714:      	cmp	x9, x24
    e718:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e71c:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e720:      	add	x8, x20, x26, lsl #4
    e724:      	ldrb	w8, [x8, #0x1c]
    e728:      	cbz	w8, 0xe744 <JNI_OnUnload+0x1ec4>
    e72c:      	lsl	x8, x26, #4
    e730:      	add	x9, x19, #0x28
    e734:      	add	x9, x9, x8
    e738:      	add	x8, x20, x8
    e73c:      	ldur	q0, [x9, #0x18]
    e740:      	stur	q0, [x8, #0x18]
    e744:      	bti	j
    e748:      	ldur	x9, [x29, #-0x40]
    e74c:      	cmp	x9, x24
    e750:      	b.hs	0xde44 <JNI_OnUnload+0x15c4>
    e754:      	cmp	x25, x21
    e758:      	b.lo	0xde74 <JNI_OnUnload+0x15f4>
    e75c:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e760:      	ldr	w8, [x22, #0x28]
    e764:      	mul	w8, w8, w26
    e768:      	add	x25, x25, x8
    e76c:      	ldur	x9, [x29, #-0x40]
    e770:      	cmp	x9, x24
    e774:      	b.lo	0xe754 <JNI_OnUnload+0x1ed4>
    e778:      	b	0xde44 <JNI_OnUnload+0x15c4>
    e77c:      	mov	w0, #0x1                // =1
    e780:      	b	0xe914 <JNI_OnUnload+0x2094>
    e784:      	adrp	x8, 0x15000
    e788:      	adrp	x0, 0x5000
    e78c:      	add	x0, x0, #0x6ca
    e790:      	b	0xe7e8 <JNI_OnUnload+0x1f68>
    e794:      	adrp	x8, 0x15000
    e798:      	adrp	x0, 0x5000
    e79c:      	add	x0, x0, #0x48b
    e7a0:      	ldr	x8, [x8, #0x1e0]
    e7a4:      	mov	w1, #0x45               // =69
    e7a8:      	add	x3, x8, #0x130
    e7ac:      	b	0xe8f8 <JNI_OnUnload+0x2078>
    e7b0:      	adrp	x8, 0x15000
    e7b4:      	adrp	x0, 0x5000
    e7b8:      	add	x0, x0, #0x8aa
    e7bc:      	ldr	x8, [x8, #0x1e0]
    e7c0:      	mov	w1, #0x44               // =68
    e7c4:      	add	x3, x8, #0x130
    e7c8:      	b	0xe8f8 <JNI_OnUnload+0x2078>
    e7cc:      	adrp	x8, 0x15000
    e7d0:      	adrp	x0, 0x5000
    e7d4:      	add	x0, x0, #0x978
    e7d8:      	b	0xe8d0 <JNI_OnUnload+0x2050>
    e7dc:      	adrp	x8, 0x15000
    e7e0:      	adrp	x0, 0x5000
    e7e4:      	add	x0, x0, #0x38b
    e7e8:      	ldr	x8, [x8, #0x1e0]
    e7ec:      	add	x3, x8, #0x130
    e7f0:      	mov	w1, #0x47               // =71
    e7f4:      	b	0xe8f8 <JNI_OnUnload+0x2078>
    e7f8:      	adrp	x8, 0x15000
    e7fc:      	adrp	x0, 0x4000
    e800:      	add	x0, x0, #0xac8
    e804:      	ldr	x8, [x8, #0x1e0]
    e808:      	mov	w1, #0x46               // =70
    e80c:      	add	x3, x8, #0x130
    e810:      	b	0xe8f8 <JNI_OnUnload+0x2078>
    e814:      	adrp	x8, 0x15000
    e818:      	adrp	x0, 0x5000
    e81c:      	add	x0, x0, #0x61a
    e820:      	ldr	x8, [x8, #0x1e0]
    e824:      	mov	w1, #0x53               // =83
    e828:      	add	x3, x8, #0x130
    e82c:      	b	0xe8f8 <JNI_OnUnload+0x2078>
    e830:      	adrp	x8, 0x15000
    e834:      	adrp	x0, 0x4000
    e838:      	add	x0, x0, #0x7d2
    e83c:      	ldr	x8, [x8, #0x1e0]
    e840:      	mov	w1, #0x3e               // =62
    e844:      	add	x3, x8, #0x130
    e848:      	b	0xe8f8 <JNI_OnUnload+0x2078>
    e84c:      	adrp	x8, 0x15000
    e850:      	adrp	x0, 0x5000
    e854:      	add	x0, x0, #0x7d9
    e858:      	b	0xe8ec <JNI_OnUnload+0x206c>
    e85c:      	adrp	x8, 0x15000
    e860:      	adrp	x1, 0x4000
    e864:      	add	x1, x1, #0x85f
    e868:      	ldr	x8, [x8, #0x1e0]
    e86c:      	mov	x2, x26
    e870:      	add	x0, x8, #0x130
    e874:      	bl	0x10d50 <fprintf@plt>
    e878:      	b	0xe900 <JNI_OnUnload+0x2080>
    e87c:      	adrp	x8, 0x15000
    e880:      	adrp	x0, 0x5000
    e884:      	add	x0, x0, #0xc8
    e888:      	ldr	x8, [x8, #0x1e0]
    e88c:      	mov	w1, #0x49               // =73
    e890:      	add	x3, x8, #0x130
    e894:      	b	0xe8f8 <JNI_OnUnload+0x2078>
    e898:      	adrp	x8, 0x15000
    e89c:      	adrp	x0, 0x5000
    e8a0:      	add	x0, x0, #0x68a
    e8a4:      	ldr	x8, [x8, #0x1e0]
    e8a8:      	mov	w1, #0x3f               // =63
    e8ac:      	add	x3, x8, #0x130
    e8b0:      	b	0xe8f8 <JNI_OnUnload+0x2078>
    e8b4:      	adrp	x8, 0x15000
    e8b8:      	adrp	x0, 0x4000
    e8bc:      	add	x0, x0, #0xfe5
    e8c0:      	b	0xe8d0 <JNI_OnUnload+0x2050>
    e8c4:      	adrp	x8, 0x15000
    e8c8:      	adrp	x0, 0x4000
    e8cc:      	add	x0, x0, #0x946
    e8d0:      	ldr	x8, [x8, #0x1e0]
    e8d4:      	add	x3, x8, #0x130
    e8d8:      	mov	w1, #0x41               // =65
    e8dc:      	b	0xe8f8 <JNI_OnUnload+0x2078>
    e8e0:      	adrp	x8, 0x15000
    e8e4:      	adrp	x0, 0x4000
    e8e8:      	add	x0, x0, #0xe52
    e8ec:      	ldr	x8, [x8, #0x1e0]
    e8f0:      	add	x3, x8, #0x130
    e8f4:      	mov	w1, #0x40               // =64
    e8f8:      	mov	w2, #0x1                // =1
    e8fc:      	bl	0x10a20 <fwrite@plt>
    e900:      	adrp	x8, 0x15000
    e904:      	ldr	x8, [x8, #0x1e0]
    e908:      	add	x0, x8, #0x130
    e90c:      	bl	0x10d60 <fflush@plt>
    e910:      	mov	w0, wzr
    e914:      	mov	sp, x29
    e918:      	ldp	x20, x19, [sp, #0x50]
    e91c:      	ldp	x22, x21, [sp, #0x40]
    e920:      	ldp	x24, x23, [sp, #0x30]
    e924:      	ldp	x26, x25, [sp, #0x20]
    e928:      	ldp	x28, x27, [sp, #0x10]
    e92c:      	ldp	x29, x30, [sp], #0x60
    e930:      	autiasp
    e934:      	ret
    e938:      	adrp	x20, 0x15000
    e93c:      	nop
    e940:      	adr	x1, 0x4677
    e944:      	ldr	x20, [x20, #0x1e0]
    e948:      	adrp	x2, 0x5000
    e94c:      	add	x2, x2, #0x19c
    e950:      	adrp	x3, 0x4000
    e954:      	add	x3, x3, #0xc76
    e958:      	add	x0, x20, #0x130
    e95c:      	bl	0x10d50 <fprintf@plt>
    e960:      	add	x0, x20, #0x130
    e964:      	bl	0x10d60 <fflush@plt>
    e968:      	bl	0x10d70 <abort@plt>
    e96c:      	adrp	x20, 0x15000
    e970:      	nop
    e974:      	adr	x1, 0x4677
    e978:      	ldr	x20, [x20, #0x1e0]
    e97c:      	adrp	x2, 0x5000
    e980:      	add	x2, x2, #0x19c
    e984:      	adrp	x3, 0x4000
    e988:      	add	x3, x3, #0xc76
    e98c:      	add	x0, x20, #0x130
    e990:      	bl	0x10d50 <fprintf@plt>
    e994:      	add	x0, x20, #0x130
    e998:      	bl	0x10d60 <fflush@plt>
    e99c:      	bl	0x10d70 <abort@plt>
    e9a0:      	adrp	x20, 0x15000
    e9a4:      	nop
    e9a8:      	adr	x1, 0x4677
    e9ac:      	ldr	x20, [x20, #0x1e0]
    e9b0:      	adrp	x2, 0x5000
    e9b4:      	add	x2, x2, #0x19c
    e9b8:      	adrp	x3, 0x4000
    e9bc:      	add	x3, x3, #0xc76
    e9c0:      	add	x0, x20, #0x130
    e9c4:      	bl	0x10d50 <fprintf@plt>
    e9c8:      	add	x0, x20, #0x130
    e9cc:      	bl	0x10d60 <fflush@plt>
    e9d0:      	bl	0x10d70 <abort@plt>
    e9d4:      	adrp	x20, 0x15000
    e9d8:      	nop
    e9dc:      	adr	x1, 0x4677
    e9e0:      	ldr	x20, [x20, #0x1e0]
    e9e4:      	adrp	x2, 0x5000
    e9e8:      	add	x2, x2, #0x19c
    e9ec:      	adrp	x3, 0x4000
    e9f0:      	add	x3, x3, #0xc76
    e9f4:      	add	x0, x20, #0x130
    e9f8:      	bl	0x10d50 <fprintf@plt>
    e9fc:      	add	x0, x20, #0x130
    ea00:      	bl	0x10d60 <fflush@plt>
    ea04:      	bl	0x10d70 <abort@plt>
    ea08:      	bti	c
    ea0c:      	ldr	w8, [x1]
    ea10:      	cmp	w8, #0x1d
    ea14:      	b.gt	0xea30 <JNI_OnUnload+0x21b0>
    ea18:      	tbz	w8, #0x1f, 0xea5c <JNI_OnUnload+0x21dc>
    ea1c:      	cmn	w8, #0x2
    ea20:      	b.eq	0xea48 <JNI_OnUnload+0x21c8>
    ea24:      	cmn	w8, #0x1
    ea28:      	b.eq	0xea8c <JNI_OnUnload+0x220c>
    ea2c:      	b	0xeadc <JNI_OnUnload+0x225c>
    ea30:      	cmp	w8, #0x1f
    ea34:      	b.gt	0xea7c <JNI_OnUnload+0x21fc>
    ea38:      	cmp	w8, #0x1e
    ea3c:      	b.eq	0xeaa0 <JNI_OnUnload+0x2220>
    ea40:      	cmp	w8, #0x1f
    ea44:      	b.ne	0xeadc <JNI_OnUnload+0x225c>
    ea48:      	add	x8, x2, #0xf8
    ea4c:      	ldr	x8, [x8]
    ea50:      	ldrsw	x9, [x1, #0x4]
    ea54:      	add	x0, x8, x9
    ea58:      	ret
    ea5c:      	cbz	w8, 0xeab4 <JNI_OnUnload+0x2234>
    ea60:      	cmp	w8, #0x1d
    ea64:      	b.ne	0xeadc <JNI_OnUnload+0x225c>
    ea68:      	add	x8, x2, #0xe8
    ea6c:      	ldr	x8, [x8]
    ea70:      	ldrsw	x9, [x1, #0x4]
    ea74:      	add	x0, x8, x9
    ea78:      	ret
    ea7c:      	cmp	w8, #0x22
    ea80:      	b.eq	0xeac8 <JNI_OnUnload+0x2248>
    ea84:      	cmp	w8, #0x20
    ea88:      	b.ne	0xeadc <JNI_OnUnload+0x225c>
    ea8c:      	add	x8, x2, #0x100
    ea90:      	ldr	x8, [x8]
    ea94:      	ldrsw	x9, [x1, #0x4]
    ea98:      	add	x0, x8, x9
    ea9c:      	ret
    eaa0:      	add	x8, x2, #0xf0
    eaa4:      	ldr	x8, [x8]
    eaa8:      	ldrsw	x9, [x1, #0x4]
    eaac:      	add	x0, x8, x9
    eab0:      	ret
    eab4:      	ldr	x8, [x1, #0x8]
    eab8:      	mov	x1, x0
    eabc:      	mov	x3, xzr
    eac0:      	mov	x0, x8
    eac4:      	b	0xf2a0 <JNI_OnUnload+0x2a20>
    eac8:      	add	x8, x2, #0x108
    eacc:      	ldr	x8, [x8]
    ead0:      	ldrsw	x9, [x1, #0x4]
    ead4:      	add	x0, x8, x9
    ead8:      	ret
    eadc:      	cmp	w8, #0x1c
    eae0:      	b.hi	0xeaf8 <JNI_OnUnload+0x2278>
    eae4:      	add	x8, x2, x8, lsl #3
    eae8:      	ldr	x8, [x8]
    eaec:      	ldrsw	x9, [x1, #0x4]
    eaf0:      	add	x0, x8, x9
    eaf4:      	ret
    eaf8:      	paciasp
    eafc:      	stp	x29, x30, [sp, #-0x20]!
    eb00:      	str	x19, [sp, #0x10]
    eb04:      	mov	x29, sp
    eb08:      	adrp	x19, 0x15000
    eb0c:      	nop
    eb10:      	adr	x1, 0x4677
    eb14:      	ldr	x19, [x19, #0x1e0]
    eb18:      	adrp	x2, 0x4000
    eb1c:      	add	x2, x2, #0xf2c
    eb20:      	adrp	x3, 0x4000
    eb24:      	add	x3, x3, #0xbfc
    eb28:      	add	x0, x19, #0x130
    eb2c:      	bl	0x10d50 <fprintf@plt>
    eb30:      	add	x0, x19, #0x130
    eb34:      	bl	0x10d60 <fflush@plt>
    eb38:      	bl	0x10d70 <abort@plt>
    eb3c:      	paciasp
    eb40:      	stp	x29, x30, [sp, #-0x20]!
    eb44:      	str	x19, [sp, #0x10]
    eb48:      	mov	x29, sp
    eb4c:      	ldr	w9, [x3]
    eb50:      	mov	x8, x2
    eb54:      	cmp	w9, #0x4
    eb58:      	b.gt	0xeb8c <JNI_OnUnload+0x230c>
    eb5c:      	cmp	w9, #0x1
    eb60:      	b.eq	0xebe4 <JNI_OnUnload+0x2364>
    eb64:      	cmp	w9, #0x2
    eb68:      	b.eq	0xeb74 <JNI_OnUnload+0x22f4>
    eb6c:      	cmp	w9, #0x3
    eb70:      	b.ne	0xece4 <JNI_OnUnload+0x2464>
    eb74:      	ldr	x9, [x3, #0x8]
    eb78:      	ldr	x0, [x9, x8]
    eb7c:      	ldr	x19, [sp, #0x10]
    eb80:      	ldp	x29, x30, [sp], #0x20
    eb84:      	autiasp
    eb88:      	ret
    eb8c:      	mov	x2, x1
    eb90:      	cmp	w9, #0x5
    eb94:      	b.eq	0xebf8 <JNI_OnUnload+0x2378>
    eb98:      	mov	x1, x0
    eb9c:      	cmp	w9, #0x6
    eba0:      	b.eq	0xebc4 <JNI_OnUnload+0x2344>
    eba4:      	cmp	w9, #0x7
    eba8:      	b.ne	0xece4 <JNI_OnUnload+0x2464>
    ebac:      	ldr	x0, [x3, #0x8]
    ebb0:      	mov	x3, x8
    ebb4:      	ldr	x19, [sp, #0x10]
    ebb8:      	ldp	x29, x30, [sp], #0x20
    ebbc:      	autiasp
    ebc0:      	b	0xf2a0 <JNI_OnUnload+0x2a20>
    ebc4:      	ldr	x0, [x3, #0x8]
    ebc8:      	mov	x3, x8
    ebcc:      	bl	0xf2a0 <JNI_OnUnload+0x2a20>
    ebd0:      	ldr	x0, [x0]
    ebd4:      	ldr	x19, [sp, #0x10]
    ebd8:      	ldp	x29, x30, [sp], #0x20
    ebdc:      	autiasp
    ebe0:      	ret
    ebe4:      	mov	x0, xzr
    ebe8:      	ldr	x19, [sp, #0x10]
    ebec:      	ldp	x29, x30, [sp], #0x20
    ebf0:      	autiasp
    ebf4:      	ret
    ebf8:      	ldr	x8, [x3, #0x8]
    ebfc:      	cmp	w8, #0x1d
    ec00:      	b.le	0xec20 <JNI_OnUnload+0x23a0>
    ec04:      	cmp	w8, #0x1f
    ec08:      	b.gt	0xec50 <JNI_OnUnload+0x23d0>
    ec0c:      	cmp	w8, #0x1e
    ec10:      	b.eq	0xecb4 <JNI_OnUnload+0x2434>
    ec14:      	cmp	w8, #0x1f
    ec18:      	b.eq	0xec78 <JNI_OnUnload+0x23f8>
    ec1c:      	b	0xec90 <JNI_OnUnload+0x2410>
    ec20:      	cmn	w8, #0x2
    ec24:      	b.eq	0xec78 <JNI_OnUnload+0x23f8>
    ec28:      	cmn	w8, #0x1
    ec2c:      	b.eq	0xec60 <JNI_OnUnload+0x23e0>
    ec30:      	cmp	w8, #0x1d
    ec34:      	b.ne	0xec90 <JNI_OnUnload+0x2410>
    ec38:      	add	x8, x2, #0xe8
    ec3c:      	ldr	x0, [x8]
    ec40:      	ldr	x19, [sp, #0x10]
    ec44:      	ldp	x29, x30, [sp], #0x20
    ec48:      	autiasp
    ec4c:      	ret
    ec50:      	cmp	w8, #0x22
    ec54:      	b.eq	0xeccc <JNI_OnUnload+0x244c>
    ec58:      	cmp	w8, #0x20
    ec5c:      	b.ne	0xec90 <JNI_OnUnload+0x2410>
    ec60:      	add	x8, x2, #0x100
    ec64:      	ldr	x0, [x8]
    ec68:      	ldr	x19, [sp, #0x10]
    ec6c:      	ldp	x29, x30, [sp], #0x20
    ec70:      	autiasp
    ec74:      	ret
    ec78:      	add	x8, x2, #0xf8
    ec7c:      	ldr	x0, [x8]
    ec80:      	ldr	x19, [sp, #0x10]
    ec84:      	ldp	x29, x30, [sp], #0x20
    ec88:      	autiasp
    ec8c:      	ret
    ec90:      	cmp	w8, #0x1c
    ec94:      	b.hi	0xed18 <JNI_OnUnload+0x2498>
    ec98:      	and	x8, x8, #0xffffffff
    ec9c:      	add	x8, x2, x8, lsl #3
    eca0:      	ldr	x0, [x8]
    eca4:      	ldr	x19, [sp, #0x10]
    eca8:      	ldp	x29, x30, [sp], #0x20
    ecac:      	autiasp
    ecb0:      	ret
    ecb4:      	add	x8, x2, #0xf0
    ecb8:      	ldr	x0, [x8]
    ecbc:      	ldr	x19, [sp, #0x10]
    ecc0:      	ldp	x29, x30, [sp], #0x20
    ecc4:      	autiasp
    ecc8:      	ret
    eccc:      	add	x8, x2, #0x108
    ecd0:      	ldr	x0, [x8]
    ecd4:      	ldr	x19, [sp, #0x10]
    ecd8:      	ldp	x29, x30, [sp], #0x20
    ecdc:      	autiasp
    ece0:      	ret
    ece4:      	adrp	x19, 0x15000
    ece8:      	nop
    ecec:      	adr	x1, 0x4677
    ecf0:      	ldr	x19, [x19, #0x1e0]
    ecf4:      	adrp	x2, 0x4000
    ecf8:      	add	x2, x2, #0xec3
    ecfc:      	adrp	x3, 0x4000
    ed00:      	add	x3, x3, #0xc17
    ed04:      	add	x0, x19, #0x130
    ed08:      	bl	0x10d50 <fprintf@plt>
    ed0c:      	add	x0, x19, #0x130
    ed10:      	bl	0x10d60 <fflush@plt>
    ed14:      	bl	0x10d70 <abort@plt>
    ed18:      	adrp	x19, 0x15000
    ed1c:      	nop
    ed20:      	adr	x1, 0x4677
    ed24:      	ldr	x19, [x19, #0x1e0]
    ed28:      	adrp	x2, 0x4000
    ed2c:      	add	x2, x2, #0xf2c
    ed30:      	adrp	x3, 0x4000
    ed34:      	add	x3, x3, #0xbfc
    ed38:      	add	x0, x19, #0x130
    ed3c:      	bl	0x10d50 <fprintf@plt>
    ed40:      	add	x0, x19, #0x130
    ed44:      	bl	0x10d60 <fflush@plt>
    ed48:      	bl	0x10d70 <abort@plt>
    ed4c:      	paciasp
    ed50:      	stp	x29, x30, [sp, #-0x30]!
    ed54:      	str	x21, [sp, #0x10]
    ed58:      	stp	x20, x19, [sp, #0x20]
    ed5c:      	mov	x29, sp
    ed60:      	and	w8, w3, #0xf
    ed64:      	ldr	x19, [x1]
    ed68:      	cmp	w8, #0x3
    ed6c:      	b.le	0xed94 <JNI_OnUnload+0x2514>
    ed70:      	cmp	w8, #0x9
    ed74:      	b.le	0xee08 <JNI_OnUnload+0x2588>
    ed78:      	cmp	w8, #0xa
    ed7c:      	b.eq	0xeed8 <JNI_OnUnload+0x2658>
    ed80:      	cmp	w8, #0xb
    ed84:      	b.eq	0xeef8 <JNI_OnUnload+0x2678>
    ed88:      	cmp	w8, #0xc
    ed8c:      	b.eq	0xee98 <JNI_OnUnload+0x2618>
    ed90:      	b	0xf0a4 <JNI_OnUnload+0x2824>
    ed94:      	cmp	w8, #0x1
    ed98:      	b.gt	0xedd8 <JNI_OnUnload+0x2558>
    ed9c:      	cbz	w8, 0xee98 <JNI_OnUnload+0x2618>
    eda0:      	cmp	w8, #0x1
    eda4:      	b.ne	0xf0a4 <JNI_OnUnload+0x2824>
    eda8:      	mov	x0, x1
    edac:      	mov	x1, x2
    edb0:      	mov	w20, w3
    edb4:      	mov	x21, x4
    edb8:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    edbc:      	mov	x4, x21
    edc0:      	mov	w3, w20
    edc4:      	and	w8, w20, #0xff
    edc8:      	ubfx	w8, w8, #4, #3
    edcc:      	cmp	w8, #0x1
    edd0:      	b.le	0xef14 <JNI_OnUnload+0x2694>
    edd4:      	b	0xee80 <JNI_OnUnload+0x2600>
    edd8:      	cmp	w8, #0x2
    eddc:      	b.eq	0xeeb8 <JNI_OnUnload+0x2638>
    ede0:      	cmp	w8, #0x3
    ede4:      	b.ne	0xf0a4 <JNI_OnUnload+0x2824>
    ede8:      	mov	x8, x19
    edec:      	ldr	w0, [x8], #0x4
    edf0:      	str	x8, [x1]
    edf4:      	and	w8, w3, #0xff
    edf8:      	ubfx	w8, w8, #4, #3
    edfc:      	cmp	w8, #0x1
    ee00:      	b.le	0xef14 <JNI_OnUnload+0x2694>
    ee04:      	b	0xee80 <JNI_OnUnload+0x2600>
    ee08:      	cmp	w8, #0x4
    ee0c:      	b.eq	0xee98 <JNI_OnUnload+0x2618>
    ee10:      	cmp	w8, #0x9
    ee14:      	b.ne	0xf0a4 <JNI_OnUnload+0x2824>
    ee18:      	mov	x10, xzr
    ee1c:      	mov	x8, xzr
    ee20:      	mov	x9, x19
    ee24:      	mov	x11, x19
    ee28:      	cmp	x11, x2
    ee2c:      	b.eq	0xef54 <JNI_OnUnload+0x26d4>
    ee30:      	ldrb	w12, [x11], #0x1
    ee34:      	add	x9, x9, #0x1
    ee38:      	and	x13, x12, #0x7f
    ee3c:      	lsl	x13, x13, x10
    ee40:      	add	x10, x10, #0x7
    ee44:      	orr	x8, x13, x8
    ee48:      	tbnz	w12, #0x7, 0xee28 <JNI_OnUnload+0x25a8>
    ee4c:      	sub	w11, w10, #0x7
    ee50:      	mov	x13, #-0x1              // =-1
    ee54:      	str	x9, [x1]
    ee58:      	cmp	w11, #0x39
    ee5c:      	mov	w11, #0x3f              // =63
    ee60:      	lsl	x10, x13, x10
    ee64:      	ccmp	w12, w11, #0x0, lo
    ee68:      	csel	x10, x10, xzr, hi
    ee6c:      	orr	x0, x8, x10
    ee70:      	and	w8, w3, #0xff
    ee74:      	ubfx	w8, w8, #4, #3
    ee78:      	cmp	w8, #0x1
    ee7c:      	b.le	0xef14 <JNI_OnUnload+0x2694>
    ee80:      	cmp	w8, #0x3
    ee84:      	b.gt	0xef88 <JNI_OnUnload+0x2708>
    ee88:      	b.ne	0xefcc <JNI_OnUnload+0x274c>
    ee8c:      	cbz	x4, 0xf03c <JNI_OnUnload+0x27bc>
    ee90:      	add	x0, x0, x4
    ee94:      	b	0xef24 <JNI_OnUnload+0x26a4>
    ee98:      	mov	x8, x19
    ee9c:      	ldr	x0, [x8], #0x8
    eea0:      	str	x8, [x1]
    eea4:      	and	w8, w3, #0xff
    eea8:      	ubfx	w8, w8, #4, #3
    eeac:      	cmp	w8, #0x1
    eeb0:      	b.le	0xef14 <JNI_OnUnload+0x2694>
    eeb4:      	b	0xee80 <JNI_OnUnload+0x2600>
    eeb8:      	mov	x8, x19
    eebc:      	ldrh	w0, [x8], #0x2
    eec0:      	str	x8, [x1]
    eec4:      	and	w8, w3, #0xff
    eec8:      	ubfx	w8, w8, #4, #3
    eecc:      	cmp	w8, #0x1
    eed0:      	b.le	0xef14 <JNI_OnUnload+0x2694>
    eed4:      	b	0xee80 <JNI_OnUnload+0x2600>
    eed8:      	mov	x8, x19
    eedc:      	ldrsh	x0, [x8], #0x2
    eee0:      	str	x8, [x1]
    eee4:      	and	w8, w3, #0xff
    eee8:      	ubfx	w8, w8, #4, #3
    eeec:      	cmp	w8, #0x1
    eef0:      	b.le	0xef14 <JNI_OnUnload+0x2694>
    eef4:      	b	0xee80 <JNI_OnUnload+0x2600>
    eef8:      	mov	x8, x19
    eefc:      	ldrsw	x0, [x8], #0x4
    ef00:      	str	x8, [x1]
    ef04:      	and	w8, w3, #0xff
    ef08:      	ubfx	w8, w8, #4, #3
    ef0c:      	cmp	w8, #0x1
    ef10:      	b.gt	0xee80 <JNI_OnUnload+0x2600>
    ef14:      	cbz	w8, 0xef24 <JNI_OnUnload+0x26a4>
    ef18:      	cmp	w8, #0x1
    ef1c:      	b.ne	0xf070 <JNI_OnUnload+0x27f0>
    ef20:      	add	x0, x0, x19
    ef24:      	tbnz	w3, #0x7, 0xef3c <JNI_OnUnload+0x26bc>
    ef28:      	ldp	x20, x19, [sp, #0x20]
    ef2c:      	ldr	x21, [sp, #0x10]
    ef30:      	ldp	x29, x30, [sp], #0x30
    ef34:      	autiasp
    ef38:      	ret
    ef3c:      	ldr	x0, [x0]
    ef40:      	ldp	x20, x19, [sp, #0x20]
    ef44:      	ldr	x21, [sp, #0x10]
    ef48:      	ldp	x29, x30, [sp], #0x30
    ef4c:      	autiasp
    ef50:      	ret
    ef54:      	adrp	x19, 0x15000
    ef58:      	nop
    ef5c:      	adr	x1, 0x4677
    ef60:      	ldr	x19, [x19, #0x1e0]
    ef64:      	adrp	x2, 0x5000
    ef68:      	add	x2, x2, #0x19c
    ef6c:      	adrp	x3, 0x4000
    ef70:      	add	x3, x3, #0xc76
    ef74:      	add	x0, x19, #0x130
    ef78:      	bl	0x10d50 <fprintf@plt>
    ef7c:      	add	x0, x19, #0x130
    ef80:      	bl	0x10d60 <fflush@plt>
    ef84:      	bl	0x10d70 <abort@plt>
    ef88:      	cmp	w8, #0x4
    ef8c:      	b.eq	0xf008 <JNI_OnUnload+0x2788>
    ef90:      	cmp	w8, #0x5
    ef94:      	b.ne	0xf070 <JNI_OnUnload+0x27f0>
    ef98:      	adrp	x19, 0x15000
    ef9c:      	nop
    efa0:      	adr	x1, 0x4677
    efa4:      	ldr	x19, [x19, #0x1e0]
    efa8:      	adrp	x2, 0x5000
    efac:      	add	x2, x2, #0x8ef
    efb0:      	adrp	x3, 0x4000
    efb4:      	add	x3, x3, #0xe93
    efb8:      	add	x0, x19, #0x130
    efbc:      	bl	0x10d50 <fprintf@plt>
    efc0:      	add	x0, x19, #0x130
    efc4:      	bl	0x10d60 <fflush@plt>
    efc8:      	bl	0x10d70 <abort@plt>
    efcc:      	cmp	w8, #0x2
    efd0:      	b.ne	0xf070 <JNI_OnUnload+0x27f0>
    efd4:      	adrp	x19, 0x15000
    efd8:      	nop
    efdc:      	adr	x1, 0x4677
    efe0:      	ldr	x19, [x19, #0x1e0]
    efe4:      	adrp	x2, 0x5000
    efe8:      	add	x2, x2, #0x8ef
    efec:      	adrp	x3, 0x5000
    eff0:      	add	x3, x3, #0x3d3
    eff4:      	add	x0, x19, #0x130
    eff8:      	bl	0x10d50 <fprintf@plt>
    effc:      	add	x0, x19, #0x130
    f000:      	bl	0x10d60 <fflush@plt>
    f004:      	bl	0x10d70 <abort@plt>
    f008:      	adrp	x19, 0x15000
    f00c:      	nop
    f010:      	adr	x1, 0x4677
    f014:      	ldr	x19, [x19, #0x1e0]
    f018:      	adrp	x2, 0x5000
    f01c:      	add	x2, x2, #0x8ef
    f020:      	adrp	x3, 0x4000
    f024:      	add	x3, x3, #0x68b
    f028:      	add	x0, x19, #0x130
    f02c:      	bl	0x10d50 <fprintf@plt>
    f030:      	add	x0, x19, #0x130
    f034:      	bl	0x10d60 <fflush@plt>
    f038:      	bl	0x10d70 <abort@plt>
    f03c:      	adrp	x19, 0x15000
    f040:      	nop
    f044:      	adr	x1, 0x4677
    f048:      	ldr	x19, [x19, #0x1e0]
    f04c:      	adrp	x2, 0x5000
    f050:      	add	x2, x2, #0x8ef
    f054:      	adrp	x3, 0x5000
    f058:      	add	x3, x3, #0x5a7
    f05c:      	add	x0, x19, #0x130
    f060:      	bl	0x10d50 <fprintf@plt>
    f064:      	add	x0, x19, #0x130
    f068:      	bl	0x10d60 <fflush@plt>
    f06c:      	bl	0x10d70 <abort@plt>
    f070:      	adrp	x19, 0x15000
    f074:      	nop
    f078:      	adr	x1, 0x4677
    f07c:      	ldr	x19, [x19, #0x1e0]
    f080:      	adrp	x2, 0x5000
    f084:      	add	x2, x2, #0x8ef
    f088:      	adrp	x3, 0x5000
    f08c:      	add	x3, x3, #0x183
    f090:      	add	x0, x19, #0x130
    f094:      	bl	0x10d50 <fprintf@plt>
    f098:      	add	x0, x19, #0x130
    f09c:      	bl	0x10d60 <fflush@plt>
    f0a0:      	bl	0x10d70 <abort@plt>
    f0a4:      	adrp	x19, 0x15000
    f0a8:      	nop
    f0ac:      	adr	x1, 0x4677
    f0b0:      	ldr	x19, [x19, #0x1e0]
    f0b4:      	adrp	x2, 0x5000
    f0b8:      	add	x2, x2, #0x8ef
    f0bc:      	adrp	x3, 0x5000
    f0c0:      	add	x3, x3, #0x183
    f0c4:      	add	x0, x19, #0x130
    f0c8:      	bl	0x10d50 <fprintf@plt>
    f0cc:      	add	x0, x19, #0x130
    f0d0:      	bl	0x10d60 <fflush@plt>
    f0d4:      	bl	0x10d70 <abort@plt>
    f0d8:      	paciasp
    f0dc:      	stp	x29, x30, [sp, #-0x20]!
    f0e0:      	str	x19, [sp, #0x10]
    f0e4:      	mov	x29, sp
    f0e8:      	ldr	x9, [x0]
    f0ec:      	cmp	x9, x1
    f0f0:      	b.eq	0xf238 <JNI_OnUnload+0x29b8>
    f0f4:      	mov	x10, x9
    f0f8:      	mov	x8, x0
    f0fc:      	ldrb	w11, [x10], #0x1
    f100:      	and	x0, x11, #0x7f
    f104:      	tbnz	w11, #0x7, 0xf11c <JNI_OnUnload+0x289c>
    f108:      	str	x10, [x8]
    f10c:      	ldr	x19, [sp, #0x10]
    f110:      	ldp	x29, x30, [sp], #0x20
    f114:      	autiasp
    f118:      	ret
    f11c:      	cmp	x10, x1
    f120:      	b.eq	0xf238 <JNI_OnUnload+0x29b8>
    f124:      	ldrsb	w11, [x9, #0x1]
    f128:      	and	w10, w11, #0x7f
    f12c:      	orr	x0, x0, x10, lsl #7
    f130:      	add	x10, x9, #0x2
    f134:      	tbz	w11, #0x1f, 0xf108 <JNI_OnUnload+0x2888>
    f138:      	cmp	x10, x1
    f13c:      	b.eq	0xf238 <JNI_OnUnload+0x29b8>
    f140:      	ldrsb	w11, [x9, #0x2]
    f144:      	and	w10, w11, #0x7f
    f148:      	orr	x0, x0, x10, lsl #14
    f14c:      	add	x10, x9, #0x3
    f150:      	tbz	w11, #0x1f, 0xf108 <JNI_OnUnload+0x2888>
    f154:      	cmp	x10, x1
    f158:      	b.eq	0xf238 <JNI_OnUnload+0x29b8>
    f15c:      	ldrsb	w11, [x9, #0x3]
    f160:      	and	w10, w11, #0x7f
    f164:      	orr	x0, x0, x10, lsl #21
    f168:      	add	x10, x9, #0x4
    f16c:      	tbz	w11, #0x1f, 0xf108 <JNI_OnUnload+0x2888>
    f170:      	cmp	x10, x1
    f174:      	b.eq	0xf238 <JNI_OnUnload+0x29b8>
    f178:      	ldrsb	w11, [x9, #0x4]
    f17c:      	and	w10, w11, #0x7f
    f180:      	orr	x0, x0, x10, lsl #28
    f184:      	add	x10, x9, #0x5
    f188:      	tbz	w11, #0x1f, 0xf108 <JNI_OnUnload+0x2888>
    f18c:      	cmp	x10, x1
    f190:      	b.eq	0xf238 <JNI_OnUnload+0x29b8>
    f194:      	ldrsb	w11, [x9, #0x5]
    f198:      	and	w10, w11, #0x7f
    f19c:      	orr	x0, x0, x10, lsl #35
    f1a0:      	add	x10, x9, #0x6
    f1a4:      	tbz	w11, #0x1f, 0xf108 <JNI_OnUnload+0x2888>
    f1a8:      	cmp	x10, x1
    f1ac:      	b.eq	0xf238 <JNI_OnUnload+0x29b8>
    f1b0:      	ldrsb	w11, [x9, #0x6]
    f1b4:      	and	w10, w11, #0x7f
    f1b8:      	orr	x0, x0, x10, lsl #42
    f1bc:      	add	x10, x9, #0x7
    f1c0:      	tbz	w11, #0x1f, 0xf108 <JNI_OnUnload+0x2888>
    f1c4:      	cmp	x10, x1
    f1c8:      	b.eq	0xf238 <JNI_OnUnload+0x29b8>
    f1cc:      	ldrsb	w11, [x9, #0x7]
    f1d0:      	and	w10, w11, #0x7f
    f1d4:      	orr	x0, x0, x10, lsl #49
    f1d8:      	add	x10, x9, #0x8
    f1dc:      	tbz	w11, #0x1f, 0xf108 <JNI_OnUnload+0x2888>
    f1e0:      	cmp	x10, x1
    f1e4:      	b.eq	0xf238 <JNI_OnUnload+0x29b8>
    f1e8:      	ldrsb	w11, [x9, #0x8]
    f1ec:      	and	w10, w11, #0x7f
    f1f0:      	orr	x0, x0, x10, lsl #56
    f1f4:      	add	x10, x9, #0x9
    f1f8:      	tbz	w11, #0x1f, 0xf108 <JNI_OnUnload+0x2888>
    f1fc:      	cmp	x10, x1
    f200:      	b.eq	0xf238 <JNI_OnUnload+0x29b8>
    f204:      	ldrb	w11, [x10]
    f208:      	tst	w11, #0x7e
    f20c:      	b.ne	0xf26c <JNI_OnUnload+0x29ec>
    f210:      	add	x10, x9, #0xa
    f214:      	tbnz	w11, #0x7, 0xf230 <JNI_OnUnload+0x29b0>
    f218:      	orr	x0, x0, x11, lsl #63
    f21c:      	str	x10, [x8]
    f220:      	ldr	x19, [sp, #0x10]
    f224:      	ldp	x29, x30, [sp], #0x20
    f228:      	autiasp
    f22c:      	ret
    f230:      	cmp	x10, x1
    f234:      	b.ne	0xf26c <JNI_OnUnload+0x29ec>
    f238:      	adrp	x19, 0x15000
    f23c:      	nop
    f240:      	adr	x1, 0x4677
    f244:      	ldr	x19, [x19, #0x1e0]
    f248:      	adrp	x2, 0x4000
    f24c:      	add	x2, x2, #0xa71
    f250:      	adrp	x3, 0x4000
    f254:      	add	x3, x3, #0xb3d
    f258:      	add	x0, x19, #0x130
    f25c:      	bl	0x10d50 <fprintf@plt>
    f260:      	add	x0, x19, #0x130
    f264:      	bl	0x10d60 <fflush@plt>
    f268:      	bl	0x10d70 <abort@plt>
    f26c:      	adrp	x19, 0x15000
    f270:      	nop
    f274:      	adr	x1, 0x4677
    f278:      	ldr	x19, [x19, #0x1e0]
    f27c:      	adrp	x2, 0x4000
    f280:      	add	x2, x2, #0xa71
    f284:      	adrp	x3, 0x4000
    f288:      	add	x3, x3, #0xdba
    f28c:      	add	x0, x19, #0x130
    f290:      	bl	0x10d50 <fprintf@plt>
    f294:      	add	x0, x19, #0x130
    f298:      	bl	0x10d60 <fflush@plt>
    f29c:      	bl	0x10d70 <abort@plt>
    f2a0:      	paciasp
    f2a4:      	stp	x29, x30, [sp, #-0x60]!
    f2a8:      	stp	x28, x27, [sp, #0x10]
    f2ac:      	stp	x26, x25, [sp, #0x20]
    f2b0:      	stp	x24, x23, [sp, #0x30]
    f2b4:      	stp	x22, x21, [sp, #0x40]
    f2b8:      	stp	x20, x19, [sp, #0x50]
    f2bc:      	mov	x29, sp
    f2c0:      	sub	sp, sp, #0x330
    f2c4:      	mov	x8, x0
    f2c8:      	stur	x0, [x29, #-0x8]
    f2cc:      	sub	x0, x29, #0x8
    f2d0:      	add	x1, x8, #0x14
    f2d4:      	mov	x21, x3
    f2d8:      	mov	x19, x2
    f2dc:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    f2e0:      	ldur	x10, [x29, #-0x8]
    f2e4:      	str	x21, [sp, #0x10]
    f2e8:      	add	x20, x10, x0
    f2ec:      	cmp	x10, x20
    f2f0:      	b.hs	0xfa20 <JNI_OnUnload+0x31a0>
    f2f4:      	add	x8, sp, #0x8
    f2f8:      	add	x21, x19, #0xf0
    f2fc:      	add	x22, x19, #0xe8
    f300:      	add	x23, x19, #0x108
    f304:      	add	x24, x19, #0xf8
    f308:      	add	x27, x8, #0x8
    f30c:      	add	x25, x19, #0x100
    f310:      	nop
    f314:      	adr	x26, 0x5a76 <_ZTSSt9bad_alloc+0x6d>
    f318:      	b	0xf330 <JNI_OnUnload+0x2ab0>
    f31c:      	ldr	x8, [x8]
    f320:      	str	x8, [x27, #0x8]!
    f324:      	ldur	x10, [x29, #-0x8]
    f328:      	cmp	x10, x20
    f32c:      	b.hs	0xfa1c <JNI_OnUnload+0x319c>
    f330:      	add	x8, x10, #0x1
    f334:      	stur	x8, [x29, #-0x8]
    f338:      	ldrb	w9, [x10]
    f33c:      	sub	w11, w9, #0x3
    f340:      	cmp	w11, #0x91
    f344:      	b.hi	0xfb18 <JNI_OnUnload+0x3298>
    f348:      	adr	x12, 0xf358 <JNI_OnUnload+0x2ad8>
    f34c:      	ldrh	w13, [x26, x11, lsl #1]
    f350:      	add	x12, x12, x13, lsl #2
    f354:      	br	x12
    f358:      	bti	j
    f35c:      	sub	w8, w9, #0x30
    f360:      	b	0xf320 <JNI_OnUnload+0x2aa0>
    f364:      	bti	j
    f368:      	mov	x12, xzr
    f36c:      	mov	x10, xzr
    f370:      	sub	w11, w9, #0x70
    f374:      	mov	x13, x8
    f378:      	cmp	x13, x20
    f37c:      	b.eq	0xfa48 <JNI_OnUnload+0x31c8>
    f380:      	ldrb	w14, [x13], #0x1
    f384:      	add	x8, x8, #0x1
    f388:      	and	x15, x14, #0x7f
    f38c:      	lsl	x15, x15, x12
    f390:      	add	x12, x12, #0x7
    f394:      	orr	x10, x15, x10
    f398:      	tbnz	w14, #0x7, 0xf378 <JNI_OnUnload+0x2af8>
    f39c:      	sub	w13, w12, #0x7
    f3a0:      	mov	x15, #-0x1              // =-1
    f3a4:      	stur	x8, [x29, #-0x8]
    f3a8:      	cmp	w13, #0x39
    f3ac:      	mov	w13, #0x3f              // =63
    f3b0:      	lsl	x12, x15, x12
    f3b4:      	ccmp	w14, w13, #0x0, lo
    f3b8:      	csel	x12, x12, xzr, hi
    f3bc:      	cmp	w9, #0x8d
    f3c0:      	b.le	0xf41c <JNI_OnUnload+0x2b9c>
    f3c4:      	cmp	w9, #0x8f
    f3c8:      	b.gt	0xf444 <JNI_OnUnload+0x2bc4>
    f3cc:      	cmp	w9, #0x8e
    f3d0:      	mov	x8, x21
    f3d4:      	b.eq	0xf468 <JNI_OnUnload+0x2be8>
    f3d8:      	cmp	w9, #0x8f
    f3dc:      	mov	x8, x24
    f3e0:      	b.eq	0xf468 <JNI_OnUnload+0x2be8>
    f3e4:      	b	0xf45c <JNI_OnUnload+0x2bdc>
    f3e8:      	bti	j
    f3ec:      	cmp	w9, #0x6f
    f3f0:      	mov	x8, x24
    f3f4:      	b.eq	0xf31c <JNI_OnUnload+0x2a9c>
    f3f8:      	cmp	w9, #0x6e
    f3fc:      	mov	x8, x21
    f400:      	b.eq	0xf31c <JNI_OnUnload+0x2a9c>
    f404:      	cmp	w9, #0x6d
    f408:      	mov	x8, x22
    f40c:      	b.eq	0xf31c <JNI_OnUnload+0x2a9c>
    f410:      	sub	w8, w9, #0x50
    f414:      	add	x8, x19, w8, uxtw #3
    f418:      	b	0xf31c <JNI_OnUnload+0x2a9c>
    f41c:      	cmp	w9, #0x6e
    f420:      	mov	x8, x24
    f424:      	b.eq	0xf468 <JNI_OnUnload+0x2be8>
    f428:      	cmp	w9, #0x6f
    f42c:      	mov	x8, x25
    f430:      	b.eq	0xf468 <JNI_OnUnload+0x2be8>
    f434:      	cmp	w9, #0x8d
    f438:      	mov	x8, x22
    f43c:      	b.eq	0xf468 <JNI_OnUnload+0x2be8>
    f440:      	b	0xf45c <JNI_OnUnload+0x2bdc>
    f444:      	cmp	w9, #0x90
    f448:      	mov	x8, x25
    f44c:      	b.eq	0xf468 <JNI_OnUnload+0x2be8>
    f450:      	cmp	w9, #0x92
    f454:      	mov	x8, x23
    f458:      	b.eq	0xf468 <JNI_OnUnload+0x2be8>
    f45c:      	cmp	w11, #0x1c
    f460:      	b.hi	0xfae4 <JNI_OnUnload+0x3264>
    f464:      	add	x8, x19, w11, uxtw #3
    f468:      	ldr	x8, [x8]
    f46c:      	orr	x9, x10, x12
    f470:      	add	x8, x8, x9
    f474:      	b	0xf320 <JNI_OnUnload+0x2aa0>
    f478:      	bti	j
    f47c:      	ldur	x8, [x10, #0x1]
    f480:      	add	x9, x10, #0x9
    f484:      	b	0xf788 <JNI_OnUnload+0x2f08>
    f488:      	bti	j
    f48c:      	sub	x0, x29, #0x8
    f490:      	mov	x1, x20
    f494:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    f498:      	ldur	x10, [x29, #-0x8]
    f49c:      	mov	x9, xzr
    f4a0:      	mov	x8, xzr
    f4a4:      	mov	x11, x10
    f4a8:      	cmp	x11, x20
    f4ac:      	b.eq	0xfa7c <JNI_OnUnload+0x31fc>
    f4b0:      	ldrb	w12, [x11], #0x1
    f4b4:      	add	x10, x10, #0x1
    f4b8:      	and	x13, x12, #0x7f
    f4bc:      	lsl	x13, x13, x9
    f4c0:      	add	x9, x9, #0x7
    f4c4:      	orr	x8, x13, x8
    f4c8:      	tbnz	w12, #0x7, 0xf4a8 <JNI_OnUnload+0x2c28>
    f4cc:      	sub	w11, w9, #0x7
    f4d0:      	mov	x13, #-0x1              // =-1
    f4d4:      	stur	x10, [x29, #-0x8]
    f4d8:      	cmp	w11, #0x39
    f4dc:      	mov	w11, #0x3f              // =63
    f4e0:      	lsl	x9, x13, x9
    f4e4:      	ccmp	w12, w11, #0x0, lo
    f4e8:      	csel	x9, x9, xzr, hi
    f4ec:      	cmp	w0, #0x1d
    f4f0:      	b.le	0xf980 <JNI_OnUnload+0x3100>
    f4f4:      	cmp	w0, #0x1f
    f4f8:      	b.gt	0xf9d0 <JNI_OnUnload+0x3150>
    f4fc:      	cmp	w0, #0x1e
    f500:      	mov	x10, x21
    f504:      	b.eq	0xf9f4 <JNI_OnUnload+0x3174>
    f508:      	cmp	w0, #0x1f
    f50c:      	mov	x10, x24
    f510:      	b.eq	0xf9f4 <JNI_OnUnload+0x3174>
    f514:      	b	0xf9e8 <JNI_OnUnload+0x3168>
    f518:      	bti	j
    f51c:      	mov	x8, x27
    f520:      	ldr	x9, [x27]
    f524:      	ldr	x10, [x8, #-0x8]!
    f528:      	cmp	x10, x9
    f52c:      	cset	w9, lo
    f530:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f534:      	bti	j
    f538:      	mov	x8, x27
    f53c:      	ldr	x9, [x27]
    f540:      	ldr	x10, [x8, #-0x8]!
    f544:      	cmp	x10, x9
    f548:      	cset	w9, ls
    f54c:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f550:      	bti	j
    f554:      	mov	x8, x27
    f558:      	ldr	x9, [x27]
    f55c:      	ldr	x10, [x8, #-0x8]!
    f560:      	sdiv	x11, x10, x9
    f564:      	msub	x9, x11, x9, x10
    f568:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f56c:      	bti	j
    f570:      	mov	x8, x27
    f574:      	ldr	x9, [x27]
    f578:      	ldr	x10, [x8, #-0x8]!
    f57c:      	cmp	x10, x9
    f580:      	cset	w9, eq
    f584:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f588:      	bti	j
    f58c:      	ldursh	x8, [x10, #0x1]
    f590:      	add	x9, x10, #0x3
    f594:      	b	0xf788 <JNI_OnUnload+0x2f08>
    f598:      	bti	j
    f59c:      	ldr	x11, [x27], #-0x8
    f5a0:      	ldursh	x8, [x10, #0x1]
    f5a4:      	add	x9, x10, #0x3
    f5a8:      	stur	x9, [x29, #-0x8]
    f5ac:      	cbz	x11, 0xf324 <JNI_OnUnload+0x2aa4>
    f5b0:      	add	x8, x9, x8
    f5b4:      	stur	x8, [x29, #-0x8]
    f5b8:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    f5bc:      	bti	j
    f5c0:      	mov	x8, x27
    f5c4:      	ldr	x9, [x27]
    f5c8:      	ldr	x10, [x8, #-0x8]!
    f5cc:      	cmp	x10, x9
    f5d0:      	cset	w9, hs
    f5d4:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f5d8:      	bti	j
    f5dc:      	mov	x10, xzr
    f5e0:      	mov	x9, xzr
    f5e4:      	mov	x11, x8
    f5e8:      	cmp	x11, x20
    f5ec:      	b.eq	0xfab0 <JNI_OnUnload+0x3230>
    f5f0:      	ldrb	w12, [x11], #0x1
    f5f4:      	add	x8, x8, #0x1
    f5f8:      	and	x13, x12, #0x7f
    f5fc:      	lsl	x13, x13, x10
    f600:      	add	x10, x10, #0x7
    f604:      	orr	x9, x13, x9
    f608:      	tbnz	w12, #0x7, 0xf5e8 <JNI_OnUnload+0x2d68>
    f60c:      	sub	w11, w10, #0x7
    f610:      	mov	x13, #-0x1              // =-1
    f614:      	stur	x8, [x29, #-0x8]
    f618:      	cmp	w11, #0x39
    f61c:      	mov	w11, #0x3f              // =63
    f620:      	lsl	x10, x13, x10
    f624:      	ccmp	w12, w11, #0x0, lo
    f628:      	csel	x10, x10, xzr, hi
    f62c:      	orr	x9, x9, x10
    f630:      	str	x9, [x27, #0x8]!
    f634:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    f638:      	bti	j
    f63c:      	mov	x8, x27
    f640:      	ldr	x9, [x27]
    f644:      	ldr	x10, [x8, #-0x8]!
    f648:      	and	x9, x10, x9
    f64c:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f650:      	bti	j
    f654:      	mov	x8, x27
    f658:      	ldr	x9, [x27]
    f65c:      	ldr	x10, [x8, #-0x8]!
    f660:      	cmp	x10, x9
    f664:      	cset	w9, hi
    f668:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f66c:      	bti	j
    f670:      	ldursw	x8, [x10, #0x1]
    f674:      	add	x9, x10, #0x5
    f678:      	b	0xf788 <JNI_OnUnload+0x2f08>
    f67c:      	bti	j
    f680:      	mov	x8, x27
    f684:      	ldr	x9, [x27]
    f688:      	ldr	x10, [x8, #-0x8]!
    f68c:      	eor	x9, x10, x9
    f690:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f694:      	bti	j
    f698:      	ldr	x8, [x27]
    f69c:      	tbz	x8, #0x3f, 0xf324 <JNI_OnUnload+0x2aa4>
    f6a0:      	b	0xf8c0 <JNI_OnUnload+0x3040>
    f6a4:      	bti	j
    f6a8:      	ldrsb	x8, [x10, #0x1]
    f6ac:      	b	0xf6ec <JNI_OnUnload+0x2e6c>
    f6b0:      	bti	j
    f6b4:      	ldr	x8, [x27]
    f6b8:      	b	0xf320 <JNI_OnUnload+0x2aa0>
    f6bc:      	bti	j
    f6c0:      	sub	x0, x29, #0x8
    f6c4:      	mov	x1, x20
    f6c8:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    f6cc:      	str	x0, [x27, #0x8]!
    f6d0:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    f6d4:      	bti	j
    f6d8:      	ldur	w8, [x10, #0x1]
    f6dc:      	add	x9, x10, #0x5
    f6e0:      	b	0xf788 <JNI_OnUnload+0x2f08>
    f6e4:      	bti	j
    f6e8:      	ldrb	w8, [x10, #0x1]
    f6ec:      	add	x9, x10, #0x2
    f6f0:      	b	0xf788 <JNI_OnUnload+0x2f08>
    f6f4:      	bti	j
    f6f8:      	sub	x27, x27, #0x8
    f6fc:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    f700:      	bti	j
    f704:      	ldurh	w8, [x10, #0x1]
    f708:      	add	x9, x10, #0x3
    f70c:      	b	0xf788 <JNI_OnUnload+0x2f08>
    f710:      	bti	j
    f714:      	ldr	x8, [x27]
    f718:      	ldr	x8, [x8]
    f71c:      	str	x8, [x27]
    f720:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    f724:      	bti	j
    f728:      	ldur	q0, [x27, #-0x10]
    f72c:      	ldr	x8, [x27]
    f730:      	stur	q0, [x27, #-0x8]
    f734:      	stur	x8, [x27, #-0x10]
    f738:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    f73c:      	bti	j
    f740:      	mov	x8, x27
    f744:      	ldr	x9, [x27]
    f748:      	ldr	x10, [x8, #-0x8]!
    f74c:      	sdiv	x9, x10, x9
    f750:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f754:      	bti	j
    f758:      	ldur	x8, [x27, #-0x8]
    f75c:      	b	0xf320 <JNI_OnUnload+0x2aa0>
    f760:      	bti	j
    f764:      	ldur	q0, [x27, #-0x8]
    f768:      	ext	v0.16b, v0.16b, v0.16b, #0x8
    f76c:      	stur	q0, [x27, #-0x8]
    f770:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    f774:      	bti	j
    f778:      	ldrb	w8, [x10, #0x1]
    f77c:      	add	x9, x10, #0x2
    f780:      	sub	x8, x27, x8, lsl #3
    f784:      	ldr	x8, [x8]
    f788:      	stur	x9, [x29, #-0x8]
    f78c:      	b	0xf320 <JNI_OnUnload+0x2aa0>
    f790:      	bti	j
    f794:      	ldr	x8, [x27]
    f798:      	mvn	x8, x8
    f79c:      	str	x8, [x27]
    f7a0:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    f7a4:      	bti	j
    f7a8:      	mov	x8, x27
    f7ac:      	ldr	x9, [x27]
    f7b0:      	ldr	x10, [x8, #-0x8]!
    f7b4:      	lsl	x9, x10, x9
    f7b8:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f7bc:      	bti	j
    f7c0:      	mov	x8, x27
    f7c4:      	ldr	x9, [x27]
    f7c8:      	ldr	x10, [x8, #-0x8]!
    f7cc:      	lsr	x9, x10, x9
    f7d0:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f7d4:      	bti	j
    f7d8:      	mov	x8, x27
    f7dc:      	ldr	x9, [x27]
    f7e0:      	ldr	x10, [x8, #-0x8]!
    f7e4:      	add	x9, x10, x9
    f7e8:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f7ec:      	bti	j
    f7f0:      	add	x8, x10, #0x2
    f7f4:      	stur	x8, [x29, #-0x8]
    f7f8:      	ldr	x8, [x27]
    f7fc:      	ldrb	w9, [x10, #0x1]
    f800:      	cmp	w9, #0x3
    f804:      	b.gt	0xf944 <JNI_OnUnload+0x30c4>
    f808:      	cmp	w9, #0x1
    f80c:      	b.eq	0xfa04 <JNI_OnUnload+0x3184>
    f810:      	cmp	w9, #0x2
    f814:      	b.ne	0xfbc0 <JNI_OnUnload+0x3340>
    f818:      	ldrh	w8, [x8]
    f81c:      	str	x8, [x27]
    f820:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    f824:      	bti	j
    f828:      	sub	x0, x29, #0x8
    f82c:      	mov	x1, x20
    f830:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    f834:      	ldr	x8, [x27]
    f838:      	add	x8, x8, x0
    f83c:      	str	x8, [x27]
    f840:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    f844:      	bti	j
    f848:      	mov	x8, x27
    f84c:      	ldr	x9, [x27]
    f850:      	ldr	x10, [x8, #-0x8]!
    f854:      	asr	x9, x10, x9
    f858:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f85c:      	bti	j
    f860:      	ldr	x8, [x27]
    f864:      	ldr	x8, [x8]
    f868:      	str	x8, [x27, #-0x8]!
    f86c:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    f870:      	bti	j
    f874:      	mov	x8, x27
    f878:      	ldr	x9, [x27]
    f87c:      	ldr	x10, [x8, #-0x8]!
    f880:      	mul	x9, x10, x9
    f884:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f888:      	bti	j
    f88c:      	mov	x8, x27
    f890:      	ldr	x9, [x27]
    f894:      	ldr	x10, [x8, #-0x8]!
    f898:      	sub	x9, x10, x9
    f89c:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f8a0:      	bti	j
    f8a4:      	mov	x8, x27
    f8a8:      	ldr	x9, [x27]
    f8ac:      	ldr	x10, [x8, #-0x8]!
    f8b0:      	orr	x9, x10, x9
    f8b4:      	b	0xf8e4 <JNI_OnUnload+0x3064>
    f8b8:      	bti	j
    f8bc:      	ldr	x8, [x27]
    f8c0:      	neg	x8, x8
    f8c4:      	str	x8, [x27]
    f8c8:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    f8cc:      	bti	j
    f8d0:      	mov	x8, x27
    f8d4:      	ldr	x9, [x27]
    f8d8:      	ldr	x10, [x8, #-0x8]!
    f8dc:      	cmp	x10, x9
    f8e0:      	cset	w9, ne
    f8e4:      	str	x9, [x8]
    f8e8:      	mov	x27, x8
    f8ec:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    f8f0:      	bti	j
    f8f4:      	ldursh	x8, [x10, #0x1]
    f8f8:      	add	x8, x10, x8
    f8fc:      	add	x8, x8, #0x3
    f900:      	stur	x8, [x29, #-0x8]
    f904:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    f908:      	bti	j
    f90c:      	sub	x0, x29, #0x8
    f910:      	mov	x1, x20
    f914:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
    f918:      	cmp	w0, #0x1d
    f91c:      	b.le	0xf958 <JNI_OnUnload+0x30d8>
    f920:      	cmp	w0, #0x1f
    f924:      	b.gt	0xf9a8 <JNI_OnUnload+0x3128>
    f928:      	cmp	w0, #0x1e
    f92c:      	mov	x8, x21
    f930:      	b.eq	0xf31c <JNI_OnUnload+0x2a9c>
    f934:      	cmp	w0, #0x1f
    f938:      	mov	x8, x24
    f93c:      	b.eq	0xf31c <JNI_OnUnload+0x2a9c>
    f940:      	b	0xf9c0 <JNI_OnUnload+0x3140>
    f944:      	cmp	w9, #0x4
    f948:      	b.eq	0xfa10 <JNI_OnUnload+0x3190>
    f94c:      	cmp	w9, #0x8
    f950:      	b.eq	0xf718 <JNI_OnUnload+0x2e98>
    f954:      	b	0xfbc0 <JNI_OnUnload+0x3340>
    f958:      	cmn	w0, #0x2
    f95c:      	mov	x8, x24
    f960:      	b.eq	0xf31c <JNI_OnUnload+0x2a9c>
    f964:      	cmn	w0, #0x1
    f968:      	mov	x8, x25
    f96c:      	b.eq	0xf31c <JNI_OnUnload+0x2a9c>
    f970:      	cmp	w0, #0x1d
    f974:      	mov	x8, x22
    f978:      	b.eq	0xf31c <JNI_OnUnload+0x2a9c>
    f97c:      	b	0xf9c0 <JNI_OnUnload+0x3140>
    f980:      	cmn	w0, #0x2
    f984:      	mov	x10, x24
    f988:      	b.eq	0xf9f4 <JNI_OnUnload+0x3174>
    f98c:      	cmn	w0, #0x1
    f990:      	mov	x10, x25
    f994:      	b.eq	0xf9f4 <JNI_OnUnload+0x3174>
    f998:      	cmp	w0, #0x1d
    f99c:      	mov	x10, x22
    f9a0:      	b.eq	0xf9f4 <JNI_OnUnload+0x3174>
    f9a4:      	b	0xf9e8 <JNI_OnUnload+0x3168>
    f9a8:      	cmp	w0, #0x20
    f9ac:      	mov	x8, x25
    f9b0:      	b.eq	0xf31c <JNI_OnUnload+0x2a9c>
    f9b4:      	cmp	w0, #0x22
    f9b8:      	mov	x8, x23
    f9bc:      	b.eq	0xf31c <JNI_OnUnload+0x2a9c>
    f9c0:      	cmp	w0, #0x1c
    f9c4:      	b.hi	0xfc28 <JNI_OnUnload+0x33a8>
    f9c8:      	add	x8, x19, w0, uxtw #3
    f9cc:      	b	0xf31c <JNI_OnUnload+0x2a9c>
    f9d0:      	cmp	w0, #0x20
    f9d4:      	mov	x10, x25
    f9d8:      	b.eq	0xf9f4 <JNI_OnUnload+0x3174>
    f9dc:      	cmp	w0, #0x22
    f9e0:      	mov	x10, x23
    f9e4:      	b.eq	0xf9f4 <JNI_OnUnload+0x3174>
    f9e8:      	cmp	w0, #0x1c
    f9ec:      	b.hi	0xfbf4 <JNI_OnUnload+0x3374>
    f9f0:      	add	x10, x19, w0, uxtw #3
    f9f4:      	ldr	x10, [x10]
    f9f8:      	orr	x8, x8, x9
    f9fc:      	add	x8, x10, x8
    fa00:      	b	0xf320 <JNI_OnUnload+0x2aa0>
    fa04:      	ldrb	w8, [x8]
    fa08:      	str	x8, [x27]
    fa0c:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    fa10:      	ldr	w8, [x8]
    fa14:      	str	x8, [x27]
    fa18:      	b	0xf324 <JNI_OnUnload+0x2aa4>
    fa1c:      	ldr	x21, [x27]
    fa20:      	mov	x0, x21
    fa24:      	add	sp, sp, #0x330
    fa28:      	ldp	x20, x19, [sp, #0x50]
    fa2c:      	ldp	x22, x21, [sp, #0x40]
    fa30:      	ldp	x24, x23, [sp, #0x30]
    fa34:      	ldp	x26, x25, [sp, #0x20]
    fa38:      	ldp	x28, x27, [sp, #0x10]
    fa3c:      	ldp	x29, x30, [sp], #0x60
    fa40:      	autiasp
    fa44:      	ret
    fa48:      	adrp	x19, 0x15000
    fa4c:      	nop
    fa50:      	adr	x1, 0x4677
    fa54:      	ldr	x19, [x19, #0x1e0]
    fa58:      	adrp	x2, 0x5000
    fa5c:      	add	x2, x2, #0x19c
    fa60:      	adrp	x3, 0x4000
    fa64:      	add	x3, x3, #0xc76
    fa68:      	add	x0, x19, #0x130
    fa6c:      	bl	0x10d50 <fprintf@plt>
    fa70:      	add	x0, x19, #0x130
    fa74:      	bl	0x10d60 <fflush@plt>
    fa78:      	bl	0x10d70 <abort@plt>
    fa7c:      	adrp	x19, 0x15000
    fa80:      	nop
    fa84:      	adr	x1, 0x4677
    fa88:      	ldr	x19, [x19, #0x1e0]
    fa8c:      	adrp	x2, 0x5000
    fa90:      	add	x2, x2, #0x19c
    fa94:      	adrp	x3, 0x4000
    fa98:      	add	x3, x3, #0xc76
    fa9c:      	add	x0, x19, #0x130
    faa0:      	bl	0x10d50 <fprintf@plt>
    faa4:      	add	x0, x19, #0x130
    faa8:      	bl	0x10d60 <fflush@plt>
    faac:      	bl	0x10d70 <abort@plt>
    fab0:      	adrp	x19, 0x15000
    fab4:      	nop
    fab8:      	adr	x1, 0x4677
    fabc:      	ldr	x19, [x19, #0x1e0]
    fac0:      	adrp	x2, 0x5000
    fac4:      	add	x2, x2, #0x19c
    fac8:      	adrp	x3, 0x4000
    facc:      	add	x3, x3, #0xc76
    fad0:      	add	x0, x19, #0x130
    fad4:      	bl	0x10d50 <fprintf@plt>
    fad8:      	add	x0, x19, #0x130
    fadc:      	bl	0x10d60 <fflush@plt>
    fae0:      	bl	0x10d70 <abort@plt>
    fae4:      	adrp	x19, 0x15000
    fae8:      	nop
    faec:      	adr	x1, 0x4677
    faf0:      	ldr	x19, [x19, #0x1e0]
    faf4:      	adrp	x2, 0x4000
    faf8:      	add	x2, x2, #0xf2c
    fafc:      	adrp	x3, 0x4000
    fb00:      	add	x3, x3, #0xbfc
    fb04:      	add	x0, x19, #0x130
    fb08:      	bl	0x10d50 <fprintf@plt>
    fb0c:      	add	x0, x19, #0x130
    fb10:      	bl	0x10d60 <fflush@plt>
    fb14:      	bl	0x10d70 <abort@plt>
    fb18:      	bti	j
    fb1c:      	adrp	x19, 0x15000
    fb20:      	nop
    fb24:      	adr	x1, 0x4677
    fb28:      	ldr	x19, [x19, #0x1e0]
    fb2c:      	adrp	x2, 0x4000
    fb30:      	add	x2, x2, #0xd5b
    fb34:      	adrp	x3, 0x5000
    fb38:      	add	x3, x3, #0x403
    fb3c:      	add	x0, x19, #0x130
    fb40:      	bl	0x10d50 <fprintf@plt>
    fb44:      	add	x0, x19, #0x130
    fb48:      	bl	0x10d60 <fflush@plt>
    fb4c:      	bl	0x10d70 <abort@plt>
    fb50:      	bti	j
    fb54:      	adrp	x19, 0x15000
    fb58:      	nop
    fb5c:      	adr	x1, 0x4677
    fb60:      	ldr	x19, [x19, #0x1e0]
    fb64:      	adrp	x2, 0x4000
    fb68:      	add	x2, x2, #0xd5b
    fb6c:      	adrp	x3, 0x4000
    fb70:      	add	x3, x3, #0xc93
    fb74:      	add	x0, x19, #0x130
    fb78:      	bl	0x10d50 <fprintf@plt>
    fb7c:      	add	x0, x19, #0x130
    fb80:      	bl	0x10d60 <fflush@plt>
    fb84:      	bl	0x10d70 <abort@plt>
    fb88:      	bti	j
    fb8c:      	adrp	x19, 0x15000
    fb90:      	nop
    fb94:      	adr	x1, 0x4677
    fb98:      	ldr	x19, [x19, #0x1e0]
    fb9c:      	adrp	x2, 0x4000
    fba0:      	add	x2, x2, #0xd5b
    fba4:      	adrp	x3, 0x5000
    fba8:      	add	x3, x3, #0x8fb
    fbac:      	add	x0, x19, #0x130
    fbb0:      	bl	0x10d50 <fprintf@plt>
    fbb4:      	add	x0, x19, #0x130
    fbb8:      	bl	0x10d60 <fflush@plt>
    fbbc:      	bl	0x10d70 <abort@plt>
    fbc0:      	adrp	x19, 0x15000
    fbc4:      	nop
    fbc8:      	adr	x1, 0x4677
    fbcc:      	ldr	x19, [x19, #0x1e0]
    fbd0:      	adrp	x2, 0x4000
    fbd4:      	add	x2, x2, #0xd5b
    fbd8:      	adrp	x3, 0x5000
    fbdc:      	add	x3, x3, #0x1a7
    fbe0:      	add	x0, x19, #0x130
    fbe4:      	bl	0x10d50 <fprintf@plt>
    fbe8:      	add	x0, x19, #0x130
    fbec:      	bl	0x10d60 <fflush@plt>
    fbf0:      	bl	0x10d70 <abort@plt>
    fbf4:      	adrp	x19, 0x15000
    fbf8:      	nop
    fbfc:      	adr	x1, 0x4677
    fc00:      	ldr	x19, [x19, #0x1e0]
    fc04:      	adrp	x2, 0x4000
    fc08:      	add	x2, x2, #0xf2c
    fc0c:      	adrp	x3, 0x4000
    fc10:      	add	x3, x3, #0xbfc
    fc14:      	add	x0, x19, #0x130
    fc18:      	bl	0x10d50 <fprintf@plt>
    fc1c:      	add	x0, x19, #0x130
    fc20:      	bl	0x10d60 <fflush@plt>
    fc24:      	bl	0x10d70 <abort@plt>
    fc28:      	adrp	x19, 0x15000
    fc2c:      	nop
    fc30:      	adr	x1, 0x4677
    fc34:      	ldr	x19, [x19, #0x1e0]
    fc38:      	adrp	x2, 0x4000
    fc3c:      	add	x2, x2, #0xf2c
    fc40:      	adrp	x3, 0x4000
    fc44:      	add	x3, x3, #0xbfc
    fc48:      	add	x0, x19, #0x130
    fc4c:      	bl	0x10d50 <fprintf@plt>
    fc50:      	add	x0, x19, #0x130
    fc54:      	bl	0x10d60 <fflush@plt>
    fc58:      	bl	0x10d70 <abort@plt>
    fc5c:      	paciasp
    fc60:      	stp	x29, x30, [sp, #-0x60]!
    fc64:      	stp	x28, x27, [sp, #0x10]
    fc68:      	stp	x26, x25, [sp, #0x20]
    fc6c:      	stp	x24, x23, [sp, #0x30]
    fc70:      	stp	x22, x21, [sp, #0x40]
    fc74:      	stp	x20, x19, [sp, #0x50]
    fc78:      	mov	x29, sp
    fc7c:      	sub	sp, sp, #0x6a0
    fc80:      	mov	w21, w3
    fc84:      	mov	x19, x2
    fc88:      	mov	x22, x1
    fc8c:      	mov	x20, x0
    fc90:      	cbz	w3, 0xfcb4 <JNI_OnUnload+0x3434>
    fc94:      	ldp	x2, x3, [x19, #0x10]
    fc98:      	add	x5, sp, #0x50
    fc9c:      	ldr	x0, [x20, #0x8]
    fca0:      	add	x6, sp, #0x18
    fca4:      	mov	x1, x22
    fca8:      	add	x4, x2, w21, uxtw
    fcac:      	bl	0x10184 <JNI_OnUnload+0x3904>
    fcb0:      	tbnz	w0, #0x0, 0xfdcc <JNI_OnUnload+0x354c>
    fcb4:      	ldr	x2, [x19, #0x20]
    fcb8:      	cbz	x2, 0xfcd8 <JNI_OnUnload+0x3458>
    fcbc:      	ldr	x0, [x20, #0x8]
    fcc0:      	ldr	w3, [x19, #0x28]
    fcc4:      	add	x4, sp, #0x50
    fcc8:      	add	x5, sp, #0x18
    fccc:      	mov	x1, x22
    fcd0:      	bl	0x1034c <JNI_OnUnload+0x3acc>
    fcd4:      	tbnz	w0, #0x0, 0xfdcc <JNI_OnUnload+0x354c>
    fcd8:      	ldr	x23, [x19]
    fcdc:      	nop
    fce0:      	adr	x0, 0x198b4
    fce4:      	bl	0x10db0 <pthread_rwlock_rdlock@plt>
    fce8:      	adrp	x8, 0x19000
    fcec:      	adrp	x9, 0x19000
    fcf0:      	ldr	x8, [x8, #0x660]
    fcf4:      	ldr	x9, [x9, #0x668]
    fcf8:      	cmp	x8, x9
    fcfc:      	b.hs	0xfda0 <JNI_OnUnload+0x3520>
    fd00:      	cmn	x23, #0x1
    fd04:      	b.ne	0xfd18 <JNI_OnUnload+0x3498>
    fd08:      	b	0xfd4c <JNI_OnUnload+0x34cc>
    fd0c:      	add	x8, x8, #0x20
    fd10:      	cmp	x8, x9
    fd14:      	b.hs	0xfda0 <JNI_OnUnload+0x3520>
    fd18:      	ldr	x10, [x8]
    fd1c:      	cmp	x10, x23
    fd20:      	b.ne	0xfd0c <JNI_OnUnload+0x348c>
    fd24:      	ldr	x10, [x8, #0x8]
    fd28:      	cmp	x10, x22
    fd2c:      	b.hi	0xfd0c <JNI_OnUnload+0x348c>
    fd30:      	ldr	x10, [x8, #0x10]
    fd34:      	cmp	x10, x22
    fd38:      	b.ls	0xfd0c <JNI_OnUnload+0x348c>
    fd3c:      	b	0xfd64 <JNI_OnUnload+0x34e4>
    fd40:      	add	x8, x8, #0x20
    fd44:      	cmp	x8, x9
    fd48:      	b.hs	0xfda0 <JNI_OnUnload+0x3520>
    fd4c:      	ldr	x10, [x8, #0x8]
    fd50:      	cmp	x10, x22
    fd54:      	b.hi	0xfd40 <JNI_OnUnload+0x34c0>
    fd58:      	ldr	x10, [x8, #0x10]
    fd5c:      	cmp	x10, x22
    fd60:      	b.ls	0xfd40 <JNI_OnUnload+0x34c0>
    fd64:      	ldr	x23, [x8, #0x18]
    fd68:      	nop
    fd6c:      	adr	x0, 0x198b4
    fd70:      	bl	0x10d90 <pthread_rwlock_unlock@plt>
    fd74:      	cbz	x23, 0xfdac <JNI_OnUnload+0x352c>
    fd78:      	ldp	x2, x3, [x19, #0x10]
    fd7c:      	add	x5, sp, #0x50
    fd80:      	ldr	x0, [x20, #0x8]
    fd84:      	add	x6, sp, #0x18
    fd88:      	mov	x1, x22
    fd8c:      	mov	x4, x23
    fd90:      	bl	0x10184 <JNI_OnUnload+0x3904>
    fd94:      	tbz	w0, #0x0, 0xfdac <JNI_OnUnload+0x352c>
    fd98:      	mov	w24, wzr
    fd9c:      	b	0xfdd0 <JNI_OnUnload+0x3550>
    fda0:      	nop
    fda4:      	adr	x0, 0x198b4
    fda8:      	bl	0x10d90 <pthread_rwlock_unlock@plt>
    fdac:      	ldp	x2, x3, [x19, #0x10]
    fdb0:      	add	x5, sp, #0x50
    fdb4:      	ldr	x0, [x20, #0x8]
    fdb8:      	add	x6, sp, #0x18
    fdbc:      	mov	x1, x22
    fdc0:      	mov	x4, xzr
    fdc4:      	bl	0x10184 <JNI_OnUnload+0x3904>
    fdc8:      	tbz	w0, #0x0, 0xff08 <JNI_OnUnload+0x3688>
    fdcc:      	mov	w24, #0x1               // =1
    fdd0:      	ldr	x25, [x19]
    fdd4:      	add	x0, sp, #0x80
    fdd8:      	mov	w1, wzr
    fddc:      	mov	w2, #0x618              // =1560
    fde0:      	bl	0x109a0 <memset@plt>
    fde4:      	ldr	x0, [x20, #0x8]
    fde8:      	add	x1, sp, #0x50
    fdec:      	add	x2, sp, #0x18
    fdf0:      	add	x5, sp, #0x80
    fdf4:      	mov	x3, x22
    fdf8:      	mov	w4, #0x4                // =4
    fdfc:      	bl	0xddc0 <JNI_OnUnload+0x1540>
    fe00:      	tbz	w0, #0x0, 0xff08 <JNI_OnUnload+0x3688>
    fe04:      	ldr	q0, [sp, #0x70]
    fe08:      	add	x8, x20, #0x220
    fe0c:      	ldr	x9, [sp, #0x38]
    fe10:      	ldr	x22, [sp, #0x68]
    fe14:      	cmp	w21, #0x0
    fe18:      	mov	w0, #0x1                // =1
    fe1c:      	stur	q0, [x8, #0x8]
    fe20:      	ldr	w8, [sp, #0x90]
    fe24:      	str	x9, [x20, #0x238]
    fe28:      	eor	w9, w24, #0x1
    fe2c:      	str	x8, [x20, #0x240]
    fe30:      	mov	w8, #0x3000000          // =50331648
    fe34:      	str	w8, [x20, #0x250]
    fe38:      	ldp	x23, x8, [sp, #0x50]
    fe3c:      	str	x22, [x20, #0x220]
    fe40:      	str	xzr, [x20, #0x248]
    fe44:      	str	w8, [x20, #0x254]
    fe48:      	csinc	w8, w9, wzr, eq
    fe4c:      	str	x23, [x20, #0x258]
    fe50:      	str	x25, [x20, #0x260]
    fe54:      	tbnz	w8, #0x0, 0xff0c <JNI_OnUnload+0x368c>
    fe58:      	ldr	x8, [x19, #0x20]
    fe5c:      	cbnz	x8, 0xff0c <JNI_OnUnload+0x368c>
    fe60:      	ldr	x24, [x19]
    fe64:      	nop
    fe68:      	adr	x0, 0x198b4
    fe6c:      	str	q0, [sp]
    fe70:      	bl	0x10d80 <pthread_rwlock_wrlock@plt>
    fe74:      	adrp	x25, 0x19000
    fe78:      	adrp	x26, 0x19000
    fe7c:      	ldr	x8, [x25, #0x668]
    fe80:      	ldr	x9, [x26, #0x670]
    fe84:      	cmp	x8, x9
    fe88:      	b.lo	0xfedc <JNI_OnUnload+0x365c>
    fe8c:      	adrp	x27, 0x19000
    fe90:      	ldr	x21, [x27, #0x660]
    fe94:      	sub	x19, x9, x21
    fe98:      	lsl	x0, x19, #2
    fe9c:      	asr	x28, x19, #3
    fea0:      	bl	0x10850 <malloc@plt>
    fea4:      	mov	x1, x21
    fea8:      	mov	x2, x19
    feac:      	mov	x20, x0
    feb0:      	bl	0x10890 <memcpy@plt>
    feb4:      	nop
    feb8:      	adr	x8, 0x198f0
    febc:      	cmp	x21, x8
    fec0:      	b.eq	0xfecc <JNI_OnUnload+0x364c>
    fec4:      	mov	x0, x21
    fec8:      	bl	0x10880 <free@plt>
    fecc:      	add	x9, x20, x28, lsl #5
    fed0:      	add	x8, x20, x19
    fed4:      	str	x20, [x27, #0x660]
    fed8:      	str	x9, [x26, #0x670]
    fedc:      	ldr	q0, [sp]
    fee0:      	stp	x24, x22, [x8]
    fee4:      	nop
    fee8:      	adr	x0, 0x198b4
    feec:      	str	x23, [x8, #0x18]
    fef0:      	str	d0, [x8, #0x10]
    fef4:      	add	x8, x8, #0x20
    fef8:      	str	x8, [x25, #0x668]
    fefc:      	bl	0x10d90 <pthread_rwlock_unlock@plt>
    ff00:      	mov	w0, #0x1                // =1
    ff04:      	b	0xff0c <JNI_OnUnload+0x368c>
    ff08:      	mov	w0, wzr
    ff0c:      	add	sp, sp, #0x6a0
    ff10:      	ldp	x20, x19, [sp, #0x50]
    ff14:      	ldp	x22, x21, [sp, #0x40]
    ff18:      	ldp	x24, x23, [sp, #0x30]
    ff1c:      	ldp	x26, x25, [sp, #0x20]
    ff20:      	ldp	x28, x27, [sp, #0x10]
    ff24:      	ldp	x29, x30, [sp], #0x60
    ff28:      	autiasp
    ff2c:      	ret
    ff30:      	paciasp
    ff34:      	sub	sp, sp, #0x70
    ff38:      	stp	x29, x30, [sp, #0x20]
    ff3c:      	str	x25, [sp, #0x30]
    ff40:      	stp	x24, x23, [sp, #0x40]
    ff44:      	stp	x22, x21, [sp, #0x50]
    ff48:      	stp	x20, x19, [sp, #0x60]
    ff4c:      	add	x29, sp, #0x20
    ff50:      	ldrh	w21, [x0, #0x18]
    ff54:      	cbz	x21, 0xff70 <JNI_OnUnload+0x36f0>
    ff58:      	ldr	x8, [x2, #0x10]
    ff5c:      	ldr	x22, [x0]
    ff60:      	mov	x20, x0
    ff64:      	mov	x19, x2
    ff68:      	cmp	x8, x22
    ff6c:      	b.hs	0xff94 <JNI_OnUnload+0x3714>
    ff70:      	mov	w0, wzr
    ff74:      	ldp	x20, x19, [sp, #0x60]
    ff78:      	ldr	x25, [sp, #0x30]
    ff7c:      	ldp	x22, x21, [sp, #0x50]
    ff80:      	ldp	x24, x23, [sp, #0x40]
    ff84:      	ldp	x29, x30, [sp, #0x20]
    ff88:      	add	sp, sp, #0x70
    ff8c:      	autiasp
    ff90:      	ret
    ff94:      	ldr	x11, [x20, #0x10]
    ff98:      	mov	x9, x21
    ff9c:      	mov	x10, x11
    ffa0:      	b	0xffb0 <JNI_OnUnload+0x3730>
    ffa4:      	subs	x9, x9, #0x1
    ffa8:      	mov	x11, x10
    ffac:      	b.eq	0xff70 <JNI_OnUnload+0x36f0>
    ffb0:      	ldr	w12, [x10], #0x38
    ffb4:      	cmp	w12, #0x1
    ffb8:      	b.ne	0xffa4 <JNI_OnUnload+0x3724>
    ffbc:      	ldr	x12, [x11, #0x10]
    ffc0:      	add	x12, x12, x22
    ffc4:      	cmp	x8, x12
    ffc8:      	b.lo	0xffa4 <JNI_OnUnload+0x3724>
    ffcc:      	ldr	x11, [x11, #0x28]
    ffd0:      	add	x13, x11, x12
    ffd4:      	cmp	x8, x13
    ffd8:      	b.hs	0xffa4 <JNI_OnUnload+0x3724>
    ffdc:      	ldr	x8, [x19, #0x8]
    ffe0:      	mov	w9, #-0x1               // =-1
    ffe4:      	mov	w25, #0xe550            // =58704
    ffe8:      	add	x23, x21, x9
    ffec:      	mov	w24, #0x38              // =56
    fff0:      	movk	w25, #0x6474, lsl #16
    fff4:      	stp	x12, x11, [x8]
    fff8:      	b	0x1000c <JNI_OnUnload+0x378c>
    fffc:      	sub	w21, w21, #0x1
   10000:      	sub	x23, x23, #0x1
   10004:      	and	w8, w21, #0xffff
   10008:      	cbz	w8, 0xff70 <JNI_OnUnload+0x36f0>
   1000c:      	and	x8, x23, #0xffffffff
   10010:      	ldr	x9, [x20, #0x10]
   10014:      	umull	x10, w8, w24
   10018:      	ldr	w10, [x9, x10]
   1001c:      	cmp	w10, w25
   10020:      	b.ne	0xfffc <JNI_OnUnload+0x377c>
   10024:      	umaddl	x8, w8, w24, x9
   10028:      	ldp	x0, x10, [x19]
   1002c:      	mov	x3, sp
   10030:      	ldr	x9, [x8, #0x10]
   10034:      	ldr	x8, [x8, #0x28]
   10038:      	add	x1, x9, x22
   1003c:      	add	x2, x8, x1
   10040:      	stp	x1, x8, [x10, #0x20]
   10044:      	bl	0x10064 <JNI_OnUnload+0x37e4>
   10048:      	tbz	w0, #0x0, 0xfffc <JNI_OnUnload+0x377c>
   1004c:      	ldr	x8, [sp]
   10050:      	ldr	x9, [x19, #0x8]
   10054:      	mov	x10, #-0x1              // =-1
   10058:      	mov	w0, #0x1                // =1
   1005c:      	stp	x8, x10, [x9, #0x10]
   10060:      	b	0xff74 <JNI_OnUnload+0x36f4>
   10064:      	paciasp
   10068:      	stp	x29, x30, [sp, #-0x40]!
   1006c:      	str	x23, [sp, #0x10]
   10070:      	stp	x22, x21, [sp, #0x20]
   10074:      	stp	x20, x19, [sp, #0x30]
   10078:      	mov	x29, sp
   1007c:      	mov	x20, x3
   10080:      	sub	x3, x2, x1
   10084:      	mov	x19, x1
   10088:      	cmp	x3, #0x3
   1008c:      	b.hi	0x100b8 <JNI_OnUnload+0x3838>
   10090:      	cmp	x2, x19
   10094:      	b.eq	0x10140 <JNI_OnUnload+0x38c0>
   10098:      	adrp	x20, 0x15000
   1009c:      	adrp	x1, 0x5000
   100a0:      	add	x1, x1, #0x267
   100a4:      	ldr	x20, [x20, #0x1e0]
   100a8:      	mov	x2, x19
   100ac:      	add	x0, x20, #0x130
   100b0:      	bl	0x10d50 <fprintf@plt>
   100b4:      	b	0x10138 <JNI_OnUnload+0x38b8>
   100b8:      	ldrb	w8, [x19]
   100bc:      	cmp	w8, #0x1
   100c0:      	b.ne	0x10118 <JNI_OnUnload+0x3898>
   100c4:      	add	x8, x19, #0x4
   100c8:      	ldrb	w21, [x19, #0x2]
   100cc:      	ldrb	w3, [x19, #0x1]
   100d0:      	str	x8, [x29, #0x18]
   100d4:      	add	x1, x29, #0x18
   100d8:      	mov	x4, x19
   100dc:      	ldrb	w8, [x19, #0x3]
   100e0:      	mov	x23, x0
   100e4:      	mov	x22, x2
   100e8:      	strb	w8, [x20, #0x18]
   100ec:      	bl	0xed4c <JNI_OnUnload+0x24cc>
   100f0:      	cmp	w21, #0xff
   100f4:      	str	x0, [x20]
   100f8:      	b.eq	0x1015c <JNI_OnUnload+0x38dc>
   100fc:      	add	x1, x29, #0x18
   10100:      	mov	x0, x23
   10104:      	mov	x2, x22
   10108:      	mov	w3, w21
   1010c:      	mov	x4, x19
   10110:      	bl	0xed4c <JNI_OnUnload+0x24cc>
   10114:      	b	0x10160 <JNI_OnUnload+0x38e0>
   10118:      	adrp	x20, 0x15000
   1011c:      	adrp	x1, 0x4000
   10120:      	add	x1, x1, #0xb5a
   10124:      	ldr	x20, [x20, #0x1e0]
   10128:      	mov	w2, w8
   1012c:      	mov	x3, x19
   10130:      	add	x0, x20, #0x130
   10134:      	bl	0x10d50 <fprintf@plt>
   10138:      	add	x0, x20, #0x130
   1013c:      	bl	0x10d60 <fflush@plt>
   10140:      	mov	w0, wzr
   10144:      	ldp	x20, x19, [sp, #0x30]
   10148:      	ldr	x23, [sp, #0x10]
   1014c:      	ldp	x22, x21, [sp, #0x20]
   10150:      	ldp	x29, x30, [sp], #0x40
   10154:      	autiasp
   10158:      	ret
   1015c:      	mov	x0, xzr
   10160:      	ldr	x8, [x29, #0x18]
   10164:      	stp	x0, x8, [x20, #0x8]
   10168:      	mov	w0, #0x1                // =1
   1016c:      	ldp	x20, x19, [sp, #0x30]
   10170:      	ldr	x23, [sp, #0x10]
   10174:      	ldp	x22, x21, [sp, #0x20]
   10178:      	ldp	x29, x30, [sp], #0x40
   1017c:      	autiasp
   10180:      	ret
   10184:      	paciasp
   10188:      	sub	sp, sp, #0x70
   1018c:      	stp	x29, x30, [sp, #0x10]
   10190:      	stp	x28, x27, [sp, #0x20]
   10194:      	stp	x26, x25, [sp, #0x30]
   10198:      	stp	x24, x23, [sp, #0x40]
   1019c:      	stp	x22, x21, [sp, #0x50]
   101a0:      	stp	x20, x19, [sp, #0x60]
   101a4:      	add	x29, sp, #0x10
   101a8:      	cmp	x4, #0x0
   101ac:      	add	x8, x3, x2
   101b0:      	csel	x22, x2, x4, eq
   101b4:      	cmn	x3, #0x1
   101b8:      	csinv	x27, x8, xzr, ne
   101bc:      	str	x22, [sp, #0x8]
   101c0:      	cmp	x22, x27
   101c4:      	b.hs	0x10308 <JNI_OnUnload+0x3a88>
   101c8:      	mov	x21, x6
   101cc:      	mov	x19, x5
   101d0:      	mov	x23, x2
   101d4:      	mov	x24, x1
   101d8:      	mov	x20, x0
   101dc:      	b	0x101ec <JNI_OnUnload+0x396c>
   101e0:      	cmp	x22, x27
   101e4:      	str	x22, [sp, #0x8]
   101e8:      	b.hs	0x10308 <JNI_OnUnload+0x3a88>
   101ec:      	mov	x8, x22
   101f0:      	mov	x26, x22
   101f4:      	ldr	w9, [x8], #0x4
   101f8:      	str	x8, [sp, #0x8]
   101fc:      	cmn	w9, #0x1
   10200:      	b.ne	0x10210 <JNI_OnUnload+0x3990>
   10204:      	ldur	x9, [x26, #0x4]
   10208:      	add	x8, x26, #0xc
   1020c:      	str	x8, [sp, #0x8]
   10210:      	cbz	x9, 0x10308 <JNI_OnUnload+0x3a88>
   10214:      	ldr	w10, [x8]
   10218:      	add	x22, x8, x9
   1021c:      	cbz	w10, 0x101e0 <JNI_OnUnload+0x3960>
   10220:      	sub	x1, x8, x10
   10224:      	cmp	x1, x23
   10228:      	b.lo	0x101e0 <JNI_OnUnload+0x3960>
   1022c:      	cmp	x1, x27
   10230:      	b.hs	0x101e0 <JNI_OnUnload+0x3960>
   10234:      	mov	x0, x20
   10238:      	mov	x2, x21
   1023c:      	bl	0xcef4 <JNI_OnUnload+0x674>
   10240:      	cbnz	x0, 0x101e0 <JNI_OnUnload+0x3960>
   10244:      	ldr	x8, [sp, #0x8]
   10248:      	ldrb	w3, [x21, #0x18]
   1024c:      	add	x1, sp, #0x8
   10250:      	mov	x0, x20
   10254:      	mov	x2, x22
   10258:      	mov	x4, xzr
   1025c:      	add	x8, x8, #0x4
   10260:      	str	x8, [sp, #0x8]
   10264:      	bl	0xed4c <JNI_OnUnload+0x24cc>
   10268:      	ldrb	w8, [x21, #0x18]
   1026c:      	mov	x25, x0
   10270:      	add	x1, sp, #0x8
   10274:      	mov	x0, x20
   10278:      	mov	x2, x22
   1027c:      	mov	x4, xzr
   10280:      	and	w3, w8, #0xf
   10284:      	bl	0xed4c <JNI_OnUnload+0x24cc>
   10288:      	cmp	x25, x24
   1028c:      	b.hs	0x101e0 <JNI_OnUnload+0x3960>
   10290:      	add	x28, x0, x25
   10294:      	cmp	x28, x24
   10298:      	b.lo	0x101e0 <JNI_OnUnload+0x3960>
   1029c:      	ldrb	w8, [x21, #0x31]
   102a0:      	str	xzr, [x19, #0x28]
   102a4:      	cbz	w8, 0x10330 <JNI_OnUnload+0x3ab0>
   102a8:      	add	x0, sp, #0x8
   102ac:      	mov	x1, x22
   102b0:      	bl	0xf0d8 <JNI_OnUnload+0x2858>
   102b4:      	ldrb	w8, [x21, #0x19]
   102b8:      	ldr	x24, [sp, #0x8]
   102bc:      	cmp	w8, #0xff
   102c0:      	add	x23, x24, x0
   102c4:      	b.eq	0x10334 <JNI_OnUnload+0x3ab4>
   102c8:      	add	x1, sp, #0x8
   102cc:      	and	w3, w8, #0xf
   102d0:      	mov	x0, x20
   102d4:      	mov	x2, x22
   102d8:      	mov	x4, xzr
   102dc:      	bl	0xed4c <JNI_OnUnload+0x24cc>
   102e0:      	cbz	x0, 0x10334 <JNI_OnUnload+0x3ab4>
   102e4:      	ldrb	w3, [x21, #0x19]
   102e8:      	add	x1, sp, #0x8
   102ec:      	mov	x0, x20
   102f0:      	mov	x2, x22
   102f4:      	mov	x4, xzr
   102f8:      	str	x24, [sp, #0x8]
   102fc:      	bl	0xed4c <JNI_OnUnload+0x24cc>
   10300:      	str	x0, [x19, #0x28]
   10304:      	b	0x10334 <JNI_OnUnload+0x3ab4>
   10308:      	mov	w0, wzr
   1030c:      	ldp	x20, x19, [sp, #0x60]
   10310:      	ldp	x22, x21, [sp, #0x50]
   10314:      	ldp	x24, x23, [sp, #0x40]
   10318:      	ldp	x26, x25, [sp, #0x30]
   1031c:      	ldp	x28, x27, [sp, #0x20]
   10320:      	ldp	x29, x30, [sp, #0x10]
   10324:      	add	sp, sp, #0x70
   10328:      	autiasp
   1032c:      	ret
   10330:      	ldr	x23, [sp, #0x8]
   10334:      	sub	x8, x22, x26
   10338:      	stp	x23, x25, [x19, #0x10]
   1033c:      	mov	w0, #0x1                // =1
   10340:      	stp	x26, x8, [x19]
   10344:      	str	x28, [x19, #0x20]
   10348:      	b	0x1030c <JNI_OnUnload+0x3a8c>
   1034c:      	paciasp
   10350:      	sub	sp, sp, #0xa0
   10354:      	stp	x29, x30, [sp, #0x40]
   10358:      	stp	x28, x27, [sp, #0x50]
   1035c:      	stp	x26, x25, [sp, #0x60]
   10360:      	stp	x24, x23, [sp, #0x70]
   10364:      	stp	x22, x21, [sp, #0x80]
   10368:      	stp	x20, x19, [sp, #0x90]
   1036c:      	add	x29, sp, #0x40
   10370:      	add	x24, x2, w3, uxtw
   10374:      	mov	x23, x2
   10378:      	mov	x20, x1
   1037c:      	add	x3, sp, #0x20
   10380:      	mov	x1, x2
   10384:      	mov	x21, x5
   10388:      	mov	x2, x24
   1038c:      	mov	x19, x4
   10390:      	mov	x22, x0
   10394:      	bl	0x10064 <JNI_OnUnload+0x37e4>
   10398:      	tbz	w0, #0x0, 0x1048c <JNI_OnUnload+0x3c0c>
   1039c:      	ldr	x8, [sp, #0x28]
   103a0:      	cbz	x8, 0x1048c <JNI_OnUnload+0x3c0c>
   103a4:      	ldrb	w0, [sp, #0x38]
   103a8:      	stp	x21, x19, [sp, #0x8]
   103ac:      	bl	0x104b4 <JNI_OnUnload+0x3c34>
   103b0:      	ldr	x27, [sp, #0x28]
   103b4:      	mov	x25, x0
   103b8:      	mov	x26, xzr
   103bc:      	cmp	x27, #0x1
   103c0:      	b.ls	0x1040c <JNI_OnUnload+0x3b8c>
   103c4:      	lsr	x21, x27, #1
   103c8:      	ldr	x8, [sp, #0x30]
   103cc:      	ldrb	w3, [sp, #0x38]
   103d0:      	add	x1, sp, #0x18
   103d4:      	mov	x0, x22
   103d8:      	mov	x2, x24
   103dc:      	add	x19, x21, x26
   103e0:      	mov	x4, x23
   103e4:      	mul	x28, x19, x25
   103e8:      	add	x8, x8, x28
   103ec:      	str	x8, [sp, #0x18]
   103f0:      	bl	0xed4c <JNI_OnUnload+0x24cc>
   103f4:      	sub	x8, x27, x21
   103f8:      	cmp	x0, x20
   103fc:      	csel	x26, x26, x19, hs
   10400:      	csel	x27, x21, x8, hs
   10404:      	b.ne	0x103bc <JNI_OnUnload+0x3b3c>
   10408:      	b	0x10410 <JNI_OnUnload+0x3b90>
   1040c:      	mul	x28, x26, x25
   10410:      	ldr	x8, [sp, #0x30]
   10414:      	ldrb	w25, [sp, #0x38]
   10418:      	add	x1, sp, #0x18
   1041c:      	mov	x0, x22
   10420:      	mov	x2, x24
   10424:      	mov	x4, x23
   10428:      	add	x8, x8, x28
   1042c:      	mov	w3, w25
   10430:      	str	x8, [sp, #0x18]
   10434:      	bl	0xed4c <JNI_OnUnload+0x24cc>
   10438:      	add	x1, sp, #0x18
   1043c:      	mov	x0, x22
   10440:      	mov	x2, x24
   10444:      	mov	w3, w25
   10448:      	mov	x4, x23
   1044c:      	bl	0xed4c <JNI_OnUnload+0x24cc>
   10450:      	ldp	x3, x19, [sp, #0x8]
   10454:      	mov	x1, x0
   10458:      	mov	x0, x22
   1045c:      	mov	w4, wzr
   10460:      	mov	x2, x19
   10464:      	bl	0xcd64 <JNI_OnUnload+0x4e4>
   10468:      	cbnz	x0, 0x1048c <JNI_OnUnload+0x3c0c>
   1046c:      	ldr	x8, [x19, #0x18]
   10470:      	cmp	x8, x20
   10474:      	b.hi	0x1048c <JNI_OnUnload+0x3c0c>
   10478:      	ldr	x8, [x19, #0x20]
   1047c:      	cmp	x8, x20
   10480:      	b.ls	0x1048c <JNI_OnUnload+0x3c0c>
   10484:      	mov	w0, #0x1                // =1
   10488:      	b	0x10490 <JNI_OnUnload+0x3c10>
   1048c:      	mov	w0, wzr
   10490:      	ldp	x20, x19, [sp, #0x90]
   10494:      	ldp	x22, x21, [sp, #0x80]
   10498:      	ldp	x24, x23, [sp, #0x70]
   1049c:      	ldp	x26, x25, [sp, #0x60]
   104a0:      	ldp	x28, x27, [sp, #0x50]
   104a4:      	ldp	x29, x30, [sp, #0x40]
   104a8:      	add	sp, sp, #0xa0
   104ac:      	autiasp
   104b0:      	ret
   104b4:      	paciasp
   104b8:      	stp	x29, x30, [sp, #-0x20]!
   104bc:      	str	x19, [sp, #0x10]
   104c0:      	mov	x29, sp
   104c4:      	and	w8, w0, #0xf
   104c8:      	mov	w0, #0x4                // =4
   104cc:      	cmp	w8, #0x8
   104d0:      	b.gt	0x104f0 <JNI_OnUnload+0x3c70>
   104d4:      	cmp	w8, #0x2
   104d8:      	b.le	0x10530 <JNI_OnUnload+0x3cb0>
   104dc:      	cmp	w8, #0x3
   104e0:      	b.eq	0x10508 <JNI_OnUnload+0x3c88>
   104e4:      	cmp	w8, #0x4
   104e8:      	b.eq	0x1051c <JNI_OnUnload+0x3c9c>
   104ec:      	b	0x1053c <JNI_OnUnload+0x3cbc>
   104f0:      	cmp	w8, #0xa
   104f4:      	b.le	0x10570 <JNI_OnUnload+0x3cf0>
   104f8:      	cmp	w8, #0xc
   104fc:      	b.eq	0x1051c <JNI_OnUnload+0x3c9c>
   10500:      	cmp	w8, #0xb
   10504:      	b.ne	0x1053c <JNI_OnUnload+0x3cbc>
   10508:      	mov	w0, #0x8                // =8
   1050c:      	ldr	x19, [sp, #0x10]
   10510:      	ldp	x29, x30, [sp], #0x20
   10514:      	autiasp
   10518:      	ret
   1051c:      	mov	w0, #0x10               // =16
   10520:      	ldr	x19, [sp, #0x10]
   10524:      	ldp	x29, x30, [sp], #0x20
   10528:      	autiasp
   1052c:      	ret
   10530:      	b.eq	0x1050c <JNI_OnUnload+0x3c8c>
   10534:      	cmp	w8, #0x1
   10538:      	b.eq	0x1057c <JNI_OnUnload+0x3cfc>
   1053c:      	adrp	x19, 0x15000
   10540:      	nop
   10544:      	adr	x1, 0x4677
   10548:      	ldr	x19, [x19, #0x1e0]
   1054c:      	adrp	x2, 0x4000
   10550:      	add	x2, x2, #0xc41
   10554:      	adrp	x3, 0x5000
   10558:      	add	x3, x3, #0x5db
   1055c:      	add	x0, x19, #0x130
   10560:      	bl	0x10d50 <fprintf@plt>
   10564:      	add	x0, x19, #0x130
   10568:      	bl	0x10d60 <fflush@plt>
   1056c:      	bl	0x10d70 <abort@plt>
   10570:      	b.eq	0x1050c <JNI_OnUnload+0x3c8c>
   10574:      	cmp	w8, #0x9
   10578:      	b.ne	0x1053c <JNI_OnUnload+0x3cbc>
   1057c:      	adrp	x19, 0x15000
   10580:      	nop
   10584:      	adr	x1, 0x4677
   10588:      	ldr	x19, [x19, #0x1e0]
   1058c:      	adrp	x2, 0x4000
   10590:      	add	x2, x2, #0xc41
   10594:      	adrp	x3, 0x4000
   10598:      	add	x3, x3, #0x988
   1059c:      	add	x0, x19, #0x130
   105a0:      	bl	0x10d50 <fprintf@plt>
   105a4:      	add	x0, x19, #0x130
   105a8:      	bl	0x10d60 <fflush@plt>
   105ac:      	bl	0x10d70 <abort@plt>
   105b0:      	bti	c
   105b4:      	add	w8, w0, #0x2
   105b8:      	cmp	w8, #0x61
   105bc:      	b.hi	0x105d4 <JNI_OnUnload+0x3d54>
   105c0:      	nop
   105c4:      	adr	x9, 0x5b9c <_ZTSSt9bad_alloc+0x193>
   105c8:      	ldrsw	x8, [x9, w8, uxtw #2]
   105cc:      	add	x0, x9, x8
   105d0:      	ret
   105d4:      	adrp	x0, 0x5000
   105d8:      	add	x0, x0, #0x54c
   105dc:      	ret
   105e0:      	bti	c
   105e4:      	ldp	x2, x3, [x0, #0x10]
   105e8:      	ldp	x4, x5, [x0, #0x20]
   105ec:      	ldp	x6, x7, [x0, #0x30]
   105f0:      	ldp	x8, x9, [x0, #0x40]
   105f4:      	ldp	x10, x11, [x0, #0x50]
   105f8:      	ldp	x12, x13, [x0, #0x60]
   105fc:      	ldp	x14, x15, [x0, #0x70]
   10600:      	ldp	x18, x19, [x0, #0x90]
   10604:      	ldp	x20, x21, [x0, #0xa0]
   10608:      	ldp	x22, x23, [x0, #0xb0]
   1060c:      	ldp	x24, x25, [x0, #0xc0]
   10610:      	ldp	x26, x27, [x0, #0xd0]
   10614:      	ldp	x28, x29, [x0, #0xe0]
   10618:      	ldr	x30, [x0, #0x100]
   1061c:      	ldp	d0, d1, [x0, #0x110]
   10620:      	ldp	d2, d3, [x0, #0x120]
   10624:      	ldp	d4, d5, [x0, #0x130]
   10628:      	ldp	d6, d7, [x0, #0x140]
   1062c:      	ldp	d8, d9, [x0, #0x150]
   10630:      	ldp	d10, d11, [x0, #0x160]
   10634:      	ldp	d12, d13, [x0, #0x170]
   10638:      	ldp	d14, d15, [x0, #0x180]
   1063c:      	ldp	d16, d17, [x0, #0x190]
   10640:      	ldp	d18, d19, [x0, #0x1a0]
   10644:      	ldp	d20, d21, [x0, #0x1b0]
   10648:      	ldp	d22, d23, [x0, #0x1c0]
   1064c:      	ldp	d24, d25, [x0, #0x1d0]
   10650:      	ldp	d26, d27, [x0, #0x1e0]
   10654:      	ldp	d28, d29, [x0, #0x1f0]
   10658:      	ldr	d30, [x0, #0x200]
   1065c:      	ldr	d31, [x0, #0x208]
   10660:      	ldr	x16, [x0, #0xf8]
   10664:      	ldp	x0, x1, [x0]
   10668:      	mov	sp, x16
   1066c:      	ret
   10670:      	bti	c
   10674:      	stp	x0, x1, [x0]
   10678:      	stp	x2, x3, [x0, #0x10]
   1067c:      	stp	x4, x5, [x0, #0x20]
   10680:      	stp	x6, x7, [x0, #0x30]
   10684:      	stp	x8, x9, [x0, #0x40]
   10688:      	stp	x10, x11, [x0, #0x50]
   1068c:      	stp	x12, x13, [x0, #0x60]
   10690:      	stp	x14, x15, [x0, #0x70]
   10694:      	stp	x16, x17, [x0, #0x80]
   10698:      	stp	x18, x19, [x0, #0x90]
   1069c:      	stp	x20, x21, [x0, #0xa0]
   106a0:      	stp	x22, x23, [x0, #0xb0]
   106a4:      	stp	x24, x25, [x0, #0xc0]
   106a8:      	stp	x26, x27, [x0, #0xd0]
   106ac:      	stp	x28, x29, [x0, #0xe0]
   106b0:      	str	x30, [x0, #0xf0]
   106b4:      	mov	x1, sp
   106b8:      	str	x1, [x0, #0xf8]
   106bc:      	str	x30, [x0, #0x100]
   106c0:      	stp	d0, d1, [x0, #0x110]
   106c4:      	stp	d2, d3, [x0, #0x120]
   106c8:      	stp	d4, d5, [x0, #0x130]
   106cc:      	stp	d6, d7, [x0, #0x140]
   106d0:      	stp	d8, d9, [x0, #0x150]
   106d4:      	stp	d10, d11, [x0, #0x160]
   106d8:      	stp	d12, d13, [x0, #0x170]
   106dc:      	stp	d14, d15, [x0, #0x180]
   106e0:      	stp	d16, d17, [x0, #0x190]
   106e4:      	stp	d18, d19, [x0, #0x1a0]
   106e8:      	stp	d20, d21, [x0, #0x1b0]
   106ec:      	stp	d22, d23, [x0, #0x1c0]
   106f0:      	stp	d24, d25, [x0, #0x1d0]
   106f4:      	stp	d26, d27, [x0, #0x1e0]
   106f8:      	stp	d28, d29, [x0, #0x1f0]
   106fc:      	str	d30, [x0, #0x200]
   10700:      	str	d31, [x0, #0x208]
   10704:      	mov	x0, #0x0                // =0
   10708:      	ret

Disassembly of section .plt:

0000000000010710 <.plt>:
   10710:      	stp	x16, x30, [sp, #-0x10]!
   10714:      	adrp	x16, 0x15000
   10718:      	ldr	x17, [x16, #0x1f8]
   1071c:      	add	x16, x16, #0x1f8
   10720:      	br	x17
   10724:      	nop
   10728:      	nop
   1072c:      	nop

0000000000010730 <__cxa_finalize@plt>:
   10730:      	adrp	x16, 0x15000
   10734:      	ldr	x17, [x16, #0x200]
   10738:      	add	x16, x16, #0x200
   1073c:      	br	x17

0000000000010740 <__cxa_atexit@plt>:
   10740:      	adrp	x16, 0x15000
   10744:      	ldr	x17, [x16, #0x208]
   10748:      	add	x16, x16, #0x208
   1074c:      	br	x17

0000000000010750 <__register_atfork@plt>:
   10750:      	adrp	x16, 0x15000
   10754:      	ldr	x17, [x16, #0x210]
   10758:      	add	x16, x16, #0x210
   1075c:      	br	x17

0000000000010760 <strlen@plt>:
   10760:      	adrp	x16, 0x15000
   10764:      	ldr	x17, [x16, #0x218]
   10768:      	add	x16, x16, #0x218
   1076c:      	br	x17

0000000000010770 <_Znwm@plt>:
   10770:      	adrp	x16, 0x15000
   10774:      	ldr	x17, [x16, #0x220]
   10778:      	add	x16, x16, #0x220
   1077c:      	br	x17

0000000000010780 <memmove@plt>:
   10780:      	adrp	x16, 0x15000
   10784:      	ldr	x17, [x16, #0x228]
   10788:      	add	x16, x16, #0x228
   1078c:      	br	x17

0000000000010790 <_ZdlPv@plt>:
   10790:      	adrp	x16, 0x15000
   10794:      	ldr	x17, [x16, #0x230]
   10798:      	add	x16, x16, #0x230
   1079c:      	br	x17

00000000000107a0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_@plt>:
   107a0:      	adrp	x16, 0x15000
   107a4:      	ldr	x17, [x16, #0x238]
   107a8:      	add	x16, x16, #0x238
   107ac:      	br	x17

00000000000107b0 <__cxa_allocate_exception@plt>:
   107b0:      	adrp	x16, 0x15000
   107b4:      	ldr	x17, [x16, #0x240]
   107b8:      	add	x16, x16, #0x240
   107bc:      	br	x17

00000000000107c0 <__cxa_throw@plt>:
   107c0:      	adrp	x16, 0x15000
   107c4:      	ldr	x17, [x16, #0x248]
   107c8:      	add	x16, x16, #0x248
   107cc:      	br	x17

00000000000107d0 <__cxa_free_exception@plt>:
   107d0:      	adrp	x16, 0x15000
   107d4:      	ldr	x17, [x16, #0x250]
   107d8:      	add	x16, x16, #0x250
   107dc:      	br	x17

00000000000107e0 <_ZNSt11logic_errorC2EPKc@plt>:
   107e0:      	adrp	x16, 0x15000
   107e4:      	ldr	x17, [x16, #0x258]
   107e8:      	add	x16, x16, #0x258
   107ec:      	br	x17

00000000000107f0 <_ZN13MTLReportTool9Interface4ImplC1Ev@plt>:
   107f0:      	adrp	x16, 0x15000
   107f4:      	ldr	x17, [x16, #0x260]
   107f8:      	add	x16, x16, #0x260
   107fc:      	br	x17

0000000000010800 <_ZN13MTLReportTool9Interface4ImplD1Ev@plt>:
   10800:      	adrp	x16, 0x15000
   10804:      	ldr	x17, [x16, #0x268]
   10808:      	add	x16, x16, #0x268
   1080c:      	br	x17

0000000000010810 <_ZN13MTLReportTool9Interface7versionEv@plt>:
   10810:      	adrp	x16, 0x15000
   10814:      	ldr	x17, [x16, #0x270]
   10818:      	add	x16, x16, #0x270
   1081c:      	br	x17

0000000000010820 <_ZN13MTLReportTool9InterfaceC1Ev@plt>:
   10820:      	adrp	x16, 0x15000
   10824:      	ldr	x17, [x16, #0x278]
   10828:      	add	x16, x16, #0x278
   1082c:      	br	x17

0000000000010830 <_ZN13MTLReportTool9InterfaceD1Ev@plt>:
   10830:      	adrp	x16, 0x15000
   10834:      	ldr	x17, [x16, #0x280]
   10838:      	add	x16, x16, #0x280
   1083c:      	br	x17

0000000000010840 <__stack_chk_fail@plt>:
   10840:      	adrp	x16, 0x15000
   10844:      	ldr	x17, [x16, #0x288]
   10848:      	add	x16, x16, #0x288
   1084c:      	br	x17

0000000000010850 <malloc@plt>:
   10850:      	adrp	x16, 0x15000
   10854:      	ldr	x17, [x16, #0x290]
   10858:      	add	x16, x16, #0x290
   1085c:      	br	x17

0000000000010860 <__cxa_begin_catch@plt>:
   10860:      	adrp	x16, 0x15000
   10864:      	ldr	x17, [x16, #0x298]
   10868:      	add	x16, x16, #0x298
   1086c:      	br	x17

0000000000010870 <_ZSt9terminatev@plt>:
   10870:      	adrp	x16, 0x15000
   10874:      	ldr	x17, [x16, #0x2a0]
   10878:      	add	x16, x16, #0x2a0
   1087c:      	br	x17

0000000000010880 <free@plt>:
   10880:      	adrp	x16, 0x15000
   10884:      	ldr	x17, [x16, #0x2a8]
   10888:      	add	x16, x16, #0x2a8
   1088c:      	br	x17

0000000000010890 <memcpy@plt>:
   10890:      	adrp	x16, 0x15000
   10894:      	ldr	x17, [x16, #0x2b0]
   10898:      	add	x16, x16, #0x2b0
   1089c:      	br	x17

00000000000108a0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEC2ERKS5_mmRKS4_@plt>:
   108a0:      	adrp	x16, 0x15000
   108a4:      	ldr	x17, [x16, #0x2b8]
   108a8:      	add	x16, x16, #0x2b8
   108ac:      	br	x17

00000000000108b0 <_ZNKSt6__ndk115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strEv@plt>:
   108b0:      	adrp	x16, 0x15000
   108b4:      	ldr	x17, [x16, #0x2c0]
   108b8:      	add	x16, x16, #0x2c0
   108bc:      	br	x17

00000000000108c0 <_ZNSt6__ndk115basic_streambufIcNS_11char_traitsIcEEED2Ev@plt>:
   108c0:      	adrp	x16, 0x15000
   108c4:      	ldr	x17, [x16, #0x2c8]
   108c8:      	add	x16, x16, #0x2c8
   108cc:      	br	x17

00000000000108d0 <_ZNSt6__ndk114basic_iostreamIcNS_11char_traitsIcEEED2Ev@plt>:
   108d0:      	adrp	x16, 0x15000
   108d4:      	ldr	x17, [x16, #0x2d0]
   108d8:      	add	x16, x16, #0x2d0
   108dc:      	br	x17

00000000000108e0 <_ZNSt6__ndk19basic_iosIcNS_11char_traitsIcEEED2Ev@plt>:
   108e0:      	adrp	x16, 0x15000
   108e4:      	ldr	x17, [x16, #0x2d8]
   108e8:      	add	x16, x16, #0x2d8
   108ec:      	br	x17

00000000000108f0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>:
   108f0:      	adrp	x16, 0x15000
   108f4:      	ldr	x17, [x16, #0x2e0]
   108f8:      	add	x16, x16, #0x2e0
   108fc:      	br	x17

0000000000010900 <_ZNSt6__ndk18ios_base4initEPv@plt>:
   10900:      	adrp	x16, 0x15000
   10904:      	ldr	x17, [x16, #0x2e8]
   10908:      	add	x16, x16, #0x2e8
   1090c:      	br	x17

0000000000010910 <_ZNSt6__ndk115basic_streambufIcNS_11char_traitsIcEEEC2Ev@plt>:
   10910:      	adrp	x16, 0x15000
   10914:      	ldr	x17, [x16, #0x2f0]
   10918:      	add	x16, x16, #0x2f0
   1091c:      	br	x17

0000000000010920 <_ZNKSt6__ndk18ios_base6getlocEv@plt>:
   10920:      	adrp	x16, 0x15000
   10924:      	ldr	x17, [x16, #0x2f8]
   10928:      	add	x16, x16, #0x2f8
   1092c:      	br	x17

0000000000010930 <_ZNKSt6__ndk16locale9use_facetERNS0_2idE@plt>:
   10930:      	adrp	x16, 0x15000
   10934:      	ldr	x17, [x16, #0x300]
   10938:      	add	x16, x16, #0x300
   1093c:      	br	x17

0000000000010940 <_ZNSt6__ndk16localeD1Ev@plt>:
   10940:      	adrp	x16, 0x15000
   10944:      	ldr	x17, [x16, #0x308]
   10948:      	add	x16, x16, #0x308
   1094c:      	br	x17

0000000000010950 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEE6sentryC1ERS3_@plt>:
   10950:      	adrp	x16, 0x15000
   10954:      	ldr	x17, [x16, #0x310]
   10958:      	add	x16, x16, #0x310
   1095c:      	br	x17

0000000000010960 <_ZNSt6__ndk18ios_base5clearEj@plt>:
   10960:      	adrp	x16, 0x15000
   10964:      	ldr	x17, [x16, #0x318]
   10968:      	add	x16, x16, #0x318
   1096c:      	br	x17

0000000000010970 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEE6sentryD1Ev@plt>:
   10970:      	adrp	x16, 0x15000
   10974:      	ldr	x17, [x16, #0x320]
   10978:      	add	x16, x16, #0x320
   1097c:      	br	x17

0000000000010980 <_ZNSt6__ndk18ios_base33__set_badbit_and_consider_rethrowEv@plt>:
   10980:      	adrp	x16, 0x15000
   10984:      	ldr	x17, [x16, #0x328]
   10988:      	add	x16, x16, #0x328
   1098c:      	br	x17

0000000000010990 <__cxa_end_catch@plt>:
   10990:      	adrp	x16, 0x15000
   10994:      	ldr	x17, [x16, #0x330]
   10998:      	add	x16, x16, #0x330
   1099c:      	br	x17

00000000000109a0 <memset@plt>:
   109a0:      	adrp	x16, 0x15000
   109a4:      	ldr	x17, [x16, #0x338]
   109a8:      	add	x16, x16, #0x338
   109ac:      	br	x17

00000000000109b0 <fclose@plt>:
   109b0:      	adrp	x16, 0x15000
   109b4:      	ldr	x17, [x16, #0x340]
   109b8:      	add	x16, x16, #0x340
   109bc:      	br	x17

00000000000109c0 <_Znam@plt>:
   109c0:      	adrp	x16, 0x15000
   109c4:      	ldr	x17, [x16, #0x348]
   109c8:      	add	x16, x16, #0x348
   109cc:      	br	x17

00000000000109d0 <fread@plt>:
   109d0:      	adrp	x16, 0x15000
   109d4:      	ldr	x17, [x16, #0x350]
   109d8:      	add	x16, x16, #0x350
   109dc:      	br	x17

00000000000109e0 <_ZdaPv@plt>:
   109e0:      	adrp	x16, 0x15000
   109e4:      	ldr	x17, [x16, #0x358]
   109e8:      	add	x16, x16, #0x358
   109ec:      	br	x17

00000000000109f0 <fseek@plt>:
   109f0:      	adrp	x16, 0x15000
   109f4:      	ldr	x17, [x16, #0x360]
   109f8:      	add	x16, x16, #0x360
   109fc:      	br	x17

0000000000010a00 <ftell@plt>:
   10a00:      	adrp	x16, 0x15000
   10a04:      	ldr	x17, [x16, #0x368]
   10a08:      	add	x16, x16, #0x368
   10a0c:      	br	x17

0000000000010a10 <fopen@plt>:
   10a10:      	adrp	x16, 0x15000
   10a14:      	ldr	x17, [x16, #0x370]
   10a18:      	add	x16, x16, #0x370
   10a1c:      	br	x17

0000000000010a20 <fwrite@plt>:
   10a20:      	adrp	x16, 0x15000
   10a24:      	ldr	x17, [x16, #0x378]
   10a28:      	add	x16, x16, #0x378
   10a2c:      	br	x17

0000000000010a30 <_ZNKSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE5rfindEcm@plt>:
   10a30:      	adrp	x16, 0x15000
   10a34:      	ldr	x17, [x16, #0x380]
   10a38:      	add	x16, x16, #0x380
   10a3c:      	br	x17

0000000000010a40 <access@plt>:
   10a40:      	adrp	x16, 0x15000
   10a44:      	ldr	x17, [x16, #0x388]
   10a48:      	add	x16, x16, #0x388
   10a4c:      	br	x17

0000000000010a50 <mkdir@plt>:
   10a50:      	adrp	x16, 0x15000
   10a54:      	ldr	x17, [x16, #0x390]
   10a58:      	add	x16, x16, #0x390
   10a5c:      	br	x17

0000000000010a60 <_ZNSt20bad_array_new_lengthC1Ev@plt>:
   10a60:      	adrp	x16, 0x15000
   10a64:      	ldr	x17, [x16, #0x398]
   10a68:      	add	x16, x16, #0x398
   10a6c:      	br	x17

0000000000010a70 <vsnprintf@plt>:
   10a70:      	adrp	x16, 0x15000
   10a74:      	ldr	x17, [x16, #0x3a0]
   10a78:      	add	x16, x16, #0x3a0
   10a7c:      	br	x17

0000000000010a80 <__vsnprintf_chk@plt>:
   10a80:      	adrp	x16, 0x15000
   10a84:      	ldr	x17, [x16, #0x3a8]
   10a88:      	add	x16, x16, #0x3a8
   10a8c:      	br	x17

0000000000010a90 <_ZNSt6__ndk16chrono12steady_clock3nowEv@plt>:
   10a90:      	adrp	x16, 0x15000
   10a94:      	ldr	x17, [x16, #0x3b0]
   10a98:      	add	x16, x16, #0x3b0
   10a9c:      	br	x17

0000000000010aa0 <_ZN5utils8TimeCostC1Ev@plt>:
   10aa0:      	adrp	x16, 0x15000
   10aa4:      	ldr	x17, [x16, #0x3b8]
   10aa8:      	add	x16, x16, #0x3b8
   10aac:      	br	x17

0000000000010ab0 <_ZN5utils8TimeCostD1Ev@plt>:
   10ab0:      	adrp	x16, 0x15000
   10ab4:      	ldr	x17, [x16, #0x3c0]
   10ab8:      	add	x16, x16, #0x3c0
   10abc:      	br	x17

0000000000010ac0 <_ZNK5utils11LogTimeCost3logEPKcz@plt>:
   10ac0:      	adrp	x16, 0x15000
   10ac4:      	ldr	x17, [x16, #0x3c8]
   10ac8:      	add	x16, x16, #0x3c8
   10acc:      	br	x17

0000000000010ad0 <_ZN13VLLogMediator11getInstanceEv@plt>:
   10ad0:      	adrp	x16, 0x15000
   10ad4:      	ldr	x17, [x16, #0x3d0]
   10ad8:      	add	x16, x16, #0x3d0
   10adc:      	br	x17

0000000000010ae0 <__cxa_guard_acquire@plt>:
   10ae0:      	adrp	x16, 0x15000
   10ae4:      	ldr	x17, [x16, #0x3d8]
   10ae8:      	add	x16, x16, #0x3d8
   10aec:      	br	x17

0000000000010af0 <__cxa_guard_release@plt>:
   10af0:      	adrp	x16, 0x15000
   10af4:      	ldr	x17, [x16, #0x3e0]
   10af8:      	add	x16, x16, #0x3e0
   10afc:      	br	x17

0000000000010b00 <_ZN13VLLogMediator3endEv@plt>:
   10b00:      	adrp	x16, 0x15000
   10b04:      	ldr	x17, [x16, #0x3e8]
   10b08:      	add	x16, x16, #0x3e8
   10b0c:      	br	x17

0000000000010b10 <_ZNSt6__ndk118condition_variableD1Ev@plt>:
   10b10:      	adrp	x16, 0x15000
   10b14:      	ldr	x17, [x16, #0x3f0]
   10b18:      	add	x16, x16, #0x3f0
   10b1c:      	br	x17

0000000000010b20 <_ZNSt6__ndk15mutexD1Ev@plt>:
   10b20:      	adrp	x16, 0x15000
   10b24:      	ldr	x17, [x16, #0x3f8]
   10b28:      	add	x16, x16, #0x3f8
   10b2c:      	br	x17

0000000000010b30 <_ZNSt6__ndk16threadD1Ev@plt>:
   10b30:      	adrp	x16, 0x15000
   10b34:      	ldr	x17, [x16, #0x400]
   10b38:      	add	x16, x16, #0x400
   10b3c:      	br	x17

0000000000010b40 <_ZNSt6__ndk15mutex4lockEv@plt>:
   10b40:      	adrp	x16, 0x15000
   10b44:      	ldr	x17, [x16, #0x408]
   10b48:      	add	x16, x16, #0x408
   10b4c:      	br	x17

0000000000010b50 <_ZNSt6__ndk15mutex6unlockEv@plt>:
   10b50:      	adrp	x16, 0x15000
   10b54:      	ldr	x17, [x16, #0x410]
   10b58:      	add	x16, x16, #0x410
   10b5c:      	br	x17

0000000000010b60 <_ZNSt6__ndk118condition_variable10notify_oneEv@plt>:
   10b60:      	adrp	x16, 0x15000
   10b64:      	ldr	x17, [x16, #0x418]
   10b68:      	add	x16, x16, #0x418
   10b6c:      	br	x17

0000000000010b70 <_ZNSt6__ndk16thread4joinEv@plt>:
   10b70:      	adrp	x16, 0x15000
   10b74:      	ldr	x17, [x16, #0x420]
   10b78:      	add	x16, x16, #0x420
   10b7c:      	br	x17

0000000000010b80 <_Z15vlcollect_resetv@plt>:
   10b80:      	adrp	x16, 0x15000
   10b84:      	ldr	x17, [x16, #0x428]
   10b88:      	add	x16, x16, #0x428
   10b8c:      	br	x17

0000000000010b90 <_ZN13VLLogMediator4initERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE@plt>:
   10b90:      	adrp	x16, 0x15000
   10b94:      	ldr	x17, [x16, #0x430]
   10b98:      	add	x16, x16, #0x430
   10b9c:      	br	x17

0000000000010ba0 <_Z14vlcollect_initPKc@plt>:
   10ba0:      	adrp	x16, 0x15000
   10ba4:      	ldr	x17, [x16, #0x438]
   10ba8:      	add	x16, x16, #0x438
   10bac:      	br	x17

0000000000010bb0 <_ZN13VLLogMediator15setConfigParamsERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE@plt>:
   10bb0:      	adrp	x16, 0x15000
   10bb4:      	ldr	x17, [x16, #0x440]
   10bb8:      	add	x16, x16, #0x440
   10bbc:      	br	x17

0000000000010bc0 <_Z20vlcollect_set_configPKc@plt>:
   10bc0:      	adrp	x16, 0x15000
   10bc4:      	ldr	x17, [x16, #0x448]
   10bc8:      	add	x16, x16, #0x448
   10bcc:      	br	x17

0000000000010bd0 <_ZNSt6__ndk115__thread_structC1Ev@plt>:
   10bd0:      	adrp	x16, 0x15000
   10bd4:      	ldr	x17, [x16, #0x450]
   10bd8:      	add	x16, x16, #0x450
   10bdc:      	br	x17

0000000000010be0 <pthread_create@plt>:
   10be0:      	adrp	x16, 0x15000
   10be4:      	ldr	x17, [x16, #0x458]
   10be8:      	add	x16, x16, #0x458
   10bec:      	br	x17

0000000000010bf0 <_ZNSt6__ndk120__throw_system_errorEiPKc@plt>:
   10bf0:      	adrp	x16, 0x15000
   10bf4:      	ldr	x17, [x16, #0x460]
   10bf8:      	add	x16, x16, #0x460
   10bfc:      	br	x17

0000000000010c00 <_ZNSt6__ndk115__thread_structD1Ev@plt>:
   10c00:      	adrp	x16, 0x15000
   10c04:      	ldr	x17, [x16, #0x468]
   10c08:      	add	x16, x16, #0x468
   10c0c:      	br	x17

0000000000010c10 <__cxa_rethrow@plt>:
   10c10:      	adrp	x16, 0x15000
   10c14:      	ldr	x17, [x16, #0x470]
   10c18:      	add	x16, x16, #0x470
   10c1c:      	br	x17

0000000000010c20 <_ZN13VLLogMediator14setLogCallbackERKNSt6__ndk18functionIFvRKNS0_6vectorI11vllog_entryNS0_9allocatorIS3_EEEEEEE@plt>:
   10c20:      	adrp	x16, 0x15000
   10c24:      	ldr	x17, [x16, #0x478]
   10c28:      	add	x16, x16, #0x478
   10c2c:      	br	x17

0000000000010c30 <_ZN13VLLogMediator13setTagExcludeEPKci@plt>:
   10c30:      	adrp	x16, 0x15000
   10c34:      	ldr	x17, [x16, #0x480]
   10c38:      	add	x16, x16, #0x480
   10c3c:      	br	x17

0000000000010c40 <_Z26vlcollect_set_tag_excludedPKci@plt>:
   10c40:      	adrp	x16, 0x15000
   10c44:      	ldr	x17, [x16, #0x488]
   10c48:      	add	x16, x16, #0x488
   10c4c:      	br	x17

0000000000010c50 <_Z19vlcollect_get_stateP15vlcollect_state@plt>:
   10c50:      	adrp	x16, 0x15000
   10c54:      	ldr	x17, [x16, #0x490]
   10c58:      	add	x16, x16, #0x490
   10c5c:      	br	x17

0000000000010c60 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEElsEm@plt>:
   10c60:      	adrp	x16, 0x15000
   10c64:      	ldr	x17, [x16, #0x498]
   10c68:      	add	x16, x16, #0x498
   10c6c:      	br	x17

0000000000010c70 <_ZN13VLLogMediator17formatMessageSafeERK11vllog_entry@plt>:
   10c70:      	adrp	x16, 0x15000
   10c74:      	ldr	x17, [x16, #0x4a0]
   10c78:      	add	x16, x16, #0x4a0
   10c7c:      	br	x17

0000000000010c80 <_ZN13VLLogMediator15getVllogVersionEv@plt>:
   10c80:      	adrp	x16, 0x15000
   10c84:      	ldr	x17, [x16, #0x4a8]
   10c88:      	add	x16, x16, #0x4a8
   10c8c:      	br	x17

0000000000010c90 <_Z17vllog_get_versionv@plt>:
   10c90:      	adrp	x16, 0x15000
   10c94:      	ldr	x17, [x16, #0x4b0]
   10c98:      	add	x16, x16, #0x4b0
   10c9c:      	br	x17

0000000000010ca0 <_ZN13VLLogMediator7runLoopEv@plt>:
   10ca0:      	adrp	x16, 0x15000
   10ca4:      	ldr	x17, [x16, #0x4b8]
   10ca8:      	add	x16, x16, #0x4b8
   10cac:      	br	x17

0000000000010cb0 <_ZNSt6__ndk16chrono12system_clock3nowEv@plt>:
   10cb0:      	adrp	x16, 0x15000
   10cb4:      	ldr	x17, [x16, #0x4c0]
   10cb8:      	add	x16, x16, #0x4c0
   10cbc:      	br	x17

0000000000010cc0 <_ZNSt6__ndk118condition_variable15__do_timed_waitERNS_11unique_lockINS_5mutexEEENS_6chrono10time_pointINS5_12system_clockENS5_8durationIxNS_5ratioILl1ELl1000000000EEEEEEE@plt>:
   10cc0:      	adrp	x16, 0x15000
   10cc4:      	ldr	x17, [x16, #0x4c8]
   10cc8:      	add	x16, x16, #0x4c8
   10ccc:      	br	x17

0000000000010cd0 <_Z19vlcollect_get_entryP11vllog_entry@plt>:
   10cd0:      	adrp	x16, 0x15000
   10cd4:      	ldr	x17, [x16, #0x4d0]
   10cd8:      	add	x16, x16, #0x4d0
   10cdc:      	br	x17

0000000000010ce0 <_Z20vlcollect_entry_freeP11vllog_entry@plt>:
   10ce0:      	adrp	x16, 0x15000
   10ce4:      	ldr	x17, [x16, #0x4d8]
   10ce8:      	add	x16, x16, #0x4d8
   10cec:      	br	x17

0000000000010cf0 <_ZN13VLLogMediator8testDataEv@plt>:
   10cf0:      	adrp	x16, 0x15000
   10cf4:      	ldr	x17, [x16, #0x4e0]
   10cf8:      	add	x16, x16, #0x4e0
   10cfc:      	br	x17

0000000000010d00 <_Z15vllog_tag_print13vllog_level_tPKcS1_S1_z@plt>:
   10d00:      	adrp	x16, 0x15000
   10d04:      	ldr	x17, [x16, #0x4e8]
   10d08:      	add	x16, x16, #0x4e8
   10d0c:      	br	x17

0000000000010d10 <_ZNSt6__ndk111this_thread9sleep_forERKNS_6chrono8durationIxNS_5ratioILl1ELl1000000000EEEEE@plt>:
   10d10:      	adrp	x16, 0x15000
   10d14:      	ldr	x17, [x16, #0x4f0]
   10d18:      	add	x16, x16, #0x4f0
   10d1c:      	br	x17

0000000000010d20 <_ZNSt6__ndk119__thread_local_dataEv@plt>:
   10d20:      	adrp	x16, 0x15000
   10d24:      	ldr	x17, [x16, #0x4f8]
   10d28:      	add	x16, x16, #0x4f8
   10d2c:      	br	x17

0000000000010d30 <pthread_setspecific@plt>:
   10d30:      	adrp	x16, 0x15000
   10d34:      	ldr	x17, [x16, #0x500]
   10d38:      	add	x16, x16, #0x500
   10d3c:      	br	x17

0000000000010d40 <__android_log_print@plt>:
   10d40:      	adrp	x16, 0x15000
   10d44:      	ldr	x17, [x16, #0x508]
   10d48:      	add	x16, x16, #0x508
   10d4c:      	br	x17

0000000000010d50 <fprintf@plt>:
   10d50:      	adrp	x16, 0x15000
   10d54:      	ldr	x17, [x16, #0x510]
   10d58:      	add	x16, x16, #0x510
   10d5c:      	br	x17

0000000000010d60 <fflush@plt>:
   10d60:      	adrp	x16, 0x15000
   10d64:      	ldr	x17, [x16, #0x518]
   10d68:      	add	x16, x16, #0x518
   10d6c:      	br	x17

0000000000010d70 <abort@plt>:
   10d70:      	adrp	x16, 0x15000
   10d74:      	ldr	x17, [x16, #0x520]
   10d78:      	add	x16, x16, #0x520
   10d7c:      	br	x17

0000000000010d80 <pthread_rwlock_wrlock@plt>:
   10d80:      	adrp	x16, 0x15000
   10d84:      	ldr	x17, [x16, #0x528]
   10d88:      	add	x16, x16, #0x528
   10d8c:      	br	x17

0000000000010d90 <pthread_rwlock_unlock@plt>:
   10d90:      	adrp	x16, 0x15000
   10d94:      	ldr	x17, [x16, #0x530]
   10d98:      	add	x16, x16, #0x530
   10d9c:      	br	x17

0000000000010da0 <dl_iterate_phdr@plt>:
   10da0:      	adrp	x16, 0x15000
   10da4:      	ldr	x17, [x16, #0x538]
   10da8:      	add	x16, x16, #0x538
   10dac:      	br	x17

0000000000010db0 <pthread_rwlock_rdlock@plt>:
   10db0:      	adrp	x16, 0x15000
   10db4:      	ldr	x17, [x16, #0x540]
   10db8:      	add	x16, x16, #0x540
   10dbc:      	br	x17

0000000000010dc0 <getpid@plt>:
   10dc0:      	adrp	x16, 0x15000
   10dc4:      	ldr	x17, [x16, #0x548]
   10dc8:      	add	x16, x16, #0x548
   10dcc:      	br	x17

0000000000010dd0 <syscall@plt>:
   10dd0:      	adrp	x16, 0x15000
   10dd4:      	ldr	x17, [x16, #0x550]
   10dd8:      	add	x16, x16, #0x550
   10ddc:      	br	x17
