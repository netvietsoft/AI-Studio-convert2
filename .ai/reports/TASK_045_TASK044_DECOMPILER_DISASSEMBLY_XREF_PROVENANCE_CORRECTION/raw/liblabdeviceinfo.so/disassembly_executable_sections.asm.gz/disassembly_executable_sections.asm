
F:\CONVERT\com.mt.mtxx.mtxx\SOURCE\extracted_native_libs\lib\arm64-v8a\liblabdeviceinfo.so:	file format elf64-littleaarch64

Disassembly of section .text:

00000000000082d4 <.text>:
    82d4:      	bti	c
    82d8:      	nop
    82dc:      	adr	x0, 0x21980
    82e0:      	b	0x1d480 <__cxa_finalize@plt>
    82e4:      	bti	c
    82e8:      	ret
    82ec:      	bti	c
    82f0:      	b	0x82e4 <.text+0x10>
    82f4:      	bti	c
    82f8:      	cbz	x0, 0x8304 <.text+0x30>
    82fc:      	mov	x16, x0
    8300:      	br	x16
    8304:      	ret
    8308:      	bti	c
    830c:      	mov	x1, x0
    8310:      	nop
    8314:      	adr	x0, 0x82f4 <.text+0x20>
    8318:      	nop
    831c:      	adr	x2, 0x21980
    8320:      	b	0x1d490 <__cxa_atexit@plt>

0000000000008324 <JNI_OnLoad>:
    8324:      	sub	sp, sp, #0x30
    8328:      	stp	x29, x30, [sp, #0x10]
    832c:      	stp	x20, x19, [sp, #0x20]
    8330:      	add	x29, sp, #0x10
    8334:      	mrs	x19, TPIDR_EL0
    8338:      	mov	w2, #0x6                // =6
    833c:      	mov	w20, #0x6               // =6
    8340:      	ldr	x8, [x19, #0x28]
    8344:      	mov	x1, sp
    8348:      	movk	w2, #0x1, lsl #16
    834c:      	movk	w20, #0x1, lsl #16
    8350:      	str	x8, [sp, #0x8]
    8354:      	ldr	x8, [x0]
    8358:      	ldr	x8, [x8, #0x30]
    835c:      	blr	x8
    8360:      	cbz	w0, 0x836c <JNI_OnLoad+0x48>
    8364:      	mov	w0, #-0x1               // =-1
    8368:      	b	0x83b0 <JNI_OnLoad+0x8c>
    836c:      	ldr	x0, [sp]
    8370:      	nop
    8374:      	adr	x1, 0x4b39
    8378:      	ldr	x8, [x0]
    837c:      	ldr	x8, [x8, #0x30]
    8380:      	blr	x8
    8384:      	cbz	x0, 0x8364 <JNI_OnLoad+0x40>
    8388:      	mov	x1, x0
    838c:      	ldr	x0, [sp]
    8390:      	nop
    8394:      	adr	x2, 0x21988
    8398:      	mov	w3, #0x1                // =1
    839c:      	ldr	x8, [x0]
    83a0:      	ldr	x8, [x8, #0x6b8]
    83a4:      	blr	x8
    83a8:      	cmp	w0, #0x0
    83ac:      	csel	w0, w20, w0, eq
    83b0:      	ldr	x8, [x19, #0x28]
    83b4:      	ldr	x9, [sp, #0x8]
    83b8:      	cmp	x8, x9
    83bc:      	b.ne	0x83d0 <JNI_OnLoad+0xac>
    83c0:      	ldp	x20, x19, [sp, #0x20]
    83c4:      	ldp	x29, x30, [sp, #0x10]
    83c8:      	add	sp, sp, #0x30
    83cc:      	ret
    83d0:      	bl	0x1d4a0 <__stack_chk_fail@plt>

00000000000083d4 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass>:
    83d4:      	sub	sp, sp, #0x150
    83d8:      	stp	x29, x30, [sp, #0xf0]
    83dc:      	stp	x28, x27, [sp, #0x100]
    83e0:      	stp	x26, x25, [sp, #0x110]
    83e4:      	stp	x24, x23, [sp, #0x120]
    83e8:      	stp	x22, x21, [sp, #0x130]
    83ec:      	stp	x20, x19, [sp, #0x140]
    83f0:      	add	x29, sp, #0xf0
    83f4:      	mrs	x19, TPIDR_EL0
    83f8:      	mov	x20, x0
    83fc:      	sub	x0, x29, #0x18
    8400:      	ldr	x8, [x19, #0x28]
    8404:      	stur	x8, [x29, #-0x10]
    8408:      	bl	0xca58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3a44>
    840c:      	sub	x0, x29, #0x20
    8410:      	stur	x19, [x29, #-0x48]
    8414:      	bl	0xcb28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3b14>
    8418:      	sub	x0, x29, #0x28
    841c:      	bl	0xcbbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3ba8>
    8420:      	sub	x0, x29, #0x30
    8424:      	bl	0xcc60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3c4c>
    8428:      	sub	x0, x29, #0x38
    842c:      	bl	0xccc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3cb0>
    8430:      	sub	x0, x29, #0x40
    8434:      	bl	0xea98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5a84>
    8438:      	ldr	x8, [x20]
    843c:      	ldr	x8, [x8, #0x30]
    8440:      	nop
    8444:      	adr	x1, 0x4b39
    8448:      	mov	x0, x20
    844c:      	blr	x8
    8450:      	ldr	x8, [x20]
    8454:      	mov	x24, x0
    8458:      	ldr	x8, [x8, #0x108]
    845c:      	adrp	x2, 0x4000
    8460:      	add	x2, x2, #0x174
    8464:      	adrp	x3, 0x2000
    8468:      	add	x3, x3, #0xd20
    846c:      	mov	x0, x20
    8470:      	mov	x1, x24
    8474:      	blr	x8
    8478:      	mov	x2, x0
    847c:      	mov	x0, x20
    8480:      	mov	x1, x24
    8484:      	bl	0x1d4b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz@plt>
    8488:      	ldr	x8, [x20]
    848c:      	mov	x19, x0
    8490:      	ldr	x8, [x8, #0x2f0]
    8494:      	adrp	x2, 0x3000
    8498:      	add	x2, x2, #0xa91
    849c:      	adrp	x3, 0x2000
    84a0:      	add	x3, x3, #0xa60
    84a4:      	mov	x0, x20
    84a8:      	mov	x1, x24
    84ac:      	blr	x8
    84b0:      	ldr	x8, [x20]
    84b4:      	mov	x25, x0
    84b8:      	ldr	x8, [x8, #0x2f0]
    84bc:      	adrp	x2, 0x4000
    84c0:      	add	x2, x2, #0x47e
    84c4:      	adrp	x3, 0x4000
    84c8:      	add	x3, x3, #0x974
    84cc:      	mov	x0, x20
    84d0:      	mov	x1, x24
    84d4:      	blr	x8
    84d8:      	ldr	x8, [x20]
    84dc:      	mov	x23, x0
    84e0:      	ldr	x8, [x8, #0x2f0]
    84e4:      	adrp	x2, 0x4000
    84e8:      	add	x2, x2, #0x17b
    84ec:      	adrp	x3, 0x2000
    84f0:      	add	x3, x3, #0xa60
    84f4:      	mov	x0, x20
    84f8:      	mov	x1, x24
    84fc:      	blr	x8
    8500:      	ldr	x8, [x20]
    8504:      	mov	x22, x0
    8508:      	ldr	x8, [x8, #0x2f0]
    850c:      	adrp	x2, 0x3000
    8510:      	add	x2, x2, #0x682
    8514:      	adrp	x3, 0x4000
    8518:      	add	x3, x3, #0x974
    851c:      	mov	x0, x20
    8520:      	mov	x1, x24
    8524:      	blr	x8
    8528:      	ldr	x8, [x20]
    852c:      	mov	x21, x0
    8530:      	ldr	x8, [x8, #0x2f0]
    8534:      	adrp	x2, 0x4000
    8538:      	add	x2, x2, #0x6e0
    853c:      	adrp	x3, 0x3000
    8540:      	add	x3, x3, #0xc10
    8544:      	mov	x0, x20
    8548:      	mov	x1, x24
    854c:      	blr	x8
    8550:      	ldr	x8, [x20]
    8554:      	mov	x28, x0
    8558:      	ldr	x8, [x8, #0x2f0]
    855c:      	adrp	x2, 0x2000
    8560:      	add	x2, x2, #0xd24
    8564:      	adrp	x3, 0x3000
    8568:      	add	x3, x3, #0xc10
    856c:      	mov	x0, x20
    8570:      	mov	x1, x24
    8574:      	blr	x8
    8578:      	ldr	x8, [x20]
    857c:      	mov	x27, x0
    8580:      	ldr	x8, [x8, #0x2f0]
    8584:      	adrp	x2, 0x3000
    8588:      	add	x2, x2, #0xe41
    858c:      	adrp	x3, 0x2000
    8590:      	add	x3, x3, #0xa60
    8594:      	mov	x0, x20
    8598:      	mov	x1, x24
    859c:      	blr	x8
    85a0:      	ldr	x8, [x20]
    85a4:      	mov	x26, x0
    85a8:      	ldr	x8, [x8, #0x2f0]
    85ac:      	adrp	x2, 0x4000
    85b0:      	add	x2, x2, #0x403
    85b4:      	adrp	x3, 0x2000
    85b8:      	add	x3, x3, #0xa60
    85bc:      	mov	x0, x20
    85c0:      	mov	x1, x24
    85c4:      	blr	x8
    85c8:      	stur	x0, [x29, #-0x50]
    85cc:      	ldr	x8, [x20]
    85d0:      	ldr	x8, [x8, #0x2f0]
    85d4:      	adrp	x2, 0x3000
    85d8:      	add	x2, x2, #0xa9b
    85dc:      	adrp	x3, 0x2000
    85e0:      	add	x3, x3, #0xa60
    85e4:      	mov	x0, x20
    85e8:      	mov	x1, x24
    85ec:      	blr	x8
    85f0:      	stur	x0, [x29, #-0x58]
    85f4:      	ldr	x8, [x20]
    85f8:      	ldr	x8, [x8, #0x2f0]
    85fc:      	adrp	x2, 0x4000
    8600:      	add	x2, x2, #0x487
    8604:      	adrp	x3, 0x2000
    8608:      	add	x3, x3, #0xa60
    860c:      	mov	x0, x20
    8610:      	mov	x1, x24
    8614:      	blr	x8
    8618:      	stur	x0, [x29, #-0x60]
    861c:      	ldr	x8, [x20]
    8620:      	ldr	x8, [x8, #0x2f0]
    8624:      	adrp	x2, 0x3000
    8628:      	add	x2, x2, #0x82c
    862c:      	adrp	x3, 0x3000
    8630:      	add	x3, x3, #0xc10
    8634:      	mov	x0, x20
    8638:      	mov	x1, x24
    863c:      	blr	x8
    8640:      	str	x0, [sp, #0x78]
    8644:      	ldr	x8, [x20]
    8648:      	ldr	x8, [x8, #0x2f0]
    864c:      	adrp	x2, 0x4000
    8650:      	add	x2, x2, #0x271
    8654:      	adrp	x3, 0x2000
    8658:      	add	x3, x3, #0xa60
    865c:      	mov	x0, x20
    8660:      	mov	x1, x24
    8664:      	blr	x8
    8668:      	stur	x0, [x29, #-0x68]
    866c:      	ldr	x8, [x20]
    8670:      	ldr	x8, [x8, #0x2f0]
    8674:      	adrp	x2, 0x4000
    8678:      	add	x2, x2, #0x40d
    867c:      	adrp	x3, 0x2000
    8680:      	add	x3, x3, #0xa60
    8684:      	mov	x0, x20
    8688:      	mov	x1, x24
    868c:      	blr	x8
    8690:      	stur	x0, [x29, #-0x70]
    8694:      	ldr	x8, [x20]
    8698:      	ldr	x8, [x8, #0x2f0]
    869c:      	adrp	x2, 0x3000
    86a0:      	add	x2, x2, #0xaa7
    86a4:      	adrp	x3, 0x3000
    86a8:      	add	x3, x3, #0xc10
    86ac:      	mov	x0, x20
    86b0:      	mov	x1, x24
    86b4:      	blr	x8
    86b8:      	str	x0, [sp, #0x70]
    86bc:      	ldr	x8, [x20]
    86c0:      	ldr	x8, [x8, #0x2f0]
    86c4:      	adrp	x2, 0x4000
    86c8:      	add	x2, x2, #0xc9a
    86cc:      	adrp	x3, 0x2000
    86d0:      	add	x3, x3, #0xa60
    86d4:      	mov	x0, x20
    86d8:      	mov	x1, x24
    86dc:      	blr	x8
    86e0:      	str	x0, [sp, #0x68]
    86e4:      	ldr	x8, [x20]
    86e8:      	ldr	x8, [x8, #0x2f0]
    86ec:      	adrp	x2, 0x3000
    86f0:      	add	x2, x2, #0xfbb
    86f4:      	adrp	x3, 0x4000
    86f8:      	add	x3, x3, #0x974
    86fc:      	mov	x0, x20
    8700:      	mov	x1, x24
    8704:      	blr	x8
    8708:      	str	x0, [sp, #0x60]
    870c:      	ldr	x8, [x20]
    8710:      	ldr	x8, [x8, #0x2f0]
    8714:      	adrp	x2, 0x4000
    8718:      	add	x2, x2, #0x6ee
    871c:      	adrp	x3, 0x4000
    8720:      	add	x3, x3, #0x5a4
    8724:      	mov	x0, x20
    8728:      	mov	x1, x24
    872c:      	blr	x8
    8730:      	str	x0, [sp, #0x58]
    8734:      	ldr	x8, [x20]
    8738:      	ldr	x8, [x8, #0x2f0]
    873c:      	adrp	x2, 0x4000
    8740:      	add	x2, x2, #0xb60
    8744:      	adrp	x3, 0x2000
    8748:      	add	x3, x3, #0xa60
    874c:      	mov	x0, x20
    8750:      	mov	x1, x24
    8754:      	blr	x8
    8758:      	str	x0, [sp, #0x50]
    875c:      	ldr	x8, [x20]
    8760:      	ldr	x8, [x8, #0x2f0]
    8764:      	adrp	x2, 0x4000
    8768:      	add	x2, x2, #0x976
    876c:      	adrp	x3, 0x2000
    8770:      	add	x3, x3, #0xa60
    8774:      	mov	x0, x20
    8778:      	mov	x1, x24
    877c:      	blr	x8
    8780:      	str	x0, [sp, #0x48]
    8784:      	ldr	x8, [x20]
    8788:      	ldr	x8, [x8, #0x2f0]
    878c:      	adrp	x2, 0x4000
    8790:      	add	x2, x2, #0xa3a
    8794:      	adrp	x3, 0x2000
    8798:      	add	x3, x3, #0xa60
    879c:      	mov	x0, x20
    87a0:      	mov	x1, x24
    87a4:      	blr	x8
    87a8:      	str	x0, [sp, #0x40]
    87ac:      	ldr	x8, [x20]
    87b0:      	ldr	x8, [x8, #0x2f0]
    87b4:      	adrp	x2, 0x4000
    87b8:      	add	x2, x2, #0x6fb
    87bc:      	adrp	x3, 0x2000
    87c0:      	add	x3, x3, #0xa60
    87c4:      	mov	x0, x20
    87c8:      	mov	x1, x24
    87cc:      	blr	x8
    87d0:      	str	x0, [sp, #0x38]
    87d4:      	ldr	x8, [x20]
    87d8:      	ldr	x8, [x8, #0x2f0]
    87dc:      	adrp	x2, 0x2000
    87e0:      	add	x2, x2, #0xb03
    87e4:      	adrp	x3, 0x4000
    87e8:      	add	x3, x3, #0x974
    87ec:      	mov	x0, x20
    87f0:      	mov	x1, x24
    87f4:      	blr	x8
    87f8:      	str	x0, [sp, #0x30]
    87fc:      	ldr	x8, [x20]
    8800:      	ldr	x8, [x8, #0x2f0]
    8804:      	adrp	x2, 0x4000
    8808:      	add	x2, x2, #0x41d
    880c:      	adrp	x3, 0x2000
    8810:      	add	x3, x3, #0xa60
    8814:      	mov	x0, x20
    8818:      	mov	x1, x24
    881c:      	blr	x8
    8820:      	str	x0, [sp, #0x28]
    8824:      	ldr	x8, [x20]
    8828:      	ldr	x8, [x8, #0x2f0]
    882c:      	adrp	x2, 0x2000
    8830:      	add	x2, x2, #0xfaa
    8834:      	adrp	x3, 0x4000
    8838:      	add	x3, x3, #0x5a4
    883c:      	mov	x0, x20
    8840:      	mov	x1, x24
    8844:      	blr	x8
    8848:      	str	x0, [sp, #0x20]
    884c:      	ldr	x8, [x20]
    8850:      	ldr	x8, [x8, #0x2f0]
    8854:      	adrp	x2, 0x4000
    8858:      	add	x2, x2, #0x989
    885c:      	adrp	x3, 0x4000
    8860:      	add	x3, x3, #0x5a4
    8864:      	mov	x0, x20
    8868:      	mov	x1, x24
    886c:      	blr	x8
    8870:      	str	x0, [sp, #0x18]
    8874:      	ldr	x8, [x20]
    8878:      	ldr	x8, [x8, #0x2f0]
    887c:      	adrp	x2, 0x3000
    8880:      	add	x2, x2, #0xab5
    8884:      	adrp	x3, 0x2000
    8888:      	add	x3, x3, #0xa60
    888c:      	mov	x0, x20
    8890:      	mov	x1, x24
    8894:      	blr	x8
    8898:      	str	x0, [sp, #0x10]
    889c:      	ldr	x8, [x20]
    88a0:      	ldr	x8, [x8, #0x2f0]
    88a4:      	adrp	x2, 0x3000
    88a8:      	add	x2, x2, #0x91
    88ac:      	adrp	x3, 0x2000
    88b0:      	add	x3, x3, #0xa60
    88b4:      	mov	x0, x20
    88b8:      	mov	x1, x24
    88bc:      	blr	x8
    88c0:      	str	x0, [sp, #0x8]
    88c4:      	ldr	x8, [x20]
    88c8:      	ldr	x8, [x8, #0x2f0]
    88cc:      	adrp	x2, 0x4000
    88d0:      	add	x2, x2, #0x281
    88d4:      	adrp	x3, 0x2000
    88d8:      	add	x3, x3, #0xa60
    88dc:      	mov	x0, x20
    88e0:      	mov	x1, x24
    88e4:      	blr	x8
    88e8:      	mov	x24, x0
    88ec:      	sub	x0, x29, #0x20
    88f0:      	bl	0xcb84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3b70>
    88f4:      	mov	x1, x0
    88f8:      	ldr	x8, [x20]
    88fc:      	ldr	x8, [x8, #0x538]
    8900:      	mov	x0, x20
    8904:      	blr	x8
    8908:      	ldr	x8, [x20]
    890c:      	mov	x3, x0
    8910:      	ldr	x8, [x8, #0x340]
    8914:      	mov	x0, x20
    8918:      	mov	x1, x19
    891c:      	mov	x2, x25
    8920:      	blr	x8
    8924:      	sub	x0, x29, #0x20
    8928:      	bl	0xcb78 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3b64>
    892c:      	ldr	x8, [x20]
    8930:      	mov	w3, w0
    8934:      	ldr	x8, [x8, #0x368]
    8938:      	mov	x0, x20
    893c:      	mov	x1, x19
    8940:      	mov	x2, x23
    8944:      	blr	x8
    8948:      	sub	x0, x29, #0x20
    894c:      	bl	0xcba8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3b94>
    8950:      	mov	x1, x0
    8954:      	ldr	x8, [x20]
    8958:      	ldr	x8, [x8, #0x538]
    895c:      	mov	x0, x20
    8960:      	blr	x8
    8964:      	ldr	x8, [x20]
    8968:      	mov	x3, x0
    896c:      	ldr	x8, [x8, #0x340]
    8970:      	mov	x0, x20
    8974:      	mov	x1, x19
    8978:      	mov	x2, x22
    897c:      	blr	x8
    8980:      	sub	x0, x29, #0x18
    8984:      	bl	0xcac0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3aac>
    8988:      	ldr	x8, [x20]
    898c:      	mov	w3, w0
    8990:      	ldr	x8, [x8, #0x368]
    8994:      	mov	x0, x20
    8998:      	mov	x1, x19
    899c:      	mov	x2, x21
    89a0:      	blr	x8
    89a4:      	sub	x0, x29, #0x18
    89a8:      	bl	0xcaf0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3adc>
    89ac:      	ldr	x8, [x20]
    89b0:      	ldr	x8, [x8, #0x348]
    89b4:      	and	w3, w0, #0x1
    89b8:      	mov	x0, x20
    89bc:      	mov	x1, x19
    89c0:      	mov	x2, x28
    89c4:      	blr	x8
    89c8:      	sub	x0, x29, #0x18
    89cc:      	bl	0xcae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3ad0>
    89d0:      	ldr	x8, [x20]
    89d4:      	ldr	x8, [x8, #0x348]
    89d8:      	and	w3, w0, #0x1
    89dc:      	mov	x0, x20
    89e0:      	mov	x1, x19
    89e4:      	mov	x2, x27
    89e8:      	blr	x8
    89ec:      	sub	x0, x29, #0x18
    89f0:      	bl	0xcb08 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3af4>
    89f4:      	mov	x1, x0
    89f8:      	ldr	x8, [x20]
    89fc:      	ldr	x8, [x8, #0x538]
    8a00:      	mov	x0, x20
    8a04:      	blr	x8
    8a08:      	ldr	x8, [x20]
    8a0c:      	mov	x3, x0
    8a10:      	ldr	x8, [x8, #0x340]
    8a14:      	mov	x0, x20
    8a18:      	mov	x1, x19
    8a1c:      	mov	x2, x26
    8a20:      	blr	x8
    8a24:      	sub	x0, x29, #0x18
    8a28:      	bl	0xcb14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3b00>
    8a2c:      	mov	x1, x0
    8a30:      	ldr	x8, [x20]
    8a34:      	ldr	x8, [x8, #0x538]
    8a38:      	mov	x0, x20
    8a3c:      	blr	x8
    8a40:      	ldr	x8, [x20]
    8a44:      	mov	x3, x0
    8a48:      	ldr	x8, [x8, #0x340]
    8a4c:      	ldur	x2, [x29, #-0x50]
    8a50:      	mov	x0, x20
    8a54:      	mov	x1, x19
    8a58:      	blr	x8
    8a5c:      	sub	x0, x29, #0x18
    8a60:      	bl	0xcab4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3aa0>
    8a64:      	mov	x1, x0
    8a68:      	ldr	x8, [x20]
    8a6c:      	ldr	x8, [x8, #0x538]
    8a70:      	mov	x0, x20
    8a74:      	blr	x8
    8a78:      	ldr	x8, [x20]
    8a7c:      	mov	x3, x0
    8a80:      	ldr	x8, [x8, #0x340]
    8a84:      	ldur	x2, [x29, #-0x58]
    8a88:      	mov	x0, x20
    8a8c:      	mov	x1, x19
    8a90:      	blr	x8
    8a94:      	sub	x0, x29, #0x18
    8a98:      	bl	0xcaa8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3a94>
    8a9c:      	mov	x1, x0
    8aa0:      	ldr	x8, [x20]
    8aa4:      	ldr	x8, [x8, #0x538]
    8aa8:      	mov	x0, x20
    8aac:      	blr	x8
    8ab0:      	ldr	x8, [x20]
    8ab4:      	mov	x3, x0
    8ab8:      	ldr	x8, [x8, #0x340]
    8abc:      	ldur	x2, [x29, #-0x60]
    8ac0:      	mov	x0, x20
    8ac4:      	mov	x1, x19
    8ac8:      	blr	x8
    8acc:      	sub	x0, x29, #0x28
    8ad0:      	bl	0xcc3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3c28>
    8ad4:      	mov	x1, x0
    8ad8:      	ldr	x8, [x20]
    8adc:      	ldr	x8, [x8, #0x538]
    8ae0:      	mov	x0, x20
    8ae4:      	blr	x8
    8ae8:      	ldr	x8, [x20]
    8aec:      	mov	x3, x0
    8af0:      	ldr	x8, [x8, #0x340]
    8af4:      	ldur	x2, [x29, #-0x68]
    8af8:      	mov	x0, x20
    8afc:      	mov	x1, x19
    8b00:      	blr	x8
    8b04:      	sub	x0, x29, #0x28
    8b08:      	bl	0xcc34 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3c20>
    8b0c:      	mov	x1, x0
    8b10:      	ldr	x8, [x20]
    8b14:      	ldr	x8, [x8, #0x538]
    8b18:      	mov	x0, x20
    8b1c:      	blr	x8
    8b20:      	ldr	x8, [x20]
    8b24:      	mov	x3, x0
    8b28:      	ldr	x8, [x8, #0x340]
    8b2c:      	ldur	x2, [x29, #-0x70]
    8b30:      	mov	x0, x20
    8b34:      	mov	x1, x19
    8b38:      	blr	x8
    8b3c:      	sub	x0, x29, #0x28
    8b40:      	bl	0xcc48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3c34>
    8b44:      	ldr	x8, [x20]
    8b48:      	ldr	x8, [x8, #0x348]
    8b4c:      	ldr	x2, [sp, #0x70]
    8b50:      	and	w3, w0, #0x1
    8b54:      	mov	x0, x20
    8b58:      	mov	x1, x19
    8b5c:      	blr	x8
    8b60:      	sub	x0, x29, #0x30
    8b64:      	bl	0xccb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3ca4>
    8b68:      	ldr	x8, [x20]
    8b6c:      	ldr	x8, [x8, #0x348]
    8b70:      	ldr	x2, [sp, #0x78]
    8b74:      	and	w3, w0, #0x1
    8b78:      	mov	x0, x20
    8b7c:      	mov	x1, x19
    8b80:      	blr	x8
    8b84:      	sub	x0, x29, #0x38
    8b88:      	bl	0xcd10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3cfc>
    8b8c:      	mov	x1, x0
    8b90:      	ldr	x8, [x20]
    8b94:      	ldr	x8, [x8, #0x538]
    8b98:      	mov	x0, x20
    8b9c:      	blr	x8
    8ba0:      	ldr	x8, [x20]
    8ba4:      	mov	x3, x0
    8ba8:      	ldr	x8, [x8, #0x340]
    8bac:      	ldr	x2, [sp, #0x68]
    8bb0:      	mov	x0, x20
    8bb4:      	mov	x1, x19
    8bb8:      	blr	x8
    8bbc:      	sub	x0, x29, #0x18
    8bc0:      	bl	0xcacc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3ab8>
    8bc4:      	ldr	x8, [x20]
    8bc8:      	mov	w3, w0
    8bcc:      	ldr	x8, [x8, #0x368]
    8bd0:      	ldr	x2, [sp, #0x60]
    8bd4:      	mov	x0, x20
    8bd8:      	mov	x1, x19
    8bdc:      	blr	x8
    8be0:      	sub	x0, x29, #0x18
    8be4:      	bl	0xcad8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3ac4>
    8be8:      	ldr	x8, [x20]
    8bec:      	mov	x3, x0
    8bf0:      	ldr	x8, [x8, #0x370]
    8bf4:      	ldr	x2, [sp, #0x58]
    8bf8:      	mov	x0, x20
    8bfc:      	mov	x1, x19
    8c00:      	blr	x8
    8c04:      	sub	x0, x29, #0x18
    8c08:      	bl	0xcafc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3ae8>
    8c0c:      	mov	x1, x0
    8c10:      	ldr	x8, [x20]
    8c14:      	ldr	x8, [x8, #0x538]
    8c18:      	mov	x0, x20
    8c1c:      	blr	x8
    8c20:      	ldr	x8, [x20]
    8c24:      	mov	x3, x0
    8c28:      	ldr	x8, [x8, #0x340]
    8c2c:      	ldr	x2, [sp, #0x50]
    8c30:      	mov	x0, x20
    8c34:      	mov	x1, x19
    8c38:      	blr	x8
    8c3c:      	sub	x0, x29, #0x18
    8c40:      	bl	0xcb1c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3b08>
    8c44:      	mov	x1, x0
    8c48:      	ldr	x8, [x20]
    8c4c:      	ldr	x8, [x8, #0x538]
    8c50:      	mov	x0, x20
    8c54:      	blr	x8
    8c58:      	ldr	x8, [x20]
    8c5c:      	mov	x3, x0
    8c60:      	ldr	x8, [x8, #0x340]
    8c64:      	ldr	x2, [sp, #0x48]
    8c68:      	mov	x0, x20
    8c6c:      	mov	x1, x19
    8c70:      	blr	x8
    8c74:      	sub	x0, x29, #0x20
    8c78:      	bl	0xcbb0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3b9c>
    8c7c:      	mov	x1, x0
    8c80:      	ldr	x8, [x20]
    8c84:      	ldr	x8, [x8, #0x538]
    8c88:      	mov	x0, x20
    8c8c:      	blr	x8
    8c90:      	ldr	x8, [x20]
    8c94:      	mov	x3, x0
    8c98:      	ldr	x8, [x8, #0x340]
    8c9c:      	ldr	x2, [sp, #0x40]
    8ca0:      	mov	x0, x20
    8ca4:      	mov	x1, x19
    8ca8:      	blr	x8
    8cac:      	sub	x0, x29, #0x20
    8cb0:      	bl	0xcb90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3b7c>
    8cb4:      	mov	x1, x0
    8cb8:      	ldr	x8, [x20]
    8cbc:      	ldr	x8, [x8, #0x538]
    8cc0:      	mov	x0, x20
    8cc4:      	blr	x8
    8cc8:      	ldr	x8, [x20]
    8ccc:      	mov	x3, x0
    8cd0:      	ldr	x8, [x8, #0x340]
    8cd4:      	ldr	x2, [sp, #0x38]
    8cd8:      	mov	x0, x20
    8cdc:      	mov	x1, x19
    8ce0:      	blr	x8
    8ce4:      	sub	x0, x29, #0x20
    8ce8:      	bl	0xcb9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3b88>
    8cec:      	ldr	x8, [x20]
    8cf0:      	mov	w3, w0
    8cf4:      	ldr	x8, [x8, #0x368]
    8cf8:      	ldr	x2, [sp, #0x30]
    8cfc:      	mov	x0, x20
    8d00:      	mov	x1, x19
    8d04:      	blr	x8
    8d08:      	sub	x0, x29, #0x28
    8d0c:      	bl	0xcc54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3c40>
    8d10:      	mov	x1, x0
    8d14:      	ldr	x8, [x20]
    8d18:      	ldr	x8, [x8, #0x538]
    8d1c:      	mov	x0, x20
    8d20:      	blr	x8
    8d24:      	ldr	x8, [x20]
    8d28:      	mov	x3, x0
    8d2c:      	ldr	x8, [x8, #0x340]
    8d30:      	ldr	x2, [sp, #0x28]
    8d34:      	mov	x0, x20
    8d38:      	mov	x1, x19
    8d3c:      	blr	x8
    8d40:      	sub	x0, x29, #0x40
    8d44:      	bl	0xeb38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5b24>
    8d48:      	ldr	x8, [x20]
    8d4c:      	mov	x3, x0
    8d50:      	ldr	x8, [x8, #0x370]
    8d54:      	ldr	x2, [sp, #0x20]
    8d58:      	mov	x0, x20
    8d5c:      	mov	x1, x19
    8d60:      	blr	x8
    8d64:      	sub	x0, x29, #0x40
    8d68:      	bl	0xeb2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5b18>
    8d6c:      	ldr	x8, [x20]
    8d70:      	mov	x3, x0
    8d74:      	ldr	x8, [x8, #0x370]
    8d78:      	ldr	x2, [sp, #0x18]
    8d7c:      	mov	x0, x20
    8d80:      	mov	x1, x19
    8d84:      	blr	x8
    8d88:      	sub	x0, x29, #0x30
    8d8c:      	bl	0xccb0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3c9c>
    8d90:      	mov	x1, x0
    8d94:      	ldr	x8, [x20]
    8d98:      	ldr	x8, [x8, #0x538]
    8d9c:      	mov	x0, x20
    8da0:      	blr	x8
    8da4:      	ldr	x8, [x20]
    8da8:      	mov	x3, x0
    8dac:      	ldr	x8, [x8, #0x340]
    8db0:      	ldr	x2, [sp, #0x10]
    8db4:      	mov	x0, x20
    8db8:      	mov	x1, x19
    8dbc:      	blr	x8
    8dc0:      	bl	0x9230 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x21c>
    8dc4:      	mov	x1, x0
    8dc8:      	ldr	x8, [x20]
    8dcc:      	ldr	x8, [x8, #0x538]
    8dd0:      	mov	x0, x20
    8dd4:      	blr	x8
    8dd8:      	ldr	x8, [x20]
    8ddc:      	mov	x3, x0
    8de0:      	ldr	x8, [x8, #0x340]
    8de4:      	ldr	x2, [sp, #0x8]
    8de8:      	mov	x0, x20
    8dec:      	mov	x1, x19
    8df0:      	blr	x8
    8df4:      	bl	0x9204 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1f0>
    8df8:      	mov	x1, x0
    8dfc:      	ldr	x8, [x20]
    8e00:      	ldr	x8, [x8, #0x538]
    8e04:      	mov	x0, x20
    8e08:      	blr	x8
    8e0c:      	ldr	x8, [x20]
    8e10:      	mov	x3, x0
    8e14:      	ldr	x8, [x8, #0x340]
    8e18:      	mov	x0, x20
    8e1c:      	mov	x1, x19
    8e20:      	mov	x2, x24
    8e24:      	blr	x8
    8e28:      	sub	x0, x29, #0x18
    8e2c:      	bl	0xcaf0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3adc>
    8e30:      	adrp	x1, 0x4000
    8e34:      	add	x1, x1, #0xca5
    8e38:      	adrp	x2, 0x4000
    8e3c:      	add	x2, x2, #0x5a6
    8e40:      	and	w3, w0, #0x1
    8e44:      	mov	w0, #0x4                // =4
    8e48:      	bl	0x1d4c0 <__android_log_print@plt>
    8e4c:      	sub	x0, x29, #0x18
    8e50:      	bl	0xcae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3ad0>
    8e54:      	adrp	x1, 0x4000
    8e58:      	add	x1, x1, #0xca5
    8e5c:      	adrp	x2, 0x2000
    8e60:      	add	x2, x2, #0xa73
    8e64:      	and	w3, w0, #0x1
    8e68:      	mov	w0, #0x4                // =4
    8e6c:      	bl	0x1d4c0 <__android_log_print@plt>
    8e70:      	sub	x0, x29, #0x30
    8e74:      	bl	0xccb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3ca4>
    8e78:      	adrp	x1, 0x4000
    8e7c:      	add	x1, x1, #0xca5
    8e80:      	adrp	x2, 0x3000
    8e84:      	add	x2, x2, #0xa23
    8e88:      	and	w3, w0, #0x1
    8e8c:      	mov	w0, #0x4                // =4
    8e90:      	bl	0x1d4c0 <__android_log_print@plt>
    8e94:      	sub	x0, x29, #0x38
    8e98:      	bl	0xcd10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3cfc>
    8e9c:      	mov	x3, x0
    8ea0:      	adrp	x1, 0x4000
    8ea4:      	add	x1, x1, #0xca5
    8ea8:      	adrp	x2, 0x3000
    8eac:      	add	x2, x2, #0x68b
    8eb0:      	mov	w0, #0x4                // =4
    8eb4:      	bl	0x1d4c0 <__android_log_print@plt>
    8eb8:      	sub	x0, x29, #0x40
    8ebc:      	bl	0xeb1c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5b08>
    8ec0:      	sub	x0, x29, #0x38
    8ec4:      	bl	0xcd00 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3cec>
    8ec8:      	sub	x0, x29, #0x30
    8ecc:      	bl	0xcca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3c8c>
    8ed0:      	sub	x0, x29, #0x28
    8ed4:      	bl	0xcc24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3c10>
    8ed8:      	sub	x0, x29, #0x20
    8edc:      	bl	0xcb68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3b54>
    8ee0:      	sub	x0, x29, #0x18
    8ee4:      	bl	0xca98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3a84>
    8ee8:      	ldur	x8, [x29, #-0x48]
    8eec:      	ldr	x8, [x8, #0x28]
    8ef0:      	ldur	x9, [x29, #-0x10]
    8ef4:      	cmp	x8, x9
    8ef8:      	b.ne	0x9010 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xc3c>
    8efc:      	mov	x0, x19
    8f00:      	ldp	x20, x19, [sp, #0x140]
    8f04:      	ldp	x22, x21, [sp, #0x130]
    8f08:      	ldp	x24, x23, [sp, #0x120]
    8f0c:      	ldp	x26, x25, [sp, #0x110]
    8f10:      	ldp	x28, x27, [sp, #0x100]
    8f14:      	ldp	x29, x30, [sp, #0xf0]
    8f18:      	add	sp, sp, #0x150
    8f1c:      	ret
    8f20:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f24:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f28:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f2c:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f30:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f34:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f38:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f3c:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f40:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f44:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f48:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f4c:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f50:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f54:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f58:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f5c:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f60:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f64:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f68:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f6c:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f70:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f74:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f78:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f7c:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f80:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f84:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f88:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f8c:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f90:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f94:      	b	0x8fc0 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbec>
    8f98:      	mov	x19, x0
    8f9c:      	b	0x8fcc <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xbf8>
    8fa0:      	mov	x19, x0
    8fa4:      	b	0x8fd4 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xc00>
    8fa8:      	mov	x19, x0
    8fac:      	b	0x8fdc <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xc08>
    8fb0:      	mov	x19, x0
    8fb4:      	b	0x8fe4 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xc10>
    8fb8:      	mov	x19, x0
    8fbc:      	b	0x8fec <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xc18>
    8fc0:      	mov	x19, x0
    8fc4:      	sub	x0, x29, #0x40
    8fc8:      	bl	0xeb1c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5b08>
    8fcc:      	sub	x0, x29, #0x38
    8fd0:      	bl	0xcd00 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3cec>
    8fd4:      	sub	x0, x29, #0x30
    8fd8:      	bl	0xcca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3c8c>
    8fdc:      	sub	x0, x29, #0x28
    8fe0:      	bl	0xcc24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3c10>
    8fe4:      	sub	x0, x29, #0x20
    8fe8:      	bl	0xcb68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3b54>
    8fec:      	sub	x0, x29, #0x18
    8ff0:      	bl	0xca98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3a84>
    8ff4:      	ldur	x8, [x29, #-0x48]
    8ff8:      	ldr	x8, [x8, #0x28]
    8ffc:      	ldur	x9, [x29, #-0x10]
    9000:      	cmp	x8, x9
    9004:      	b.ne	0x9010 <_ZN13LabDeviceInfo9infoMakerEP7_JNIEnvP7_jclass+0xc3c>
    9008:      	mov	x0, x19
    900c:      	bl	0x19798 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10784>
    9010:      	bl	0x1d4a0 <__stack_chk_fail@plt>

0000000000009014 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz>:
    9014:      	sub	sp, sp, #0x120
    9018:      	stp	x29, x30, [sp, #0x100]
    901c:      	stp	x28, x19, [sp, #0x110]
    9020:      	add	x29, sp, #0x100
    9024:      	stp	x3, x4, [x29, #-0x78]
    9028:      	sub	x9, x29, #0x78
    902c:      	mov	x10, sp
    9030:      	stp	x5, x6, [x29, #-0x68]
    9034:      	add	x10, x10, #0x80
    9038:      	sub	x3, x29, #0x50
    903c:      	stur	x7, [x29, #-0x58]
    9040:      	stp	q0, q1, [sp]
    9044:      	stp	q2, q3, [sp, #0x20]
    9048:      	stp	q4, q5, [sp, #0x40]
    904c:      	stp	q6, q7, [sp, #0x60]
    9050:      	mrs	x19, TPIDR_EL0
    9054:      	ldr	x8, [x19, #0x28]
    9058:      	stur	x8, [x29, #-0x8]
    905c:      	add	x8, x9, #0x28
    9060:      	add	x9, x29, #0x20
    9064:      	stp	x9, x8, [x29, #-0x28]
    9068:      	mov	x8, #-0x28              // =-40
    906c:      	sub	x9, x29, #0x28
    9070:      	movk	x8, #0xff80, lsl #32
    9074:      	stp	x10, x8, [x29, #-0x18]
    9078:      	ldr	x8, [x0]
    907c:      	ldp	q0, q1, [x9]
    9080:      	ldr	x8, [x8, #0xe8]
    9084:      	stp	q0, q1, [x29, #-0x50]
    9088:      	blr	x8
    908c:      	ldr	x8, [x19, #0x28]
    9090:      	ldur	x9, [x29, #-0x8]
    9094:      	cmp	x8, x9
    9098:      	b.ne	0x90ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x98>
    909c:      	ldp	x28, x19, [sp, #0x110]
    90a0:      	ldp	x29, x30, [sp, #0x100]
    90a4:      	add	sp, sp, #0x120
    90a8:      	ret
    90ac:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    90b0:      	sub	sp, sp, #0x120
    90b4:      	stp	x29, x30, [sp, #0x100]
    90b8:      	str	x28, [sp, #0x110]
    90bc:      	add	x29, sp, #0x100
    90c0:      	mov	x8, #-0x38              // =-56
    90c4:      	mov	x9, sp
    90c8:      	sub	x10, x29, #0x78
    90cc:      	movk	x8, #0xff80, lsl #32
    90d0:      	add	x9, x9, #0x80
    90d4:      	stp	x1, x2, [x29, #-0x78]
    90d8:      	stp	x9, x8, [x29, #-0x10]
    90dc:      	add	x8, x10, #0x38
    90e0:      	add	x9, x29, #0x20
    90e4:      	stp	x9, x8, [x29, #-0x20]
    90e8:      	nop
    90ec:      	adr	x0, 0x2b11
    90f0:      	stp	x3, x4, [x29, #-0x68]
    90f4:      	sub	x1, x29, #0x40
    90f8:      	stp	q0, q1, [sp]
    90fc:      	ldp	q0, q1, [x29, #-0x20]
    9100:      	stp	x5, x6, [x29, #-0x58]
    9104:      	stur	x7, [x29, #-0x48]
    9108:      	stp	q2, q3, [sp, #0x20]
    910c:      	stp	q4, q5, [sp, #0x40]
    9110:      	stp	q6, q7, [sp, #0x60]
    9114:      	stp	q0, q1, [x29, #-0x40]
    9118:      	bl	0xe720 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x570c>
    911c:      	bl	0x1d4d0 <abort@plt>
    9120:      	adrp	x8, 0x26000
    9124:      	ldrb	w8, [x8, #0x3d0]
    9128:      	cbz	w8, 0x9150 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13c>
    912c:      	adrp	x8, 0x26000
    9130:      	adrp	x9, 0x26000
    9134:      	mov	w10, w0
    9138:      	ldr	x8, [x8, #0x3e0]
    913c:      	ldr	w9, [x9, #0x424]
    9140:      	add	x8, x8, x10, lsl #6
    9144:      	cmp	w9, w0
    9148:      	csel	x0, x8, xzr, hi
    914c:      	ret
    9150:      	stp	x29, x30, [sp, #-0x10]!
    9154:      	mov	x29, sp
    9158:      	adrp	x1, 0x2000
    915c:      	add	x1, x1, #0xe6a
    9160:      	bl	0x90b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c>
    9164:      	adrp	x8, 0x26000
    9168:      	ldrb	w8, [x8, #0x3d0]
    916c:      	cbz	w8, 0x9198 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x184>
    9170:      	adrp	x9, 0x26000
    9174:      	adrp	x8, 0x26000
    9178:      	mov	w10, #0x98              // =152
    917c:      	ldr	x9, [x9, #0x3f0]
    9180:      	ldr	w8, [x8, #0x42c]
    9184:      	nop
    9188:      	umaddl	x9, w0, w10, x9
    918c:      	cmp	w8, w0
    9190:      	csel	x0, x9, xzr, hi
    9194:      	ret
    9198:      	stp	x29, x30, [sp, #-0x10]!
    919c:      	mov	x29, sp
    91a0:      	adrp	x1, 0x3000
    91a4:      	add	x1, x1, #0xc12
    91a8:      	bl	0x90b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c>
    91ac:      	adrp	x8, 0x26000
    91b0:      	ldrb	w8, [x8, #0x3d0]
    91b4:      	cbz	w8, 0x91c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1b0>
    91b8:      	adrp	x8, 0x26000
    91bc:      	ldr	w0, [x8, #0x424]
    91c0:      	ret
    91c4:      	stp	x29, x30, [sp, #-0x10]!
    91c8:      	mov	x29, sp
    91cc:      	adrp	x1, 0x3000
    91d0:      	add	x1, x1, #0xe4b
    91d4:      	bl	0x90b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c>
    91d8:      	adrp	x8, 0x26000
    91dc:      	ldrb	w8, [x8, #0x3d0]
    91e0:      	cbz	w8, 0x91f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1dc>
    91e4:      	adrp	x8, 0x26000
    91e8:      	ldr	w0, [x8, #0x42c]
    91ec:      	ret
    91f0:      	stp	x29, x30, [sp, #-0x10]!
    91f4:      	mov	x29, sp
    91f8:      	adrp	x1, 0x4000
    91fc:      	add	x1, x1, #0x5b5
    9200:      	bl	0x90b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c>
    9204:      	adrp	x8, 0x26000
    9208:      	ldrb	w8, [x8, #0x3d0]
    920c:      	cbz	w8, 0x921c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x208>
    9210:      	nop
    9214:      	adr	x0, 0x26448
    9218:      	ret
    921c:      	stp	x29, x30, [sp, #-0x10]!
    9220:      	mov	x29, sp
    9224:      	adrp	x1, 0x2000
    9228:      	add	x1, x1, #0xa85
    922c:      	bl	0x90b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c>
    9230:      	adrp	x0, 0x3000
    9234:      	add	x0, x0, #0xa3
    9238:      	ret
    923c:      	sub	sp, sp, #0x160
    9240:      	stp	x29, x30, [sp, #0x110]
    9244:      	str	x28, [sp, #0x120]
    9248:      	stp	x24, x23, [sp, #0x130]
    924c:      	stp	x22, x21, [sp, #0x140]
    9250:      	stp	x20, x19, [sp, #0x150]
    9254:      	add	x29, sp, #0x110
    9258:      	mrs	x24, TPIDR_EL0
    925c:      	mov	x20, x0
    9260:      	mov	x19, x1
    9264:      	ldr	x8, [x24, #0x28]
    9268:      	nop
    926c:      	adr	x3, 0x4292
    9270:      	add	x0, sp, #0x8
    9274:      	mov	w1, #0x100              // =256
    9278:      	mov	w2, #0x100              // =256
    927c:      	mov	x4, x20
    9280:      	stur	x8, [x29, #-0x8]
    9284:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    9288:      	adrp	x21, 0x22000
    928c:      	add	x1, sp, #0x8
    9290:      	ldr	x21, [x21, #0x100]
    9294:      	mov	x0, x21
    9298:      	bl	0x1d4f0 <strstr@plt>
    929c:      	cbnz	x0, 0x9324 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x310>
    92a0:      	mov	x0, x21
    92a4:      	mov	w1, #0x100              // =256
    92a8:      	bl	0x1d500 <__strlen_chk@plt>
    92ac:      	mov	x22, x0
    92b0:      	mov	x0, x20
    92b4:      	bl	0x1d510 <strlen@plt>
    92b8:      	mov	x23, x0
    92bc:      	mov	x0, x19
    92c0:      	bl	0x1d510 <strlen@plt>
    92c4:      	add	x8, x0, x23
    92c8:      	add	x9, x22, x8
    92cc:      	add	x9, x9, #0x2
    92d0:      	cmp	x9, #0x100
    92d4:      	b.lo	0x9304 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2f0>
    92d8:      	mov	w8, #0x100              // =256
    92dc:      	adrp	x3, 0x3000
    92e0:      	add	x3, x3, #0xa31
    92e4:      	sub	x2, x8, x22
    92e8:      	add	x0, x21, x22
    92ec:      	mov	x1, #-0x1               // =-1
    92f0:      	mov	x4, x20
    92f4:      	mov	x5, x19
    92f8:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    92fc:      	strb	wzr, [x21, #0xff]
    9300:      	b	0x9324 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x310>
    9304:      	adrp	x3, 0x3000
    9308:      	add	x3, x3, #0xa31
    930c:      	add	x0, x21, x22
    9310:      	add	x2, x8, #0x3
    9314:      	mov	x1, #-0x1               // =-1
    9318:      	mov	x4, x20
    931c:      	mov	x5, x19
    9320:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    9324:      	ldr	x8, [x24, #0x28]
    9328:      	ldur	x9, [x29, #-0x8]
    932c:      	cmp	x8, x9
    9330:      	b.ne	0x9350 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x33c>
    9334:      	ldp	x20, x19, [sp, #0x150]
    9338:      	ldr	x28, [sp, #0x120]
    933c:      	ldp	x22, x21, [sp, #0x140]
    9340:      	ldp	x24, x23, [sp, #0x130]
    9344:      	ldp	x29, x30, [sp, #0x110]
    9348:      	add	sp, sp, #0x160
    934c:      	ret
    9350:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    9354:      	sub	sp, sp, #0x110
    9358:      	stp	x29, x30, [sp, #0xf0]
    935c:      	stp	x28, x19, [sp, #0x100]
    9360:      	add	x29, sp, #0xf0
    9364:      	stp	x4, x5, [x29, #-0x70]
    9368:      	sub	x10, x29, #0x70
    936c:      	sub	x11, x29, #0x28
    9370:      	stp	x6, x7, [x29, #-0x60]
    9374:      	mov	x8, x3
    9378:      	mov	x3, x1
    937c:      	stp	q0, q1, [sp]
    9380:      	sub	x5, x29, #0x50
    9384:      	mov	x1, x2
    9388:      	stp	q2, q3, [sp, #0x20]
    938c:      	mov	w2, wzr
    9390:      	mov	x4, x8
    9394:      	stp	q4, q5, [sp, #0x40]
    9398:      	stp	q6, q7, [sp, #0x60]
    939c:      	mrs	x19, TPIDR_EL0
    93a0:      	ldr	x9, [x19, #0x28]
    93a4:      	stur	x9, [x29, #-0x8]
    93a8:      	add	x9, x10, #0x20
    93ac:      	add	x10, x29, #0x20
    93b0:      	stp	x10, x9, [x29, #-0x28]
    93b4:      	mov	x9, #-0x20              // =-32
    93b8:      	mov	x10, sp
    93bc:      	movk	x9, #0xff80, lsl #32
    93c0:      	add	x10, x10, #0x80
    93c4:      	stp	x10, x9, [x29, #-0x18]
    93c8:      	ldp	q0, q1, [x11]
    93cc:      	stp	q0, q1, [x29, #-0x50]
    93d0:      	bl	0x1d520 <__vsnprintf_chk@plt>
    93d4:      	ldr	x8, [x19, #0x28]
    93d8:      	ldur	x9, [x29, #-0x8]
    93dc:      	cmp	x8, x9
    93e0:      	b.ne	0x93f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3e0>
    93e4:      	ldp	x28, x19, [sp, #0x100]
    93e8:      	ldp	x29, x30, [sp, #0xf0]
    93ec:      	add	sp, sp, #0x110
    93f0:      	ret
    93f4:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    93f8:      	sub	sp, sp, #0x80
    93fc:      	stp	x29, x30, [sp, #0x50]
    9400:      	str	x21, [sp, #0x60]
    9404:      	stp	x20, x19, [sp, #0x70]
    9408:      	add	x29, sp, #0x50
    940c:      	mrs	x21, TPIDR_EL0
    9410:      	adrp	x20, 0x4000
    9414:      	add	x20, x20, #0x185
    9418:      	ldr	x8, [x21, #0x28]
    941c:      	mov	w4, w1
    9420:      	mov	w19, w0
    9424:      	add	x0, sp, #0x8
    9428:      	mov	w1, #0x20               // =32
    942c:      	mov	w2, #0x20               // =32
    9430:      	mov	x3, x20
    9434:      	stur	x8, [x29, #-0x8]
    9438:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    943c:      	add	x0, sp, #0x28
    9440:      	mov	w1, #0x20               // =32
    9444:      	mov	w2, #0x20               // =32
    9448:      	mov	x3, x20
    944c:      	mov	w4, w19
    9450:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    9454:      	add	x0, sp, #0x28
    9458:      	add	x1, sp, #0x8
    945c:      	bl	0x923c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x228>
    9460:      	ldr	x8, [x21, #0x28]
    9464:      	ldur	x9, [x29, #-0x8]
    9468:      	cmp	x8, x9
    946c:      	b.ne	0x9484 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x470>
    9470:      	ldp	x20, x19, [sp, #0x70]
    9474:      	ldr	x21, [sp, #0x60]
    9478:      	ldp	x29, x30, [sp, #0x50]
    947c:      	add	sp, sp, #0x80
    9480:      	ret
    9484:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    9488:      	mov	w8, #0xff               // =255
    948c:      	movk	w8, #0x60, lsl #16
    9490:      	cmp	w0, w8
    9494:      	b.le	0x94d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4c4>
    9498:      	mov	w8, #0xff               // =255
    949c:      	movk	w8, #0x80, lsl #16
    94a0:      	cmp	w0, w8
    94a4:      	b.gt	0x9634 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x620>
    94a8:      	sub	w8, w0, #0x700, lsl #12 // =0x700000
    94ac:      	sub	w8, w8, #0x100
    94b0:      	cmp	w8, #0x20
    94b4:      	b.hi	0x9660 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x64c>
    94b8:      	nop
    94bc:      	adr	x9, 0x4da3
    94c0:      	adr	x10, 0x94d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4bc>
    94c4:      	ldrb	w11, [x9, x8]
    94c8:      	add	x10, x10, x11, lsl #2
    94cc:      	br	x10
    94d0:      	mov	w0, #0x1a               // =26
    94d4:      	ret
    94d8:      	mov	w8, #0x376              // =886
    94dc:      	movk	w8, #0x30, lsl #16
    94e0:      	cmp	w0, w8
    94e4:      	b.gt	0x9550 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x53c>
    94e8:      	mov	w8, #0x352              // =850
    94ec:      	movk	w8, #0x30, lsl #16
    94f0:      	cmp	w0, w8
    94f4:      	b.gt	0x95b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5a4>
    94f8:      	mov	w8, #0x211              // =529
    94fc:      	movk	w8, #0x30, lsl #16
    9500:      	cmp	w0, w8
    9504:      	b.le	0x9684 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x670>
    9508:      	mov	w8, #0x216              // =534
    950c:      	movk	w8, #0x30, lsl #16
    9510:      	cmp	w0, w8
    9514:      	b.le	0x9844 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x830>
    9518:      	mov	w8, #0x217              // =535
    951c:      	movk	w8, #0x30, lsl #16
    9520:      	cmp	w0, w8
    9524:      	b.eq	0x98fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8e8>
    9528:      	mov	w8, #0x332              // =818
    952c:      	movk	w8, #0x30, lsl #16
    9530:      	cmp	w0, w8
    9534:      	b.eq	0x9904 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8f0>
    9538:      	mov	w8, #0x335              // =821
    953c:      	movk	w8, #0x30, lsl #16
    9540:      	cmp	w0, w8
    9544:      	b.ne	0x9724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x710>
    9548:      	mov	w0, #0xb                // =11
    954c:      	ret
    9550:      	mov	w8, #0x570              // =1392
    9554:      	movk	w8, #0x30, lsl #16
    9558:      	cmp	w0, w8
    955c:      	b.le	0x95f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5dc>
    9560:      	mov	w8, #0xff               // =255
    9564:      	movk	w8, #0x40, lsl #16
    9568:      	cmp	w0, w8
    956c:      	b.le	0x96f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6e0>
    9570:      	mov	w8, #0x101              // =257
    9574:      	movk	w8, #0x40, lsl #16
    9578:      	cmp	w0, w8
    957c:      	b.le	0x989c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x888>
    9580:      	mov	w8, #0x102              // =258
    9584:      	movk	w8, #0x40, lsl #16
    9588:      	cmp	w0, w8
    958c:      	b.eq	0x96ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6d8>
    9590:      	mov	w8, #0x105              // =261
    9594:      	movk	w8, #0x40, lsl #16
    9598:      	cmp	w0, w8
    959c:      	b.eq	0x94d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4bc>
    95a0:      	mov	w8, #0x106              // =262
    95a4:      	movk	w8, #0x40, lsl #16
    95a8:      	cmp	w0, w8
    95ac:      	b.ne	0x9724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x710>
    95b0:      	mov	w0, #0x1b               // =27
    95b4:      	ret
    95b8:      	mov	w8, #0x371              // =881
    95bc:      	movk	w8, #0x30, lsl #16
    95c0:      	cmp	w0, w8
    95c4:      	b.gt	0x96bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6a8>
    95c8:      	mov	w8, #0x356              // =854
    95cc:      	movk	w8, #0x30, lsl #16
    95d0:      	cmp	w0, w8
    95d4:      	b.gt	0x986c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x858>
    95d8:      	sub	w8, w0, #0x300, lsl #12 // =0x300000
    95dc:      	sub	w8, w8, #0x354
    95e0:      	cmp	w8, #0x2
    95e4:      	b.hs	0x98dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c8>
    95e8:      	mov	w0, #0xd                // =13
    95ec:      	ret
    95f0:      	mov	w8, #0x502              // =1282
    95f4:      	movk	w8, #0x30, lsl #16
    95f8:      	cmp	w0, w8
    95fc:      	b.gt	0x972c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x718>
    9600:      	mov	w8, #0x500              // =1280
    9604:      	movk	w8, #0x30, lsl #16
    9608:      	cmp	w0, w8
    960c:      	b.gt	0x97f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7dc>
    9610:      	mov	w8, #0x377              // =887
    9614:      	movk	w8, #0x30, lsl #16
    9618:      	cmp	w0, w8
    961c:      	b.eq	0x9770 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x75c>
    9620:      	mov	w8, #0x378              // =888
    9624:      	movk	w8, #0x30, lsl #16
    9628:      	cmp	w0, w8
    962c:      	b.eq	0x9760 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x74c>
    9630:      	b	0x9724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x710>
    9634:      	sub	w8, w0, #0xc00, lsl #12 // =0xc00000
    9638:      	sub	w8, w8, #0x100
    963c:      	cmp	w8, #0x3
    9640:      	b.lo	0x9810 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7fc>
    9644:      	mov	w8, #0x100              // =256
    9648:      	movk	w8, #0x80, lsl #16
    964c:      	cmp	w0, w8
    9650:      	b.eq	0x9818 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x804>
    9654:      	mov	w8, #0x200              // =512
    9658:      	movk	w8, #0x80, lsl #16
    965c:      	b	0x971c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x708>
    9660:      	sub	w8, w0, #0x600, lsl #12 // =0x600000
    9664:      	sub	w8, w8, #0x100
    9668:      	cmp	w8, #0x3
    966c:      	b.lo	0x9768 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x754>
    9670:      	sub	w8, w0, #0x600, lsl #12 // =0x600000
    9674:      	sub	w8, w8, #0x103
    9678:      	cmp	w8, #0x2
    967c:      	b.lo	0x96ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6d8>
    9680:      	b	0x9724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x710>
    9684:      	mov	w8, #0x207              // =519
    9688:      	movk	w8, #0x30, lsl #16
    968c:      	cmp	w0, w8
    9690:      	b.gt	0x9780 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76c>
    9694:      	mov	w8, #0x205              // =517
    9698:      	movk	w8, #0x30, lsl #16
    969c:      	cmp	w0, w8
    96a0:      	b.eq	0x98f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8e0>
    96a4:      	mov	w8, #0x207              // =519
    96a8:      	movk	w8, #0x30, lsl #16
    96ac:      	cmp	w0, w8
    96b0:      	b.ne	0x9724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x710>
    96b4:      	mov	w0, #0x2                // =2
    96b8:      	ret
    96bc:      	mov	w8, #0x374              // =884
    96c0:      	movk	w8, #0x30, lsl #16
    96c4:      	cmp	w0, w8
    96c8:      	b.gt	0x979c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x788>
    96cc:      	mov	w8, #0x372              // =882
    96d0:      	movk	w8, #0x30, lsl #16
    96d4:      	cmp	w0, w8
    96d8:      	b.eq	0x9768 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x754>
    96dc:      	mov	w8, #0x373              // =883
    96e0:      	movk	w8, #0x30, lsl #16
    96e4:      	cmp	w0, w8
    96e8:      	b.ne	0x9724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x710>
    96ec:      	mov	w0, #0x11               // =17
    96f0:      	ret
    96f4:      	mov	w8, #0x572              // =1394
    96f8:      	movk	w8, #0x30, lsl #16
    96fc:      	cmp	w0, w8
    9700:      	b.gt	0x97c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7b0>
    9704:      	mov	w8, #0x571              // =1393
    9708:      	movk	w8, #0x30, lsl #16
    970c:      	cmp	w0, w8
    9710:      	b.eq	0x9760 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x74c>
    9714:      	mov	w8, #0x572              // =1394
    9718:      	movk	w8, #0x30, lsl #16
    971c:      	cmp	w0, w8
    9720:      	b.eq	0x9818 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x804>
    9724:      	mov	w0, #-0x1               // =-1
    9728:      	ret
    972c:      	mov	w8, #0x504              // =1284
    9730:      	movk	w8, #0x30, lsl #16
    9734:      	cmp	w0, w8
    9738:      	b.gt	0x9820 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x80c>
    973c:      	mov	w8, #0x503              // =1283
    9740:      	movk	w8, #0x30, lsl #16
    9744:      	cmp	w0, w8
    9748:      	b.eq	0x9778 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x764>
    974c:      	mov	w8, #0x504              // =1284
    9750:      	movk	w8, #0x30, lsl #16
    9754:      	cmp	w0, w8
    9758:      	b.eq	0x97e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7d4>
    975c:      	b	0x9724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x710>
    9760:      	mov	w0, #0x15               // =21
    9764:      	ret
    9768:      	mov	w0, #0x10               // =16
    976c:      	ret
    9770:      	mov	w0, #0x14               // =20
    9774:      	ret
    9778:      	mov	w0, #0x18               // =24
    977c:      	ret
    9780:      	mov	w8, #0x208              // =520
    9784:      	movk	w8, #0x30, lsl #16
    9788:      	cmp	w0, w8
    978c:      	b.eq	0x98d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c0>
    9790:      	mov	w8, #0x209              // =521
    9794:      	movk	w8, #0x30, lsl #16
    9798:      	b	0x98b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8a0>
    979c:      	mov	w8, #0x375              // =885
    97a0:      	movk	w8, #0x30, lsl #16
    97a4:      	cmp	w0, w8
    97a8:      	b.eq	0x98cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8b8>
    97ac:      	mov	w8, #0x376              // =886
    97b0:      	movk	w8, #0x30, lsl #16
    97b4:      	cmp	w0, w8
    97b8:      	b.ne	0x9724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x710>
    97bc:      	mov	w0, #0x13               // =19
    97c0:      	ret
    97c4:      	mov	w8, #0x573              // =1395
    97c8:      	movk	w8, #0x30, lsl #16
    97cc:      	cmp	w0, w8
    97d0:      	b.eq	0x97e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7d4>
    97d4:      	mov	w8, #0x574              // =1396
    97d8:      	movk	w8, #0x30, lsl #16
    97dc:      	cmp	w0, w8
    97e0:      	b.eq	0x94d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4bc>
    97e4:      	b	0x9724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x710>
    97e8:      	mov	w0, #0x19               // =25
    97ec:      	ret
    97f0:      	mov	w8, #0x501              // =1281
    97f4:      	movk	w8, #0x30, lsl #16
    97f8:      	cmp	w0, w8
    97fc:      	b.eq	0x9818 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x804>
    9800:      	mov	w8, #0x502              // =1282
    9804:      	movk	w8, #0x30, lsl #16
    9808:      	cmp	w0, w8
    980c:      	b.ne	0x9724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x710>
    9810:      	mov	w0, #0x17               // =23
    9814:      	ret
    9818:      	mov	w0, #0x16               // =22
    981c:      	ret
    9820:      	mov	w8, #0x505              // =1285
    9824:      	movk	w8, #0x30, lsl #16
    9828:      	cmp	w0, w8
    982c:      	b.eq	0x94d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4bc>
    9830:      	mov	w8, #0x551              // =1361
    9834:      	movk	w8, #0x30, lsl #16
    9838:      	cmp	w0, w8
    983c:      	b.eq	0x9894 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x880>
    9840:      	b	0x9724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x710>
    9844:      	mov	w8, #0x212              // =530
    9848:      	movk	w8, #0x30, lsl #16
    984c:      	cmp	w0, w8
    9850:      	b.eq	0x990c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8f8>
    9854:      	mov	w8, #0x215              // =533
    9858:      	movk	w8, #0x30, lsl #16
    985c:      	cmp	w0, w8
    9860:      	b.ne	0x9724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x710>
    9864:      	mov	w0, #0x6                // =6
    9868:      	ret
    986c:      	mov	w8, #0x357              // =855
    9870:      	movk	w8, #0x30, lsl #16
    9874:      	cmp	w0, w8
    9878:      	b.eq	0x9894 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x880>
    987c:      	mov	w8, #0x365              // =869
    9880:      	movk	w8, #0x30, lsl #16
    9884:      	cmp	w0, w8
    9888:      	b.ne	0x9724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x710>
    988c:      	mov	w0, #0xf                // =15
    9890:      	ret
    9894:      	mov	w0, #0xe                // =14
    9898:      	ret
    989c:      	mov	w8, #0x100              // =256
    98a0:      	movk	w8, #0x40, lsl #16
    98a4:      	cmp	w0, w8
    98a8:      	b.eq	0x98d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c0>
    98ac:      	mov	w8, #0x101              // =257
    98b0:      	movk	w8, #0x40, lsl #16
    98b4:      	cmp	w0, w8
    98b8:      	b.ne	0x9724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x710>
    98bc:      	mov	w0, #0x4                // =4
    98c0:      	ret
    98c4:      	mov	w0, #0x1c               // =28
    98c8:      	ret
    98cc:      	mov	w0, #0x12               // =18
    98d0:      	ret
    98d4:      	mov	w0, #0x3                // =3
    98d8:      	ret
    98dc:      	mov	w8, #0x353              // =851
    98e0:      	movk	w8, #0x30, lsl #16
    98e4:      	cmp	w0, w8
    98e8:      	b.ne	0x9724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x710>
    98ec:      	mov	w0, #0xc                // =12
    98f0:      	ret
    98f4:      	mov	w0, #0x1                // =1
    98f8:      	ret
    98fc:      	mov	w0, #0x7                // =7
    9900:      	ret
    9904:      	mov	w0, #0x8                // =8
    9908:      	ret
    990c:      	mov	w0, #0x5                // =5
    9910:      	ret
    9914:      	cmp	w0, #0x12
    9918:      	b.gt	0x9970 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x95c>
    991c:      	cmp	w0, #0x10
    9920:      	b.eq	0x99b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x99c>
    9924:      	cmp	w0, #0x11
    9928:      	b.eq	0x9a3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa28>
    992c:      	cmp	w0, #0x12
    9930:      	b.ne	0x9a24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa10>
    9934:      	mov	w8, #0x91c0             // =37312
    9938:      	mov	w0, #-0x1               // =-1
    993c:      	movk	w8, #0x21, lsl #16
    9940:      	cmp	w1, w8
    9944:      	b.eq	0x9bc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb0>
    9948:      	mov	w8, #0xb100             // =45312
    994c:      	movk	w8, #0x21, lsl #16
    9950:      	cmp	w1, w8
    9954:      	b.eq	0x9bc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb0>
    9958:      	mov	w8, #0x8480             // =33920
    995c:      	movk	w8, #0x1e, lsl #16
    9960:      	cmp	w1, w8
    9964:      	mov	w8, #-0x2               // =-2
    9968:      	csel	w0, w8, wzr, lo
    996c:      	ret
    9970:      	cmp	w0, #0x13
    9974:      	b.eq	0x99ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d8>
    9978:      	cmp	w0, #0x14
    997c:      	b.eq	0x9a84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa70>
    9980:      	cmp	w0, #0x16
    9984:      	b.ne	0x9a24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa10>
    9988:      	mov	w8, #0xc6c0             // =50880
    998c:      	movk	w8, #0x2d, lsl #16
    9990:      	cmp	w1, w8
    9994:      	csetm	w8, lo
    9998:      	mov	w9, #0xc6c0             // =50880
    999c:      	movk	w9, #0x2d, lsl #16
    99a0:      	cmp	w1, w9
    99a4:      	b.ls	0x9a98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa84>
    99a8:      	mov	w0, #0x1                // =1
    99ac:      	ret
    99b0:      	mov	w8, #0x4f10             // =20240
    99b4:      	mov	w0, #-0x1               // =-1
    99b8:      	movk	w8, #0x23, lsl #16
    99bc:      	cmp	w1, w8
    99c0:      	b.eq	0x9bc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb0>
    99c4:      	mov	w8, #0x2290             // =8848
    99c8:      	movk	w8, #0x20, lsl #16
    99cc:      	cmp	w1, w8
    99d0:      	b.eq	0x9bc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb0>
    99d4:      	mov	w8, #0x3998             // =14744
    99d8:      	movk	w8, #0x15, lsl #16
    99dc:      	cmp	w1, w8
    99e0:      	b.eq	0x9b28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb14>
    99e4:      	mov	w0, wzr
    99e8:      	ret
    99ec:      	mov	w8, #0xc5ff             // =50687
    99f0:      	movk	w8, #0x2a, lsl #16
    99f4:      	cmp	w1, w8
    99f8:      	b.gt	0x9aac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa98>
    99fc:      	mov	w8, #0xc300             // =49920
    9a00:      	movk	w8, #0x1e, lsl #16
    9a04:      	cmp	w1, w8
    9a08:      	b.eq	0x9b28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb14>
    9a0c:      	mov	w8, #0xbaa0             // =47776
    9a10:      	movk	w8, #0x22, lsl #16
    9a14:      	cmp	w1, w8
    9a18:      	b.ne	0x9acc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xab8>
    9a1c:      	mov	w0, #-0x6               // =-6
    9a20:      	ret
    9a24:      	mov	w8, #0xbb00             // =47872
    9a28:      	movk	w8, #0x17, lsl #16
    9a2c:      	cmp	w1, w8
    9a30:      	b.ne	0x9ae0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xacc>
    9a34:      	mov	w0, #-0x2               // =-2
    9a38:      	ret
    9a3c:      	mov	w8, #0xb0ff             // =45311
    9a40:      	mov	w0, #-0x1               // =-1
    9a44:      	movk	w8, #0x21, lsl #16
    9a48:      	cmp	w1, w8
    9a4c:      	b.le	0x9b30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb1c>
    9a50:      	mov	w8, #0xb100             // =45312
    9a54:      	movk	w8, #0x21, lsl #16
    9a58:      	cmp	w1, w8
    9a5c:      	b.eq	0x9bc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb0>
    9a60:      	mov	w8, #0xa90              // =2704
    9a64:      	movk	w8, #0x24, lsl #16
    9a68:      	cmp	w1, w8
    9a6c:      	b.eq	0x9bc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb0>
    9a70:      	mov	w8, #0xac40             // =44096
    9a74:      	movk	w8, #0x27, lsl #16
    9a78:      	cmp	w1, w8
    9a7c:      	b.eq	0x9bc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb0>
    9a80:      	b	0x9b58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb44>
    9a84:      	mov	w8, wzr
    9a88:      	mov	w9, #0xc6c0             // =50880
    9a8c:      	movk	w9, #0x2d, lsl #16
    9a90:      	cmp	w1, w9
    9a94:      	b.hi	0x99a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x994>
    9a98:      	mov	w9, #0xb8d0             // =47312
    9a9c:      	movk	w9, #0x21, lsl #16
    9aa0:      	cmp	w1, w9
    9aa4:      	csinv	w0, w8, wzr, ne
    9aa8:      	ret
    9aac:      	mov	w8, #0xc600             // =50688
    9ab0:      	movk	w8, #0x2a, lsl #16
    9ab4:      	cmp	w1, w8
    9ab8:      	b.eq	0x9bbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba8>
    9abc:      	mov	w8, #0x1e00             // =7680
    9ac0:      	movk	w8, #0x2d, lsl #16
    9ac4:      	cmp	w1, w8
    9ac8:      	b.eq	0x9bbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba8>
    9acc:      	mov	w8, #0xac40             // =44096
    9ad0:      	movk	w8, #0x27, lsl #16
    9ad4:      	cmp	w1, w8
    9ad8:      	csetm	w0, lo
    9adc:      	ret
    9ae0:      	lsr	w8, w1, #9
    9ae4:      	cmp	w8, #0xc35
    9ae8:      	b.lo	0x9bbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba8>
    9aec:      	mov	w8, #0x8867             // =34919
    9af0:      	mov	w0, wzr
    9af4:      	movk	w8, #0x1e, lsl #16
    9af8:      	cmp	w1, w8
    9afc:      	b.le	0x9b70 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb5c>
    9b00:      	mov	w8, #0xedaf             // =60847
    9b04:      	movk	w8, #0x20, lsl #16
    9b08:      	cmp	w1, w8
    9b0c:      	b.gt	0x9b9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb88>
    9b10:      	mov	w8, #0x8868             // =34920
    9b14:      	movk	w8, #0x1e, lsl #16
    9b18:      	cmp	w1, w8
    9b1c:      	b.eq	0x9bbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba8>
    9b20:      	mov	w8, #0xce70             // =52848
    9b24:      	b	0x9bb0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb9c>
    9b28:      	mov	w0, #-0x3               // =-3
    9b2c:      	ret
    9b30:      	mov	w8, #0x8a00             // =35328
    9b34:      	movk	w8, #0x1b, lsl #16
    9b38:      	cmp	w1, w8
    9b3c:      	b.eq	0x9bc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb0>
    9b40:      	mov	w8, #0x26c0             // =9920
    9b44:      	movk	w8, #0x1e, lsl #16
    9b48:      	cmp	w1, w8
    9b4c:      	b.ne	0x9b58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb44>
    9b50:      	mov	w0, #-0x2               // =-2
    9b54:      	ret
    9b58:      	mov	w8, #0x8480             // =33920
    9b5c:      	movk	w8, #0x1e, lsl #16
    9b60:      	cmp	w1, w8
    9b64:      	mov	w8, #-0x4               // =-4
    9b68:      	csel	w0, w8, wzr, lo
    9b6c:      	ret
    9b70:      	mov	w8, #0x9298             // =37528
    9b74:      	movk	w8, #0x1b, lsl #16
    9b78:      	cmp	w1, w8
    9b7c:      	b.eq	0x9bbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba8>
    9b80:      	mov	w8, #0xc130             // =49456
    9b84:      	movk	w8, #0x1d, lsl #16
    9b88:      	cmp	w1, w8
    9b8c:      	b.eq	0x9bbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba8>
    9b90:      	mov	w8, #0x5988             // =22920
    9b94:      	movk	w8, #0x1e, lsl #16
    9b98:      	b	0x9bb4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba0>
    9b9c:      	mov	w8, #0xb4a0             // =46240
    9ba0:      	movk	w8, #0x23, lsl #16
    9ba4:      	cmp	w1, w8
    9ba8:      	b.eq	0x9bbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba8>
    9bac:      	mov	w8, #0xedb0             // =60848
    9bb0:      	movk	w8, #0x20, lsl #16
    9bb4:      	cmp	w1, w8
    9bb8:      	b.ne	0x9bc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb0>
    9bbc:      	mov	w0, #-0x1               // =-1
    9bc0:      	ret
    9bc4:      	ret
    9bc8:      	sub	sp, sp, #0x110
    9bcc:      	stp	x29, x30, [sp, #0xc0]
    9bd0:      	stp	x28, x25, [sp, #0xd0]
    9bd4:      	stp	x24, x23, [sp, #0xe0]
    9bd8:      	stp	x22, x21, [sp, #0xf0]
    9bdc:      	stp	x20, x19, [sp, #0x100]
    9be0:      	add	x29, sp, #0xc0
    9be4:      	mrs	x23, TPIDR_EL0
    9be8:      	mov	x21, x3
    9bec:      	mov	x22, x2
    9bf0:      	ldr	x8, [x23, #0x28]
    9bf4:      	mov	x19, x1
    9bf8:      	mov	x20, x0
    9bfc:      	stur	x8, [x29, #-0x8]
    9c00:      	cbz	x2, 0x9c34 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc20>
    9c04:      	adrp	x1, 0x3000
    9c08:      	add	x1, x1, #0xced
    9c0c:      	mov	x0, x22
    9c10:      	bl	0x1d4f0 <strstr@plt>
    9c14:      	cbnz	x0, 0x9c2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc18>
    9c18:      	adrp	x1, 0x3000
    9c1c:      	add	x1, x1, #0x3cd
    9c20:      	mov	x0, x22
    9c24:      	bl	0x1d4f0 <strstr@plt>
    9c28:      	cbz	x0, 0x9d64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd50>
    9c2c:      	mov	w24, #0x1               // =1
    9c30:      	b	0x9c38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc24>
    9c34:      	mov	w24, wzr
    9c38:      	adrp	x0, 0x4000
    9c3c:      	add	x0, x0, #0xa48
    9c40:      	mov	x1, x22
    9c44:      	mov	w2, wzr
    9c48:      	bl	0x1d560 <printf@plt>
    9c4c:      	cbz	x20, 0x9f88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf74>
    9c50:      	adrp	x1, 0x4000
    9c54:      	add	x1, x1, #0x188
    9c58:      	mov	x0, sp
    9c5c:      	mov	w2, #0x1                // =1
    9c60:      	stur	xzr, [x29, #-0x10]
    9c64:      	bl	0x1d570 <regcomp@plt>
    9c68:      	cbz	w0, 0x9c9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc88>
    9c6c:      	mov	x1, sp
    9c70:      	add	x2, sp, #0x30
    9c74:      	mov	w3, #0x80               // =128
    9c78:      	bl	0x1d580 <regerror@plt>
    9c7c:      	adrp	x8, 0x22000
    9c80:      	adrp	x1, 0x3000
    9c84:      	add	x1, x1, #0x8a7
    9c88:      	ldr	x8, [x8, #0x108]
    9c8c:      	adrp	x3, 0x4000
    9c90:      	add	x3, x3, #0x188
    9c94:      	add	x2, sp, #0x30
    9c98:      	b	0x9ce0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xccc>
    9c9c:      	mov	x0, sp
    9ca0:      	add	x3, sp, #0x20
    9ca4:      	mov	x1, x20
    9ca8:      	mov	w2, #0x1                // =1
    9cac:      	mov	w4, wzr
    9cb0:      	bl	0x1d590 <regexec@plt>
    9cb4:      	cbz	w0, 0x9d98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd84>
    9cb8:      	mov	x1, sp
    9cbc:      	add	x2, sp, #0x30
    9cc0:      	mov	w3, #0x80               // =128
    9cc4:      	bl	0x1d580 <regerror@plt>
    9cc8:      	adrp	x8, 0x22000
    9ccc:      	adrp	x1, 0x2000
    9cd0:      	add	x1, x1, #0xfd4
    9cd4:      	ldr	x8, [x8, #0x108]
    9cd8:      	add	x2, sp, #0x30
    9cdc:      	mov	x3, x20
    9ce0:      	add	x0, x8, #0x130
    9ce4:      	bl	0x1d5a0 <fprintf@plt>
    9ce8:      	mov	w22, #-0x1              // =-1
    9cec:      	adrp	x1, 0x3000
    9cf0:      	add	x1, x1, #0x6a1
    9cf4:      	mov	x0, x20
    9cf8:      	bl	0x1d4f0 <strstr@plt>
    9cfc:      	cbz	x0, 0x9e48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe34>
    9d00:      	cmp	w22, #0x14a
    9d04:      	b.lo	0x9e68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe54>
    9d08:      	cmp	w22, #0x190
    9d0c:      	b.hs	0x9d18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd04>
    9d10:      	mov	w20, #0x4               // =4
    9d14:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    9d18:      	cmp	w22, #0x19a
    9d1c:      	b.lo	0x9e68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe54>
    9d20:      	cmp	w22, #0x1ae
    9d24:      	b.lo	0x9ef8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xee4>
    9d28:      	cmp	w22, #0x1f4
    9d2c:      	b.lo	0x9d10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcfc>
    9d30:      	cmp	w22, #0x1fa
    9d34:      	b.lo	0x9e68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe54>
    9d38:      	cmp	w22, #0x212
    9d3c:      	b.lo	0x9f24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf10>
    9d40:      	cmp	w22, #0x21b
    9d44:      	b.hi	0xa050 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x103c>
    9d48:      	cbz	x19, 0x9d10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcfc>
    9d4c:      	adrp	x1, 0x3000
    9d50:      	add	x1, x1, #0x6a8
    9d54:      	mov	x0, x19
    9d58:      	bl	0x1d4f0 <strstr@plt>
    9d5c:      	cbnz	x0, 0xa058 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1044>
    9d60:      	b	0x9d10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcfc>
    9d64:      	adrp	x1, 0x2000
    9d68:      	add	x1, x1, #0xb45
    9d6c:      	mov	x0, x22
    9d70:      	bl	0x1d4f0 <strstr@plt>
    9d74:      	mov	w24, #0x2               // =2
    9d78:      	cbnz	x0, 0x9c38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc24>
    9d7c:      	adrp	x1, 0x3000
    9d80:      	add	x1, x1, #0x718
    9d84:      	mov	x0, x22
    9d88:      	bl	0x1d4f0 <strstr@plt>
    9d8c:      	cmp	x0, #0x0
    9d90:      	cinc	w24, w24, eq
    9d94:      	b	0x9c38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc24>
    9d98:      	ldrsw	x25, [sp, #0x20]
    9d9c:      	ldr	x8, [sp, #0x28]
    9da0:      	cmp	x8, x25
    9da4:      	b.le	0x9df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xde4>
    9da8:      	adrp	x22, 0x2000
    9dac:      	add	x22, x22, #0xfe6
    9db0:      	ldrb	w4, [x20, x25]
    9db4:      	sub	x0, x29, #0x10
    9db8:      	sub	x3, x29, #0x10
    9dbc:      	mov	w1, #0x8                // =8
    9dc0:      	mov	x2, x22
    9dc4:      	bl	0xc9b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x39a0>
    9dc8:      	ldr	x8, [sp, #0x28]
    9dcc:      	add	x25, x25, #0x1
    9dd0:      	cmp	x8, x25
    9dd4:      	b.gt	0x9db0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd9c>
    9dd8:      	ldurb	w9, [x29, #-0x10]
    9ddc:      	sub	x10, x29, #0x10
    9de0:      	cmp	w9, #0x2d
    9de4:      	b.eq	0x9e04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdf0>
    9de8:      	mov	w8, #0x1                // =1
    9dec:      	cmp	w9, #0x2b
    9df0:      	b.eq	0x9e08 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdf4>
    9df4:      	b	0x9e10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdfc>
    9df8:      	mov	w11, wzr
    9dfc:      	mov	w8, #0x1                // =1
    9e00:      	b	0x9e30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe1c>
    9e04:      	mov	w8, #-0x1               // =-1
    9e08:      	ldurb	w9, [x29, #-0xf]
    9e0c:      	orr	x10, x10, #0x1
    9e10:      	mov	w11, wzr
    9e14:      	cbz	w9, 0x9e30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe1c>
    9e18:      	add	x10, x10, #0x1
    9e1c:      	mov	w12, #0xa               // =10
    9e20:      	madd	w11, w11, w12, w9
    9e24:      	ldrb	w9, [x10], #0x1
    9e28:      	sub	w11, w11, #0x30
    9e2c:      	cbnz	w9, 0x9e20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe0c>
    9e30:      	mul	w22, w11, w8
    9e34:      	adrp	x1, 0x3000
    9e38:      	add	x1, x1, #0x6a1
    9e3c:      	mov	x0, x20
    9e40:      	bl	0x1d4f0 <strstr@plt>
    9e44:      	cbnz	x0, 0x9d00 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcec>
    9e48:      	adrp	x1, 0x3000
    9e4c:      	add	x1, x1, #0x4d0
    9e50:      	mov	x0, x20
    9e54:      	bl	0x1d4f0 <strstr@plt>
    9e58:      	cbz	x0, 0x9e74 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe60>
    9e5c:      	sub	w8, w22, #0x258
    9e60:      	cmp	w8, #0xa0
    9e64:      	b.hs	0x9ea4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe90>
    9e68:      	mov	w20, #0x1               // =1
    9e6c:      	add	w0, w20, w24
    9e70:      	b	0x9f8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf78>
    9e74:      	adrp	x1, 0x4000
    9e78:      	add	x1, x1, #0xa53
    9e7c:      	mov	x0, x20
    9e80:      	bl	0x1d4f0 <strstr@plt>
    9e84:      	cbz	x0, 0x9f00 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xeec>
    9e88:      	adrp	x1, 0x3000
    9e8c:      	add	x1, x1, #0xac6
    9e90:      	mov	x0, x20
    9e94:      	bl	0x1d4f0 <strstr@plt>
    9e98:      	cbz	x0, 0x9f2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf18>
    9e9c:      	mov	w20, #0x18              // =24
    9ea0:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    9ea4:      	sub	w8, w22, #0x2f8
    9ea8:      	cmp	w8, #0x27
    9eac:      	b.hi	0x9ee0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecc>
    9eb0:      	cbz	x19, 0x9ef8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xee4>
    9eb4:      	adrp	x1, 0x4000
    9eb8:      	add	x1, x1, #0x5c4
    9ebc:      	mov	x0, x19
    9ec0:      	bl	0x1d4f0 <strstr@plt>
    9ec4:      	cbz	x0, 0x9ef8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xee4>
    9ec8:      	adrp	x1, 0x3000
    9ecc:      	add	x1, x1, #0xfc6
    9ed0:      	mov	x0, x19
    9ed4:      	bl	0x1d4f0 <strstr@plt>
    9ed8:      	cbnz	x0, 0x9d10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcfc>
    9edc:      	b	0x9ef8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xee4>
    9ee0:      	sub	w8, w22, #0x320
    9ee4:      	cmp	w8, #0x3c
    9ee8:      	b.lo	0x9f24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf10>
    9eec:      	sub	w8, w22, #0x35c
    9ef0:      	cmp	w8, #0x14
    9ef4:      	b.hs	0x9f80 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf6c>
    9ef8:      	mov	w20, #0x3               // =3
    9efc:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    9f00:      	adrp	x1, 0x4000
    9f04:      	add	x1, x1, #0xb6d
    9f08:      	mov	x0, x20
    9f0c:      	bl	0x1d4f0 <strstr@plt>
    9f10:      	cbz	x0, 0x9f58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf44>
    9f14:      	cmp	w22, #0xc8
    9f18:      	b.lo	0x9e68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe54>
    9f1c:      	cmp	w22, #0x258
    9f20:      	b.hs	0x9f88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf74>
    9f24:      	mov	w20, #0x2               // =2
    9f28:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    9f2c:      	cmp	w22, #0x34
    9f30:      	b.lo	0x9e68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe54>
    9f34:      	cmp	w22, #0x38
    9f38:      	b.hi	0x9fb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfa4>
    9f3c:      	cbz	x19, 0x9d10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcfc>
    9f40:      	adrp	x1, 0x3000
    9f44:      	add	x1, x1, #0xfcb
    9f48:      	mov	x0, x19
    9f4c:      	bl	0x1d4f0 <strstr@plt>
    9f50:      	cbnz	x0, 0xa058 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1044>
    9f54:      	b	0x9d10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcfc>
    9f58:      	adrp	x1, 0x4000
    9f5c:      	add	x1, x1, #0x83f
    9f60:      	mov	x0, x20
    9f64:      	bl	0x1d4f0 <strstr@plt>
    9f68:      	cbz	x0, 0xa008 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xff4>
    9f6c:      	mov	w8, #0x24e6             // =9446
    9f70:      	cmp	w22, w8
    9f74:      	mov	w8, #0x1                // =1
    9f78:      	cinc	w20, w8, eq
    9f7c:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    9f80:      	cmp	w22, #0x36f
    9f84:      	b.hi	0x9d10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcfc>
    9f88:      	mov	w0, wzr
    9f8c:      	ldr	x8, [x23, #0x28]
    9f90:      	ldur	x9, [x29, #-0x8]
    9f94:      	cmp	x8, x9
    9f98:      	b.ne	0xa414 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1400>
    9f9c:      	ldp	x20, x19, [sp, #0x100]
    9fa0:      	ldp	x22, x21, [sp, #0xf0]
    9fa4:      	ldp	x24, x23, [sp, #0xe0]
    9fa8:      	ldp	x28, x25, [sp, #0xd0]
    9fac:      	ldp	x29, x30, [sp, #0xc0]
    9fb0:      	add	sp, sp, #0x110
    9fb4:      	ret
    9fb8:      	cmp	w22, #0x47
    9fbc:      	b.lo	0xa058 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1044>
    9fc0:      	cmp	w22, #0x4b
    9fc4:      	b.le	0xa060 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x104c>
    9fc8:      	cmp	w22, #0x4c
    9fcc:      	b.eq	0xa118 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1104>
    9fd0:      	cmp	w22, #0x4d
    9fd4:      	b.eq	0xa188 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1174>
    9fd8:      	cmp	w22, #0x4e
    9fdc:      	b.ne	0xa2a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x128c>
    9fe0:      	mov	w20, #0xa               // =10
    9fe4:      	cbz	x19, 0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    9fe8:      	adrp	x1, 0x3000
    9fec:      	add	x1, x1, #0xfcb
    9ff0:      	mov	x0, x19
    9ff4:      	bl	0x1d4f0 <strstr@plt>
    9ff8:      	mov	w8, #0xe                // =14
    9ffc:      	cmp	x0, #0x0
    a000:      	csel	w20, w20, w8, eq
    a004:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a008:      	adrp	x1, 0x3000
    a00c:      	add	x1, x1, #0xd02
    a010:      	mov	x0, x20
    a014:      	bl	0x1d4f0 <strstr@plt>
    a018:      	cbnz	x0, 0x9e68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe54>
    a01c:      	adrp	x1, 0x4000
    a020:      	add	x1, x1, #0x495
    a024:      	mov	x0, x20
    a028:      	bl	0x1d4f0 <strstr@plt>
    a02c:      	cbz	x0, 0xa0f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10dc>
    a030:      	adrp	x1, 0x3000
    a034:      	add	x1, x1, #0xe57
    a038:      	mov	x0, x20
    a03c:      	bl	0x1d4f0 <strstr@plt>
    a040:      	mov	w8, #0x1                // =1
    a044:      	cmp	x0, #0x0
    a048:      	cinc	w20, w8, ne
    a04c:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a050:      	cmp	w22, #0x258
    a054:      	b.hs	0xa08c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1078>
    a058:      	mov	w20, #0x5               // =5
    a05c:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a060:      	cmp	w22, #0x47
    a064:      	b.eq	0xa24c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1238>
    a068:      	cmp	w22, #0x48
    a06c:      	b.ne	0xa2a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x128c>
    a070:      	cbz	x19, 0xa058 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1044>
    a074:      	adrp	x1, 0x3000
    a078:      	add	x1, x1, #0xfcb
    a07c:      	mov	x0, x19
    a080:      	bl	0x1d4f0 <strstr@plt>
    a084:      	cbnz	x0, 0xa180 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x116c>
    a088:      	b	0xa058 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1044>
    a08c:      	cmp	w22, #0x262
    a090:      	b.lo	0x9f24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf10>
    a094:      	cmp	w22, #0x26c
    a098:      	b.lo	0x9ef8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xee4>
    a09c:      	cmp	w22, #0x276
    a0a0:      	b.lo	0x9d10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcfc>
    a0a4:      	cmp	w22, #0x280
    a0a8:      	b.lo	0xa058 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1044>
    a0ac:      	cmp	w22, #0x28a
    a0b0:      	b.lo	0xa180 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x116c>
    a0b4:      	cmp	w22, #0x294
    a0b8:      	b.lo	0xa388 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1374>
    a0bc:      	cmp	w22, #0x2a8
    a0c0:      	b.lo	0xa2f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e0>
    a0c4:      	cmp	w22, #0x2d9
    a0c8:      	b.hi	0xa3fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13e8>
    a0cc:      	adrp	x1, 0x2000
    a0d0:      	add	x1, x1, #0xc85
    a0d4:      	mov	x0, x19
    a0d8:      	bl	0x1d4f0 <strstr@plt>
    a0dc:      	cbnz	x0, 0xa2c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12b0>
    a0e0:      	cmp	w22, #0x2c6
    a0e4:      	mov	w8, #0xe                // =14
    a0e8:      	mov	w9, #0x8                // =8
    a0ec:      	b	0xa3cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13b8>
    a0f0:      	adrp	x1, 0x3000
    a0f4:      	add	x1, x1, #0xd13
    a0f8:      	mov	x0, x20
    a0fc:      	bl	0x1d4f0 <strstr@plt>
    a100:      	cbz	x0, 0xa2cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12b8>
    a104:      	mov	w8, #-0x1a90            // =-6800
    a108:      	add	w8, w22, w8
    a10c:      	cmp	w8, #0xc8
    a110:      	b.lo	0x9f24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf10>
    a114:      	b	0x9f88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf74>
    a118:      	cbz	x19, 0xa158 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1144>
    a11c:      	adrp	x1, 0x3000
    a120:      	add	x1, x1, #0xfcb
    a124:      	mov	x0, x19
    a128:      	bl	0x1d4f0 <strstr@plt>
    a12c:      	cbz	x0, 0xa158 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1144>
    a130:      	adrp	x1, 0x2000
    a134:      	add	x1, x1, #0xd35
    a138:      	mov	x0, x19
    a13c:      	bl	0x1d4f0 <strstr@plt>
    a140:      	cbnz	x0, 0xa334 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1320>
    a144:      	adrp	x1, 0x3000
    a148:      	add	x1, x1, #0xfd1
    a14c:      	mov	x0, x19
    a150:      	bl	0x1d4f0 <strstr@plt>
    a154:      	cbnz	x0, 0xa180 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x116c>
    a158:      	adrp	x1, 0x4000
    a15c:      	add	x1, x1, #0x5c4
    a160:      	mov	x0, x19
    a164:      	bl	0x1d4f0 <strstr@plt>
    a168:      	cbz	x0, 0xa058 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1044>
    a16c:      	adrp	x1, 0x3000
    a170:      	add	x1, x1, #0x21d
    a174:      	mov	x0, x19
    a178:      	bl	0x1d4f0 <strstr@plt>
    a17c:      	cbz	x0, 0xa320 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x130c>
    a180:      	mov	w20, #0x8               // =8
    a184:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a188:      	adrp	x1, 0x3000
    a18c:      	add	x1, x1, #0x6ac
    a190:      	mov	x0, x20
    a194:      	bl	0x1d4f0 <strstr@plt>
    a198:      	mov	w8, #0x6                // =6
    a19c:      	cmp	x0, #0x0
    a1a0:      	cinc	w20, w8, ne
    a1a4:      	cbz	x19, 0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a1a8:      	adrp	x1, 0x4000
    a1ac:      	add	x1, x1, #0x5c4
    a1b0:      	mov	x0, x19
    a1b4:      	bl	0x1d4f0 <strstr@plt>
    a1b8:      	cbz	x0, 0xa1d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11bc>
    a1bc:      	adrp	x1, 0x3000
    a1c0:      	add	x1, x1, #0xfd1
    a1c4:      	mov	x0, x19
    a1c8:      	bl	0x1d4f0 <strstr@plt>
    a1cc:      	cbnz	x0, 0xa388 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1374>
    a1d0:      	adrp	x1, 0x3000
    a1d4:      	add	x1, x1, #0x214
    a1d8:      	mov	x0, x19
    a1dc:      	bl	0x1d4f0 <strstr@plt>
    a1e0:      	cbz	x0, 0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a1e4:      	adrp	x1, 0x3000
    a1e8:      	add	x1, x1, #0x4d7
    a1ec:      	mov	x0, x19
    a1f0:      	bl	0x1d4f0 <strstr@plt>
    a1f4:      	cbnz	x0, 0xa388 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1374>
    a1f8:      	adrp	x1, 0x4000
    a1fc:      	add	x1, x1, #0x18f
    a200:      	mov	x0, x19
    a204:      	bl	0x1d4f0 <strstr@plt>
    a208:      	cbnz	x0, 0xa388 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1374>
    a20c:      	adrp	x1, 0x4000
    a210:      	add	x1, x1, #0xcb4
    a214:      	mov	x0, x19
    a218:      	bl	0x1d4f0 <strstr@plt>
    a21c:      	cbnz	x0, 0xa388 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1374>
    a220:      	adrp	x1, 0x4000
    a224:      	add	x1, x1, #0x83a
    a228:      	mov	x0, x19
    a22c:      	bl	0x1d4f0 <strstr@plt>
    a230:      	cbnz	x0, 0xa388 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1374>
    a234:      	adrp	x1, 0x2000
    a238:      	add	x1, x1, #0xb58
    a23c:      	mov	x0, x19
    a240:      	bl	0x1d4f0 <strstr@plt>
    a244:      	mov	w8, #0x6                // =6
    a248:      	b	0x9ffc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfe8>
    a24c:      	adrp	x1, 0x3000
    a250:      	add	x1, x1, #0xfcb
    a254:      	mov	x0, x19
    a258:      	bl	0x1d4f0 <strstr@plt>
    a25c:      	cbnz	x0, 0xa334 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1320>
    a260:      	adrp	x1, 0x4000
    a264:      	add	x1, x1, #0x5c4
    a268:      	mov	x0, x19
    a26c:      	bl	0x1d4f0 <strstr@plt>
    a270:      	cbnz	x0, 0x9d10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcfc>
    a274:      	adrp	x1, 0x3000
    a278:      	add	x1, x1, #0x214
    a27c:      	mov	x0, x19
    a280:      	bl	0x1d4f0 <strstr@plt>
    a284:      	cbz	x0, 0xa058 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1044>
    a288:      	adrp	x1, 0x4000
    a28c:      	add	x1, x1, #0x996
    a290:      	mov	x0, x19
    a294:      	bl	0x1d4f0 <strstr@plt>
    a298:      	cbnz	x0, 0x9f24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf10>
    a29c:      	b	0xa058 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1044>
    a2a0:      	sub	w8, w22, #0x136
    a2a4:      	cmp	w8, #0x12c
    a2a8:      	b.hi	0xa2fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e8>
    a2ac:      	cbz	x21, 0xa2c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12b0>
    a2b0:      	adrp	x1, 0x3000
    a2b4:      	add	x1, x1, #0xcfb
    a2b8:      	mov	x0, x21
    a2bc:      	bl	0x1d4f0 <strstr@plt>
    a2c0:      	cbnz	x0, 0xa334 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1320>
    a2c4:      	mov	w20, #0x6               // =6
    a2c8:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a2cc:      	adrp	x1, 0x3000
    a2d0:      	add	x1, x1, #0x3d9
    a2d4:      	mov	x0, x20
    a2d8:      	bl	0x1d4f0 <strstr@plt>
    a2dc:      	cbnz	x0, 0x9e68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe54>
    a2e0:      	adrp	x1, 0x2000
    a2e4:      	add	x1, x1, #0xc8d
    a2e8:      	mov	x0, x20
    a2ec:      	bl	0x1d4f0 <strstr@plt>
    a2f0:      	cbz	x0, 0xa34c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1338>
    a2f4:      	mov	w20, #0xa               // =10
    a2f8:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a2fc:      	cmp	w22, #0x267
    a300:      	mov	w20, #0xc               // =12
    a304:      	b.eq	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a308:      	cmp	w22, #0x2c6
    a30c:      	b.eq	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a310:      	cmp	w22, #0x2cb
    a314:      	b.ne	0xa33c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1328>
    a318:      	mov	w20, #0xe               // =14
    a31c:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a320:      	adrp	x1, 0x2000
    a324:      	add	x1, x1, #0xb53
    a328:      	mov	x0, x19
    a32c:      	bl	0x1d4f0 <strstr@plt>
    a330:      	cbz	x0, 0xa058 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1044>
    a334:      	mov	w20, #0x7               // =7
    a338:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a33c:      	cmp	w22, #0x2cf
    a340:      	b.ls	0x9f88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf74>
    a344:      	mov	w20, #0x11              // =17
    a348:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a34c:      	adrp	x1, 0x3000
    a350:      	add	x1, x1, #0x9a3
    a354:      	mov	x0, x20
    a358:      	bl	0x1d4f0 <strstr@plt>
    a35c:      	cbz	x0, 0xa390 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x137c>
    a360:      	cmp	w22, #0x397
    a364:      	mov	w0, wzr
    a368:      	b.gt	0xa3d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13c0>
    a36c:      	cmp	w22, #0x212
    a370:      	b.eq	0xa388 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1374>
    a374:      	cmp	w22, #0x21c
    a378:      	b.eq	0xa2f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e0>
    a37c:      	cmp	w22, #0x226
    a380:      	b.eq	0xa318 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1304>
    a384:      	b	0x9f8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf78>
    a388:      	mov	w20, #0x9               // =9
    a38c:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a390:      	adrp	x1, 0x3000
    a394:      	add	x1, x1, #0x9ab
    a398:      	mov	x0, x20
    a39c:      	bl	0x1d4f0 <strstr@plt>
    a3a0:      	cbz	x0, 0x9f8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf78>
    a3a4:      	sub	w8, w22, #0x38f
    a3a8:      	cmp	w8, #0x58
    a3ac:      	b.hi	0xa3f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13e0>
    a3b0:      	adrp	x1, 0x2000
    a3b4:      	add	x1, x1, #0xc97
    a3b8:      	mov	x0, x19
    a3bc:      	bl	0x1d4f0 <strstr@plt>
    a3c0:      	mov	w8, #0x8                // =8
    a3c4:      	cmp	x0, #0x0
    a3c8:      	mov	w9, #0xd                // =13
    a3cc:      	csel	w20, w9, w8, eq
    a3d0:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a3d4:      	cmp	w22, #0x398
    a3d8:      	b.eq	0xa3f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13e0>
    a3dc:      	cmp	w22, #0x3ac
    a3e0:      	b.eq	0xa420 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x140c>
    a3e4:      	cmp	w22, #0x3b6
    a3e8:      	b.ne	0x9f8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf78>
    a3ec:      	mov	w20, #0x16              // =22
    a3f0:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a3f4:      	mov	w20, #0xf               // =15
    a3f8:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a3fc:      	cmp	w22, #0x2df
    a400:      	b.lo	0xa344 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1330>
    a404:      	cmp	w22, #0x2e4
    a408:      	b.hs	0xa418 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1404>
    a40c:      	mov	w20, #0x12              // =18
    a410:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a414:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    a418:      	cmp	w22, #0x2ee
    a41c:      	b.hs	0xa428 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1414>
    a420:      	mov	w20, #0x14              // =20
    a424:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a428:      	cmp	w22, #0x33e
    a42c:      	b.lo	0xa3ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13d8>
    a430:      	cmp	w22, #0x348
    a434:      	mov	w8, #0x1a               // =26
    a438:      	mov	w9, #0x18               // =24
    a43c:      	csel	w20, w9, w8, lo
    a440:      	b	0x9e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58>
    a444:      	stp	x29, x30, [sp, #-0x30]!
    a448:      	stp	x22, x21, [sp, #0x10]
    a44c:      	stp	x20, x19, [sp, #0x20]
    a450:      	mov	x29, sp
    a454:      	mov	w20, w1
    a458:      	mov	w19, w0
    a45c:      	mov	w22, #0xd               // =13
    a460:      	cbz	x2, 0xa4f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14e4>
    a464:      	adrp	x1, 0x3000
    a468:      	add	x1, x1, #0xced
    a46c:      	mov	x0, x2
    a470:      	mov	x21, x2
    a474:      	bl	0x1d4f0 <strstr@plt>
    a478:      	cbnz	x0, 0xa490 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x147c>
    a47c:      	adrp	x1, 0x3000
    a480:      	add	x1, x1, #0x3cd
    a484:      	mov	x0, x21
    a488:      	bl	0x1d4f0 <strstr@plt>
    a48c:      	cbz	x0, 0xa498 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1484>
    a490:      	mov	w8, #0x1                // =1
    a494:      	b	0xa4fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14e8>
    a498:      	adrp	x1, 0x2000
    a49c:      	add	x1, x1, #0xb45
    a4a0:      	mov	x0, x21
    a4a4:      	bl	0x1d4f0 <strstr@plt>
    a4a8:      	cbnz	x0, 0xa4c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14ac>
    a4ac:      	adrp	x1, 0x3000
    a4b0:      	add	x1, x1, #0x718
    a4b4:      	mov	x0, x21
    a4b8:      	bl	0x1d4f0 <strstr@plt>
    a4bc:      	cbz	x0, 0xa4c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14b4>
    a4c0:      	mov	w8, #0x2                // =2
    a4c4:      	b	0xa4fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14e8>
    a4c8:      	adrp	x1, 0x4000
    a4cc:      	add	x1, x1, #0x715
    a4d0:      	mov	x0, x21
    a4d4:      	bl	0x1d4f0 <strstr@plt>
    a4d8:      	cbnz	x0, 0xa4f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14dc>
    a4dc:      	adrp	x1, 0x4000
    a4e0:      	add	x1, x1, #0x42a
    a4e4:      	mov	x0, x21
    a4e8:      	bl	0x1d4f0 <strstr@plt>
    a4ec:      	cbz	x0, 0xa4f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14e4>
    a4f0:      	mov	w8, #0x3                // =3
    a4f4:      	b	0xa4fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14e8>
    a4f8:      	mov	w8, #0xd                // =13
    a4fc:      	tst	w20, #0x1
    a500:      	mov	w9, #0x10               // =16
    a504:      	csel	w9, w9, w22, ne
    a508:      	tst	w19, #0x1
    a50c:      	csel	w0, w9, w8, ne
    a510:      	ldp	x20, x19, [sp, #0x20]
    a514:      	ldp	x22, x21, [sp, #0x10]
    a518:      	ldp	x29, x30, [sp], #0x30
    a51c:      	ret
    a520:      	mov	w8, #0x500              // =1280
    a524:      	movk	w8, #0x30, lsl #16
    a528:      	cmp	w0, w8
    a52c:      	b.gt	0xa594 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1580>
    a530:      	mov	w8, #0x103              // =259
    a534:      	movk	w8, #0x20, lsl #16
    a538:      	cmp	w0, w8
    a53c:      	b.le	0xa5e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x15d4>
    a540:      	mov	w8, #0x207              // =519
    a544:      	movk	w8, #0x30, lsl #16
    a548:      	cmp	w0, w8
    a54c:      	b.le	0xa6a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1694>
    a550:      	mov	w8, #0x214              // =532
    a554:      	movk	w8, #0x30, lsl #16
    a558:      	cmp	w0, w8
    a55c:      	b.le	0xa9b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x199c>
    a560:      	sub	w8, w0, #0x300, lsl #12 // =0x300000
    a564:      	sub	w8, w8, #0x332
    a568:      	cmp	w8, #0x46
    a56c:      	b.hi	0xae0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1df8>
    a570:      	adrp	x9, 0x4000
    a574:      	add	x9, x9, #0xdde
    a578:      	adr	x10, 0xa588 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1574>
    a57c:      	ldrh	w11, [x9, x8, lsl #1]
    a580:      	add	x10, x10, x11, lsl #2
    a584:      	br	x10
    a588:      	adrp	x0, 0x4000
    a58c:      	add	x0, x0, #0x1a9
    a590:      	ret
    a594:      	mov	w8, #0xff               // =255
    a598:      	movk	w8, #0x70, lsl #16
    a59c:      	cmp	w0, w8
    a5a0:      	b.le	0xa63c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1628>
    a5a4:      	mov	w8, #0xff               // =255
    a5a8:      	movk	w8, #0x80, lsl #16
    a5ac:      	cmp	w0, w8
    a5b0:      	b.gt	0xa7dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x17c8>
    a5b4:      	sub	w8, w0, #0x700, lsl #12 // =0x700000
    a5b8:      	sub	w8, w8, #0x100
    a5bc:      	cmp	w8, #0x20
    a5c0:      	b.hi	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    a5c4:      	adrp	x9, 0x4000
    a5c8:      	add	x9, x9, #0xe6c
    a5cc:      	adr	x10, 0xa5dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x15c8>
    a5d0:      	ldrh	w11, [x9, x8, lsl #1]
    a5d4:      	add	x10, x10, x11, lsl #2
    a5d8:      	br	x10
    a5dc:      	adrp	x0, 0x4000
    a5e0:      	add	x0, x0, #0xb9d
    a5e4:      	ret
    a5e8:      	mov	w8, #0x300              // =768
    a5ec:      	movk	w8, #0x10, lsl #16
    a5f0:      	cmp	w0, w8
    a5f4:      	b.gt	0xa714 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1700>
    a5f8:      	mov	w8, #0x1ff              // =511
    a5fc:      	movk	w8, #0x10, lsl #16
    a600:      	cmp	w0, w8
    a604:      	b.le	0xaadc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1ac8>
    a608:      	sub	w8, w0, #0x100, lsl #12 // =0x100000
    a60c:      	sub	w8, w8, #0x200
    a610:      	cmp	w8, #0xc
    a614:      	b.hi	0xae50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1e3c>
    a618:      	nop
    a61c:      	adr	x9, 0x4dc4
    a620:      	adr	x10, 0xa630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x161c>
    a624:      	ldrh	w11, [x9, x8, lsl #1]
    a628:      	add	x10, x10, x11, lsl #2
    a62c:      	br	x10
    a630:      	adrp	x0, 0x3000
    a634:      	add	x0, x0, #0x4df
    a638:      	ret
    a63c:      	mov	w8, #0x101              // =257
    a640:      	movk	w8, #0x40, lsl #16
    a644:      	cmp	w0, w8
    a648:      	b.gt	0xa780 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x176c>
    a64c:      	mov	w8, #0x551              // =1361
    a650:      	movk	w8, #0x30, lsl #16
    a654:      	cmp	w0, w8
    a658:      	b.le	0xa8d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x18bc>
    a65c:      	mov	w8, #0x572              // =1394
    a660:      	movk	w8, #0x30, lsl #16
    a664:      	cmp	w0, w8
    a668:      	b.le	0xab84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1b70>
    a66c:      	mov	w8, #0xff               // =255
    a670:      	movk	w8, #0x40, lsl #16
    a674:      	cmp	w0, w8
    a678:      	b.gt	0xac54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1c40>
    a67c:      	mov	w8, #0x573              // =1395
    a680:      	movk	w8, #0x30, lsl #16
    a684:      	cmp	w0, w8
    a688:      	b.eq	0xafa4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1f90>
    a68c:      	mov	w8, #0x574              // =1396
    a690:      	movk	w8, #0x30, lsl #16
    a694:      	cmp	w0, w8
    a698:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    a69c:      	adrp	x0, 0x2000
    a6a0:      	add	x0, x0, #0xe80
    a6a4:      	ret
    a6a8:      	mov	w8, #0x1ff              // =511
    a6ac:      	movk	w8, #0x20, lsl #16
    a6b0:      	cmp	w0, w8
    a6b4:      	b.le	0xa838 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1824>
    a6b8:      	mov	w8, #0xff               // =255
    a6bc:      	movk	w8, #0x30, lsl #16
    a6c0:      	cmp	w0, w8
    a6c4:      	b.le	0xaa64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1a50>
    a6c8:      	mov	w8, #0x101              // =257
    a6cc:      	movk	w8, #0x30, lsl #16
    a6d0:      	cmp	w0, w8
    a6d4:      	b.le	0xadb4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1da0>
    a6d8:      	mov	w8, #0x102              // =258
    a6dc:      	movk	w8, #0x30, lsl #16
    a6e0:      	cmp	w0, w8
    a6e4:      	b.eq	0xb088 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2074>
    a6e8:      	mov	w8, #0x205              // =517
    a6ec:      	movk	w8, #0x30, lsl #16
    a6f0:      	cmp	w0, w8
    a6f4:      	b.eq	0xb070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x205c>
    a6f8:      	mov	w8, #0x207              // =519
    a6fc:      	movk	w8, #0x30, lsl #16
    a700:      	cmp	w0, w8
    a704:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    a708:      	adrp	x0, 0x3000
    a70c:      	add	x0, x0, #0xc26
    a710:      	ret
    a714:      	mov	w8, #0x500              // =1280
    a718:      	movk	w8, #0x10, lsl #16
    a71c:      	cmp	w0, w8
    a720:      	b.le	0xa884 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1870>
    a724:      	mov	w8, #0x5ff              // =1535
    a728:      	movk	w8, #0x10, lsl #16
    a72c:      	cmp	w0, w8
    a730:      	b.le	0xaaa0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1a8c>
    a734:      	mov	w8, #0x100              // =256
    a738:      	movk	w8, #0x20, lsl #16
    a73c:      	cmp	w0, w8
    a740:      	b.le	0xade0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1dcc>
    a744:      	mov	w8, #0x101              // =257
    a748:      	movk	w8, #0x20, lsl #16
    a74c:      	cmp	w0, w8
    a750:      	b.eq	0xb0a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x208c>
    a754:      	mov	w8, #0x102              // =258
    a758:      	movk	w8, #0x20, lsl #16
    a75c:      	cmp	w0, w8
    a760:      	b.eq	0xb094 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2080>
    a764:      	mov	w8, #0x103              // =259
    a768:      	movk	w8, #0x20, lsl #16
    a76c:      	cmp	w0, w8
    a770:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    a774:      	adrp	x0, 0x3000
    a778:      	add	x0, x0, #0xad3
    a77c:      	ret
    a780:      	mov	w8, #0x100              // =256
    a784:      	movk	w8, #0x50, lsl #16
    a788:      	cmp	w0, w8
    a78c:      	b.le	0xa91c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1908>
    a790:      	mov	w8, #0x100              // =256
    a794:      	movk	w8, #0x60, lsl #16
    a798:      	cmp	w0, w8
    a79c:      	b.le	0xabc0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1bac>
    a7a0:      	mov	w8, #0x102              // =258
    a7a4:      	movk	w8, #0x60, lsl #16
    a7a8:      	cmp	w0, w8
    a7ac:      	b.gt	0xac80 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1c6c>
    a7b0:      	mov	w8, #0x101              // =257
    a7b4:      	movk	w8, #0x60, lsl #16
    a7b8:      	cmp	w0, w8
    a7bc:      	b.eq	0xafb0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1f9c>
    a7c0:      	mov	w8, #0x102              // =258
    a7c4:      	movk	w8, #0x60, lsl #16
    a7c8:      	cmp	w0, w8
    a7cc:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    a7d0:      	adrp	x0, 0x4000
    a7d4:      	add	x0, x0, #0x2b9
    a7d8:      	ret
    a7dc:      	mov	w8, #0xff               // =255
    a7e0:      	movk	w8, #0xb0, lsl #16
    a7e4:      	cmp	w0, w8
    a7e8:      	b.gt	0xa968 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1954>
    a7ec:      	mov	w8, #0xff               // =255
    a7f0:      	movk	w8, #0x90, lsl #16
    a7f4:      	cmp	w0, w8
    a7f8:      	b.le	0xabfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1be8>
    a7fc:      	mov	w8, #0x100              // =256
    a800:      	movk	w8, #0x90, lsl #16
    a804:      	cmp	w0, w8
    a808:      	b.eq	0xb0dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x20c8>
    a80c:      	mov	w8, #0x100              // =256
    a810:      	movk	w8, #0xa0, lsl #16
    a814:      	cmp	w0, w8
    a818:      	b.eq	0xb0c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x20b0>
    a81c:      	mov	w8, #0x101              // =257
    a820:      	movk	w8, #0xa0, lsl #16
    a824:      	cmp	w0, w8
    a828:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    a82c:      	adrp	x0, 0x3000
    a830:      	add	x0, x0, #0xd69
    a834:      	ret
    a838:      	mov	w8, #0x107              // =263
    a83c:      	movk	w8, #0x20, lsl #16
    a840:      	cmp	w0, w8
    a844:      	b.gt	0xa9ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x19d8>
    a848:      	mov	w8, #0x105              // =261
    a84c:      	movk	w8, #0x20, lsl #16
    a850:      	cmp	w0, w8
    a854:      	b.gt	0xacac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1c98>
    a858:      	mov	w8, #0x104              // =260
    a85c:      	movk	w8, #0x20, lsl #16
    a860:      	cmp	w0, w8
    a864:      	b.eq	0xafd4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1fc0>
    a868:      	mov	w8, #0x105              // =261
    a86c:      	movk	w8, #0x20, lsl #16
    a870:      	cmp	w0, w8
    a874:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    a878:      	adrp	x0, 0x3000
    a87c:      	add	x0, x0, #0x4f3
    a880:      	ret
    a884:      	mov	w8, #0x402              // =1026
    a888:      	movk	w8, #0x10, lsl #16
    a88c:      	cmp	w0, w8
    a890:      	b.gt	0xaa28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1a14>
    a894:      	mov	w8, #0x400              // =1024
    a898:      	movk	w8, #0x10, lsl #16
    a89c:      	cmp	w0, w8
    a8a0:      	b.gt	0xad04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1cf0>
    a8a4:      	mov	w8, #0x301              // =769
    a8a8:      	movk	w8, #0x10, lsl #16
    a8ac:      	cmp	w0, w8
    a8b0:      	b.eq	0xb004 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1ff0>
    a8b4:      	mov	w8, #0x400              // =1024
    a8b8:      	movk	w8, #0x10, lsl #16
    a8bc:      	cmp	w0, w8
    a8c0:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    a8c4:      	adrp	x0, 0x3000
    a8c8:      	add	x0, x0, #0xc3
    a8cc:      	ret
    a8d0:      	mov	w8, #0x503              // =1283
    a8d4:      	movk	w8, #0x30, lsl #16
    a8d8:      	cmp	w0, w8
    a8dc:      	b.gt	0xab0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1af8>
    a8e0:      	mov	w8, #0x501              // =1281
    a8e4:      	movk	w8, #0x30, lsl #16
    a8e8:      	cmp	w0, w8
    a8ec:      	b.eq	0xb124 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2110>
    a8f0:      	mov	w8, #0x502              // =1282
    a8f4:      	movk	w8, #0x30, lsl #16
    a8f8:      	cmp	w0, w8
    a8fc:      	b.eq	0xb0f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x20e0>
    a900:      	mov	w8, #0x503              // =1283
    a904:      	movk	w8, #0x30, lsl #16
    a908:      	cmp	w0, w8
    a90c:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    a910:      	adrp	x0, 0x4000
    a914:      	add	x0, x0, #0xb93
    a918:      	ret
    a91c:      	mov	w8, #0x104              // =260
    a920:      	movk	w8, #0x40, lsl #16
    a924:      	cmp	w0, w8
    a928:      	b.gt	0xab48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1b34>
    a92c:      	mov	w8, #0x102              // =258
    a930:      	movk	w8, #0x40, lsl #16
    a934:      	cmp	w0, w8
    a938:      	b.eq	0xb130 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x211c>
    a93c:      	mov	w8, #0x103              // =259
    a940:      	movk	w8, #0x40, lsl #16
    a944:      	cmp	w0, w8
    a948:      	b.eq	0xb100 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x20ec>
    a94c:      	mov	w8, #0x104              // =260
    a950:      	movk	w8, #0x40, lsl #16
    a954:      	cmp	w0, w8
    a958:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    a95c:      	adrp	x0, 0x3000
    a960:      	add	x0, x0, #0x514
    a964:      	ret
    a968:      	mov	w8, #0x100              // =256
    a96c:      	movk	w8, #0xc0, lsl #16
    a970:      	cmp	w0, w8
    a974:      	b.le	0xac28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1c14>
    a978:      	mov	w8, #0x101              // =257
    a97c:      	movk	w8, #0xc0, lsl #16
    a980:      	cmp	w0, w8
    a984:      	b.eq	0xb0e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x20d4>
    a988:      	mov	w8, #0x102              // =258
    a98c:      	movk	w8, #0xc0, lsl #16
    a990:      	cmp	w0, w8
    a994:      	b.eq	0xb0d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x20bc>
    a998:      	mov	w8, #0x1000100          // =16777472
    a99c:      	cmp	w0, w8
    a9a0:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    a9a4:      	adrp	x0, 0x3000
    a9a8:      	add	x0, x0, #0x6d3
    a9ac:      	ret
    a9b0:      	mov	w8, #0x208              // =520
    a9b4:      	movk	w8, #0x30, lsl #16
    a9b8:      	cmp	w0, w8
    a9bc:      	b.eq	0xae38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1e24>
    a9c0:      	mov	w8, #0x209              // =521
    a9c4:      	movk	w8, #0x30, lsl #16
    a9c8:      	cmp	w0, w8
    a9cc:      	b.eq	0xae44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1e30>
    a9d0:      	mov	w8, #0x212              // =530
    a9d4:      	movk	w8, #0x30, lsl #16
    a9d8:      	cmp	w0, w8
    a9dc:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    a9e0:      	adrp	x0, 0x4000
    a9e4:      	add	x0, x0, #0xa69
    a9e8:      	ret
    a9ec:      	mov	w8, #0x109              // =265
    a9f0:      	movk	w8, #0x20, lsl #16
    a9f4:      	cmp	w0, w8
    a9f8:      	b.gt	0xacd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1cc4>
    a9fc:      	mov	w8, #0x108              // =264
    aa00:      	movk	w8, #0x20, lsl #16
    aa04:      	cmp	w0, w8
    aa08:      	b.eq	0xafe0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1fcc>
    aa0c:      	mov	w8, #0x109              // =265
    aa10:      	movk	w8, #0x20, lsl #16
    aa14:      	cmp	w0, w8
    aa18:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    aa1c:      	adrp	x0, 0x4000
    aa20:      	add	x0, x0, #0x85b
    aa24:      	ret
    aa28:      	mov	w8, #0x404              // =1028
    aa2c:      	movk	w8, #0x10, lsl #16
    aa30:      	cmp	w0, w8
    aa34:      	b.gt	0xad30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1d1c>
    aa38:      	mov	w8, #0x403              // =1027
    aa3c:      	movk	w8, #0x10, lsl #16
    aa40:      	cmp	w0, w8
    aa44:      	b.eq	0xb010 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1ffc>
    aa48:      	mov	w8, #0x404              // =1028
    aa4c:      	movk	w8, #0x10, lsl #16
    aa50:      	cmp	w0, w8
    aa54:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    aa58:      	adrp	x0, 0x3000
    aa5c:      	add	x0, x0, #0x4ea
    aa60:      	ret
    aa64:      	mov	w8, #0x201              // =513
    aa68:      	movk	w8, #0x20, lsl #16
    aa6c:      	cmp	w0, w8
    aa70:      	b.gt	0xad5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1d48>
    aa74:      	mov	w8, #0x200              // =512
    aa78:      	movk	w8, #0x20, lsl #16
    aa7c:      	cmp	w0, w8
    aa80:      	b.eq	0xb034 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2020>
    aa84:      	mov	w8, #0x201              // =513
    aa88:      	movk	w8, #0x20, lsl #16
    aa8c:      	cmp	w0, w8
    aa90:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    aa94:      	adrp	x0, 0x3000
    aa98:      	add	x0, x0, #0xa38
    aa9c:      	ret
    aaa0:      	mov	w8, #0x502              // =1282
    aaa4:      	movk	w8, #0x10, lsl #16
    aaa8:      	cmp	w0, w8
    aaac:      	b.gt	0xad88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1d74>
    aab0:      	mov	w8, #0x501              // =1281
    aab4:      	movk	w8, #0x10, lsl #16
    aab8:      	cmp	w0, w8
    aabc:      	b.eq	0xb04c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2038>
    aac0:      	mov	w8, #0x502              // =1282
    aac4:      	movk	w8, #0x10, lsl #16
    aac8:      	cmp	w0, w8
    aacc:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    aad0:      	adrp	x0, 0x3000
    aad4:      	add	x0, x0, #0x22b
    aad8:      	ret
    aadc:      	cbz	w0, 0xb1e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x21d0>
    aae0:      	mov	w8, #0x100              // =256
    aae4:      	movk	w8, #0x10, lsl #16
    aae8:      	cmp	w0, w8
    aaec:      	b.eq	0xb220 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x220c>
    aaf0:      	mov	w8, #0x101              // =257
    aaf4:      	movk	w8, #0x10, lsl #16
    aaf8:      	cmp	w0, w8
    aafc:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    ab00:      	adrp	x0, 0x3000
    ab04:      	add	x0, x0, #0x725
    ab08:      	ret
    ab0c:      	mov	w8, #0x504              // =1284
    ab10:      	movk	w8, #0x30, lsl #16
    ab14:      	cmp	w0, w8
    ab18:      	b.eq	0xb13c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2128>
    ab1c:      	mov	w8, #0x505              // =1285
    ab20:      	movk	w8, #0x30, lsl #16
    ab24:      	cmp	w0, w8
    ab28:      	b.eq	0xb10c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x20f8>
    ab2c:      	mov	w8, #0x551              // =1361
    ab30:      	movk	w8, #0x30, lsl #16
    ab34:      	cmp	w0, w8
    ab38:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    ab3c:      	adrp	x0, 0x2000
    ab40:      	add	x0, x0, #0xd59
    ab44:      	ret
    ab48:      	mov	w8, #0x105              // =261
    ab4c:      	movk	w8, #0x40, lsl #16
    ab50:      	cmp	w0, w8
    ab54:      	b.eq	0xb148 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2134>
    ab58:      	mov	w8, #0x106              // =262
    ab5c:      	movk	w8, #0x40, lsl #16
    ab60:      	cmp	w0, w8
    ab64:      	b.eq	0xb118 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2104>
    ab68:      	mov	w8, #0x100              // =256
    ab6c:      	movk	w8, #0x50, lsl #16
    ab70:      	cmp	w0, w8
    ab74:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    ab78:      	adrp	x0, 0x4000
    ab7c:      	add	x0, x0, #0x0
    ab80:      	ret
    ab84:      	mov	w8, #0x552              // =1362
    ab88:      	movk	w8, #0x30, lsl #16
    ab8c:      	cmp	w0, w8
    ab90:      	b.eq	0xb16c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2158>
    ab94:      	mov	w8, #0x571              // =1393
    ab98:      	movk	w8, #0x30, lsl #16
    ab9c:      	cmp	w0, w8
    aba0:      	b.eq	0xb154 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2140>
    aba4:      	mov	w8, #0x572              // =1394
    aba8:      	movk	w8, #0x30, lsl #16
    abac:      	cmp	w0, w8
    abb0:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    abb4:      	adrp	x0, 0x4000
    abb8:      	add	x0, x0, #0xa8a
    abbc:      	ret
    abc0:      	mov	w8, #0x101              // =257
    abc4:      	movk	w8, #0x50, lsl #16
    abc8:      	cmp	w0, w8
    abcc:      	b.eq	0xb178 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2164>
    abd0:      	mov	w8, #0x102              // =258
    abd4:      	movk	w8, #0x50, lsl #16
    abd8:      	cmp	w0, w8
    abdc:      	b.eq	0xb160 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x214c>
    abe0:      	mov	w8, #0x100              // =256
    abe4:      	movk	w8, #0x60, lsl #16
    abe8:      	cmp	w0, w8
    abec:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    abf0:      	adrp	x0, 0x3000
    abf4:      	add	x0, x0, #0x9cc
    abf8:      	ret
    abfc:      	mov	w8, #0x100              // =256
    ac00:      	movk	w8, #0x80, lsl #16
    ac04:      	cmp	w0, w8
    ac08:      	b.eq	0xb0ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2098>
    ac0c:      	mov	w8, #0x200              // =512
    ac10:      	movk	w8, #0x80, lsl #16
    ac14:      	cmp	w0, w8
    ac18:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    ac1c:      	adrp	x0, 0x2000
    ac20:      	add	x0, x0, #0xd74
    ac24:      	ret
    ac28:      	mov	w8, #0x100              // =256
    ac2c:      	movk	w8, #0xb0, lsl #16
    ac30:      	cmp	w0, w8
    ac34:      	b.eq	0xb0b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x20a4>
    ac38:      	mov	w8, #0x100              // =256
    ac3c:      	movk	w8, #0xc0, lsl #16
    ac40:      	cmp	w0, w8
    ac44:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    ac48:      	adrp	x0, 0x2000
    ac4c:      	add	x0, x0, #0xfc7
    ac50:      	ret
    ac54:      	mov	w8, #0x100              // =256
    ac58:      	movk	w8, #0x40, lsl #16
    ac5c:      	cmp	w0, w8
    ac60:      	b.eq	0xafbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1fa8>
    ac64:      	mov	w8, #0x101              // =257
    ac68:      	movk	w8, #0x40, lsl #16
    ac6c:      	cmp	w0, w8
    ac70:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    ac74:      	adrp	x0, 0x3000
    ac78:      	add	x0, x0, #0xd4a
    ac7c:      	ret
    ac80:      	mov	w8, #0x103              // =259
    ac84:      	movk	w8, #0x60, lsl #16
    ac88:      	cmp	w0, w8
    ac8c:      	b.eq	0xafc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1fb4>
    ac90:      	mov	w8, #0x104              // =260
    ac94:      	movk	w8, #0x60, lsl #16
    ac98:      	cmp	w0, w8
    ac9c:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    aca0:      	adrp	x0, 0x2000
    aca4:      	add	x0, x0, #0xb70
    aca8:      	ret
    acac:      	mov	w8, #0x106              // =262
    acb0:      	movk	w8, #0x20, lsl #16
    acb4:      	cmp	w0, w8
    acb8:      	b.eq	0xafec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1fd8>
    acbc:      	mov	w8, #0x107              // =263
    acc0:      	movk	w8, #0x20, lsl #16
    acc4:      	cmp	w0, w8
    acc8:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    accc:      	adrp	x0, 0x3000
    acd0:      	add	x0, x0, #0xc1a
    acd4:      	ret
    acd8:      	mov	w8, #0x10a              // =266
    acdc:      	movk	w8, #0x20, lsl #16
    ace0:      	cmp	w0, w8
    ace4:      	b.eq	0xaff8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1fe4>
    ace8:      	mov	w8, #0x10b              // =267
    acec:      	movk	w8, #0x20, lsl #16
    acf0:      	cmp	w0, w8
    acf4:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    acf8:      	adrp	x0, 0x3000
    acfc:      	add	x0, x0, #0x23b
    ad00:      	ret
    ad04:      	mov	w8, #0x401              // =1025
    ad08:      	movk	w8, #0x10, lsl #16
    ad0c:      	cmp	w0, w8
    ad10:      	b.eq	0xb01c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2008>
    ad14:      	mov	w8, #0x402              // =1026
    ad18:      	movk	w8, #0x10, lsl #16
    ad1c:      	cmp	w0, w8
    ad20:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    ad24:      	adrp	x0, 0x4000
    ad28:      	add	x0, x0, #0xb88
    ad2c:      	ret
    ad30:      	mov	w8, #0x405              // =1029
    ad34:      	movk	w8, #0x10, lsl #16
    ad38:      	cmp	w0, w8
    ad3c:      	b.eq	0xb028 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2014>
    ad40:      	mov	w8, #0x500              // =1280
    ad44:      	movk	w8, #0x10, lsl #16
    ad48:      	cmp	w0, w8
    ad4c:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    ad50:      	adrp	x0, 0x3000
    ad54:      	add	x0, x0, #0xd32
    ad58:      	ret
    ad5c:      	mov	w8, #0x202              // =514
    ad60:      	movk	w8, #0x20, lsl #16
    ad64:      	cmp	w0, w8
    ad68:      	b.eq	0xb040 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x202c>
    ad6c:      	mov	w8, #0x203              // =515
    ad70:      	movk	w8, #0x20, lsl #16
    ad74:      	cmp	w0, w8
    ad78:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    ad7c:      	adrp	x0, 0x4000
    ad80:      	add	x0, x0, #0x2a4
    ad84:      	ret
    ad88:      	mov	w8, #0x503              // =1283
    ad8c:      	movk	w8, #0x10, lsl #16
    ad90:      	cmp	w0, w8
    ad94:      	b.eq	0xb058 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2044>
    ad98:      	mov	w8, #0x504              // =1284
    ad9c:      	movk	w8, #0x10, lsl #16
    ada0:      	cmp	w0, w8
    ada4:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    ada8:      	adrp	x0, 0x2000
    adac:      	add	x0, x0, #0xc06
    adb0:      	ret
    adb4:      	mov	w8, #0x100              // =256
    adb8:      	movk	w8, #0x30, lsl #16
    adbc:      	cmp	w0, w8
    adc0:      	b.eq	0xb064 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2050>
    adc4:      	mov	w8, #0x101              // =257
    adc8:      	movk	w8, #0x30, lsl #16
    adcc:      	cmp	w0, w8
    add0:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    add4:      	adrp	x0, 0x3000
    add8:      	add	x0, x0, #0xff0
    addc:      	ret
    ade0:      	mov	w8, #0x600              // =1536
    ade4:      	movk	w8, #0x10, lsl #16
    ade8:      	cmp	w0, w8
    adec:      	b.eq	0xb07c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2068>
    adf0:      	mov	w8, #0x100              // =256
    adf4:      	movk	w8, #0x20, lsl #16
    adf8:      	cmp	w0, w8
    adfc:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    ae00:      	adrp	x0, 0x3000
    ae04:      	add	x0, x0, #0xd40
    ae08:      	ret
    ae0c:      	mov	w8, #0x215              // =533
    ae10:      	movk	w8, #0x30, lsl #16
    ae14:      	cmp	w0, w8
    ae18:      	b.eq	0xb2c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x22b4>
    ae1c:      	mov	w8, #0x217              // =535
    ae20:      	movk	w8, #0x30, lsl #16
    ae24:      	cmp	w0, w8
    ae28:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    ae2c:      	adrp	x0, 0x2000
    ae30:      	add	x0, x0, #0xd43
    ae34:      	ret
    ae38:      	adrp	x0, 0x2000
    ae3c:      	add	x0, x0, #0xc13
    ae40:      	ret
    ae44:      	adrp	x0, 0x3000
    ae48:      	add	x0, x0, #0xce
    ae4c:      	ret
    ae50:      	mov	w8, #0x300              // =768
    ae54:      	movk	w8, #0x10, lsl #16
    ae58:      	cmp	w0, w8
    ae5c:      	b.ne	0xb22c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2218>
    ae60:      	adrp	x0, 0x4000
    ae64:      	add	x0, x0, #0x4a6
    ae68:      	ret
    ae6c:      	adrp	x0, 0x3000
    ae70:      	add	x0, x0, #0xaea
    ae74:      	ret
    ae78:      	adrp	x0, 0x4000
    ae7c:      	add	x0, x0, #0x2c3
    ae80:      	ret
    ae84:      	adrp	x0, 0x3000
    ae88:      	add	x0, x0, #0xe7b
    ae8c:      	ret
    ae90:      	adrp	x0, 0x3000
    ae94:      	add	x0, x0, #0x6ca
    ae98:      	ret
    ae9c:      	adrp	x0, 0x3000
    aea0:      	add	x0, x0, #0x3ff
    aea4:      	ret
    aea8:      	adrp	x0, 0x4000
    aeac:      	add	x0, x0, #0x875
    aeb0:      	ret
    aeb4:      	adrp	x0, 0x3000
    aeb8:      	add	x0, x0, #0x3f9
    aebc:      	ret
    aec0:      	adrp	x0, 0x3000
    aec4:      	add	x0, x0, #0xe6a
    aec8:      	ret
    aecc:      	adrp	x0, 0x3000
    aed0:      	add	x0, x0, #0xd5f
    aed4:      	ret
    aed8:      	adrp	x0, 0x4000
    aedc:      	add	x0, x0, #0x72f
    aee0:      	ret
    aee4:      	adrp	x0, 0x3000
    aee8:      	add	x0, x0, #0xd8
    aeec:      	ret
    aef0:      	adrp	x0, 0x3000
    aef4:      	add	x0, x0, #0xd57
    aef8:      	ret
    aefc:      	adrp	x0, 0x2000
    af00:      	add	x0, x0, #0xb7a
    af04:      	ret
    af08:      	adrp	x0, 0x2000
    af0c:      	add	x0, x0, #0xd6c
    af10:      	ret
    af14:      	adrp	x0, 0x2000
    af18:      	add	x0, x0, #0xab2
    af1c:      	ret
    af20:      	adrp	x0, 0x2000
    af24:      	add	x0, x0, #0xe8c
    af28:      	ret
    af2c:      	adrp	x0, 0x2000
    af30:      	add	x0, x0, #0xaa8
    af34:      	ret
    af38:      	adrp	x0, 0x2000
    af3c:      	add	x0, x0, #0xaa0
    af40:      	ret
    af44:      	adrp	x0, 0x4000
    af48:      	add	x0, x0, #0xcce
    af4c:      	ret
    af50:      	adrp	x0, 0x4000
    af54:      	add	x0, x0, #0xba3
    af58:      	ret
    af5c:      	adrp	x0, 0x4000
    af60:      	add	x0, x0, #0xcc6
    af64:      	ret
    af68:      	adrp	x0, 0x2000
    af6c:      	add	x0, x0, #0xca8
    af70:      	ret
    af74:      	adrp	x0, 0x3000
    af78:      	add	x0, x0, #0x51c
    af7c:      	ret
    af80:      	adrp	x0, 0x3000
    af84:      	add	x0, x0, #0xc3c
    af88:      	ret
    af8c:      	adrp	x0, 0x3000
    af90:      	add	x0, x0, #0xe73
    af94:      	ret
    af98:      	adrp	x0, 0x3000
    af9c:      	add	x0, x0, #0x524
    afa0:      	ret
    afa4:      	adrp	x0, 0x3000
    afa8:      	add	x0, x0, #0x3ed
    afac:      	ret
    afb0:      	adrp	x0, 0x4000
    afb4:      	add	x0, x0, #0x9b4
    afb8:      	ret
    afbc:      	adrp	x0, 0x3000
    afc0:      	add	x0, x0, #0x9c3
    afc4:      	ret
    afc8:      	adrp	x0, 0x3000
    afcc:      	add	x0, x0, #0xae0
    afd0:      	ret
    afd4:      	adrp	x0, 0x4000
    afd8:      	add	x0, x0, #0xa65
    afdc:      	ret
    afe0:      	adrp	x0, 0x2000
    afe4:      	add	x0, x0, #0xd39
    afe8:      	ret
    afec:      	adrp	x0, 0x4000
    aff0:      	add	x0, x0, #0x850
    aff4:      	ret
    aff8:      	adrp	x0, 0x3000
    affc:      	add	x0, x0, #0xfe5
    b000:      	ret
    b004:      	adrp	x0, 0x4000
    b008:      	add	x0, x0, #0x4b1
    b00c:      	ret
    b010:      	adrp	x0, 0x3000
    b014:      	add	x0, x0, #0x4e2
    b018:      	ret
    b01c:      	adrp	x0, 0x2000
    b020:      	add	x0, x0, #0xfb3
    b024:      	ret
    b028:      	adrp	x0, 0x3000
    b02c:      	add	x0, x0, #0xd24
    b030:      	ret
    b034:      	adrp	x0, 0x3000
    b038:      	add	x0, x0, #0x839
    b03c:      	ret
    b040:      	adrp	x0, 0x3000
    b044:      	add	x0, x0, #0x83f
    b048:      	ret
    b04c:      	adrp	x0, 0x4000
    b050:      	add	x0, x0, #0x9a5
    b054:      	ret
    b058:      	adrp	x0, 0x3000
    b05c:      	add	x0, x0, #0x9b3
    b060:      	ret
    b064:      	adrp	x0, 0x3000
    b068:      	add	x0, x0, #0xfeb
    b06c:      	ret
    b070:      	adrp	x0, 0x3000
    b074:      	add	x0, x0, #0x4fd
    b078:      	ret
    b07c:      	adrp	x0, 0x3000
    b080:      	add	x0, x0, #0xd43
    b084:      	ret
    b088:      	adrp	x0, 0x4000
    b08c:      	add	x0, x0, #0x2a9
    b090:      	ret
    b094:      	adrp	x0, 0x3000
    b098:      	add	x0, x0, #0xcb
    b09c:      	ret
    b0a0:      	adrp	x0, 0x3000
    b0a4:      	add	x0, x0, #0x9c0
    b0a8:      	ret
    b0ac:      	adrp	x0, 0x3000
    b0b0:      	add	x0, x0, #0xe81
    b0b4:      	ret
    b0b8:      	adrp	x0, 0x4000
    b0bc:      	add	x0, x0, #0x734
    b0c0:      	ret
    b0c4:      	adrp	x0, 0x3000
    b0c8:      	add	x0, x0, #0x52d
    b0cc:      	ret
    b0d0:      	adrp	x0, 0x3000
    b0d4:      	add	x0, x0, #0xd74
    b0d8:      	ret
    b0dc:      	adrp	x0, 0x4000
    b0e0:      	add	x0, x0, #0x87d
    b0e4:      	ret
    b0e8:      	adrp	x0, 0x4000
    b0ec:      	add	x0, x0, #0xa96
    b0f0:      	ret
    b0f4:      	adrp	x0, 0x3000
    b0f8:      	add	x0, x0, #0xad6
    b0fc:      	ret
    b100:      	adrp	x0, 0x2000
    b104:      	add	x0, x0, #0xd65
    b108:      	ret
    b10c:      	adrp	x0, 0x3000
    b110:      	add	x0, x0, #0xc30
    b114:      	ret
    b118:      	adrp	x0, 0x4000
    b11c:      	add	x0, x0, #0x1b4
    b120:      	ret
    b124:      	adrp	x0, 0x4000
    b128:      	add	x0, x0, #0x2af
    b12c:      	ret
    b130:      	adrp	x0, 0x4000
    b134:      	add	x0, x0, #0x86a
    b138:      	ret
    b13c:      	adrp	x0, 0x3000
    b140:      	add	x0, x0, #0x736
    b144:      	ret
    b148:      	adrp	x0, 0x4000
    b14c:      	add	x0, x0, #0x86f
    b150:      	ret
    b154:      	adrp	x0, 0x4000
    b158:      	add	x0, x0, #0x723
    b15c:      	ret
    b160:      	adrp	x0, 0x3000
    b164:      	add	x0, x0, #0xd50
    b168:      	ret
    b16c:      	adrp	x0, 0x3000
    b170:      	add	x0, x0, #0x846
    b174:      	ret
    b178:      	adrp	x0, 0x3000
    b17c:      	add	x0, x0, #0xe61
    b180:      	ret
    b184:      	adrp	x0, 0x2000
    b188:      	add	x0, x0, #0xc9e
    b18c:      	ret
    b190:      	adrp	x0, 0x4000
    b194:      	add	x0, x0, #0x1a2
    b198:      	ret
    b19c:      	adrp	x0, 0x4000
    b1a0:      	add	x0, x0, #0xa5a
    b1a4:      	ret
    b1a8:      	adrp	x0, 0x4000
    b1ac:      	add	x0, x0, #0x99b
    b1b0:      	ret
    b1b4:      	adrp	x0, 0x4000
    b1b8:      	add	x0, x0, #0xcc0
    b1bc:      	ret
    b1c0:      	adrp	x0, 0x3000
    b1c4:      	add	x0, x0, #0xacc
    b1c8:      	ret
    b1cc:      	adrp	x0, 0x4000
    b1d0:      	add	x0, x0, #0x437
    b1d4:      	ret
    b1d8:      	adrp	x0, 0x4000
    b1dc:      	add	x0, x0, #0xcb9
    b1e0:      	ret
    b1e4:      	adrp	x0, 0x3000
    b1e8:      	add	x0, x0, #0xa4
    b1ec:      	ret
    b1f0:      	adrp	x0, 0x4000
    b1f4:      	add	x0, x0, #0x29c
    b1f8:      	ret
    b1fc:      	adrp	x0, 0x4000
    b200:      	add	x0, x0, #0xb73
    b204:      	ret
    b208:      	adrp	x0, 0x3000
    b20c:      	add	x0, x0, #0x222
    b210:      	ret
    b214:      	adrp	x0, 0x4000
    b218:      	add	x0, x0, #0xb80
    b21c:      	ret
    b220:      	adrp	x0, 0x3000
    b224:      	add	x0, x0, #0x4dc
    b228:      	ret
    b22c:      	adrp	x0, 0x2000
    b230:      	add	x0, x0, #0xbff
    b234:      	ret
    b238:      	adrp	x0, 0x2000
    b23c:      	add	x0, x0, #0xa95
    b240:      	ret
    b244:      	adrp	x0, 0x3000
    b248:      	add	x0, x0, #0xff5
    b24c:      	ret
    b250:      	adrp	x0, 0x2000
    b254:      	add	x0, x0, #0xc1d
    b258:      	ret
    b25c:      	adrp	x0, 0x2000
    b260:      	add	x0, x0, #0xd4e
    b264:      	ret
    b268:      	adrp	x0, 0x3000
    b26c:      	add	x0, x0, #0x507
    b270:      	ret
    b274:      	adrp	x0, 0x2000
    b278:      	add	x0, x0, #0xb65
    b27c:      	ret
    b280:      	adrp	x0, 0x3000
    b284:      	add	x0, x0, #0x72b
    b288:      	ret
    b28c:      	adrp	x0, 0x4000
    b290:      	add	x0, x0, #0x85f
    b294:      	ret
    b298:      	adrp	x0, 0x3000
    b29c:      	add	x0, x0, #0x6bf
    b2a0:      	ret
    b2a4:      	adrp	x0, 0x2000
    b2a8:      	add	x0, x0, #0xe75
    b2ac:      	ret
    b2b0:      	adrp	x0, 0x4000
    b2b4:      	add	x0, x0, #0xa7f
    b2b8:      	ret
    b2bc:      	adrp	x0, 0x2000
    b2c0:      	add	x0, x0, #0xfbc
    b2c4:      	ret
    b2c8:      	adrp	x0, 0x4000
    b2cc:      	add	x0, x0, #0xa74
    b2d0:      	ret
    b2d4:      	stp	x29, x30, [sp, #-0x60]!
    b2d8:      	stp	x28, x27, [sp, #0x10]
    b2dc:      	stp	x26, x25, [sp, #0x20]
    b2e0:      	stp	x24, x23, [sp, #0x30]
    b2e4:      	stp	x22, x21, [sp, #0x40]
    b2e8:      	stp	x20, x19, [sp, #0x50]
    b2ec:      	mov	x29, sp
    b2f0:      	sub	sp, sp, #0x3a0
    b2f4:      	mrs	x24, TPIDR_EL0
    b2f8:      	mov	x19, x8
    b2fc:      	mov	w1, wzr
    b300:      	ldr	x8, [x24, #0x28]
    b304:      	mov	x0, x19
    b308:      	mov	w2, #0x8a8              // =2216
    b30c:      	stur	x8, [x29, #-0x18]
    b310:      	bl	0x1d5b0 <memset@plt>
    b314:      	bl	0xd288 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4274>
    b318:      	tbz	w0, #0x0, 0xb41c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2408>
    b31c:      	bl	0x91d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1c4>
    b320:      	cbz	w0, 0xb6d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x26c0>
    b324:      	bl	0x91ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x198>
    b328:      	cbz	w0, 0xb6d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x26c0>
    b32c:      	mov	w0, wzr
    b330:      	bl	0x9164 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x150>
    b334:      	cbz	x0, 0xb6d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x26c0>
    b338:      	mov	x20, x0
    b33c:      	bl	0x91ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x198>
    b340:      	ldp	q1, q0, [x20, #0x20]
    b344:      	mov	w9, #0x20               // =32
    b348:      	ldp	q2, q3, [x20]
    b34c:      	cmp	w0, #0x20
    b350:      	csel	w27, w0, w9, lo
    b354:      	stp	q1, q0, [x19, #0x20]
    b358:      	stp	q2, q3, [x19]
    b35c:      	ldp	q1, q0, [x20, #0x60]
    b360:      	ldp	q2, q3, [x20, #0x40]
    b364:      	stp	q1, q0, [x19, #0x60]
    b368:      	stp	q2, q3, [x19, #0x40]
    b36c:      	ldr	d0, [x20, #0x80]
    b370:      	str	d0, [x19, #0x200]
    b374:      	ldr	w8, [x20, #0x88]
    b378:      	str	w27, [x19, #0x20c]
    b37c:      	str	w8, [x19, #0x208]
    b380:      	cbz	w0, 0xb480 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x246c>
    b384:      	mov	x23, xzr
    b388:      	mov	w21, wzr
    b38c:      	mov	w20, wzr
    b390:      	mov	w22, wzr
    b394:      	mov	w28, w0
    b398:      	add	x26, x19, #0x22c
    b39c:      	str	x24, [sp]
    b3a0:      	b	0xb3f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x23dc>
    b3a4:      	ldr	w8, [x24, #0x8]
    b3a8:      	stur	w8, [x26, #-0x1c]
    b3ac:      	ldr	d0, [x24]
    b3b0:      	stur	d0, [x26, #-0x18]
    b3b4:      	ldr	w8, [x24, #0x20]
    b3b8:      	stp	w8, w25, [x26, #-0x10]
    b3bc:      	ldur	d0, [x24, #0x2c]
    b3c0:      	str	w0, [x26]
    b3c4:      	fmov	w8, s0
    b3c8:      	stur	d0, [x26, #-0x8]
    b3cc:      	cmp	w21, w0
    b3d0:      	csel	w22, w23, w22, lt
    b3d4:      	csel	w21, w21, w0, gt
    b3d8:      	cmp	w20, w8
    b3dc:      	csel	w20, w20, w8, hi
    b3e0:      	add	x23, x23, #0x1
    b3e4:      	add	x26, x26, #0x28
    b3e8:      	cmp	x28, x23
    b3ec:      	b.eq	0xb468 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2454>
    b3f0:      	mov	w0, w23
    b3f4:      	bl	0x9120 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10c>
    b3f8:      	cbz	x0, 0xb3e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x23cc>
    b3fc:      	ldr	w25, [x0, #0x24]
    b400:      	mov	x24, x0
    b404:      	mov	w0, w25
    b408:      	bl	0x9488 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x474>
    b40c:      	cmp	x23, x27
    b410:      	b.lo	0xb3a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2390>
    b414:      	ldr	w8, [x24, #0x2c]
    b418:      	b	0xb3cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x23b8>
    b41c:      	ldr	x8, [x24, #0x28]
    b420:      	ldur	x9, [x29, #-0x18]
    b424:      	cmp	x8, x9
    b428:      	b.ne	0xb830 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x281c>
    b42c:      	adrp	x8, 0x22000
    b430:      	adrp	x0, 0x2000
    b434:      	add	x0, x0, #0xc28
    b438:      	ldr	x8, [x8, #0x108]
    b43c:      	mov	w1, #0x25               // =37
    b440:      	mov	w2, #0x1                // =1
    b444:      	add	x3, x8, #0x130
    b448:      	add	sp, sp, #0x3a0
    b44c:      	ldp	x20, x19, [sp, #0x50]
    b450:      	ldp	x22, x21, [sp, #0x40]
    b454:      	ldp	x24, x23, [sp, #0x30]
    b458:      	ldp	x26, x25, [sp, #0x20]
    b45c:      	ldp	x28, x27, [sp, #0x10]
    b460:      	ldp	x29, x30, [sp], #0x60
    b464:      	b	0x1d5c0 <fwrite@plt>
    b468:      	cmp	w21, #0x0
    b46c:      	b.le	0xb490 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x247c>
    b470:      	mov	w0, w21
    b474:      	mov	w1, w20
    b478:      	bl	0x9914 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x900>
    b47c:      	b	0xb494 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2480>
    b480:      	mov	w21, wzr
    b484:      	mov	w20, wzr
    b488:      	mov	w22, wzr
    b48c:      	b	0xb498 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2484>
    b490:      	mov	w0, wzr
    b494:      	ldr	x24, [sp]
    b498:      	sxtw	x8, w20
    b49c:      	str	w0, [x19, #0x714]
    b4a0:      	add	w9, w0, w21
    b4a4:      	mov	w0, w22
    b4a8:      	str	w9, [x19, #0x710]
    b4ac:      	str	x8, [x19, #0x718]
    b4b0:      	bl	0x9120 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10c>
    b4b4:      	cbz	x0, 0xb6d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x26c0>
    b4b8:      	ldr	w8, [x0, #0x24]
    b4bc:      	mov	x21, x0
    b4c0:      	add	x23, sp, #0x10
    b4c4:      	mov	w0, w8
    b4c8:      	bl	0xa520 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x150c>
    b4cc:      	ldr	w8, [x21, #0x20]
    b4d0:      	mov	x1, x0
    b4d4:      	cmp	w8, #0x10
    b4d8:      	b.hi	0xb4ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x24d8>
    b4dc:      	nop
    b4e0:      	adr	x9, 0x219a0
    b4e4:      	ldr	x21, [x9, x8, lsl #3]
    b4e8:      	b	0xb4f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x24e0>
    b4ec:      	adrp	x21, 0x2000
    b4f0:      	add	x21, x21, #0xbff
    b4f4:      	add	x0, x19, #0x7a2
    b4f8:      	mov	w2, #0x80               // =128
    b4fc:      	bl	0x1d5d0 <strncpy@plt>
    b500:      	adrp	x22, 0x4000
    b504:      	add	x22, x22, #0xaa3
    b508:      	mov	x0, x21
    b50c:      	mov	x1, x22
    b510:      	bl	0x1d4f0 <strstr@plt>
    b514:      	cmp	x0, #0x0
    b518:      	add	x0, x19, #0x722
    b51c:      	mov	w2, #0x80               // =128
    b520:      	csel	x1, x21, x22, eq
    b524:      	mov	w3, #0x80               // =128
    b528:      	mov	w4, #0x18               // =24
    b52c:      	bl	0x1d5e0 <__strncpy_chk2@plt>
    b530:      	movi	v0.2d, #0000000000000000
    b534:      	add	x0, sp, #0xc
    b538:      	add	x1, sp, #0x8
    b53c:      	add	x2, sp, #0x280
    b540:      	add	x3, sp, #0x1b0
    b544:      	add	x4, sp, #0xe0
    b548:      	strb	wzr, [sp, #0xc]
    b54c:      	strb	wzr, [sp, #0x8]
    b550:      	stp	q0, q0, [x23, #0xf0]
    b554:      	stp	q0, q0, [x23, #0x110]
    b558:      	stp	q0, q0, [x23, #0x130]
    b55c:      	stp	q0, q0, [x23, #0x150]
    b560:      	stp	q0, q0, [x23, #0x170]
    b564:      	stp	q0, q0, [x23, #0x1a0]
    b568:      	stp	q0, q0, [x23, #0x1c0]
    b56c:      	stp	q0, q0, [x23, #0x1e0]
    b570:      	stp	q0, q0, [x23, #0x200]
    b574:      	stp	q0, q0, [x23, #0x220]
    b578:      	stp	q0, q0, [x23, #0x240]
    b57c:      	stp	q0, q0, [x23, #0x270]
    b580:      	stp	q0, q0, [x23, #0x290]
    b584:      	stp	q0, q0, [x23, #0x2b0]
    b588:      	stp	q0, q0, [x23, #0x2d0]
    b58c:      	stp	q0, q0, [x23, #0x2f0]
    b590:      	stp	q0, q0, [x23, #0x310]
    b594:      	str	xzr, [sp, #0x340]
    b598:      	str	xzr, [sp, #0x270]
    b59c:      	str	xzr, [sp, #0x1a0]
    b5a0:      	stp	q0, q0, [x23, #0xd0]
    b5a4:      	bl	0xdf1c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4f08>
    b5a8:      	add	x0, x19, #0x80
    b5ac:      	add	x1, sp, #0x280
    b5b0:      	mov	w2, #0x80               // =128
    b5b4:      	mov	w3, #0x80               // =128
    b5b8:      	mov	w4, #0xc8               // =200
    b5bc:      	bl	0x1d5e0 <__strncpy_chk2@plt>
    b5c0:      	add	x0, x19, #0x100
    b5c4:      	add	x1, sp, #0x1b0
    b5c8:      	mov	w2, #0x80               // =128
    b5cc:      	mov	w3, #0x80               // =128
    b5d0:      	mov	w4, #0xc8               // =200
    b5d4:      	bl	0x1d5e0 <__strncpy_chk2@plt>
    b5d8:      	adrp	x3, 0x4000
    b5dc:      	add	x3, x3, #0x185
    b5e0:      	add	x0, sp, #0x10
    b5e4:      	mov	w1, #0x20               // =32
    b5e8:      	mov	w2, #0x20               // =32
    b5ec:      	mov	w4, #0x65               // =101
    b5f0:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    b5f4:      	add	x0, sp, #0x10
    b5f8:      	add	x1, x19, #0x100
    b5fc:      	bl	0x923c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x228>
    b600:      	add	x0, x19, #0x180
    b604:      	add	x1, sp, #0xe0
    b608:      	mov	w2, #0x80               // =128
    b60c:      	mov	w3, #0x80               // =128
    b610:      	mov	w4, #0xc8               // =200
    b614:      	bl	0x1d5e0 <__strncpy_chk2@plt>
    b618:      	movi	v0.2d, #0000000000000000
    b61c:      	add	x0, sp, #0x10
    b620:      	str	xzr, [sp, #0xd0]
    b624:      	stp	q0, q0, [x23, #0x80]
    b628:      	stp	q0, q0, [x23, #0xa0]
    b62c:      	stp	q0, q0, [sp, #0x10]
    b630:      	stp	q0, q0, [sp, #0x30]
    b634:      	stp	q0, q0, [sp, #0x50]
    b638:      	stp	q0, q0, [sp, #0x70]
    b63c:      	bl	0xe3a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5390>
    b640:      	add	x0, x19, #0x822
    b644:      	add	x1, sp, #0x10
    b648:      	mov	w2, #0x80               // =128
    b64c:      	mov	w3, #0x80               // =128
    b650:      	mov	w4, #0xc8               // =200
    b654:      	bl	0x1d5e0 <__strncpy_chk2@plt>
    b658:      	ldrb	w9, [sp, #0xc]
    b65c:      	ldrb	w8, [sp, #0x8]
    b660:      	ldr	w10, [x19, #0x710]
    b664:      	and	w9, w8, w9
    b668:      	cmp	w10, #0x0
    b66c:      	strb	w8, [x19, #0x720]
    b670:      	strb	w9, [sp, #0xc]
    b674:      	strb	w9, [x19, #0x721]
    b678:      	b.gt	0xb6d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x26c0>
    b67c:      	cbz	w8, 0xb704 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x26f0>
    b680:      	cmp	w9, #0x0
    b684:      	mov	w8, #0x18               // =24
    b688:      	mov	w9, #0x14               // =20
    b68c:      	csel	w4, w9, w8, eq
    b690:      	str	w4, [x19, #0x710]
    b694:      	adrp	x19, 0x4000
    b698:      	add	x19, x19, #0x185
    b69c:      	sub	x0, x29, #0x58
    b6a0:      	mov	w1, #0x20               // =32
    b6a4:      	mov	w2, #0x20               // =32
    b6a8:      	mov	x3, x19
    b6ac:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    b6b0:      	sub	x0, x29, #0x38
    b6b4:      	mov	w1, #0x20               // =32
    b6b8:      	mov	w2, #0x20               // =32
    b6bc:      	mov	x3, x19
    b6c0:      	mov	w4, #0x5                // =5
    b6c4:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    b6c8:      	sub	x0, x29, #0x38
    b6cc:      	sub	x1, x29, #0x58
    b6d0:      	bl	0x923c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x228>
    b6d4:      	ldr	x8, [x24, #0x28]
    b6d8:      	ldur	x9, [x29, #-0x18]
    b6dc:      	cmp	x8, x9
    b6e0:      	b.ne	0xb830 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x281c>
    b6e4:      	add	sp, sp, #0x3a0
    b6e8:      	ldp	x20, x19, [sp, #0x50]
    b6ec:      	ldp	x22, x21, [sp, #0x40]
    b6f0:      	ldp	x24, x23, [sp, #0x30]
    b6f4:      	ldp	x26, x25, [sp, #0x20]
    b6f8:      	ldp	x28, x27, [sp, #0x10]
    b6fc:      	ldp	x29, x30, [sp], #0x60
    b700:      	ret
    b704:      	mov	w8, #0xbdff             // =48639
    b708:      	mov	w4, #0xf                // =15
    b70c:      	movk	w8, #0x23, lsl #16
    b710:      	cmp	w20, w8
    b714:      	b.le	0xb740 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x272c>
    b718:      	cmp	w20, #0x258, lsl #12    // =0x258000
    b71c:      	b.lt	0xb788 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2774>
    b720:      	b.eq	0xb690 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x267c>
    b724:      	mov	w8, #0xac40             // =44096
    b728:      	movk	w8, #0x27, lsl #16
    b72c:      	cmp	w20, w8
    b730:      	b.eq	0xb7e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x27d4>
    b734:      	mov	w8, #0xa810             // =43024
    b738:      	movk	w8, #0x29, lsl #16
    b73c:      	b	0xb7a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x278c>
    b740:      	cmp	w20, #0x20d, lsl #12    // =0x20d000
    b744:      	b.ge	0xb770 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x275c>
    b748:      	mov	w8, #0x3998             // =14744
    b74c:      	movk	w8, #0x15, lsl #16
    b750:      	cmp	w20, w8
    b754:      	b.eq	0xb768 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2754>
    b758:      	mov	w8, #0x8a00             // =35328
    b75c:      	movk	w8, #0x1b, lsl #16
    b760:      	cmp	w20, w8
    b764:      	b.ne	0xb7b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x279c>
    b768:      	mov	w4, #0x10               // =16
    b76c:      	b	0xb690 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x267c>
    b770:      	b.eq	0xb7a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2794>
    b774:      	mov	w8, #0x9200             // =37376
    b778:      	movk	w8, #0x22, lsl #16
    b77c:      	cmp	w20, w8
    b780:      	b.eq	0xb690 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x267c>
    b784:      	b	0xb7b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x279c>
    b788:      	mov	w8, #0xbe00             // =48640
    b78c:      	movk	w8, #0x23, lsl #16
    b790:      	cmp	w20, w8
    b794:      	b.eq	0xb7e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x27d4>
    b798:      	mov	w8, #0x9f00             // =40704
    b79c:      	movk	w8, #0x24, lsl #16
    b7a0:      	cmp	w20, w8
    b7a4:      	b.ne	0xb7b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x279c>
    b7a8:      	mov	w4, #0x12               // =18
    b7ac:      	b	0xb690 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x267c>
    b7b0:      	mov	w8, #0xc6bf             // =50879
    b7b4:      	movk	w8, #0x2d, lsl #16
    b7b8:      	cmp	w20, w8
    b7bc:      	b.ls	0xb7c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x27b4>
    b7c0:      	mov	w4, #0x14               // =20
    b7c4:      	b	0xb690 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x267c>
    b7c8:      	mov	w8, #0xb97f             // =47487
    b7cc:      	movk	w8, #0x2a, lsl #16
    b7d0:      	cmp	w20, w8
    b7d4:      	b.hi	0xb7a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2794>
    b7d8:      	mov	w8, #0x32df             // =13023
    b7dc:      	movk	w8, #0x29, lsl #16
    b7e0:      	cmp	w20, w8
    b7e4:      	b.ls	0xb7f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x27dc>
    b7e8:      	mov	w4, #0x11               // =17
    b7ec:      	b	0xb690 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x267c>
    b7f0:      	mov	w8, #0xac3f             // =44095
    b7f4:      	movk	w8, #0x27, lsl #16
    b7f8:      	cmp	w20, w8
    b7fc:      	b.hi	0xb768 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2754>
    b800:      	mov	w8, #0x91bf             // =37311
    b804:      	movk	w8, #0x21, lsl #16
    b808:      	cmp	w20, w8
    b80c:      	b.ls	0xb818 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2804>
    b810:      	mov	w4, #0xd                // =13
    b814:      	b	0xb690 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x267c>
    b818:      	mov	w8, #0x773f             // =30527
    b81c:      	movk	w8, #0x1b, lsl #16
    b820:      	cmp	w20, w8
    b824:      	mov	w8, #0xa                // =10
    b828:      	cinc	w4, w8, hi
    b82c:      	b	0xb690 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x267c>
    b830:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    b834:      	stp	x29, x30, [sp, #-0x50]!
    b838:      	stp	x28, x25, [sp, #0x10]
    b83c:      	stp	x24, x23, [sp, #0x20]
    b840:      	stp	x22, x21, [sp, #0x30]
    b844:      	stp	x20, x19, [sp, #0x40]
    b848:      	mov	x29, sp
    b84c:      	sub	sp, sp, #0x930
    b850:      	mrs	x25, TPIDR_EL0
    b854:      	mov	x19, x8
    b858:      	adrp	x20, 0x26000
    b85c:      	add	x20, x20, #0x574
    b860:      	ldr	x8, [x25, #0x28]
    b864:      	mov	x0, x20
    b868:      	stur	x8, [x29, #-0x8]
    b86c:      	bl	0x1d5f0 <_ZNSt6__ndk15mutex4lockEv@plt>
    b870:      	add	x0, x20, #0x1ac
    b874:      	mov	w1, wzr
    b878:      	mov	w2, #0x208              // =520
    b87c:      	bl	0x1d5b0 <memset@plt>
    b880:      	adrp	x0, 0x4000
    b884:      	add	x0, x0, #0x881
    b888:      	mov	w1, #0x1                // =1
    b88c:      	stp	xzr, xzr, [sp, #0x8]
    b890:      	str	wzr, [sp, #0x4]
    b894:      	bl	0x1d600 <dlopen@plt>
    b898:      	cbz	x0, 0xba8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2a78>
    b89c:      	mov	x20, x0
    b8a0:      	sub	x21, x29, #0x70
    b8a4:      	bl	0x1d610 <eglGetError@plt>
    b8a8:      	mov	x8, #0x3098             // =12440
    b8ac:      	mov	w9, #0x3038             // =12344
    b8b0:      	movk	x8, #0x2, lsl #32
    b8b4:      	stur	w9, [x29, #-0x10]
    b8b8:      	str	x8, [x21, #0x58]
    b8bc:      	nop
    b8c0:      	adr	x8, 0x4eb0
    b8c4:      	ldp	q0, q1, [x8]
    b8c8:      	nop
    b8cc:      	adr	x8, 0x4ed4
    b8d0:      	stur	w9, [x29, #-0x20]
    b8d4:      	stur	w9, [x29, #-0x50]
    b8d8:      	stp	q0, q1, [x21, #0x30]
    b8dc:      	ldp	q0, q1, [x8]
    b8e0:      	add	x8, sp, #0x18
    b8e4:      	stp	q0, q1, [x21]
    b8e8:      	bl	0xb2d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x22c0>
    b8ec:      	mov	x0, xzr
    b8f0:      	bl	0x1d620 <eglGetDisplay@plt>
    b8f4:      	mov	x21, x0
    b8f8:      	bl	0x1d610 <eglGetError@plt>
    b8fc:      	cbz	x21, 0xbab0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2a9c>
    b900:      	add	x1, sp, #0x8
    b904:      	add	x2, sp, #0x4
    b908:      	mov	x0, x21
    b90c:      	bl	0x1d630 <eglInitialize@plt>
    b910:      	mov	w22, w0
    b914:      	bl	0x1d610 <eglGetError@plt>
    b918:      	cmp	w22, #0x1
    b91c:      	b.ne	0xbac4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2ab0>
    b920:      	sub	x1, x29, #0x70
    b924:      	add	x2, sp, #0x10
    b928:      	add	x4, sp, #0xc
    b92c:      	mov	x0, x21
    b930:      	mov	w3, #0x1                // =1
    b934:      	bl	0x1d640 <eglChooseConfig@plt>
    b938:      	mov	w22, w0
    b93c:      	bl	0x1d610 <eglGetError@plt>
    b940:      	cmp	w22, #0x1
    b944:      	mov	w2, w0
    b948:      	b.ne	0xbad8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2ac4>
    b94c:      	ldr	w8, [sp, #0xc]
    b950:      	cbz	w8, 0xbad8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2ac4>
    b954:      	ldr	x1, [sp, #0x10]
    b958:      	cbz	x1, 0xbad8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2ac4>
    b95c:      	sub	x2, x29, #0x40
    b960:      	mov	x0, x21
    b964:      	bl	0x1d650 <eglCreatePbufferSurface@plt>
    b968:      	mov	x23, x0
    b96c:      	bl	0x1d610 <eglGetError@plt>
    b970:      	cbz	x23, 0xbc24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2c10>
    b974:      	ldr	x1, [sp, #0x10]
    b978:      	sub	x3, x29, #0x18
    b97c:      	mov	x0, x21
    b980:      	mov	x2, xzr
    b984:      	bl	0x1d660 <eglCreateContext@plt>
    b988:      	mov	x22, x0
    b98c:      	bl	0x1d610 <eglGetError@plt>
    b990:      	cbz	x22, 0xbc48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2c34>
    b994:      	mov	x0, x21
    b998:      	mov	x1, x23
    b99c:      	mov	x2, x23
    b9a0:      	mov	x3, x22
    b9a4:      	bl	0x1d670 <eglMakeCurrent@plt>
    b9a8:      	mov	w24, w0
    b9ac:      	bl	0x1d610 <eglGetError@plt>
    b9b0:      	cmp	w24, #0x1
    b9b4:      	b.ne	0xbc5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2c48>
    b9b8:      	mov	w0, #0x1f00             // =7936
    b9bc:      	bl	0x1d680 <glGetString@plt>
    b9c0:      	adrp	x24, 0x26000
    b9c4:      	add	x24, x24, #0x720
    b9c8:      	mov	x1, x0
    b9cc:      	mov	x0, x24
    b9d0:      	mov	w2, #0x7f               // =127
    b9d4:      	bl	0x1d5d0 <strncpy@plt>
    b9d8:      	mov	w0, #0x1f01             // =7937
    b9dc:      	bl	0x1d680 <glGetString@plt>
    b9e0:      	mov	x1, x0
    b9e4:      	add	x0, x24, #0x80
    b9e8:      	mov	w2, #0x7f               // =127
    b9ec:      	bl	0x1d5d0 <strncpy@plt>
    b9f0:      	mov	w0, #0x1f02             // =7938
    b9f4:      	bl	0x1d680 <glGetString@plt>
    b9f8:      	mov	x1, x0
    b9fc:      	add	x0, x24, #0x100
    ba00:      	mov	w2, #0x7f               // =127
    ba04:      	bl	0x1d5d0 <strncpy@plt>
    ba08:      	mov	w0, #0x8b8c             // =35724
    ba0c:      	bl	0x1d680 <glGetString@plt>
    ba10:      	mov	x1, x0
    ba14:      	add	x0, x24, #0x180
    ba18:      	mov	w2, #0x7f               // =127
    ba1c:      	bl	0x1d5d0 <strncpy@plt>
    ba20:      	add	x8, sp, #0x18
    ba24:      	add	x0, x24, #0x80
    ba28:      	add	x1, sp, #0x18
    ba2c:      	add	x2, x24, #0x100
    ba30:      	add	x3, x8, #0x80
    ba34:      	bl	0x9bc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb4>
    ba38:      	str	w0, [x24, #0x204]
    ba3c:      	cbnz	w0, 0xba68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2a54>
    ba40:      	ldrb	w0, [sp, #0x738]
    ba44:      	ldrb	w1, [sp, #0x739]
    ba48:      	adrp	x24, 0x26000
    ba4c:      	add	x24, x24, #0x820
    ba50:      	mov	x2, x24
    ba54:      	bl	0xa444 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1430>
    ba58:      	mov	w1, w0
    ba5c:      	str	w0, [x24, #0x104]
    ba60:      	mov	w0, #0x6                // =6
    ba64:      	bl	0x93f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3e4>
    ba68:      	bl	0x1d610 <eglGetError@plt>
    ba6c:      	mov	x0, x21
    ba70:      	mov	x1, xzr
    ba74:      	mov	x2, xzr
    ba78:      	mov	x3, xzr
    ba7c:      	bl	0x1d670 <eglMakeCurrent@plt>
    ba80:      	bl	0x1d610 <eglGetError@plt>
    ba84:      	mov	w24, #0x1               // =1
    ba88:      	b	0xbb04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2af0>
    ba8c:      	adrp	x8, 0x22000
    ba90:      	adrp	x0, 0x3000
    ba94:      	add	x0, x0, #0x852
    ba98:      	ldr	x8, [x8, #0x108]
    ba9c:      	mov	w1, #0x19               // =25
    baa0:      	mov	w2, #0x1                // =1
    baa4:      	add	x3, x8, #0x130
    baa8:      	bl	0x1d5c0 <fwrite@plt>
    baac:      	b	0xbbd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2bc4>
    bab0:      	adrp	x8, 0x22000
    bab4:      	mov	w2, w0
    bab8:      	adrp	x1, 0x4000
    babc:      	add	x1, x1, #0x4ba
    bac0:      	b	0xbae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2ad0>
    bac4:      	adrp	x8, 0x22000
    bac8:      	mov	w2, w0
    bacc:      	adrp	x1, 0x3000
    bad0:      	add	x1, x1, #0xe8a
    bad4:      	b	0xbae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2ad0>
    bad8:      	adrp	x8, 0x22000
    badc:      	adrp	x1, 0x4000
    bae0:      	add	x1, x1, #0xcd8
    bae4:      	ldr	x8, [x8, #0x108]
    bae8:      	add	x0, x8, #0x130
    baec:      	bl	0x1d5a0 <fprintf@plt>
    baf0:      	mov	x22, xzr
    baf4:      	mov	x23, xzr
    baf8:      	bl	0x1d610 <eglGetError@plt>
    bafc:      	cmp	x21, #0x0
    bb00:      	cset	w24, ne
    bb04:      	cbz	x23, 0xbb48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2b34>
    bb08:      	cbz	w24, 0xbb48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2b34>
    bb0c:      	mov	x0, x21
    bb10:      	mov	x1, x23
    bb14:      	bl	0x1d690 <eglDestroySurface@plt>
    bb18:      	cmp	w0, #0x1
    bb1c:      	b.eq	0xbb48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2b34>
    bb20:      	bl	0x1d610 <eglGetError@plt>
    bb24:      	sub	w8, w0, #0x3, lsl #12   // =0x3000
    bb28:      	mov	w2, w0
    bb2c:      	cmp	w8, #0xd
    bb30:      	b.hi	0xbba8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2b94>
    bb34:      	mov	w9, #0x1                // =1
    bb38:      	lsl	w8, w9, w8
    bb3c:      	mov	w9, #0x2101             // =8449
    bb40:      	tst	w8, w9
    bb44:      	b.eq	0xbba8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2b94>
    bb48:      	cmp	x22, #0x0
    bb4c:      	csel	w8, wzr, w24, eq
    bb50:      	cmp	w8, #0x1
    bb54:      	b.ne	0xbbd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2bbc>
    bb58:      	mov	x0, x21
    bb5c:      	mov	x1, x22
    bb60:      	bl	0x1d6a0 <eglDestroyContext@plt>
    bb64:      	cmp	w0, #0x1
    bb68:      	b.eq	0xbbd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2bbc>
    bb6c:      	bl	0x1d610 <eglGetError@plt>
    bb70:      	mov	w8, #0x3006             // =12294
    bb74:      	cmp	w0, w8
    bb78:      	b.eq	0xbbd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2bbc>
    bb7c:      	mov	w8, #0x3008             // =12296
    bb80:      	mov	w2, w0
    bb84:      	cmp	w0, w8
    bb88:      	b.eq	0xbbd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2bbc>
    bb8c:      	adrp	x8, 0x22000
    bb90:      	adrp	x1, 0x3000
    bb94:      	add	x1, x1, #0xde
    bb98:      	ldr	x8, [x8, #0x108]
    bb9c:      	add	x0, x8, #0x130
    bba0:      	bl	0x1d5a0 <fprintf@plt>
    bba4:      	b	0xbbd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2bbc>
    bba8:      	adrp	x8, 0x22000
    bbac:      	adrp	x1, 0x3000
    bbb0:      	add	x1, x1, #0x27c
    bbb4:      	ldr	x8, [x8, #0x108]
    bbb8:      	add	x0, x8, #0x130
    bbbc:      	bl	0x1d5a0 <fprintf@plt>
    bbc0:      	cmp	x22, #0x0
    bbc4:      	csel	w8, wzr, w24, eq
    bbc8:      	cmp	w8, #0x1
    bbcc:      	b.eq	0xbb58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2b44>
    bbd0:      	mov	x0, x20
    bbd4:      	bl	0x1d6b0 <dlclose@plt>
    bbd8:      	adrp	x1, 0x26000
    bbdc:      	add	x1, x1, #0x720
    bbe0:      	mov	x0, x19
    bbe4:      	mov	w2, #0x208              // =520
    bbe8:      	bl	0x1d540 <memcpy@plt>
    bbec:      	adrp	x0, 0x26000
    bbf0:      	add	x0, x0, #0x574
    bbf4:      	bl	0x1d6c0 <_ZNSt6__ndk15mutex6unlockEv@plt>
    bbf8:      	ldr	x8, [x25, #0x28]
    bbfc:      	ldur	x9, [x29, #-0x8]
    bc00:      	cmp	x8, x9
    bc04:      	b.ne	0xbc7c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2c68>
    bc08:      	add	sp, sp, #0x930
    bc0c:      	ldp	x20, x19, [sp, #0x40]
    bc10:      	ldp	x22, x21, [sp, #0x30]
    bc14:      	ldp	x24, x23, [sp, #0x20]
    bc18:      	ldp	x28, x25, [sp, #0x10]
    bc1c:      	ldp	x29, x30, [sp], #0x50
    bc20:      	ret
    bc24:      	adrp	x8, 0x22000
    bc28:      	mov	w2, w0
    bc2c:      	adrp	x1, 0x3000
    bc30:      	add	x1, x1, #0x740
    bc34:      	ldr	x8, [x8, #0x108]
    bc38:      	add	x0, x8, #0x130
    bc3c:      	bl	0x1d5a0 <fprintf@plt>
    bc40:      	mov	x22, xzr
    bc44:      	b	0xbaf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2ae4>
    bc48:      	adrp	x8, 0x22000
    bc4c:      	mov	w2, w0
    bc50:      	adrp	x1, 0x3000
    bc54:      	add	x1, x1, #0xaf0
    bc58:      	b	0xbc6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2c58>
    bc5c:      	adrp	x8, 0x22000
    bc60:      	mov	w2, w0
    bc64:      	adrp	x1, 0x3000
    bc68:      	add	x1, x1, #0x241
    bc6c:      	ldr	x8, [x8, #0x108]
    bc70:      	add	x0, x8, #0x130
    bc74:      	bl	0x1d5a0 <fprintf@plt>
    bc78:      	b	0xbaf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2ae4>
    bc7c:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    bc80:      	stp	x29, x30, [sp, #-0x40]!
    bc84:      	str	x28, [sp, #0x10]
    bc88:      	stp	x22, x21, [sp, #0x20]
    bc8c:      	stp	x20, x19, [sp, #0x30]
    bc90:      	mov	x29, sp
    bc94:      	sub	sp, sp, #0x1, lsl #12   // =0x1000
    bc98:      	sub	sp, sp, #0x180
    bc9c:      	mrs	x21, TPIDR_EL0
    bca0:      	mov	x19, x8
    bca4:      	ldr	x8, [x21, #0x28]
    bca8:      	stur	x8, [x29, #-0x8]
    bcac:      	bl	0x1d610 <eglGetError@plt>
    bcb0:      	cmp	w0, #0x3, lsl #12       // =0x3000
    bcb4:      	b.eq	0xbcd4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2cc0>
    bcb8:      	adrp	x8, 0x22000
    bcbc:      	mov	w2, w0
    bcc0:      	adrp	x1, 0x3000
    bcc4:      	add	x1, x1, #0x86c
    bcc8:      	ldr	x8, [x8, #0x108]
    bccc:      	add	x0, x8, #0x130
    bcd0:      	bl	0x1d5a0 <fprintf@plt>
    bcd4:      	bl	0x1d6d0 <eglGetCurrentContext@plt>
    bcd8:      	cbz	x0, 0xbe54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2e40>
    bcdc:      	adrp	x20, 0x26000
    bce0:      	add	x20, x20, #0x720
    bce4:      	mov	w1, wzr
    bce8:      	mov	x0, x20
    bcec:      	mov	w2, #0x208              // =520
    bcf0:      	bl	0x1d5b0 <memset@plt>
    bcf4:      	mov	w0, #0x1f00             // =7936
    bcf8:      	bl	0x1d680 <glGetString@plt>
    bcfc:      	mov	x1, x0
    bd00:      	mov	x0, x20
    bd04:      	mov	w2, #0x7f               // =127
    bd08:      	bl	0x1d5d0 <strncpy@plt>
    bd0c:      	mov	w0, #0x1f01             // =7937
    bd10:      	bl	0x1d680 <glGetString@plt>
    bd14:      	mov	x1, x0
    bd18:      	add	x0, x20, #0x80
    bd1c:      	mov	w2, #0x7f               // =127
    bd20:      	bl	0x1d5d0 <strncpy@plt>
    bd24:      	mov	w0, #0x1f02             // =7938
    bd28:      	bl	0x1d680 <glGetString@plt>
    bd2c:      	mov	x1, x0
    bd30:      	add	x0, x20, #0x100
    bd34:      	mov	w2, #0x7f               // =127
    bd38:      	bl	0x1d5d0 <strncpy@plt>
    bd3c:      	mov	w0, #0x8b8c             // =35724
    bd40:      	bl	0x1d680 <glGetString@plt>
    bd44:      	mov	x1, x0
    bd48:      	add	x0, x20, #0x180
    bd4c:      	mov	w2, #0x7f               // =127
    bd50:      	bl	0x1d5d0 <strncpy@plt>
    bd54:      	add	x8, sp, #0x8b0
    bd58:      	bl	0xb2d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x22c0>
    bd5c:      	add	x8, sp, #0x8
    bd60:      	add	x22, sp, #0x8
    bd64:      	bl	0xb2d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x22c0>
    bd68:      	add	x0, x20, #0x80
    bd6c:      	add	x1, sp, #0x8b0
    bd70:      	add	x2, x20, #0x100
    bd74:      	add	x3, x22, #0x80
    bd78:      	bl	0x9bc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb4>
    bd7c:      	str	w0, [x20, #0x204]
    bd80:      	cbnz	w0, 0xbdf0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2ddc>
    bd84:      	add	x8, sp, #0x8b0
    bd88:      	add	x20, sp, #0x8b0
    bd8c:      	bl	0xb2d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x22c0>
    bd90:      	ldrb	w0, [x20, #0x720]
    bd94:      	ldrb	w1, [x20, #0x721]
    bd98:      	adrp	x20, 0x26000
    bd9c:      	add	x20, x20, #0x820
    bda0:      	mov	x2, x20
    bda4:      	bl	0xa444 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1430>
    bda8:      	str	w0, [x20, #0x104]
    bdac:      	adrp	x20, 0x4000
    bdb0:      	add	x20, x20, #0x185
    bdb4:      	mov	w4, w0
    bdb8:      	sub	x0, x29, #0x28
    bdbc:      	mov	w1, #0x20               // =32
    bdc0:      	mov	w2, #0x20               // =32
    bdc4:      	mov	x3, x20
    bdc8:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    bdcc:      	add	x0, sp, #0x8
    bdd0:      	mov	w1, #0x20               // =32
    bdd4:      	mov	w2, #0x20               // =32
    bdd8:      	mov	x3, x20
    bddc:      	mov	w4, #0x6                // =6
    bde0:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    bde4:      	add	x0, sp, #0x8
    bde8:      	sub	x1, x29, #0x28
    bdec:      	bl	0x923c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x228>
    bdf0:      	bl	0x1d6e0 <glGetError@plt>
    bdf4:      	cbz	w0, 0xbe14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2e00>
    bdf8:      	adrp	x8, 0x22000
    bdfc:      	mov	w2, w0
    be00:      	adrp	x1, 0x2000
    be04:      	add	x1, x1, #0xb81
    be08:      	ldr	x8, [x8, #0x108]
    be0c:      	add	x0, x8, #0x130
    be10:      	bl	0x1d5a0 <fprintf@plt>
    be14:      	adrp	x1, 0x26000
    be18:      	add	x1, x1, #0x720
    be1c:      	mov	x0, x19
    be20:      	mov	w2, #0x208              // =520
    be24:      	bl	0x1d540 <memcpy@plt>
    be28:      	ldr	x8, [x21, #0x28]
    be2c:      	ldur	x9, [x29, #-0x8]
    be30:      	cmp	x8, x9
    be34:      	b.ne	0xbe84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2e70>
    be38:      	add	sp, sp, #0x1, lsl #12   // =0x1000
    be3c:      	add	sp, sp, #0x180
    be40:      	ldp	x20, x19, [sp, #0x30]
    be44:      	ldr	x28, [sp, #0x10]
    be48:      	ldp	x22, x21, [sp, #0x20]
    be4c:      	ldp	x29, x30, [sp], #0x40
    be50:      	ret
    be54:      	ldr	x8, [x21, #0x28]
    be58:      	ldur	x9, [x29, #-0x8]
    be5c:      	cmp	x8, x9
    be60:      	b.ne	0xbe84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2e70>
    be64:      	mov	x8, x19
    be68:      	add	sp, sp, #0x1, lsl #12   // =0x1000
    be6c:      	add	sp, sp, #0x180
    be70:      	ldp	x20, x19, [sp, #0x30]
    be74:      	ldr	x28, [sp, #0x10]
    be78:      	ldp	x22, x21, [sp, #0x20]
    be7c:      	ldp	x29, x30, [sp], #0x40
    be80:      	b	0xb834 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2820>
    be84:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    be88:      	sub	sp, sp, #0x100
    be8c:      	stp	x29, x30, [sp, #0xa0]
    be90:      	stp	x28, x27, [sp, #0xb0]
    be94:      	stp	x26, x25, [sp, #0xc0]
    be98:      	stp	x24, x23, [sp, #0xd0]
    be9c:      	stp	x22, x21, [sp, #0xe0]
    bea0:      	stp	x20, x19, [sp, #0xf0]
    bea4:      	add	x29, sp, #0xa0
    bea8:      	mrs	x25, TPIDR_EL0
    beac:      	adrp	x26, 0x26000
    beb0:      	ldr	x8, [x25, #0x28]
    beb4:      	stur	x8, [x29, #-0x8]
    beb8:      	ldrb	w8, [x26, #0x570]
    bebc:      	tbnz	w8, #0x0, 0xc074 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3060>
    bec0:      	movi	v0.2d, #0000000000000000
    bec4:      	str	x0, [sp, #0x10]
    bec8:      	adrp	x21, 0x26000
    becc:      	add	x21, x21, #0x59c
    bed0:      	adrp	x0, 0x3000
    bed4:      	add	x0, x0, #0x76f
    bed8:      	mov	w1, #0x2                // =2
    bedc:      	strb	wzr, [x21, #0x180]
    bee0:      	stp	q0, q0, [x21]
    bee4:      	stp	q0, q0, [x21, #0x20]
    bee8:      	stp	q0, q0, [x21, #0x40]
    beec:      	stp	q0, q0, [x21, #0x60]
    bef0:      	stp	q0, q0, [x21, #0x80]
    bef4:      	stp	q0, q0, [x21, #0xa0]
    bef8:      	stp	q0, q0, [x21, #0xc0]
    befc:      	stp	q0, q0, [x21, #0xe0]
    bf00:      	stp	q0, q0, [x21, #0x100]
    bf04:      	stp	q0, q0, [x21, #0x120]
    bf08:      	stp	q0, q0, [x21, #0x140]
    bf0c:      	stp	q0, q0, [x21, #0x160]
    bf10:      	bl	0x1d600 <dlopen@plt>
    bf14:      	mov	x19, x0
    bf18:      	cbnz	x0, 0xbfc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2fb0>
    bf1c:      	adrp	x0, 0x3000
    bf20:      	add	x0, x0, #0x2b0
    bf24:      	mov	w1, #0x2                // =2
    bf28:      	bl	0x1d600 <dlopen@plt>
    bf2c:      	mov	x19, x0
    bf30:      	cbnz	x0, 0xbfc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2fb0>
    bf34:      	adrp	x0, 0x2000
    bf38:      	add	x0, x0, #0xaba
    bf3c:      	mov	w1, #0x2                // =2
    bf40:      	bl	0x1d600 <dlopen@plt>
    bf44:      	mov	x19, x0
    bf48:      	cbnz	x0, 0xbfc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2fb0>
    bf4c:      	adrp	x0, 0x2000
    bf50:      	add	x0, x0, #0xc4e
    bf54:      	mov	w1, #0x2                // =2
    bf58:      	bl	0x1d600 <dlopen@plt>
    bf5c:      	mov	x19, x0
    bf60:      	cbnz	x0, 0xbfc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2fb0>
    bf64:      	adrp	x0, 0x2000
    bf68:      	add	x0, x0, #0xac5
    bf6c:      	mov	w1, #0x2                // =2
    bf70:      	bl	0x1d600 <dlopen@plt>
    bf74:      	mov	x19, x0
    bf78:      	cbnz	x0, 0xbfc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2fb0>
    bf7c:      	adrp	x0, 0x4000
    bf80:      	add	x0, x0, #0x5e2
    bf84:      	mov	w1, #0x2                // =2
    bf88:      	bl	0x1d600 <dlopen@plt>
    bf8c:      	mov	x19, x0
    bf90:      	cbnz	x0, 0xbfc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2fb0>
    bf94:      	adrp	x0, 0x4000
    bf98:      	add	x0, x0, #0x16
    bf9c:      	mov	w1, #0x2                // =2
    bfa0:      	bl	0x1d600 <dlopen@plt>
    bfa4:      	mov	x19, x0
    bfa8:      	cbnz	x0, 0xbfc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2fb0>
    bfac:      	adrp	x0, 0x3000
    bfb0:      	add	x0, x0, #0x538
    bfb4:      	mov	w1, #0x2                // =2
    bfb8:      	bl	0x1d600 <dlopen@plt>
    bfbc:      	mov	x19, x0
    bfc0:      	cbz	x0, 0xc068 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3054>
    bfc4:      	adrp	x1, 0x4000
    bfc8:      	add	x1, x1, #0x9be
    bfcc:      	mov	x0, x19
    bfd0:      	bl	0x1d6f0 <dlsym@plt>
    bfd4:      	mov	x23, x0
    bfd8:      	adrp	x1, 0x4000
    bfdc:      	add	x1, x1, #0x7
    bfe0:      	mov	x0, x19
    bfe4:      	bl	0x1d6f0 <dlsym@plt>
    bfe8:      	mov	x22, x0
    bfec:      	adrp	x1, 0x4000
    bff0:      	add	x1, x1, #0x5d2
    bff4:      	mov	x0, x19
    bff8:      	bl	0x1d6f0 <dlsym@plt>
    bffc:      	cbz	x23, 0xc060 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x304c>
    c000:      	cbz	x22, 0xc060 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x304c>
    c004:      	cbz	x0, 0xc060 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x304c>
    c008:      	mov	x28, x0
    c00c:      	sub	x2, x29, #0x24
    c010:      	mov	w0, wzr
    c014:      	mov	x1, xzr
    c018:      	stur	wzr, [x29, #-0x24]
    c01c:      	blr	x23
    c020:      	cbnz	w0, 0xc060 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x304c>
    c024:      	ldur	w24, [x29, #-0x24]
    c028:      	cbz	w24, 0xc060 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x304c>
    c02c:      	lsl	x0, x24, #3
    c030:      	bl	0x1d700 <_Znam@plt>
    c034:      	mov	x20, x0
    c038:      	mov	w0, w24
    c03c:      	mov	x2, xzr
    c040:      	mov	x1, x20
    c044:      	blr	x23
    c048:      	cbz	w0, 0xc0b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x30a0>
    c04c:      	mov	x0, x19
    c050:      	bl	0x1d6b0 <dlclose@plt>
    c054:      	mov	x0, x20
    c058:      	bl	0x1d710 <_ZdaPv@plt>
    c05c:      	b	0xc068 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3054>
    c060:      	mov	x0, x19
    c064:      	bl	0x1d6b0 <dlclose@plt>
    c068:      	ldr	x0, [sp, #0x10]
    c06c:      	mov	w8, #0x1                // =1
    c070:      	strb	w8, [x26, #0x570]
    c074:      	adrp	x1, 0x26000
    c078:      	add	x1, x1, #0x59c
    c07c:      	mov	w2, #0x181              // =385
    c080:      	bl	0x1d540 <memcpy@plt>
    c084:      	ldr	x8, [x25, #0x28]
    c088:      	ldur	x9, [x29, #-0x8]
    c08c:      	cmp	x8, x9
    c090:      	b.ne	0xc9a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x398c>
    c094:      	ldp	x20, x19, [sp, #0xf0]
    c098:      	ldp	x22, x21, [sp, #0xe0]
    c09c:      	ldp	x24, x23, [sp, #0xd0]
    c0a0:      	ldp	x26, x25, [sp, #0xc0]
    c0a4:      	ldp	x28, x27, [sp, #0xb0]
    c0a8:      	ldp	x29, x30, [sp, #0xa0]
    c0ac:      	add	sp, sp, #0x100
    c0b0:      	ret
    c0b4:      	ldur	w8, [x29, #-0x24]
    c0b8:      	cbz	w8, 0xc04c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3038>
    c0bc:      	mov	x27, xzr
    c0c0:      	b	0xc0d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x30c0>
    c0c4:      	ldur	w8, [x29, #-0x24]
    c0c8:      	add	x27, x27, #0x1
    c0cc:      	cmp	x27, x8
    c0d0:      	b.hs	0xc04c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3038>
    c0d4:      	ldr	x0, [x20, x27, lsl #3]
    c0d8:      	sub	x4, x29, #0x20
    c0dc:      	mov	w1, #0x4                // =4
    c0e0:      	mov	w2, wzr
    c0e4:      	mov	x3, xzr
    c0e8:      	stur	wzr, [x29, #-0x20]
    c0ec:      	blr	x22
    c0f0:      	cbnz	w0, 0xc0c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x30b0>
    c0f4:      	ldur	w23, [x29, #-0x20]
    c0f8:      	cbz	w23, 0xc0c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x30b0>
    c0fc:      	lsl	x0, x23, #3
    c100:      	bl	0x1d700 <_Znam@plt>
    c104:      	ldr	x8, [x20, x27, lsl #3]
    c108:      	mov	x24, x0
    c10c:      	mov	w1, #0x4                // =4
    c110:      	mov	w2, w23
    c114:      	mov	x3, x24
    c118:      	mov	x4, xzr
    c11c:      	mov	x0, x8
    c120:      	blr	x22
    c124:      	cbz	w0, 0xc134 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3120>
    c128:      	mov	x0, x24
    c12c:      	bl	0x1d710 <_ZdaPv@plt>
    c130:      	b	0xc0c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x30b0>
    c134:      	ldr	x22, [x24]
    c138:      	mov	x0, x24
    c13c:      	bl	0x1d710 <_ZdaPv@plt>
    c140:      	cbz	x22, 0xc04c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3038>
    c144:      	sub	x0, x29, #0x40
    c148:      	mov	x1, x22
    c14c:      	mov	w2, #0x102b             // =4139
    c150:      	mov	x3, x28
    c154:      	mov	x23, x28
    c158:      	sub	x24, x29, #0x40
    c15c:      	bl	0xcd18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3d04>
    c160:      	add	x0, sp, #0x48
    c164:      	mov	x1, x22
    c168:      	mov	w2, #0x102f             // =4143
    c16c:      	mov	x3, x28
    c170:      	bl	0xcd18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3d04>
    c174:      	add	x0, sp, #0x30
    c178:      	mov	x1, x22
    c17c:      	mov	w2, #0x102d             // =4141
    c180:      	mov	x3, x28
    c184:      	bl	0xcd18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3d04>
    c188:      	add	x0, sp, #0x18
    c18c:      	mov	x1, x22
    c190:      	mov	w2, #0x1030             // =4144
    c194:      	mov	x3, x28
    c198:      	add	x22, sp, #0x18
    c19c:      	bl	0xcd18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3d04>
    c1a0:      	ldrb	w8, [sp, #0x18]
    c1a4:      	ldp	x10, x11, [sp, #0x20]
    c1a8:      	lsr	x9, x8, #1
    c1ac:      	tst	w8, #0x1
    c1b0:      	csel	x8, x9, x10, eq
    c1b4:      	orr	x9, x22, #0x1
    c1b8:      	csel	x22, x9, x11, eq
    c1bc:      	cmp	x8, #0xb
    c1c0:      	add	x23, x22, x8
    c1c4:      	b.lt	0xc220 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x320c>
    c1c8:      	mov	x27, #0x6c63            // =27747
    c1cc:      	mov	x28, #0x686b            // =26731
    c1d0:      	mov	x0, x22
    c1d4:      	movk	x27, #0x6b5f, lsl #16
    c1d8:      	movk	x28, #0x5f72, lsl #16
    c1dc:      	movk	x27, #0x7268, lsl #32
    c1e0:      	movk	x28, #0x7066, lsl #32
    c1e4:      	movk	x27, #0x665f, lsl #48
    c1e8:      	movk	x28, #0x3631, lsl #48
    c1ec:      	sub	x2, x8, #0xa
    c1f0:      	mov	w1, #0x63               // =99
    c1f4:      	bl	0x1d720 <memchr@plt>
    c1f8:      	cbz	x0, 0xc220 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x320c>
    c1fc:      	ldr	x8, [x0]
    c200:      	ldur	x9, [x0, #0x3]
    c204:      	cmp	x8, x27
    c208:      	ccmp	x9, x28, #0x0, eq
    c20c:      	b.eq	0xc224 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3210>
    c210:      	add	x0, x0, #0x1
    c214:      	sub	x8, x23, x0
    c218:      	cmp	x8, #0xa
    c21c:      	b.gt	0xc1ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x31d8>
    c220:      	mov	x0, x23
    c224:      	ldurb	w8, [x29, #-0x40]
    c228:      	sub	x9, x0, x22
    c22c:      	cmp	x0, x23
    c230:      	ccmn	x9, #0x1, #0x4, ne
    c234:      	lsr	x9, x8, #1
    c238:      	cset	w11, ne
    c23c:      	tst	w8, #0x1
    c240:      	ldp	x10, x8, [x29, #-0x38]
    c244:      	csel	x28, x9, x10, eq
    c248:      	orr	x10, x24, #0x1
    c24c:      	adrp	x9, 0x26000
    c250:      	csel	x22, x10, x8, eq
    c254:      	cmp	x28, #0x13
    c258:      	str	x10, [sp, #0x8]
    c25c:      	strb	w11, [x9, #0x69c]
    c260:      	b.ne	0xc3ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x33d8>
    c264:      	mov	x10, #0x5551            // =21841
    c268:      	ldp	x8, x9, [x22]
    c26c:      	movk	x10, #0x4c41, lsl #16
    c270:      	ldur	x11, [x22, #0xb]
    c274:      	movk	x10, #0x4f43, lsl #32
    c278:      	movk	x10, #0x4d4d, lsl #48
    c27c:      	cmp	x8, x10
    c280:      	mov	x8, #0x4120             // =16672
    c284:      	movk	x8, #0x7264, lsl #16
    c288:      	movk	x8, #0x6e65, lsl #32
    c28c:      	movk	x8, #0x286f, lsl #48
    c290:      	ccmp	x9, x8, #0x0, eq
    c294:      	mov	x8, #0x6572             // =25970
    c298:      	movk	x8, #0x6f6e, lsl #16
    c29c:      	movk	x8, #0x5428, lsl #32
    c2a0:      	movk	x8, #0x294d, lsl #48
    c2a4:      	ccmp	x11, x8, #0x0, eq
    c2a8:      	b.ne	0xc3f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x33e0>
    c2ac:      	sub	x0, x29, #0x20
    c2b0:      	add	x1, sp, #0x48
    c2b4:      	sub	x21, x29, #0x20
    c2b8:      	bl	0xcecc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3eb8>
    c2bc:      	ldurb	w8, [x29, #-0x20]
    c2c0:      	ldur	x9, [x29, #-0x10]
    c2c4:      	orr	x21, x21, #0x1
    c2c8:      	adrp	x0, 0x26000
    c2cc:      	add	x0, x0, #0x59c
    c2d0:      	adrp	x3, 0x3000
    c2d4:      	add	x3, x3, #0x8ba
    c2d8:      	tst	w8, #0x1
    c2dc:      	mov	w1, #0x181              // =385
    c2e0:      	csel	x4, x21, x9, eq
    c2e4:      	mov	w2, #0x80               // =128
    c2e8:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    c2ec:      	ldurb	w8, [x29, #-0x20]
    c2f0:      	tbz	w8, #0x0, 0xc2fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x32e8>
    c2f4:      	ldur	x0, [x29, #-0x10]
    c2f8:      	bl	0x1d550 <_ZdlPv@plt>
    c2fc:      	sub	x0, x29, #0x20
    c300:      	add	x1, sp, #0x48
    c304:      	bl	0xd0ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4098>
    c308:      	ldurb	w8, [x29, #-0x20]
    c30c:      	ldur	x9, [x29, #-0x10]
    c310:      	adrp	x0, 0x26000
    c314:      	add	x0, x0, #0x69d
    c318:      	adrp	x3, 0x3000
    c31c:      	add	x3, x3, #0x8ba
    c320:      	tst	w8, #0x1
    c324:      	mov	w1, #0x80               // =128
    c328:      	mov	w2, #0x80               // =128
    c32c:      	csel	x4, x21, x9, eq
    c330:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    c334:      	ldurb	w8, [x29, #-0x20]
    c338:      	tbz	w8, #0x0, 0xc344 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3330>
    c33c:      	ldur	x0, [x29, #-0x10]
    c340:      	bl	0x1d550 <_ZdlPv@plt>
    c344:      	add	x0, sp, #0x30
    c348:      	mov	w1, #0x23               // =35
    c34c:      	mov	x2, xzr
    c350:      	add	x22, sp, #0x30
    c354:      	bl	0x1d730 <_ZNKSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE4findEcm@plt>
    c358:      	cmn	x0, #0x1
    c35c:      	b.eq	0xc6e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x36d0>
    c360:      	mov	x21, x0
    c364:      	add	x0, sp, #0x30
    c368:      	mov	w1, #0x20               // =32
    c36c:      	mov	x2, x21
    c370:      	bl	0x1d730 <_ZNKSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE4findEcm@plt>
    c374:      	cmn	x0, #0x1
    c378:      	b.eq	0xc714 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3700>
    c37c:      	ldrb	w8, [sp, #0x30]
    c380:      	ldr	x9, [sp, #0x38]
    c384:      	lsr	x10, x8, #1
    c388:      	tst	w8, #0x1
    c38c:      	csel	x9, x10, x9, eq
    c390:      	cmp	x9, x21
    c394:      	b.ls	0xc9a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3990>
    c398:      	add	x23, x21, #0x1
    c39c:      	mvn	x10, x21
    c3a0:      	ldr	x11, [sp, #0x40]
    c3a4:      	add	x12, sp, #0x30
    c3a8:      	add	x10, x0, x10
    c3ac:      	tst	w8, #0x1
    c3b0:      	orr	x12, x12, #0x1
    c3b4:      	sub	x8, x9, x23
    c3b8:      	csel	x24, x12, x11, eq
    c3bc:      	cmp	x8, x10
    c3c0:      	csel	x21, x8, x10, lo
    c3c4:      	cmn	x21, #0x10
    c3c8:      	b.hs	0xc9ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3998>
    c3cc:      	cmp	x21, #0x17
    c3d0:      	b.hs	0xc778 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3764>
    c3d4:      	lsl	w8, w21, #1
    c3d8:      	sub	x9, x29, #0x20
    c3dc:      	orr	x22, x9, #0x1
    c3e0:      	sturb	w8, [x29, #-0x20]
    c3e4:      	cbnz	x21, 0xc794 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3780>
    c3e8:      	b	0xc7a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3790>
    c3ec:      	cmp	x28, #0x4
    c3f0:      	b.lt	0xc5f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x35e0>
    c3f4:      	mov	w23, #0x614d            // =24909
    c3f8:      	add	x24, x22, x28
    c3fc:      	mov	x8, x28
    c400:      	movk	w23, #0x696c, lsl #16
    c404:      	mov	x0, x22
    c408:      	sub	x2, x8, #0x3
    c40c:      	mov	w1, #0x4d               // =77
    c410:      	bl	0x1d720 <memchr@plt>
    c414:      	cbz	x0, 0xc510 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x34fc>
    c418:      	ldr	w8, [x0]
    c41c:      	cmp	w8, w23
    c420:      	b.eq	0xc438 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3424>
    c424:      	add	x0, x0, #0x1
    c428:      	sub	x8, x24, x0
    c42c:      	cmp	x8, #0x4
    c430:      	b.ge	0xc408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x33f4>
    c434:      	b	0xc510 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x34fc>
    c438:      	cmp	x0, x24
    c43c:      	b.eq	0xc510 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x34fc>
    c440:      	sub	x8, x0, x22
    c444:      	cmn	x8, #0x1
    c448:      	b.eq	0xc510 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x34fc>
    c44c:      	sub	x0, x29, #0x20
    c450:      	add	x1, sp, #0x48
    c454:      	sub	x21, x29, #0x20
    c458:      	bl	0xcecc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3eb8>
    c45c:      	ldurb	w8, [x29, #-0x20]
    c460:      	ldur	x9, [x29, #-0x10]
    c464:      	orr	x21, x21, #0x1
    c468:      	adrp	x0, 0x26000
    c46c:      	add	x0, x0, #0x59c
    c470:      	adrp	x3, 0x3000
    c474:      	add	x3, x3, #0x8ba
    c478:      	tst	w8, #0x1
    c47c:      	mov	w1, #0x181              // =385
    c480:      	csel	x4, x21, x9, eq
    c484:      	mov	w2, #0x80               // =128
    c488:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    c48c:      	ldurb	w8, [x29, #-0x20]
    c490:      	tbz	w8, #0x0, 0xc49c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3488>
    c494:      	ldur	x0, [x29, #-0x10]
    c498:      	bl	0x1d550 <_ZdlPv@plt>
    c49c:      	sub	x0, x29, #0x20
    c4a0:      	add	x1, sp, #0x48
    c4a4:      	bl	0xd0ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4098>
    c4a8:      	ldurb	w8, [x29, #-0x20]
    c4ac:      	ldur	x9, [x29, #-0x10]
    c4b0:      	adrp	x0, 0x26000
    c4b4:      	add	x0, x0, #0x61c
    c4b8:      	adrp	x3, 0x3000
    c4bc:      	add	x3, x3, #0x8ba
    c4c0:      	tst	w8, #0x1
    c4c4:      	mov	w1, #0x101              // =257
    c4c8:      	mov	w2, #0x80               // =128
    c4cc:      	csel	x4, x21, x9, eq
    c4d0:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    c4d4:      	ldurb	w8, [x29, #-0x20]
    c4d8:      	ldr	x21, [sp, #0x8]
    c4dc:      	tbz	w8, #0x0, 0xc4e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x34d4>
    c4e0:      	ldur	x0, [x29, #-0x10]
    c4e4:      	bl	0x1d550 <_ZdlPv@plt>
    c4e8:      	ldurb	w8, [x29, #-0x40]
    c4ec:      	ldur	x9, [x29, #-0x30]
    c4f0:      	adrp	x0, 0x26000
    c4f4:      	add	x0, x0, #0x69d
    c4f8:      	adrp	x3, 0x3000
    c4fc:      	add	x3, x3, #0x8ba
    c500:      	tst	w8, #0x1
    c504:      	mov	w1, #0x80               // =128
    c508:      	csel	x4, x21, x9, eq
    c50c:      	b	0xc70c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x36f8>
    c510:      	cmp	x28, #0x7
    c514:      	b.lt	0xc5f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x35e0>
    c518:      	mov	w27, #0x6f50            // =28496
    c51c:      	mov	w23, #0x7265            // =29285
    c520:      	mov	x0, x22
    c524:      	movk	w27, #0x6577, lsl #16
    c528:      	movk	w23, #0x5256, lsl #16
    c52c:      	sub	x2, x28, #0x6
    c530:      	mov	w1, #0x50               // =80
    c534:      	bl	0x1d720 <memchr@plt>
    c538:      	cbz	x0, 0xc5f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x35e0>
    c53c:      	ldr	w8, [x0]
    c540:      	ldur	w9, [x0, #0x3]
    c544:      	cmp	w8, w27
    c548:      	ccmp	w9, w23, #0x0, eq
    c54c:      	b.eq	0xc564 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3550>
    c550:      	add	x0, x0, #0x1
    c554:      	sub	x28, x24, x0
    c558:      	cmp	x28, #0x7
    c55c:      	b.ge	0xc52c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3518>
    c560:      	b	0xc5f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x35e0>
    c564:      	cmp	x0, x24
    c568:      	b.eq	0xc5f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x35e0>
    c56c:      	sub	x8, x0, x22
    c570:      	cmn	x8, #0x1
    c574:      	b.eq	0xc5f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x35e0>
    c578:      	add	x0, sp, #0x48
    c57c:      	mov	w1, #0x20               // =32
    c580:      	mov	x2, xzr
    c584:      	bl	0x1d730 <_ZNKSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE4findEcm@plt>
    c588:      	cmn	x0, #0x1
    c58c:      	b.eq	0xc7f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x37e0>
    c590:      	ldrb	w9, [sp, #0x48]
    c594:      	ldr	x8, [sp, #0x50]
    c598:      	lsr	x10, x9, #1
    c59c:      	tst	w9, #0x1
    c5a0:      	csel	x8, x10, x8, eq
    c5a4:      	cmp	x8, x0
    c5a8:      	b.ls	0xc9a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3990>
    c5ac:      	add	x24, x0, #0x1
    c5b0:      	ldr	x10, [sp, #0x58]
    c5b4:      	add	x11, sp, #0x48
    c5b8:      	orr	x11, x11, #0x1
    c5bc:      	tst	w9, #0x1
    c5c0:      	sub	x21, x8, x24
    c5c4:      	csel	x27, x11, x10, eq
    c5c8:      	cmn	x21, #0x10
    c5cc:      	b.hs	0xc9ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3998>
    c5d0:      	cmp	x21, #0x17
    c5d4:      	b.hs	0xc810 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x37fc>
    c5d8:      	lsl	w9, w21, #1
    c5dc:      	sub	x10, x29, #0x20
    c5e0:      	cmp	x8, x24
    c5e4:      	orr	x22, x10, #0x1
    c5e8:      	sturb	w9, [x29, #-0x20]
    c5ec:      	b.ne	0xc82c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3818>
    c5f0:      	b	0xc83c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3828>
    c5f4:      	ldrb	w8, [sp, #0x48]
    c5f8:      	ldr	x9, [sp, #0x58]
    c5fc:      	add	x10, sp, #0x48
    c600:      	orr	x10, x10, #0x1
    c604:      	adrp	x22, 0x3000
    c608:      	add	x22, x22, #0x8ba
    c60c:      	tst	w8, #0x1
    c610:      	mov	x0, x21
    c614:      	mov	w1, #0x181              // =385
    c618:      	csel	x4, x10, x9, eq
    c61c:      	mov	w2, #0x80               // =128
    c620:      	mov	x3, x22
    c624:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    c628:      	ldrb	w8, [sp, #0x30]
    c62c:      	ldr	x9, [sp, #0x40]
    c630:      	add	x10, sp, #0x30
    c634:      	orr	x10, x10, #0x1
    c638:      	add	x0, x21, #0x80
    c63c:      	mov	w1, #0x101              // =257
    c640:      	tst	w8, #0x1
    c644:      	mov	w2, #0x80               // =128
    c648:      	mov	x3, x22
    c64c:      	csel	x4, x10, x9, eq
    c650:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    c654:      	ldurb	w8, [x29, #-0x40]
    c658:      	ldur	x9, [x29, #-0x30]
    c65c:      	add	x0, x21, #0x101
    c660:      	mov	w1, #0x80               // =128
    c664:      	mov	w2, #0x80               // =128
    c668:      	mov	x3, x22
    c66c:      	tst	w8, #0x1
    c670:      	ldr	x8, [sp, #0x8]
    c674:      	csel	x4, x8, x9, eq
    c678:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    c67c:      	mov	x0, x19
    c680:      	bl	0x1d6b0 <dlclose@plt>
    c684:      	ldrb	w8, [sp, #0x18]
    c688:      	tbnz	w8, #0x0, 0xc6a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3694>
    c68c:      	ldrb	w8, [sp, #0x30]
    c690:      	tbnz	w8, #0x0, 0xc6b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x36a4>
    c694:      	ldrb	w8, [sp, #0x48]
    c698:      	tbnz	w8, #0x0, 0xc6c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x36b4>
    c69c:      	ldurb	w8, [x29, #-0x40]
    c6a0:      	tbz	w8, #0x0, 0xc054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3040>
    c6a4:      	b	0xc6d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x36c4>
    c6a8:      	ldr	x0, [sp, #0x28]
    c6ac:      	bl	0x1d550 <_ZdlPv@plt>
    c6b0:      	ldrb	w8, [sp, #0x30]
    c6b4:      	tbz	w8, #0x0, 0xc694 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3680>
    c6b8:      	ldr	x0, [sp, #0x40]
    c6bc:      	bl	0x1d550 <_ZdlPv@plt>
    c6c0:      	ldrb	w8, [sp, #0x48]
    c6c4:      	tbz	w8, #0x0, 0xc69c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3688>
    c6c8:      	ldr	x0, [sp, #0x58]
    c6cc:      	bl	0x1d550 <_ZdlPv@plt>
    c6d0:      	ldurb	w8, [x29, #-0x40]
    c6d4:      	tbz	w8, #0x0, 0xc054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3040>
    c6d8:      	ldur	x0, [x29, #-0x30]
    c6dc:      	bl	0x1d550 <_ZdlPv@plt>
    c6e0:      	b	0xc054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3040>
    c6e4:      	ldrb	w8, [sp, #0x30]
    c6e8:      	ldr	x9, [sp, #0x40]
    c6ec:      	orr	x10, x22, #0x1
    c6f0:      	adrp	x0, 0x26000
    c6f4:      	add	x0, x0, #0x61c
    c6f8:      	adrp	x3, 0x3000
    c6fc:      	add	x3, x3, #0x8ba
    c700:      	tst	w8, #0x1
    c704:      	mov	w1, #0x101              // =257
    c708:      	csel	x4, x10, x9, eq
    c70c:      	mov	w2, #0x80               // =128
    c710:      	b	0xc678 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3664>
    c714:      	ldrb	w9, [sp, #0x30]
    c718:      	ldr	x8, [sp, #0x38]
    c71c:      	lsr	x10, x9, #1
    c720:      	tst	w9, #0x1
    c724:      	csel	x8, x10, x8, eq
    c728:      	cmp	x8, x21
    c72c:      	b.ls	0xc9a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3990>
    c730:      	add	x23, x21, #0x1
    c734:      	ldr	x10, [sp, #0x40]
    c738:      	add	x11, sp, #0x30
    c73c:      	orr	x11, x11, #0x1
    c740:      	tst	w9, #0x1
    c744:      	sub	x21, x8, x23
    c748:      	csel	x24, x11, x10, eq
    c74c:      	cmn	x21, #0x10
    c750:      	b.hs	0xc9ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3998>
    c754:      	cmp	x21, #0x17
    c758:      	b.hs	0xc778 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3764>
    c75c:      	lsl	w9, w21, #1
    c760:      	sub	x10, x29, #0x20
    c764:      	cmp	x8, x23
    c768:      	orr	x22, x10, #0x1
    c76c:      	sturb	w9, [x29, #-0x20]
    c770:      	b.ne	0xc794 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3780>
    c774:      	b	0xc7a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3790>
    c778:      	orr	x27, x21, #0xf
    c77c:      	add	x0, x27, #0x1
    c780:      	bl	0x1d530 <_Znwm@plt>
    c784:      	add	x8, x27, #0x2
    c788:      	mov	x22, x0
    c78c:      	stp	x21, x0, [x29, #-0x18]
    c790:      	stur	x8, [x29, #-0x20]
    c794:      	add	x1, x24, x23
    c798:      	mov	x0, x22
    c79c:      	mov	x2, x21
    c7a0:      	bl	0x1d740 <memmove@plt>
    c7a4:      	add	x8, x22, x21
    c7a8:      	strb	wzr, [x8]
    c7ac:      	ldurb	w8, [x29, #-0x20]
    c7b0:      	ldur	x9, [x29, #-0x10]
    c7b4:      	sub	x10, x29, #0x20
    c7b8:      	orr	x10, x10, #0x1
    c7bc:      	adrp	x0, 0x26000
    c7c0:      	add	x0, x0, #0x61c
    c7c4:      	tst	w8, #0x1
    c7c8:      	adrp	x3, 0x3000
    c7cc:      	add	x3, x3, #0x8ba
    c7d0:      	csel	x4, x10, x9, eq
    c7d4:      	mov	w1, #0x101              // =257
    c7d8:      	mov	w2, #0x80               // =128
    c7dc:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    c7e0:      	ldurb	w8, [x29, #-0x20]
    c7e4:      	tbz	w8, #0x0, 0xc67c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3668>
    c7e8:      	ldur	x0, [x29, #-0x10]
    c7ec:      	bl	0x1d550 <_ZdlPv@plt>
    c7f0:      	b	0xc67c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3668>
    c7f4:      	ldrb	w8, [sp, #0x48]
    c7f8:      	tbnz	w8, #0x0, 0xc844 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3830>
    c7fc:      	ldur	q0, [sp, #0x48]
    c800:      	ldr	x8, [sp, #0x58]
    c804:      	stur	q0, [x29, #-0x20]
    c808:      	stur	x8, [x29, #-0x10]
    c80c:      	b	0xc850 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x383c>
    c810:      	orr	x23, x21, #0xf
    c814:      	add	x0, x23, #0x1
    c818:      	bl	0x1d530 <_Znwm@plt>
    c81c:      	add	x8, x23, #0x2
    c820:      	mov	x22, x0
    c824:      	stp	x21, x0, [x29, #-0x18]
    c828:      	stur	x8, [x29, #-0x20]
    c82c:      	add	x1, x27, x24
    c830:      	mov	x0, x22
    c834:      	mov	x2, x21
    c838:      	bl	0x1d740 <memmove@plt>
    c83c:      	strb	wzr, [x22, x21]
    c840:      	b	0xc850 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x383c>
    c844:      	ldp	x2, x1, [sp, #0x50]
    c848:      	sub	x0, x29, #0x20
    c84c:      	bl	0xd1ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x41d8>
    c850:      	ldurb	w8, [x29, #-0x20]
    c854:      	ldur	x9, [x29, #-0x10]
    c858:      	sub	x10, x29, #0x20
    c85c:      	orr	x10, x10, #0x1
    c860:      	ldr	x21, [sp, #0x8]
    c864:      	adrp	x0, 0x26000
    c868:      	add	x0, x0, #0x59c
    c86c:      	tst	w8, #0x1
    c870:      	adrp	x3, 0x3000
    c874:      	add	x3, x3, #0x8ba
    c878:      	csel	x4, x10, x9, eq
    c87c:      	mov	w1, #0x181              // =385
    c880:      	mov	w2, #0x80               // =128
    c884:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    c888:      	ldurb	w8, [x29, #-0x20]
    c88c:      	tbz	w8, #0x0, 0xc898 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3884>
    c890:      	ldur	x0, [x29, #-0x10]
    c894:      	bl	0x1d550 <_ZdlPv@plt>
    c898:      	ldurb	w8, [x29, #-0x40]
    c89c:      	ldur	x9, [x29, #-0x30]
    c8a0:      	adrp	x0, 0x26000
    c8a4:      	add	x0, x0, #0x69d
    c8a8:      	adrp	x3, 0x3000
    c8ac:      	add	x3, x3, #0x8ba
    c8b0:      	tst	w8, #0x1
    c8b4:      	mov	w1, #0x80               // =128
    c8b8:      	mov	w2, #0x80               // =128
    c8bc:      	csel	x4, x21, x9, eq
    c8c0:      	bl	0x9354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x340>
    c8c4:      	add	x0, sp, #0x30
    c8c8:      	mov	w1, #0x40               // =64
    c8cc:      	mov	x2, xzr
    c8d0:      	bl	0x1d730 <_ZNKSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE4findEcm@plt>
    c8d4:      	cmn	x0, #0x1
    c8d8:      	b.eq	0xc940 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x392c>
    c8dc:      	ldrb	w9, [sp, #0x30]
    c8e0:      	ldr	x8, [sp, #0x38]
    c8e4:      	lsr	x10, x9, #1
    c8e8:      	tst	w9, #0x1
    c8ec:      	csel	x8, x10, x8, eq
    c8f0:      	cmp	x8, x0
    c8f4:      	b.ls	0xc9a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3990>
    c8f8:      	add	x23, x0, #0x1
    c8fc:      	ldr	x10, [sp, #0x40]
    c900:      	add	x11, sp, #0x30
    c904:      	orr	x11, x11, #0x1
    c908:      	tst	w9, #0x1
    c90c:      	sub	x21, x8, x23
    c910:      	csel	x24, x11, x10, eq
    c914:      	cmn	x21, #0x10
    c918:      	b.hs	0xc9ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3998>
    c91c:      	cmp	x21, #0x17
    c920:      	b.hs	0xc95c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3948>
    c924:      	lsl	w9, w21, #1
    c928:      	sub	x10, x29, #0x20
    c92c:      	cmp	x8, x23
    c930:      	orr	x22, x10, #0x1
    c934:      	sturb	w9, [x29, #-0x20]
    c938:      	b.ne	0xc978 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3964>
    c93c:      	b	0xc988 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3974>
    c940:      	ldrb	w8, [sp, #0x30]
    c944:      	tbnz	w8, #0x0, 0xc990 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x397c>
    c948:      	ldr	q0, [sp, #0x30]
    c94c:      	ldr	x8, [sp, #0x40]
    c950:      	stur	q0, [x29, #-0x20]
    c954:      	stur	x8, [x29, #-0x10]
    c958:      	b	0xc7ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3798>
    c95c:      	orr	x27, x21, #0xf
    c960:      	add	x0, x27, #0x1
    c964:      	bl	0x1d530 <_Znwm@plt>
    c968:      	add	x8, x27, #0x2
    c96c:      	mov	x22, x0
    c970:      	stp	x21, x0, [x29, #-0x18]
    c974:      	stur	x8, [x29, #-0x20]
    c978:      	add	x1, x24, x23
    c97c:      	mov	x0, x22
    c980:      	mov	x2, x21
    c984:      	bl	0x1d740 <memmove@plt>
    c988:      	strb	wzr, [x22, x21]
    c98c:      	b	0xc7ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3798>
    c990:      	ldp	x2, x1, [sp, #0x38]
    c994:      	sub	x0, x29, #0x20
    c998:      	bl	0xd1ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x41d8>
    c99c:      	b	0xc7ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3798>
    c9a0:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    c9a4:      	sub	x0, x29, #0x20
    c9a8:      	bl	0xd1c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x41ac>
    c9ac:      	sub	x0, x29, #0x20
    c9b0:      	bl	0xcea0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3e8c>
    c9b4:      	sub	sp, sp, #0x120
    c9b8:      	stp	x29, x30, [sp, #0x100]
    c9bc:      	stp	x28, x19, [sp, #0x110]
    c9c0:      	add	x29, sp, #0x100
    c9c4:      	stp	x3, x4, [x29, #-0x78]
    c9c8:      	sub	x10, x29, #0x78
    c9cc:      	sub	x11, x29, #0x28
    c9d0:      	stp	x5, x6, [x29, #-0x68]
    c9d4:      	mov	x8, x2
    c9d8:      	mov	x2, x1
    c9dc:      	stur	x7, [x29, #-0x58]
    c9e0:      	sub	x4, x29, #0x50
    c9e4:      	mov	w1, wzr
    c9e8:      	stp	q0, q1, [sp]
    c9ec:      	mov	x3, x8
    c9f0:      	stp	q2, q3, [sp, #0x20]
    c9f4:      	stp	q4, q5, [sp, #0x40]
    c9f8:      	stp	q6, q7, [sp, #0x60]
    c9fc:      	mrs	x19, TPIDR_EL0
    ca00:      	ldr	x9, [x19, #0x28]
    ca04:      	stur	x9, [x29, #-0x8]
    ca08:      	add	x9, x10, #0x28
    ca0c:      	add	x10, x29, #0x20
    ca10:      	stp	x10, x9, [x29, #-0x28]
    ca14:      	mov	x9, #-0x28              // =-40
    ca18:      	mov	x10, sp
    ca1c:      	movk	x9, #0xff80, lsl #32
    ca20:      	add	x10, x10, #0x80
    ca24:      	stp	x10, x9, [x29, #-0x18]
    ca28:      	ldp	q0, q1, [x11]
    ca2c:      	stp	q0, q1, [x29, #-0x50]
    ca30:      	bl	0x1d750 <__vsprintf_chk@plt>
    ca34:      	ldr	x8, [x19, #0x28]
    ca38:      	ldur	x9, [x29, #-0x8]
    ca3c:      	cmp	x8, x9
    ca40:      	b.ne	0xca54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3a40>
    ca44:      	ldp	x28, x19, [sp, #0x110]
    ca48:      	ldp	x29, x30, [sp, #0x100]
    ca4c:      	add	sp, sp, #0x120
    ca50:      	ret
    ca54:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    ca58:      	stp	x29, x30, [sp, #-0x20]!
    ca5c:      	stp	x20, x19, [sp, #0x10]
    ca60:      	mov	x29, sp
    ca64:      	mov	x19, x0
    ca68:      	mov	w0, #0x8a8              // =2216
    ca6c:      	bl	0x1d530 <_Znwm@plt>
    ca70:      	mov	w1, wzr
    ca74:      	mov	w2, #0x8a8              // =2216
    ca78:      	mov	x20, x0
    ca7c:      	bl	0x1d5b0 <memset@plt>
    ca80:      	mov	x8, x20
    ca84:      	bl	0xb2d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x22c0>
    ca88:      	str	x20, [x19]
    ca8c:      	ldp	x20, x19, [sp, #0x10]
    ca90:      	ldp	x29, x30, [sp], #0x20
    ca94:      	ret
    ca98:      	ldr	x0, [x0]
    ca9c:      	cbz	x0, 0xcaa4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3a90>
    caa0:      	b	0x1d550 <_ZdlPv@plt>
    caa4:      	ret
    caa8:      	ldr	x8, [x0]
    caac:      	add	x0, x8, #0x100
    cab0:      	ret
    cab4:      	ldr	x8, [x0]
    cab8:      	add	x0, x8, #0x180
    cabc:      	ret
    cac0:      	ldr	x8, [x0]
    cac4:      	ldr	w0, [x8, #0x710]
    cac8:      	ret
    cacc:      	ldr	x8, [x0]
    cad0:      	ldr	w0, [x8, #0x714]
    cad4:      	ret
    cad8:      	ldr	x8, [x0]
    cadc:      	ldr	x0, [x8, #0x718]
    cae0:      	ret
    cae4:      	ldr	x8, [x0]
    cae8:      	ldrb	w0, [x8, #0x721]
    caec:      	ret
    caf0:      	ldr	x8, [x0]
    caf4:      	ldrb	w0, [x8, #0x720]
    caf8:      	ret
    cafc:      	ldr	x8, [x0]
    cb00:      	add	x0, x8, #0x7a2
    cb04:      	ret
    cb08:      	ldr	x8, [x0]
    cb0c:      	add	x0, x8, #0x722
    cb10:      	ret
    cb14:      	ldr	x0, [x0]
    cb18:      	ret
    cb1c:      	ldr	x8, [x0]
    cb20:      	add	x0, x8, #0x822
    cb24:      	ret
    cb28:      	stp	x29, x30, [sp, #-0x20]!
    cb2c:      	stp	x20, x19, [sp, #0x10]
    cb30:      	mov	x29, sp
    cb34:      	mov	x19, x0
    cb38:      	mov	w0, #0x208              // =520
    cb3c:      	bl	0x1d530 <_Znwm@plt>
    cb40:      	mov	w1, wzr
    cb44:      	mov	w2, #0x208              // =520
    cb48:      	mov	x20, x0
    cb4c:      	bl	0x1d5b0 <memset@plt>
    cb50:      	mov	x8, x20
    cb54:      	bl	0xbc80 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2c6c>
    cb58:      	str	x20, [x19]
    cb5c:      	ldp	x20, x19, [sp, #0x10]
    cb60:      	ldp	x29, x30, [sp], #0x20
    cb64:      	ret
    cb68:      	ldr	x0, [x0]
    cb6c:      	cbz	x0, 0xcb74 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3b60>
    cb70:      	b	0x1d550 <_ZdlPv@plt>
    cb74:      	ret
    cb78:      	ldr	x8, [x0]
    cb7c:      	ldr	w0, [x8, #0x204]
    cb80:      	ret
    cb84:      	ldr	x8, [x0]
    cb88:      	add	x0, x8, #0x80
    cb8c:      	ret
    cb90:      	ldr	x8, [x0]
    cb94:      	add	x0, x8, #0x180
    cb98:      	ret
    cb9c:      	ldr	x8, [x0]
    cba0:      	ldr	w0, [x8, #0x200]
    cba4:      	ret
    cba8:      	ldr	x0, [x0]
    cbac:      	ret
    cbb0:      	ldr	x8, [x0]
    cbb4:      	add	x0, x8, #0x100
    cbb8:      	ret
    cbbc:      	stp	x29, x30, [sp, #-0x20]!
    cbc0:      	stp	x20, x19, [sp, #0x10]
    cbc4:      	mov	x29, sp
    cbc8:      	mov	x19, x0
    cbcc:      	mov	w0, #0x181              // =385
    cbd0:      	bl	0x1d530 <_Znwm@plt>
    cbd4:      	movi	v0.2d, #0000000000000000
    cbd8:      	mov	x20, x0
    cbdc:      	strb	wzr, [x0, #0x180]
    cbe0:      	stp	q0, q0, [x0]
    cbe4:      	stp	q0, q0, [x0, #0x20]
    cbe8:      	stp	q0, q0, [x0, #0x40]
    cbec:      	stp	q0, q0, [x0, #0x60]
    cbf0:      	stp	q0, q0, [x0, #0x80]
    cbf4:      	stp	q0, q0, [x0, #0xa0]
    cbf8:      	stp	q0, q0, [x0, #0xc0]
    cbfc:      	stp	q0, q0, [x0, #0xe0]
    cc00:      	stp	q0, q0, [x0, #0x100]
    cc04:      	stp	q0, q0, [x0, #0x120]
    cc08:      	stp	q0, q0, [x0, #0x140]
    cc0c:      	stp	q0, q0, [x0, #0x160]
    cc10:      	bl	0xbe88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x2e74>
    cc14:      	str	x20, [x19]
    cc18:      	ldp	x20, x19, [sp, #0x10]
    cc1c:      	ldp	x29, x30, [sp], #0x20
    cc20:      	ret
    cc24:      	ldr	x0, [x0]
    cc28:      	cbz	x0, 0xcc30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3c1c>
    cc2c:      	b	0x1d550 <_ZdlPv@plt>
    cc30:      	ret
    cc34:      	ldr	x0, [x0]
    cc38:      	ret
    cc3c:      	ldr	x8, [x0]
    cc40:      	add	x0, x8, #0x80
    cc44:      	ret
    cc48:      	ldr	x8, [x0]
    cc4c:      	ldrb	w0, [x8, #0x100]
    cc50:      	ret
    cc54:      	ldr	x8, [x0]
    cc58:      	add	x0, x8, #0x101
    cc5c:      	ret
    cc60:      	stp	x29, x30, [sp, #-0x20]!
    cc64:      	str	x19, [sp, #0x10]
    cc68:      	mov	x29, sp
    cc6c:      	mov	x19, x0
    cc70:      	mov	w0, #0x81               // =129
    cc74:      	bl	0x1d530 <_Znwm@plt>
    cc78:      	movi	v0.2d, #0000000000000000
    cc7c:      	strb	wzr, [x0, #0x80]
    cc80:      	stp	q0, q0, [x0]
    cc84:      	stp	q0, q0, [x0, #0x20]
    cc88:      	stp	q0, q0, [x0, #0x40]
    cc8c:      	stp	q0, q0, [x0, #0x60]
    cc90:      	str	x0, [x19]
    cc94:      	ldr	x19, [sp, #0x10]
    cc98:      	ldp	x29, x30, [sp], #0x20
    cc9c:      	ret
    cca0:      	ldr	x0, [x0]
    cca4:      	cbz	x0, 0xccac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3c98>
    cca8:      	b	0x1d550 <_ZdlPv@plt>
    ccac:      	ret
    ccb0:      	ldr	x0, [x0]
    ccb4:      	ret
    ccb8:      	ldr	x8, [x0]
    ccbc:      	ldrb	w0, [x8, #0x80]
    ccc0:      	ret
    ccc4:      	stp	x29, x30, [sp, #-0x20]!
    ccc8:      	str	x19, [sp, #0x10]
    cccc:      	mov	x29, sp
    ccd0:      	mov	x19, x0
    ccd4:      	mov	w0, #0x80               // =128
    ccd8:      	bl	0x1d530 <_Znwm@plt>
    ccdc:      	movi	v0.2d, #0000000000000000
    cce0:      	str	x0, [x19]
    cce4:      	stp	q0, q0, [x0]
    cce8:      	stp	q0, q0, [x0, #0x20]
    ccec:      	stp	q0, q0, [x0, #0x40]
    ccf0:      	stp	q0, q0, [x0, #0x60]
    ccf4:      	ldr	x19, [sp, #0x10]
    ccf8:      	ldp	x29, x30, [sp], #0x20
    ccfc:      	ret
    cd00:      	ldr	x0, [x0]
    cd04:      	cbz	x0, 0xcd0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3cf8>
    cd08:      	b	0x1d550 <_ZdlPv@plt>
    cd0c:      	ret
    cd10:      	ldr	x0, [x0]
    cd14:      	ret
    cd18:      	sub	sp, sp, #0x80
    cd1c:      	stp	x29, x30, [sp, #0x30]
    cd20:      	stp	x26, x25, [sp, #0x40]
    cd24:      	stp	x24, x23, [sp, #0x50]
    cd28:      	stp	x22, x21, [sp, #0x60]
    cd2c:      	stp	x20, x19, [sp, #0x70]
    cd30:      	add	x29, sp, #0x30
    cd34:      	mrs	x25, TPIDR_EL0
    cd38:      	mov	x20, x3
    cd3c:      	mov	w21, w2
    cd40:      	ldr	x8, [x25, #0x28]
    cd44:      	mov	x22, x1
    cd48:      	mov	x19, x0
    cd4c:      	sub	x4, x29, #0x10
    cd50:      	mov	x0, x1
    cd54:      	mov	w1, w2
    cd58:      	mov	x2, xzr
    cd5c:      	mov	x3, xzr
    cd60:      	stur	x8, [x29, #-0x8]
    cd64:      	stur	xzr, [x29, #-0x10]
    cd68:      	blr	x20
    cd6c:      	cbnz	w0, 0xcd9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3d88>
    cd70:      	ldur	x23, [x29, #-0x10]
    cd74:      	cbz	x23, 0xcd9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3d88>
    cd78:      	cmn	x23, #0x10
    cd7c:      	b.hs	0xce98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3e84>
    cd80:      	cmp	x23, #0x17
    cd84:      	b.hs	0xcda4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3d90>
    cd88:      	lsl	w8, w23, #1
    cd8c:      	add	x9, sp, #0x8
    cd90:      	orr	x24, x9, #0x1
    cd94:      	strb	w8, [sp, #0x8]
    cd98:      	b	0xcdc0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3dac>
    cd9c:      	strh	wzr, [x19]
    cda0:      	b	0xce68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3e54>
    cda4:      	orr	x26, x23, #0xf
    cda8:      	add	x0, x26, #0x1
    cdac:      	bl	0x1d530 <_Znwm@plt>
    cdb0:      	add	x8, x26, #0x2
    cdb4:      	mov	x24, x0
    cdb8:      	stp	x23, x0, [sp, #0x10]
    cdbc:      	str	x8, [sp, #0x8]
    cdc0:      	mov	x0, x24
    cdc4:      	mov	w1, wzr
    cdc8:      	mov	x2, x23
    cdcc:      	bl	0x1d5b0 <memset@plt>
    cdd0:      	strb	wzr, [x24, x23]
    cdd4:      	add	x10, sp, #0x8
    cdd8:      	mov	x0, x22
    cddc:      	ldrb	w8, [sp, #0x8]
    cde0:      	ldr	x9, [sp, #0x18]
    cde4:      	orr	x24, x10, #0x1
    cde8:      	mov	w1, w21
    cdec:      	mov	x2, x23
    cdf0:      	mov	x4, xzr
    cdf4:      	tst	w8, #0x1
    cdf8:      	csel	x3, x24, x9, eq
    cdfc:      	blr	x20
    ce00:      	cbz	w0, 0xce1c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3e08>
    ce04:      	ldrb	w8, [sp, #0x8]
    ce08:      	strh	wzr, [x19]
    ce0c:      	tbz	w8, #0x0, 0xce68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3e54>
    ce10:      	ldr	x0, [sp, #0x18]
    ce14:      	bl	0x1d550 <_ZdlPv@plt>
    ce18:      	b	0xce68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3e54>
    ce1c:      	ldrb	w8, [sp, #0x8]
    ce20:      	ldr	x9, [sp, #0x10]
    ce24:      	lsr	x10, x8, #1
    ce28:      	tst	w8, #0x1
    ce2c:      	csel	x9, x10, x9, eq
    ce30:      	cbz	x9, 0xce58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3e44>
    ce34:      	ldr	x10, [sp, #0x18]
    ce38:      	tst	w8, #0x1
    ce3c:      	sub	x1, x9, #0x1
    ce40:      	csel	x8, x24, x10, eq
    ce44:      	ldrb	w8, [x8, x1]
    ce48:      	cbnz	w8, 0xce58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3e44>
    ce4c:      	add	x0, sp, #0x8
    ce50:      	mov	w2, wzr
    ce54:      	bl	0x1d760 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6resizeEmc@plt>
    ce58:      	ldur	q0, [sp, #0x8]
    ce5c:      	ldr	x8, [sp, #0x18]
    ce60:      	str	q0, [x19]
    ce64:      	str	x8, [x19, #0x10]
    ce68:      	ldr	x8, [x25, #0x28]
    ce6c:      	ldur	x9, [x29, #-0x8]
    ce70:      	cmp	x8, x9
    ce74:      	b.ne	0xce94 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3e80>
    ce78:      	ldp	x20, x19, [sp, #0x70]
    ce7c:      	ldp	x22, x21, [sp, #0x60]
    ce80:      	ldp	x24, x23, [sp, #0x50]
    ce84:      	ldp	x26, x25, [sp, #0x40]
    ce88:      	ldp	x29, x30, [sp, #0x30]
    ce8c:      	add	sp, sp, #0x80
    ce90:      	ret
    ce94:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    ce98:      	add	x0, sp, #0x8
    ce9c:      	bl	0xcea0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3e8c>
    cea0:      	stp	x29, x30, [sp, #-0x10]!
    cea4:      	mov	x29, sp
    cea8:      	adrp	x0, 0x4000
    ceac:      	add	x0, x0, #0x5fd
    ceb0:      	bl	0xceb4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3ea0>
    ceb4:      	stp	x29, x30, [sp, #-0x10]!
    ceb8:      	mov	x29, sp
    cebc:      	mov	x1, x0
    cec0:      	adrp	x0, 0x3000
    cec4:      	add	x0, x0, #0x405
    cec8:      	bl	0x1d770 <_ZNSt6__ndk122__libcpp_verbose_abortEPKcz@plt>
    cecc:      	stp	x29, x30, [sp, #-0x40]!
    ced0:      	str	x23, [sp, #0x10]
    ced4:      	stp	x22, x21, [sp, #0x20]
    ced8:      	stp	x20, x19, [sp, #0x30]
    cedc:      	mov	x29, sp
    cee0:      	mov	x21, x1
    cee4:      	mov	x19, x0
    cee8:      	mov	x0, x1
    ceec:      	mov	w1, #0x20               // =32
    cef0:      	mov	x2, xzr
    cef4:      	bl	0x1d730 <_ZNKSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE4findEcm@plt>
    cef8:      	cmn	x0, #0x1
    cefc:      	b.eq	0xcf7c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3f68>
    cf00:      	add	x20, x0, #0x1
    cf04:      	mov	x22, x0
    cf08:      	mov	x0, x21
    cf0c:      	mov	w1, #0x20               // =32
    cf10:      	mov	x2, x20
    cf14:      	bl	0x1d730 <_ZNKSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE4findEcm@plt>
    cf18:      	cmn	x0, #0x1
    cf1c:      	b.eq	0xcfa8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3f94>
    cf20:      	ldrb	w8, [x21]
    cf24:      	ldr	x9, [x21, #0x8]
    cf28:      	lsr	x10, x8, #1
    cf2c:      	tst	w8, #0x1
    cf30:      	csel	x9, x10, x9, eq
    cf34:      	cmp	x9, x22
    cf38:      	b.ls	0xd09c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4088>
    cf3c:      	mvn	x10, x22
    cf40:      	ldr	x11, [x21, #0x10]
    cf44:      	tst	w8, #0x1
    cf48:      	add	x10, x0, x10
    cf4c:      	sub	x8, x9, x20
    cf50:      	csinc	x22, x11, x21, ne
    cf54:      	cmp	x8, x10
    cf58:      	csel	x21, x8, x10, lo
    cf5c:      	cmn	x21, #0x10
    cf60:      	b.hs	0xd0a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4090>
    cf64:      	cmp	x21, #0x17
    cf68:      	b.hs	0xcff8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3fe4>
    cf6c:      	lsl	w8, w21, #1
    cf70:      	strb	w8, [x19], #0x1
    cf74:      	cbnz	x21, 0xd014 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4000>
    cf78:      	b	0xd024 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4010>
    cf7c:      	ldrb	w8, [x21]
    cf80:      	tbnz	w8, #0x0, 0xd03c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4028>
    cf84:      	ldr	q0, [x21]
    cf88:      	ldr	x8, [x21, #0x10]
    cf8c:      	str	q0, [x19]
    cf90:      	str	x8, [x19, #0x10]
    cf94:      	ldp	x20, x19, [sp, #0x30]
    cf98:      	ldr	x23, [sp, #0x10]
    cf9c:      	ldp	x22, x21, [sp, #0x20]
    cfa0:      	ldp	x29, x30, [sp], #0x40
    cfa4:      	ret
    cfa8:      	ldrb	w9, [x21]
    cfac:      	ldr	x8, [x21, #0x8]
    cfb0:      	lsr	x10, x9, #1
    cfb4:      	tst	w9, #0x1
    cfb8:      	csel	x8, x10, x8, eq
    cfbc:      	cmp	x8, x22
    cfc0:      	b.ls	0xd09c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4088>
    cfc4:      	ldr	x10, [x21, #0x10]
    cfc8:      	tst	w9, #0x1
    cfcc:      	sub	x22, x8, x20
    cfd0:      	csinc	x21, x10, x21, ne
    cfd4:      	cmn	x22, #0x10
    cfd8:      	b.hs	0xd0a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4090>
    cfdc:      	cmp	x22, #0x17
    cfe0:      	b.hs	0xd058 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4044>
    cfe4:      	lsl	w9, w22, #1
    cfe8:      	cmp	x8, x20
    cfec:      	strb	w9, [x19], #0x1
    cff0:      	b.ne	0xd074 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4060>
    cff4:      	b	0xd084 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4070>
    cff8:      	orr	x23, x21, #0xf
    cffc:      	add	x0, x23, #0x1
    d000:      	bl	0x1d530 <_Znwm@plt>
    d004:      	add	x8, x23, #0x2
    d008:      	stp	x21, x0, [x19, #0x8]
    d00c:      	str	x8, [x19]
    d010:      	mov	x19, x0
    d014:      	add	x1, x22, x20
    d018:      	mov	x0, x19
    d01c:      	mov	x2, x21
    d020:      	bl	0x1d740 <memmove@plt>
    d024:      	strb	wzr, [x19, x21]
    d028:      	ldp	x20, x19, [sp, #0x30]
    d02c:      	ldr	x23, [sp, #0x10]
    d030:      	ldp	x22, x21, [sp, #0x20]
    d034:      	ldp	x29, x30, [sp], #0x40
    d038:      	ret
    d03c:      	ldp	x2, x1, [x21, #0x8]
    d040:      	mov	x0, x19
    d044:      	ldp	x20, x19, [sp, #0x30]
    d048:      	ldr	x23, [sp, #0x10]
    d04c:      	ldp	x22, x21, [sp, #0x20]
    d050:      	ldp	x29, x30, [sp], #0x40
    d054:      	b	0xd1ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x41d8>
    d058:      	orr	x23, x22, #0xf
    d05c:      	add	x0, x23, #0x1
    d060:      	bl	0x1d530 <_Znwm@plt>
    d064:      	add	x8, x23, #0x2
    d068:      	stp	x22, x0, [x19, #0x8]
    d06c:      	str	x8, [x19]
    d070:      	mov	x19, x0
    d074:      	add	x1, x21, x20
    d078:      	mov	x0, x19
    d07c:      	mov	x2, x22
    d080:      	bl	0x1d740 <memmove@plt>
    d084:      	strb	wzr, [x19, x22]
    d088:      	ldp	x20, x19, [sp, #0x30]
    d08c:      	ldr	x23, [sp, #0x10]
    d090:      	ldp	x22, x21, [sp, #0x20]
    d094:      	ldp	x29, x30, [sp], #0x40
    d098:      	ret
    d09c:      	mov	x0, x19
    d0a0:      	bl	0xd1c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x41ac>
    d0a4:      	mov	x0, x19
    d0a8:      	bl	0xcea0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3e8c>
    d0ac:      	stp	x29, x30, [sp, #-0x40]!
    d0b0:      	str	x23, [sp, #0x10]
    d0b4:      	stp	x22, x21, [sp, #0x20]
    d0b8:      	stp	x20, x19, [sp, #0x30]
    d0bc:      	mov	x29, sp
    d0c0:      	mov	x21, x1
    d0c4:      	mov	x19, x0
    d0c8:      	mov	x0, x1
    d0cc:      	mov	w1, #0x20               // =32
    d0d0:      	mov	x2, xzr
    d0d4:      	bl	0x1d730 <_ZNKSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE4findEcm@plt>
    d0d8:      	cmn	x0, #0x1
    d0dc:      	b.eq	0xd14c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4138>
    d0e0:      	add	x2, x0, #0x1
    d0e4:      	mov	x0, x21
    d0e8:      	mov	w1, #0x20               // =32
    d0ec:      	bl	0x1d730 <_ZNKSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE4findEcm@plt>
    d0f0:      	cmn	x0, #0x1
    d0f4:      	b.eq	0xd14c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4138>
    d0f8:      	ldrb	w9, [x21]
    d0fc:      	ldr	x8, [x21, #0x8]
    d100:      	lsr	x10, x9, #1
    d104:      	tst	w9, #0x1
    d108:      	csel	x8, x10, x8, eq
    d10c:      	cmp	x8, x0
    d110:      	b.ls	0xd1b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x419c>
    d114:      	add	x22, x0, #0x1
    d118:      	ldr	x10, [x21, #0x10]
    d11c:      	tst	w9, #0x1
    d120:      	sub	x20, x8, x22
    d124:      	csinc	x21, x10, x21, ne
    d128:      	cmn	x20, #0x10
    d12c:      	b.hs	0xd1b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x41a4>
    d130:      	cmp	x20, #0x17
    d134:      	b.hs	0xd168 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4154>
    d138:      	lsl	w9, w20, #1
    d13c:      	cmp	x8, x22
    d140:      	strb	w9, [x19], #0x1
    d144:      	b.ne	0xd184 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4170>
    d148:      	b	0xd194 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4180>
    d14c:      	strb	wzr, [x19], #0x1
    d150:      	strb	wzr, [x19]
    d154:      	ldp	x20, x19, [sp, #0x30]
    d158:      	ldr	x23, [sp, #0x10]
    d15c:      	ldp	x22, x21, [sp, #0x20]
    d160:      	ldp	x29, x30, [sp], #0x40
    d164:      	ret
    d168:      	orr	x23, x20, #0xf
    d16c:      	add	x0, x23, #0x1
    d170:      	bl	0x1d530 <_Znwm@plt>
    d174:      	add	x8, x23, #0x2
    d178:      	stp	x20, x0, [x19, #0x8]
    d17c:      	str	x8, [x19]
    d180:      	mov	x19, x0
    d184:      	add	x1, x21, x22
    d188:      	mov	x0, x19
    d18c:      	mov	x2, x20
    d190:      	bl	0x1d740 <memmove@plt>
    d194:      	add	x19, x19, x20
    d198:      	strb	wzr, [x19]
    d19c:      	ldp	x20, x19, [sp, #0x30]
    d1a0:      	ldr	x23, [sp, #0x10]
    d1a4:      	ldp	x22, x21, [sp, #0x20]
    d1a8:      	ldp	x29, x30, [sp], #0x40
    d1ac:      	ret
    d1b0:      	mov	x0, x19
    d1b4:      	bl	0xd1c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x41ac>
    d1b8:      	mov	x0, x19
    d1bc:      	bl	0xcea0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3e8c>
    d1c0:      	stp	x29, x30, [sp, #-0x10]!
    d1c4:      	mov	x29, sp
    d1c8:      	adrp	x0, 0x4000
    d1cc:      	add	x0, x0, #0x5fd
    d1d0:      	bl	0xd1d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x41c0>
    d1d4:      	stp	x29, x30, [sp, #-0x10]!
    d1d8:      	mov	x29, sp
    d1dc:      	mov	x1, x0
    d1e0:      	adrp	x0, 0x3000
    d1e4:      	add	x0, x0, #0xd81
    d1e8:      	bl	0x1d770 <_ZNSt6__ndk122__libcpp_verbose_abortEPKcz@plt>
    d1ec:      	stp	x29, x30, [sp, #-0x30]!
    d1f0:      	stp	x22, x21, [sp, #0x10]
    d1f4:      	stp	x20, x19, [sp, #0x20]
    d1f8:      	mov	x29, sp
    d1fc:      	mov	x19, x2
    d200:      	cmp	x2, #0x16
    d204:      	b.hi	0xd224 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4210>
    d208:      	lsl	w8, w19, #1
    d20c:      	strb	w8, [x0], #0x1
    d210:      	add	x2, x19, #0x1
    d214:      	ldp	x20, x19, [sp, #0x20]
    d218:      	ldp	x22, x21, [sp, #0x10]
    d21c:      	ldp	x29, x30, [sp], #0x30
    d220:      	b	0x1d740 <memmove@plt>
    d224:      	mov	x20, x0
    d228:      	cmn	x19, #0x10
    d22c:      	b.hs	0xd264 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4250>
    d230:      	orr	x22, x19, #0xf
    d234:      	mov	x21, x1
    d238:      	add	x0, x22, #0x1
    d23c:      	bl	0x1d530 <_Znwm@plt>
    d240:      	add	x8, x22, #0x2
    d244:      	mov	x1, x21
    d248:      	stp	x19, x0, [x20, #0x8]
    d24c:      	str	x8, [x20]
    d250:      	add	x2, x19, #0x1
    d254:      	ldp	x20, x19, [sp, #0x20]
    d258:      	ldp	x22, x21, [sp, #0x10]
    d25c:      	ldp	x29, x30, [sp], #0x30
    d260:      	b	0x1d740 <memmove@plt>
    d264:      	mov	x0, x20
    d268:      	bl	0xcea0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x3e8c>
    d26c:      	adrp	x0, 0x22000
    d270:      	adrp	x1, 0x26000
    d274:      	add	x1, x1, #0x574
    d278:      	ldr	x0, [x0, #0x110]
    d27c:      	nop
    d280:      	adr	x2, 0x21980
    d284:      	b	0x1d490 <__cxa_atexit@plt>
    d288:      	stp	x29, x30, [sp, #-0x10]!
    d28c:      	mov	x29, sp
    d290:      	nop
    d294:      	adr	x0, 0x26928
    d298:      	nop
    d29c:      	adr	x1, 0xed00 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5cec>
    d2a0:      	bl	0x1d780 <pthread_once@plt>
    d2a4:      	adrp	x8, 0x26000
    d2a8:      	ldrb	w0, [x8, #0x3d0]
    d2ac:      	ldp	x29, x30, [sp], #0x10
    d2b0:      	ret
    d2b4:      	stp	x29, x30, [sp, #-0x60]!
    d2b8:      	stp	x28, x27, [sp, #0x10]
    d2bc:      	stp	x26, x25, [sp, #0x20]
    d2c0:      	stp	x24, x23, [sp, #0x30]
    d2c4:      	stp	x22, x21, [sp, #0x40]
    d2c8:      	stp	x20, x19, [sp, #0x50]
    d2cc:      	mov	x29, sp
    d2d0:      	sub	sp, sp, #0x10
    d2d4:      	mrs	x26, TPIDR_EL0
    d2d8:      	add	x9, x1, #0xf
    d2dc:      	mov	x20, x3
    d2e0:      	ldr	x8, [x26, #0x28]
    d2e4:      	and	x9, x9, #0xfffffffffffffff0
    d2e8:      	mov	x19, x2
    d2ec:      	mov	x23, x1
    d2f0:      	stur	x8, [x29, #-0x8]
    d2f4:      	mov	x8, sp
    d2f8:      	sub	x22, x8, x9
    d2fc:      	mov	sp, x22
    d300:      	mov	w1, wzr
    d304:      	bl	0x1d7c0 <__open_2@plt>
    d308:      	cmn	w0, #0x1
    d30c:      	b.eq	0xd3d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x43bc>
    d310:      	mov	w21, w0
    d314:      	add	x27, x22, x23
    d318:      	mov	w23, #0x1               // =1
    d31c:      	mov	x25, x22
    d320:      	b	0xd33c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4328>
    d324:      	mov	x24, x28
    d328:      	sub	x24, x24, x1
    d32c:      	mov	x0, x22
    d330:      	mov	x2, x24
    d334:      	bl	0x1d740 <memmove@plt>
    d338:      	add	x25, x22, x24
    d33c:      	sub	x2, x27, x25
    d340:      	mov	w0, w21
    d344:      	mov	x1, x25
    d348:      	mov	x3, #-0x1               // =-1
    d34c:      	bl	0x1d7d0 <__read_chk@plt>
    d350:      	tbnz	x0, #0x3f, 0xd3c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x43b4>
    d354:      	add	x24, x25, x0
    d358:      	cbz	x0, 0xd3d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x43c4>
    d35c:      	cmp	x22, x24
    d360:      	b.eq	0xd3bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x43a8>
    d364:      	add	x28, x0, x25
    d368:      	mov	x1, x22
    d36c:      	mov	x25, x1
    d370:      	ldrb	w8, [x25]
    d374:      	cmp	w8, #0xa
    d378:      	b.eq	0xd38c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4378>
    d37c:      	add	x25, x25, #0x1
    d380:      	cmp	x25, x24
    d384:      	b.ne	0xd370 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x435c>
    d388:      	b	0xd324 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4310>
    d38c:      	mov	x0, x1
    d390:      	mov	x1, x25
    d394:      	mov	x2, x20
    d398:      	mov	x3, x23
    d39c:      	blr	x19
    d3a0:      	tbz	w0, #0x0, 0xd3c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x43b4>
    d3a4:      	add	x1, x25, #0x1
    d3a8:      	add	x23, x23, #0x1
    d3ac:      	cmp	x1, x24
    d3b0:      	b.ne	0xd36c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4358>
    d3b4:      	mov	x1, x24
    d3b8:      	b	0xd328 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4314>
    d3bc:      	mov	x1, x22
    d3c0:      	mov	x24, x22
    d3c4:      	b	0xd328 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4314>
    d3c8:      	mov	w19, wzr
    d3cc:      	b	0xd3f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x43dc>
    d3d0:      	mov	w19, wzr
    d3d4:      	b	0xd3f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x43e4>
    d3d8:      	mov	x0, x22
    d3dc:      	mov	x1, x24
    d3e0:      	mov	x2, x20
    d3e4:      	mov	x3, x23
    d3e8:      	blr	x19
    d3ec:      	mov	w19, w0
    d3f0:      	mov	w0, w21
    d3f4:      	bl	0x1d7e0 <close@plt>
    d3f8:      	ldr	x8, [x26, #0x28]
    d3fc:      	ldur	x9, [x29, #-0x8]
    d400:      	cmp	x8, x9
    d404:      	b.ne	0xd42c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4418>
    d408:      	and	w0, w19, #0x1
    d40c:      	mov	sp, x29
    d410:      	ldp	x20, x19, [sp, #0x50]
    d414:      	ldp	x22, x21, [sp, #0x40]
    d418:      	ldp	x24, x23, [sp, #0x30]
    d41c:      	ldp	x26, x25, [sp, #0x20]
    d420:      	ldp	x28, x27, [sp, #0x10]
    d424:      	ldp	x29, x30, [sp], #0x60
    d428:      	ret
    d42c:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    d430:      	cmp	x0, x1
    d434:      	b.eq	0xd4e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x44cc>
    d438:      	mov	x8, x0
    d43c:      	mov	x10, xzr
    d440:      	neg	x9, x0
    d444:      	ldrb	w11, [x8, x10]
    d448:      	cmp	w11, #0x3a
    d44c:      	b.eq	0xd464 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4450>
    d450:      	add	x10, x10, #0x1
    d454:      	add	x11, x8, x10
    d458:      	cmp	x11, x1
    d45c:      	b.ne	0xd444 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4430>
    d460:      	b	0xd4e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x44cc>
    d464:      	cbz	x10, 0xd4e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x44cc>
    d468:      	add	x12, x8, x10
    d46c:      	sub	x11, x9, x10
    d470:      	add	x9, x12, #0x1
    d474:      	b	0xd480 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x446c>
    d478:      	subs	x10, x10, #0x1
    d47c:      	b.eq	0xd4e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x44cc>
    d480:      	add	x12, x8, x10
    d484:      	ldurb	w12, [x12, #-0x1]
    d488:      	cmp	w12, #0x9
    d48c:      	b.eq	0xd478 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4464>
    d490:      	cmp	w12, #0x20
    d494:      	b.eq	0xd478 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4464>
    d498:      	stp	x29, x30, [sp, #-0x10]!
    d49c:      	mov	x29, sp
    d4a0:      	cmp	x9, x1
    d4a4:      	b.eq	0xd748 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4734>
    d4a8:      	ldrb	w12, [x9], #0x1
    d4ac:      	sub	x11, x11, #0x1
    d4b0:      	cmp	w12, #0x20
    d4b4:      	b.eq	0xd4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x448c>
    d4b8:      	sub	x0, x9, #0x1
    d4bc:      	mov	x14, x1
    d4c0:      	cmp	x0, x1
    d4c4:      	b.eq	0xd4e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x44d4>
    d4c8:      	mov	x1, x14
    d4cc:      	ldrb	w9, [x1, #-0x1]!
    d4d0:      	cmp	w9, #0x20
    d4d4:      	b.eq	0xd4bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x44a8>
    d4d8:      	add	x1, x1, #0x1
    d4dc:      	b	0xd4ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x44d8>
    d4e0:      	mov	w0, #0x1                // =1
    d4e4:      	ret
    d4e8:      	mov	x1, x0
    d4ec:      	ldp	w9, w13, [x2, #0x8]
    d4f0:      	mov	w15, #0x18              // =24
    d4f4:      	ldr	x12, [x2, #0x10]
    d4f8:      	add	x16, x2, #0x18
    d4fc:      	umaddl	x15, w9, w15, x12
    d500:      	cmp	w9, w13
    d504:      	csel	x9, x15, x16, lo
    d508:      	cmp	x10, #0xb
    d50c:      	b.gt	0xd570 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x455c>
    d510:      	cmp	x10, #0x8
    d514:      	b.eq	0xd5cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x45b8>
    d518:      	cmp	x10, #0x9
    d51c:      	b.eq	0xd694 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4680>
    d520:      	cmp	x10, #0xb
    d524:      	b.ne	0xd748 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4734>
    d528:      	mov	x11, #0x5043            // =20547
    d52c:      	ldr	x10, [x8]
    d530:      	ldur	x8, [x8, #0x3]
    d534:      	movk	x11, #0x2055, lsl #16
    d538:      	movk	x11, #0x6176, lsl #32
    d53c:      	movk	x11, #0x6972, lsl #48
    d540:      	cmp	x10, x11
    d544:      	mov	x10, #0x7620            // =30240
    d548:      	movk	x10, #0x7261, lsl #16
    d54c:      	movk	x10, #0x6169, lsl #32
    d550:      	movk	x10, #0x746e, lsl #48
    d554:      	ccmp	x8, x10, #0x0, eq
    d558:      	b.ne	0xd748 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4734>
    d55c:      	mov	x2, x9
    d560:      	bl	0xe464 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5450>
    d564:      	ldp	x29, x30, [sp], #0x10
    d568:      	mov	w0, #0x1                // =1
    d56c:      	ret
    d570:      	cmp	x10, #0xc
    d574:      	b.eq	0xd654 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4640>
    d578:      	cmp	x10, #0xf
    d57c:      	b.eq	0xd6f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x46dc>
    d580:      	cmp	x10, #0x10
    d584:      	b.ne	0xd748 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4734>
    d588:      	mov	x11, #0x5043            // =20547
    d58c:      	ldp	x10, x8, [x8]
    d590:      	movk	x11, #0x2055, lsl #16
    d594:      	movk	x11, #0x7261, lsl #32
    d598:      	movk	x11, #0x6863, lsl #48
    d59c:      	cmp	x10, x11
    d5a0:      	mov	x10, #0x7469            // =29801
    d5a4:      	movk	x10, #0x6365, lsl #16
    d5a8:      	movk	x10, #0x7574, lsl #32
    d5ac:      	movk	x10, #0x6572, lsl #48
    d5b0:      	ccmp	x8, x10, #0x0, eq
    d5b4:      	b.ne	0xd748 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4734>
    d5b8:      	mov	x2, x9
    d5bc:      	bl	0xe5f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x55e0>
    d5c0:      	ldp	x29, x30, [sp], #0x10
    d5c4:      	mov	w0, #0x1                // =1
    d5c8:      	ret
    d5cc:      	mov	x12, #0x5043            // =20547
    d5d0:      	ldr	x10, [x8]
    d5d4:      	movk	x12, #0x2055, lsl #16
    d5d8:      	movk	x12, #0x6170, lsl #32
    d5dc:      	movk	x12, #0x7472, lsl #48
    d5e0:      	cmp	x10, x12
    d5e4:      	b.eq	0xd768 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4754>
    d5e8:      	mov	x10, #0x6546            // =25926
    d5ec:      	ldr	x9, [x8]
    d5f0:      	movk	x10, #0x7461, lsl #16
    d5f4:      	movk	x10, #0x7275, lsl #32
    d5f8:      	movk	x10, #0x7365, lsl #48
    d5fc:      	cmp	x9, x10
    d600:      	b.eq	0xd748 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4734>
    d604:      	mov	x10, #0x6f42            // =28482
    d608:      	ldr	x9, [x8]
    d60c:      	movk	x10, #0x6f67, lsl #16
    d610:      	movk	x10, #0x494d, lsl #32
    d614:      	movk	x10, #0x5350, lsl #48
    d618:      	cmp	x9, x10
    d61c:      	b.eq	0xd748 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4734>
    d620:      	mov	x9, #0x6148             // =24904
    d624:      	ldr	x8, [x8]
    d628:      	movk	x9, #0x6472, lsl #16
    d62c:      	movk	x9, #0x6177, lsl #32
    d630:      	movk	x9, #0x6572, lsl #48
    d634:      	cmp	x8, x9
    d638:      	b.ne	0xd748 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4734>
    d63c:      	add	x8, x1, x11
    d640:      	mov	x9, x0
    d644:      	cmp	x8, #0x40
    d648:      	b.ls	0xd7ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4798>
    d64c:      	mov	w8, #0x40               // =64
    d650:      	b	0xd7b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x47a4>
    d654:      	mov	x11, #0x5043            // =20547
    d658:      	ldr	x10, [x8]
    d65c:      	ldr	w8, [x8, #0x8]
    d660:      	movk	x11, #0x2055, lsl #16
    d664:      	movk	x11, #0x6572, lsl #32
    d668:      	movk	x11, #0x6976, lsl #48
    d66c:      	cmp	x10, x11
    d670:      	mov	w10, #0x6973            // =26995
    d674:      	movk	w10, #0x6e6f, lsl #16
    d678:      	ccmp	w8, w10, #0x0, eq
    d67c:      	b.ne	0xd748 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4734>
    d680:      	mov	x2, x9
    d684:      	bl	0xe4dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x54c8>
    d688:      	ldp	x29, x30, [sp], #0x10
    d68c:      	mov	w0, #0x1                // =1
    d690:      	ret
    d694:      	mov	x10, #0x7270            // =29296
    d698:      	ldr	x9, [x8]
    d69c:      	ldrb	w8, [x8, #0x8]
    d6a0:      	movk	x10, #0x636f, lsl #16
    d6a4:      	movk	x10, #0x7365, lsl #32
    d6a8:      	movk	x10, #0x6f73, lsl #48
    d6ac:      	cmp	x9, x10
    d6b0:      	mov	w9, #0x72               // =114
    d6b4:      	ccmp	w8, w9, #0x0, eq
    d6b8:      	b.ne	0xd748 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4734>
    d6bc:      	cmp	x0, x14
    d6c0:      	b.eq	0xd77c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4768>
    d6c4:      	mov	w8, wzr
    d6c8:      	mov	w9, #0xa                // =10
    d6cc:      	ldrb	w10, [x0]
    d6d0:      	sub	w10, w10, #0x30
    d6d4:      	cmp	w10, #0xa
    d6d8:      	b.hi	0xd780 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x476c>
    d6dc:      	madd	w8, w8, w9, w10
    d6e0:      	add	x0, x0, #0x1
    d6e4:      	cmp	x0, x1
    d6e8:      	b.ne	0xd6cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x46b8>
    d6ec:      	b	0xd780 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x476c>
    d6f0:      	mov	x10, #0x5043            // =20547
    d6f4:      	ldr	x11, [x8]
    d6f8:      	ldur	x12, [x8, #0x7]
    d6fc:      	movk	x10, #0x2055, lsl #16
    d700:      	movk	x10, #0x6d69, lsl #32
    d704:      	movk	x10, #0x6c70, lsl #48
    d708:      	cmp	x11, x10
    d70c:      	mov	x11, #0x656c            // =25964
    d710:      	movk	x11, #0x656d, lsl #16
    d714:      	movk	x11, #0x746e, lsl #32
    d718:      	movk	x11, #0x7265, lsl #48
    d71c:      	ccmp	x12, x11, #0x0, eq
    d720:      	b.eq	0xd754 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4740>
    d724:      	ldr	x11, [x8]
    d728:      	ldur	x8, [x8, #0x7]
    d72c:      	cmp	x11, x10
    d730:      	mov	x10, #0x656c            // =25964
    d734:      	movk	x10, #0x656d, lsl #16
    d738:      	movk	x10, #0x746e, lsl #32
    d73c:      	movk	x10, #0x726f, lsl #48
    d740:      	ccmp	x8, x10, #0x0, eq
    d744:      	b.eq	0xd754 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4740>
    d748:      	ldp	x29, x30, [sp], #0x10
    d74c:      	mov	w0, #0x1                // =1
    d750:      	ret
    d754:      	mov	x2, x9
    d758:      	bl	0xe538 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5524>
    d75c:      	ldp	x29, x30, [sp], #0x10
    d760:      	mov	w0, #0x1                // =1
    d764:      	ret
    d768:      	mov	x2, x9
    d76c:      	bl	0xe3a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5394>
    d770:      	ldp	x29, x30, [sp], #0x10
    d774:      	mov	w0, #0x1                // =1
    d778:      	ret
    d77c:      	mov	w8, wzr
    d780:      	cmp	w8, w13
    d784:      	b.hs	0xd79c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4788>
    d788:      	mov	w9, #0x18               // =24
    d78c:      	umaddl	x9, w8, w9, x12
    d790:      	ldr	w10, [x9, #0x14]
    d794:      	orr	w10, w10, #0x200000
    d798:      	str	w10, [x9, #0x14]
    d79c:      	str	w8, [x2, #0x8]
    d7a0:      	ldp	x29, x30, [sp], #0x10
    d7a4:      	mov	w0, #0x1                // =1
    d7a8:      	ret
    d7ac:      	ldr	x10, [x2]
    d7b0:      	add	x10, x10, x1
    d7b4:      	strb	wzr, [x10, x11]
    d7b8:      	ldr	x0, [x2]
    d7bc:      	mov	x1, x9
    d7c0:      	mov	x2, x8
    d7c4:      	bl	0x1d540 <memcpy@plt>
    d7c8:      	ldp	x29, x30, [sp], #0x10
    d7cc:      	mov	w0, #0x1                // =1
    d7d0:      	ret
    d7d4:      	stp	x29, x30, [sp, #-0x20]!
    d7d8:      	stp	x20, x19, [sp, #0x10]
    d7dc:      	mov	x29, sp
    d7e0:      	mov	w1, #0x40               // =64
    d7e4:      	mov	x20, x0
    d7e8:      	mov	x19, x8
    d7ec:      	bl	0x1d810 <strnlen@plt>
    d7f0:      	and	x8, x0, #0xfffffffffffffffe
    d7f4:      	cmp	x8, #0x12
    d7f8:      	b.ne	0xd88c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4878>
    d7fc:      	mov	w8, #-0x20202021        // =-538976289
    d800:      	ldr	w9, [x20]
    d804:      	orr	w10, w8, #0x20
    d808:      	and	w9, w9, w10
    d80c:      	mov	w10, #0x4153            // =16723
    d810:      	movk	w10, #0x534d, lsl #16
    d814:      	cmp	w9, w10
    d818:      	b.ne	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d81c:      	ldr	w9, [x20, #0x4]
    d820:      	mov	w10, #0xdfdf            // =57311
    d824:      	movk	w10, #0xffdf, lsl #16
    d828:      	and	w9, w9, w10
    d82c:      	mov	w10, #0x4e55            // =20053
    d830:      	movk	w10, #0x2047, lsl #16
    d834:      	cmp	w9, w10
    d838:      	b.ne	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d83c:      	ldr	w9, [x20, #0x8]
    d840:      	add	w8, w8, #0x20
    d844:      	and	w8, w9, w8
    d848:      	mov	w9, #0x5845             // =22597
    d84c:      	movk	w9, #0x4e59, lsl #16
    d850:      	cmp	w8, w9
    d854:      	b.ne	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d858:      	ldrh	w8, [x20, #0xc]
    d85c:      	mov	w9, #0x534f             // =21327
    d860:      	and	w8, w8, #0xdfdfdfdf
    d864:      	cmp	w8, w9
    d868:      	b.ne	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d86c:      	ldrb	w8, [x20, #0xe]
    d870:      	cmp	w8, #0x20
    d874:      	b.ne	0xd934 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4920>
    d878:      	cmp	x0, #0x13
    d87c:      	b.ne	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d880:      	ldrb	w8, [x20, #0xf]
    d884:      	mov	w9, #0xf                // =15
    d888:      	b	0xd938 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4924>
    d88c:      	cmp	x0, #0xd
    d890:      	b.ne	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d894:      	ldrb	w8, [x20]
    d898:      	and	w8, w8, #0xffffffdf
    d89c:      	cmp	w8, #0x55
    d8a0:      	b.ne	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d8a4:      	ldur	w8, [x20, #0x1]
    d8a8:      	mov	w9, #0x494e             // =18766
    d8ac:      	movk	w9, #0x4556, lsl #16
    d8b0:      	and	w8, w8, #0xdfdfdfdf
    d8b4:      	cmp	w8, w9
    d8b8:      	b.ne	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d8bc:      	ldur	w8, [x20, #0x5]
    d8c0:      	mov	w9, #-0x20202021        // =-538976289
    d8c4:      	and	w8, w8, w9
    d8c8:      	mov	w9, #0x5352             // =21330
    d8cc:      	movk	w9, #0x4c41, lsl #16
    d8d0:      	cmp	w8, w9
    d8d4:      	b.ne	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d8d8:      	ldrb	w8, [x20, #0x9]
    d8dc:      	sub	w8, w8, #0x30
    d8e0:      	cmp	w8, #0x9
    d8e4:      	b.hi	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d8e8:      	ldrb	w9, [x20, #0xa]
    d8ec:      	sub	w9, w9, #0x30
    d8f0:      	cmp	w9, #0x9
    d8f4:      	b.hi	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d8f8:      	ldrb	w10, [x20, #0xb]
    d8fc:      	sub	w10, w10, #0x30
    d900:      	cmp	w10, #0x9
    d904:      	b.hi	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d908:      	ldrb	w11, [x20, #0xc]
    d90c:      	sub	w11, w11, #0x30
    d910:      	cmp	w11, #0x9
    d914:      	b.hi	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d918:      	mov	w12, #0xa               // =10
    d91c:      	madd	w8, w8, w12, w9
    d920:      	adrp	x9, 0x4000
    d924:      	ldr	d0, [x9, #0xf58]
    d928:      	madd	w8, w8, w12, w10
    d92c:      	madd	w8, w8, w12, w11
    d930:      	b	0xd990 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x497c>
    d934:      	mov	w9, #0xe                // =14
    d938:      	sub	w8, w8, #0x30
    d93c:      	cmp	w8, #0x9
    d940:      	b.hi	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d944:      	add	x10, x20, x9
    d948:      	ldrb	w9, [x10, #0x1]
    d94c:      	sub	w9, w9, #0x30
    d950:      	cmp	w9, #0x9
    d954:      	b.hi	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d958:      	ldrb	w11, [x10, #0x2]
    d95c:      	sub	w11, w11, #0x30
    d960:      	cmp	w11, #0x9
    d964:      	b.hi	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d968:      	ldrb	w10, [x10, #0x3]
    d96c:      	sub	w10, w10, #0x30
    d970:      	cmp	w10, #0x9
    d974:      	b.hi	0xd9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4994>
    d978:      	mov	w12, #0xa               // =10
    d97c:      	madd	w8, w8, w12, w9
    d980:      	adrp	x9, 0x4000
    d984:      	ldr	d0, [x9, #0xf58]
    d988:      	madd	w8, w8, w12, w11
    d98c:      	madd	w8, w8, w12, w10
    d990:      	str	d0, [x19]
    d994:      	str	w8, [x19, #0x8]
    d998:      	stur	xzr, [x19, #0xc]
    d99c:      	ldp	x20, x19, [sp, #0x10]
    d9a0:      	ldp	x29, x30, [sp], #0x20
    d9a4:      	ret
    d9a8:      	stp	xzr, xzr, [x19]
    d9ac:      	str	wzr, [x19, #0x10]
    d9b0:      	ldp	x20, x19, [sp, #0x10]
    d9b4:      	ldp	x29, x30, [sp], #0x20
    d9b8:      	ret
    d9bc:      	stp	x29, x30, [sp, #-0x20]!
    d9c0:      	stp	x20, x19, [sp, #0x10]
    d9c4:      	mov	x29, sp
    d9c8:      	mov	w1, #0x5c               // =92
    d9cc:      	mov	x20, x0
    d9d0:      	mov	x19, x8
    d9d4:      	bl	0x1d810 <strnlen@plt>
    d9d8:      	cmp	x0, #0xd
    d9dc:      	b.eq	0xda44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4a30>
    d9e0:      	cmp	x0, #0xa
    d9e4:      	b.ne	0xdaf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ae4>
    d9e8:      	ldr	w8, [x20]
    d9ec:      	mov	w9, #0x7865             // =30821
    d9f0:      	movk	w9, #0x6e79, lsl #16
    d9f4:      	cmp	w8, w9
    d9f8:      	b.ne	0xdaf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ae4>
    d9fc:      	ldrh	w8, [x20, #0x4]
    da00:      	mov	w9, #0x736f             // =29551
    da04:      	cmp	w8, w9
    da08:      	b.ne	0xdaf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ae4>
    da0c:      	ldrb	w8, [x20, #0x6]
    da10:      	sub	w8, w8, #0x30
    da14:      	cmp	w8, #0x9
    da18:      	b.hi	0xdaf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ae4>
    da1c:      	ldrb	w9, [x20, #0x7]
    da20:      	sub	w9, w9, #0x30
    da24:      	cmp	w9, #0x9
    da28:      	b.hi	0xdaf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ae4>
    da2c:      	ldrb	w10, [x20, #0x8]
    da30:      	sub	w10, w10, #0x30
    da34:      	cmp	w10, #0x9
    da38:      	b.hi	0xdaf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ae4>
    da3c:      	ldrb	w11, [x20, #0x9]
    da40:      	b	0xdabc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4aa8>
    da44:      	ldrb	w8, [x20]
    da48:      	and	w8, w8, #0xffffffdf
    da4c:      	cmp	w8, #0x55
    da50:      	b.ne	0xdaf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ae4>
    da54:      	ldur	w8, [x20, #0x1]
    da58:      	mov	w9, #0x494e             // =18766
    da5c:      	movk	w9, #0x4556, lsl #16
    da60:      	and	w8, w8, #0xdfdfdfdf
    da64:      	cmp	w8, w9
    da68:      	b.ne	0xdaf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ae4>
    da6c:      	ldur	w8, [x20, #0x5]
    da70:      	mov	w9, #-0x20202021        // =-538976289
    da74:      	and	w8, w8, w9
    da78:      	mov	w9, #0x5352             // =21330
    da7c:      	movk	w9, #0x4c41, lsl #16
    da80:      	cmp	w8, w9
    da84:      	b.ne	0xdaf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ae4>
    da88:      	ldrb	w8, [x20, #0x9]
    da8c:      	sub	w8, w8, #0x30
    da90:      	cmp	w8, #0x9
    da94:      	b.hi	0xdaf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ae4>
    da98:      	ldrb	w9, [x20, #0xa]
    da9c:      	sub	w9, w9, #0x30
    daa0:      	cmp	w9, #0x9
    daa4:      	b.hi	0xdaf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ae4>
    daa8:      	ldrb	w10, [x20, #0xb]
    daac:      	sub	w10, w10, #0x30
    dab0:      	cmp	w10, #0x9
    dab4:      	b.hi	0xdaf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ae4>
    dab8:      	ldrb	w11, [x20, #0xc]
    dabc:      	sub	w11, w11, #0x30
    dac0:      	cmp	w11, #0x9
    dac4:      	b.hi	0xdaf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ae4>
    dac8:      	mov	w12, #0xa               // =10
    dacc:      	madd	w8, w8, w12, w9
    dad0:      	adrp	x9, 0x4000
    dad4:      	ldr	d0, [x9, #0xf58]
    dad8:      	madd	w8, w8, w12, w10
    dadc:      	str	d0, [x19]
    dae0:      	madd	w8, w8, w12, w11
    dae4:      	str	w8, [x19, #0x8]
    dae8:      	stur	xzr, [x19, #0xc]
    daec:      	ldp	x20, x19, [sp, #0x10]
    daf0:      	ldp	x29, x30, [sp], #0x20
    daf4:      	ret
    daf8:      	stp	xzr, xzr, [x19]
    dafc:      	str	wzr, [x19, #0x10]
    db00:      	ldp	x20, x19, [sp, #0x10]
    db04:      	ldp	x29, x30, [sp], #0x20
    db08:      	ret
    db0c:      	sub	sp, sp, #0xe0
    db10:      	stp	x29, x30, [sp, #0xa0]
    db14:      	str	x23, [sp, #0xb0]
    db18:      	stp	x22, x21, [sp, #0xc0]
    db1c:      	stp	x20, x19, [sp, #0xd0]
    db20:      	add	x29, sp, #0xa0
    db24:      	mrs	x22, TPIDR_EL0
    db28:      	mov	x19, x8
    db2c:      	mov	x20, x0
    db30:      	ldr	x8, [x22, #0x28]
    db34:      	add	x21, sp, #0xc
    db38:      	stur	x8, [x29, #-0x8]
    db3c:      	add	x8, sp, #0xc
    db40:      	stp	xzr, xzr, [x19]
    db44:      	str	wzr, [x19, #0x10]
    db48:      	bl	0xd7d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x47c0>
    db4c:      	add	x0, x20, #0x40
    db50:      	mov	w1, #0x5c               // =92
    db54:      	bl	0x1d810 <strnlen@plt>
    db58:      	cmp	x0, #0xd
    db5c:      	b.ne	0xdc0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4bf8>
    db60:      	ldurb	w8, [x20, #0x40]
    db64:      	and	w8, w8, #0xffffffdf
    db68:      	cmp	w8, #0x55
    db6c:      	b.ne	0xdc0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4bf8>
    db70:      	ldur	w8, [x20, #0x41]
    db74:      	mov	w9, #0x494e             // =18766
    db78:      	movk	w9, #0x4556, lsl #16
    db7c:      	and	w8, w8, #0xdfdfdfdf
    db80:      	cmp	w8, w9
    db84:      	b.ne	0xdc0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4bf8>
    db88:      	ldur	w8, [x20, #0x45]
    db8c:      	mov	w9, #-0x20202021        // =-538976289
    db90:      	and	w8, w8, w9
    db94:      	mov	w9, #0x5352             // =21330
    db98:      	movk	w9, #0x4c41, lsl #16
    db9c:      	cmp	w8, w9
    dba0:      	b.ne	0xdc0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4bf8>
    dba4:      	ldrb	w8, [x20, #0x49]
    dba8:      	sub	w8, w8, #0x30
    dbac:      	cmp	w8, #0x9
    dbb0:      	b.hi	0xdc0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4bf8>
    dbb4:      	ldrb	w9, [x20, #0x4a]
    dbb8:      	sub	w9, w9, #0x30
    dbbc:      	cmp	w9, #0x9
    dbc0:      	b.hi	0xdc0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4bf8>
    dbc4:      	ldrb	w10, [x20, #0x4b]
    dbc8:      	sub	w10, w10, #0x30
    dbcc:      	cmp	w10, #0x9
    dbd0:      	b.hi	0xdc0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4bf8>
    dbd4:      	ldrb	w11, [x20, #0x4c]
    dbd8:      	sub	w11, w11, #0x30
    dbdc:      	cmp	w11, #0x9
    dbe0:      	b.hi	0xdc0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4bf8>
    dbe4:      	mov	w12, #0xa               // =10
    dbe8:      	stur	xzr, [sp, #0x2c]
    dbec:      	madd	w8, w8, w12, w9
    dbf0:      	adrp	x9, 0x4000
    dbf4:      	ldr	d0, [x9, #0xf58]
    dbf8:      	madd	w8, w8, w12, w10
    dbfc:      	stur	d0, [sp, #0x20]
    dc00:      	madd	w8, w8, w12, w11
    dc04:      	str	w8, [sp, #0x28]
    dc08:      	b	0xdc18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4c04>
    dc0c:      	stur	xzr, [x21, #0x1c]
    dc10:      	stur	xzr, [x21, #0x14]
    dc14:      	stur	wzr, [x21, #0x24]
    dc18:      	mov	w23, #0x7865            // =30821
    dc1c:      	add	x0, x20, #0x9c
    dc20:      	mov	w1, #0x5c               // =92
    dc24:      	movk	w23, #0x6e79, lsl #16
    dc28:      	bl	0x1d810 <strnlen@plt>
    dc2c:      	cmp	x0, #0xa
    dc30:      	b.ne	0xdcb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ca4>
    dc34:      	ldur	w8, [x20, #0x9c]
    dc38:      	cmp	w8, w23
    dc3c:      	b.ne	0xdcb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ca4>
    dc40:      	ldrh	w8, [x20, #0xa0]
    dc44:      	mov	w9, #0x736f             // =29551
    dc48:      	cmp	w8, w9
    dc4c:      	b.ne	0xdcb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ca4>
    dc50:      	ldrb	w8, [x20, #0xa2]
    dc54:      	sub	w8, w8, #0x30
    dc58:      	cmp	w8, #0x9
    dc5c:      	b.hi	0xdcb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ca4>
    dc60:      	ldrb	w9, [x20, #0xa3]
    dc64:      	sub	w9, w9, #0x30
    dc68:      	cmp	w9, #0x9
    dc6c:      	b.hi	0xdcb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ca4>
    dc70:      	ldrb	w10, [x20, #0xa4]
    dc74:      	sub	w10, w10, #0x30
    dc78:      	cmp	w10, #0x9
    dc7c:      	b.hi	0xdcb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ca4>
    dc80:      	ldrb	w11, [x20, #0xa5]
    dc84:      	sub	w11, w11, #0x30
    dc88:      	cmp	w11, #0x9
    dc8c:      	b.hi	0xdcb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ca4>
    dc90:      	mov	w12, #0xa               // =10
    dc94:      	stur	xzr, [sp, #0x40]
    dc98:      	madd	w8, w8, w12, w9
    dc9c:      	adrp	x9, 0x4000
    dca0:      	ldr	d0, [x9, #0xf58]
    dca4:      	madd	w8, w8, w12, w10
    dca8:      	stur	d0, [sp, #0x34]
    dcac:      	madd	w8, w8, w12, w11
    dcb0:      	str	w8, [sp, #0x3c]
    dcb4:      	b	0xdcc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4cb0>
    dcb8:      	add	x8, sp, #0xc
    dcbc:      	stp	xzr, xzr, [x8, #0x28]
    dcc0:      	stur	wzr, [x8, #0x38]
    dcc4:      	add	x21, x20, #0x154
    dcc8:      	mov	w1, #0x5c               // =92
    dccc:      	stp	xzr, xzr, [sp, #0x48]
    dcd0:      	mov	x0, x21
    dcd4:      	str	wzr, [sp, #0x58]
    dcd8:      	bl	0x1d810 <strnlen@plt>
    dcdc:      	cmp	x0, #0xa
    dce0:      	b.ne	0xdd68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4d54>
    dce4:      	ldr	w8, [x21]
    dce8:      	cmp	w8, w23
    dcec:      	b.ne	0xdd68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4d54>
    dcf0:      	ldrh	w8, [x20, #0x158]
    dcf4:      	mov	w9, #0x736f             // =29551
    dcf8:      	cmp	w8, w9
    dcfc:      	b.ne	0xdd68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4d54>
    dd00:      	ldrb	w8, [x20, #0x15a]
    dd04:      	sub	w8, w8, #0x30
    dd08:      	cmp	w8, #0x9
    dd0c:      	b.hi	0xdd68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4d54>
    dd10:      	ldrb	w9, [x20, #0x15b]
    dd14:      	sub	w9, w9, #0x30
    dd18:      	cmp	w9, #0x9
    dd1c:      	b.hi	0xdd68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4d54>
    dd20:      	ldrb	w10, [x20, #0x15c]
    dd24:      	sub	w10, w10, #0x30
    dd28:      	cmp	w10, #0x9
    dd2c:      	b.hi	0xdd68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4d54>
    dd30:      	ldrb	w11, [x20, #0x15d]
    dd34:      	sub	w11, w11, #0x30
    dd38:      	cmp	w11, #0x9
    dd3c:      	b.hi	0xdd68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4d54>
    dd40:      	mov	w12, #0xa               // =10
    dd44:      	stur	xzr, [sp, #0x68]
    dd48:      	madd	w8, w8, w12, w9
    dd4c:      	adrp	x9, 0x4000
    dd50:      	ldr	d0, [x9, #0xf58]
    dd54:      	madd	w8, w8, w12, w10
    dd58:      	stur	d0, [sp, #0x5c]
    dd5c:      	madd	w8, w8, w12, w11
    dd60:      	str	w8, [sp, #0x64]
    dd64:      	b	0xdd74 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4d60>
    dd68:      	add	x8, sp, #0xc
    dd6c:      	stp	xzr, xzr, [x8, #0x50]
    dd70:      	stur	wzr, [x8, #0x60]
    dd74:      	add	x21, sp, #0xc
    dd78:      	add	x0, x20, #0x1b0
    dd7c:      	add	x8, x21, #0x64
    dd80:      	bl	0xd9bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x49a8>
    dd84:      	add	x8, x21, #0x78
    dd88:      	add	x0, x20, #0x20c
    dd8c:      	bl	0xd9bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x49a8>
    dd90:      	ldr	w8, [sp, #0xc]
    dd94:      	ldr	w9, [sp, #0x20]
    dd98:      	cbz	w8, 0xddac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4d98>
    dd9c:      	cbz	w9, 0xddb4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4da0>
    dda0:      	cmp	w8, w9
    dda4:      	b.ne	0xdef0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4edc>
    dda8:      	b	0xddb4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4da0>
    ddac:      	mov	w8, w9
    ddb0:      	cbz	w9, 0xddc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4db4>
    ddb4:      	ldr	w9, [sp, #0x34]
    ddb8:      	cbz	w9, 0xddd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4dbc>
    ddbc:      	cmp	w8, w9
    ddc0:      	b.ne	0xdef0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4edc>
    ddc4:      	b	0xddd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4dbc>
    ddc8:      	ldr	w8, [sp, #0x34]
    ddcc:      	cbz	w8, 0xddf0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ddc>
    ddd0:      	ldr	w9, [sp, #0x48]
    ddd4:      	cbz	w9, 0xddf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4de4>
    ddd8:      	cbz	w8, 0xdde8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4dd4>
    dddc:      	cmp	w8, w9
    dde0:      	b.eq	0xddf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4de4>
    dde4:      	b	0xdef0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4edc>
    dde8:      	mov	w8, w9
    ddec:      	b	0xddf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4de4>
    ddf0:      	ldr	w8, [sp, #0x48]
    ddf4:      	cbz	w8, 0xde6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e58>
    ddf8:      	ldr	w9, [sp, #0x5c]
    ddfc:      	cbz	w9, 0xde14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e00>
    de00:      	cbz	w8, 0xde10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4dfc>
    de04:      	cmp	w8, w9
    de08:      	b.eq	0xde14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e00>
    de0c:      	b	0xdef0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4edc>
    de10:      	mov	w8, w9
    de14:      	ldr	w9, [sp, #0x70]
    de18:      	cbz	w9, 0xde30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e1c>
    de1c:      	cbz	w8, 0xde2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e18>
    de20:      	cmp	w8, w9
    de24:      	b.eq	0xde30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e1c>
    de28:      	b	0xdef0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4edc>
    de2c:      	mov	w8, w9
    de30:      	ldr	w9, [sp, #0x84]
    de34:      	cbz	w9, 0xde48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e34>
    de38:      	cbz	w8, 0xde4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e38>
    de3c:      	cmp	w8, w9
    de40:      	b.ne	0xdef0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4edc>
    de44:      	b	0xde4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e38>
    de48:      	cbz	w8, 0xdef0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4edc>
    de4c:      	ldr	w8, [sp, #0x10]
    de50:      	cbz	w8, 0xde5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e48>
    de54:      	mov	x8, xzr
    de58:      	b	0xded4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ec0>
    de5c:      	ldr	w8, [sp, #0x24]
    de60:      	cbz	w8, 0xde88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e74>
    de64:      	mov	w8, #0x1                // =1
    de68:      	b	0xded4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ec0>
    de6c:      	ldr	w8, [sp, #0x5c]
    de70:      	cbnz	w8, 0xde14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e00>
    de74:      	ldr	w8, [sp, #0x70]
    de78:      	cbnz	w8, 0xde30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e1c>
    de7c:      	ldr	w8, [sp, #0x84]
    de80:      	cbnz	w8, 0xde4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e38>
    de84:      	b	0xdef0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4edc>
    de88:      	ldr	w8, [sp, #0x38]
    de8c:      	cbz	w8, 0xde98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e84>
    de90:      	mov	w8, #0x2                // =2
    de94:      	b	0xded4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ec0>
    de98:      	ldr	w8, [sp, #0x4c]
    de9c:      	cbz	w8, 0xdea8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4e94>
    dea0:      	mov	w8, #0x3                // =3
    dea4:      	b	0xded4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ec0>
    dea8:      	ldr	w8, [sp, #0x60]
    deac:      	cbz	w8, 0xdeb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ea4>
    deb0:      	mov	w8, #0x4                // =4
    deb4:      	b	0xded4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ec0>
    deb8:      	ldr	w8, [sp, #0x74]
    debc:      	cbz	w8, 0xdec8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4eb4>
    dec0:      	mov	w8, #0x5                // =5
    dec4:      	b	0xded4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4ec0>
    dec8:      	ldr	w8, [sp, #0x88]
    decc:      	cbz	w8, 0xdef0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4edc>
    ded0:      	mov	w8, #0x6                // =6
    ded4:      	mov	w9, #0x14               // =20
    ded8:      	add	x10, sp, #0xc
    dedc:      	umaddl	x8, w8, w9, x10
    dee0:      	ldr	q0, [x8]
    dee4:      	ldr	w8, [x8, #0x10]
    dee8:      	str	q0, [x19]
    deec:      	str	w8, [x19, #0x10]
    def0:      	ldr	x8, [x22, #0x28]
    def4:      	ldur	x9, [x29, #-0x8]
    def8:      	cmp	x8, x9
    defc:      	b.ne	0xdf18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4f04>
    df00:      	ldp	x20, x19, [sp, #0xd0]
    df04:      	ldr	x23, [sp, #0xb0]
    df08:      	ldp	x22, x21, [sp, #0xc0]
    df0c:      	ldp	x29, x30, [sp, #0xa0]
    df10:      	add	sp, sp, #0xe0
    df14:      	ret
    df18:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    df1c:      	stp	x29, x30, [sp, #-0x60]!
    df20:      	stp	x28, x27, [sp, #0x10]
    df24:      	stp	x26, x25, [sp, #0x20]
    df28:      	stp	x24, x23, [sp, #0x30]
    df2c:      	stp	x22, x21, [sp, #0x40]
    df30:      	stp	x20, x19, [sp, #0x50]
    df34:      	mov	x29, sp
    df38:      	sub	sp, sp, #0x540
    df3c:      	str	x2, [sp, #0x8]
    df40:      	mrs	x26, TPIDR_EL0
    df44:      	mov	x22, x1
    df48:      	ldr	x8, [x26, #0x28]
    df4c:      	mov	x23, x0
    df50:      	mov	x20, x4
    df54:      	mov	x21, x3
    df58:      	add	x27, sp, #0xcc
    df5c:      	stur	x8, [x29, #-0x18]
    df60:      	strb	wzr, [x0]
    df64:      	nop
    df68:      	adr	x0, 0x2e92
    df6c:      	strb	wzr, [x1]
    df70:      	adrp	x1, 0x3000
    df74:      	add	x1, x1, #0xa3f
    df78:      	bl	0x1d820 <fopen@plt>
    df7c:      	cbz	x0, 0xdfec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4fd8>
    df80:      	mov	x24, x0
    df84:      	bl	0x1d830 <feof@plt>
    df88:      	mov	w25, wzr
    df8c:      	cbnz	w0, 0xdfd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4fc4>
    df90:      	mov	x28, #0x7270            // =29296
    df94:      	mov	w19, #0x72              // =114
    df98:      	movk	x28, #0x636f, lsl #16
    df9c:      	movk	x28, #0x7365, lsl #32
    dfa0:      	movk	x28, #0x6f73, lsl #48
    dfa4:      	add	x0, sp, #0x128
    dfa8:      	mov	w1, #0x400              // =1024
    dfac:      	mov	x2, x24
    dfb0:      	bl	0x1d840 <fgets@plt>
    dfb4:      	cbz	x0, 0xdfd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4fc4>
    dfb8:      	ldur	x8, [x27, #0x5c]
    dfbc:      	ldrb	w9, [sp, #0x130]
    dfc0:      	mov	x0, x24
    dfc4:      	cmp	x8, x28
    dfc8:      	ccmp	w9, w19, #0x0, eq
    dfcc:      	cinc	w25, w25, eq
    dfd0:      	bl	0x1d830 <feof@plt>
    dfd4:      	cbz	w0, 0xdfa4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4f90>
    dfd8:      	mov	x0, x24
    dfdc:      	bl	0x1d850 <fclose@plt>
    dfe0:      	cmp	w25, #0x1
    dfe4:      	csinc	w28, w25, wzr, hi
    dfe8:      	b	0xdff0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4fdc>
    dfec:      	mov	w28, #0x1               // =1
    dff0:      	movi	v0.2d, #0000000000000000
    dff4:      	mov	w24, w28
    dff8:      	mov	w1, #0x18               // =24
    dffc:      	mov	x0, x24
    e000:      	stur	q0, [x27, #0x44]
    e004:      	stur	q0, [x27, #0x34]
    e008:      	stur	q0, [x27, #0x24]
    e00c:      	stur	q0, [x27, #0x14]
    e010:      	bl	0x1d860 <calloc@plt>
    e014:      	mov	x25, x0
    e018:      	cbz	x0, 0xe03c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5028>
    e01c:      	add	x8, sp, #0xe0
    e020:      	stp	wzr, w28, [x27, #0x64]
    e024:      	stur	x8, [x27, #0x5c]
    e028:      	stur	x25, [x27, #0x6c]
    e02c:      	stur	xzr, [x27, #0x74]
    e030:      	stur	xzr, [x27, #0x84]
    e034:      	stur	xzr, [x27, #0x7c]
    e038:      	b	0xe058 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5044>
    e03c:      	movi	v0.2d, #0000000000000000
    e040:      	add	x8, sp, #0xe0
    e044:      	strb	wzr, [x23]
    e048:      	stur	x8, [x27, #0x5c]
    e04c:      	stp	wzr, w28, [x27, #0x64]
    e050:      	stur	q0, [x27, #0x6c]
    e054:      	stur	q0, [x27, #0x7c]
    e058:      	nop
    e05c:      	adr	x0, 0x2e92
    e060:      	nop
    e064:      	adr	x2, 0xd430 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x441c>
    e068:      	add	x3, sp, #0x128
    e06c:      	mov	w1, #0x400              // =1024
    e070:      	bl	0xd2b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x42a0>
    e074:      	tbnz	w0, #0x0, 0xe07c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5068>
    e078:      	strb	wzr, [x23]
    e07c:      	cmp	w28, #0x2
    e080:      	b.hs	0xe08c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5078>
    e084:      	mov	x8, xzr
    e088:      	b	0xe0c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x50ac>
    e08c:      	and	x8, x24, #0xfffffffe
    e090:      	add	x9, x25, #0x2c
    e094:      	mov	x10, x8
    e098:      	ldur	w11, [x9, #-0x18]
    e09c:      	ldr	w12, [x9]
    e0a0:      	subs	x10, x10, #0x2
    e0a4:      	orr	w11, w11, #0x1000
    e0a8:      	orr	w12, w12, #0x1000
    e0ac:      	stur	w11, [x9, #-0x18]
    e0b0:      	str	w12, [x9], #0x30
    e0b4:      	b.ne	0xe098 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5084>
    e0b8:      	cmp	x8, x24
    e0bc:      	b.eq	0xe0e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x50d0>
    e0c0:      	mov	w9, #0x18               // =24
    e0c4:      	umaddl	x9, w8, w9, x25
    e0c8:      	sub	x8, x24, x8
    e0cc:      	add	x9, x9, #0x14
    e0d0:      	ldr	w10, [x9]
    e0d4:      	subs	x8, x8, #0x1
    e0d8:      	orr	w10, w10, #0x1000
    e0dc:      	str	w10, [x9], #0x18
    e0e0:      	b.ne	0xe0d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x50bc>
    e0e4:      	mov	x8, xzr
    e0e8:      	mov	w9, wzr
    e0ec:      	mov	w28, wzr
    e0f0:      	add	x10, x25, #0x14
    e0f4:      	mov	w11, #0x3f0000          // =4128768
    e0f8:      	b	0xe10c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x50f8>
    e0fc:      	add	x8, x8, #0x1
    e100:      	add	x10, x10, #0x18
    e104:      	cmp	x24, x8
    e108:      	b.eq	0xe12c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5118>
    e10c:      	ldr	w12, [x10]
    e110:      	stur	w8, [x10, #-0x4]
    e114:      	tbz	w12, #0xc, 0xe0fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x50e8>
    e118:      	bics	wzr, w11, w12
    e11c:      	add	w9, w9, #0x1
    e120:      	b.ne	0xe0fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x50e8>
    e124:      	ldur	w28, [x10, #-0x10]
    e128:      	b	0xe0fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x50e8>
    e12c:      	mov	w0, #0x10               // =16
    e130:      	bl	0x1d800 <getauxval@plt>
    e134:      	add	x19, sp, #0x128
    e138:      	mov	x24, x0
    e13c:      	adrp	x0, 0x4000
    e140:      	add	x0, x0, #0x73b
    e144:      	add	x1, x19, #0x40
    e148:      	bl	0x1d7f0 <__system_property_get@plt>
    e14c:      	adrp	x0, 0x2000
    e150:      	add	x0, x0, #0xcae
    e154:      	add	x1, x19, #0x9c
    e158:      	bl	0x1d7f0 <__system_property_get@plt>
    e15c:      	adrp	x0, 0x3000
    e160:      	add	x0, x0, #0x77c
    e164:      	add	x1, x19, #0xf8
    e168:      	bl	0x1d7f0 <__system_property_get@plt>
    e16c:      	adrp	x0, 0x2000
    e170:      	add	x0, x0, #0xfeb
    e174:      	add	x1, x19, #0x154
    e178:      	bl	0x1d7f0 <__system_property_get@plt>
    e17c:      	adrp	x0, 0x3000
    e180:      	add	x0, x0, #0x112
    e184:      	add	x1, x19, #0x1b0
    e188:      	bl	0x1d7f0 <__system_property_get@plt>
    e18c:      	adrp	x0, 0x4000
    e190:      	add	x0, x0, #0xabb
    e194:      	add	x1, x19, #0x20c
    e198:      	bl	0x1d7f0 <__system_property_get@plt>
    e19c:      	add	x8, sp, #0xcc
    e1a0:      	add	x0, sp, #0x128
    e1a4:      	bl	0xdb0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x4af8>
    e1a8:      	and	w8, w28, #0xfffffff0
    e1ac:      	mov	w9, #0x8040             // =32832
    e1b0:      	and	w8, w8, #0xff00ffff
    e1b4:      	movk	w9, #0x5100, lsl #16
    e1b8:      	cmp	w8, w9
    e1bc:      	b.eq	0xe1c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x51b0>
    e1c0:      	tbz	w24, #0x14, 0xe1cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x51b8>
    e1c4:      	mov	w8, #0x1                // =1
    e1c8:      	strb	w8, [x23]
    e1cc:      	mov	w8, #0x600              // =1536
    e1d0:      	bics	wzr, w8, w24
    e1d4:      	b.ne	0xe1f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x51dc>
    e1d8:      	ldp	w8, w9, [x27, #0x4]
    e1dc:      	cmp	w8, #0x6
    e1e0:      	mov	w8, #0x2652             // =9810
    e1e4:      	ccmp	w9, w8, #0x0, eq
    e1e8:      	cset	w8, ne
    e1ec:      	strb	w8, [x22]
    e1f0:      	adrp	x0, 0x4000
    e1f4:      	add	x0, x0, #0x88b
    e1f8:      	add	x1, sp, #0x6f
    e1fc:      	bl	0x1d7f0 <__system_property_get@plt>
    e200:      	mov	w22, w0
    e204:      	cmp	w0, #0x1
    e208:      	b.lt	0xe224 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5210>
    e20c:      	mov	w23, w22
    e210:      	add	x1, sp, #0x6f
    e214:      	mov	x0, x21
    e218:      	mov	x2, x23
    e21c:      	bl	0x1d540 <memcpy@plt>
    e220:      	strb	wzr, [x21, x23]
    e224:      	adrp	x0, 0x3000
    e228:      	add	x0, x0, #0xdc3
    e22c:      	add	x1, sp, #0x12
    e230:      	bl	0x1d7f0 <__system_property_get@plt>
    e234:      	mov	w21, w0
    e238:      	cmp	w0, #0x1
    e23c:      	b.lt	0xe258 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5244>
    e240:      	mov	w23, w21
    e244:      	add	x1, sp, #0x12
    e248:      	mov	x0, x20
    e24c:      	mov	x2, x23
    e250:      	bl	0x1d540 <memcpy@plt>
    e254:      	strb	wzr, [x20, x23]
    e258:      	adds	w8, w21, w22
    e25c:      	add	w20, w8, #0x2
    e260:      	b.le	0xe2bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x52a8>
    e264:      	mov	x0, x20
    e268:      	bl	0x1d870 <malloc@plt>
    e26c:      	adrp	x8, 0x3000
    e270:      	add	x8, x8, #0xa3
    e274:      	cmp	w22, #0x0
    e278:      	add	x9, sp, #0x6f
    e27c:      	mov	x1, #-0x1               // =-1
    e280:      	mov	x2, x20
    e284:      	csel	x4, x9, x8, gt
    e288:      	cmp	w21, #0x0
    e28c:      	add	x9, sp, #0x12
    e290:      	csel	x5, x9, x8, gt
    e294:      	mov	x23, x0
    e298:      	bl	0xe300 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x52ec>
    e29c:      	ldr	x0, [sp, #0x8]
    e2a0:      	mov	x1, x23
    e2a4:      	mov	x2, x20
    e2a8:      	bl	0x1d540 <memcpy@plt>
    e2ac:      	cbz	x23, 0xe2cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x52b8>
    e2b0:      	mov	x0, x23
    e2b4:      	bl	0x1d880 <free@plt>
    e2b8:      	b	0xe2cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x52b8>
    e2bc:      	sxtw	x2, w20
    e2c0:      	ldr	x0, [sp, #0x8]
    e2c4:      	mov	x1, xzr
    e2c8:      	bl	0x1d540 <memcpy@plt>
    e2cc:      	ldr	x8, [x26, #0x28]
    e2d0:      	ldur	x9, [x29, #-0x18]
    e2d4:      	cmp	x8, x9
    e2d8:      	b.ne	0xe2fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x52e8>
    e2dc:      	add	sp, sp, #0x540
    e2e0:      	ldp	x20, x19, [sp, #0x50]
    e2e4:      	ldp	x22, x21, [sp, #0x40]
    e2e8:      	ldp	x24, x23, [sp, #0x30]
    e2ec:      	ldp	x26, x25, [sp, #0x20]
    e2f0:      	ldp	x28, x27, [sp, #0x10]
    e2f4:      	ldp	x29, x30, [sp], #0x60
    e2f8:      	ret
    e2fc:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    e300:      	sub	sp, sp, #0x110
    e304:      	stp	x29, x30, [sp, #0xf0]
    e308:      	stp	x28, x19, [sp, #0x100]
    e30c:      	add	x29, sp, #0xf0
    e310:      	stp	x4, x5, [x29, #-0x70]
    e314:      	sub	x9, x29, #0x70
    e318:      	sub	x10, x29, #0x28
    e31c:      	stp	x6, x7, [x29, #-0x60]
    e320:      	mov	x3, x1
    e324:      	adrp	x4, 0x2000
    e328:      	add	x4, x4, #0xd7e
    e32c:      	stp	q0, q1, [sp]
    e330:      	sub	x5, x29, #0x50
    e334:      	stp	q2, q3, [sp, #0x20]
    e338:      	mov	x1, x2
    e33c:      	mov	w2, wzr
    e340:      	stp	q4, q5, [sp, #0x40]
    e344:      	stp	q6, q7, [sp, #0x60]
    e348:      	mrs	x19, TPIDR_EL0
    e34c:      	ldr	x8, [x19, #0x28]
    e350:      	stur	x8, [x29, #-0x8]
    e354:      	add	x8, x9, #0x20
    e358:      	add	x9, x29, #0x20
    e35c:      	stp	x9, x8, [x29, #-0x28]
    e360:      	mov	x8, #-0x20              // =-32
    e364:      	mov	x9, sp
    e368:      	movk	x8, #0xff80, lsl #32
    e36c:      	add	x9, x9, #0x80
    e370:      	stp	x9, x8, [x29, #-0x18]
    e374:      	ldp	q0, q1, [x10]
    e378:      	stp	q0, q1, [x29, #-0x50]
    e37c:      	bl	0x1d520 <__vsnprintf_chk@plt>
    e380:      	ldr	x8, [x19, #0x28]
    e384:      	ldur	x9, [x29, #-0x8]
    e388:      	cmp	x8, x9
    e38c:      	b.ne	0xe3a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x538c>
    e390:      	ldp	x28, x19, [sp, #0x100]
    e394:      	ldp	x29, x30, [sp, #0xf0]
    e398:      	add	sp, sp, #0x110
    e39c:      	ret
    e3a0:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    e3a4:      	ret
    e3a8:      	sub	x8, x1, x0
    e3ac:      	sub	x8, x8, #0x6
    e3b0:      	cmn	x8, #0x3
    e3b4:      	b.lo	0xe460 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x544c>
    e3b8:      	ldrb	w8, [x0]
    e3bc:      	cmp	w8, #0x30
    e3c0:      	b.ne	0xe460 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x544c>
    e3c4:      	ldrb	w8, [x0, #0x1]
    e3c8:      	cmp	w8, #0x78
    e3cc:      	b.ne	0xe460 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x544c>
    e3d0:      	add	x8, x0, #0x2
    e3d4:      	cmp	x8, x1
    e3d8:      	b.eq	0xe43c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5428>
    e3dc:      	mov	w9, wzr
    e3e0:      	b	0xe3fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x53e8>
    e3e4:      	mov	w11, #-0x30             // =-48
    e3e8:      	add	w10, w11, w10
    e3ec:      	add	x8, x8, #0x1
    e3f0:      	add	w9, w10, w9, lsl #4
    e3f4:      	cmp	x8, x1
    e3f8:      	b.eq	0xe434 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5420>
    e3fc:      	ldrb	w10, [x8]
    e400:      	sub	w11, w10, #0x30
    e404:      	cmp	w11, #0xa
    e408:      	b.lo	0xe3e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x53d0>
    e40c:      	sub	w11, w10, #0x41
    e410:      	cmp	w11, #0x6
    e414:      	b.hs	0xe420 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x540c>
    e418:      	mov	w11, #-0x37             // =-55
    e41c:      	b	0xe3e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x53d4>
    e420:      	sub	w11, w10, #0x61
    e424:      	cmp	w11, #0x5
    e428:      	b.hi	0xe460 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x544c>
    e42c:      	mov	w11, #-0x57             // =-87
    e430:      	b	0xe3e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x53d4>
    e434:      	ubfiz	w8, w9, #4, #12
    e438:      	b	0xe440 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x542c>
    e43c:      	mov	w8, wzr
    e440:      	ldr	w9, [x2, #0x4]
    e444:      	ldr	w10, [x2, #0x14]
    e448:      	mov	w11, #0x280000          // =2621440
    e44c:      	and	w9, w9, #0xffff000f
    e450:      	orr	w8, w9, w8
    e454:      	orr	w9, w10, w11
    e458:      	str	w8, [x2, #0x4]
    e45c:      	str	w9, [x2, #0x14]
    e460:      	ret
    e464:      	sub	x8, x1, x0
    e468:      	cmp	x8, #0x3
    e46c:      	b.ne	0xe4d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x54c4>
    e470:      	ldrb	w8, [x0]
    e474:      	cmp	w8, #0x30
    e478:      	b.ne	0xe4d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x54c4>
    e47c:      	ldrb	w8, [x0, #0x1]
    e480:      	cmp	w8, #0x78
    e484:      	b.ne	0xe4d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x54c4>
    e488:      	ldrb	w9, [x0, #0x2]
    e48c:      	sub	w8, w9, #0x30
    e490:      	cmp	w8, #0xa
    e494:      	b.lo	0xe4bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x54a8>
    e498:      	sub	w8, w9, #0x41
    e49c:      	cmp	w8, #0x5
    e4a0:      	b.hi	0xe4ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5498>
    e4a4:      	sub	w8, w9, #0x37
    e4a8:      	b	0xe4bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x54a8>
    e4ac:      	sub	w8, w9, #0x61
    e4b0:      	cmp	w8, #0x5
    e4b4:      	b.hi	0xe4d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x54c4>
    e4b8:      	sub	w8, w9, #0x57
    e4bc:      	ldr	w9, [x2, #0x4]
    e4c0:      	ldr	w10, [x2, #0x14]
    e4c4:      	bfi	w9, w8, #20, #4
    e4c8:      	mov	w8, #0x240000           // =2359296
    e4cc:      	orr	w8, w10, w8
    e4d0:      	str	w9, [x2, #0x4]
    e4d4:      	str	w8, [x2, #0x14]
    e4d8:      	ret
    e4dc:      	cmp	x0, x1
    e4e0:      	b.eq	0xe514 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5500>
    e4e4:      	mov	w8, wzr
    e4e8:      	mov	w9, #0xa                // =10
    e4ec:      	ldrb	w10, [x0]
    e4f0:      	sub	w10, w10, #0x30
    e4f4:      	cmp	w10, #0x9
    e4f8:      	b.hi	0xe534 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5520>
    e4fc:      	madd	w8, w8, w9, w10
    e500:      	add	x0, x0, #0x1
    e504:      	cmp	x0, x1
    e508:      	b.ne	0xe4ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x54d8>
    e50c:      	and	w8, w8, #0xf
    e510:      	b	0xe518 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5504>
    e514:      	mov	w8, wzr
    e518:      	ldr	w9, [x2, #0x4]
    e51c:      	ldr	w10, [x2, #0x14]
    e520:      	and	w9, w9, #0xfffffff0
    e524:      	orr	w8, w9, w8
    e528:      	orr	w9, w10, #0x300000
    e52c:      	str	w8, [x2, #0x4]
    e530:      	str	w9, [x2, #0x14]
    e534:      	ret
    e538:      	sub	x8, x1, x0
    e53c:      	sub	x8, x8, #0x3
    e540:      	cmp	x8, #0x1
    e544:      	b.hi	0xe5f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x55dc>
    e548:      	ldrb	w8, [x0]
    e54c:      	cmp	w8, #0x30
    e550:      	b.ne	0xe5f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x55dc>
    e554:      	ldrb	w8, [x0, #0x1]
    e558:      	cmp	w8, #0x78
    e55c:      	b.ne	0xe5f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x55dc>
    e560:      	add	x8, x0, #0x2
    e564:      	cmp	x8, x1
    e568:      	b.eq	0xe5cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x55b8>
    e56c:      	mov	w9, wzr
    e570:      	b	0xe58c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5578>
    e574:      	mov	w11, #-0x30             // =-48
    e578:      	add	w10, w11, w10
    e57c:      	add	x8, x8, #0x1
    e580:      	add	w9, w10, w9, lsl #4
    e584:      	cmp	x8, x1
    e588:      	b.eq	0xe5c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x55b0>
    e58c:      	ldrb	w10, [x8]
    e590:      	sub	w11, w10, #0x30
    e594:      	cmp	w11, #0xa
    e598:      	b.lo	0xe574 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5560>
    e59c:      	sub	w11, w10, #0x41
    e5a0:      	cmp	w11, #0x6
    e5a4:      	b.hs	0xe5b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x559c>
    e5a8:      	mov	w11, #-0x37             // =-55
    e5ac:      	b	0xe578 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5564>
    e5b0:      	sub	w11, w10, #0x61
    e5b4:      	cmp	w11, #0x5
    e5b8:      	b.hi	0xe5f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x55dc>
    e5bc:      	mov	w11, #-0x57             // =-87
    e5c0:      	b	0xe578 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5564>
    e5c4:      	lsl	w8, w9, #24
    e5c8:      	b	0xe5d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x55bc>
    e5cc:      	mov	w8, wzr
    e5d0:      	ldr	w9, [x2, #0x4]
    e5d4:      	ldr	w10, [x2, #0x14]
    e5d8:      	mov	w11, #0x220000          // =2228224
    e5dc:      	and	w9, w9, #0xffffff
    e5e0:      	orr	w8, w9, w8
    e5e4:      	orr	w9, w10, w11
    e5e8:      	str	w8, [x2, #0x4]
    e5ec:      	str	w9, [x2, #0x14]
    e5f0:      	ret
    e5f4:      	sub	x9, x1, x0
    e5f8:      	cmp	x9, #0x7
    e5fc:      	b.ne	0xe624 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5610>
    e600:      	ldr	w8, [x0]
    e604:      	mov	w11, #0x4141            // =16705
    e608:      	ldur	w10, [x0, #0x3]
    e60c:      	movk	w11, #0x6372, lsl #16
    e610:      	cmp	w8, w11
    e614:      	mov	w8, #0x6863             // =26723
    e618:      	movk	w8, #0x3436, lsl #16
    e61c:      	ccmp	w10, w8, #0x0, eq
    e620:      	b.eq	0xe698 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5684>
    e624:      	cmp	x0, x1
    e628:      	b.eq	0xe680 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x566c>
    e62c:      	mov	w8, wzr
    e630:      	add	x10, x0, x9
    e634:      	mov	w11, #0xa               // =10
    e638:      	mov	x9, x0
    e63c:      	ldrb	w12, [x9]
    e640:      	sub	w12, w12, #0x30
    e644:      	cmp	w12, #0x9
    e648:      	b.hi	0xe660 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x564c>
    e64c:      	madd	w8, w8, w11, w12
    e650:      	add	x9, x9, #0x1
    e654:      	cmp	x9, x1
    e658:      	b.ne	0xe63c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5628>
    e65c:      	mov	x9, x10
    e660:      	cmp	x9, x0
    e664:      	b.eq	0xe680 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x566c>
    e668:      	cbz	w8, 0xe680 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x566c>
    e66c:      	ldr	w9, [x2, #0x14]
    e670:      	mov	w10, #0x210000          // =2162688
    e674:      	str	w8, [x2]
    e678:      	orr	w8, w9, w10
    e67c:      	str	w8, [x2, #0x14]
    e680:      	add	x8, x2, #0x4
    e684:      	mov	w9, #0xf0000            // =983040
    e688:      	ldr	w10, [x8]
    e68c:      	orr	w9, w10, w9
    e690:      	str	w9, [x8]
    e694:      	ret
    e698:      	ldr	w8, [x2, #0x4]
    e69c:      	mov	w9, #0x8                // =8
    e6a0:      	orr	w8, w8, #0xf0000
    e6a4:      	stp	w9, w8, [x2]
    e6a8:      	add	x8, x2, #0x14
    e6ac:      	mov	w9, #0x210000           // =2162688
    e6b0:      	ldr	w10, [x8]
    e6b4:      	orr	w9, w10, w9
    e6b8:      	str	w9, [x8]
    e6bc:      	ret
    e6c0:      	sub	sp, sp, #0x50
    e6c4:      	stp	x29, x30, [sp, #0x30]
    e6c8:      	str	x19, [sp, #0x40]
    e6cc:      	add	x29, sp, #0x30
    e6d0:      	mrs	x19, TPIDR_EL0
    e6d4:      	mov	x2, x0
    e6d8:      	mov	x3, sp
    e6dc:      	ldr	x8, [x19, #0x28]
    e6e0:      	mov	w0, #0x6                // =6
    e6e4:      	stur	x8, [x29, #-0x8]
    e6e8:      	ldp	q0, q1, [x1]
    e6ec:      	nop
    e6f0:      	adr	x1, 0x4f88
    e6f4:      	stp	q0, q1, [sp]
    e6f8:      	bl	0x1d890 <__android_log_vprint@plt>
    e6fc:      	ldr	x8, [x19, #0x28]
    e700:      	ldur	x9, [x29, #-0x8]
    e704:      	cmp	x8, x9
    e708:      	b.ne	0xe71c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5708>
    e70c:      	ldp	x29, x30, [sp, #0x30]
    e710:      	ldr	x19, [sp, #0x40]
    e714:      	add	sp, sp, #0x50
    e718:      	ret
    e71c:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    e720:      	sub	sp, sp, #0x50
    e724:      	stp	x29, x30, [sp, #0x30]
    e728:      	str	x19, [sp, #0x40]
    e72c:      	add	x29, sp, #0x30
    e730:      	mrs	x19, TPIDR_EL0
    e734:      	mov	x2, x0
    e738:      	mov	x3, sp
    e73c:      	ldr	x8, [x19, #0x28]
    e740:      	mov	w0, #0x7                // =7
    e744:      	stur	x8, [x29, #-0x8]
    e748:      	ldp	q0, q1, [x1]
    e74c:      	nop
    e750:      	adr	x1, 0x4f88
    e754:      	stp	q0, q1, [sp]
    e758:      	bl	0x1d890 <__android_log_vprint@plt>
    e75c:      	ldr	x8, [x19, #0x28]
    e760:      	ldur	x9, [x29, #-0x8]
    e764:      	cmp	x8, x9
    e768:      	b.ne	0xe77c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5768>
    e76c:      	ldp	x29, x30, [sp, #0x30]
    e770:      	ldr	x19, [sp, #0x40]
    e774:      	add	sp, sp, #0x50
    e778:      	ret
    e77c:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    e780:      	stp	x29, x30, [sp, #-0x60]!
    e784:      	stp	x28, x27, [sp, #0x10]
    e788:      	stp	x26, x25, [sp, #0x20]
    e78c:      	stp	x24, x23, [sp, #0x30]
    e790:      	stp	x22, x21, [sp, #0x40]
    e794:      	stp	x20, x19, [sp, #0x50]
    e798:      	mov	x29, sp
    e79c:      	sub	sp, sp, #0x10
    e7a0:      	mrs	x26, TPIDR_EL0
    e7a4:      	add	x9, x1, #0xf
    e7a8:      	mov	x20, x3
    e7ac:      	ldr	x8, [x26, #0x28]
    e7b0:      	and	x9, x9, #0xfffffffffffffff0
    e7b4:      	mov	x19, x2
    e7b8:      	mov	x23, x1
    e7bc:      	stur	x8, [x29, #-0x8]
    e7c0:      	mov	x8, sp
    e7c4:      	sub	x22, x8, x9
    e7c8:      	mov	sp, x22
    e7cc:      	mov	w1, wzr
    e7d0:      	bl	0x1d7c0 <__open_2@plt>
    e7d4:      	cmn	w0, #0x1
    e7d8:      	b.eq	0xe89c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5888>
    e7dc:      	mov	w21, w0
    e7e0:      	add	x27, x22, x23
    e7e4:      	mov	w23, #0x1               // =1
    e7e8:      	mov	x25, x22
    e7ec:      	b	0xe808 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x57f4>
    e7f0:      	mov	x24, x28
    e7f4:      	sub	x24, x24, x1
    e7f8:      	mov	x0, x22
    e7fc:      	mov	x2, x24
    e800:      	bl	0x1d740 <memmove@plt>
    e804:      	add	x25, x22, x24
    e808:      	sub	x2, x27, x25
    e80c:      	mov	w0, w21
    e810:      	mov	x1, x25
    e814:      	mov	x3, #-0x1               // =-1
    e818:      	bl	0x1d7d0 <__read_chk@plt>
    e81c:      	tbnz	x0, #0x3f, 0xe894 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5880>
    e820:      	add	x24, x25, x0
    e824:      	cbz	x0, 0xe8a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5890>
    e828:      	cmp	x22, x24
    e82c:      	b.eq	0xe888 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5874>
    e830:      	add	x28, x0, x25
    e834:      	mov	x1, x22
    e838:      	mov	x25, x1
    e83c:      	ldrb	w8, [x25]
    e840:      	cmp	w8, #0xa
    e844:      	b.eq	0xe858 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5844>
    e848:      	add	x25, x25, #0x1
    e84c:      	cmp	x25, x24
    e850:      	b.ne	0xe83c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5828>
    e854:      	b	0xe7f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x57dc>
    e858:      	mov	x0, x1
    e85c:      	mov	x1, x25
    e860:      	mov	x2, x20
    e864:      	mov	x3, x23
    e868:      	blr	x19
    e86c:      	tbz	w0, #0x0, 0xe894 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5880>
    e870:      	add	x1, x25, #0x1
    e874:      	add	x23, x23, #0x1
    e878:      	cmp	x1, x24
    e87c:      	b.ne	0xe838 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5824>
    e880:      	mov	x1, x24
    e884:      	b	0xe7f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x57e0>
    e888:      	mov	x1, x22
    e88c:      	mov	x24, x22
    e890:      	b	0xe7f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x57e0>
    e894:      	mov	w19, wzr
    e898:      	b	0xe8bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x58a8>
    e89c:      	mov	w19, wzr
    e8a0:      	b	0xe8c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x58b0>
    e8a4:      	mov	x0, x22
    e8a8:      	mov	x1, x24
    e8ac:      	mov	x2, x20
    e8b0:      	mov	x3, x23
    e8b4:      	blr	x19
    e8b8:      	mov	w19, w0
    e8bc:      	mov	w0, w21
    e8c0:      	bl	0x1d7e0 <close@plt>
    e8c4:      	ldr	x8, [x26, #0x28]
    e8c8:      	ldur	x9, [x29, #-0x8]
    e8cc:      	cmp	x8, x9
    e8d0:      	b.ne	0xe8f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x58e4>
    e8d4:      	and	w0, w19, #0x1
    e8d8:      	mov	sp, x29
    e8dc:      	ldp	x20, x19, [sp, #0x50]
    e8e0:      	ldp	x22, x21, [sp, #0x40]
    e8e4:      	ldp	x24, x23, [sp, #0x30]
    e8e8:      	ldp	x26, x25, [sp, #0x20]
    e8ec:      	ldp	x28, x27, [sp, #0x10]
    e8f0:      	ldp	x29, x30, [sp], #0x60
    e8f4:      	ret
    e8f8:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    e8fc:      	cmp	x0, x1
    e900:      	b.eq	0xea38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5a24>
    e904:      	mov	x10, xzr
    e908:      	ldrb	w8, [x0, x10]
    e90c:      	cmp	w8, #0x3a
    e910:      	b.eq	0xe928 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5914>
    e914:      	add	x10, x10, #0x1
    e918:      	add	x8, x0, x10
    e91c:      	cmp	x8, x1
    e920:      	b.ne	0xe908 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x58f4>
    e924:      	b	0xea38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5a24>
    e928:      	cbz	x10, 0xea38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5a24>
    e92c:      	add	x8, x0, x10
    e930:      	add	x8, x8, #0x1
    e934:      	b	0xe940 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x592c>
    e938:      	subs	x10, x10, #0x1
    e93c:      	b.eq	0xea38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5a24>
    e940:      	add	x9, x0, x10
    e944:      	ldurb	w9, [x9, #-0x1]
    e948:      	cmp	w9, #0x9
    e94c:      	b.eq	0xe938 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5924>
    e950:      	cmp	w9, #0x20
    e954:      	b.eq	0xe938 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5924>
    e958:      	b	0xe968 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5954>
    e95c:      	ldrb	w9, [x8], #0x1
    e960:      	cmp	w9, #0x20
    e964:      	b.ne	0xe974 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5960>
    e968:      	cmp	x8, x1
    e96c:      	b.ne	0xe95c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5948>
    e970:      	b	0xea38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5a24>
    e974:      	sub	x8, x8, #0x1
    e978:      	mov	x11, x1
    e97c:      	cmp	x8, x1
    e980:      	b.eq	0xe99c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5988>
    e984:      	mov	x1, x11
    e988:      	ldrb	w9, [x1, #-0x1]!
    e98c:      	cmp	w9, #0x20
    e990:      	b.eq	0xe978 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5964>
    e994:      	add	x9, x1, #0x1
    e998:      	b	0xe9a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x598c>
    e99c:      	mov	x9, x8
    e9a0:      	cmp	x10, #0xc
    e9a4:      	b.eq	0xea0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x59f8>
    e9a8:      	cmp	x10, #0x8
    e9ac:      	b.ne	0xea38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5a24>
    e9b0:      	mov	x12, #0x654d            // =25933
    e9b4:      	ldr	x10, [x0]
    e9b8:      	movk	x12, #0x546d, lsl #16
    e9bc:      	movk	x12, #0x746f, lsl #32
    e9c0:      	movk	x12, #0x6c61, lsl #48
    e9c4:      	cmp	x10, x12
    e9c8:      	b.ne	0xea38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5a24>
    e9cc:      	cmp	x8, x11
    e9d0:      	b.eq	0xea80 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5a6c>
    e9d4:      	mov	x10, xzr
    e9d8:      	mov	w11, #0xa               // =10
    e9dc:      	ldrb	w12, [x8]
    e9e0:      	sub	x12, x12, #0x30
    e9e4:      	cmp	x12, #0xa
    e9e8:      	b.hi	0xe9fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x59e8>
    e9ec:      	madd	x10, x10, x11, x12
    e9f0:      	add	x8, x8, #0x1
    e9f4:      	cmp	x8, x9
    e9f8:      	b.ne	0xe9dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x59c8>
    e9fc:      	lsr	x8, x10, #10
    ea00:      	mov	w0, #0x1                // =1
    ea04:      	str	x8, [x2]
    ea08:      	ret
    ea0c:      	mov	x13, #0x654d            // =25933
    ea10:      	ldr	x10, [x0]
    ea14:      	ldr	w12, [x0, #0x8]
    ea18:      	movk	x13, #0x416d, lsl #16
    ea1c:      	movk	x13, #0x6176, lsl #32
    ea20:      	movk	x13, #0x6c69, lsl #48
    ea24:      	cmp	x10, x13
    ea28:      	mov	w10, #0x6261            // =25185
    ea2c:      	movk	w10, #0x656c, lsl #16
    ea30:      	ccmp	w12, w10, #0x0, eq
    ea34:      	b.eq	0xea40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5a2c>
    ea38:      	mov	w0, #0x1                // =1
    ea3c:      	ret
    ea40:      	cmp	x8, x11
    ea44:      	b.eq	0xea8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5a78>
    ea48:      	mov	x10, xzr
    ea4c:      	mov	w11, #0xa               // =10
    ea50:      	ldrb	w12, [x8]
    ea54:      	sub	x12, x12, #0x30
    ea58:      	cmp	x12, #0xa
    ea5c:      	b.hi	0xea70 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5a5c>
    ea60:      	madd	x10, x10, x11, x12
    ea64:      	add	x8, x8, #0x1
    ea68:      	cmp	x8, x9
    ea6c:      	b.ne	0xea50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5a3c>
    ea70:      	lsr	x8, x10, #10
    ea74:      	mov	w0, #0x1                // =1
    ea78:      	str	x8, [x2, #0x8]
    ea7c:      	ret
    ea80:      	mov	w0, #0x1                // =1
    ea84:      	str	xzr, [x2]
    ea88:      	ret
    ea8c:      	mov	w0, #0x1                // =1
    ea90:      	str	xzr, [x2, #0x8]
    ea94:      	ret
    ea98:      	sub	sp, sp, #0x50
    ea9c:      	stp	x29, x30, [sp, #0x20]
    eaa0:      	str	x21, [sp, #0x30]
    eaa4:      	stp	x20, x19, [sp, #0x40]
    eaa8:      	add	x29, sp, #0x20
    eaac:      	mrs	x21, TPIDR_EL0
    eab0:      	mov	x19, x0
    eab4:      	mov	w0, #0x10               // =16
    eab8:      	ldr	x8, [x21, #0x28]
    eabc:      	stur	x8, [x29, #-0x8]
    eac0:      	bl	0x1d530 <_Znwm@plt>
    eac4:      	mov	x20, x0
    eac8:      	nop
    eacc:      	adr	x0, 0x3b21
    ead0:      	nop
    ead4:      	adr	x2, 0xe8fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x58e8>
    ead8:      	mov	x3, sp
    eadc:      	mov	w1, #0x400              // =1024
    eae0:      	stp	xzr, xzr, [sp]
    eae4:      	bl	0xe780 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x576c>
    eae8:      	ldr	q0, [sp]
    eaec:      	str	x20, [x19]
    eaf0:      	str	q0, [x20]
    eaf4:      	ldr	x8, [x21, #0x28]
    eaf8:      	ldur	x9, [x29, #-0x8]
    eafc:      	cmp	x8, x9
    eb00:      	b.ne	0xeb18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5b04>
    eb04:      	ldp	x20, x19, [sp, #0x40]
    eb08:      	ldr	x21, [sp, #0x30]
    eb0c:      	ldp	x29, x30, [sp, #0x20]
    eb10:      	add	sp, sp, #0x50
    eb14:      	ret
    eb18:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    eb1c:      	ldr	x0, [x0]
    eb20:      	cbz	x0, 0xeb28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5b14>
    eb24:      	b	0x1d550 <_ZdlPv@plt>
    eb28:      	ret
    eb2c:      	ldr	x8, [x0]
    eb30:      	ldr	x0, [x8, #0x8]
    eb34:      	ret
    eb38:      	ldr	x8, [x0]
    eb3c:      	ldr	x0, [x8]
    eb40:      	ret
    eb44:      	sub	sp, sp, #0x160
    eb48:      	stp	x29, x30, [sp, #0x110]
    eb4c:      	str	x28, [sp, #0x120]
    eb50:      	stp	x24, x23, [sp, #0x130]
    eb54:      	stp	x22, x21, [sp, #0x140]
    eb58:      	stp	x20, x19, [sp, #0x150]
    eb5c:      	add	x29, sp, #0x110
    eb60:      	mrs	x24, TPIDR_EL0
    eb64:      	mov	x20, x0
    eb68:      	mov	x19, x1
    eb6c:      	ldr	x8, [x24, #0x28]
    eb70:      	nop
    eb74:      	adr	x3, 0x4292
    eb78:      	add	x0, sp, #0x8
    eb7c:      	mov	w1, #0x100              // =256
    eb80:      	mov	w2, #0x100              // =256
    eb84:      	mov	x4, x20
    eb88:      	stur	x8, [x29, #-0x8]
    eb8c:      	bl	0xec5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5c48>
    eb90:      	adrp	x21, 0x22000
    eb94:      	add	x1, sp, #0x8
    eb98:      	ldr	x21, [x21, #0x100]
    eb9c:      	mov	x0, x21
    eba0:      	bl	0x1d4f0 <strstr@plt>
    eba4:      	cbnz	x0, 0xec2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5c18>
    eba8:      	mov	x0, x21
    ebac:      	mov	w1, #0x100              // =256
    ebb0:      	bl	0x1d500 <__strlen_chk@plt>
    ebb4:      	mov	x22, x0
    ebb8:      	mov	x0, x20
    ebbc:      	bl	0x1d510 <strlen@plt>
    ebc0:      	mov	x23, x0
    ebc4:      	mov	x0, x19
    ebc8:      	bl	0x1d510 <strlen@plt>
    ebcc:      	add	x8, x0, x23
    ebd0:      	add	x9, x22, x8
    ebd4:      	add	x9, x9, #0x2
    ebd8:      	cmp	x9, #0x100
    ebdc:      	b.lo	0xec0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5bf8>
    ebe0:      	mov	w8, #0x100              // =256
    ebe4:      	adrp	x3, 0x3000
    ebe8:      	add	x3, x3, #0xa31
    ebec:      	sub	x2, x8, x22
    ebf0:      	add	x0, x21, x22
    ebf4:      	mov	x1, #-0x1               // =-1
    ebf8:      	mov	x4, x20
    ebfc:      	mov	x5, x19
    ec00:      	bl	0xec5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5c48>
    ec04:      	strb	wzr, [x21, #0xff]
    ec08:      	b	0xec2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5c18>
    ec0c:      	adrp	x3, 0x3000
    ec10:      	add	x3, x3, #0xa31
    ec14:      	add	x0, x21, x22
    ec18:      	add	x2, x8, #0x3
    ec1c:      	mov	x1, #-0x1               // =-1
    ec20:      	mov	x4, x20
    ec24:      	mov	x5, x19
    ec28:      	bl	0xec5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5c48>
    ec2c:      	ldr	x8, [x24, #0x28]
    ec30:      	ldur	x9, [x29, #-0x8]
    ec34:      	cmp	x8, x9
    ec38:      	b.ne	0xec58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5c44>
    ec3c:      	ldp	x20, x19, [sp, #0x150]
    ec40:      	ldr	x28, [sp, #0x120]
    ec44:      	ldp	x22, x21, [sp, #0x140]
    ec48:      	ldp	x24, x23, [sp, #0x130]
    ec4c:      	ldp	x29, x30, [sp, #0x110]
    ec50:      	add	sp, sp, #0x160
    ec54:      	ret
    ec58:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    ec5c:      	sub	sp, sp, #0x110
    ec60:      	stp	x29, x30, [sp, #0xf0]
    ec64:      	stp	x28, x19, [sp, #0x100]
    ec68:      	add	x29, sp, #0xf0
    ec6c:      	stp	x4, x5, [x29, #-0x70]
    ec70:      	sub	x10, x29, #0x70
    ec74:      	mov	x11, sp
    ec78:      	stp	x6, x7, [x29, #-0x60]
    ec7c:      	add	x11, x11, #0x80
    ec80:      	mov	x8, x3
    ec84:      	stp	q0, q1, [sp]
    ec88:      	mov	x3, x1
    ec8c:      	sub	x5, x29, #0x50
    ec90:      	stp	q2, q3, [sp, #0x20]
    ec94:      	mov	x1, x2
    ec98:      	mov	w2, wzr
    ec9c:      	stp	q4, q5, [sp, #0x40]
    eca0:      	mov	x4, x8
    eca4:      	stp	q6, q7, [sp, #0x60]
    eca8:      	mrs	x19, TPIDR_EL0
    ecac:      	ldr	x9, [x19, #0x28]
    ecb0:      	stur	x9, [x29, #-0x8]
    ecb4:      	add	x9, x10, #0x20
    ecb8:      	add	x10, x29, #0x20
    ecbc:      	stp	x10, x9, [x29, #-0x28]
    ecc0:      	mov	x9, #-0x20              // =-32
    ecc4:      	sub	x10, x29, #0x28
    ecc8:      	movk	x9, #0xff80, lsl #32
    eccc:      	stp	x11, x9, [x29, #-0x18]
    ecd0:      	ldp	q0, q1, [x10]
    ecd4:      	stp	q0, q1, [x29, #-0x50]
    ecd8:      	bl	0x1d520 <__vsnprintf_chk@plt>
    ecdc:      	ldr	x8, [x19, #0x28]
    ece0:      	ldur	x9, [x29, #-0x8]
    ece4:      	cmp	x8, x9
    ece8:      	b.ne	0xecfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5ce8>
    ecec:      	ldp	x28, x19, [sp, #0x100]
    ecf0:      	ldp	x29, x30, [sp, #0xf0]
    ecf4:      	add	sp, sp, #0x110
    ecf8:      	ret
    ecfc:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    ed00:      	stp	x29, x30, [sp, #-0x60]!
    ed04:      	stp	x28, x27, [sp, #0x10]
    ed08:      	stp	x26, x25, [sp, #0x20]
    ed0c:      	stp	x24, x23, [sp, #0x30]
    ed10:      	stp	x22, x21, [sp, #0x40]
    ed14:      	stp	x20, x19, [sp, #0x50]
    ed18:      	mov	x29, sp
    ed1c:      	sub	sp, sp, #0x550
    ed20:      	mrs	x26, TPIDR_EL0
    ed24:      	ldr	x8, [x26, #0x28]
    ed28:      	stur	x8, [x29, #-0x10]
    ed2c:      	bl	0x186b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf6a4>
    ed30:      	mov	w19, w0
    ed34:      	bl	0x18d0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfcf8>
    ed38:      	mov	w20, w0
    ed3c:      	mov	w0, w19
    ed40:      	bl	0x18e50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfe3c>
    ed44:      	add	w23, w0, #0x1
    ed48:      	cmp	w19, w23
    ed4c:      	csinc	w8, w19, w0, lo
    ed50:      	cmp	w23, #0x0
    ed54:      	cset	w9, ne
    ed58:      	csel	w8, w8, w19, ne
    ed5c:      	adds	w10, w20, #0x1
    ed60:      	orr	w11, w9, #0x2
    ed64:      	csel	w22, w9, w11, hs
    ed68:      	cmp	w8, w10
    ed6c:      	csel	w21, w8, w10, lo
    ed70:      	adds	w24, w20, #0x1
    ed74:      	orr	w9, w23, w24
    ed78:      	csel	w20, w8, w21, hs
    ed7c:      	cbz	w9, 0xeeb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5ea4>
    ed80:      	mov	x0, x20
    ed84:      	mov	w1, #0x38               // =56
    ed88:      	bl	0x1d860 <calloc@plt>
    ed8c:      	cbz	x0, 0xeef0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5edc>
    ed90:      	mov	x19, x0
    ed94:      	cbz	w24, 0xedac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5d98>
    ed98:      	add	x1, x19, #0x34
    ed9c:      	mov	w0, w21
    eda0:      	mov	w2, #0x38               // =56
    eda4:      	mov	w3, #0x2                // =2
    eda8:      	bl	0x18ee0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfecc>
    edac:      	cbz	w23, 0xedc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5db0>
    edb0:      	add	x1, x19, #0x34
    edb4:      	mov	w0, w20
    edb8:      	mov	w2, #0x38               // =56
    edbc:      	mov	w3, #0x1                // =1
    edc0:      	bl	0x18f8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xff78>
    edc4:      	add	x0, sp, #0x220
    edc8:      	add	x23, sp, #0x220
    edcc:      	bl	0x1848c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf478>
    edd0:      	adrp	x21, 0x4000
    edd4:      	add	x21, x21, #0x185
    edd8:      	add	x0, sp, #0x180
    eddc:      	mov	w1, #0x20               // =32
    ede0:      	mov	w2, #0x20               // =32
    ede4:      	mov	x3, x21
    ede8:      	mov	w4, wzr
    edec:      	bl	0xec5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5c48>
    edf0:      	add	x0, sp, #0x180
    edf4:      	add	x1, x23, #0x40
    edf8:      	bl	0xeb44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5b30>
    edfc:      	add	x0, sp, #0x180
    ee00:      	mov	w1, #0x20               // =32
    ee04:      	mov	w2, #0x20               // =32
    ee08:      	mov	x3, x21
    ee0c:      	mov	w4, #0x1                // =1
    ee10:      	bl	0xec5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5c48>
    ee14:      	add	x0, sp, #0x180
    ee18:      	add	x1, x23, #0x9c
    ee1c:      	bl	0xeb44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5b30>
    ee20:      	add	x0, sp, #0x180
    ee24:      	mov	w1, #0x20               // =32
    ee28:      	mov	w2, #0x20               // =32
    ee2c:      	mov	x3, x21
    ee30:      	mov	w4, #0x2                // =2
    ee34:      	bl	0xec5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5c48>
    ee38:      	add	x0, sp, #0x180
    ee3c:      	add	x1, x23, #0x268
    ee40:      	bl	0xeb44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5b30>
    ee44:      	add	x0, sp, #0x180
    ee48:      	mov	w1, #0x20               // =32
    ee4c:      	mov	w2, #0x20               // =32
    ee50:      	mov	x3, x21
    ee54:      	mov	w4, #0x3                // =3
    ee58:      	bl	0xec5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5c48>
    ee5c:      	add	x0, sp, #0x180
    ee60:      	add	x1, x23, #0x2c4
    ee64:      	bl	0xeb44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5b30>
    ee68:      	add	x0, sp, #0x220
    ee6c:      	add	x1, sp, #0x217
    ee70:      	mov	w2, w20
    ee74:      	mov	x3, x19
    ee78:      	bl	0x11e50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8e3c>
    ee7c:      	tbz	w0, #0x0, 0xef34 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5f20>
    ee80:      	cbz	w20, 0xefc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5fb4>
    ee84:      	mov	x21, xzr
    ee88:      	add	x23, x19, #0xc
    ee8c:      	b	0xeea0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5e8c>
    ee90:      	add	x21, x21, #0x1
    ee94:      	add	x23, x23, #0x38
    ee98:      	cmp	x20, x21
    ee9c:      	b.eq	0xef44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5f30>
    eea0:      	ldr	w8, [x23]
    eea4:      	cbnz	w8, 0xee90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5e7c>
    eea8:      	mov	w0, w21
    eeac:      	bl	0x18b88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfb74>
    eeb0:      	str	w0, [x23]
    eeb4:      	b	0xee90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5e7c>
    eeb8:      	ldr	x8, [x26, #0x28]
    eebc:      	ldur	x9, [x29, #-0x10]
    eec0:      	cmp	x8, x9
    eec4:      	b.ne	0xfdf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de4>
    eec8:      	adrp	x0, 0x2000
    eecc:      	add	x0, x0, #0xff3
    eed0:      	add	sp, sp, #0x550
    eed4:      	ldp	x20, x19, [sp, #0x50]
    eed8:      	ldp	x22, x21, [sp, #0x40]
    eedc:      	ldp	x24, x23, [sp, #0x30]
    eee0:      	ldp	x26, x25, [sp, #0x20]
    eee4:      	ldp	x28, x27, [sp, #0x10]
    eee8:      	ldp	x29, x30, [sp], #0x60
    eeec:      	b	0xfdfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de8>
    eef0:      	ldr	x8, [x26, #0x28]
    eef4:      	ldur	x9, [x29, #-0x10]
    eef8:      	cmp	x8, x9
    eefc:      	b.ne	0xfdf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de4>
    ef00:      	lsl	x8, x20, #6
    ef04:      	adrp	x0, 0x3000
    ef08:      	add	x0, x0, #0x11e
    ef0c:      	mov	w2, w20
    ef10:      	sub	x1, x8, x20, lsl #3
    ef14:      	add	sp, sp, #0x550
    ef18:      	ldp	x20, x19, [sp, #0x50]
    ef1c:      	ldp	x22, x21, [sp, #0x40]
    ef20:      	ldp	x24, x23, [sp, #0x30]
    ef24:      	ldp	x26, x25, [sp, #0x20]
    ef28:      	ldp	x28, x27, [sp, #0x10]
    ef2c:      	ldp	x29, x30, [sp], #0x60
    ef30:      	b	0xfdfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de8>
    ef34:      	adrp	x0, 0x3000
    ef38:      	add	x0, x0, #0x55a
    ef3c:      	bl	0xfdfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de8>
    ef40:      	b	0xfdc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6db4>
    ef44:      	cbz	w20, 0xefc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5fb4>
    ef48:      	add	x8, x19, #0x34
    ef4c:      	mov	x9, x20
    ef50:      	b	0xef60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5f4c>
    ef54:      	subs	x9, x9, #0x1
    ef58:      	add	x8, x8, #0x38
    ef5c:      	b.eq	0xef78 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5f64>
    ef60:      	ldr	w10, [x8]
    ef64:      	bics	wzr, w22, w10
    ef68:      	b.ne	0xef54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5f40>
    ef6c:      	orr	w10, w10, #0x1000
    ef70:      	str	w10, [x8]
    ef74:      	b	0xef54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5f40>
    ef78:      	cbz	w20, 0xefc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5fb4>
    ef7c:      	mov	x8, xzr
    ef80:      	mov	w21, wzr
    ef84:      	mov	w22, wzr
    ef88:      	add	x9, x19, #0x34
    ef8c:      	mov	w10, #0x3f0000          // =4128768
    ef90:      	b	0xefa4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5f90>
    ef94:      	add	x8, x8, #0x1
    ef98:      	add	x9, x9, #0x38
    ef9c:      	cmp	x20, x8
    efa0:      	b.eq	0xefd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5fbc>
    efa4:      	ldr	w11, [x9]
    efa8:      	stur	w8, [x9, #-0x4]
    efac:      	tbz	w11, #0xc, 0xef94 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5f80>
    efb0:      	ubfx	w12, w11, #21, #1
    efb4:      	bics	wzr, w10, w11
    efb8:      	add	w21, w12, w21
    efbc:      	b.ne	0xef94 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5f80>
    efc0:      	ldur	w22, [x9, #-0x28]
    efc4:      	b	0xef94 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5f80>
    efc8:      	mov	w22, wzr
    efcc:      	mov	w21, wzr
    efd0:      	add	x8, sp, #0x200
    efd4:      	add	x0, sp, #0x220
    efd8:      	mov	w1, w21
    efdc:      	mov	w2, wzr
    efe0:      	bl	0x16980 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd96c>
    efe4:      	add	x0, sp, #0xfc
    efe8:      	add	x1, sp, #0xf8
    efec:      	str	xzr, [sp, #0xf8]
    eff0:      	bl	0x180cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf0b8>
    eff4:      	ldp	w1, w0, [sp, #0xf8]
    eff8:      	nop
    effc:      	adr	x4, 0x2692c
    f000:      	add	x3, sp, #0x200
    f004:      	mov	w2, w22
    f008:      	bl	0x18104 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf0f0>
    f00c:      	cbz	w20, 0xf190 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x617c>
    f010:      	mov	x22, xzr
    f014:      	add	x23, x19, #0x1c
    f018:      	b	0xf02c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6018>
    f01c:      	add	x22, x22, #0x1
    f020:      	add	x23, x23, #0x38
    f024:      	cmp	x20, x22
    f028:      	b.eq	0xf08c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6078>
    f02c:      	ldrb	w8, [x23, #0x19]
    f030:      	tbz	w8, #0x4, 0xf01c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6008>
    f034:      	mov	w0, w22
    f038:      	bl	0x18870 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf85c>
    f03c:      	cbz	w0, 0xf050 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x603c>
    f040:      	ldr	w8, [x23, #0x18]
    f044:      	str	w0, [x23, #0xc]
    f048:      	orr	w8, w8, #0x4
    f04c:      	str	w8, [x23, #0x18]
    f050:      	mov	w0, w22
    f054:      	bl	0x18900 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf8ec>
    f058:      	cbz	w0, 0xf06c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6058>
    f05c:      	ldr	w8, [x23, #0x18]
    f060:      	str	w0, [x23, #0x10]
    f064:      	orr	w8, w8, #0x8
    f068:      	str	w8, [x23, #0x18]
    f06c:      	mov	w0, w22
    f070:      	mov	x1, x23
    f074:      	bl	0x18c74 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfc60>
    f078:      	tbz	w0, #0x0, 0xf01c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6008>
    f07c:      	ldr	w8, [x23, #0x18]
    f080:      	orr	w8, w8, #0x40
    f084:      	str	w8, [x23, #0x18]
    f088:      	b	0xf01c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6008>
    f08c:      	cbz	w20, 0xf190 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x617c>
    f090:      	cmp	w20, #0x1
    f094:      	b.ne	0xf0a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x608c>
    f098:      	mov	x8, xzr
    f09c:      	b	0xf0cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x60b8>
    f0a0:      	mov	x9, xzr
    f0a4:      	and	x8, x20, #0xfffffffe
    f0a8:      	add	x10, x19, #0x58
    f0ac:      	add	w11, w9, #0x1
    f0b0:      	stur	w9, [x10, #-0x38]
    f0b4:      	add	x9, x9, #0x2
    f0b8:      	cmp	x8, x9
    f0bc:      	str	w11, [x10], #0x70
    f0c0:      	b.ne	0xf0ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6098>
    f0c4:      	cmp	x8, x20
    f0c8:      	b.eq	0xf0e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x60d4>
    f0cc:      	mov	w9, #0x38               // =56
    f0d0:      	umaddl	x9, w8, w9, x19
    f0d4:      	add	x9, x9, #0x20
    f0d8:      	str	w8, [x9], #0x38
    f0dc:      	add	x8, x8, #0x1
    f0e0:      	cmp	x20, x8
    f0e4:      	b.ne	0xf0d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x60c4>
    f0e8:      	cbz	w20, 0xf190 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x617c>
    f0ec:      	mov	x22, xzr
    f0f0:      	mov	w24, #0x34              // =52
    f0f4:      	mov	w25, #0x1040            // =4160
    f0f8:      	nop
    f0fc:      	adr	x23, 0xfe94 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6e80>
    f100:      	b	0xf114 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6100>
    f104:      	add	x22, x22, #0x1
    f108:      	add	x24, x24, #0x38
    f10c:      	cmp	x20, x22
    f110:      	b.eq	0xf138 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6124>
    f114:      	ldr	w8, [x19, x24]
    f118:      	bics	wzr, w25, w8
    f11c:      	b.ne	0xf104 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x60f0>
    f120:      	mov	w0, w20
    f124:      	mov	w1, w22
    f128:      	mov	x2, x23
    f12c:      	mov	x3, x19
    f130:      	bl	0x19010 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfffc>
    f134:      	b	0xf104 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x60f0>
    f138:      	cbz	w20, 0xf190 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x617c>
    f13c:      	mov	x9, xzr
    f140:      	mov	w8, wzr
    f144:      	add	x10, x19, #0x20
    f148:      	mov	w11, #0x1400            // =5120
    f14c:      	mov	w12, #0x38              // =56
    f150:      	b	0xf164 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6150>
    f154:      	add	x9, x9, #0x1
    f158:      	add	x10, x10, #0x38
    f15c:      	cmp	x20, x9
    f160:      	b.eq	0xf194 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6180>
    f164:      	ldr	w13, [x10, #0x14]
    f168:      	bics	wzr, w11, w13
    f16c:      	b.ne	0xf154 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6140>
    f170:      	ldr	w13, [x10]
    f174:      	add	w8, w8, #0x1
    f178:      	cmp	x9, x13
    f17c:      	b.ls	0xf154 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6140>
    f180:      	umaddl	x13, w13, w12, x19
    f184:      	ldr	w13, [x13, #0x20]
    f188:      	str	w13, [x10]
    f18c:      	b	0xf154 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6140>
    f190:      	mov	w8, wzr
    f194:      	cmp	w8, w21
    f198:      	b.eq	0xf1bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x61a8>
    f19c:      	mov	w0, w21
    f1a0:      	mov	w1, w20
    f1a4:      	mov	x2, x19
    f1a8:      	bl	0x12958 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9944>
    f1ac:      	tbnz	w0, #0x0, 0xf1bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x61a8>
    f1b0:      	mov	w0, w20
    f1b4:      	mov	x1, x19
    f1b8:      	bl	0x12bd4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9bc0>
    f1bc:      	mov	w0, w20
    f1c0:      	mov	x1, x19
    f1c4:      	str	x26, [sp, #0xa0]
    f1c8:      	mov	w24, w21
    f1cc:      	bl	0x12db4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9da0>
    f1d0:      	add	x0, sp, #0x200
    f1d4:      	mov	w1, w20
    f1d8:      	mov	w2, w21
    f1dc:      	mov	x3, x19
    f1e0:      	bl	0x177f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe7e4>
    f1e4:      	mov	w23, w0
    f1e8:      	cbz	w20, 0xf3a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x638c>
    f1ec:      	mov	w27, #0x4               // =4
    f1f0:      	str	x24, [sp, #0x90]
    f1f4:      	mov	x22, xzr
    f1f8:      	str	w23, [sp, #0x8c]
    f1fc:      	mov	w24, wzr
    f200:      	mov	w23, wzr
    f204:      	add	x25, x19, #0x34
    f208:      	mov	w26, #0x38              // =56
    f20c:      	movk	w27, #0x3f, lsl #16
    f210:      	b	0xf224 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6210>
    f214:      	add	x22, x22, #0x1
    f218:      	add	x25, x25, #0x38
    f21c:      	cmp	x20, x22
    f220:      	b.eq	0xf2e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x62d4>
    f224:      	ldrb	w8, [x25, #0x1]
    f228:      	tbz	w8, #0x4, 0xf214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6200>
    f22c:      	ldur	w0, [x25, #-0x28]
    f230:      	ldur	w28, [x25, #-0x14]
    f234:      	cbz	w0, 0xf258 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6244>
    f238:      	sub	x1, x25, #0x24
    f23c:      	sub	x2, x25, #0x20
    f240:      	bl	0x102e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72cc>
    f244:      	ldur	w8, [x25, #-0xc]
    f248:      	cmp	w24, w8
    f24c:      	csel	w23, w22, w23, lo
    f250:      	csel	w24, w24, w8, hi
    f254:      	b	0xf2a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6290>
    f258:      	movi	v0.2d, #0000000000000000
    f25c:      	add	x1, sp, #0x180
    f260:      	add	x2, sp, #0x100
    f264:      	mov	w0, w22
    f268:      	stp	q0, q0, [sp, #0x100]
    f26c:      	stp	q0, q0, [sp, #0x120]
    f270:      	stp	q0, q0, [sp, #0x140]
    f274:      	stp	q0, q0, [sp, #0x160]
    f278:      	stp	q0, q0, [sp, #0x180]
    f27c:      	stp	q0, q0, [sp, #0x1a0]
    f280:      	stp	q0, q0, [sp, #0x1c0]
    f284:      	stp	q0, q0, [sp, #0x1e0]
    f288:      	bl	0x18a44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfa30>
    f28c:      	tbz	w0, #0x0, 0xf2a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6290>
    f290:      	sub	x2, x25, #0x24
    f294:      	sub	x3, x25, #0x20
    f298:      	add	x0, sp, #0x180
    f29c:      	add	x1, sp, #0x100
    f2a0:      	bl	0x10874 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7860>
    f2a4:      	ldur	w8, [x25, #-0x24]
    f2a8:      	cbnz	w8, 0xf214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6200>
    f2ac:      	umaddl	x8, w28, w26, x19
    f2b0:      	ldr	w8, [x8, #0xc]
    f2b4:      	cbz	w8, 0xf214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6200>
    f2b8:      	umaddl	x9, w28, w26, x19
    f2bc:      	ldr	w11, [x25]
    f2c0:      	stur	w8, [x25, #-0x28]
    f2c4:      	ldr	w10, [x9, #0x34]
    f2c8:      	and	w10, w10, w27
    f2cc:      	orr	w10, w11, w10
    f2d0:      	str	w10, [x25]
    f2d4:      	ldr	d0, [x9, #0x10]
    f2d8:      	stur	d0, [x25, #-0x24]
    f2dc:      	ldr	w8, [x9, #0x28]
    f2e0:      	stur	w8, [x25, #-0xc]
    f2e4:      	b	0xf214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6200>
    f2e8:      	cbz	w24, 0xf338 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6324>
    f2ec:      	mov	w8, #0x38               // =56
    f2f0:      	adrp	x3, 0x2000
    f2f4:      	add	x3, x3, #0xea0
    f2f8:      	umaddl	x8, w23, w8, x19
    f2fc:      	add	x0, sp, #0x100
    f300:      	mov	w1, #0x20               // =32
    f304:      	mov	w2, #0x20               // =32
    f308:      	ldr	w4, [x8, #0xc]
    f30c:      	bl	0xec5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5c48>
    f310:      	adrp	x3, 0x4000
    f314:      	add	x3, x3, #0x185
    f318:      	add	x0, sp, #0x180
    f31c:      	mov	w1, #0x20               // =32
    f320:      	mov	w2, #0x20               // =32
    f324:      	mov	w4, #0x4                // =4
    f328:      	bl	0xec5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5c48>
    f32c:      	add	x0, sp, #0x180
    f330:      	add	x1, sp, #0x100
    f334:      	bl	0xeb44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x5b30>
    f338:      	nop
    f33c:      	adr	x3, 0xff04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6ef0>
    f340:      	mov	x0, x19
    f344:      	mov	x1, x20
    f348:      	mov	w2, #0x38               // =56
    f34c:      	bl	0x1d8a0 <qsort@plt>
    f350:      	mov	w27, wzr
    f354:      	cbz	w20, 0xf3c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x63ac>
    f358:      	ldr	w23, [sp, #0x8c]
    f35c:      	ldr	x24, [sp, #0x90]
    f360:      	add	x8, x19, #0x34
    f364:      	mov	x9, x20
    f368:      	b	0xf378 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6364>
    f36c:      	subs	x9, x9, #0x1
    f370:      	add	x8, x8, #0x38
    f374:      	b.eq	0xf3c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x63b4>
    f378:      	ldrb	w10, [x8, #0x1]
    f37c:      	tbz	w10, #0x4, 0xf36c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6358>
    f380:      	ldur	w10, [x8, #-0x20]
    f384:      	cmp	w27, #0x0
    f388:      	ccmp	w10, w22, #0x0, ne
    f38c:      	cinc	w27, w27, ne
    f390:      	csel	w22, w10, w22, ne
    f394:      	sub	w11, w27, #0x1
    f398:      	stur	w11, [x8, #-0x1c]
    f39c:      	b	0xf36c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6358>
    f3a0:      	nop
    f3a4:      	adr	x3, 0xff04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6ef0>
    f3a8:      	mov	x0, x19
    f3ac:      	mov	x1, x20
    f3b0:      	mov	w2, #0x38               // =56
    f3b4:      	bl	0x1d8a0 <qsort@plt>
    f3b8:      	mov	w27, wzr
    f3bc:      	b	0xf3c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x63b4>
    f3c0:      	ldr	w23, [sp, #0x8c]
    f3c4:      	ldr	x24, [sp, #0x90]
    f3c8:      	nop
    f3cc:      	adr	x28, 0x2693c
    f3d0:      	add	x0, sp, #0x200
    f3d4:      	mov	x1, x28
    f3d8:      	bl	0x16798 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd784>
    f3dc:      	mov	x0, x24
    f3e0:      	mov	w1, #0x50               // =80
    f3e4:      	str	w21, [x28, #0x84]
    f3e8:      	str	w21, [x28, #0x8c]
    f3ec:      	str	w23, [x28, #0x94]
    f3f0:      	bl	0x1d860 <calloc@plt>
    f3f4:      	cbz	x0, 0xf4bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x64a8>
    f3f8:      	str	x0, [sp, #0x98]
    f3fc:      	mov	x0, x24
    f400:      	mov	w1, #0x40               // =64
    f404:      	bl	0x1d860 <calloc@plt>
    f408:      	cbz	x0, 0xf500 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x64ec>
    f40c:      	mov	w25, w23
    f410:      	str	x0, [sp, #0x80]
    f414:      	mov	w1, #0x38               // =56
    f418:      	mov	x0, x25
    f41c:      	bl	0x1d860 <calloc@plt>
    f420:      	str	x0, [sp, #0x78]
    f424:      	cbz	x0, 0xf53c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6528>
    f428:      	mov	w25, w27
    f42c:      	mov	w1, #0x10               // =16
    f430:      	mov	x0, x25
    f434:      	bl	0x1d860 <calloc@plt>
    f438:      	str	x0, [sp, #0x48]
    f43c:      	cbz	x0, 0xf57c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6568>
    f440:      	mov	x0, x20
    f444:      	mov	w1, #0x8                // =8
    f448:      	bl	0x1d860 <calloc@plt>
    f44c:      	str	x0, [sp, #0x50]
    f450:      	cbz	x0, 0xf5b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x65a0>
    f454:      	mov	x0, x20
    f458:      	mov	w1, #0x8                // =8
    f45c:      	bl	0x1d860 <calloc@plt>
    f460:      	ldr	x26, [sp, #0x80]
    f464:      	str	x0, [sp, #0x40]
    f468:      	cbz	x0, 0xf5ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x65d8>
    f46c:      	cmp	w27, #0x2
    f470:      	b.lo	0xf620 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x660c>
    f474:      	mov	x0, x20
    f478:      	mov	w1, #0x4                // =4
    f47c:      	bl	0x1d860 <calloc@plt>
    f480:      	str	x0, [sp, #0x38]
    f484:      	cbnz	x0, 0xf624 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6610>
    f488:      	lsl	x1, x20, #2
    f48c:      	adrp	x0, 0x3000
    f490:      	add	x0, x0, #0x593
    f494:      	mov	w2, w20
    f498:      	bl	0xfdfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de8>
    f49c:      	ldp	x23, x20, [sp, #0x48]
    f4a0:      	mov	x24, xzr
    f4a4:      	ldr	x21, [sp, #0x78]
    f4a8:      	ldr	x22, [sp, #0x40]
    f4ac:      	mov	x28, xzr
    f4b0:      	str	xzr, [sp, #0xa8]
    f4b4:      	mov	x27, xzr
    f4b8:      	b	0xfd68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6d54>
    f4bc:      	add	x8, x24, x24, lsl #2
    f4c0:      	adrp	x0, 0x4000
    f4c4:      	add	x0, x0, #0x3f
    f4c8:      	mov	w2, w21
    f4cc:      	lsl	x1, x8, #4
    f4d0:      	bl	0xfdfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de8>
    f4d4:      	mov	x24, xzr
    f4d8:      	mov	x22, xzr
    f4dc:      	mov	x20, xzr
    f4e0:      	str	xzr, [sp, #0xa8]
    f4e4:      	mov	x28, xzr
    f4e8:      	mov	x27, xzr
    f4ec:      	mov	x23, xzr
    f4f0:      	mov	x21, xzr
    f4f4:      	mov	x26, xzr
    f4f8:      	mov	x25, xzr
    f4fc:      	b	0xfd6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6d58>
    f500:      	lsl	x1, x24, #6
    f504:      	adrp	x0, 0x3000
    f508:      	add	x0, x0, #0xa42
    f50c:      	mov	w2, w21
    f510:      	bl	0xfdfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de8>
    f514:      	mov	x24, xzr
    f518:      	mov	x22, xzr
    f51c:      	mov	x20, xzr
    f520:      	str	xzr, [sp, #0xa8]
    f524:      	mov	x28, xzr
    f528:      	mov	x27, xzr
    f52c:      	mov	x23, xzr
    f530:      	mov	x21, xzr
    f534:      	mov	x26, xzr
    f538:      	b	0xfd68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6d54>
    f53c:      	lsl	x8, x25, #6
    f540:      	adrp	x0, 0x3000
    f544:      	add	x0, x0, #0xc42
    f548:      	mov	w2, w23
    f54c:      	sub	x1, x8, x25, lsl #3
    f550:      	bl	0xfdfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de8>
    f554:      	ldr	x26, [sp, #0x80]
    f558:      	mov	x24, xzr
    f55c:      	mov	x22, xzr
    f560:      	mov	x20, xzr
    f564:      	str	xzr, [sp, #0xa8]
    f568:      	mov	x28, xzr
    f56c:      	mov	x27, xzr
    f570:      	mov	x23, xzr
    f574:      	mov	x21, xzr
    f578:      	b	0xfd68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6d54>
    f57c:      	lsl	x1, x25, #4
    f580:      	adrp	x0, 0x4000
    f584:      	add	x0, x0, #0x60a
    f588:      	mov	w2, w27
    f58c:      	bl	0xfdfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de8>
    f590:      	ldp	x21, x26, [sp, #0x78]
    f594:      	mov	x24, xzr
    f598:      	mov	x22, xzr
    f59c:      	mov	x20, xzr
    f5a0:      	str	xzr, [sp, #0xa8]
    f5a4:      	mov	x28, xzr
    f5a8:      	mov	x27, xzr
    f5ac:      	mov	x23, xzr
    f5b0:      	b	0xfd68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6d54>
    f5b4:      	lsl	x1, x20, #3
    f5b8:      	adrp	x0, 0x2000
    f5bc:      	add	x0, x0, #0xd84
    f5c0:      	mov	w2, w20
    f5c4:      	bl	0xfdfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de8>
    f5c8:      	ldp	x21, x26, [sp, #0x78]
    f5cc:      	mov	x24, xzr
    f5d0:      	ldr	x23, [sp, #0x48]
    f5d4:      	mov	x22, xzr
    f5d8:      	mov	x20, xzr
    f5dc:      	str	xzr, [sp, #0xa8]
    f5e0:      	mov	x28, xzr
    f5e4:      	mov	x27, xzr
    f5e8:      	b	0xfd68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6d54>
    f5ec:      	lsl	x1, x20, #3
    f5f0:      	adrp	x0, 0x3000
    f5f4:      	add	x0, x0, #0xb2f
    f5f8:      	mov	w2, w20
    f5fc:      	bl	0xfdfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de8>
    f600:      	ldp	x23, x20, [sp, #0x48]
    f604:      	mov	x24, xzr
    f608:      	ldr	x21, [sp, #0x78]
    f60c:      	mov	x22, xzr
    f610:      	str	xzr, [sp, #0xa8]
    f614:      	mov	x28, xzr
    f618:      	mov	x27, xzr
    f61c:      	b	0xfd68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6d54>
    f620:      	str	xzr, [sp, #0x38]
    f624:      	mov	x0, x24
    f628:      	mov	w1, #0x20               // =32
    f62c:      	bl	0x1d860 <calloc@plt>
    f630:      	str	x0, [sp, #0x30]
    f634:      	cbz	x0, 0xf92c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6918>
    f638:      	mov	x0, x24
    f63c:      	mov	w1, #0x20               // =32
    f640:      	bl	0x1d860 <calloc@plt>
    f644:      	cbz	x0, 0xf9ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6998>
    f648:      	str	x0, [sp, #0x20]
    f64c:      	ldr	x0, [sp, #0x98]
    f650:      	cbz	w20, 0xf6c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x66b0>
    f654:      	movi	v0.2s, #0x1
    f658:      	mov	w8, wzr
    f65c:      	add	x9, x19, #0x34
    f660:      	mov	x10, x20
    f664:      	b	0xf6a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6690>
    f668:      	ldr	x14, [sp, #0x48]
    f66c:      	ldur	w13, [x9, #-0x28]
    f670:      	mov	w22, w11
    f674:      	add	x12, x14, w8, uxtw #4
    f678:      	add	w8, w8, #0x1
    f67c:      	stp	w11, w13, [x12]
    f680:      	str	xzr, [x12, #0x8]
    f684:      	sub	w11, w8, #0x1
    f688:      	add	x11, x14, w11, uxtw #4
    f68c:      	ldr	d1, [x11, #0x8]
    f690:      	add	v1.2s, v1.2s, v0.2s
    f694:      	str	d1, [x11, #0x8]
    f698:      	subs	x10, x10, #0x1
    f69c:      	add	x9, x9, #0x38
    f6a0:      	b.eq	0xf6c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x66b0>
    f6a4:      	ldrb	w11, [x9, #0x1]
    f6a8:      	tbz	w11, #0x4, 0xf698 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6684>
    f6ac:      	ldur	w11, [x9, #-0x20]
    f6b0:      	cbz	w8, 0xf668 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6654>
    f6b4:      	cmp	w11, w22
    f6b8:      	b.ne	0xf668 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6654>
    f6bc:      	ldr	x14, [sp, #0x48]
    f6c0:      	b	0xf684 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6670>
    f6c4:      	cbz	w21, 0xf9dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x69c8>
    f6c8:      	lsl	x8, x24, #6
    f6cc:      	mov	x1, xzr
    f6d0:      	mov	x22, xzr
    f6d4:      	mov	x13, xzr
    f6d8:      	mov	w14, wzr
    f6dc:      	mov	x15, xzr
    f6e0:      	add	x28, x19, #0x30
    f6e4:      	stp	xzr, x8, [sp, #0x10]
    f6e8:      	mov	w4, #-0x1               // =-1
    f6ec:      	mov	w16, #0x1               // =1
    f6f0:      	mov	w17, #0x38              // =56
    f6f4:      	mov	w8, #0x1                // =1
    f6f8:      	str	w23, [sp, #0x8c]
    f6fc:      	str	wzr, [sp, #0x5c]
    f700:      	str	w8, [sp, #0x2c]
    f704:      	str	x24, [sp, #0x90]
    f708:      	b	0xf774 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6760>
    f70c:      	ldr	w8, [sp, #0x180]
    f710:      	ldr	x0, [sp, #0x98]
    f714:      	ldr	x26, [sp, #0x80]
    f718:      	ldr	x13, [sp, #0xa8]
    f71c:      	ldr	w14, [sp, #0x70]
    f720:      	ldr	x15, [sp, #0x68]
    f724:      	cbz	w8, 0xf918 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6904>
    f728:      	ldur	w8, [x28, #-0x10]
    f72c:      	ldr	w9, [x28]
    f730:      	str	wzr, [sp, #0x2c]
    f734:      	cmp	w8, w9
    f738:      	ldr	w8, [sp, #0x5c]
    f73c:      	cinc	w8, w8, eq
    f740:      	str	w8, [sp, #0x5c]
    f744:      	ldr	x1, [sp, #0x60]
    f748:      	mov	w17, #0x38              // =56
    f74c:      	mov	w4, w23
    f750:      	ldr	x8, [sp, #0x18]
    f754:      	add	x22, x22, #0x40
    f758:      	add	x15, x15, #0x1
    f75c:      	add	w14, w14, #0x1
    f760:      	add	x28, x28, #0x38
    f764:      	add	x13, x13, #0x50
    f768:      	cmp	x8, x22
    f76c:      	add	x1, x1, #0x20
    f770:      	b.eq	0xf95c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6948>
    f774:      	ldur	w9, [x28, #-0x10]
    f778:      	ldr	w8, [x28]
    f77c:      	str	w14, [sp, #0x70]
    f780:      	cmp	w9, w8
    f784:      	b.ne	0xf7d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x67c0>
    f788:      	add	w9, w4, #0x1
    f78c:      	ldr	x12, [sp, #0x78]
    f790:      	ldur	w11, [x28, #-0xc]
    f794:      	nop
    f798:      	umaddl	x10, w9, w17, x12
    f79c:      	ldur	d0, [x28, #-0x20]
    f7a0:      	ldur	w2, [x28, #-0x24]
    f7a4:      	mov	w24, w15
    f7a8:      	mov	w4, w9
    f7ac:      	stp	w14, w11, [x10]
    f7b0:      	stp	w14, w11, [x10, #0x8]
    f7b4:      	nop
    f7b8:      	adr	x14, 0x2693c
    f7bc:      	str	w9, [x10, #0x10]
    f7c0:      	str	x14, [x10, #0x18]
    f7c4:      	str	d0, [x10, #0x20]
    f7c8:      	str	w2, [x10, #0x28]
    f7cc:      	str	xzr, [x10, #0x30]
    f7d0:      	b	0xf7f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x67dc>
    f7d4:      	ldur	d0, [x28, #-0x20]
    f7d8:      	ldur	w2, [x28, #-0x24]
    f7dc:      	mov	w9, w4
    f7e0:      	ldr	x12, [sp, #0x78]
    f7e4:      	mov	w24, w14
    f7e8:      	nop
    f7ec:      	adr	x14, 0x2693c
    f7f0:      	umaddl	x9, w9, w17, x12
    f7f4:      	ldr	x12, [sp, #0x30]
    f7f8:      	add	x11, x26, x22
    f7fc:      	str	x13, [sp, #0xa8]
    f800:      	add	x10, x0, x13
    f804:      	ldr	x13, [sp, #0x50]
    f808:      	add	x26, x12, x1
    f80c:      	ldr	x12, [sp, #0x20]
    f810:      	str	wzr, [x10]
    f814:      	stp	x9, x14, [x10, #0x10]
    f818:      	ldur	d1, [x28, #-0x8]
    f81c:      	add	x25, x12, x1
    f820:      	lsl	x12, x8, #3
    f824:      	str	x11, [x10, #0x8]
    f828:      	str	w8, [x10, #0x20]
    f82c:      	stp	x26, x25, [x10, #0x28]
    f830:      	str	x10, [x13, x12]
    f834:      	stp	x9, x14, [x11, #0x10]
    f838:      	ldp	x10, x9, [sp, #0x38]
    f83c:      	stp	x1, x15, [sp, #0x60]
    f840:      	stp	w24, w16, [x11]
    f844:      	str	w24, [x11, #0x8]
    f848:      	str	d0, [x11, #0x20]
    f84c:      	str	w2, [x11, #0x28]
    f850:      	stur	d1, [x11, #0x2c]
    f854:      	str	x11, [x9, x12]
    f858:      	cbz	x10, 0xf864 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6850>
    f85c:      	ldur	w9, [x28, #-0x18]
    f860:      	str	w9, [x10, x8, lsl #2]
    f864:      	mov	w0, v0.s[1]
    f868:      	movi	v0.2d, #0000000000000000
    f86c:      	ldur	w1, [x28, #-0xc]
    f870:      	ldur	w5, [x28, #-0x30]
    f874:      	add	x8, sp, #0x100
    f878:      	add	x3, sp, #0x200
    f87c:      	str	x8, [sp, #0x8]
    f880:      	mov	x6, x26
    f884:      	mov	x7, x25
    f888:      	add	x8, sp, #0x180
    f88c:      	mov	w23, w4
    f890:      	stp	q0, q0, [sp, #0x100]
    f894:      	stp	q0, q0, [sp, #0x180]
    f898:      	str	x8, [sp]
    f89c:      	bl	0x110c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x80b0>
    f8a0:      	ldr	w8, [sp, #0x100]
    f8a4:      	mov	w16, #0x1               // =1
    f8a8:      	stp	w24, w16, [x25, #0x18]
    f8ac:      	stp	w24, w16, [x26, #0x18]
    f8b0:      	cbz	w8, 0xf70c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x66f8>
    f8b4:      	ldur	w9, [x28, #-0x10]
    f8b8:      	ldr	w10, [x28]
    f8bc:      	ldr	x0, [sp, #0x98]
    f8c0:      	ldr	x26, [sp, #0x80]
    f8c4:      	ldr	x13, [sp, #0xa8]
    f8c8:      	ldr	w14, [sp, #0x70]
    f8cc:      	cmp	w9, w10
    f8d0:      	ldr	w9, [sp, #0x5c]
    f8d4:      	ldr	x15, [sp, #0x68]
    f8d8:      	add	w9, w9, #0x1
    f8dc:      	str	w9, [sp, #0x5c]
    f8e0:      	b.ne	0xf744 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6730>
    f8e4:      	ldr	x1, [sp, #0x60]
    f8e8:      	mov	w17, #0x38              // =56
    f8ec:      	mov	w4, w23
    f8f0:      	cbz	w23, 0xf920 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x690c>
    f8f4:      	ldp	w10, w9, [sp, #0x10]
    f8f8:      	cmp	w8, w10
    f8fc:      	cinc	w9, w9, ne
    f900:      	cset	w8, eq
    f904:      	str	w9, [sp, #0x14]
    f908:      	ldr	w9, [sp, #0x2c]
    f90c:      	and	w9, w8, w9
    f910:      	str	w9, [sp, #0x2c]
    f914:      	b	0xf750 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x673c>
    f918:      	str	wzr, [sp, #0x2c]
    f91c:      	b	0xf744 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6730>
    f920:      	mov	w9, #0x1                // =1
    f924:      	stp	w8, w9, [sp, #0x10]
    f928:      	b	0xf750 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x673c>
    f92c:      	lsl	x1, x24, #5
    f930:      	adrp	x0, 0x4000
    f934:      	add	x0, x0, #0x4ea
    f938:      	mov	w2, w21
    f93c:      	bl	0xfdfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de8>
    f940:      	ldp	x23, x20, [sp, #0x48]
    f944:      	mov	x28, xzr
    f948:      	ldp	x24, x22, [sp, #0x38]
    f94c:      	mov	x27, xzr
    f950:      	ldr	x21, [sp, #0x78]
    f954:      	str	xzr, [sp, #0xa8]
    f958:      	b	0xfd68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6d54>
    f95c:      	ldr	w24, [sp, #0x5c]
    f960:      	cbz	w24, 0xf9f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x69dc>
    f964:      	mov	w25, w24
    f968:      	mov	w1, #0x20               // =32
    f96c:      	mov	x0, x25
    f970:      	bl	0x1d860 <calloc@plt>
    f974:      	cbz	x0, 0xfa08 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x69f4>
    f978:      	ldr	w8, [sp, #0x14]
    f97c:      	mov	x22, x0
    f980:      	cbz	w8, 0xfa2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6a18>
    f984:      	mov	w25, w8
    f988:      	mov	w1, #0x20               // =32
    f98c:      	mov	x0, x25
    f990:      	bl	0x1d860 <calloc@plt>
    f994:      	ldr	w23, [sp, #0x8c]
    f998:      	nop
    f99c:      	adr	x28, 0x2693c
    f9a0:      	cbz	x0, 0xfd3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6d28>
    f9a4:      	mov	x11, x0
    f9a8:      	b	0xfa40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6a2c>
    f9ac:      	lsl	x1, x24, #5
    f9b0:      	adrp	x0, 0x4000
    f9b4:      	add	x0, x0, #0x8a3
    f9b8:      	mov	w2, w21
    f9bc:      	bl	0xfdfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de8>
    f9c0:      	ldp	x23, x20, [sp, #0x48]
    f9c4:      	mov	x28, xzr
    f9c8:      	ldp	x24, x22, [sp, #0x38]
    f9cc:      	ldr	x21, [sp, #0x78]
    f9d0:      	ldr	x27, [sp, #0x30]
    f9d4:      	str	xzr, [sp, #0xa8]
    f9d8:      	b	0xfd68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6d54>
    f9dc:      	mov	x22, xzr
    f9e0:      	mov	x11, xzr
    f9e4:      	mov	w10, wzr
    f9e8:      	mov	w24, wzr
    f9ec:      	b	0xfc48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6c34>
    f9f0:      	ldr	w23, [sp, #0x8c]
    f9f4:      	mov	x11, xzr
    f9f8:      	mov	x22, xzr
    f9fc:      	nop
    fa00:      	adr	x28, 0x2693c
    fa04:      	b	0xfa44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6a30>
    fa08:      	lsl	x1, x25, #5
    fa0c:      	adrp	x0, 0x4000
    fa10:      	add	x0, x0, #0x74c
    fa14:      	mov	w2, w24
    fa18:      	bl	0xfdfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de8>
    fa1c:      	ldp	x21, x26, [sp, #0x78]
    fa20:      	ldr	x20, [sp, #0x50]
    fa24:      	str	xzr, [sp, #0xa8]
    fa28:      	b	0xfd5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6d48>
    fa2c:      	ldr	w23, [sp, #0x8c]
    fa30:      	str	wzr, [sp, #0x14]
    fa34:      	mov	x11, xzr
    fa38:      	nop
    fa3c:      	adr	x28, 0x2693c
    fa40:      	ldr	x0, [sp, #0x98]
    fa44:      	cbz	w21, 0xfc40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6c2c>
    fa48:      	str	x22, [sp, #0xa8]
    fa4c:      	mov	x22, xzr
    fa50:      	add	x23, x19, #0x20
    fa54:      	str	w24, [sp, #0x5c]
    fa58:      	add	x24, x0, #0x40
    fa5c:      	mov	w25, #-0x1              // =-1
    fa60:      	mov	w8, #-0x1               // =-1
    fa64:      	mov	w4, #-0x1               // =-1
    fa68:      	stp	x11, x8, [sp, #0x68]
    fa6c:      	b	0xfa90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6a7c>
    fa70:      	ldr	x8, [sp, #0x68]
    fa74:      	str	x8, [x24]
    fa78:      	ldr	x8, [sp, #0x90]
    fa7c:      	add	x22, x22, #0x1
    fa80:      	add	x23, x23, #0x38
    fa84:      	add	x24, x24, #0x50
    fa88:      	cmp	x8, x22
    fa8c:      	b.eq	0xfc20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6c0c>
    fa90:      	ldp	w8, w1, [x23]
    fa94:      	ldr	w9, [x23, #0x10]
    fa98:      	movi	v0.2d, #0000000000000000
    fa9c:      	ldur	w0, [x23, #-0xc]
    faa0:      	ldur	w2, [x23, #-0x14]
    faa4:      	ldur	w5, [x23, #-0x20]
    faa8:      	add	x3, sp, #0x200
    faac:      	cmp	w8, w9
    fab0:      	add	x8, sp, #0xb0
    fab4:      	add	x6, sp, #0x180
    fab8:      	cinc	w4, w4, eq
    fabc:      	add	x7, sp, #0x100
    fac0:      	str	x8, [sp, #0x8]
    fac4:      	add	x8, sp, #0xd0
    fac8:      	stp	q0, q0, [sp, #0xb0]
    facc:      	mov	w26, w4
    fad0:      	stp	q0, q0, [sp, #0xd0]
    fad4:      	str	x8, [sp]
    fad8:      	bl	0x110c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x80b0>
    fadc:      	ldr	w8, [sp, #0xb0]
    fae0:      	cbz	w8, 0xfb50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6b3c>
    fae4:      	ldr	x9, [sp, #0xa8]
    fae8:      	add	w25, w25, #0x1
    faec:      	ldr	w10, [sp, #0xd8]
    faf0:      	ldr	d0, [sp, #0xd0]
    faf4:      	mov	w12, #0x1               // =1
    faf8:      	ldr	w11, [x23, #0x10]
    fafc:      	add	x9, x9, x25, lsl #5
    fb00:      	stp	w10, w12, [x9, #0x8]
    fb04:      	ldr	w10, [x23]
    fb08:      	str	d0, [x9]
    fb0c:      	ldr	d0, [sp, #0xe0]
    fb10:      	cmp	w10, w11
    fb14:      	stp	w22, w12, [x9, #0x18]
    fb18:      	str	d0, [x9, #0x10]
    fb1c:      	stur	x9, [x24, #-0x8]
    fb20:      	b.ne	0xfba4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6b90>
    fb24:      	ldr	x10, [sp, #0x70]
    fb28:      	ldr	w9, [sp, #0x14]
    fb2c:      	mov	w4, w26
    fb30:      	add	w10, w10, #0x1
    fb34:      	cmp	w10, w9
    fb38:      	str	x10, [sp, #0x70]
    fb3c:      	b.hs	0xfbf4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6be0>
    fb40:      	ldr	w9, [sp, #0x2c]
    fb44:      	tbz	w9, #0x0, 0xfbc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6bb4>
    fb48:      	ldr	x9, [sp, #0x90]
    fb4c:      	b	0xfbcc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6bb8>
    fb50:      	ldr	w9, [sp, #0xd0]
    fb54:      	cbz	w9, 0xfbac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6b98>
    fb58:      	ldr	w8, [x23]
    fb5c:      	ldr	w10, [x23, #0x10]
    fb60:      	mov	w4, w26
    fb64:      	cmp	w8, w10
    fb68:      	b.ne	0xfbb4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6ba0>
    fb6c:      	ldr	x11, [sp, #0xa8]
    fb70:      	add	w8, w25, #0x1
    fb74:      	ldur	d0, [sp, #0xd4]
    fb78:      	ldr	d1, [sp, #0xe0]
    fb7c:      	mov	w25, w8
    fb80:      	add	x10, x11, x8, lsl #5
    fb84:      	str	w9, [x10]
    fb88:      	mov	w9, #0x1                // =1
    fb8c:      	str	w9, [x10, #0xc]
    fb90:      	ldr	w9, [x23, #0x4]
    fb94:      	stur	d0, [x10, #0x4]
    fb98:      	str	d1, [x10, #0x10]
    fb9c:      	stp	w22, w9, [x10, #0x18]
    fba0:      	b	0xfbbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6ba8>
    fba4:      	mov	w4, w26
    fba8:      	b	0xfbf4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6be0>
    fbac:      	mov	w4, w26
    fbb0:      	b	0xfa78 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6a64>
    fbb4:      	ldr	x11, [sp, #0xa8]
    fbb8:      	mov	w8, w25
    fbbc:      	add	x8, x11, x8, lsl #5
    fbc0:      	stur	x8, [x24, #-0x8]
    fbc4:      	b	0xfa78 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6a64>
    fbc8:      	ldr	w9, [x23, #0x4]
    fbcc:      	ldp	x10, x11, [sp, #0x68]
    fbd0:      	ldur	d0, [sp, #0xb4]
    fbd4:      	ldr	d1, [sp, #0xc0]
    fbd8:      	add	x10, x10, x11, lsl #5
    fbdc:      	str	w8, [x10]
    fbe0:      	mov	w8, #0x1                // =1
    fbe4:      	stur	d0, [x10, #0x4]
    fbe8:      	str	w8, [x10, #0xc]
    fbec:      	str	d1, [x10, #0x10]
    fbf0:      	stp	w22, w9, [x10, #0x18]
    fbf4:      	ldr	w8, [sp, #0x2c]
    fbf8:      	tbnz	w8, #0x0, 0xfa70 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6a5c>
    fbfc:      	ldr	w8, [sp, #0x14]
    fc00:      	ldr	x9, [sp, #0x70]
    fc04:      	cmp	w9, w8
    fc08:      	b.hs	0xfa78 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6a64>
    fc0c:      	mov	x8, x9
    fc10:      	ldr	x9, [sp, #0x68]
    fc14:      	mov	w8, w8
    fc18:      	add	x8, x9, x8, lsl #5
    fc1c:      	b	0xfa74 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6a60>
    fc20:      	ldr	w23, [sp, #0x8c]
    fc24:      	ldr	x0, [sp, #0x98]
    fc28:      	ldr	x26, [sp, #0x80]
    fc2c:      	ldr	w24, [sp, #0x5c]
    fc30:      	ldr	w10, [sp, #0x14]
    fc34:      	ldr	x22, [sp, #0xa8]
    fc38:      	ldr	x11, [sp, #0x68]
    fc3c:      	b	0xfc48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6c34>
    fc40:      	ldr	x26, [sp, #0x80]
    fc44:      	ldr	w10, [sp, #0x14]
    fc48:      	adrp	x8, 0x26000
    fc4c:      	adrp	x9, 0x26000
    fc50:      	str	x26, [x8, #0x3e0]
    fc54:      	adrp	x8, 0x26000
    fc58:      	str	x0, [x8, #0x3d8]
    fc5c:      	ldr	x8, [sp, #0x78]
    fc60:      	str	x8, [x9, #0x3e8]
    fc64:      	adrp	x8, 0x26000
    fc68:      	ldr	x9, [sp, #0x48]
    fc6c:      	str	x28, [x8, #0x3f0]
    fc70:      	adrp	x8, 0x26000
    fc74:      	str	x9, [x8, #0x548]
    fc78:      	ldr	x9, [sp, #0x30]
    fc7c:      	nop
    fc80:      	adr	x8, 0x263f8
    fc84:      	str	x9, [x8]
    fc88:      	ldr	x9, [sp, #0x20]
    fc8c:      	str	x11, [x8, #0x18]
    fc90:      	stp	x9, x22, [x8, #0x8]
    fc94:      	adrp	x8, 0x26000
    fc98:      	mov	w22, #0x1               // =1
    fc9c:      	str	w21, [x8, #0x420]
    fca0:      	adrp	x8, 0x26000
    fca4:      	str	w21, [x8, #0x424]
    fca8:      	adrp	x8, 0x26000
    fcac:      	str	w23, [x8, #0x428]
    fcb0:      	adrp	x8, 0x26000
    fcb4:      	str	w22, [x8, #0x42c]
    fcb8:      	adrp	x8, 0x26000
    fcbc:      	str	w27, [x8, #0x550]
    fcc0:      	nop
    fcc4:      	adr	x8, 0x26430
    fcc8:      	stp	w21, w21, [x8]
    fccc:      	stp	w24, w10, [x8, #0x8]
    fcd0:      	bl	0x11c90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c7c>
    fcd4:      	adrp	x8, 0x26000
    fcd8:      	ldr	x9, [sp, #0x50]
    fcdc:      	str	xzr, [sp, #0xa8]
    fce0:      	str	w0, [x8, #0x444]
    fce4:      	adrp	x8, 0x26000
    fce8:      	mov	x28, xzr
    fcec:      	str	w20, [x8, #0x554]
    fcf0:      	adrp	x8, 0x26000
    fcf4:      	mov	x27, xzr
    fcf8:      	str	x9, [x8, #0x558]
    fcfc:      	ldp	x9, x10, [sp, #0x38]
    fd00:      	adrp	x8, 0x26000
    fd04:      	mov	x23, xzr
    fd08:      	mov	x21, xzr
    fd0c:      	mov	x26, xzr
    fd10:      	mov	x25, xzr
    fd14:      	mov	x24, xzr
    fd18:      	str	x10, [x8, #0x560]
    fd1c:      	adrp	x8, 0x26000
    fd20:      	mov	x20, xzr
    fd24:      	str	x9, [x8, #0x568]
    fd28:      	adrp	x8, 0x26000
    fd2c:      	dmb	ish
    fd30:      	strb	w22, [x8, #0x3d0]
    fd34:      	mov	x22, xzr
    fd38:      	b	0xfd6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6d58>
    fd3c:      	lsl	x1, x25, #5
    fd40:      	ldr	w2, [sp, #0x14]
    fd44:      	adrp	x0, 0x4000
    fd48:      	add	x0, x0, #0x2cd
    fd4c:      	bl	0xfdfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de8>
    fd50:      	ldp	x21, x26, [sp, #0x78]
    fd54:      	ldr	x20, [sp, #0x50]
    fd58:      	str	x22, [sp, #0xa8]
    fd5c:      	ldp	x22, x23, [sp, #0x40]
    fd60:      	ldr	x28, [sp, #0x20]
    fd64:      	ldp	x27, x24, [sp, #0x30]
    fd68:      	ldr	x25, [sp, #0x98]
    fd6c:      	mov	x0, x19
    fd70:      	bl	0x1d880 <free@plt>
    fd74:      	mov	x0, x25
    fd78:      	bl	0x1d880 <free@plt>
    fd7c:      	mov	x0, x26
    fd80:      	bl	0x1d880 <free@plt>
    fd84:      	mov	x0, x21
    fd88:      	bl	0x1d880 <free@plt>
    fd8c:      	mov	x0, x23
    fd90:      	bl	0x1d880 <free@plt>
    fd94:      	mov	x0, x27
    fd98:      	bl	0x1d880 <free@plt>
    fd9c:      	mov	x0, x28
    fda0:      	bl	0x1d880 <free@plt>
    fda4:      	ldr	x0, [sp, #0xa8]
    fda8:      	bl	0x1d880 <free@plt>
    fdac:      	mov	x0, x20
    fdb0:      	bl	0x1d880 <free@plt>
    fdb4:      	mov	x0, x22
    fdb8:      	bl	0x1d880 <free@plt>
    fdbc:      	mov	x0, x24
    fdc0:      	bl	0x1d880 <free@plt>
    fdc4:      	ldr	x26, [sp, #0xa0]
    fdc8:      	ldr	x8, [x26, #0x28]
    fdcc:      	ldur	x9, [x29, #-0x10]
    fdd0:      	cmp	x8, x9
    fdd4:      	b.ne	0xfdf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6de4>
    fdd8:      	add	sp, sp, #0x550
    fddc:      	ldp	x20, x19, [sp, #0x50]
    fde0:      	ldp	x22, x21, [sp, #0x40]
    fde4:      	ldp	x24, x23, [sp, #0x30]
    fde8:      	ldp	x26, x25, [sp, #0x20]
    fdec:      	ldp	x28, x27, [sp, #0x10]
    fdf0:      	ldp	x29, x30, [sp], #0x60
    fdf4:      	ret
    fdf8:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    fdfc:      	sub	sp, sp, #0x130
    fe00:      	stp	x29, x30, [sp, #0x110]
    fe04:      	stp	x28, x19, [sp, #0x120]
    fe08:      	add	x29, sp, #0x110
    fe0c:      	stp	x1, x2, [sp, #0x88]
    fe10:      	add	x9, sp, #0x88
    fe14:      	mov	x10, sp
    fe18:      	stp	x3, x4, [sp, #0x98]
    fe1c:      	add	x10, x10, #0x80
    fe20:      	sub	x1, x29, #0x50
    fe24:      	stp	x5, x6, [sp, #0xa8]
    fe28:      	str	x7, [sp, #0xb8]
    fe2c:      	stp	q0, q1, [sp]
    fe30:      	stp	q2, q3, [sp, #0x20]
    fe34:      	stp	q4, q5, [sp, #0x40]
    fe38:      	stp	q6, q7, [sp, #0x60]
    fe3c:      	mrs	x19, TPIDR_EL0
    fe40:      	ldr	x8, [x19, #0x28]
    fe44:      	stur	x8, [x29, #-0x8]
    fe48:      	add	x8, x9, #0x38
    fe4c:      	add	x9, x29, #0x20
    fe50:      	stp	x9, x8, [x29, #-0x28]
    fe54:      	mov	x8, #-0x38              // =-56
    fe58:      	sub	x9, x29, #0x28
    fe5c:      	movk	x8, #0xff80, lsl #32
    fe60:      	stp	x10, x8, [x29, #-0x18]
    fe64:      	ldp	q0, q1, [x9]
    fe68:      	stp	q0, q1, [x29, #-0x50]
    fe6c:      	bl	0xe6c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x56ac>
    fe70:      	ldr	x8, [x19, #0x28]
    fe74:      	ldur	x9, [x29, #-0x8]
    fe78:      	cmp	x8, x9
    fe7c:      	b.ne	0xfe90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6e7c>
    fe80:      	ldp	x28, x19, [sp, #0x120]
    fe84:      	ldp	x29, x30, [sp, #0x110]
    fe88:      	add	sp, sp, #0x130
    fe8c:      	ret
    fe90:      	bl	0x1d4a0 <__stack_chk_fail@plt>
    fe94:      	mov	w10, #0x38              // =56
    fe98:      	cmp	w1, w2
    fe9c:      	umaddl	x8, w0, w10, x3
    fea0:      	ldr	w9, [x8, #0x20]!
    fea4:      	ldr	w11, [x8, #0x14]
    fea8:      	orr	w11, w11, #0x400
    feac:      	str	w11, [x8, #0x14]
    feb0:      	b.hs	0xfef8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6ee4>
    feb4:      	umaddl	x11, w1, w10, x3
    feb8:      	mov	w10, w2
    febc:      	sub	x10, x10, w1, uxtw
    fec0:      	add	x11, x11, #0x34
    fec4:      	b	0xfed4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6ec0>
    fec8:      	subs	x10, x10, #0x1
    fecc:      	add	x11, x11, #0x38
    fed0:      	b.eq	0xfef8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6ee4>
    fed4:      	ldr	w12, [x11]
    fed8:      	tbz	w12, #0xc, 0xfec8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6eb4>
    fedc:      	ldur	w13, [x11, #-0x14]
    fee0:      	orr	w12, w12, #0x400
    fee4:      	str	w12, [x11]
    fee8:      	cmp	w13, w9
    feec:      	csel	w9, w13, w9, lo
    fef0:      	stur	w9, [x11, #-0x14]
    fef4:      	b	0xfec8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6eb4>
    fef8:      	mov	w0, #0x1                // =1
    fefc:      	str	w9, [x8]
    ff00:      	ret
    ff04:      	ldr	w8, [x0, #0x34]
    ff08:      	ldr	w9, [x1, #0x34]
    ff0c:      	ubfx	w10, w8, #12, #1
    ff10:      	and	w9, w9, #0x1000
    ff14:      	cmp	w10, w9, lsr #12
    ff18:      	b.eq	0xff2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6f18>
    ff1c:      	lsr	w9, w9, #12
    ff20:      	and	w8, w8, #0x1000
    ff24:      	sub	w0, w9, w8, lsr #12
    ff28:      	ret
    ff2c:      	stp	x29, x30, [sp, #-0x30]!
    ff30:      	stp	x22, x21, [sp, #0x10]
    ff34:      	stp	x20, x19, [sp, #0x20]
    ff38:      	mov	x29, sp
    ff3c:      	ldr	w8, [x0, #0xc]
    ff40:      	ldr	w19, [x1, #0xc]
    ff44:      	cmp	w8, w19
    ff48:      	b.eq	0xff84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6f70>
    ff4c:      	mov	x21, x0
    ff50:      	mov	w0, w8
    ff54:      	mov	x22, x1
    ff58:      	bl	0xfff8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6fe4>
    ff5c:      	mov	w20, w0
    ff60:      	mov	w0, w19
    ff64:      	bl	0xfff8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6fe4>
    ff68:      	mov	w8, w0
    ff6c:      	mov	w9, #-0x1               // =-1
    ff70:      	mov	x1, x22
    ff74:      	cmp	w20, w0
    ff78:      	mov	x0, x21
    ff7c:      	cneg	w8, w9, ls
    ff80:      	b.ne	0xffe4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6fd0>
    ff84:      	ldr	w8, [x0, #0x28]
    ff88:      	ldr	w9, [x1, #0x28]
    ff8c:      	cmp	w8, w9
    ff90:      	b.ne	0xffcc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6fb8>
    ff94:      	ldr	w8, [x0, #0x20]
    ff98:      	ldr	w9, [x1, #0x20]
    ff9c:      	cmp	w8, w9
    ffa0:      	b.ne	0xffcc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x6fb8>
    ffa4:      	ldr	w8, [x0, #0x30]
    ffa8:      	ldr	w9, [x1, #0x30]
    ffac:      	cmp	w8, w9
    ffb0:      	cset	w8, hi
    ffb4:      	cset	w9, lo
    ffb8:      	sub	w0, w8, w9
    ffbc:      	ldp	x20, x19, [sp, #0x20]
    ffc0:      	ldp	x22, x21, [sp, #0x10]
    ffc4:      	ldp	x29, x30, [sp], #0x30
    ffc8:      	ret
    ffcc:      	mov	w8, #-0x1               // =-1
    ffd0:      	cneg	w0, w8, ls
    ffd4:      	ldp	x20, x19, [sp, #0x20]
    ffd8:      	ldp	x22, x21, [sp, #0x10]
    ffdc:      	ldp	x29, x30, [sp], #0x30
    ffe0:      	ret
    ffe4:      	mov	w0, w8
    ffe8:      	ldp	x20, x19, [sp, #0x20]
    ffec:      	ldp	x22, x21, [sp, #0x10]
    fff0:      	ldp	x29, x30, [sp], #0x30
    fff4:      	ret
    fff8:      	mov	w9, #0xd4cf             // =54479
    fffc:      	and	w8, w0, #0xfffffff0
   10000:      	mov	w0, #0x6                // =6
   10004:      	movk	w9, #0x4100, lsl #16
   10008:      	and	w8, w8, #0xff00ffff
   1000c:      	cmp	w8, w9
   10010:      	b.le	0x10070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x705c>
   10014:      	mov	w9, #0x800f             // =32783
   10018:      	movk	w9, #0x5100, lsl #16
   1001c:      	cmp	w8, w9
   10020:      	b.le	0x1010c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x70f8>
   10024:      	mov	w9, #0x804f             // =32847
   10028:      	movk	w9, #0x5100, lsl #16
   1002c:      	cmp	w8, w9
   10030:      	b.le	0x10144 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7130>
   10034:      	mov	w9, #0x1f               // =31
   10038:      	movk	w9, #0x5300, lsl #16
   1003c:      	cmp	w8, w9
   10040:      	b.le	0x10200 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x71ec>
   10044:      	mov	w9, #0x40               // =64
   10048:      	movk	w9, #0x5300, lsl #16
   1004c:      	cmp	w8, w9
   10050:      	b.eq	0x10280 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x726c>
   10054:      	mov	w9, #0x30               // =48
   10058:      	movk	w9, #0x5300, lsl #16
   1005c:      	cmp	w8, w9
   10060:      	b.eq	0x10280 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x726c>
   10064:      	mov	w9, #0x20               // =32
   10068:      	movk	w9, #0x5300, lsl #16
   1006c:      	b	0x102b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72a4>
   10070:      	mov	w9, #0xd0af             // =53423
   10074:      	movk	w9, #0x4100, lsl #16
   10078:      	cmp	w8, w9
   1007c:      	b.gt	0x100c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x70b0>
   10080:      	mov	w9, #0xd06f             // =53359
   10084:      	movk	w9, #0x4100, lsl #16
   10088:      	cmp	w8, w9
   1008c:      	b.gt	0x1016c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7158>
   10090:      	mov	w9, #0xd04f             // =53327
   10094:      	movk	w9, #0x4100, lsl #16
   10098:      	cmp	w8, w9
   1009c:      	b.gt	0x1021c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7208>
   100a0:      	mov	w9, #0xd030             // =53296
   100a4:      	movk	w9, #0x4100, lsl #16
   100a8:      	cmp	w8, w9
   100ac:      	b.eq	0x1023c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7228>
   100b0:      	mov	w9, #0xd040             // =53312
   100b4:      	movk	w9, #0x4100, lsl #16
   100b8:      	cmp	w8, w9
   100bc:      	b.eq	0x102c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72b4>
   100c0:      	b	0x102d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72c4>
   100c4:      	mov	w9, #0xd43f             // =54335
   100c8:      	movk	w9, #0x4100, lsl #16
   100cc:      	cmp	w8, w9
   100d0:      	b.gt	0x10198 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7184>
   100d4:      	mov	w9, #0x2f50             // =12112
   100d8:      	movk	w9, #0xbeff, lsl #16
   100dc:      	add	w9, w8, w9
   100e0:      	cmp	w9, #0x30
   100e4:      	b.hi	0x10100 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x70ec>
   100e8:      	mov	w10, #0x1               // =1
   100ec:      	lsl	x9, x10, x9
   100f0:      	mov	x10, #0x1000100010001   // =281479271743489
   100f4:      	movk	x10, #0x0, lsl #16
   100f8:      	tst	x9, x10
   100fc:      	b.ne	0x102c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72ac>
   10100:      	mov	w9, #0xd410             // =54288
   10104:      	movk	w9, #0x4100, lsl #16
   10108:      	b	0x102b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72a4>
   1010c:      	mov	w9, #0x200f             // =8207
   10110:      	movk	w9, #0x5100, lsl #16
   10114:      	cmp	w8, w9
   10118:      	b.gt	0x101c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x71ac>
   1011c:      	mov	w9, #0xd3ff             // =54271
   10120:      	movk	w9, #0x4800, lsl #16
   10124:      	cmp	w8, w9
   10128:      	b.gt	0x10284 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7270>
   1012c:      	mov	w9, #0xd4d0             // =54480
   10130:      	movk	w9, #0x4100, lsl #16
   10134:      	cmp	w8, w9
   10138:      	b.eq	0x102c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72ac>
   1013c:      	mov	w9, #0xd4e0             // =54496
   10140:      	b	0x10274 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7260>
   10144:      	mov	w9, #0x802f             // =32815
   10148:      	movk	w9, #0x5100, lsl #16
   1014c:      	cmp	w8, w9
   10150:      	b.gt	0x101e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x71d4>
   10154:      	mov	w9, #0x8010             // =32784
   10158:      	movk	w9, #0x5100, lsl #16
   1015c:      	cmp	w8, w9
   10160:      	b.eq	0x102c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72b4>
   10164:      	mov	w9, #0x8020             // =32800
   10168:      	b	0x102b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72a0>
   1016c:      	mov	w9, #0xd08f             // =53391
   10170:      	movk	w9, #0x4100, lsl #16
   10174:      	cmp	w8, w9
   10178:      	b.gt	0x10244 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7230>
   1017c:      	mov	w9, #0xd070             // =53360
   10180:      	movk	w9, #0x4100, lsl #16
   10184:      	cmp	w8, w9
   10188:      	b.eq	0x102d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72bc>
   1018c:      	mov	w9, #0xd080             // =53376
   10190:      	movk	w9, #0x4100, lsl #16
   10194:      	b	0x102b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72a4>
   10198:      	mov	w9, #0xd46f             // =54383
   1019c:      	movk	w9, #0x4100, lsl #16
   101a0:      	cmp	w8, w9
   101a4:      	b.gt	0x10260 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x724c>
   101a8:      	mov	w9, #0xd440             // =54336
   101ac:      	movk	w9, #0x4100, lsl #16
   101b0:      	cmp	w8, w9
   101b4:      	b.eq	0x10280 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x726c>
   101b8:      	mov	w9, #0xd460             // =54368
   101bc:      	b	0x10230 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x721c>
   101c0:      	mov	w9, #0x210f             // =8463
   101c4:      	movk	w9, #0x5100, lsl #16
   101c8:      	cmp	w8, w9
   101cc:      	b.gt	0x102a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x728c>
   101d0:      	mov	w9, #0x2010             // =8208
   101d4:      	movk	w9, #0x5100, lsl #16
   101d8:      	cmp	w8, w9
   101dc:      	b.eq	0x102c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72b4>
   101e0:      	mov	w9, #0x2050             // =8272
   101e4:      	b	0x102b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72a0>
   101e8:      	mov	w9, #0x8030             // =32816
   101ec:      	movk	w9, #0x5100, lsl #16
   101f0:      	cmp	w8, w9
   101f4:      	b.eq	0x102c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72b4>
   101f8:      	mov	w9, #0x8040             // =32832
   101fc:      	b	0x102b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72a0>
   10200:      	mov	w9, #0x8050             // =32848
   10204:      	movk	w9, #0x5100, lsl #16
   10208:      	cmp	w8, w9
   1020c:      	b.eq	0x102c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72b4>
   10210:      	mov	w9, #0x10               // =16
   10214:      	movk	w9, #0x5300, lsl #16
   10218:      	b	0x102b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72a4>
   1021c:      	mov	w9, #0xd050             // =53328
   10220:      	movk	w9, #0x4100, lsl #16
   10224:      	cmp	w8, w9
   10228:      	b.eq	0x1023c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7228>
   1022c:      	mov	w9, #0xd060             // =53344
   10230:      	movk	w9, #0x4100, lsl #16
   10234:      	cmp	w8, w9
   10238:      	b.ne	0x102d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72c4>
   1023c:      	mov	w0, #0x2                // =2
   10240:      	ret
   10244:      	mov	w9, #0xd090             // =53392
   10248:      	movk	w9, #0x4100, lsl #16
   1024c:      	cmp	w8, w9
   10250:      	b.eq	0x102c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72ac>
   10254:      	mov	w9, #0xd0a0             // =53408
   10258:      	movk	w9, #0x4100, lsl #16
   1025c:      	b	0x102b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72a4>
   10260:      	mov	w9, #0xd470             // =54384
   10264:      	movk	w9, #0x4100, lsl #16
   10268:      	cmp	w8, w9
   1026c:      	b.eq	0x102c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72ac>
   10270:      	mov	w9, #0xd480             // =54400
   10274:      	movk	w9, #0x4100, lsl #16
   10278:      	cmp	w8, w9
   1027c:      	b.ne	0x102d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72c4>
   10280:      	ret
   10284:      	mov	w9, #0xd400             // =54272
   10288:      	movk	w9, #0x4800, lsl #16
   1028c:      	cmp	w8, w9
   10290:      	b.eq	0x102c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72ac>
   10294:      	mov	w9, #0x30               // =48
   10298:      	movk	w9, #0x4e00, lsl #16
   1029c:      	b	0x102b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72a4>
   102a0:      	mov	w9, #0x2110             // =8464
   102a4:      	movk	w9, #0x5100, lsl #16
   102a8:      	cmp	w8, w9
   102ac:      	b.eq	0x102c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72b4>
   102b0:      	mov	w9, #0x8000             // =32768
   102b4:      	movk	w9, #0x5100, lsl #16
   102b8:      	cmp	w8, w9
   102bc:      	b.ne	0x102d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x72c4>
   102c0:      	mov	w0, #0x5                // =5
   102c4:      	ret
   102c8:      	mov	w0, #0x1                // =1
   102cc:      	ret
   102d0:      	mov	w0, #0x4                // =4
   102d4:      	ret
   102d8:      	mov	w0, #0x3                // =3
   102dc:      	ret
   102e0:      	lsr	w8, w0, #24
   102e4:      	cmp	w8, #0x4d
   102e8:      	b.gt	0x10340 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x732c>
   102ec:      	cmp	w8, #0x42
   102f0:      	b.gt	0x10378 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7364>
   102f4:      	cmp	w8, #0x41
   102f8:      	b.eq	0x10428 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7414>
   102fc:      	cmp	w8, #0x42
   10300:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   10304:      	ubfx	w9, w0, #4, #12
   10308:      	mov	w8, #0x100              // =256
   1030c:      	mov	w10, #0xd               // =13
   10310:      	movk	w8, #0x80, lsl #16
   10314:      	str	w10, [x1]
   10318:      	cmp	w9, #0xf
   1031c:      	b.eq	0x105f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x75dc>
   10320:      	cmp	w9, #0x516
   10324:      	b.eq	0x105dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x75c8>
   10328:      	cmp	w9, #0x100
   1032c:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   10330:      	mov	w8, #0x101              // =257
   10334:      	movk	w8, #0xa0, lsl #16
   10338:      	str	w8, [x2]
   1033c:      	ret
   10340:      	cmp	w8, #0x50
   10344:      	b.gt	0x103b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x73a4>
   10348:      	cmp	w8, #0x4e
   1034c:      	b.eq	0x10474 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7460>
   10350:      	cmp	w8, #0x50
   10354:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   10358:      	mov	w8, #0xe                // =14
   1035c:      	tst	w0, #0xfff0
   10360:      	str	w8, [x1]
   10364:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   10368:      	mov	w8, #0x100              // =256
   1036c:      	movk	w8, #0xb0, lsl #16
   10370:      	str	w8, [x2]
   10374:      	ret
   10378:      	cmp	w8, #0x43
   1037c:      	b.eq	0x104a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7494>
   10380:      	cmp	w8, #0x48
   10384:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   10388:      	ubfx	w8, w0, #4, #12
   1038c:      	mov	w9, #0xf                // =15
   10390:      	str	w9, [x1]
   10394:      	cmp	w8, #0xd04
   10398:      	b.le	0x10578 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7564>
   1039c:      	cmp	w8, #0xd05
   103a0:      	b.eq	0x10648 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7634>
   103a4:      	cmp	w8, #0xd42
   103a8:      	b.eq	0x10588 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7574>
   103ac:      	cmp	w8, #0xd40
   103b0:      	b.eq	0x105fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x75e8>
   103b4:      	b	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   103b8:      	cmp	w8, #0x51
   103bc:      	b.eq	0x104d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x74bc>
   103c0:      	cmp	w8, #0x53
   103c4:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   103c8:      	and	w8, w0, #0xfffff0
   103cc:      	mov	w9, #0x2f               // =47
   103d0:      	mov	w10, #0x6               // =6
   103d4:      	and	w8, w8, #0xfff0ffff
   103d8:      	movk	w9, #0x10, lsl #16
   103dc:      	str	w10, [x1]
   103e0:      	cmp	w8, w9
   103e4:      	b.le	0x10598 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7584>
   103e8:      	mov	w9, #0x30               // =48
   103ec:      	movk	w9, #0x10, lsl #16
   103f0:      	cmp	w8, w9
   103f4:      	b.eq	0x1065c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7648>
   103f8:      	mov	w9, #0x40               // =64
   103fc:      	movk	w9, #0x10, lsl #16
   10400:      	cmp	w8, w9
   10404:      	b.eq	0x10670 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x765c>
   10408:      	mov	w9, #0x10               // =16
   1040c:      	movk	w9, #0x40, lsl #16
   10410:      	cmp	w8, w9
   10414:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   10418:      	mov	w8, #0x101              // =257
   1041c:      	movk	w8, #0x60, lsl #16
   10420:      	str	w8, [x2]
   10424:      	ret
   10428:      	ubfx	w8, w0, #4, #12
   1042c:      	mov	w9, #0x3                // =3
   10430:      	str	w9, [x1]
   10434:      	sub	w8, w8, #0xd01
   10438:      	cmp	w8, #0x86
   1043c:      	b.hi	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   10440:      	mov	w9, #0x376              // =886
   10444:      	nop
   10448:      	adr	x10, 0x4f90
   1044c:      	movk	w9, #0x30, lsl #16
   10450:      	adr	x11, 0x10464 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7450>
   10454:      	ldrh	w12, [x10, x8, lsl #1]
   10458:      	add	x11, x11, x12, lsl #2
   1045c:      	sub	w8, w9, #0x44
   10460:      	br	x11
   10464:      	mov	w8, #0x376              // =886
   10468:      	movk	w8, #0x30, lsl #16
   1046c:      	str	w8, [x2]
   10470:      	ret
   10474:      	ubfx	w9, w0, #4, #12
   10478:      	mov	w8, #0x100              // =256
   1047c:      	mov	w10, #0x7               // =7
   10480:      	movk	w8, #0x50, lsl #16
   10484:      	str	w10, [x1]
   10488:      	cbz	w9, 0x104c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x74b4>
   1048c:      	cmp	w9, #0x4
   10490:      	b.eq	0x106dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76c8>
   10494:      	cmp	w9, #0x3
   10498:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   1049c:      	add	w8, w8, #0x1
   104a0:      	str	w8, [x2]
   104a4:      	ret
   104a8:      	ubfx	w9, w0, #4, #12
   104ac:      	mov	w10, #0xc               // =12
   104b0:      	str	w10, [x1]
   104b4:      	sub	w8, w9, #0xa0
   104b8:      	cmp	w8, #0x4
   104bc:      	mov	w8, #0x100              // =256
   104c0:      	movk	w8, #0x80, lsl #16
   104c4:      	b.hs	0x105c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x75b4>
   104c8:      	str	w8, [x2]
   104cc:      	ret
   104d0:      	ubfx	w9, w0, #4, #12
   104d4:      	mov	w8, #0x102              // =258
   104d8:      	mov	w10, #0x4               // =4
   104dc:      	movk	w8, #0x40, lsl #16
   104e0:      	str	w10, [x1]
   104e4:      	cmp	w9, #0x800
   104e8:      	b.le	0x10528 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7514>
   104ec:      	cmp	w9, #0x803
   104f0:      	b.le	0x10614 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7600>
   104f4:      	cmp	w9, #0xbff
   104f8:      	b.gt	0x106cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76b8>
   104fc:      	cmp	w9, #0x804
   10500:      	b.eq	0x105fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x75e8>
   10504:      	cmp	w9, #0x805
   10508:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   1050c:      	mov	w9, #0x376              // =886
   10510:      	mov	w8, #0x3                // =3
   10514:      	movk	w9, #0x30, lsl #16
   10518:      	str	w8, [x1]
   1051c:      	sub	w8, w9, #0x21
   10520:      	str	w8, [x2]
   10524:      	ret
   10528:      	cmp	w9, #0x200
   1052c:      	b.le	0x106a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7690>
   10530:      	sub	w10, w9, #0x201
   10534:      	cmp	w10, #0x10
   10538:      	b.hi	0x10554 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7540>
   1053c:      	mov	w11, #0x1               // =1
   10540:      	lsl	w10, w11, w10
   10544:      	mov	w11, #0x11              // =17
   10548:      	movk	w11, #0x1, lsl #16
   1054c:      	tst	w10, w11
   10550:      	b.ne	0x104c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x74b4>
   10554:      	cmp	w9, #0x800
   10558:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   1055c:      	mov	w9, #0x376              // =886
   10560:      	mov	w8, #0x3                // =3
   10564:      	movk	w9, #0x30, lsl #16
   10568:      	str	w8, [x1]
   1056c:      	sub	w8, w9, #0x3
   10570:      	str	w8, [x2]
   10574:      	ret
   10578:      	cmp	w8, #0xd01
   1057c:      	b.eq	0x1067c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7668>
   10580:      	cmp	w8, #0xd02
   10584:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   10588:      	mov	w8, #0x101              // =257
   1058c:      	movk	w8, #0xc0, lsl #16
   10590:      	str	w8, [x2]
   10594:      	ret
   10598:      	mov	w9, #0x100010           // =1048592
   1059c:      	cmp	w8, w9
   105a0:      	b.eq	0x10690 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x767c>
   105a4:      	mov	w9, #0x20               // =32
   105a8:      	movk	w9, #0x10, lsl #16
   105ac:      	cmp	w8, w9
   105b0:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   105b4:      	mov	w8, #0x101              // =257
   105b8:      	movk	w8, #0x60, lsl #16
   105bc:      	add	w8, w8, #0x1
   105c0:      	str	w8, [x2]
   105c4:      	ret
   105c8:      	cmp	w9, #0xaf
   105cc:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   105d0:      	add	w8, w8, #0x100
   105d4:      	str	w8, [x2]
   105d8:      	ret
   105dc:      	mov	w9, #0xc                // =12
   105e0:      	add	w8, w8, #0x100
   105e4:      	str	w9, [x1]
   105e8:      	str	w8, [x2]
   105ec:      	ret
   105f0:      	orr	w8, w8, #0x200000
   105f4:      	str	w8, [x2]
   105f8:      	ret
   105fc:      	mov	w9, #0x3                // =3
   10600:      	mov	w8, #0x376              // =886
   10604:      	movk	w8, #0x30, lsl #16
   10608:      	str	w9, [x1]
   1060c:      	str	w8, [x2]
   10610:      	ret
   10614:      	cmp	w9, #0x801
   10618:      	b.eq	0x106f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76e4>
   1061c:      	cmp	w9, #0x802
   10620:      	b.eq	0x10714 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7700>
   10624:      	cmp	w9, #0x803
   10628:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   1062c:      	mov	w9, #0x376              // =886
   10630:      	mov	w8, #0x3                // =3
   10634:      	movk	w9, #0x30, lsl #16
   10638:      	str	w8, [x1]
   1063c:      	sub	w8, w9, #0x22
   10640:      	str	w8, [x2]
   10644:      	ret
   10648:      	mov	w8, #0x101              // =257
   1064c:      	movk	w8, #0xc0, lsl #16
   10650:      	add	w8, w8, #0x1
   10654:      	str	w8, [x2]
   10658:      	ret
   1065c:      	mov	w8, #0x101              // =257
   10660:      	movk	w8, #0x60, lsl #16
   10664:      	orr	w8, w8, #0x2
   10668:      	str	w8, [x2]
   1066c:      	ret
   10670:      	mov	w8, #0x101              // =257
   10674:      	movk	w8, #0x60, lsl #16
   10678:      	b	0x106c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76ac>
   1067c:      	mov	w8, #0x100              // =256
   10680:      	movk	w8, #0xb0, lsl #16
   10684:      	add	w8, w8, #0x100, lsl #12 // =0x100000
   10688:      	str	w8, [x2]
   1068c:      	ret
   10690:      	mov	w8, #0x100              // =256
   10694:      	movk	w8, #0x50, lsl #16
   10698:      	add	w8, w8, #0x100, lsl #12 // =0x100000
   1069c:      	str	w8, [x2]
   106a0:      	ret
   106a4:      	cmp	w9, #0x1
   106a8:      	b.eq	0x106c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76ac>
   106ac:      	cmp	w9, #0x2
   106b0:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   106b4:      	add	w8, w8, #0x4
   106b8:      	str	w8, [x2]
   106bc:      	ret
   106c0:      	add	w8, w8, #0x3
   106c4:      	str	w8, [x2]
   106c8:      	ret
   106cc:      	cmp	w9, #0xc00
   106d0:      	b.eq	0x106ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d8>
   106d4:      	cmp	w9, #0xc01
   106d8:      	b.ne	0x106e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x76d4>
   106dc:      	add	w8, w8, #0x2
   106e0:      	str	w8, [x2]
   106e4:      	ret
   106e8:      	ret
   106ec:      	add	w8, w8, #0x1
   106f0:      	str	w8, [x2]
   106f4:      	ret
   106f8:      	mov	w9, #0x376              // =886
   106fc:      	mov	w8, #0x3                // =3
   10700:      	movk	w9, #0x30, lsl #16
   10704:      	str	w8, [x1]
   10708:      	sub	w8, w9, #0x23
   1070c:      	str	w8, [x2]
   10710:      	ret
   10714:      	mov	w9, #0x376              // =886
   10718:      	mov	w8, #0x3                // =3
   1071c:      	movk	w9, #0x30, lsl #16
   10720:      	str	w8, [x1]
   10724:      	sub	w8, w9, #0x1
   10728:      	str	w8, [x2]
   1072c:      	ret
   10730:      	add	w8, w9, #0x18c
   10734:      	str	w8, [x2]
   10738:      	ret
   1073c:      	add	w8, w9, #0x1fc
   10740:      	str	w8, [x2]
   10744:      	ret
   10748:      	add	w8, w9, #0x8c
   1074c:      	str	w8, [x2]
   10750:      	ret
   10754:      	add	w8, w9, #0x1fd
   10758:      	str	w8, [x2]
   1075c:      	ret
   10760:      	add	w8, w9, #0x8e
   10764:      	str	w8, [x2]
   10768:      	ret
   1076c:      	add	w8, w9, #0x8a
   10770:      	str	w8, [x2]
   10774:      	ret
   10778:      	add	w8, w9, #0x1fe
   1077c:      	str	w8, [x2]
   10780:      	ret
   10784:      	add	w8, w9, #0x18d
   10788:      	str	w8, [x2]
   1078c:      	ret
   10790:      	add	w8, w9, #0x8d
   10794:      	str	w8, [x2]
   10798:      	ret
   1079c:      	sub	w8, w9, #0x41
   107a0:      	str	w8, [x2]
   107a4:      	ret
   107a8:      	sub	w8, w9, #0x1f
   107ac:      	str	w8, [x2]
   107b0:      	ret
   107b4:      	add	w8, w9, #0x1
   107b8:      	str	w8, [x2]
   107bc:      	ret
   107c0:      	add	w8, w9, #0x1dc
   107c4:      	str	w8, [x2]
   107c8:      	ret
   107cc:      	sub	w8, w9, #0x23
   107d0:      	str	w8, [x2]
   107d4:      	ret
   107d8:      	sub	w8, w9, #0x4
   107dc:      	str	w8, [x2]
   107e0:      	ret
   107e4:      	sub	w8, w9, #0x3
   107e8:      	str	w8, [x2]
   107ec:      	ret
   107f0:      	add	w8, w9, #0x2
   107f4:      	str	w8, [x2]
   107f8:      	ret
   107fc:      	add	w8, w9, #0x18b
   10800:      	str	w8, [x2]
   10804:      	ret
   10808:      	sub	w8, w9, #0x22
   1080c:      	sub	w9, w9, #0x21
   10810:      	tst	w0, #0xf00000
   10814:      	csel	w8, w8, w9, eq
   10818:      	str	w8, [x2]
   1081c:      	ret
   10820:      	sub	w8, w9, #0x11
   10824:      	str	w8, [x2]
   10828:      	ret
   1082c:      	sub	w8, w9, #0x1
   10830:      	str	w8, [x2]
   10834:      	ret
   10838:      	add	w8, w9, #0x1fb
   1083c:      	str	w8, [x2]
   10840:      	ret
   10844:      	add	w8, w9, #0x1db
   10848:      	str	w8, [x2]
   1084c:      	ret
   10850:      	add	w8, w9, #0x8b
   10854:      	str	w8, [x2]
   10858:      	ret
   1085c:      	add	w8, w9, #0x18f
   10860:      	str	w8, [x2]
   10864:      	ret
   10868:      	add	w8, w9, #0x18e
   1086c:      	str	w8, [x2]
   10870:      	ret
   10874:      	stp	x29, x30, [sp, #-0x40]!
   10878:      	str	x23, [sp, #0x10]
   1087c:      	stp	x22, x21, [sp, #0x20]
   10880:      	stp	x20, x19, [sp, #0x30]
   10884:      	mov	x29, sp
   10888:      	mov	x20, x1
   1088c:      	nop
   10890:      	adr	x1, 0x430b
   10894:      	mov	x19, x3
   10898:      	mov	x21, x2
   1089c:      	mov	x22, x0
   108a0:      	bl	0x1d8b0 <strcmp@plt>
   108a4:      	cbz	w0, 0x108d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x78c4>
   108a8:      	adrp	x1, 0x3000
   108ac:      	add	x1, x1, #0x8bd
   108b0:      	mov	x0, x22
   108b4:      	bl	0x1d8b0 <strcmp@plt>
   108b8:      	cbz	w0, 0x108e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x78cc>
   108bc:      	adrp	x1, 0x4000
   108c0:      	add	x1, x1, #0x78a
   108c4:      	mov	x0, x22
   108c8:      	bl	0x1d8b0 <strcmp@plt>
   108cc:      	cbz	w0, 0x108e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x78d4>
   108d0:      	mov	w8, #0x6                // =6
   108d4:      	b	0x1091c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7908>
   108d8:      	mov	w8, #0x3                // =3
   108dc:      	b	0x1091c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7908>
   108e0:      	mov	w8, #0x4                // =4
   108e4:      	b	0x1091c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7908>
   108e8:      	adrp	x1, 0x4000
   108ec:      	add	x1, x1, #0x442
   108f0:      	mov	x0, x22
   108f4:      	bl	0x1d8b0 <strcmp@plt>
   108f8:      	cbz	w0, 0x10904 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x78f0>
   108fc:      	mov	w8, #0xd                // =13
   10900:      	b	0x1091c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7908>
   10904:      	adrp	x1, 0x3000
   10908:      	add	x1, x1, #0x2c0
   1090c:      	mov	x0, x22
   10910:      	bl	0x1d8b0 <strcmp@plt>
   10914:      	cbz	w0, 0x10920 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x790c>
   10918:      	mov	w8, #0xf                // =15
   1091c:      	str	w8, [x21]
   10920:      	adrp	x1, 0x3000
   10924:      	add	x1, x1, #0x5d3
   10928:      	mov	x0, x20
   1092c:      	mov	w2, #0x7                // =7
   10930:      	str	wzr, [x19]
   10934:      	bl	0x1d8c0 <strncmp@plt>
   10938:      	cbz	w0, 0x10b20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7b0c>
   1093c:      	adrp	x1, 0x4000
   10940:      	add	x1, x1, #0x44b
   10944:      	mov	x0, x20
   10948:      	mov	w2, #0x9                // =9
   1094c:      	bl	0x1d8c0 <strncmp@plt>
   10950:      	cbz	w0, 0x10d9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7d88>
   10954:      	nop
   10958:      	adr	x1, 0x430b
   1095c:      	mov	x0, x20
   10960:      	mov	w2, #0x3                // =3
   10964:      	bl	0x1d8c0 <strncmp@plt>
   10968:      	cbz	w0, 0x10e10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7dfc>
   1096c:      	mov	w21, #0x100             // =256
   10970:      	adrp	x1, 0x4000
   10974:      	add	x1, x1, #0x91
   10978:      	mov	x0, x20
   1097c:      	mov	w2, #0x7                // =7
   10980:      	movk	w21, #0x80, lsl #16
   10984:      	bl	0x1d8c0 <strncmp@plt>
   10988:      	cbz	w0, 0x10e64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7e50>
   1098c:      	adrp	x1, 0x4000
   10990:      	add	x1, x1, #0xbae
   10994:      	mov	x0, x20
   10998:      	bl	0x1d8b0 <strcmp@plt>
   1099c:      	cbz	w0, 0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   109a0:      	adrp	x1, 0x3000
   109a4:      	add	x1, x1, #0xdd8
   109a8:      	mov	x0, x20
   109ac:      	bl	0x1d8b0 <strcmp@plt>
   109b0:      	cbz	w0, 0x10eb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7ea4>
   109b4:      	mov	w22, #0x100             // =256
   109b8:      	adrp	x1, 0x3000
   109bc:      	add	x1, x1, #0x44b
   109c0:      	mov	x0, x20
   109c4:      	movk	w22, #0xb0, lsl #16
   109c8:      	bl	0x1d8b0 <strcmp@plt>
   109cc:      	cbz	w0, 0x11048 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8034>
   109d0:      	mov	w22, #0x101             // =257
   109d4:      	adrp	x1, 0x3000
   109d8:      	add	x1, x1, #0x5e4
   109dc:      	mov	x0, x20
   109e0:      	movk	w22, #0xc0, lsl #16
   109e4:      	bl	0x1d8b0 <strcmp@plt>
   109e8:      	cbz	w0, 0x10ee8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7ed4>
   109ec:      	adrp	x1, 0x3000
   109f0:      	add	x1, x1, #0xecc
   109f4:      	mov	x0, x20
   109f8:      	bl	0x1d8b0 <strcmp@plt>
   109fc:      	cbz	w0, 0x10efc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7ee8>
   10a00:      	adrp	x1, 0x3000
   10a04:      	add	x1, x1, #0x798
   10a08:      	mov	x0, x20
   10a0c:      	bl	0x1d8b0 <strcmp@plt>
   10a10:      	cbz	w0, 0x10f0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7ef8>
   10a14:      	mov	w22, #0x100             // =256
   10a18:      	adrp	x1, 0x4000
   10a1c:      	add	x1, x1, #0xd41
   10a20:      	mov	x0, x20
   10a24:      	movk	w22, #0x50, lsl #16
   10a28:      	bl	0x1d8b0 <strcmp@plt>
   10a2c:      	cbz	w0, 0x10f20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f0c>
   10a30:      	adrp	x1, 0x4000
   10a34:      	add	x1, x1, #0x312
   10a38:      	mov	x0, x20
   10a3c:      	bl	0x1d8b0 <strcmp@plt>
   10a40:      	cbz	w0, 0x10efc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7ee8>
   10a44:      	adrp	x1, 0x2000
   10a48:      	add	x1, x1, #0xea6
   10a4c:      	mov	x0, x20
   10a50:      	bl	0x1d8b0 <strcmp@plt>
   10a54:      	cbz	w0, 0x10f3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f28>
   10a58:      	adrp	x1, 0x3000
   10a5c:      	add	x1, x1, #0x79f
   10a60:      	mov	x0, x20
   10a64:      	bl	0x1d8b0 <strcmp@plt>
   10a68:      	cbz	w0, 0x10f4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f38>
   10a6c:      	adrp	x1, 0x3000
   10a70:      	add	x1, x1, #0xb6b
   10a74:      	mov	x0, x20
   10a78:      	bl	0x1d8b0 <strcmp@plt>
   10a7c:      	cbz	w0, 0x10f60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f4c>
   10a80:      	mov	w23, #0x101             // =257
   10a84:      	adrp	x1, 0x4000
   10a88:      	add	x1, x1, #0x9d3
   10a8c:      	mov	x0, x20
   10a90:      	movk	w23, #0x40, lsl #16
   10a94:      	bl	0x1d8b0 <strcmp@plt>
   10a98:      	cbz	w0, 0x10f78 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f64>
   10a9c:      	adrp	x1, 0x4000
   10aa0:      	add	x1, x1, #0x31a
   10aa4:      	mov	x0, x20
   10aa8:      	bl	0x1d8b0 <strcmp@plt>
   10aac:      	cbz	w0, 0x10f8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f78>
   10ab0:      	adrp	x1, 0x4000
   10ab4:      	add	x1, x1, #0x31f
   10ab8:      	mov	x0, x20
   10abc:      	bl	0x1d8b0 <strcmp@plt>
   10ac0:      	cbz	w0, 0x10f9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f88>
   10ac4:      	adrp	x1, 0x3000
   10ac8:      	add	x1, x1, #0xc84
   10acc:      	mov	x0, x20
   10ad0:      	bl	0x1d8b0 <strcmp@plt>
   10ad4:      	cbz	w0, 0x10fac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f98>
   10ad8:      	adrp	x1, 0x3000
   10adc:      	add	x1, x1, #0x458
   10ae0:      	mov	x0, x20
   10ae4:      	bl	0x1d8b0 <strcmp@plt>
   10ae8:      	cbz	w0, 0x10fbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7fa8>
   10aec:      	adrp	x1, 0x2000
   10af0:      	add	x1, x1, #0xb94
   10af4:      	mov	x0, x20
   10af8:      	mov	w2, #0x8                // =8
   10afc:      	bl	0x1d8c0 <strncmp@plt>
   10b00:      	cbz	w0, 0x10fcc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7fb8>
   10b04:      	adrp	x1, 0x3000
   10b08:      	add	x1, x1, #0x5f1
   10b0c:      	mov	x0, x20
   10b10:      	bl	0x1d8b0 <strcmp@plt>
   10b14:      	cbnz	w0, 0x11050 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x803c>
   10b18:      	add	w21, w21, #0x100, lsl #12 // =0x100000
   10b1c:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10b20:      	mov	w21, #0x100             // =256
   10b24:      	adrp	x1, 0x2000
   10b28:      	add	x1, x1, #0xc5b
   10b2c:      	add	x0, x20, #0x7
   10b30:      	movk	w21, #0x30, lsl #16
   10b34:      	bl	0x1d8b0 <strcmp@plt>
   10b38:      	cbz	w0, 0x10e5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7e48>
   10b3c:      	adrp	x1, 0x3000
   10b40:      	add	x1, x1, #0x447
   10b44:      	add	x0, x20, #0x7
   10b48:      	bl	0x1d8b0 <strcmp@plt>
   10b4c:      	cbz	w0, 0x10e98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7e84>
   10b50:      	adrp	x1, 0x2000
   10b54:      	add	x1, x1, #0xea3
   10b58:      	add	x0, x20, #0x7
   10b5c:      	bl	0x1d8b0 <strcmp@plt>
   10b60:      	cbz	w0, 0x10ea8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7e94>
   10b64:      	adrp	x1, 0x4000
   10b68:      	add	x1, x1, #0x86
   10b6c:      	add	x0, x20, #0x7
   10b70:      	bl	0x1d8b0 <strcmp@plt>
   10b74:      	cbz	w0, 0x10ec0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7eac>
   10b78:      	adrp	x1, 0x3000
   10b7c:      	add	x1, x1, #0x6da
   10b80:      	add	x0, x20, #0x7
   10b84:      	bl	0x1d8b0 <strcmp@plt>
   10b88:      	cbz	w0, 0x10ed8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7ec4>
   10b8c:      	adrp	x1, 0x4000
   10b90:      	add	x1, x1, #0xd33
   10b94:      	add	x0, x20, #0x7
   10b98:      	bl	0x1d8b0 <strcmp@plt>
   10b9c:      	cbz	w0, 0x10ef4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7ee0>
   10ba0:      	adrp	x1, 0x4000
   10ba4:      	add	x1, x1, #0x1bd
   10ba8:      	add	x0, x20, #0x7
   10bac:      	bl	0x1d8b0 <strcmp@plt>
   10bb0:      	cbz	w0, 0x10f04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7ef0>
   10bb4:      	adrp	x1, 0x3000
   10bb8:      	add	x1, x1, #0xec4
   10bbc:      	add	x0, x20, #0x7
   10bc0:      	bl	0x1d8b0 <strcmp@plt>
   10bc4:      	cbz	w0, 0x10f18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f04>
   10bc8:      	adrp	x1, 0x2000
   10bcc:      	add	x1, x1, #0xdca
   10bd0:      	add	x0, x20, #0x7
   10bd4:      	bl	0x1d8b0 <strcmp@plt>
   10bd8:      	cbz	w0, 0x10f2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f18>
   10bdc:      	adrp	x1, 0x4000
   10be0:      	add	x1, x1, #0x89
   10be4:      	add	x0, x20, #0x7
   10be8:      	bl	0x1d8b0 <strcmp@plt>
   10bec:      	cbz	w0, 0x10f34 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f20>
   10bf0:      	adrp	x1, 0x4000
   10bf4:      	add	x1, x1, #0x8d
   10bf8:      	add	x0, x20, #0x7
   10bfc:      	bl	0x1d8b0 <strcmp@plt>
   10c00:      	cbz	w0, 0x10f44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f30>
   10c04:      	adrp	x1, 0x4000
   10c08:      	add	x1, x1, #0x1c1
   10c0c:      	add	x0, x20, #0x7
   10c10:      	bl	0x1d8b0 <strcmp@plt>
   10c14:      	cbz	w0, 0x10f58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f44>
   10c18:      	adrp	x1, 0x3000
   10c1c:      	add	x1, x1, #0x5db
   10c20:      	add	x0, x20, #0x7
   10c24:      	bl	0x1d8b0 <strcmp@plt>
   10c28:      	cbz	w0, 0x10f70 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f5c>
   10c2c:      	adrp	x1, 0x3000
   10c30:      	add	x1, x1, #0xdd4
   10c34:      	add	x0, x20, #0x7
   10c38:      	bl	0x1d8b0 <strcmp@plt>
   10c3c:      	cbz	w0, 0x10f84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f70>
   10c40:      	adrp	x1, 0x4000
   10c44:      	add	x1, x1, #0x9cf
   10c48:      	add	x0, x20, #0x7
   10c4c:      	bl	0x1d8b0 <strcmp@plt>
   10c50:      	cbz	w0, 0x10f94 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f80>
   10c54:      	adrp	x1, 0x4000
   10c58:      	add	x1, x1, #0x792
   10c5c:      	add	x0, x20, #0x7
   10c60:      	bl	0x1d8b0 <strcmp@plt>
   10c64:      	cbz	w0, 0x10fa4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7f90>
   10c68:      	adrp	x1, 0x4000
   10c6c:      	add	x1, x1, #0xad0
   10c70:      	add	x0, x20, #0x7
   10c74:      	bl	0x1d8b0 <strcmp@plt>
   10c78:      	cbz	w0, 0x10fb4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7fa0>
   10c7c:      	adrp	x1, 0x3000
   10c80:      	add	x1, x1, #0xec8
   10c84:      	add	x0, x20, #0x7
   10c88:      	bl	0x1d8b0 <strcmp@plt>
   10c8c:      	cbz	w0, 0x10fc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7fb0>
   10c90:      	adrp	x1, 0x2000
   10c94:      	add	x1, x1, #0xdce
   10c98:      	add	x0, x20, #0x7
   10c9c:      	bl	0x1d8b0 <strcmp@plt>
   10ca0:      	cbz	w0, 0x11064 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8050>
   10ca4:      	adrp	x1, 0x3000
   10ca8:      	add	x1, x1, #0x791
   10cac:      	add	x0, x20, #0x7
   10cb0:      	bl	0x1d8b0 <strcmp@plt>
   10cb4:      	cbz	w0, 0x1106c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8058>
   10cb8:      	adrp	x1, 0x3000
   10cbc:      	add	x1, x1, #0x5df
   10cc0:      	add	x0, x20, #0x7
   10cc4:      	bl	0x1d8b0 <strcmp@plt>
   10cc8:      	cbz	w0, 0x11074 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8060>
   10ccc:      	adrp	x1, 0x4000
   10cd0:      	add	x1, x1, #0xad4
   10cd4:      	add	x0, x20, #0x7
   10cd8:      	bl	0x1d8b0 <strcmp@plt>
   10cdc:      	cbz	w0, 0x1107c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8068>
   10ce0:      	adrp	x1, 0x4000
   10ce4:      	add	x1, x1, #0x8e2
   10ce8:      	add	x0, x20, #0x7
   10cec:      	bl	0x1d8b0 <strcmp@plt>
   10cf0:      	cbz	w0, 0x11084 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8070>
   10cf4:      	adrp	x1, 0x4000
   10cf8:      	add	x1, x1, #0xd37
   10cfc:      	add	x0, x20, #0x7
   10d00:      	bl	0x1d8b0 <strcmp@plt>
   10d04:      	cbz	w0, 0x1108c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8078>
   10d08:      	adrp	x1, 0x4000
   10d0c:      	add	x1, x1, #0xd3c
   10d10:      	add	x0, x20, #0x7
   10d14:      	bl	0x1d8b0 <strcmp@plt>
   10d18:      	cbz	w0, 0x11094 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8080>
   10d1c:      	adrp	x1, 0x3000
   10d20:      	add	x1, x1, #0x6dd
   10d24:      	add	x0, x20, #0x7
   10d28:      	bl	0x1d8b0 <strcmp@plt>
   10d2c:      	cbz	w0, 0x1109c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8088>
   10d30:      	adrp	x1, 0x2000
   10d34:      	add	x1, x1, #0xdd2
   10d38:      	add	x0, x20, #0x7
   10d3c:      	bl	0x1d8b0 <strcmp@plt>
   10d40:      	cbz	w0, 0x110a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8090>
   10d44:      	adrp	x1, 0x4000
   10d48:      	add	x1, x1, #0x30f
   10d4c:      	add	x0, x20, #0x7
   10d50:      	bl	0x1d8b0 <strcmp@plt>
   10d54:      	cbz	w0, 0x110ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8098>
   10d58:      	adrp	x1, 0x3000
   10d5c:      	add	x1, x1, #0x169
   10d60:      	add	x0, x20, #0x7
   10d64:      	bl	0x1d8b0 <strcmp@plt>
   10d68:      	cbz	w0, 0x110b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x80a0>
   10d6c:      	adrp	x1, 0x4000
   10d70:      	add	x1, x1, #0xad9
   10d74:      	add	x0, x20, #0x7
   10d78:      	bl	0x1d8b0 <strcmp@plt>
   10d7c:      	cbz	w0, 0x110bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x80a8>
   10d80:      	adrp	x1, 0x4000
   10d84:      	add	x1, x1, #0x796
   10d88:      	add	x0, x20, #0x7
   10d8c:      	bl	0x1d8b0 <strcmp@plt>
   10d90:      	cbnz	w0, 0x11050 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x803c>
   10d94:      	add	w21, w21, #0x405
   10d98:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10d9c:      	mov	w21, #0x100             // =256
   10da0:      	adrp	x1, 0x4000
   10da4:      	add	x1, x1, #0x79b
   10da8:      	add	x0, x20, #0x9
   10dac:      	movk	w21, #0x30, lsl #16
   10db0:      	bl	0x1d8b0 <strcmp@plt>
   10db4:      	cbz	w0, 0x10ea0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7e8c>
   10db8:      	adrp	x1, 0x4000
   10dbc:      	add	x1, x1, #0x651
   10dc0:      	add	x0, x20, #0x9
   10dc4:      	bl	0x1d8b0 <strcmp@plt>
   10dc8:      	cbz	w0, 0x10eb0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7e9c>
   10dcc:      	adrp	x1, 0x3000
   10dd0:      	add	x1, x1, #0x795
   10dd4:      	add	x0, x20, #0x9
   10dd8:      	bl	0x1d8b0 <strcmp@plt>
   10ddc:      	cbz	w0, 0x10ec8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7eb4>
   10de0:      	adrp	x1, 0x3000
   10de4:      	add	x1, x1, #0x31
   10de8:      	add	x0, x20, #0x9
   10dec:      	bl	0x1d8b0 <strcmp@plt>
   10df0:      	cbz	w0, 0x10ee0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7ecc>
   10df4:      	adrp	x1, 0x3000
   10df8:      	add	x1, x1, #0x16c
   10dfc:      	add	x0, x20, #0x9
   10e00:      	bl	0x1d8b0 <strcmp@plt>
   10e04:      	cbnz	w0, 0x11050 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x803c>
   10e08:      	add	w21, w21, #0x301
   10e0c:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10e10:      	mov	w21, #0x100             // =256
   10e14:      	adrp	x1, 0x4000
   10e18:      	add	x1, x1, #0x455
   10e1c:      	add	x0, x20, #0x3
   10e20:      	movk	w21, #0x30, lsl #16
   10e24:      	bl	0x1d8b0 <strcmp@plt>
   10e28:      	cbz	w0, 0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10e2c:      	adrp	x1, 0x3000
   10e30:      	add	x1, x1, #0x8c2
   10e34:      	add	x0, x20, #0x3
   10e38:      	bl	0x1d8b0 <strcmp@plt>
   10e3c:      	cbz	w0, 0x11040 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x802c>
   10e40:      	adrp	x1, 0x3000
   10e44:      	add	x1, x1, #0xb68
   10e48:      	add	x0, x20, #0x3
   10e4c:      	bl	0x1d8b0 <strcmp@plt>
   10e50:      	cbnz	w0, 0x11050 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x803c>
   10e54:      	add	w21, w21, #0x2
   10e58:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10e5c:      	add	w21, w21, #0x105
   10e60:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10e64:      	adrp	x1, 0x4000
   10e68:      	add	x1, x1, #0xbaa
   10e6c:      	add	x0, x20, #0x7
   10e70:      	bl	0x1d8b0 <strcmp@plt>
   10e74:      	cbz	w0, 0x10ed0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7ebc>
   10e78:      	adrp	x1, 0x2000
   10e7c:      	add	x1, x1, #0xae7
   10e80:      	add	x0, x20, #0x7
   10e84:      	bl	0x1d8b0 <strcmp@plt>
   10e88:      	cbnz	w0, 0x11050 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x803c>
   10e8c:      	mov	w21, #0x101             // =257
   10e90:      	movk	w21, #0xa0, lsl #16
   10e94:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10e98:      	add	w21, w21, #0x253
   10e9c:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10ea0:      	add	w21, w21, #0x300
   10ea4:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10ea8:      	add	w21, w21, #0x107
   10eac:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10eb0:      	add	w21, w21, #0x303
   10eb4:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10eb8:      	add	w21, w21, #0x100
   10ebc:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10ec0:      	add	w21, w21, #0x108
   10ec4:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10ec8:      	add	w21, w21, #0x302
   10ecc:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10ed0:      	add	w21, w21, #0x200, lsl #12 // =0x200000
   10ed4:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10ed8:      	add	w21, w21, #0x109
   10edc:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10ee0:      	add	w21, w21, #0x304
   10ee4:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10ee8:      	mov	w21, #0x101             // =257
   10eec:      	movk	w21, #0xc0, lsl #16
   10ef0:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10ef4:      	add	w21, w21, #0x112
   10ef8:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10efc:      	add	w21, w22, #0x1
   10f00:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f04:      	add	w21, w21, #0x115
   10f08:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f0c:      	mov	w21, #0x600             // =1536
   10f10:      	movk	w21, #0x10, lsl #16
   10f14:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f18:      	add	w21, w21, #0x117
   10f1c:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f20:      	mov	w21, #0x100             // =256
   10f24:      	movk	w21, #0x50, lsl #16
   10f28:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f2c:      	add	w21, w21, #0x232
   10f30:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f34:      	add	w21, w21, #0x235
   10f38:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f3c:      	add	w21, w22, #0x2
   10f40:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f44:      	add	w21, w21, #0x255
   10f48:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f4c:      	mov	w21, #0x100             // =256
   10f50:      	movk	w21, #0xb0, lsl #16
   10f54:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f58:      	add	w21, w21, #0x254
   10f5c:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f60:      	mov	w8, #0x100              // =256
   10f64:      	movk	w8, #0x30, lsl #16
   10f68:      	add	w21, w8, #0x100, lsl #12 // =0x100000
   10f6c:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f70:      	add	w21, w21, #0x257
   10f74:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f78:      	mov	w21, #0x101             // =257
   10f7c:      	movk	w21, #0x40, lsl #16
   10f80:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f84:      	add	w21, w21, #0x265
   10f88:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f8c:      	add	w21, w23, #0x1
   10f90:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f94:      	add	w21, w21, #0x272
   10f98:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10f9c:      	add	w21, w23, #0x4
   10fa0:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10fa4:      	add	w21, w21, #0x273
   10fa8:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10fac:      	add	w21, w23, #0x2
   10fb0:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10fb4:      	add	w21, w21, #0x275
   10fb8:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10fbc:      	add	w21, w23, #0x3
   10fc0:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10fc4:      	add	w21, w21, #0x276
   10fc8:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10fcc:      	adrp	x1, 0x3000
   10fd0:      	add	x1, x1, #0xc8b
   10fd4:      	add	x0, x20, #0x8
   10fd8:      	bl	0x1d8b0 <strcmp@plt>
   10fdc:      	cbz	w0, 0x11048 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8034>
   10fe0:      	mov	w21, #0x101             // =257
   10fe4:      	adrp	x1, 0x2000
   10fe8:      	add	x1, x1, #0xead
   10fec:      	add	x0, x20, #0x8
   10ff0:      	movk	w21, #0x60, lsl #16
   10ff4:      	bl	0x1d8b0 <strcmp@plt>
   10ff8:      	cbz	w0, 0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   10ffc:      	adrp	x1, 0x3000
   11000:      	add	x1, x1, #0xa7c
   11004:      	add	x0, x20, #0x8
   11008:      	bl	0x1d8b0 <strcmp@plt>
   1100c:      	cbz	w0, 0x11040 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x802c>
   11010:      	adrp	x1, 0x3000
   11014:      	add	x1, x1, #0xa7e
   11018:      	add	x0, x20, #0x8
   1101c:      	bl	0x1d8b0 <strcmp@plt>
   11020:      	cbz	w0, 0x10e54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x7e40>
   11024:      	adrp	x1, 0x2000
   11028:      	add	x1, x1, #0xaeb
   1102c:      	add	x0, x20, #0x8
   11030:      	bl	0x1d8b0 <strcmp@plt>
   11034:      	cbnz	w0, 0x11050 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x803c>
   11038:      	add	w21, w21, #0x3
   1103c:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   11040:      	add	w21, w21, #0x1
   11044:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   11048:      	add	w21, w22, #0x100, lsl #12 // =0x100000
   1104c:      	str	w21, [x19]
   11050:      	ldp	x20, x19, [sp, #0x30]
   11054:      	ldr	x23, [sp, #0x10]
   11058:      	ldp	x22, x21, [sp, #0x20]
   1105c:      	ldp	x29, x30, [sp], #0x40
   11060:      	ret
   11064:      	add	w21, w21, #0x277
   11068:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   1106c:      	add	w21, w21, #0x278
   11070:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   11074:      	add	w21, w21, #0x451
   11078:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   1107c:      	add	w21, w21, #0x471
   11080:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   11084:      	add	w21, w21, #0x472
   11088:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   1108c:      	add	w21, w21, #0x473
   11090:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   11094:      	add	w21, w21, #0x474
   11098:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   1109c:      	add	w21, w21, #0x452
   110a0:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   110a4:      	add	w21, w21, #0x401
   110a8:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   110ac:      	add	w21, w21, #0x402
   110b0:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   110b4:      	add	w21, w21, #0x403
   110b8:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   110bc:      	add	w21, w21, #0x404
   110c0:      	b	0x1104c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8038>
   110c4:      	mov	w10, #0x376             // =886
   110c8:      	ldp	x9, x8, [sp]
   110cc:      	movk	w10, #0x30, lsl #16
   110d0:      	cmp	w0, w10
   110d4:      	b.le	0x11170 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x815c>
   110d8:      	mov	w10, #0xff              // =255
   110dc:      	movk	w10, #0x50, lsl #16
   110e0:      	cmp	w0, w10
   110e4:      	b.gt	0x11230 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x821c>
   110e8:      	sub	w10, w0, #0x300, lsl #12 // =0x300000
   110ec:      	sub	w10, w10, #0x400
   110f0:      	cmp	w10, #0x4
   110f4:      	b.hi	0x11378 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8364>
   110f8:      	cmp	w10, #0x1
   110fc:      	b.eq	0x11378 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8364>
   11100:      	adrp	x10, 0x5000
   11104:      	adrp	x11, 0x5000
   11108:      	adrp	x12, 0x4000
   1110c:      	ldr	q0, [x10, #0x1d0]
   11110:      	ldr	q1, [x11, #0xf0]
   11114:      	adrp	x11, 0x5000
   11118:      	mov	w10, #0x404             // =1028
   1111c:      	str	wzr, [x9, #0x1c]
   11120:      	mov	w13, #0x40              // =64
   11124:      	stp	q0, q1, [x6]
   11128:      	movk	w10, #0x30, lsl #16
   1112c:      	mov	w16, #0x40              // =64
   11130:      	stp	q0, q1, [x7]
   11134:      	ldr	q0, [x11, #0xb0]
   11138:      	cmp	w0, w10
   1113c:      	mov	w10, #0x40000           // =262144
   11140:      	mov	w11, #0x100000          // =1048576
   11144:      	stur	q0, [x9, #0x4]
   11148:      	ldr	d0, [x12, #0xf38]
   1114c:      	csel	w10, w11, w10, eq
   11150:      	adrp	x11, 0x5000
   11154:      	str	w10, [x9]
   11158:      	mov	w12, #0x4               // =4
   1115c:      	stur	d0, [x9, #0x14]
   11160:      	ldr	q0, [x11, #0xc0]
   11164:      	mov	w11, #0x10000           // =65536
   11168:      	stp	q0, q1, [x8]
   1116c:      	b	0x1182c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8818>
   11170:      	mov	w10, #0x364             // =868
   11174:      	movk	w10, #0x30, lsl #16
   11178:      	cmp	w0, w10
   1117c:      	b.gt	0x112a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8290>
   11180:      	mov	w10, #0x353             // =851
   11184:      	movk	w10, #0x30, lsl #16
   11188:      	cmp	w0, w10
   1118c:      	b.le	0x11410 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x83fc>
   11190:      	sub	w10, w0, #0x300, lsl #12 // =0x300000
   11194:      	sub	w10, w10, #0x354
   11198:      	cmp	w10, #0x2
   1119c:      	b.hs	0x115bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x85a8>
   111a0:      	mov	w11, #0x8010            // =32784
   111a4:      	and	w10, w2, #0xfffffff0
   111a8:      	movk	w11, #0x5100, lsl #16
   111ac:      	and	w10, w10, #0xff00ffff
   111b0:      	orr	w11, w11, #0x20
   111b4:      	cmp	w10, w11
   111b8:      	b.ne	0x1162c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8618>
   111bc:      	adrp	x10, 0x5000
   111c0:      	adrp	x11, 0x5000
   111c4:      	adrp	x12, 0x5000
   111c8:      	ldr	q0, [x10, #0x160]
   111cc:      	ldr	q1, [x11, #0xf0]
   111d0:      	ldr	q2, [x12, #0x1c0]
   111d4:      	ldp	w11, w10, [x3, #0x4]
   111d8:      	adrp	x12, 0x5000
   111dc:      	stp	q0, q1, [x6]
   111e0:      	mov	w13, #0x40              // =64
   111e4:      	stp	q0, q1, [x7]
   111e8:      	ldr	q0, [x12, #0x110]
   111ec:      	mov	w12, #0x4               // =4
   111f0:      	cmp	w10, #0x34d
   111f4:      	mov	w10, #0x100000          // =1048576
   111f8:      	stp	q2, q1, [x9]
   111fc:      	ccmp	w11, #0x4, #0x0, eq
   11200:      	mov	w11, #0x200000          // =2097152
   11204:      	stur	q0, [x8, #0x4]
   11208:      	csel	w10, w11, w10, eq
   1120c:      	mov	w11, #0x8000            // =32768
   11210:      	str	xzr, [x8, #0x18]
   11214:      	str	w10, [x8]
   11218:      	mov	w10, #0x20000           // =131072
   1121c:      	mov	w16, #0x40              // =64
   11220:      	str	wzr, [x8, #0x14]
   11224:      	mov	w14, #0x4               // =4
   11228:      	mov	w15, #0x8000            // =32768
   1122c:      	b	0x11c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c1c>
   11230:      	sub	w10, w0, #0x500, lsl #12 // =0x500000
   11234:      	sub	w10, w10, #0x100
   11238:      	cmp	w10, #0x2
   1123c:      	b.lo	0x11500 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x84ec>
   11240:      	sub	w10, w0, #0x600, lsl #12 // =0x600000
   11244:      	sub	w10, w10, #0x100
   11248:      	cmp	w10, #0x2
   1124c:      	b.hs	0x1154c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8538>
   11250:      	adrp	x10, 0x5000
   11254:      	adrp	x11, 0x5000
   11258:      	mov	w15, #0x10000           // =65536
   1125c:      	ldr	q0, [x10, #0x1d0]
   11260:      	adrp	x10, 0x5000
   11264:      	ldr	q1, [x11, #0x240]
   11268:      	adrp	x11, 0x5000
   1126c:      	ldr	q2, [x10, #0x220]
   11270:      	adrp	x10, 0x5000
   11274:      	stp	q0, q1, [x6]
   11278:      	ldr	q0, [x11, #0xf0]
   1127c:      	ldr	q1, [x10, #0x1e0]
   11280:      	mov	w14, #0x4               // =4
   11284:      	mov	w16, #0x80              // =128
   11288:      	mov	w11, #0x8000            // =32768
   1128c:      	stp	q2, q0, [x7]
   11290:      	mov	w12, #0x8               // =8
   11294:      	mov	w13, #0x40              // =64
   11298:      	stp	q1, q0, [x9]
   1129c:      	mov	w10, #0x200000          // =2097152
   112a0:      	b	0x11c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c1c>
   112a4:      	mov	w10, #0x372             // =882
   112a8:      	movk	w10, #0x30, lsl #16
   112ac:      	cmp	w0, w10
   112b0:      	b.le	0x11478 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8464>
   112b4:      	mov	w10, #0x373             // =883
   112b8:      	movk	w10, #0x30, lsl #16
   112bc:      	cmp	w0, w10
   112c0:      	b.eq	0x11680 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x866c>
   112c4:      	mov	w10, #0x375             // =885
   112c8:      	movk	w10, #0x30, lsl #16
   112cc:      	cmp	w0, w10
   112d0:      	b.eq	0x116c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x86ac>
   112d4:      	mov	w10, #0x376             // =886
   112d8:      	movk	w10, #0x30, lsl #16
   112dc:      	cmp	w0, w10
   112e0:      	b.ne	0x11838 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8824>
   112e4:      	ldp	w10, w11, [x3, #0x4]
   112e8:      	adrp	x12, 0x5000
   112ec:      	adrp	x14, 0x5000
   112f0:      	mov	w13, #0x40000           // =262144
   112f4:      	ldr	q0, [x12, #0x1d0]
   112f8:      	ldr	q1, [x14, #0xf0]
   112fc:      	mov	w12, #0x80000           // =524288
   11300:      	cmp	w10, #0xa
   11304:      	adrp	x15, 0x4000
   11308:      	str	wzr, [x9, #0x1c]
   1130c:      	cset	w10, eq
   11310:      	cmp	w11, #0x3d4
   11314:      	adrp	x11, 0x5000
   11318:      	cset	w14, eq
   1131c:      	stp	q0, q1, [x6]
   11320:      	mov	w16, #0x40              // =64
   11324:      	tst	w10, w14
   11328:      	stp	q0, q1, [x7]
   1132c:      	ldr	q0, [x11, #0xb0]
   11330:      	csel	w10, w12, w13, ne
   11334:      	adrp	x13, 0x5000
   11338:      	ldr	d1, [x15, #0xf38]
   1133c:      	mov	w11, #0x100000          // =1048576
   11340:      	stur	q0, [x9, #0x4]
   11344:      	mov	w12, #0x400000          // =4194304
   11348:      	ldr	q0, [x13, #0x110]
   1134c:      	csel	w11, w12, w11, ne
   11350:      	str	w10, [x9]
   11354:      	stur	d1, [x9, #0x14]
   11358:      	mov	w12, #0x4               // =4
   1135c:      	mov	w13, #0x40              // =64
   11360:      	str	w11, [x8]
   11364:      	mov	w11, #0x10000           // =65536
   11368:      	stur	q0, [x8, #0x4]
   1136c:      	str	xzr, [x8, #0x18]
   11370:      	str	wzr, [x8, #0x14]
   11374:      	b	0x1182c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8818>
   11378:      	mov	w10, #0x377             // =887
   1137c:      	movk	w10, #0x30, lsl #16
   11380:      	cmp	w0, w10
   11384:      	b.eq	0x117e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x87cc>
   11388:      	mov	w10, #0x102             // =258
   1138c:      	movk	w10, #0x40, lsl #16
   11390:      	cmp	w0, w10
   11394:      	b.ne	0x11838 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8824>
   11398:      	adrp	x10, 0x5000
   1139c:      	adrp	x11, 0x5000
   113a0:      	adrp	x12, 0x5000
   113a4:      	ldr	q0, [x10, #0x160]
   113a8:      	mov	w10, #0xfff0            // =65520
   113ac:      	ldr	q1, [x11, #0xf0]
   113b0:      	movk	w10, #0xff00, lsl #16
   113b4:      	mov	w11, #0xdff0            // =57328
   113b8:      	ldr	q2, [x12, #0x170]
   113bc:      	orr	w10, w10, #0xf0000
   113c0:      	movk	w11, #0xaef0, lsl #16
   113c4:      	stp	q0, q1, [x6]
   113c8:      	and	w10, w2, w10
   113cc:      	stp	q2, q1, [x7]
   113d0:      	add	w10, w10, w11
   113d4:      	tst	w10, #0xfffffeff
   113d8:      	b.eq	0x11998 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8984>
   113dc:      	adrp	x10, 0x5000
   113e0:      	adrp	x11, 0x5000
   113e4:      	mov	w15, #0x8000            // =32768
   113e8:      	ldr	q0, [x10, #0x210]
   113ec:      	ldr	q1, [x11, #0x240]
   113f0:      	mov	w14, #0x4               // =4
   113f4:      	mov	w11, #0x6000            // =24576
   113f8:      	mov	w12, #0x3               // =3
   113fc:      	mov	w13, #0x40              // =64
   11400:      	stp	q0, q1, [x9]
   11404:      	mov	w10, #0x100000          // =1048576
   11408:      	mov	w16, #0x40              // =64
   1140c:      	b	0x11c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c1c>
   11410:      	mov	w10, #0x335             // =821
   11414:      	movk	w10, #0x30, lsl #16
   11418:      	cmp	w0, w10
   1141c:      	b.eq	0x1173c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8728>
   11420:      	mov	w10, #0x353             // =851
   11424:      	movk	w10, #0x30, lsl #16
   11428:      	cmp	w0, w10
   1142c:      	b.ne	0x11838 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8824>
   11430:      	and	w10, w2, #0xfffffff0
   11434:      	mov	w11, #0x8010            // =32784
   11438:      	ldr	w12, [x3, #0x4]
   1143c:      	and	w10, w10, #0xff00ffff
   11440:      	movk	w11, #0x5100, lsl #16
   11444:      	cmp	w10, w11
   11448:      	b.ne	0x11898 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8884>
   1144c:      	cmp	w12, #0x4
   11450:      	b.eq	0x11a5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8a48>
   11454:      	cmp	w12, #0x2
   11458:      	b.ne	0x11a80 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8a6c>
   1145c:      	ldr	w10, [x3, #0x8]
   11460:      	mov	w11, #0x2326            // =8998
   11464:      	cmp	w10, w11
   11468:      	mov	w10, #0x80000           // =524288
   1146c:      	mov	w11, #0x100000          // =1048576
   11470:      	csel	w10, w11, w10, eq
   11474:      	b	0x11aec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8ad8>
   11478:      	mov	w10, #0x365             // =869
   1147c:      	movk	w10, #0x30, lsl #16
   11480:      	cmp	w0, w10
   11484:      	b.eq	0x11788 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8774>
   11488:      	mov	w10, #0x372             // =882
   1148c:      	movk	w10, #0x30, lsl #16
   11490:      	cmp	w0, w10
   11494:      	b.ne	0x11838 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8824>
   11498:      	adrp	x10, 0x5000
   1149c:      	adrp	x11, 0x5000
   114a0:      	adrp	x12, 0x5000
   114a4:      	ldr	q0, [x10, #0x230]
   114a8:      	ldr	w10, [x3, #0x4]
   114ac:      	ldr	q1, [x11, #0xf0]
   114b0:      	mov	w11, #0x100000          // =1048576
   114b4:      	ldr	q2, [x12, #0x140]
   114b8:      	mov	w12, #0x200000          // =2097152
   114bc:      	cmp	w10, #0xa
   114c0:      	stp	q0, q1, [x6]
   114c4:      	mov	w15, #0xc000            // =49152
   114c8:      	csel	w10, w12, w11, eq
   114cc:      	adrp	x11, 0x5000
   114d0:      	stp	q2, q1, [x7]
   114d4:      	ldr	q0, [x11, #0x110]
   114d8:      	adrp	x11, 0x4000
   114dc:      	str	w10, [x9]
   114e0:      	ldr	d1, [x11, #0xf38]
   114e4:      	str	wzr, [x9, #0x1c]
   114e8:      	mov	w14, #0x3               // =3
   114ec:      	stur	q0, [x9, #0x4]
   114f0:      	mov	w11, #0x8000            // =32768
   114f4:      	mov	w12, #0x2               // =2
   114f8:      	stur	d1, [x9, #0x14]
   114fc:      	b	0x11620 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x860c>
   11500:      	adrp	x10, 0x5000
   11504:      	adrp	x11, 0x5000
   11508:      	mov	w15, #0x20000           // =131072
   1150c:      	ldr	q0, [x10, #0x1c0]
   11510:      	adrp	x10, 0x5000
   11514:      	ldr	q1, [x11, #0xf0]
   11518:      	ldr	q2, [x10, #0x1d0]
   1151c:      	adrp	x10, 0x5000
   11520:      	mov	w11, #0x10000           // =65536
   11524:      	stp	q0, q1, [x6]
   11528:      	ldr	q0, [x10, #0x1e0]
   1152c:      	mov	w12, #0x4               // =4
   11530:      	stp	q2, q1, [x7]
   11534:      	mov	w13, #0x40              // =64
   11538:      	mov	w10, #0x200000          // =2097152
   1153c:      	stp	q0, q1, [x9]
   11540:      	mov	w16, #0x40              // =64
   11544:      	mov	w14, #0x4               // =4
   11548:      	b	0x11c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c1c>
   1154c:      	mov	w10, #0x102             // =258
   11550:      	movk	w10, #0x60, lsl #16
   11554:      	cmp	w0, w10
   11558:      	b.ne	0x11838 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8824>
   1155c:      	adrp	x10, 0x5000
   11560:      	adrp	x11, 0x5000
   11564:      	mov	w14, #0x4               // =4
   11568:      	ldr	q0, [x10, #0x1d0]
   1156c:      	ldr	q1, [x11, #0x240]
   11570:      	adrp	x10, 0x5000
   11574:      	adrp	x11, 0x5000
   11578:      	ldr	q2, [x10, #0xe0]
   1157c:      	adrp	x10, 0x5000
   11580:      	stp	q0, q1, [x6]
   11584:      	ldr	q0, [x11, #0xf0]
   11588:      	ldr	q1, [x10, #0x250]
   1158c:      	adrp	x10, 0x5000
   11590:      	mov	w16, #0x80              // =128
   11594:      	mov	w11, #0x10000           // =65536
   11598:      	stp	q2, q0, [x7]
   1159c:      	ldr	q2, [x10, #0x1a0]
   115a0:      	mov	w12, #0x8               // =8
   115a4:      	stp	q1, q0, [x9]
   115a8:      	mov	w13, #0x40              // =64
   115ac:      	mov	w10, #0x80000           // =524288
   115b0:      	stp	q2, q0, [x8]
   115b4:      	mov	w15, #0x10000           // =65536
   115b8:      	b	0x11c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c1c>
   115bc:      	mov	w10, #0x357             // =855
   115c0:      	movk	w10, #0x30, lsl #16
   115c4:      	cmp	w0, w10
   115c8:      	b.ne	0x11838 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8824>
   115cc:      	adrp	x10, 0x5000
   115d0:      	adrp	x11, 0x5000
   115d4:      	mov	w15, #0xc000            // =49152
   115d8:      	ldr	q0, [x10, #0x230]
   115dc:      	adrp	x10, 0x5000
   115e0:      	ldr	q1, [x11, #0xf0]
   115e4:      	ldr	q2, [x10, #0x140]
   115e8:      	adrp	x11, 0x5000
   115ec:      	lsl	w10, w1, #19
   115f0:      	stp	q0, q1, [x6]
   115f4:      	ldr	q0, [x11, #0x110]
   115f8:      	adrp	x11, 0x4000
   115fc:      	stp	q2, q1, [x7]
   11600:      	ldr	d1, [x11, #0xf38]
   11604:      	mov	w14, #0x3               // =3
   11608:      	mov	w11, #0x8000            // =32768
   1160c:      	mov	w12, #0x2               // =2
   11610:      	str	w10, [x9]
   11614:      	stur	q0, [x9, #0x4]
   11618:      	stur	d1, [x9, #0x14]
   1161c:      	str	wzr, [x9, #0x1c]
   11620:      	mov	w13, #0x40              // =64
   11624:      	mov	w16, #0x40              // =64
   11628:      	b	0x11c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c1c>
   1162c:      	adrp	x11, 0x5000
   11630:      	adrp	x10, 0x5000
   11634:      	ldr	q0, [x11, #0xf0]
   11638:      	ldr	w11, [x3, #0x4]
   1163c:      	ldr	q1, [x10, #0x160]
   11640:      	mov	w10, #0x100000          // =1048576
   11644:      	cmp	w11, #0xa
   11648:      	stp	q1, q0, [x6]
   1164c:      	stp	q1, q0, [x7]
   11650:      	b.eq	0x119cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x89b8>
   11654:      	cmp	w11, #0x6
   11658:      	b.ne	0x119dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x89c8>
   1165c:      	adrp	x10, 0x5000
   11660:      	mov	w11, #0x8000            // =32768
   11664:      	mov	w12, #0x4               // =4
   11668:      	ldr	q1, [x10, #0x250]
   1166c:      	mov	w13, #0x40              // =64
   11670:      	mov	w10, #0x80000           // =524288
   11674:      	mov	w16, #0x40              // =64
   11678:      	stp	q1, q0, [x9]
   1167c:      	b	0x117d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x87c0>
   11680:      	ldr	w10, [x3, #0x4]
   11684:      	cmp	w10, #0xa
   11688:      	b.eq	0x116b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x86a0>
   1168c:      	cmp	w10, #0x5
   11690:      	b.eq	0x11934 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8920>
   11694:      	mov	w10, #0x8002            // =32770
   11698:      	movk	w10, #0x51af, lsl #16
   1169c:      	cmp	w2, w10
   116a0:      	b.eq	0x11934 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8920>
   116a4:      	mov	w10, #0x8001            // =32769
   116a8:      	movk	w10, #0x51af, lsl #16
   116ac:      	cmp	w2, w10
   116b0:      	b.ne	0x11adc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8ac8>
   116b4:      	mov	w11, #0x10000           // =65536
   116b8:      	mov	w10, #0x200000          // =2097152
   116bc:      	b	0x1193c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8928>
   116c0:      	adrp	x10, 0x5000
   116c4:      	adrp	x11, 0x5000
   116c8:      	adrp	x12, 0x5000
   116cc:      	ldr	q0, [x10, #0x1d0]
   116d0:      	adrp	x10, 0x5000
   116d4:      	ldr	q1, [x11, #0xf0]
   116d8:      	ldr	q2, [x10, #0x120]
   116dc:      	str	xzr, [x8, #0x18]
   116e0:      	mov	w14, #0x4               // =4
   116e4:      	ldp	w10, w11, [x3, #0x4]
   116e8:      	stp	q0, q1, [x6]
   116ec:      	ldr	q0, [x12, #0x1f0]
   116f0:      	adrp	x12, 0x5000
   116f4:      	stp	q2, q1, [x7]
   116f8:      	mov	w13, #0x40              // =64
   116fc:      	mov	w16, #0x40              // =64
   11700:      	cmp	w11, #0x34d
   11704:      	mov	w11, #0x200000          // =2097152
   11708:      	stp	q0, q1, [x9]
   1170c:      	ccmp	w10, #0x4, #0x0, eq
   11710:      	mov	w10, #0x100000          // =1048576
   11714:      	ldr	q0, [x12, #0x110]
   11718:      	csel	w10, w11, w10, eq
   1171c:      	mov	w11, #0x10000           // =65536
   11720:      	str	wzr, [x8, #0x14]
   11724:      	str	w10, [x8]
   11728:      	mov	w12, #0x10              // =16
   1172c:      	mov	w10, #0x40000           // =262144
   11730:      	stur	q0, [x8, #0x4]
   11734:      	mov	w15, #0x10000           // =65536
   11738:      	b	0x11c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c1c>
   1173c:      	adrp	x10, 0x5000
   11740:      	adrp	x11, 0x5000
   11744:      	mov	w14, #0x2               // =2
   11748:      	ldr	q0, [x10, #0x180]
   1174c:      	adrp	x10, 0x5000
   11750:      	ldr	q1, [x11, #0xf0]
   11754:      	ldr	q2, [x10, #0xd0]
   11758:      	adrp	x10, 0x5000
   1175c:      	mov	w11, #0x4000            // =16384
   11760:      	stp	q0, q1, [x6]
   11764:      	ldr	q0, [x10, #0x1f0]
   11768:      	mov	w12, #0x4               // =4
   1176c:      	stp	q2, q1, [x7]
   11770:      	mov	w13, #0x40              // =64
   11774:      	mov	w10, #0x40000           // =262144
   11778:      	stp	q0, q1, [x9]
   1177c:      	mov	w16, #0x40              // =64
   11780:      	mov	w15, #0x4000            // =16384
   11784:      	b	0x11c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c1c>
   11788:      	adrp	x10, 0x5000
   1178c:      	adrp	x11, 0x5000
   11790:      	mov	w12, #0x4               // =4
   11794:      	ldr	q0, [x10, #0x1c0]
   11798:      	adrp	x10, 0x5000
   1179c:      	ldr	q1, [x11, #0x150]
   117a0:      	adrp	x11, 0x5000
   117a4:      	ldr	q2, [x10, #0x160]
   117a8:      	adrp	x10, 0x5000
   117ac:      	stp	q0, q1, [x9]
   117b0:      	ldr	q0, [x11, #0xf0]
   117b4:      	ldr	q1, [x10, #0x250]
   117b8:      	mov	w11, #0x8000            // =32768
   117bc:      	mov	w13, #0x40              // =64
   117c0:      	mov	w10, #0x20000           // =131072
   117c4:      	stp	q2, q0, [x6]
   117c8:      	mov	w16, #0x40              // =64
   117cc:      	stp	q2, q0, [x7]
   117d0:      	stp	q1, q0, [x8]
   117d4:      	mov	w14, #0x4               // =4
   117d8:      	mov	w15, #0x8000            // =32768
   117dc:      	b	0x11c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c1c>
   117e0:      	adrp	x10, 0x5000
   117e4:      	adrp	x11, 0x5000
   117e8:      	mov	w12, #0x4               // =4
   117ec:      	ldr	q0, [x10, #0x1f0]
   117f0:      	adrp	x10, 0x5000
   117f4:      	ldr	q1, [x11, #0x150]
   117f8:      	adrp	x11, 0x5000
   117fc:      	ldr	q2, [x10, #0x1d0]
   11800:      	adrp	x10, 0x5000
   11804:      	stp	q0, q1, [x9]
   11808:      	ldr	q0, [x11, #0xf0]
   1180c:      	ldr	q1, [x10, #0x260]
   11810:      	mov	w11, #0x10000           // =65536
   11814:      	mov	w13, #0x40              // =64
   11818:      	mov	w10, #0x40000           // =262144
   1181c:      	mov	w16, #0x40              // =64
   11820:      	stp	q2, q0, [x6]
   11824:      	stp	q2, q0, [x7]
   11828:      	stp	q1, q0, [x8]
   1182c:      	mov	w14, #0x4               // =4
   11830:      	mov	w15, #0x10000           // =65536
   11834:      	b	0x11c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c1c>
   11838:      	cmp	w5, #0x8
   1183c:      	b.lo	0x118e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x88cc>
   11840:      	adrp	x10, 0x5000
   11844:      	adrp	x11, 0x5000
   11848:      	mov	w12, #0x4               // =4
   1184c:      	ldr	q0, [x10, #0x160]
   11850:      	ldr	q1, [x11, #0xf0]
   11854:      	adrp	x10, 0x4000
   11858:      	adrp	x11, 0x5000
   1185c:      	ldr	d2, [x10, #0xf28]
   11860:      	lsl	w10, w1, #18
   11864:      	stp	q0, q1, [x6]
   11868:      	ldr	q0, [x11, #0xb0]
   1186c:      	mov	w11, #0x8000            // =32768
   11870:      	str	d2, [x7]
   11874:      	mov	w13, #0x40              // =64
   11878:      	mov	w16, #0x40              // =64
   1187c:      	str	q1, [x7, #0x10]
   11880:      	mov	w14, #0x4               // =4
   11884:      	mov	w15, #0x8000            // =32768
   11888:      	str	w10, [x9]
   1188c:      	stur	q0, [x9, #0x4]
   11890:      	stp	wzr, wzr, [x9, #0x14]
   11894:      	b	0x11c2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c18>
   11898:      	cmp	w12, #0x5
   1189c:      	mov	w11, #0x4000            // =16384
   118a0:      	mov	w10, #0x40000           // =262144
   118a4:      	b.le	0x11a40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8a2c>
   118a8:      	cmp	w12, #0x9
   118ac:      	b.le	0x11ac0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8aac>
   118b0:      	cmp	w12, #0xa
   118b4:      	b.eq	0x11b7c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8b68>
   118b8:      	cmp	w12, #0xf
   118bc:      	b.eq	0x11b8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8b78>
   118c0:      	cmp	w12, #0x1a
   118c4:      	b.ne	0x11bd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8bbc>
   118c8:      	ldr	w10, [x3, #0x8]
   118cc:      	cmp	w10, #0xd28
   118d0:      	ccmp	w4, #0x0, #0x0, eq
   118d4:      	mov	w10, #0x40000           // =262144
   118d8:      	mov	w11, #0x80000           // =524288
   118dc:      	b	0x11bc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8bb4>
   118e0:      	adrp	x10, 0x5000
   118e4:      	adrp	x11, 0x5000
   118e8:      	cmp	w5, #0x7
   118ec:      	ldr	q0, [x10, #0xd0]
   118f0:      	ldr	q1, [x11, #0x190]
   118f4:      	stp	q0, q1, [x6]
   118f8:      	stp	q0, q1, [x7]
   118fc:      	b.ne	0x11a20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8a0c>
   11900:      	adrp	x11, 0x5000
   11904:      	lsl	w10, w1, #17
   11908:      	mov	w12, #0x4               // =4
   1190c:      	ldr	q0, [x11, #0x1b0]
   11910:      	mov	w11, #0x4000            // =16384
   11914:      	mov	w13, #0x20              // =32
   11918:      	mov	w16, #0x20              // =32
   1191c:      	mov	w14, #0x4               // =4
   11920:      	mov	w15, #0x4000            // =16384
   11924:      	stp	wzr, wzr, [x9, #0x14]
   11928:      	str	w10, [x9]
   1192c:      	stur	q0, [x9, #0x4]
   11930:      	b	0x11c2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c18>
   11934:      	mov	w11, #0x10000           // =65536
   11938:      	mov	w10, #0x100000          // =1048576
   1193c:      	adrp	x12, 0x5000
   11940:      	adrp	x13, 0x5000
   11944:      	str	xzr, [x7, #0x18]
   11948:      	ldr	q0, [x12, #0x1d0]
   1194c:      	ldr	q1, [x13, #0xf0]
   11950:      	adrp	x13, 0x5000
   11954:      	lsr	w12, w11, #12
   11958:      	str	w10, [x9]
   1195c:      	mov	w15, #0x10000           // =65536
   11960:      	stp	q0, q1, [x6]
   11964:      	ldr	q0, [x13, #0x100]
   11968:      	adrp	x13, 0x5000
   1196c:      	stp	w11, w12, [x7]
   11970:      	mov	w14, #0x4               // =4
   11974:      	mov	w16, #0x40              // =64
   11978:      	stur	q0, [x7, #0x8]
   1197c:      	ldr	q0, [x13, #0x110]
   11980:      	adrp	x13, 0x4000
   11984:      	stur	q0, [x9, #0x4]
   11988:      	ldr	d0, [x13, #0xf38]
   1198c:      	mov	w13, #0x40              // =64
   11990:      	stur	d0, [x9, #0x14]
   11994:      	b	0x11c2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c18>
   11998:      	adrp	x10, 0x5000
   1199c:      	adrp	x11, 0x5000
   119a0:      	mov	w15, #0x8000            // =32768
   119a4:      	ldr	q0, [x10, #0x130]
   119a8:      	ldr	q1, [x11, #0x240]
   119ac:      	mov	w14, #0x4               // =4
   119b0:      	mov	w11, #0x6000            // =24576
   119b4:      	mov	w12, #0x3               // =3
   119b8:      	mov	w13, #0x40              // =64
   119bc:      	stp	q0, q1, [x9]
   119c0:      	mov	w10, #0x80000           // =524288
   119c4:      	mov	w16, #0x40              // =64
   119c8:      	b	0x11c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c1c>
   119cc:      	ldr	w11, [x3, #0x8]
   119d0:      	cmp	w11, #0x3d4
   119d4:      	mov	w11, #0x400000          // =4194304
   119d8:      	csel	w10, w11, w10, eq
   119dc:      	adrp	x11, 0x5000
   119e0:      	str	w10, [x8]
   119e4:      	adrp	x10, 0x5000
   119e8:      	ldr	q1, [x11, #0x1c0]
   119ec:      	ldr	q2, [x10, #0x110]
   119f0:      	mov	w11, #0x8000            // =32768
   119f4:      	mov	w12, #0x4               // =4
   119f8:      	mov	w13, #0x40              // =64
   119fc:      	str	xzr, [x8, #0x18]
   11a00:      	stp	q1, q0, [x9]
   11a04:      	mov	w10, #0x20000           // =131072
   11a08:      	mov	w16, #0x40              // =64
   11a0c:      	stur	q2, [x8, #0x4]
   11a10:      	mov	w14, #0x4               // =4
   11a14:      	mov	w15, #0x8000            // =32768
   11a18:      	str	wzr, [x8, #0x14]
   11a1c:      	b	0x11c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c1c>
   11a20:      	ldr	w10, [x9]
   11a24:      	mov	w11, #0x4000            // =16384
   11a28:      	mov	w12, #0x4               // =4
   11a2c:      	mov	w13, #0x20              // =32
   11a30:      	mov	w16, #0x20              // =32
   11a34:      	mov	w14, #0x4               // =4
   11a38:      	mov	w15, #0x4000            // =16384
   11a3c:      	b	0x11c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c1c>
   11a40:      	cmp	w12, #0x3
   11a44:      	b.gt	0x11a88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8a74>
   11a48:      	cmp	w12, #0x2
   11a4c:      	b.eq	0x11b3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8b28>
   11a50:      	cmp	w12, #0x3
   11a54:      	b.eq	0x11ad0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8abc>
   11a58:      	b	0x11bd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8bbc>
   11a5c:      	ldr	w10, [x3, #0x8]
   11a60:      	cmp	w10, #0x294
   11a64:      	b.eq	0x11ae8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8ad4>
   11a68:      	cmp	w10, #0x27c
   11a6c:      	b.eq	0x11ae8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8ad4>
   11a70:      	cmp	w10, #0x276
   11a74:      	b.ne	0x11a80 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8a6c>
   11a78:      	cmp	w4, #0x0
   11a7c:      	b	0x11468 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8454>
   11a80:      	mov	w10, #0x80000           // =524288
   11a84:      	b	0x11aec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8ad8>
   11a88:      	cmp	w12, #0x4
   11a8c:      	b.eq	0x11b68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8b54>
   11a90:      	cmp	w12, #0x5
   11a94:      	b.ne	0x11bd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8bbc>
   11a98:      	ldr	w10, [x3, #0x8]
   11a9c:      	mov	w11, #0x1fed            // =8173
   11aa0:      	mov	w12, #0x40000           // =262144
   11aa4:      	mov	w13, #0x8000            // =32768
   11aa8:      	cmp	w10, w11
   11aac:      	mov	w10, #0x80000           // =524288
   11ab0:      	mov	w11, #0x4000            // =16384
   11ab4:      	csel	w10, w10, w12, eq
   11ab8:      	csel	w11, w13, w11, eq
   11abc:      	b	0x11bd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8bbc>
   11ac0:      	cmp	w12, #0x6
   11ac4:      	b.eq	0x11bcc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8bb8>
   11ac8:      	cmp	w12, #0x9
   11acc:      	b.ne	0x11bd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8bbc>
   11ad0:      	mov	w11, #0x8000            // =32768
   11ad4:      	mov	w10, #0x80000           // =524288
   11ad8:      	b	0x11bd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8bbc>
   11adc:      	mov	w11, #0x8000            // =32768
   11ae0:      	mov	w10, #0x80000           // =524288
   11ae4:      	b	0x1193c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8928>
   11ae8:      	mov	w10, #0x100000          // =1048576
   11aec:      	adrp	x11, 0x5000
   11af0:      	adrp	x12, 0x5000
   11af4:      	str	w10, [x9]
   11af8:      	ldr	q0, [x11, #0x140]
   11afc:      	adrp	x11, 0x5000
   11b00:      	ldr	q1, [x12, #0xf0]
   11b04:      	ldr	q2, [x11, #0x160]
   11b08:      	adrp	x11, 0x5000
   11b0c:      	mov	w14, #0x2               // =2
   11b10:      	stp	q0, q1, [x6]
   11b14:      	ldr	q0, [x11, #0x110]
   11b18:      	mov	w11, #0x8000            // =32768
   11b1c:      	stp	q2, q1, [x7]
   11b20:      	mov	w12, #0x4               // =4
   11b24:      	mov	w13, #0x40              // =64
   11b28:      	stur	q0, [x9, #0x4]
   11b2c:      	mov	w16, #0x40              // =64
   11b30:      	mov	w15, #0x8000            // =32768
   11b34:      	stp	wzr, wzr, [x9, #0x14]
   11b38:      	b	0x11c2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c18>
   11b3c:      	ldr	w12, [x3, #0x8]
   11b40:      	mov	w10, #0x22f7            // =8951
   11b44:      	mov	w11, #0x8000            // =32768
   11b48:      	cmp	w12, w10
   11b4c:      	mov	w10, #0x80000           // =524288
   11b50:      	b.gt	0x11ba8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8b94>
   11b54:      	mov	w13, #0x22e9            // =8937
   11b58:      	cmp	w12, w13
   11b5c:      	b.eq	0x11bc0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8bac>
   11b60:      	mov	w13, #0x22ec            // =8940
   11b64:      	b	0x11bb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8ba4>
   11b68:      	ldr	w10, [x3, #0x8]
   11b6c:      	cmp	w10, #0x1c2
   11b70:      	mov	w10, #0x80000           // =524288
   11b74:      	ccmp	w4, #0x0, #0x0, eq
   11b78:      	b	0x11bc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8bb0>
   11b7c:      	ldr	w10, [x3, #0x8]
   11b80:      	cmp	w10, #0x3ca
   11b84:      	mov	w10, #0x80000           // =524288
   11b88:      	b	0x11bc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8bb0>
   11b8c:      	ldr	w10, [x3, #0x8]
   11b90:      	mov	w11, #0x80000           // =524288
   11b94:      	cmp	w10, #0xb15
   11b98:      	mov	w10, #0x40000           // =262144
   11b9c:      	csel	w10, w11, w10, eq
   11ba0:      	mov	w11, #0x4000            // =16384
   11ba4:      	b	0x11bd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8bbc>
   11ba8:      	mov	w13, #0x22f8            // =8952
   11bac:      	cmp	w12, w13
   11bb0:      	b.eq	0x11c88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c74>
   11bb4:      	mov	w13, #0x22f9            // =8953
   11bb8:      	cmp	w12, w13
   11bbc:      	b.ne	0x11bd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8bbc>
   11bc0:      	cmp	w4, #0x0
   11bc4:      	mov	w11, #0x100000          // =1048576
   11bc8:      	csel	w10, w11, w10, eq
   11bcc:      	mov	w11, #0x8000            // =32768
   11bd0:      	adrp	x12, 0x5000
   11bd4:      	movi	v0.2d, #0000000000000000
   11bd8:      	str	w11, [x6]
   11bdc:      	ldr	q1, [x12, #0x200]
   11be0:      	adrp	x12, 0x5000
   11be4:      	str	wzr, [x6, #0x1c]
   11be8:      	str	w11, [x7]
   11bec:      	mov	w14, #0x2               // =2
   11bf0:      	mov	w13, #0x40              // =64
   11bf4:      	stur	q1, [x6, #0x4]
   11bf8:      	ldr	q1, [x12, #0xa0]
   11bfc:      	adrp	x12, 0x5000
   11c00:      	stur	d0, [x6, #0x14]
   11c04:      	mov	w16, #0x40              // =64
   11c08:      	mov	w15, w11
   11c0c:      	stur	q1, [x7, #0x4]
   11c10:      	ldr	q1, [x12, #0x110]
   11c14:      	mov	w12, #0x4               // =4
   11c18:      	stur	d0, [x7, #0x14]
   11c1c:      	str	wzr, [x7, #0x1c]
   11c20:      	str	w10, [x9]
   11c24:      	stur	q1, [x9, #0x4]
   11c28:      	stur	d0, [x9, #0x14]
   11c2c:      	str	wzr, [x9, #0x1c]
   11c30:      	mul	w14, w16, w14
   11c34:      	mul	w12, w13, w12
   11c38:      	udiv	w14, w15, w14
   11c3c:      	udiv	w12, w11, w12
   11c40:      	mov	w11, #0x1               // =1
   11c44:      	stp	w14, w11, [x6, #0x8]
   11c48:      	stp	w12, w11, [x7, #0x8]
   11c4c:      	cbz	w10, 0x11c84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c70>
   11c50:      	ldr	w12, [x9, #0x4]
   11c54:      	ldr	w13, [x9, #0x10]
   11c58:      	mul	w12, w13, w12
   11c5c:      	udiv	w12, w10, w12
   11c60:      	ldr	w10, [x8]
   11c64:      	stp	w12, w11, [x9, #0x8]
   11c68:      	cbz	w10, 0x11c84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8c70>
   11c6c:      	ldr	w9, [x8, #0x4]
   11c70:      	ldr	w11, [x8, #0x10]
   11c74:      	mul	w9, w11, w9
   11c78:      	udiv	w9, w10, w9
   11c7c:      	mov	w10, #0x1               // =1
   11c80:      	stp	w9, w10, [x8, #0x8]
   11c84:      	ret
   11c88:      	cmp	w4, #0x0
   11c8c:      	b	0x118d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x88c0>
   11c90:      	ldr	x8, [x0, #0x8]
   11c94:      	mov	w9, #0x352              // =850
   11c98:      	movk	w9, #0x30, lsl #16
   11c9c:      	ldr	w8, [x8, #0x24]
   11ca0:      	cmp	w8, w9
   11ca4:      	b.gt	0x11cfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8ce8>
   11ca8:      	mov	w9, #0x208              // =520
   11cac:      	movk	w9, #0x30, lsl #16
   11cb0:      	cmp	w8, w9
   11cb4:      	b.gt	0x11d44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8d30>
   11cb8:      	mov	w9, #0x204              // =516
   11cbc:      	movk	w9, #0x30, lsl #16
   11cc0:      	cmp	w8, w9
   11cc4:      	b.le	0x11dc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8db0>
   11cc8:      	mov	w9, #0x205              // =517
   11ccc:      	movk	w9, #0x30, lsl #16
   11cd0:      	cmp	w8, w9
   11cd4:      	b.eq	0x11e18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8e04>
   11cd8:      	mov	w9, #0x207              // =519
   11cdc:      	movk	w9, #0x30, lsl #16
   11ce0:      	cmp	w8, w9
   11ce4:      	b.eq	0x11e10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8dfc>
   11ce8:      	mov	w9, #0x208              // =520
   11cec:      	movk	w9, #0x30, lsl #16
   11cf0:      	cmp	w8, w9
   11cf4:      	b.eq	0x11e10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8dfc>
   11cf8:      	b	0x11db4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8da0>
   11cfc:      	mov	w9, #0x372              // =882
   11d00:      	movk	w9, #0x30, lsl #16
   11d04:      	cmp	w8, w9
   11d08:      	b.le	0x11d88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8d74>
   11d0c:      	sub	w9, w8, #0x400, lsl #12 // =0x400000
   11d10:      	sub	w9, w9, #0x100
   11d14:      	cmp	w9, #0x3
   11d18:      	b.lo	0x11de4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8dd0>
   11d1c:      	sub	w9, w8, #0x600, lsl #12 // =0x600000
   11d20:      	sub	w9, w9, #0x100
   11d24:      	cmp	w9, #0x3
   11d28:      	b.lo	0x11de4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8dd0>
   11d2c:      	mov	w9, #0x373              // =883
   11d30:      	movk	w9, #0x30, lsl #16
   11d34:      	cmp	w8, w9
   11d38:      	b.ne	0x11db4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8da0>
   11d3c:      	mov	w0, #0x800000           // =8388608
   11d40:      	ret
   11d44:      	mov	w9, #0x214              // =532
   11d48:      	movk	w9, #0x30, lsl #16
   11d4c:      	cmp	w8, w9
   11d50:      	b.le	0x11de8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8dd4>
   11d54:      	mov	w9, #0x215              // =533
   11d58:      	movk	w9, #0x30, lsl #16
   11d5c:      	cmp	w8, w9
   11d60:      	b.eq	0x11db4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8da0>
   11d64:      	mov	w9, #0x217              // =535
   11d68:      	movk	w9, #0x30, lsl #16
   11d6c:      	cmp	w8, w9
   11d70:      	b.eq	0x11e08 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8df4>
   11d74:      	mov	w9, #0x335              // =821
   11d78:      	movk	w9, #0x30, lsl #16
   11d7c:      	cmp	w8, w9
   11d80:      	b.eq	0x11e10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8dfc>
   11d84:      	b	0x11db4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8da0>
   11d88:      	mov	w9, #0x353              // =851
   11d8c:      	movk	w9, #0x30, lsl #16
   11d90:      	cmp	w8, w9
   11d94:      	b.eq	0x11dbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8da8>
   11d98:      	mov	w9, #0x357              // =855
   11d9c:      	movk	w9, #0x30, lsl #16
   11da0:      	cmp	w8, w9
   11da4:      	b.eq	0x11dbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8da8>
   11da8:      	mov	w9, #0x372              // =882
   11dac:      	movk	w9, #0x30, lsl #16
   11db0:      	cmp	w8, w9
   11db4:      	mov	w0, #0x400000           // =4194304
   11db8:      	ret
   11dbc:      	mov	w0, #0x200000           // =2097152
   11dc0:      	ret
   11dc4:      	mov	w9, #0x600              // =1536
   11dc8:      	movk	w9, #0x10, lsl #16
   11dcc:      	cmp	w8, w9
   11dd0:      	b.eq	0x11de4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8dd0>
   11dd4:      	mov	w9, #0x102              // =258
   11dd8:      	movk	w9, #0x30, lsl #16
   11ddc:      	cmp	w8, w9
   11de0:      	b.ne	0x11db4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8da0>
   11de4:      	b	0x11e20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8e0c>
   11de8:      	mov	w9, #0x209              // =521
   11dec:      	movk	w9, #0x30, lsl #16
   11df0:      	cmp	w8, w9
   11df4:      	b.eq	0x11e10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8dfc>
   11df8:      	mov	w9, #0x212              // =530
   11dfc:      	movk	w9, #0x30, lsl #16
   11e00:      	cmp	w8, w9
   11e04:      	b.ne	0x11db4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8da0>
   11e08:      	mov	w0, #0x800000           // =8388608
   11e0c:      	ret
   11e10:      	mov	w0, #0x100000           // =1048576
   11e14:      	ret
   11e18:      	mov	w0, #0x80000            // =524288
   11e1c:      	ret
   11e20:      	ldr	x8, [x0, #0x48]
   11e24:      	cbnz	x8, 0x11e40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8e2c>
   11e28:      	ldr	x8, [x0, #0x40]
   11e2c:      	cbnz	x8, 0x11e40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8e2c>
   11e30:      	ldr	x8, [x0, #0x38]
   11e34:      	cbnz	x8, 0x11e40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8e2c>
   11e38:      	ldr	x8, [x0, #0x30]
   11e3c:      	cbz	x8, 0x11e48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8e34>
   11e40:      	ldr	w0, [x8]
   11e44:      	ret
   11e48:      	mov	w0, wzr
   11e4c:      	ret
   11e50:      	sub	sp, sp, #0x80
   11e54:      	stp	x29, x30, [sp, #0x60]
   11e58:      	str	x19, [sp, #0x70]
   11e5c:      	add	x29, sp, #0x60
   11e60:      	mrs	x19, TPIDR_EL0
   11e64:      	movi	v0.2d, #0000000000000000
   11e68:      	ldr	x8, [x19, #0x28]
   11e6c:      	stur	x8, [x29, #-0x8]
   11e70:      	strb	wzr, [x0]
   11e74:      	stp	x0, x1, [sp]
   11e78:      	nop
   11e7c:      	adr	x0, 0x2e92
   11e80:      	stp	wzr, w2, [sp, #0x10]
   11e84:      	nop
   11e88:      	adr	x2, 0x11ed0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8ebc>
   11e8c:      	str	x3, [sp, #0x18]
   11e90:      	mov	x3, sp
   11e94:      	mov	w1, #0x400              // =1024
   11e98:      	stp	q0, q0, [sp, #0x20]
   11e9c:      	str	q0, [sp, #0x40]
   11ea0:      	str	xzr, [sp, #0x50]
   11ea4:      	bl	0x18524 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf510>
   11ea8:      	ldr	x8, [x19, #0x28]
   11eac:      	ldur	x9, [x29, #-0x8]
   11eb0:      	cmp	x8, x9
   11eb4:      	b.ne	0x11ecc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8eb8>
   11eb8:      	and	w0, w0, #0x1
   11ebc:      	ldp	x29, x30, [sp, #0x60]
   11ec0:      	ldr	x19, [sp, #0x70]
   11ec4:      	add	sp, sp, #0x80
   11ec8:      	ret
   11ecc:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   11ed0:      	cmp	x0, x1
   11ed4:      	b.eq	0x11f5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8f48>
   11ed8:      	mov	x8, x0
   11edc:      	mov	x10, xzr
   11ee0:      	neg	x9, x0
   11ee4:      	ldrb	w11, [x8, x10]
   11ee8:      	cmp	w11, #0x3a
   11eec:      	b.eq	0x11f04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8ef0>
   11ef0:      	add	x10, x10, #0x1
   11ef4:      	add	x11, x8, x10
   11ef8:      	cmp	x11, x1
   11efc:      	b.ne	0x11ee4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8ed0>
   11f00:      	b	0x11f5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8f48>
   11f04:      	cbz	x10, 0x11f5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8f48>
   11f08:      	sub	x11, x9, x10
   11f0c:      	add	x0, x8, x10
   11f10:      	b	0x11f1c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8f08>
   11f14:      	subs	x10, x10, #0x1
   11f18:      	b.eq	0x11f5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8f48>
   11f1c:      	add	x9, x8, x10
   11f20:      	ldurb	w9, [x9, #-0x1]
   11f24:      	cmp	w9, #0x9
   11f28:      	b.eq	0x11f14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8f00>
   11f2c:      	cmp	w9, #0x20
   11f30:      	b.eq	0x11f14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8f00>
   11f34:      	stp	x29, x30, [sp, #-0x10]!
   11f38:      	mov	x29, sp
   11f3c:      	add	x0, x0, #0x1
   11f40:      	cmp	x0, x1
   11f44:      	b.eq	0x12208 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x91f4>
   11f48:      	ldrb	w9, [x0]
   11f4c:      	sub	x11, x11, #0x1
   11f50:      	cmp	w9, #0x20
   11f54:      	b.eq	0x11f3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8f28>
   11f58:      	b	0x11f74 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8f60>
   11f5c:      	mov	w0, #0x1                // =1
   11f60:      	ret
   11f64:      	mov	x1, x14
   11f68:      	ldrb	w9, [x1, #-0x1]!
   11f6c:      	cmp	w9, #0x20
   11f70:      	b.ne	0x11f88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8f74>
   11f74:      	mov	x14, x1
   11f78:      	cmp	x0, x1
   11f7c:      	b.ne	0x11f64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8f50>
   11f80:      	mov	x1, x0
   11f84:      	b	0x11f8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8f78>
   11f88:      	add	x1, x1, #0x1
   11f8c:      	ldp	w9, w13, [x2, #0x10]
   11f90:      	mov	w15, #0x38              // =56
   11f94:      	ldr	x12, [x2, #0x18]
   11f98:      	add	x16, x2, #0x20
   11f9c:      	umaddl	x15, w9, w15, x12
   11fa0:      	cmp	w9, w13
   11fa4:      	csel	x9, x15, x16, lo
   11fa8:      	cmp	x10, #0xb
   11fac:      	b.gt	0x12010 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x8ffc>
   11fb0:      	cmp	x10, #0x8
   11fb4:      	b.eq	0x1206c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9058>
   11fb8:      	cmp	x10, #0x9
   11fbc:      	b.eq	0x12154 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9140>
   11fc0:      	cmp	x10, #0xb
   11fc4:      	b.ne	0x12208 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x91f4>
   11fc8:      	mov	x11, #0x5043            // =20547
   11fcc:      	ldr	x10, [x8]
   11fd0:      	ldur	x8, [x8, #0x3]
   11fd4:      	movk	x11, #0x2055, lsl #16
   11fd8:      	movk	x11, #0x6176, lsl #32
   11fdc:      	movk	x11, #0x6972, lsl #48
   11fe0:      	cmp	x10, x11
   11fe4:      	mov	x10, #0x7620            // =30240
   11fe8:      	movk	x10, #0x7261, lsl #16
   11fec:      	movk	x10, #0x6169, lsl #32
   11ff0:      	movk	x10, #0x746e, lsl #48
   11ff4:      	ccmp	x8, x10, #0x0, eq
   11ff8:      	b.ne	0x12208 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x91f4>
   11ffc:      	mov	x2, x9
   12000:      	bl	0x126f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x96e4>
   12004:      	ldp	x29, x30, [sp], #0x10
   12008:      	mov	w0, #0x1                // =1
   1200c:      	ret
   12010:      	cmp	x10, #0xc
   12014:      	b.eq	0x12114 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9100>
   12018:      	cmp	x10, #0xf
   1201c:      	b.eq	0x121b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x919c>
   12020:      	cmp	x10, #0x10
   12024:      	b.ne	0x12208 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x91f4>
   12028:      	mov	x11, #0x5043            // =20547
   1202c:      	ldp	x10, x8, [x8]
   12030:      	movk	x11, #0x2055, lsl #16
   12034:      	movk	x11, #0x7261, lsl #32
   12038:      	movk	x11, #0x6863, lsl #48
   1203c:      	cmp	x10, x11
   12040:      	mov	x10, #0x7469            // =29801
   12044:      	movk	x10, #0x6365, lsl #16
   12048:      	movk	x10, #0x7574, lsl #32
   1204c:      	movk	x10, #0x6572, lsl #48
   12050:      	ccmp	x8, x10, #0x0, eq
   12054:      	b.ne	0x12208 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x91f4>
   12058:      	mov	x2, x9
   1205c:      	bl	0x12888 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9874>
   12060:      	ldp	x29, x30, [sp], #0x10
   12064:      	mov	w0, #0x1                // =1
   12068:      	ret
   1206c:      	mov	x12, #0x5043            // =20547
   12070:      	ldr	x10, [x8]
   12074:      	movk	x12, #0x2055, lsl #16
   12078:      	movk	x12, #0x6170, lsl #32
   1207c:      	movk	x12, #0x7472, lsl #48
   12080:      	cmp	x10, x12
   12084:      	b.eq	0x12228 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9214>
   12088:      	mov	x12, #0x6546            // =25926
   1208c:      	ldr	x10, [x8]
   12090:      	movk	x12, #0x7461, lsl #16
   12094:      	movk	x12, #0x7275, lsl #32
   12098:      	movk	x12, #0x7365, lsl #48
   1209c:      	cmp	x10, x12
   120a0:      	b.eq	0x1223c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9228>
   120a4:      	mov	x10, #0x6f42            // =28482
   120a8:      	ldr	x9, [x8]
   120ac:      	movk	x10, #0x6f67, lsl #16
   120b0:      	movk	x10, #0x494d, lsl #32
   120b4:      	movk	x10, #0x5350, lsl #48
   120b8:      	cmp	x9, x10
   120bc:      	b.eq	0x12208 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x91f4>
   120c0:      	mov	x10, #0x6148            // =24904
   120c4:      	ldr	x9, [x8]
   120c8:      	movk	x10, #0x6472, lsl #16
   120cc:      	movk	x10, #0x6177, lsl #32
   120d0:      	movk	x10, #0x6572, lsl #48
   120d4:      	cmp	x9, x10
   120d8:      	b.eq	0x12280 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x926c>
   120dc:      	mov	x9, #0x6552             // =25938
   120e0:      	ldr	x8, [x8]
   120e4:      	movk	x9, #0x6976, lsl #16
   120e8:      	movk	x9, #0x6973, lsl #32
   120ec:      	movk	x9, #0x6e6f, lsl #48
   120f0:      	cmp	x8, x9
   120f4:      	b.ne	0x12208 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x91f4>
   120f8:      	add	x8, x1, x11
   120fc:      	ldr	x9, [x2, #0x8]
   12100:      	mov	x10, x0
   12104:      	cmp	x8, #0x9
   12108:      	b.ls	0x1229c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9288>
   1210c:      	mov	w8, #0x9                // =9
   12110:      	b	0x122a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9290>
   12114:      	mov	x11, #0x5043            // =20547
   12118:      	ldr	x10, [x8]
   1211c:      	ldr	w8, [x8, #0x8]
   12120:      	movk	x11, #0x2055, lsl #16
   12124:      	movk	x11, #0x6572, lsl #32
   12128:      	movk	x11, #0x6976, lsl #48
   1212c:      	cmp	x10, x11
   12130:      	mov	w10, #0x6973            // =26995
   12134:      	movk	w10, #0x6e6f, lsl #16
   12138:      	ccmp	w8, w10, #0x0, eq
   1213c:      	b.ne	0x12208 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x91f4>
   12140:      	mov	x2, x9
   12144:      	bl	0x12770 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x975c>
   12148:      	ldp	x29, x30, [sp], #0x10
   1214c:      	mov	w0, #0x1                // =1
   12150:      	ret
   12154:      	mov	x10, #0x7270            // =29296
   12158:      	ldr	x9, [x8]
   1215c:      	ldrb	w8, [x8, #0x8]
   12160:      	movk	x10, #0x636f, lsl #16
   12164:      	movk	x10, #0x7365, lsl #32
   12168:      	movk	x10, #0x6f73, lsl #48
   1216c:      	cmp	x9, x10
   12170:      	mov	w9, #0x72               // =114
   12174:      	ccmp	w8, w9, #0x0, eq
   12178:      	b.ne	0x12208 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x91f4>
   1217c:      	cmp	x0, x14
   12180:      	b.eq	0x12250 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x923c>
   12184:      	mov	w8, wzr
   12188:      	mov	w9, #0xa                // =10
   1218c:      	ldrb	w10, [x0]
   12190:      	sub	w10, w10, #0x30
   12194:      	cmp	w10, #0xa
   12198:      	b.hi	0x12254 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9240>
   1219c:      	madd	w8, w8, w9, w10
   121a0:      	add	x0, x0, #0x1
   121a4:      	cmp	x0, x1
   121a8:      	b.ne	0x1218c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9178>
   121ac:      	b	0x12254 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9240>
   121b0:      	mov	x10, #0x5043            // =20547
   121b4:      	ldr	x11, [x8]
   121b8:      	ldur	x12, [x8, #0x7]
   121bc:      	movk	x10, #0x2055, lsl #16
   121c0:      	movk	x10, #0x6d69, lsl #32
   121c4:      	movk	x10, #0x6c70, lsl #48
   121c8:      	cmp	x11, x10
   121cc:      	mov	x11, #0x656c            // =25964
   121d0:      	movk	x11, #0x656d, lsl #16
   121d4:      	movk	x11, #0x746e, lsl #32
   121d8:      	movk	x11, #0x7265, lsl #48
   121dc:      	ccmp	x12, x11, #0x0, eq
   121e0:      	b.eq	0x12214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9200>
   121e4:      	ldr	x11, [x8]
   121e8:      	ldur	x8, [x8, #0x7]
   121ec:      	cmp	x11, x10
   121f0:      	mov	x10, #0x656c            // =25964
   121f4:      	movk	x10, #0x656d, lsl #16
   121f8:      	movk	x10, #0x746e, lsl #32
   121fc:      	movk	x10, #0x726f, lsl #48
   12200:      	ccmp	x8, x10, #0x0, eq
   12204:      	b.eq	0x12214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9200>
   12208:      	ldp	x29, x30, [sp], #0x10
   1220c:      	mov	w0, #0x1                // =1
   12210:      	ret
   12214:      	mov	x2, x9
   12218:      	bl	0x127cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x97b8>
   1221c:      	ldp	x29, x30, [sp], #0x10
   12220:      	mov	w0, #0x1                // =1
   12224:      	ret
   12228:      	mov	x2, x9
   1222c:      	bl	0x122c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x92ac>
   12230:      	ldp	x29, x30, [sp], #0x10
   12234:      	mov	w0, #0x1                // =1
   12238:      	ret
   1223c:      	mov	x2, x9
   12240:      	bl	0x1237c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9368>
   12244:      	ldp	x29, x30, [sp], #0x10
   12248:      	mov	w0, #0x1                // =1
   1224c:      	ret
   12250:      	mov	w8, wzr
   12254:      	cmp	w8, w13
   12258:      	b.hs	0x12270 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x925c>
   1225c:      	mov	w9, #0x38               // =56
   12260:      	umaddl	x9, w8, w9, x12
   12264:      	ldr	w10, [x9, #0x34]
   12268:      	orr	w10, w10, #0x200000
   1226c:      	str	w10, [x9, #0x34]
   12270:      	str	w8, [x2, #0x10]
   12274:      	ldp	x29, x30, [sp], #0x10
   12278:      	mov	w0, #0x1                // =1
   1227c:      	ret
   12280:      	add	x8, x1, x11
   12284:      	ldr	x9, [x2]
   12288:      	mov	x10, x0
   1228c:      	cmp	x8, #0x40
   12290:      	b.ls	0x1229c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9288>
   12294:      	mov	w8, #0x40               // =64
   12298:      	b	0x122a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9290>
   1229c:      	add	x12, x9, x1
   122a0:      	strb	wzr, [x12, x11]
   122a4:      	mov	x0, x9
   122a8:      	mov	x1, x10
   122ac:      	mov	x2, x8
   122b0:      	bl	0x1d540 <memcpy@plt>
   122b4:      	ldp	x29, x30, [sp], #0x10
   122b8:      	mov	w0, #0x1                // =1
   122bc:      	ret
   122c0:      	sub	x8, x1, x0
   122c4:      	sub	x8, x8, #0x6
   122c8:      	cmn	x8, #0x3
   122cc:      	b.lo	0x12378 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9364>
   122d0:      	ldrb	w8, [x0]
   122d4:      	cmp	w8, #0x30
   122d8:      	b.ne	0x12378 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9364>
   122dc:      	ldrb	w8, [x0, #0x1]
   122e0:      	cmp	w8, #0x78
   122e4:      	b.ne	0x12378 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9364>
   122e8:      	add	x8, x0, #0x2
   122ec:      	cmp	x8, x1
   122f0:      	b.eq	0x12354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9340>
   122f4:      	mov	w9, wzr
   122f8:      	b	0x12314 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9300>
   122fc:      	mov	w11, #-0x30             // =-48
   12300:      	add	w10, w11, w10
   12304:      	add	x8, x8, #0x1
   12308:      	add	w9, w10, w9, lsl #4
   1230c:      	cmp	x8, x1
   12310:      	b.eq	0x1234c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9338>
   12314:      	ldrb	w10, [x8]
   12318:      	sub	w11, w10, #0x30
   1231c:      	cmp	w11, #0xa
   12320:      	b.lo	0x122fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x92e8>
   12324:      	sub	w11, w10, #0x41
   12328:      	cmp	w11, #0x6
   1232c:      	b.hs	0x12338 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9324>
   12330:      	mov	w11, #-0x37             // =-55
   12334:      	b	0x12300 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x92ec>
   12338:      	sub	w11, w10, #0x61
   1233c:      	cmp	w11, #0x5
   12340:      	b.hi	0x12378 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9364>
   12344:      	mov	w11, #-0x57             // =-87
   12348:      	b	0x12300 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x92ec>
   1234c:      	ubfiz	w8, w9, #4, #12
   12350:      	b	0x12358 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9344>
   12354:      	mov	w8, wzr
   12358:      	ldr	w9, [x2, #0xc]
   1235c:      	ldr	w10, [x2, #0x34]
   12360:      	mov	w11, #0x280000          // =2621440
   12364:      	and	w9, w9, #0xffff000f
   12368:      	orr	w8, w9, w8
   1236c:      	orr	w9, w10, w11
   12370:      	str	w8, [x2, #0xc]
   12374:      	str	w9, [x2, #0x34]
   12378:      	ret
   1237c:      	stp	x29, x30, [sp, #-0x60]!
   12380:      	stp	x28, x27, [sp, #0x10]
   12384:      	stp	x26, x25, [sp, #0x20]
   12388:      	stp	x24, x23, [sp, #0x30]
   1238c:      	stp	x22, x21, [sp, #0x40]
   12390:      	stp	x20, x19, [sp, #0x50]
   12394:      	ldr	w15, [x2, #0x34]
   12398:      	mov	x30, #0x7361            // =29537
   1239c:      	mov	x24, #0x7361            // =29537
   123a0:      	ldp	w13, w14, [x2, #0x4]
   123a4:      	movk	x30, #0x6d69, lsl #16
   123a8:      	movk	x24, #0x6d69, lsl #16
   123ac:      	mov	w8, #0x646d             // =25709
   123b0:      	mov	w9, #0x7361             // =29537
   123b4:      	orr	w16, w15, #0x600000
   123b8:      	mov	w15, #0x6873            // =26739
   123bc:      	mov	w17, #0x6873            // =26739
   123c0:      	mov	w3, #0x6366             // =25446
   123c4:      	mov	w5, #0x6d70             // =28016
   123c8:      	mov	w7, #0x7263             // =29283
   123cc:      	mov	w21, #0x7063            // =28771
   123d0:      	mov	w26, #0x7665            // =30309
   123d4:      	mov	w27, #0x7473            // =29811
   123d8:      	mov	w28, #0x7461            // =29793
   123dc:      	mov	w29, #0x696d            // =26989
   123e0:      	movk	x30, #0x7264, lsl #32
   123e4:      	movk	x24, #0x6664, lsl #32
   123e8:      	mov	w23, #0x736a            // =29546
   123ec:      	movk	w8, #0x7068, lsl #16
   123f0:      	movk	w9, #0x6d69, lsl #16
   123f4:      	mov	w10, #0x7066            // =28774
   123f8:      	mov	w11, #0x6561            // =25953
   123fc:      	mov	w12, #0x73              // =115
   12400:      	movk	w15, #0x3161, lsl #16
   12404:      	sub	x25, x1, #0x1
   12408:      	movk	w17, #0x3261, lsl #16
   1240c:      	movk	w3, #0x616d, lsl #16
   12410:      	movk	w5, #0x6c75, lsl #16
   12414:      	mov	w6, #0x6c               // =108
   12418:      	movk	w7, #0x3363, lsl #16
   1241c:      	mov	w19, #0x32              // =50
   12420:      	mov	w20, #0x64              // =100
   12424:      	movk	w21, #0x6975, lsl #16
   12428:      	movk	w26, #0x7374, lsl #16
   1242c:      	movk	w27, #0x6d72, lsl #16
   12430:      	movk	w28, #0x6d6f, lsl #16
   12434:      	movk	w29, #0x7363, lsl #16
   12438:      	movk	x30, #0x6d64, lsl #48
   1243c:      	movk	x24, #0x6d68, lsl #48
   12440:      	movk	w23, #0x7663, lsl #16
   12444:      	str	w16, [x2, #0x34]
   12448:      	b	0x12458 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9444>
   1244c:      	add	x0, x16, x4
   12450:      	cmp	x4, #0x1
   12454:      	b.eq	0x126dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x96c8>
   12458:      	add	x4, x0, #0x1
   1245c:      	cmp	x4, x1
   12460:      	b.eq	0x124bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x94a8>
   12464:      	ldrb	w16, [x4], #0x1
   12468:      	cmp	w16, #0x20
   1246c:      	b.ne	0x1245c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9448>
   12470:      	sub	x16, x4, #0x2
   12474:      	sub	x4, x4, #0x1
   12478:      	sub	x4, x4, x0
   1247c:      	cmp	x4, #0x4
   12480:      	b.le	0x124d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x94bc>
   12484:      	cmp	x4, #0x5
   12488:      	b.eq	0x1253c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9528>
   1248c:      	cmp	x4, #0x7
   12490:      	b.eq	0x125e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x95cc>
   12494:      	cmp	x4, #0x8
   12498:      	b.ne	0x126a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x968c>
   1249c:      	ldr	x4, [x0]
   124a0:      	cmp	x4, x30
   124a4:      	b.eq	0x12648 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9634>
   124a8:      	ldr	x0, [x0]
   124ac:      	cmp	x0, x24
   124b0:      	b.ne	0x126a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x968c>
   124b4:      	orr	w13, w13, #0x800000
   124b8:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   124bc:      	mov	x16, x25
   124c0:      	mov	x4, x1
   124c4:      	sub	x4, x1, x0
   124c8:      	cmp	x4, #0x4
   124cc:      	b.gt	0x12484 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9470>
   124d0:      	cmp	x4, #0x2
   124d4:      	b.eq	0x125cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x95b8>
   124d8:      	cmp	x4, #0x3
   124dc:      	b.eq	0x12624 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9610>
   124e0:      	cmp	x4, #0x4
   124e4:      	b.ne	0x126a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x968c>
   124e8:      	ldr	w4, [x0]
   124ec:      	cmp	w4, w15
   124f0:      	b.eq	0x12650 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x963c>
   124f4:      	ldr	w4, [x0]
   124f8:      	cmp	w4, w17
   124fc:      	b.eq	0x12668 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9654>
   12500:      	ldr	w4, [x0]
   12504:      	add	w22, w8, #0xbf9
   12508:      	cmp	w4, w22
   1250c:      	b.eq	0x12680 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x966c>
   12510:      	ldr	w4, [x0]
   12514:      	cmp	w4, w3
   12518:      	b.eq	0x12690 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x967c>
   1251c:      	ldr	w0, [x0]
   12520:      	mov	w4, #0x3869             // =14441
   12524:      	movk	w4, #0x6d6d, lsl #16
   12528:      	cmp	w0, w4
   1252c:      	b.ne	0x126a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x968c>
   12530:      	orr	w14, w14, #0x2000
   12534:      	str	w14, [x2, #0x8]
   12538:      	b	0x126a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x968c>
   1253c:      	ldr	w4, [x0]
   12540:      	ldrb	w22, [x0, #0x4]
   12544:      	cmp	w4, w5
   12548:      	ccmp	w22, w6, #0x0, eq
   1254c:      	b.eq	0x12640 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x962c>
   12550:      	ldr	w4, [x0]
   12554:      	ldrb	w22, [x0, #0x4]
   12558:      	cmp	w4, w7
   1255c:      	ccmp	w22, w19, #0x0, eq
   12560:      	b.eq	0x12660 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x964c>
   12564:      	ldr	w4, [x0]
   12568:      	ldrb	w22, [x0, #0x4]
   1256c:      	cmp	w4, w9
   12570:      	ccmp	w22, w20, #0x0, eq
   12574:      	b.eq	0x12678 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9664>
   12578:      	ldr	w4, [x0]
   1257c:      	ldrb	w22, [x0, #0x4]
   12580:      	cmp	w4, w21
   12584:      	ccmp	w22, w20, #0x0, eq
   12588:      	b.eq	0x12688 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9674>
   1258c:      	ldr	w4, [x0]
   12590:      	ldrb	w22, [x0, #0x4]
   12594:      	cmp	w4, w23
   12598:      	mov	w4, #0x74               // =116
   1259c:      	ccmp	w22, w4, #0x0, eq
   125a0:      	b.eq	0x12698 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9684>
   125a4:      	ldr	w4, [x0]
   125a8:      	mov	w22, #0x726c            // =29292
   125ac:      	ldrb	w0, [x0, #0x4]
   125b0:      	movk	w22, #0x7063, lsl #16
   125b4:      	cmp	w4, w22
   125b8:      	mov	w4, #0x63               // =99
   125bc:      	ccmp	w0, w4, #0x0, eq
   125c0:      	b.ne	0x126a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x968c>
   125c4:      	orr	w13, w13, #0x8000
   125c8:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   125cc:      	ldrh	w0, [x0]
   125d0:      	cmp	w0, w10
   125d4:      	b.ne	0x126a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x968c>
   125d8:      	orr	w13, w13, #0x1
   125dc:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   125e0:      	ldr	w4, [x0]
   125e4:      	ldur	w22, [x0, #0x3]
   125e8:      	cmp	w4, w26
   125ec:      	ccmp	w22, w27, #0x0, eq
   125f0:      	b.eq	0x12658 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9644>
   125f4:      	ldr	w4, [x0]
   125f8:      	ldur	w22, [x0, #0x3]
   125fc:      	cmp	w4, w28
   12600:      	ccmp	w22, w29, #0x0, eq
   12604:      	b.eq	0x12670 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x965c>
   12608:      	ldr	w4, [x0]
   1260c:      	ldur	w0, [x0, #0x3]
   12610:      	cmp	w4, w9
   12614:      	ccmp	w0, w8, #0x0, eq
   12618:      	b.ne	0x126a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x968c>
   1261c:      	orr	w13, w13, #0x400
   12620:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   12624:      	ldrh	w4, [x0]
   12628:      	ldrb	w0, [x0, #0x2]
   1262c:      	cmp	w4, w11
   12630:      	ccmp	w0, w12, #0x0, eq
   12634:      	b.ne	0x126a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x968c>
   12638:      	orr	w13, w13, #0x8
   1263c:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   12640:      	orr	w13, w13, #0x10
   12644:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   12648:      	orr	w13, w13, #0x1000
   1264c:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   12650:      	orr	w13, w13, #0x20
   12654:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   12658:      	orr	w13, w13, #0x4
   1265c:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   12660:      	orr	w13, w13, #0x80
   12664:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   12668:      	orr	w13, w13, #0x40
   1266c:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   12670:      	orr	w13, w13, #0x100
   12674:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   12678:      	orr	w13, w13, #0x2
   1267c:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   12680:      	orr	w13, w13, #0x200
   12684:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   12688:      	orr	w13, w13, #0x800
   1268c:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   12690:      	orr	w13, w13, #0x4000
   12694:      	b	0x1269c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9688>
   12698:      	orr	w13, w13, #0x2000
   1269c:      	str	w13, [x2, #0x4]
   126a0:      	add	x0, x16, #0x1
   126a4:      	cmp	x0, x1
   126a8:      	b.eq	0x126dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x96c8>
   126ac:      	sub	x0, x1, x16
   126b0:      	mov	w4, #0x1                // =1
   126b4:      	ldrb	w22, [x16, x4]
   126b8:      	cmp	w22, #0x20
   126bc:      	b.ne	0x1244c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9438>
   126c0:      	add	x4, x4, #0x1
   126c4:      	cmp	x0, x4
   126c8:      	b.ne	0x126b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x96a0>
   126cc:      	mov	x4, x0
   126d0:      	mov	x0, x1
   126d4:      	cmp	x4, #0x1
   126d8:      	b.ne	0x12458 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9444>
   126dc:      	ldp	x20, x19, [sp, #0x50]
   126e0:      	ldp	x22, x21, [sp, #0x40]
   126e4:      	ldp	x24, x23, [sp, #0x30]
   126e8:      	ldp	x26, x25, [sp, #0x20]
   126ec:      	ldp	x28, x27, [sp, #0x10]
   126f0:      	ldp	x29, x30, [sp], #0x60
   126f4:      	ret
   126f8:      	sub	x8, x1, x0
   126fc:      	cmp	x8, #0x3
   12700:      	b.ne	0x1276c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9758>
   12704:      	ldrb	w8, [x0]
   12708:      	cmp	w8, #0x30
   1270c:      	b.ne	0x1276c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9758>
   12710:      	ldrb	w8, [x0, #0x1]
   12714:      	cmp	w8, #0x78
   12718:      	b.ne	0x1276c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9758>
   1271c:      	ldrb	w9, [x0, #0x2]
   12720:      	sub	w8, w9, #0x30
   12724:      	cmp	w8, #0xa
   12728:      	b.lo	0x12750 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x973c>
   1272c:      	sub	w8, w9, #0x41
   12730:      	cmp	w8, #0x5
   12734:      	b.hi	0x12740 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x972c>
   12738:      	sub	w8, w9, #0x37
   1273c:      	b	0x12750 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x973c>
   12740:      	sub	w8, w9, #0x61
   12744:      	cmp	w8, #0x5
   12748:      	b.hi	0x1276c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9758>
   1274c:      	sub	w8, w9, #0x57
   12750:      	ldr	w9, [x2, #0xc]
   12754:      	ldr	w10, [x2, #0x34]
   12758:      	bfi	w9, w8, #20, #4
   1275c:      	mov	w8, #0x240000           // =2359296
   12760:      	orr	w8, w10, w8
   12764:      	str	w9, [x2, #0xc]
   12768:      	str	w8, [x2, #0x34]
   1276c:      	ret
   12770:      	cmp	x0, x1
   12774:      	b.eq	0x127a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9794>
   12778:      	mov	w8, wzr
   1277c:      	mov	w9, #0xa                // =10
   12780:      	ldrb	w10, [x0]
   12784:      	sub	w10, w10, #0x30
   12788:      	cmp	w10, #0x9
   1278c:      	b.hi	0x127c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x97b4>
   12790:      	madd	w8, w8, w9, w10
   12794:      	add	x0, x0, #0x1
   12798:      	cmp	x0, x1
   1279c:      	b.ne	0x12780 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x976c>
   127a0:      	and	w8, w8, #0xf
   127a4:      	b	0x127ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9798>
   127a8:      	mov	w8, wzr
   127ac:      	ldr	w9, [x2, #0xc]
   127b0:      	ldr	w10, [x2, #0x34]
   127b4:      	and	w9, w9, #0xfffffff0
   127b8:      	orr	w8, w9, w8
   127bc:      	orr	w9, w10, #0x300000
   127c0:      	str	w8, [x2, #0xc]
   127c4:      	str	w9, [x2, #0x34]
   127c8:      	ret
   127cc:      	sub	x8, x1, x0
   127d0:      	sub	x8, x8, #0x3
   127d4:      	cmp	x8, #0x1
   127d8:      	b.hi	0x12884 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9870>
   127dc:      	ldrb	w8, [x0]
   127e0:      	cmp	w8, #0x30
   127e4:      	b.ne	0x12884 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9870>
   127e8:      	ldrb	w8, [x0, #0x1]
   127ec:      	cmp	w8, #0x78
   127f0:      	b.ne	0x12884 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9870>
   127f4:      	add	x8, x0, #0x2
   127f8:      	cmp	x8, x1
   127fc:      	b.eq	0x12860 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x984c>
   12800:      	mov	w9, wzr
   12804:      	b	0x12820 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x980c>
   12808:      	mov	w11, #-0x30             // =-48
   1280c:      	add	w10, w11, w10
   12810:      	add	x8, x8, #0x1
   12814:      	add	w9, w10, w9, lsl #4
   12818:      	cmp	x8, x1
   1281c:      	b.eq	0x12858 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9844>
   12820:      	ldrb	w10, [x8]
   12824:      	sub	w11, w10, #0x30
   12828:      	cmp	w11, #0xa
   1282c:      	b.lo	0x12808 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x97f4>
   12830:      	sub	w11, w10, #0x41
   12834:      	cmp	w11, #0x6
   12838:      	b.hs	0x12844 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9830>
   1283c:      	mov	w11, #-0x37             // =-55
   12840:      	b	0x1280c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x97f8>
   12844:      	sub	w11, w10, #0x61
   12848:      	cmp	w11, #0x5
   1284c:      	b.hi	0x12884 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9870>
   12850:      	mov	w11, #-0x57             // =-87
   12854:      	b	0x1280c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x97f8>
   12858:      	lsl	w8, w9, #24
   1285c:      	b	0x12864 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9850>
   12860:      	mov	w8, wzr
   12864:      	ldr	w9, [x2, #0xc]
   12868:      	ldr	w10, [x2, #0x34]
   1286c:      	mov	w11, #0x220000          // =2228224
   12870:      	and	w9, w9, #0xffffff
   12874:      	orr	w8, w9, w8
   12878:      	orr	w9, w10, w11
   1287c:      	str	w8, [x2, #0xc]
   12880:      	str	w9, [x2, #0x34]
   12884:      	ret
   12888:      	sub	x9, x1, x0
   1288c:      	cmp	x9, #0x7
   12890:      	b.ne	0x128b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x98a4>
   12894:      	ldr	w8, [x0]
   12898:      	mov	w11, #0x4141            // =16705
   1289c:      	ldur	w10, [x0, #0x3]
   128a0:      	movk	w11, #0x6372, lsl #16
   128a4:      	cmp	w8, w11
   128a8:      	mov	w8, #0x6863             // =26723
   128ac:      	movk	w8, #0x3436, lsl #16
   128b0:      	ccmp	w10, w8, #0x0, eq
   128b4:      	b.eq	0x1292c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9918>
   128b8:      	cmp	x0, x1
   128bc:      	b.eq	0x12914 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9900>
   128c0:      	mov	w8, wzr
   128c4:      	add	x10, x0, x9
   128c8:      	mov	w11, #0xa               // =10
   128cc:      	mov	x9, x0
   128d0:      	ldrb	w12, [x9]
   128d4:      	sub	w12, w12, #0x30
   128d8:      	cmp	w12, #0x9
   128dc:      	b.hi	0x128f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x98e0>
   128e0:      	madd	w8, w8, w11, w12
   128e4:      	add	x9, x9, #0x1
   128e8:      	cmp	x9, x1
   128ec:      	b.ne	0x128d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x98bc>
   128f0:      	mov	x9, x10
   128f4:      	cmp	x9, x0
   128f8:      	b.eq	0x12914 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9900>
   128fc:      	cbz	w8, 0x12914 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9900>
   12900:      	ldr	w9, [x2, #0x34]
   12904:      	mov	w10, #0x210000          // =2162688
   12908:      	str	w8, [x2]
   1290c:      	orr	w8, w9, w10
   12910:      	str	w8, [x2, #0x34]
   12914:      	add	x8, x2, #0xc
   12918:      	mov	w9, #0xf0000            // =983040
   1291c:      	ldr	w10, [x8]
   12920:      	orr	w9, w10, w9
   12924:      	str	w9, [x8]
   12928:      	ret
   1292c:      	ldr	w8, [x2, #0xc]
   12930:      	mov	w9, #0x8                // =8
   12934:      	str	w9, [x2]
   12938:      	mov	w9, #0x210000           // =2162688
   1293c:      	orr	w8, w8, #0xf0000
   12940:      	str	w8, [x2, #0xc]
   12944:      	add	x8, x2, #0x34
   12948:      	ldr	w10, [x8]
   1294c:      	orr	w9, w10, w9
   12950:      	str	w9, [x8]
   12954:      	ret
   12958:      	sub	sp, sp, #0x30
   1295c:      	stp	x29, x30, [sp, #0x20]
   12960:      	add	x29, sp, #0x20
   12964:      	mrs	x8, TPIDR_EL0
   12968:      	ldr	x9, [x8, #0x28]
   1296c:      	cmp	w0, #0x6
   12970:      	stur	x9, [x29, #-0x8]
   12974:      	b.eq	0x129c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x99b0>
   12978:      	cmp	w0, #0x8
   1297c:      	b.eq	0x129a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9994>
   12980:      	cmp	w0, #0xa
   12984:      	b.ne	0x12b50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b3c>
   12988:      	movi	v0.2s, #0x4
   1298c:      	mov	w10, #0x2               // =2
   12990:      	mov	w9, #0x2                // =2
   12994:      	str	d0, [sp, #0x8]
   12998:      	add	x11, sp, #0x8
   1299c:      	str	w9, [x11, x10, lsl #2]
   129a0:      	cbnz	w1, 0x129e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x99cc>
   129a4:      	b	0x12bb0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b9c>
   129a8:      	mov	w9, #0x4                // =4
   129ac:      	str	w9, [sp, #0x8]
   129b0:      	mov	w10, #0x1               // =1
   129b4:      	add	x11, sp, #0x8
   129b8:      	str	w9, [x11, x10, lsl #2]
   129bc:      	cbnz	w1, 0x129e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x99cc>
   129c0:      	b	0x12bb0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b9c>
   129c4:      	mov	w9, #0x4                // =4
   129c8:      	str	w9, [sp, #0x8]
   129cc:      	mov	w9, #0x2                // =2
   129d0:      	mov	w10, #0x1               // =1
   129d4:      	add	x11, sp, #0x8
   129d8:      	str	w9, [x11, x10, lsl #2]
   129dc:      	cbz	w1, 0x12bb0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b9c>
   129e0:      	mov	x12, xzr
   129e4:      	mov	w3, wzr
   129e8:      	mov	w14, wzr
   129ec:      	mov	w9, w1
   129f0:      	add	x13, x2, #0x20
   129f4:      	b	0x12a20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9a0c>
   129f8:      	mov	w17, wzr
   129fc:      	ldr	w3, [x11, w14, uxtw #2]
   12a00:      	ubfx	w5, w0, #10, #1
   12a04:      	add	w14, w14, #0x1
   12a08:      	mov	w10, w12
   12a0c:      	sub	w3, w3, #0x1
   12a10:      	add	x12, x12, #0x1
   12a14:      	add	x13, x13, #0x38
   12a18:      	cmp	x9, x12
   12a1c:      	b.eq	0x12b58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b44>
   12a20:      	ldr	w0, [x13, #0x14]
   12a24:      	tbz	w0, #0xc, 0x12a10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x99fc>
   12a28:      	cbz	w3, 0x12a48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9a34>
   12a2c:      	tbz	w5, #0x0, 0x12a5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9a48>
   12a30:      	tbz	w0, #0xa, 0x12b50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b3c>
   12a34:      	ldr	w0, [x13]
   12a38:      	cmp	w0, w10
   12a3c:      	b.ne	0x12b50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b3c>
   12a40:      	mov	w5, #0x1                // =1
   12a44:      	b	0x12a0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x99f8>
   12a48:      	tbz	w0, #0xa, 0x129f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x99e4>
   12a4c:      	ldr	w10, [x13]
   12a50:      	cmp	x12, x10
   12a54:      	b.eq	0x129fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x99e8>
   12a58:      	b	0x12b50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b3c>
   12a5c:      	tbnz	w0, #0xa, 0x12b50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b3c>
   12a60:      	tbz	w0, #0x3, 0x12a80 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9a6c>
   12a64:      	ldr	w5, [x13, #0xc]
   12a68:      	tbnz	w17, #0x3, 0x12a78 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9a64>
   12a6c:      	orr	w17, w17, #0x8
   12a70:      	mov	w15, w5
   12a74:      	b	0x12a80 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9a6c>
   12a78:      	cmp	w15, w5
   12a7c:      	b.ne	0x12b50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b3c>
   12a80:      	tbz	w0, #0x2, 0x12aa0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9a8c>
   12a84:      	ldr	w5, [x13, #0x8]
   12a88:      	tbnz	w17, #0x2, 0x12a98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9a84>
   12a8c:      	orr	w17, w17, #0x4
   12a90:      	mov	w16, w5
   12a94:      	b	0x12aa0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9a8c>
   12a98:      	cmp	w16, w5
   12a9c:      	b.ne	0x12b50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b3c>
   12aa0:      	tbz	w0, #0x11, 0x12ac8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9ab4>
   12aa4:      	ldur	w5, [x13, #-0x14]
   12aa8:      	tbnz	w17, #0x11, 0x12abc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9aa8>
   12aac:      	bfxil	w5, w4, #0, #24
   12ab0:      	orr	w17, w17, #0x20000
   12ab4:      	mov	w4, w5
   12ab8:      	b	0x12ac8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9ab4>
   12abc:      	eor	w5, w5, w4
   12ac0:      	lsr	w5, w5, #24
   12ac4:      	cbnz	w5, 0x12b50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b3c>
   12ac8:      	tbz	w0, #0x12, 0x12af0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9adc>
   12acc:      	ldur	w5, [x13, #-0x14]
   12ad0:      	tbnz	w17, #0x12, 0x12ae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9ad0>
   12ad4:      	lsr	w5, w5, #20
   12ad8:      	orr	w17, w17, #0x40000
   12adc:      	bfi	w4, w5, #20, #4
   12ae0:      	b	0x12af0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9adc>
   12ae4:      	eor	w5, w5, w4
   12ae8:      	tst	w5, #0xf00000
   12aec:      	b.ne	0x12b50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b3c>
   12af0:      	tbz	w0, #0x13, 0x12b18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b04>
   12af4:      	ldur	w5, [x13, #-0x14]
   12af8:      	tbnz	w17, #0x13, 0x12b0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9af8>
   12afc:      	lsr	w5, w5, #4
   12b00:      	orr	w17, w17, #0x80000
   12b04:      	bfi	w4, w5, #4, #12
   12b08:      	b	0x12b18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b04>
   12b0c:      	eor	w5, w5, w4
   12b10:      	tst	w5, #0xfff0
   12b14:      	b.ne	0x12b50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b3c>
   12b18:      	tbnz	w0, #0x14, 0x12b24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b10>
   12b1c:      	mov	w5, wzr
   12b20:      	b	0x12a0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x99f8>
   12b24:      	ldur	w0, [x13, #-0x14]
   12b28:      	mov	w5, wzr
   12b2c:      	tbnz	w17, #0x14, 0x12b3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b28>
   12b30:      	bfxil	w4, w0, #0, #4
   12b34:      	orr	w17, w17, #0x100000
   12b38:      	b	0x12a0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x99f8>
   12b3c:      	eor	w0, w0, w4
   12b40:      	tst	w0, #0xf
   12b44:      	mov	w0, wzr
   12b48:      	b.eq	0x12a0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x99f8>
   12b4c:      	b	0x12bb4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9ba0>
   12b50:      	mov	w0, wzr
   12b54:      	b	0x12bb4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9ba0>
   12b58:      	cbz	w1, 0x12bb0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b9c>
   12b5c:      	mov	x11, xzr
   12b60:      	mov	w13, wzr
   12b64:      	mov	w14, wzr
   12b68:      	add	x12, x2, #0x34
   12b6c:      	add	x15, sp, #0x8
   12b70:      	b	0x12b94 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b80>
   12b74:      	orr	w16, w16, #0x400
   12b78:      	stur	w10, [x12, #-0x14]
   12b7c:      	str	w16, [x12]
   12b80:      	sub	w13, w13, #0x1
   12b84:      	add	x11, x11, #0x1
   12b88:      	add	x12, x12, #0x38
   12b8c:      	cmp	x9, x11
   12b90:      	b.eq	0x12bb0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b9c>
   12b94:      	ldr	w16, [x12]
   12b98:      	tbz	w16, #0xc, 0x12b84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b70>
   12b9c:      	cbnz	w13, 0x12b74 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b60>
   12ba0:      	ldr	w13, [x15, w14, uxtw #2]
   12ba4:      	add	w14, w14, #0x1
   12ba8:      	mov	w10, w11
   12bac:      	b	0x12b80 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9b6c>
   12bb0:      	mov	w0, #0x1                // =1
   12bb4:      	ldr	x8, [x8, #0x28]
   12bb8:      	ldur	x9, [x29, #-0x8]
   12bbc:      	cmp	x8, x9
   12bc0:      	b.ne	0x12bd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9bbc>
   12bc4:      	ldp	x29, x30, [sp, #0x20]
   12bc8:      	add	sp, sp, #0x30
   12bcc:      	ret
   12bd0:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   12bd4:      	cbz	w0, 0x12db0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d9c>
   12bd8:      	mov	x8, xzr
   12bdc:      	mov	w2, wzr
   12be0:      	mov	w15, wzr
   12be4:      	mov	w9, w0
   12be8:      	add	x10, x1, #0x34
   12bec:      	mov	w11, #0x1400            // =5120
   12bf0:      	b	0x12c08 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9bf4>
   12bf4:      	mov	w2, #0x1                // =1
   12bf8:      	add	x8, x8, #0x1
   12bfc:      	add	x10, x10, #0x38
   12c00:      	cmp	x9, x8
   12c04:      	b.eq	0x12db0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d9c>
   12c08:      	ldr	w17, [x10]
   12c0c:      	and	w0, w17, w11
   12c10:      	cmp	w0, #0x1, lsl #12       // =0x1000
   12c14:      	b.ne	0x12bf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9be4>
   12c18:      	cbz	w2, 0x12d08 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9cf4>
   12c1c:      	tbz	w17, #0x3, 0x12c3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c28>
   12c20:      	ldur	w0, [x10, #-0x8]
   12c24:      	tbnz	w15, #0x3, 0x12c34 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c20>
   12c28:      	orr	w15, w15, #0x8
   12c2c:      	mov	w14, w0
   12c30:      	b	0x12c3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c28>
   12c34:      	cmp	w14, w0
   12c38:      	b.ne	0x12cec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9cd8>
   12c3c:      	tbz	w17, #0x2, 0x12c5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c48>
   12c40:      	ldur	w0, [x10, #-0xc]
   12c44:      	tbnz	w15, #0x2, 0x12c54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c40>
   12c48:      	orr	w15, w15, #0x4
   12c4c:      	mov	w13, w0
   12c50:      	b	0x12c5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c48>
   12c54:      	cmp	w13, w0
   12c58:      	b.ne	0x12d08 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9cf4>
   12c5c:      	tbz	w17, #0x11, 0x12c84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c70>
   12c60:      	ldur	w0, [x10, #-0x28]
   12c64:      	tbnz	w15, #0x11, 0x12c78 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c64>
   12c68:      	bfxil	w0, w12, #0, #24
   12c6c:      	orr	w15, w15, #0x20000
   12c70:      	mov	w12, w0
   12c74:      	b	0x12c84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c70>
   12c78:      	eor	w0, w0, w12
   12c7c:      	lsr	w0, w0, #24
   12c80:      	cbnz	w0, 0x12d08 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9cf4>
   12c84:      	tbz	w17, #0x12, 0x12cac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c98>
   12c88:      	ldur	w0, [x10, #-0x28]
   12c8c:      	tbnz	w15, #0x12, 0x12ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c8c>
   12c90:      	lsr	w0, w0, #20
   12c94:      	orr	w15, w15, #0x40000
   12c98:      	bfi	w12, w0, #20, #4
   12c9c:      	b	0x12cac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9c98>
   12ca0:      	eor	w0, w0, w12
   12ca4:      	tst	w0, #0xf00000
   12ca8:      	b.ne	0x12d08 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9cf4>
   12cac:      	tbz	w17, #0x13, 0x12cd4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9cc0>
   12cb0:      	ldur	w0, [x10, #-0x28]
   12cb4:      	tbnz	w15, #0x13, 0x12cc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9cb4>
   12cb8:      	lsr	w0, w0, #4
   12cbc:      	orr	w15, w15, #0x80000
   12cc0:      	bfi	w12, w0, #4, #12
   12cc4:      	b	0x12cd4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9cc0>
   12cc8:      	eor	w0, w0, w12
   12ccc:      	tst	w0, #0xfff0
   12cd0:      	b.ne	0x12d08 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9cf4>
   12cd4:      	tbz	w17, #0x14, 0x12d9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d88>
   12cd8:      	ldur	w0, [x10, #-0x28]
   12cdc:      	tbnz	w15, #0x14, 0x12cfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9ce8>
   12ce0:      	bfxil	w12, w0, #0, #4
   12ce4:      	orr	w15, w15, #0x100000
   12ce8:      	b	0x12d9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d88>
   12cec:      	orr	w14, w17, #0x400
   12cf0:      	stur	w8, [x10, #-0x14]
   12cf4:      	str	w14, [x10]
   12cf8:      	b	0x12d28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d14>
   12cfc:      	eor	w0, w0, w12
   12d00:      	tst	w0, #0xf
   12d04:      	b.eq	0x12d9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d88>
   12d08:      	orr	w15, w17, #0x400
   12d0c:      	stur	w8, [x10, #-0x14]
   12d10:      	str	w15, [x10]
   12d14:      	tbnz	w17, #0x3, 0x12d28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d14>
   12d18:      	mov	w15, wzr
   12d1c:      	mov	w16, w8
   12d20:      	tbnz	w17, #0x2, 0x12d38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d24>
   12d24:      	b	0x12d40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d2c>
   12d28:      	ldur	w14, [x10, #-0x8]
   12d2c:      	mov	w16, w8
   12d30:      	mov	w15, #0x8               // =8
   12d34:      	tbz	w17, #0x2, 0x12d40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d2c>
   12d38:      	ldur	w13, [x10, #-0xc]
   12d3c:      	orr	w15, w15, #0x4
   12d40:      	tbnz	w17, #0x11, 0x12d54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d40>
   12d44:      	tbnz	w17, #0x12, 0x12d64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d50>
   12d48:      	tbnz	w17, #0x13, 0x12d78 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d64>
   12d4c:      	tbz	w17, #0x14, 0x12bf4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9be0>
   12d50:      	b	0x12d8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d78>
   12d54:      	ldurb	w0, [x10, #-0x25]
   12d58:      	orr	w15, w15, #0x20000
   12d5c:      	bfi	w12, w0, #24, #8
   12d60:      	tbz	w17, #0x12, 0x12d48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d34>
   12d64:      	ldur	w0, [x10, #-0x28]
   12d68:      	orr	w15, w15, #0x40000
   12d6c:      	lsr	w0, w0, #20
   12d70:      	bfi	w12, w0, #20, #4
   12d74:      	tbz	w17, #0x13, 0x12d4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9d38>
   12d78:      	ldur	w0, [x10, #-0x28]
   12d7c:      	orr	w15, w15, #0x80000
   12d80:      	lsr	w0, w0, #4
   12d84:      	bfi	w12, w0, #4, #12
   12d88:      	tbz	w17, #0x14, 0x12bf4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9be0>
   12d8c:      	ldur	w17, [x10, #-0x28]
   12d90:      	orr	w15, w15, #0x100000
   12d94:      	bfxil	w12, w17, #0, #4
   12d98:      	b	0x12bf4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9be0>
   12d9c:      	orr	w17, w17, #0x400
   12da0:      	add	w2, w2, #0x1
   12da4:      	stur	w16, [x10, #-0x14]
   12da8:      	str	w17, [x10]
   12dac:      	b	0x12bf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9be4>
   12db0:      	ret
   12db4:      	cbz	w0, 0x12e38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9e24>
   12db8:      	mov	w8, w0
   12dbc:      	add	x9, x1, #0x34
   12dc0:      	mov	w10, #0x38              // =56
   12dc4:      	mov	x11, x8
   12dc8:      	b	0x12dd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9dc4>
   12dcc:      	subs	x11, x11, #0x1
   12dd0:      	add	x9, x9, #0x38
   12dd4:      	b.eq	0x12dfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9de8>
   12dd8:      	ldrb	w12, [x9, #0x1]
   12ddc:      	tbz	w12, #0x4, 0x12dcc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9db8>
   12de0:      	ldur	w12, [x9, #-0x14]
   12de4:      	nop
   12de8:      	umaddl	x12, w12, w10, x1
   12dec:      	ldr	w13, [x12, #0x24]
   12df0:      	add	w13, w13, #0x1
   12df4:      	str	w13, [x12, #0x24]
   12df8:      	b	0x12dcc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9db8>
   12dfc:      	cbz	w0, 0x12e38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9e24>
   12e00:      	add	x9, x1, #0x20
   12e04:      	mov	w10, #0x38              // =56
   12e08:      	b	0x12e18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9e04>
   12e0c:      	subs	x8, x8, #0x1
   12e10:      	add	x9, x9, #0x38
   12e14:      	b.eq	0x12e38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9e24>
   12e18:      	ldrb	w11, [x9, #0x15]
   12e1c:      	tbz	w11, #0x4, 0x12e0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9df8>
   12e20:      	ldr	w11, [x9]
   12e24:      	nop
   12e28:      	umaddl	x11, w11, w10, x1
   12e2c:      	ldr	w11, [x11, #0x24]
   12e30:      	str	w11, [x9, #0x4]
   12e34:      	b	0x12e0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9df8>
   12e38:      	ret
   12e3c:      	sub	sp, sp, #0x110
   12e40:      	stp	x29, x30, [sp, #0xb0]
   12e44:      	stp	x28, x27, [sp, #0xc0]
   12e48:      	stp	x26, x25, [sp, #0xd0]
   12e4c:      	stp	x24, x23, [sp, #0xe0]
   12e50:      	stp	x22, x21, [sp, #0xf0]
   12e54:      	stp	x20, x19, [sp, #0x100]
   12e58:      	add	x29, sp, #0xb0
   12e5c:      	mrs	x24, TPIDR_EL0
   12e60:      	mov	x19, x8
   12e64:      	mov	w26, w1
   12e68:      	ldr	x8, [x24, #0x28]
   12e6c:      	mov	w1, #0x40               // =64
   12e70:      	mov	w22, w3
   12e74:      	mov	x21, x0
   12e78:      	stur	x8, [x29, #-0x10]
   12e7c:      	bl	0x1d810 <strnlen@plt>
   12e80:      	mov	x20, x0
   12e84:      	tbz	w22, #0x0, 0x12f10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9efc>
   12e88:      	adrp	x22, 0x4000
   12e8c:      	add	x22, x22, #0x529
   12e90:      	mov	x1, x21
   12e94:      	mov	x0, x22
   12e98:      	mov	x2, x20
   12e9c:      	bl	0x1d8c0 <strncmp@plt>
   12ea0:      	cbnz	w0, 0x12eac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9e98>
   12ea4:      	ldrb	w8, [x22, x20]
   12ea8:      	cbz	w8, 0x131b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa19c>
   12eac:      	adrp	x22, 0x3000
   12eb0:      	add	x22, x22, #0x460
   12eb4:      	mov	x1, x21
   12eb8:      	mov	x0, x22
   12ebc:      	mov	x2, x20
   12ec0:      	bl	0x1d8c0 <strncmp@plt>
   12ec4:      	cbnz	w0, 0x12ed0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9ebc>
   12ec8:      	ldrb	w8, [x22, x20]
   12ecc:      	cbz	w8, 0x131b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa19c>
   12ed0:      	adrp	x22, 0x3000
   12ed4:      	add	x22, x22, #0x9d6
   12ed8:      	mov	x1, x21
   12edc:      	mov	x0, x22
   12ee0:      	mov	x2, x20
   12ee4:      	bl	0x1d8c0 <strncmp@plt>
   12ee8:      	cbnz	w0, 0x12ef4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9ee0>
   12eec:      	ldrb	w8, [x22, x20]
   12ef0:      	cbz	w8, 0x131b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa19c>
   12ef4:      	ldr	x8, [x24, #0x28]
   12ef8:      	ldur	x9, [x29, #-0x10]
   12efc:      	cmp	x8, x9
   12f00:      	b.ne	0x131d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa1c4>
   12f04:      	stp	xzr, xzr, [x19]
   12f08:      	str	wzr, [x19, #0x10]
   12f0c:      	b	0x134b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa4a4>
   12f10:      	add	x22, x21, x20
   12f14:      	cbz	x20, 0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   12f18:      	mov	x25, #0x200             // =512
   12f1c:      	str	w26, [sp, #0x4]
   12f20:      	mov	x26, xzr
   12f24:      	sub	x27, x20, #0x6
   12f28:      	mov	w28, #0x1               // =1
   12f2c:      	movk	x25, #0x1001, lsl #32
   12f30:      	mov	w8, #0x1                // =1
   12f34:      	b	0x12f48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9f34>
   12f38:      	mov	w8, wzr
   12f3c:      	add	x26, x26, #0x1
   12f40:      	cmp	x20, x26
   12f44:      	b.eq	0x13100 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa0ec>
   12f48:      	ldrb	w9, [x21, x26]
   12f4c:      	lsl	x10, x28, x9
   12f50:      	cmp	w9, #0x2c
   12f54:      	and	x10, x10, x25
   12f58:      	ccmp	x10, #0x0, #0x4, ls
   12f5c:      	b.eq	0x12f74 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9f60>
   12f60:      	mov	w8, #0x1                // =1
   12f64:      	add	x26, x26, #0x1
   12f68:      	cmp	x20, x26
   12f6c:      	b.ne	0x12f48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9f34>
   12f70:      	b	0x13100 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa0ec>
   12f74:      	tbz	w8, #0x0, 0x12f38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9f24>
   12f78:      	orr	w8, w9, #0x20
   12f7c:      	sub	w8, w8, #0x61
   12f80:      	cmp	w8, #0x19
   12f84:      	b.hi	0x12f38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9f24>
   12f88:      	add	x0, x21, x26
   12f8c:      	add	x2, sp, #0x8
   12f90:      	mov	x1, x22
   12f94:      	bl	0x1361c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa608>
   12f98:      	tbnz	w0, #0x0, 0x13498 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa484>
   12f9c:      	add	x8, x21, x26
   12fa0:      	add	x23, x8, #0x4
   12fa4:      	cmp	x23, x22
   12fa8:      	b.hi	0x12fc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9fb4>
   12fac:      	ldr	w8, [x21, x26]
   12fb0:      	mov	w9, #-0x20202021        // =-538976289
   12fb4:      	and	w8, w8, w9
   12fb8:      	mov	w9, #0x4154             // =16724
   12fbc:      	movk	w9, #0x4f52, lsl #16
   12fc0:      	cmp	w8, w9
   12fc4:      	b.eq	0x13284 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa270>
   12fc8:      	add	x0, x21, x26
   12fcc:      	add	x2, sp, #0x8
   12fd0:      	mov	x1, x22
   12fd4:      	bl	0x138a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa88c>
   12fd8:      	tbnz	w0, #0x0, 0x13498 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa484>
   12fdc:      	add	x8, x21, x26
   12fe0:      	add	x9, x8, #0x6
   12fe4:      	cmp	x9, x22
   12fe8:      	b.hi	0x13048 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa034>
   12fec:      	ldrb	w9, [x8, #0x2]
   12ff0:      	ldrb	w10, [x8]
   12ff4:      	ldrb	w8, [x8, #0x1]
   12ff8:      	orr	w9, w10, w9, lsl #16
   12ffc:      	orr	w8, w9, w8, lsl #8
   13000:      	mov	w9, #0x4453             // =17491
   13004:      	movk	w9, #0x4d, lsl #16
   13008:      	cmp	w8, w9
   1300c:      	b.ne	0x13048 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa034>
   13010:      	add	x8, x21, x26
   13014:      	ldrb	w8, [x8, #0x3]
   13018:      	sub	w8, w8, #0x30
   1301c:      	cmp	w8, #0x9
   13020:      	b.hi	0x13048 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa034>
   13024:      	ldrb	w9, [x23]
   13028:      	sub	w9, w9, #0x30
   1302c:      	cmp	w9, #0x9
   13030:      	b.hi	0x13048 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa034>
   13034:      	add	x10, x21, x26
   13038:      	ldrb	w10, [x10, #0x5]
   1303c:      	sub	w10, w10, #0x30
   13040:      	cmp	w10, #0x9
   13044:      	b.ls	0x135e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa5cc>
   13048:      	cmp	x27, x26
   1304c:      	b.ne	0x130a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa094>
   13050:      	ldrh	w8, [x21, x26]
   13054:      	mov	w9, #0x4d53             // =19795
   13058:      	cmp	w8, w9
   1305c:      	b.ne	0x130a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa094>
   13060:      	add	x9, x21, x26
   13064:      	ldrb	w8, [x9, #0x2]
   13068:      	sub	w8, w8, #0x30
   1306c:      	cmp	w8, #0x9
   13070:      	b.hi	0x130a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa094>
   13074:      	ldrb	w9, [x9, #0x3]
   13078:      	sub	w9, w9, #0x30
   1307c:      	cmp	w9, #0x9
   13080:      	b.hi	0x130a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa094>
   13084:      	ldrb	w10, [x23]
   13088:      	sub	w10, w10, #0x30
   1308c:      	cmp	w10, #0x9
   13090:      	b.hi	0x130a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa094>
   13094:      	add	x11, x21, x26
   13098:      	ldrb	w11, [x11, #0x5]
   1309c:      	sub	w11, w11, #0x30
   130a0:      	cmp	w11, #0x9
   130a4:      	b.ls	0x135f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa5e4>
   130a8:      	add	x0, x21, x26
   130ac:      	add	x3, sp, #0x8
   130b0:      	mov	x1, x22
   130b4:      	mov	w2, #0x1                // =1
   130b8:      	bl	0x13a28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaa14>
   130bc:      	tbnz	w0, #0x0, 0x13498 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa484>
   130c0:      	add	x0, x21, x26
   130c4:      	add	x2, sp, #0x8
   130c8:      	mov	x1, x22
   130cc:      	bl	0x13ce0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaccc>
   130d0:      	tbnz	w0, #0x0, 0x13498 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa484>
   130d4:      	add	x0, x21, x26
   130d8:      	add	x2, sp, #0x8
   130dc:      	mov	x1, x22
   130e0:      	bl	0x13d98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xad84>
   130e4:      	tbnz	w0, #0x0, 0x13498 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa484>
   130e8:      	add	x0, x21, x26
   130ec:      	add	x2, sp, #0x8
   130f0:      	mov	x1, x22
   130f4:      	bl	0x13e6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xae58>
   130f8:      	tbz	w0, #0x0, 0x12f38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9f24>
   130fc:      	b	0x13498 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa484>
   13100:      	and	x8, x20, #0xfffffffffffffffe
   13104:      	cmp	x8, #0x12
   13108:      	b.ne	0x131dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa1c8>
   1310c:      	ldr	w8, [x21]
   13110:      	mov	w9, #-0x20202021        // =-538976289
   13114:      	ldr	w26, [sp, #0x4]
   13118:      	add	w9, w9, #0x20
   1311c:      	and	w8, w8, w9
   13120:      	mov	w9, #0x4153             // =16723
   13124:      	movk	w9, #0x534d, lsl #16
   13128:      	cmp	w8, w9
   1312c:      	b.ne	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   13130:      	ldr	w8, [x21, #0x4]
   13134:      	mov	w9, #0xdfdf             // =57311
   13138:      	movk	w9, #0xffdf, lsl #16
   1313c:      	and	w8, w8, w9
   13140:      	mov	w9, #0x4e55             // =20053
   13144:      	movk	w9, #0x2047, lsl #16
   13148:      	cmp	w8, w9
   1314c:      	b.ne	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   13150:      	ldr	w8, [x21, #0x8]
   13154:      	mov	w9, #-0x20202021        // =-538976289
   13158:      	add	w9, w9, #0x20
   1315c:      	and	w8, w8, w9
   13160:      	mov	w9, #0x5845             // =22597
   13164:      	movk	w9, #0x4e59, lsl #16
   13168:      	cmp	w8, w9
   1316c:      	b.ne	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   13170:      	ldrb	w8, [x21, #0xc]
   13174:      	ldrb	w9, [x21, #0xd]
   13178:      	orr	w8, w8, w9, lsl #8
   1317c:      	mov	w9, #0xdfdf             // =57311
   13180:      	and	w8, w8, w9
   13184:      	mov	w9, #0x534f             // =21327
   13188:      	cmp	w8, w9
   1318c:      	b.ne	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   13190:      	ldrb	w8, [x21, #0xe]
   13194:      	cmp	w8, #0x20
   13198:      	b.ne	0x132dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa2c8>
   1319c:      	cmp	x20, #0x13
   131a0:      	b.ne	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   131a4:      	ldrb	w8, [x21, #0xf]
   131a8:      	mov	w9, #0xf                // =15
   131ac:      	b	0x132e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa2cc>
   131b0:      	adrp	x8, 0x4000
   131b4:      	mov	w9, #0xd2               // =210
   131b8:      	stur	xzr, [x19, #0xc]
   131bc:      	ldr	d0, [x8, #0xf60]
   131c0:      	str	w9, [x19, #0x8]
   131c4:      	str	d0, [x19]
   131c8:      	ldr	x8, [x24, #0x28]
   131cc:      	ldur	x9, [x29, #-0x10]
   131d0:      	cmp	x8, x9
   131d4:      	b.eq	0x134b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa4a4>
   131d8:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   131dc:      	ldr	w26, [sp, #0x4]
   131e0:      	cmp	x20, #0xd
   131e4:      	b.ne	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   131e8:      	ldrb	w8, [x21]
   131ec:      	and	w8, w8, #0xffffffdf
   131f0:      	cmp	w8, #0x55
   131f4:      	b.ne	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   131f8:      	ldur	w8, [x21, #0x1]
   131fc:      	mov	w9, #-0x20202021        // =-538976289
   13200:      	and	w8, w8, w9
   13204:      	mov	w9, #0x494e             // =18766
   13208:      	movk	w9, #0x4556, lsl #16
   1320c:      	cmp	w8, w9
   13210:      	b.ne	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   13214:      	ldur	w8, [x21, #0x5]
   13218:      	mov	w9, #-0x20202021        // =-538976289
   1321c:      	and	w8, w8, w9
   13220:      	mov	w9, #0x5352             // =21330
   13224:      	movk	w9, #0x4c41, lsl #16
   13228:      	cmp	w8, w9
   1322c:      	b.ne	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   13230:      	ldrb	w8, [x21, #0x9]
   13234:      	sub	w8, w8, #0x30
   13238:      	cmp	w8, #0x9
   1323c:      	b.hi	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   13240:      	ldrb	w9, [x21, #0xa]
   13244:      	sub	w9, w9, #0x30
   13248:      	cmp	w9, #0x9
   1324c:      	b.hi	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   13250:      	ldrb	w10, [x21, #0xb]
   13254:      	sub	w10, w10, #0x30
   13258:      	cmp	w10, #0x9
   1325c:      	b.hi	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   13260:      	ldrb	w11, [x21, #0xc]
   13264:      	sub	w11, w11, #0x30
   13268:      	cmp	w11, #0x9
   1326c:      	b.hi	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   13270:      	mov	w12, #0xa               // =10
   13274:      	madd	w8, w8, w12, w9
   13278:      	adrp	x9, 0x4000
   1327c:      	ldr	d0, [x9, #0xf58]
   13280:      	b	0x13608 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa5f4>
   13284:      	movi	v0.2d, #0000000000000000
   13288:      	adrp	x0, 0x2000
   1328c:      	add	x0, x0, #0xccc
   13290:      	add	x1, sp, #0x20
   13294:      	stp	q0, q0, [sp, #0x20]
   13298:      	stp	q0, q0, [sp, #0x40]
   1329c:      	stp	q0, q0, [sp, #0x60]
   132a0:      	stp	q0, q0, [sp, #0x80]
   132a4:      	bl	0x1d7f0 <__system_property_get@plt>
   132a8:      	cmp	w0, #0x1
   132ac:      	mov	w0, wzr
   132b0:      	b.lt	0x135c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa5b4>
   132b4:      	ldrb	w8, [sp, #0x20]
   132b8:      	cbz	w8, 0x135c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa5b4>
   132bc:      	add	x0, sp, #0x20
   132c0:      	sub	w8, w8, #0x3a
   132c4:      	cmn	w8, #0xb
   132c8:      	b.hi	0x135c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa5b0>
   132cc:      	ldrb	w8, [x0, #0x1]!
   132d0:      	cbnz	w8, 0x132c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa2ac>
   132d4:      	mov	w0, wzr
   132d8:      	b	0x135c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa5b4>
   132dc:      	mov	w9, #0xe                // =14
   132e0:      	sub	w8, w8, #0x30
   132e4:      	cmp	w8, #0x9
   132e8:      	b.hi	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   132ec:      	add	x10, x21, x9
   132f0:      	ldrb	w9, [x10, #0x1]
   132f4:      	sub	w9, w9, #0x30
   132f8:      	cmp	w9, #0x9
   132fc:      	b.hi	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   13300:      	ldrb	w11, [x10, #0x2]
   13304:      	sub	w11, w11, #0x30
   13308:      	cmp	w11, #0x9
   1330c:      	b.hi	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   13310:      	ldrb	w10, [x10, #0x3]
   13314:      	sub	w10, w10, #0x30
   13318:      	cmp	w10, #0x9
   1331c:      	b.hi	0x1333c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa328>
   13320:      	mov	w12, #0xa               // =10
   13324:      	madd	w8, w8, w12, w9
   13328:      	adrp	x9, 0x4000
   1332c:      	ldr	d0, [x9, #0xf58]
   13330:      	madd	w8, w8, w12, w11
   13334:      	madd	w8, w8, w12, w10
   13338:      	b	0x13610 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa5fc>
   1333c:      	ldp	w25, w23, [x21]
   13340:      	sub	x8, x20, #0xd
   13344:      	cmp	x8, #0x1
   13348:      	b.hi	0x133b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa3a0>
   1334c:      	mov	w8, #0x6e55             // =28245
   13350:      	movk	w8, #0x7369, lsl #16
   13354:      	cmp	w25, w8
   13358:      	b.ne	0x133b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa3a0>
   1335c:      	mov	w8, #0x636f             // =25455
   13360:      	movk	w8, #0x5520, lsl #16
   13364:      	cmp	w23, w8
   13368:      	b.ne	0x133b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa3a0>
   1336c:      	ldrh	w8, [x21, #0x8]
   13370:      	mov	w9, #0x534d             // =21325
   13374:      	cmp	w8, w9
   13378:      	b.ne	0x133b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa3a0>
   1337c:      	mov	w8, wzr
   13380:      	mov	w9, #0xa                // =10
   13384:      	mov	w10, #0xa               // =10
   13388:      	ldrb	w11, [x21, x10]
   1338c:      	sub	w11, w11, #0x30
   13390:      	cmp	w11, #0x9
   13394:      	b.hi	0x133b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa3a0>
   13398:      	madd	w8, w8, w9, w11
   1339c:      	add	x10, x10, #0x1
   133a0:      	cmp	w10, w20
   133a4:      	b.lo	0x13388 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa374>
   133a8:      	adrp	x9, 0x4000
   133ac:      	ldr	d0, [x9, #0xf08]
   133b0:      	b	0x13428 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa414>
   133b4:      	add	x2, sp, #0x8
   133b8:      	mov	x0, x21
   133bc:      	mov	x1, x22
   133c0:      	bl	0x14484 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb470>
   133c4:      	tbnz	w0, #0x0, 0x13498 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa484>
   133c8:      	sub	x8, x20, #0xb
   133cc:      	cmp	x8, #0x1
   133d0:      	b.hi	0x13458 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa444>
   133d4:      	mov	w8, #0x6e55             // =28245
   133d8:      	movk	w8, #0x7369, lsl #16
   133dc:      	cmp	w25, w8
   133e0:      	b.ne	0x13458 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa444>
   133e4:      	mov	w8, #0x636f             // =25455
   133e8:      	movk	w8, #0x5420, lsl #16
   133ec:      	cmp	w23, w8
   133f0:      	b.ne	0x13458 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa444>
   133f4:      	mov	w8, wzr
   133f8:      	mov	w9, #0x8                // =8
   133fc:      	mov	w10, #0xa               // =10
   13400:      	ldrb	w11, [x21, x9]
   13404:      	sub	w11, w11, #0x30
   13408:      	cmp	w11, #0x9
   1340c:      	b.hi	0x13458 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa444>
   13410:      	madd	w8, w8, w10, w11
   13414:      	add	x9, x9, #0x1
   13418:      	cmp	w9, w20
   1341c:      	b.lo	0x13400 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa3ec>
   13420:      	adrp	x9, 0x4000
   13424:      	ldr	d0, [x9, #0xf48]
   13428:      	stur	xzr, [sp, #0x14]
   1342c:      	str	d0, [sp, #0x8]
   13430:      	str	w8, [sp, #0x10]
   13434:      	ldr	w8, [sp, #0x18]
   13438:      	ldur	q0, [sp, #0x8]
   1343c:      	str	w8, [x19, #0x10]
   13440:      	str	q0, [x19]
   13444:      	ldr	x8, [x24, #0x28]
   13448:      	ldur	x9, [x29, #-0x10]
   1344c:      	cmp	x8, x9
   13450:      	b.eq	0x134b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa4a4>
   13454:      	b	0x131d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa1c4>
   13458:      	add	x3, sp, #0x8
   1345c:      	mov	x0, x21
   13460:      	mov	x1, x22
   13464:      	mov	w2, w26
   13468:      	bl	0x146a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb690>
   1346c:      	tbnz	w0, #0x0, 0x13498 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa484>
   13470:      	add	x2, sp, #0x8
   13474:      	mov	x0, x21
   13478:      	mov	x1, x22
   1347c:      	bl	0x1474c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb738>
   13480:      	tbnz	w0, #0x0, 0x13498 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa484>
   13484:      	add	x2, sp, #0x8
   13488:      	mov	x0, x21
   1348c:      	mov	x1, x22
   13490:      	bl	0x147ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb7d8>
   13494:      	tbz	w0, #0x0, 0x134d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa4c4>
   13498:      	ldur	q0, [sp, #0x8]
   1349c:      	ldr	w8, [sp, #0x18]
   134a0:      	str	q0, [x19]
   134a4:      	str	w8, [x19, #0x10]
   134a8:      	ldr	x8, [x24, #0x28]
   134ac:      	ldur	x9, [x29, #-0x10]
   134b0:      	cmp	x8, x9
   134b4:      	b.ne	0x131d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa1c4>
   134b8:      	ldp	x20, x19, [sp, #0x100]
   134bc:      	ldp	x22, x21, [sp, #0xf0]
   134c0:      	ldp	x24, x23, [sp, #0xe0]
   134c4:      	ldp	x26, x25, [sp, #0xd0]
   134c8:      	ldp	x28, x27, [sp, #0xc0]
   134cc:      	ldp	x29, x30, [sp, #0xb0]
   134d0:      	add	sp, sp, #0x110
   134d4:      	ret
   134d8:      	adrp	x22, 0x2000
   134dc:      	add	x22, x22, #0xcc0
   134e0:      	mov	x1, x21
   134e4:      	mov	x0, x22
   134e8:      	mov	x2, x20
   134ec:      	bl	0x1d8c0 <strncmp@plt>
   134f0:      	cbnz	w0, 0x134fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa4e8>
   134f4:      	ldrb	w8, [x22, x20]
   134f8:      	cbz	w8, 0x13570 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa55c>
   134fc:      	adrp	x22, 0x4000
   13500:      	add	x22, x22, #0xd48
   13504:      	mov	x1, x21
   13508:      	mov	x0, x22
   1350c:      	mov	x2, x20
   13510:      	bl	0x1d8c0 <strncmp@plt>
   13514:      	cbnz	w0, 0x13520 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa50c>
   13518:      	ldrb	w8, [x22, x20]
   1351c:      	cbz	w8, 0x13578 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa564>
   13520:      	adrp	x22, 0x3000
   13524:      	add	x22, x22, #0x9dc
   13528:      	mov	x1, x21
   1352c:      	mov	x0, x22
   13530:      	mov	x2, x20
   13534:      	bl	0x1d8c0 <strncmp@plt>
   13538:      	cbnz	w0, 0x13544 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa530>
   1353c:      	ldrb	w8, [x22, x20]
   13540:      	cbz	w8, 0x13580 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa56c>
   13544:      	adrp	x22, 0x3000
   13548:      	add	x22, x22, #0xed9
   1354c:      	mov	x1, x21
   13550:      	mov	x0, x22
   13554:      	mov	x2, x20
   13558:      	bl	0x1d8c0 <strncmp@plt>
   1355c:      	cbnz	w0, 0x12ef4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9ee0>
   13560:      	ldrb	w8, [x22, x20]
   13564:      	cbnz	w8, 0x12ef4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9ee0>
   13568:      	mov	w8, #0x3                // =3
   1356c:      	b	0x13584 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa570>
   13570:      	mov	x8, xzr
   13574:      	b	0x13584 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa570>
   13578:      	mov	w8, #0x1                // =1
   1357c:      	b	0x13584 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa570>
   13580:      	mov	w8, #0x2                // =2
   13584:      	nop
   13588:      	adr	x9, 0x21a28
   1358c:      	nop
   13590:      	adr	x10, 0x5270
   13594:      	add	x8, x9, x8, lsl #4
   13598:      	stur	xzr, [x19, #0xc]
   1359c:      	ldrb	w9, [x8, #0xa]
   135a0:      	ldrh	w8, [x8, #0x8]
   135a4:      	ldr	w10, [x10, w9, uxtw #2]
   135a8:      	stp	w9, w8, [x19, #0x4]
   135ac:      	str	w10, [x19]
   135b0:      	ldr	x8, [x24, #0x28]
   135b4:      	ldur	x9, [x29, #-0x10]
   135b8:      	cmp	x8, x9
   135bc:      	b.eq	0x134b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa4a4>
   135c0:      	b	0x131d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa1c4>
   135c4:      	bl	0x1d7a0 <atoi@plt>
   135c8:      	adrp	x8, 0x4000
   135cc:      	stur	xzr, [sp, #0x14]
   135d0:      	ldr	d0, [x8, #0xf20]
   135d4:      	str	w0, [sp, #0x10]
   135d8:      	str	d0, [sp, #0x8]
   135dc:      	b	0x13434 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa420>
   135e0:      	mov	w11, #0xa               // =10
   135e4:      	madd	w8, w8, w11, w9
   135e8:      	adrp	x9, 0x4000
   135ec:      	ldr	d0, [x9, #0xf20]
   135f0:      	madd	w8, w8, w11, w10
   135f4:      	b	0x13610 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa5fc>
   135f8:      	mov	w12, #0xa               // =10
   135fc:      	madd	w8, w8, w12, w9
   13600:      	adrp	x9, 0x4000
   13604:      	ldr	d0, [x9, #0xf20]
   13608:      	madd	w8, w8, w12, w10
   1360c:      	madd	w8, w8, w12, w11
   13610:      	str	d0, [sp, #0x8]
   13614:      	stur	xzr, [sp, #0x14]
   13618:      	b	0x13430 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa41c>
   1361c:      	add	x8, x0, #0x7
   13620:      	cmp	x8, x1
   13624:      	b.hi	0x13734 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa720>
   13628:      	ldrb	w8, [x0, #0x2]
   1362c:      	ldrb	w9, [x0]
   13630:      	ldrb	w10, [x0, #0x1]
   13634:      	orr	w8, w9, w8, lsl #16
   13638:      	mov	w9, #0x2020             // =8224
   1363c:      	movk	w9, #0x20, lsl #16
   13640:      	orr	w8, w8, w10, lsl #8
   13644:      	orr	w8, w8, w9
   13648:      	sub	w9, w8, #0x6d7, lsl #12 // =0x6d7000
   1364c:      	cmp	w9, #0x36d
   13650:      	b.eq	0x13688 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa674>
   13654:      	mov	w9, #0x7061             // =28769
   13658:      	movk	w9, #0x71, lsl #16
   1365c:      	cmp	w8, w9
   13660:      	b.ne	0x13734 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa720>
   13664:      	mov	w9, #0x3                // =3
   13668:      	mov	x8, x0
   1366c:      	ldrb	w10, [x8, #0x3]!
   13670:      	cmp	w10, #0x20
   13674:      	b.eq	0x1369c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa688>
   13678:      	sub	w10, w10, #0x30
   1367c:      	cmp	w10, #0x9
   13680:      	b.ls	0x136bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa6a8>
   13684:      	b	0x13734 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa720>
   13688:      	mov	w9, #0x2                // =2
   1368c:      	mov	x8, x0
   13690:      	ldrb	w10, [x8, #0x3]!
   13694:      	cmp	w10, #0x20
   13698:      	b.ne	0x13678 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa664>
   1369c:      	add	x8, x0, #0x8
   136a0:      	cmp	x8, x1
   136a4:      	b.hi	0x13734 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa720>
   136a8:      	ldrb	w10, [x0, #0x4]!
   136ac:      	mov	x8, x0
   136b0:      	sub	w10, w10, #0x30
   136b4:      	cmp	w10, #0x9
   136b8:      	b.hi	0x13734 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa720>
   136bc:      	ldrb	w11, [x8, #0x1]
   136c0:      	sub	w11, w11, #0x30
   136c4:      	cmp	w11, #0x9
   136c8:      	b.hi	0x13734 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa720>
   136cc:      	ldrb	w12, [x8, #0x2]
   136d0:      	sub	w12, w12, #0x30
   136d4:      	cmp	w12, #0x9
   136d8:      	b.hi	0x13734 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa720>
   136dc:      	ldrb	w13, [x8, #0x3]
   136e0:      	sub	w13, w13, #0x30
   136e4:      	cmp	w13, #0x9
   136e8:      	b.hi	0x13734 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa720>
   136ec:      	mov	w14, #0xa               // =10
   136f0:      	mov	w0, #0x1                // =1
   136f4:      	stur	xzr, [x2, #0xc]
   136f8:      	madd	w10, w10, w14, w11
   136fc:      	sub	x11, x1, #0x4
   13700:      	stp	w0, w9, [x2]
   13704:      	subs	x9, x11, x8
   13708:      	madd	w10, w10, w14, w12
   1370c:      	madd	w10, w10, w14, w13
   13710:      	str	w10, [x2, #0x8]
   13714:      	b.eq	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   13718:      	ldrb	w10, [x8, #0x4]
   1371c:      	orr	w11, w10, #0x20
   13720:      	sub	w11, w11, #0x61
   13724:      	cmp	w11, #0x19
   13728:      	b.hi	0x1373c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa728>
   1372c:      	and	w10, w10, #0xffffffdf
   13730:      	b	0x13744 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa730>
   13734:      	mov	w0, wzr
   13738:      	ret
   1373c:      	cmp	w10, #0x2d
   13740:      	b.ne	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   13744:      	cmp	x9, #0x1
   13748:      	strb	w10, [x2, #0xc]
   1374c:      	b.eq	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   13750:      	ldrb	w10, [x8, #0x5]
   13754:      	orr	w11, w10, #0x20
   13758:      	sub	w11, w11, #0x61
   1375c:      	cmp	w11, #0x1a
   13760:      	b.hs	0x1376c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa758>
   13764:      	and	w10, w10, #0xffffffdf
   13768:      	b	0x13774 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa760>
   1376c:      	cmp	w10, #0x2d
   13770:      	b.ne	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   13774:      	cmp	x9, #0x2
   13778:      	strb	w10, [x2, #0xd]
   1377c:      	b.eq	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   13780:      	ldrb	w10, [x8, #0x6]
   13784:      	orr	w11, w10, #0x20
   13788:      	sub	w11, w11, #0x61
   1378c:      	cmp	w11, #0x1a
   13790:      	b.hs	0x1379c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa788>
   13794:      	and	w10, w10, #0xffffffdf
   13798:      	b	0x137a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa790>
   1379c:      	cmp	w10, #0x2d
   137a0:      	b.ne	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   137a4:      	cmp	x9, #0x3
   137a8:      	strb	w10, [x2, #0xe]
   137ac:      	b.eq	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   137b0:      	ldrb	w10, [x8, #0x7]
   137b4:      	orr	w11, w10, #0x20
   137b8:      	sub	w11, w11, #0x61
   137bc:      	cmp	w11, #0x1a
   137c0:      	b.hs	0x137cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa7b8>
   137c4:      	and	w10, w10, #0xffffffdf
   137c8:      	b	0x137d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa7c0>
   137cc:      	cmp	w10, #0x2d
   137d0:      	b.ne	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   137d4:      	cmp	x9, #0x4
   137d8:      	strb	w10, [x2, #0xf]
   137dc:      	b.eq	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   137e0:      	ldrb	w10, [x8, #0x8]
   137e4:      	orr	w11, w10, #0x20
   137e8:      	sub	w11, w11, #0x61
   137ec:      	cmp	w11, #0x1a
   137f0:      	b.hs	0x137fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa7e8>
   137f4:      	and	w10, w10, #0xffffffdf
   137f8:      	b	0x13804 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa7f0>
   137fc:      	cmp	w10, #0x2d
   13800:      	b.ne	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   13804:      	cmp	x9, #0x5
   13808:      	strb	w10, [x2, #0x10]
   1380c:      	b.eq	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   13810:      	ldrb	w10, [x8, #0x9]
   13814:      	orr	w11, w10, #0x20
   13818:      	sub	w11, w11, #0x61
   1381c:      	cmp	w11, #0x1a
   13820:      	b.hs	0x1382c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa818>
   13824:      	and	w10, w10, #0xffffffdf
   13828:      	b	0x13834 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa820>
   1382c:      	cmp	w10, #0x2d
   13830:      	b.ne	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   13834:      	cmp	x9, #0x6
   13838:      	strb	w10, [x2, #0x11]
   1383c:      	b.eq	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   13840:      	ldrb	w10, [x8, #0xa]
   13844:      	orr	w11, w10, #0x20
   13848:      	sub	w11, w11, #0x61
   1384c:      	cmp	w11, #0x1a
   13850:      	b.hs	0x1385c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa848>
   13854:      	and	w10, w10, #0xffffffdf
   13858:      	b	0x13864 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa850>
   1385c:      	cmp	w10, #0x2d
   13860:      	b.ne	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   13864:      	cmp	x9, #0x7
   13868:      	strb	w10, [x2, #0x12]
   1386c:      	b.eq	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   13870:      	ldrb	w8, [x8, #0xb]
   13874:      	orr	w9, w8, #0x20
   13878:      	sub	w9, w9, #0x61
   1387c:      	cmp	w9, #0x1a
   13880:      	b.hs	0x13890 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa87c>
   13884:      	and	w8, w8, #0xffffffdf
   13888:      	strb	w8, [x2, #0x13]
   1388c:      	ret
   13890:      	cmp	w8, #0x2d
   13894:      	b.ne	0x13738 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa724>
   13898:      	strb	w8, [x2, #0x13]
   1389c:      	ret
   138a0:      	sub	sp, sp, #0xb0
   138a4:      	stp	x29, x30, [sp, #0x90]
   138a8:      	stp	x20, x19, [sp, #0xa0]
   138ac:      	add	x29, sp, #0x90
   138b0:      	mrs	x19, TPIDR_EL0
   138b4:      	add	x9, x0, #0x6
   138b8:      	ldr	x8, [x19, #0x28]
   138bc:      	cmp	x9, x1
   138c0:      	stur	x8, [x29, #-0x8]
   138c4:      	b.hi	0x139d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa9bc>
   138c8:      	ldrb	w8, [x0]
   138cc:      	sub	w9, w8, #0x41
   138d0:      	orr	w10, w8, #0x20
   138d4:      	cmp	w9, #0x1a
   138d8:      	csel	w8, w10, w8, lo
   138dc:      	cmp	w8, #0x70
   138e0:      	b.ne	0x139d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa9bc>
   138e4:      	ldrb	w8, [x0, #0x1]
   138e8:      	sub	w9, w8, #0x41
   138ec:      	orr	w10, w8, #0x20
   138f0:      	cmp	w9, #0x1a
   138f4:      	csel	w8, w10, w8, lo
   138f8:      	cmp	w8, #0x61
   138fc:      	b.ne	0x139d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa9bc>
   13900:      	ldrb	w8, [x0, #0x2]
   13904:      	sub	w9, w8, #0x41
   13908:      	orr	w10, w8, #0x20
   1390c:      	cmp	w9, #0x1a
   13910:      	csel	w8, w10, w8, lo
   13914:      	cmp	w8, #0x72
   13918:      	b.ne	0x139d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa9bc>
   1391c:      	ldrb	w8, [x0, #0x3]
   13920:      	sub	w9, w8, #0x41
   13924:      	orr	w10, w8, #0x20
   13928:      	cmp	w9, #0x1a
   1392c:      	csel	w8, w10, w8, lo
   13930:      	cmp	w8, #0x72
   13934:      	b.ne	0x139d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa9bc>
   13938:      	ldrb	w8, [x0, #0x4]
   1393c:      	sub	w9, w8, #0x41
   13940:      	orr	w10, w8, #0x20
   13944:      	cmp	w9, #0x1a
   13948:      	csel	w8, w10, w8, lo
   1394c:      	cmp	w8, #0x6f
   13950:      	b.ne	0x139d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa9bc>
   13954:      	ldrb	w8, [x0, #0x5]
   13958:      	sub	w9, w8, #0x41
   1395c:      	orr	w10, w8, #0x20
   13960:      	cmp	w9, #0x1a
   13964:      	csel	w8, w10, w8, lo
   13968:      	cmp	w8, #0x74
   1396c:      	b.ne	0x139d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa9bc>
   13970:      	movi	v0.2d, #0000000000000000
   13974:      	adrp	x0, 0x2000
   13978:      	add	x0, x0, #0xccc
   1397c:      	mov	x1, sp
   13980:      	mov	x20, x2
   13984:      	stp	q0, q0, [sp]
   13988:      	stp	q0, q0, [sp, #0x20]
   1398c:      	stp	q0, q0, [sp, #0x40]
   13990:      	stp	q0, q0, [sp, #0x60]
   13994:      	bl	0x1d7f0 <__system_property_get@plt>
   13998:      	cmp	w0, #0x1
   1399c:      	mov	w0, wzr
   139a0:      	b.lt	0x139f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa9e4>
   139a4:      	ldrb	w9, [sp]
   139a8:      	mov	x8, x20
   139ac:      	cbz	w9, 0x139fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa9e8>
   139b0:      	mov	x0, sp
   139b4:      	sub	w9, w9, #0x3a
   139b8:      	cmn	w9, #0xb
   139bc:      	b.hi	0x139f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa9e0>
   139c0:      	ldrb	w9, [x0, #0x1]!
   139c4:      	cbnz	w9, 0x139b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa9a0>
   139c8:      	mov	w0, wzr
   139cc:      	b	0x139fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa9e8>
   139d0:      	mov	w0, wzr
   139d4:      	ldr	x8, [x19, #0x28]
   139d8:      	ldur	x9, [x29, #-0x8]
   139dc:      	cmp	x8, x9
   139e0:      	b.ne	0x13a24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaa10>
   139e4:      	ldp	x20, x19, [sp, #0xa0]
   139e8:      	ldp	x29, x30, [sp, #0x90]
   139ec:      	add	sp, sp, #0xb0
   139f0:      	ret
   139f4:      	bl	0x1d7a0 <atoi@plt>
   139f8:      	mov	x8, x20
   139fc:      	adrp	x9, 0x4000
   13a00:      	str	w0, [x8, #0x8]
   13a04:      	mov	w0, #0x1                // =1
   13a08:      	ldr	d0, [x9, #0xf20]
   13a0c:      	stur	xzr, [x8, #0xc]
   13a10:      	str	d0, [x8]
   13a14:      	ldr	x8, [x19, #0x28]
   13a18:      	ldur	x9, [x29, #-0x8]
   13a1c:      	cmp	x8, x9
   13a20:      	b.eq	0x139e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa9d0>
   13a24:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   13a28:      	add	x8, x0, #0x6
   13a2c:      	cmp	x8, x1
   13a30:      	b.hi	0x13af4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaae0>
   13a34:      	ldrb	w8, [x0]
   13a38:      	ldrb	w9, [x0, #0x1]
   13a3c:      	orr	w8, w8, w9, lsl #8
   13a40:      	mov	w9, #0xdfdf             // =57311
   13a44:      	and	w8, w8, w9
   13a48:      	mov	w9, #0x544d             // =21581
   13a4c:      	cmp	w8, w9
   13a50:      	b.ne	0x13af4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaae0>
   13a54:      	mov	x8, x0
   13a58:      	ldrb	w9, [x8, #0x2]!
   13a5c:      	and	w10, w9, #0xffffffdf
   13a60:      	cmp	w10, #0x4b
   13a64:      	b.ne	0x13a7c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaa68>
   13a68:      	add	x8, x0, #0x7
   13a6c:      	cmp	x8, x1
   13a70:      	b.hi	0x13af4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaae0>
   13a74:      	ldrb	w9, [x0, #0x3]!
   13a78:      	mov	x8, x0
   13a7c:      	sub	w9, w9, #0x30
   13a80:      	cmp	w9, #0x9
   13a84:      	b.hi	0x13af4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaae0>
   13a88:      	ldrb	w10, [x8, #0x1]
   13a8c:      	sub	w10, w10, #0x30
   13a90:      	cmp	w10, #0x9
   13a94:      	b.hi	0x13af4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaae0>
   13a98:      	ldrb	w11, [x8, #0x2]
   13a9c:      	sub	w11, w11, #0x30
   13aa0:      	cmp	w11, #0x9
   13aa4:      	b.hi	0x13af4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaae0>
   13aa8:      	ldrb	w12, [x8, #0x3]
   13aac:      	sub	w12, w12, #0x30
   13ab0:      	cmp	w12, #0x9
   13ab4:      	b.hi	0x13af4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaae0>
   13ab8:      	mov	w13, #0xa               // =10
   13abc:      	madd	w9, w9, w13, w10
   13ac0:      	adrp	x10, 0x4000
   13ac4:      	ldr	d0, [x10, #0xf40]
   13ac8:      	mov	x10, x3
   13acc:      	str	xzr, [x10, #0xc]!
   13ad0:      	madd	w9, w9, w13, w11
   13ad4:      	add	x11, x8, #0x4
   13ad8:      	str	d0, [x3]
   13adc:      	madd	w9, w9, w13, w12
   13ae0:      	str	w9, [x3, #0x8]
   13ae4:      	tbz	w2, #0x0, 0x13afc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaae8>
   13ae8:      	sub	x8, x1, x11
   13aec:      	cmp	x8, #0x8
   13af0:      	b.ls	0x13b24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xab10>
   13af4:      	mov	w0, wzr
   13af8:      	ret
   13afc:      	sub	x9, x1, #0x4
   13b00:      	subs	x9, x9, x8
   13b04:      	b.eq	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13b08:      	ldrb	w11, [x11]
   13b0c:      	orr	w12, w11, #0x20
   13b10:      	sub	w12, w12, #0x61
   13b14:      	cmp	w12, #0x19
   13b18:      	b.hi	0x13b6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xab58>
   13b1c:      	and	w11, w11, #0xffffffdf
   13b20:      	b	0x13b74 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xab60>
   13b24:      	cmp	x11, x1
   13b28:      	b.eq	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13b2c:      	cmp	x8, #0x1
   13b30:      	mov	w0, #0x1                // =1
   13b34:      	csinc	x8, x8, xzr, hi
   13b38:      	b	0x13b4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xab38>
   13b3c:      	and	w9, w9, #0xffffffdf
   13b40:      	subs	x8, x8, #0x1
   13b44:      	strb	w9, [x10], #0x1
   13b48:      	b.eq	0x13af8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaae4>
   13b4c:      	ldrb	w9, [x11], #0x1
   13b50:      	orr	w12, w9, #0x20
   13b54:      	sub	w12, w12, #0x61
   13b58:      	cmp	w12, #0x19
   13b5c:      	b.ls	0x13b3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xab28>
   13b60:      	cmp	w9, #0x2f
   13b64:      	b.eq	0x13b40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xab2c>
   13b68:      	b	0x13af4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaae0>
   13b6c:      	cmp	w11, #0x2f
   13b70:      	b.ne	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13b74:      	cmp	x9, #0x1
   13b78:      	strb	w11, [x10]
   13b7c:      	b.eq	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13b80:      	ldrb	w10, [x8, #0x5]
   13b84:      	orr	w11, w10, #0x20
   13b88:      	sub	w11, w11, #0x61
   13b8c:      	cmp	w11, #0x1a
   13b90:      	b.hs	0x13b9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xab88>
   13b94:      	and	w10, w10, #0xffffffdf
   13b98:      	b	0x13ba4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xab90>
   13b9c:      	cmp	w10, #0x2f
   13ba0:      	b.ne	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13ba4:      	cmp	x9, #0x2
   13ba8:      	strb	w10, [x3, #0xd]
   13bac:      	b.eq	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13bb0:      	ldrb	w10, [x8, #0x6]
   13bb4:      	orr	w11, w10, #0x20
   13bb8:      	sub	w11, w11, #0x61
   13bbc:      	cmp	w11, #0x1a
   13bc0:      	b.hs	0x13bcc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xabb8>
   13bc4:      	and	w10, w10, #0xffffffdf
   13bc8:      	b	0x13bd4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xabc0>
   13bcc:      	cmp	w10, #0x2f
   13bd0:      	b.ne	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13bd4:      	cmp	x9, #0x3
   13bd8:      	strb	w10, [x3, #0xe]
   13bdc:      	b.eq	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13be0:      	ldrb	w10, [x8, #0x7]
   13be4:      	orr	w11, w10, #0x20
   13be8:      	sub	w11, w11, #0x61
   13bec:      	cmp	w11, #0x1a
   13bf0:      	b.hs	0x13bfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xabe8>
   13bf4:      	and	w10, w10, #0xffffffdf
   13bf8:      	b	0x13c04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xabf0>
   13bfc:      	cmp	w10, #0x2f
   13c00:      	b.ne	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13c04:      	cmp	x9, #0x4
   13c08:      	strb	w10, [x3, #0xf]
   13c0c:      	b.eq	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13c10:      	ldrb	w10, [x8, #0x8]
   13c14:      	orr	w11, w10, #0x20
   13c18:      	sub	w11, w11, #0x61
   13c1c:      	cmp	w11, #0x1a
   13c20:      	b.hs	0x13c2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac18>
   13c24:      	and	w10, w10, #0xffffffdf
   13c28:      	b	0x13c34 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac20>
   13c2c:      	cmp	w10, #0x2f
   13c30:      	b.ne	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13c34:      	cmp	x9, #0x5
   13c38:      	strb	w10, [x3, #0x10]
   13c3c:      	b.eq	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13c40:      	ldrb	w10, [x8, #0x9]
   13c44:      	orr	w11, w10, #0x20
   13c48:      	sub	w11, w11, #0x61
   13c4c:      	cmp	w11, #0x1a
   13c50:      	b.hs	0x13c5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac48>
   13c54:      	and	w10, w10, #0xffffffdf
   13c58:      	b	0x13c64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac50>
   13c5c:      	cmp	w10, #0x2f
   13c60:      	b.ne	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13c64:      	cmp	x9, #0x6
   13c68:      	strb	w10, [x3, #0x11]
   13c6c:      	b.eq	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13c70:      	ldrb	w10, [x8, #0xa]
   13c74:      	orr	w11, w10, #0x20
   13c78:      	sub	w11, w11, #0x61
   13c7c:      	cmp	w11, #0x1a
   13c80:      	b.hs	0x13c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac78>
   13c84:      	and	w10, w10, #0xffffffdf
   13c88:      	b	0x13c94 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac80>
   13c8c:      	cmp	w10, #0x2f
   13c90:      	b.ne	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13c94:      	cmp	x9, #0x7
   13c98:      	strb	w10, [x3, #0x12]
   13c9c:      	b.ne	0x13ca8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac94>
   13ca0:      	mov	w0, #0x1                // =1
   13ca4:      	ret
   13ca8:      	ldrb	w8, [x8, #0xb]
   13cac:      	orr	w9, w8, #0x20
   13cb0:      	sub	w9, w9, #0x61
   13cb4:      	cmp	w9, #0x1a
   13cb8:      	b.hs	0x13ccc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xacb8>
   13cbc:      	and	w8, w8, #0xffffffdf
   13cc0:      	mov	w0, #0x1                // =1
   13cc4:      	strb	w8, [x3, #0x13]
   13cc8:      	ret
   13ccc:      	cmp	w8, #0x2f
   13cd0:      	b.ne	0x13ca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xac8c>
   13cd4:      	mov	w0, #0x1                // =1
   13cd8:      	strb	w8, [x3, #0x13]
   13cdc:      	ret
   13ce0:      	sub	x8, x1, x0
   13ce4:      	sub	x9, x8, #0xc
   13ce8:      	cmn	x9, #0x4
   13cec:      	b.lo	0x13d90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xad7c>
   13cf0:      	ldrb	w9, [x0]
   13cf4:      	and	w9, w9, #0xffffffdf
   13cf8:      	cmp	w9, #0x4b
   13cfc:      	b.ne	0x13d90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xad7c>
   13d00:      	ldur	w9, [x0, #0x1]
   13d04:      	mov	w10, #0x7269            // =29289
   13d08:      	movk	w10, #0x6e69, lsl #16
   13d0c:      	cmp	w9, w10
   13d10:      	b.ne	0x13d90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xad7c>
   13d14:      	ldrb	w10, [x0, #0x5]
   13d18:      	mov	w9, #0x5                // =5
   13d1c:      	cmp	w10, #0x20
   13d20:      	b.hi	0x13d40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xad2c>
   13d24:      	mov	w11, #0x1               // =1
   13d28:      	lsl	x10, x11, x10
   13d2c:      	mov	x11, #0x2600            // =9728
   13d30:      	movk	x11, #0x1, lsl #32
   13d34:      	tst	x10, x11
   13d38:      	b.eq	0x13d40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xad2c>
   13d3c:      	mov	w9, #0x6                // =6
   13d40:      	mov	w10, wzr
   13d44:      	mov	w11, #0xa               // =10
   13d48:      	ldrb	w12, [x0, x9]
   13d4c:      	sub	w13, w12, #0x30
   13d50:      	cmp	w13, #0x9
   13d54:      	b.hi	0x13d6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xad58>
   13d58:      	madd	w10, w10, w11, w13
   13d5c:      	add	x9, x9, #0x1
   13d60:      	cmp	x8, x9
   13d64:      	b.hi	0x13d48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xad34>
   13d68:      	mov	w12, wzr
   13d6c:      	adrp	x8, 0x4000
   13d70:      	mov	w0, #0x1                // =1
   13d74:      	str	w10, [x2, #0x8]
   13d78:      	ldr	d0, [x8, #0xf30]
   13d7c:      	strb	w12, [x2, #0xc]
   13d80:      	stur	wzr, [x2, #0xd]
   13d84:      	str	d0, [x2]
   13d88:      	str	wzr, [x2, #0x10]
   13d8c:      	ret
   13d90:      	mov	w0, wzr
   13d94:      	ret
   13d98:      	sub	x9, x1, x0
   13d9c:      	and	x8, x9, #0xfffffffffffffffe
   13da0:      	cmp	x8, #0x6
   13da4:      	b.ne	0x13e2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xae18>
   13da8:      	ldrb	w8, [x0]
   13dac:      	ldrb	w10, [x0, #0x1]
   13db0:      	orr	w8, w8, w10, lsl #8
   13db4:      	mov	w10, #0xdfdf            // =57311
   13db8:      	and	w8, w8, w10
   13dbc:      	mov	w10, #0x4b52            // =19282
   13dc0:      	cmp	w8, w10
   13dc4:      	b.ne	0x13e2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xae18>
   13dc8:      	ldrb	w8, [x0, #0x2]
   13dcc:      	sub	w8, w8, #0x30
   13dd0:      	cmp	w8, #0x9
   13dd4:      	b.hi	0x13e2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xae18>
   13dd8:      	ldrb	w10, [x0, #0x3]
   13ddc:      	sub	w10, w10, #0x30
   13de0:      	cmp	w10, #0x9
   13de4:      	b.hi	0x13e2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xae18>
   13de8:      	ldrb	w11, [x0, #0x4]
   13dec:      	sub	w12, w11, #0x30
   13df0:      	cmp	w12, #0x9
   13df4:      	b.hi	0x13e2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xae18>
   13df8:      	ldrb	w11, [x0, #0x5]
   13dfc:      	sub	w11, w11, #0x30
   13e00:      	cmp	w11, #0x9
   13e04:      	b.hi	0x13e2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xae18>
   13e08:      	cmp	x9, #0x7
   13e0c:      	b.ne	0x13e34 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xae20>
   13e10:      	ldrb	w9, [x0, #0x6]
   13e14:      	orr	w13, w9, #0x20
   13e18:      	sub	w13, w13, #0x61
   13e1c:      	cmp	w13, #0x19
   13e20:      	b.hi	0x13e2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xae18>
   13e24:      	and	w9, w9, #0xffffffdf
   13e28:      	b	0x13e38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xae24>
   13e2c:      	mov	w0, wzr
   13e30:      	ret
   13e34:      	mov	w9, wzr
   13e38:      	mov	w13, #0xa               // =10
   13e3c:      	mov	w0, #0x1                // =1
   13e40:      	strb	w9, [x2, #0xc]
   13e44:      	madd	w8, w8, w13, w10
   13e48:      	adrp	x10, 0x4000
   13e4c:      	stur	wzr, [x2, #0xd]
   13e50:      	ldr	d0, [x10, #0xf50]
   13e54:      	str	wzr, [x2, #0x10]
   13e58:      	madd	w8, w8, w13, w12
   13e5c:      	str	d0, [x2]
   13e60:      	madd	w8, w8, w13, w11
   13e64:      	str	w8, [x2, #0x8]
   13e68:      	ret
   13e6c:      	sub	sp, sp, #0xc0
   13e70:      	stp	x29, x30, [sp, #0x90]
   13e74:      	stp	x22, x21, [sp, #0xa0]
   13e78:      	stp	x20, x19, [sp, #0xb0]
   13e7c:      	add	x29, sp, #0x90
   13e80:      	movi	v0.2d, #0000000000000000
   13e84:      	mrs	x22, TPIDR_EL0
   13e88:      	mov	x21, x1
   13e8c:      	ldr	x8, [x22, #0x28]
   13e90:      	mov	x20, x0
   13e94:      	adrp	x0, 0x2000
   13e98:      	add	x0, x0, #0xccc
   13e9c:      	mov	x1, sp
   13ea0:      	mov	x19, x2
   13ea4:      	stur	x8, [x29, #-0x8]
   13ea8:      	stp	q0, q0, [sp]
   13eac:      	stp	q0, q0, [sp, #0x20]
   13eb0:      	stp	q0, q0, [sp, #0x40]
   13eb4:      	stp	q0, q0, [sp, #0x60]
   13eb8:      	bl	0x1d7f0 <__system_property_get@plt>
   13ebc:      	cmp	w0, #0x1
   13ec0:      	mov	w0, wzr
   13ec4:      	b.lt	0x13ef4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaee0>
   13ec8:      	ldrb	w8, [sp]
   13ecc:      	cbz	w8, 0x13ef4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaee0>
   13ed0:      	mov	x0, sp
   13ed4:      	sub	w8, w8, #0x3a
   13ed8:      	cmn	w8, #0xb
   13edc:      	b.hi	0x13ef0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaedc>
   13ee0:      	ldrb	w8, [x0, #0x1]!
   13ee4:      	cbnz	w8, 0x13ed4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaec0>
   13ee8:      	mov	w0, wzr
   13eec:      	b	0x13ef4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaee0>
   13ef0:      	bl	0x1d7a0 <atoi@plt>
   13ef4:      	ldrb	w8, [x20]
   13ef8:      	sub	w9, w8, #0x41
   13efc:      	orr	w10, w8, #0x20
   13f00:      	cmp	w9, #0x1a
   13f04:      	csel	w9, w10, w8, lo
   13f08:      	sub	w8, w21, w20
   13f0c:      	cmp	w9, #0x62
   13f10:      	b.eq	0x140b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb09c>
   13f14:      	cmp	w9, #0x6c
   13f18:      	b.eq	0x13f98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaf84>
   13f1c:      	cmp	w9, #0x6b
   13f20:      	b.ne	0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   13f24:      	ldrb	w9, [x20, #0x1]
   13f28:      	sub	w10, w9, #0x41
   13f2c:      	orr	w11, w9, #0x20
   13f30:      	cmp	w10, #0x1a
   13f34:      	csel	w9, w11, w9, lo
   13f38:      	cmp	w9, #0x6f
   13f3c:      	b.ne	0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   13f40:      	ldrb	w9, [x20, #0x2]
   13f44:      	sub	w10, w9, #0x41
   13f48:      	orr	w11, w9, #0x20
   13f4c:      	cmp	w10, #0x1a
   13f50:      	csel	w9, w11, w9, lo
   13f54:      	cmp	w9, #0x6e
   13f58:      	b.ne	0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   13f5c:      	ldrb	w9, [x20, #0x3]
   13f60:      	sub	w10, w9, #0x41
   13f64:      	orr	w11, w9, #0x20
   13f68:      	cmp	w10, #0x1a
   13f6c:      	csel	w9, w11, w9, lo
   13f70:      	cmp	w9, #0x61
   13f74:      	b.ne	0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   13f78:      	ldrb	w9, [x20, #0x4]
   13f7c:      	cbnz	w9, 0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   13f80:      	adrp	x9, 0x3000
   13f84:      	add	x9, x9, #0x5f5
   13f88:      	ldrb	w8, [x9, w8, sxtw]
   13f8c:      	cbnz	w8, 0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   13f90:      	mov	x8, xzr
   13f94:      	b	0x14240 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb22c>
   13f98:      	ldrb	w9, [x20, #0x1]
   13f9c:      	sub	w10, w9, #0x41
   13fa0:      	orr	w11, w9, #0x20
   13fa4:      	cmp	w10, #0x1a
   13fa8:      	csel	w9, w11, w9, lo
   13fac:      	cmp	w9, #0x69
   13fb0:      	b.ne	0x14004 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaff0>
   13fb4:      	ldrb	w9, [x20, #0x2]
   13fb8:      	sub	w10, w9, #0x41
   13fbc:      	orr	w11, w9, #0x20
   13fc0:      	cmp	w10, #0x1a
   13fc4:      	csel	w9, w11, w9, lo
   13fc8:      	cmp	w9, #0x74
   13fcc:      	b.ne	0x14004 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaff0>
   13fd0:      	ldrb	w9, [x20, #0x3]
   13fd4:      	sub	w10, w9, #0x41
   13fd8:      	orr	w11, w9, #0x20
   13fdc:      	cmp	w10, #0x1a
   13fe0:      	csel	w9, w11, w9, lo
   13fe4:      	cmp	w9, #0x6f
   13fe8:      	b.ne	0x14004 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaff0>
   13fec:      	ldrb	w9, [x20, #0x4]
   13ff0:      	cbnz	w9, 0x14004 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaff0>
   13ff4:      	adrp	x9, 0x3000
   13ff8:      	add	x9, x9, #0x7a5
   13ffc:      	ldrb	w9, [x9, w8, sxtw]
   14000:      	cbz	w9, 0x1423c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb228>
   14004:      	ldrb	w9, [x20, #0x1]
   14008:      	sub	w10, w9, #0x41
   1400c:      	orr	w11, w9, #0x20
   14010:      	cmp	w10, #0x1a
   14014:      	csel	w9, w11, w9, lo
   14018:      	cmp	w9, #0x61
   1401c:      	b.ne	0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   14020:      	ldrb	w9, [x20, #0x2]
   14024:      	sub	w10, w9, #0x41
   14028:      	orr	w11, w9, #0x20
   1402c:      	cmp	w10, #0x1a
   14030:      	csel	w9, w11, w9, lo
   14034:      	cmp	w9, #0x67
   14038:      	b.ne	0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   1403c:      	ldrb	w9, [x20, #0x3]
   14040:      	sub	w10, w9, #0x41
   14044:      	orr	w11, w9, #0x20
   14048:      	cmp	w10, #0x1a
   1404c:      	csel	w9, w11, w9, lo
   14050:      	cmp	w9, #0x6f
   14054:      	b.ne	0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   14058:      	ldrb	w9, [x20, #0x4]
   1405c:      	sub	w10, w9, #0x41
   14060:      	orr	w11, w9, #0x20
   14064:      	cmp	w10, #0x1a
   14068:      	csel	w9, w11, w9, lo
   1406c:      	cmp	w9, #0x6f
   14070:      	b.ne	0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   14074:      	ldrb	w9, [x20, #0x5]
   14078:      	sub	w10, w9, #0x41
   1407c:      	orr	w11, w9, #0x20
   14080:      	cmp	w10, #0x1a
   14084:      	csel	w9, w11, w9, lo
   14088:      	cmp	w9, #0x6e
   1408c:      	b.ne	0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   14090:      	ldrb	w9, [x20, #0x6]
   14094:      	cbnz	w9, 0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   14098:      	adrp	x9, 0x2000
   1409c:      	add	x9, x9, #0xdd5
   140a0:      	ldrb	w8, [x9, w8, sxtw]
   140a4:      	cbnz	w8, 0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   140a8:      	mov	w8, #0x4                // =4
   140ac:      	b	0x14240 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb22c>
   140b0:      	ldrb	w9, [x20, #0x1]
   140b4:      	sub	w10, w9, #0x41
   140b8:      	orr	w11, w9, #0x20
   140bc:      	cmp	w10, #0x1a
   140c0:      	csel	w9, w11, w9, lo
   140c4:      	cmp	w9, #0x65
   140c8:      	b.ne	0x14154 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb140>
   140cc:      	ldrb	w9, [x20, #0x2]
   140d0:      	sub	w10, w9, #0x41
   140d4:      	orr	w11, w9, #0x20
   140d8:      	cmp	w10, #0x1a
   140dc:      	csel	w9, w11, w9, lo
   140e0:      	cmp	w9, #0x6e
   140e4:      	b.ne	0x14154 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb140>
   140e8:      	ldrb	w9, [x20, #0x3]
   140ec:      	sub	w10, w9, #0x41
   140f0:      	orr	w11, w9, #0x20
   140f4:      	cmp	w10, #0x1a
   140f8:      	csel	w9, w11, w9, lo
   140fc:      	cmp	w9, #0x67
   14100:      	b.ne	0x14154 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb140>
   14104:      	ldrb	w9, [x20, #0x4]
   14108:      	sub	w10, w9, #0x41
   1410c:      	orr	w11, w9, #0x20
   14110:      	cmp	w10, #0x1a
   14114:      	csel	w9, w11, w9, lo
   14118:      	cmp	w9, #0x61
   1411c:      	b.ne	0x14154 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb140>
   14120:      	ldrb	w9, [x20, #0x5]
   14124:      	sub	w10, w9, #0x41
   14128:      	orr	w11, w9, #0x20
   1412c:      	cmp	w10, #0x1a
   14130:      	csel	w9, w11, w9, lo
   14134:      	cmp	w9, #0x6c
   14138:      	b.ne	0x14154 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb140>
   1413c:      	ldrb	w9, [x20, #0x6]
   14140:      	cbnz	w9, 0x14154 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb140>
   14144:      	adrp	x9, 0x3000
   14148:      	add	x9, x9, #0xde2
   1414c:      	ldrb	w9, [x9, w8, sxtw]
   14150:      	cbz	w9, 0x14290 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb27c>
   14154:      	ldrb	w9, [x20, #0x1]
   14158:      	sub	w10, w9, #0x41
   1415c:      	orr	w11, w9, #0x20
   14160:      	cmp	w10, #0x1a
   14164:      	csel	w9, w11, w9, lo
   14168:      	cmp	w9, #0x65
   1416c:      	b.ne	0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   14170:      	ldrb	w9, [x20, #0x2]
   14174:      	sub	w10, w9, #0x41
   14178:      	orr	w11, w9, #0x20
   1417c:      	cmp	w10, #0x1a
   14180:      	csel	w9, w11, w9, lo
   14184:      	cmp	w9, #0x6e
   14188:      	b.ne	0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   1418c:      	ldrb	w9, [x20, #0x3]
   14190:      	sub	w10, w9, #0x41
   14194:      	orr	w11, w9, #0x20
   14198:      	cmp	w10, #0x1a
   1419c:      	csel	w9, w11, w9, lo
   141a0:      	cmp	w9, #0x67
   141a4:      	b.ne	0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   141a8:      	ldrb	w9, [x20, #0x4]
   141ac:      	sub	w10, w9, #0x41
   141b0:      	orr	w11, w9, #0x20
   141b4:      	cmp	w10, #0x1a
   141b8:      	csel	w9, w11, w9, lo
   141bc:      	cmp	w9, #0x61
   141c0:      	b.ne	0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   141c4:      	ldrb	w9, [x20, #0x5]
   141c8:      	sub	w10, w9, #0x41
   141cc:      	orr	w11, w9, #0x20
   141d0:      	cmp	w10, #0x1a
   141d4:      	csel	w9, w11, w9, lo
   141d8:      	cmp	w9, #0x6c
   141dc:      	b.ne	0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   141e0:      	ldrb	w9, [x20, #0x6]
   141e4:      	sub	w10, w9, #0x41
   141e8:      	orr	w11, w9, #0x20
   141ec:      	cmp	w10, #0x1a
   141f0:      	csel	w9, w11, w9, lo
   141f4:      	cmp	w9, #0x70
   141f8:      	b.ne	0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   141fc:      	ldrb	w9, [x20, #0x7]
   14200:      	cbnz	w9, 0x14214 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb200>
   14204:      	adrp	x9, 0x3000
   14208:      	add	x9, x9, #0x5fa
   1420c:      	ldrb	w8, [x9, w8, sxtw]
   14210:      	cbz	w8, 0x14298 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb284>
   14214:      	mov	w0, wzr
   14218:      	ldr	x8, [x22, #0x28]
   1421c:      	ldur	x9, [x29, #-0x8]
   14220:      	cmp	x8, x9
   14224:      	b.ne	0x1428c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb278>
   14228:      	ldp	x20, x19, [sp, #0xb0]
   1422c:      	ldp	x22, x21, [sp, #0xa0]
   14230:      	ldp	x29, x30, [sp, #0x90]
   14234:      	add	sp, sp, #0xc0
   14238:      	ret
   1423c:      	mov	w8, #0x3                // =3
   14240:      	nop
   14244:      	adr	x9, 0x21da0
   14248:      	cbnz	w0, 0x14254 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb240>
   1424c:      	add	x10, x9, x8, lsl #4
   14250:      	ldrh	w0, [x10, #0x8]
   14254:      	add	x8, x9, x8, lsl #4
   14258:      	adrp	x9, 0x4000
   1425c:      	str	w0, [x19, #0x8]
   14260:      	ldr	d0, [x9, #0xf20]
   14264:      	stur	wzr, [x19, #0xd]
   14268:      	mov	w0, #0x1                // =1
   1426c:      	ldrb	w8, [x8, #0xb]
   14270:      	str	wzr, [x19, #0x10]
   14274:      	str	d0, [x19]
   14278:      	strb	w8, [x19, #0xc]
   1427c:      	ldr	x8, [x22, #0x28]
   14280:      	ldur	x9, [x29, #-0x8]
   14284:      	cmp	x8, x9
   14288:      	b.eq	0x14228 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb214>
   1428c:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   14290:      	mov	w8, #0x1                // =1
   14294:      	b	0x14240 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb22c>
   14298:      	mov	w8, #0x2                // =2
   1429c:      	b	0x14240 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb22c>
   142a0:      	sub	x8, x1, x0
   142a4:      	and	x9, x8, #0xfffffffffffffffe
   142a8:      	cmp	x9, #0x12
   142ac:      	b.ne	0x143b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb3a4>
   142b0:      	ldr	w10, [x0]
   142b4:      	mov	w9, #0xdfff             // =57343
   142b8:      	mov	w11, #0x4153            // =16723
   142bc:      	movk	w9, #0xdfdf, lsl #16
   142c0:      	movk	w11, #0x534d, lsl #16
   142c4:      	and	w10, w10, w9
   142c8:      	cmp	w10, w11
   142cc:      	b.ne	0x143b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb3a4>
   142d0:      	ldr	w10, [x0, #0x4]
   142d4:      	mov	w11, #0xdfdf            // =57311
   142d8:      	movk	w11, #0xffdf, lsl #16
   142dc:      	and	w10, w10, w11
   142e0:      	mov	w11, #0x4e55            // =20053
   142e4:      	movk	w11, #0x2047, lsl #16
   142e8:      	cmp	w10, w11
   142ec:      	b.ne	0x143b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb3a4>
   142f0:      	ldr	w10, [x0, #0x8]
   142f4:      	and	w9, w10, w9
   142f8:      	mov	w10, #0x5845            // =22597
   142fc:      	movk	w10, #0x4e59, lsl #16
   14300:      	cmp	w9, w10
   14304:      	b.ne	0x143b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb3a4>
   14308:      	ldrb	w9, [x0, #0xc]
   1430c:      	ldrb	w10, [x0, #0xd]
   14310:      	orr	w9, w9, w10, lsl #8
   14314:      	mov	w10, #0xdfdf            // =57311
   14318:      	and	w9, w9, w10
   1431c:      	mov	w10, #0x534f            // =21327
   14320:      	cmp	w9, w10
   14324:      	b.ne	0x143b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb3a4>
   14328:      	ldrb	w9, [x0, #0xe]
   1432c:      	cmp	w9, #0x20
   14330:      	b.ne	0x14348 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb334>
   14334:      	cmp	x8, #0x13
   14338:      	b.ne	0x143b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb3a4>
   1433c:      	ldrb	w9, [x0, #0xf]
   14340:      	mov	w10, #0xf               // =15
   14344:      	b	0x1434c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb338>
   14348:      	mov	w10, #0xe               // =14
   1434c:      	sub	w8, w9, #0x30
   14350:      	cmp	w8, #0x9
   14354:      	b.hi	0x143b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb3a4>
   14358:      	add	x10, x0, x10
   1435c:      	ldrb	w9, [x10, #0x1]
   14360:      	sub	w9, w9, #0x30
   14364:      	cmp	w9, #0x9
   14368:      	b.hi	0x143b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb3a4>
   1436c:      	ldrb	w11, [x10, #0x2]
   14370:      	sub	w11, w11, #0x30
   14374:      	cmp	w11, #0x9
   14378:      	b.hi	0x143b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb3a4>
   1437c:      	ldrb	w10, [x10, #0x3]
   14380:      	sub	w10, w10, #0x30
   14384:      	cmp	w10, #0x9
   14388:      	b.hi	0x143b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb3a4>
   1438c:      	mov	w12, #0xa               // =10
   14390:      	mov	w0, #0x1                // =1
   14394:      	stur	xzr, [x2, #0xc]
   14398:      	madd	w8, w8, w12, w9
   1439c:      	adrp	x9, 0x4000
   143a0:      	ldr	d0, [x9, #0xf58]
   143a4:      	madd	w8, w8, w12, w11
   143a8:      	str	d0, [x2]
   143ac:      	madd	w8, w8, w12, w10
   143b0:      	str	w8, [x2, #0x8]
   143b4:      	ret
   143b8:      	mov	w0, wzr
   143bc:      	ret
   143c0:      	add	x8, x0, #0xd
   143c4:      	cmp	x8, x1
   143c8:      	b.ne	0x1447c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb468>
   143cc:      	ldrb	w8, [x0]
   143d0:      	and	w8, w8, #0xffffffdf
   143d4:      	cmp	w8, #0x55
   143d8:      	b.ne	0x1447c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb468>
   143dc:      	ldur	w8, [x0, #0x1]
   143e0:      	mov	w9, #0x494e             // =18766
   143e4:      	movk	w9, #0x4556, lsl #16
   143e8:      	and	w8, w8, #0xdfdfdfdf
   143ec:      	cmp	w8, w9
   143f0:      	b.ne	0x1447c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb468>
   143f4:      	ldur	w8, [x0, #0x5]
   143f8:      	mov	w9, #-0x20202021        // =-538976289
   143fc:      	and	w8, w8, w9
   14400:      	mov	w9, #0x5352             // =21330
   14404:      	movk	w9, #0x4c41, lsl #16
   14408:      	cmp	w8, w9
   1440c:      	b.ne	0x1447c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb468>
   14410:      	ldrb	w8, [x0, #0x9]
   14414:      	sub	w8, w8, #0x30
   14418:      	cmp	w8, #0x9
   1441c:      	b.hi	0x1447c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb468>
   14420:      	ldrb	w9, [x0, #0xa]
   14424:      	sub	w9, w9, #0x30
   14428:      	cmp	w9, #0x9
   1442c:      	b.hi	0x1447c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb468>
   14430:      	ldrb	w10, [x0, #0xb]
   14434:      	sub	w10, w10, #0x30
   14438:      	cmp	w10, #0x9
   1443c:      	b.hi	0x1447c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb468>
   14440:      	ldrb	w11, [x0, #0xc]
   14444:      	sub	w11, w11, #0x30
   14448:      	cmp	w11, #0x9
   1444c:      	b.hi	0x1447c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb468>
   14450:      	mov	w12, #0xa               // =10
   14454:      	mov	w0, #0x1                // =1
   14458:      	stur	xzr, [x2, #0xc]
   1445c:      	madd	w8, w8, w12, w9
   14460:      	adrp	x9, 0x4000
   14464:      	ldr	d0, [x9, #0xf58]
   14468:      	madd	w8, w8, w12, w10
   1446c:      	str	d0, [x2]
   14470:      	madd	w8, w8, w12, w11
   14474:      	str	w8, [x2, #0x8]
   14478:      	ret
   1447c:      	mov	w0, wzr
   14480:      	ret
   14484:      	add	x8, x0, #0x5
   14488:      	cmp	x8, x1
   1448c:      	b.hi	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   14490:      	ldrh	w9, [x0]
   14494:      	mov	w10, #0x2020            // =8224
   14498:      	orr	w9, w9, w10
   1449c:      	mov	w10, #0x7073            // =28787
   144a0:      	cmp	w9, w10
   144a4:      	b.eq	0x144b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb4a0>
   144a8:      	mov	w10, #0x6373            // =25459
   144ac:      	cmp	w9, w10
   144b0:      	b.ne	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   144b4:      	ldrb	w10, [x0, #0x2]
   144b8:      	and	w9, w10, #0xffffffdf
   144bc:      	cmp	w9, #0x58
   144c0:      	b.ne	0x144fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb4e8>
   144c4:      	cmp	x8, x1
   144c8:      	b.ne	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   144cc:      	ldurh	w8, [x0, #0x3]
   144d0:      	mov	w9, #0x3531             // =13617
   144d4:      	cmp	w8, w9
   144d8:      	b.ne	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   144dc:      	adrp	x8, 0x4000
   144e0:      	mov	w9, #0x1e23             // =7715
   144e4:      	mov	w0, #0x1                // =1
   144e8:      	ldr	d0, [x8, #0xf68]
   144ec:      	str	w9, [x2, #0x8]
   144f0:      	stur	xzr, [x2, #0xc]
   144f4:      	str	d0, [x2]
   144f8:      	ret
   144fc:      	add	x9, x0, #0x6
   14500:      	cmp	x9, x1
   14504:      	b.hi	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   14508:      	sub	w10, w10, #0x30
   1450c:      	cmp	w10, #0x9
   14510:      	b.hi	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   14514:      	ldrb	w11, [x0, #0x3]
   14518:      	sub	w11, w11, #0x30
   1451c:      	cmp	w11, #0x9
   14520:      	b.hi	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   14524:      	ldrb	w12, [x0, #0x4]
   14528:      	sub	w12, w12, #0x30
   1452c:      	cmp	w12, #0x9
   14530:      	b.hi	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   14534:      	ldrb	w8, [x8]
   14538:      	sub	w8, w8, #0x30
   1453c:      	cmp	w8, #0x9
   14540:      	b.hi	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   14544:      	mov	w13, #0xa               // =10
   14548:      	stur	xzr, [x2, #0xc]
   1454c:      	madd	w10, w10, w13, w11
   14550:      	adrp	x11, 0x4000
   14554:      	ldr	d0, [x11, #0xf68]
   14558:      	madd	w10, w10, w13, w12
   1455c:      	str	d0, [x2]
   14560:      	madd	w10, w10, w13, w8
   14564:      	sub	x8, x1, #0x6
   14568:      	subs	x8, x8, x0
   1456c:      	str	w10, [x2, #0x8]
   14570:      	b.ne	0x1457c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb568>
   14574:      	mov	w0, #0x1                // =1
   14578:      	ret
   1457c:      	ldrb	w9, [x9]
   14580:      	orr	w10, w9, #0x20
   14584:      	sub	w10, w10, #0x61
   14588:      	cmp	w10, #0x19
   1458c:      	b.hi	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   14590:      	and	w9, w9, #0xffffffdf
   14594:      	cmp	x8, #0x1
   14598:      	strb	w9, [x2, #0xc]
   1459c:      	b.eq	0x14574 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb560>
   145a0:      	ldrb	w9, [x0, #0x7]
   145a4:      	orr	w10, w9, #0x20
   145a8:      	sub	w10, w10, #0x61
   145ac:      	cmp	w10, #0x19
   145b0:      	b.hi	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   145b4:      	and	w9, w9, #0xffffffdf
   145b8:      	cmp	x8, #0x2
   145bc:      	strb	w9, [x2, #0xd]
   145c0:      	b.eq	0x14574 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb560>
   145c4:      	ldrb	w9, [x0, #0x8]
   145c8:      	orr	w10, w9, #0x20
   145cc:      	sub	w10, w10, #0x61
   145d0:      	cmp	w10, #0x19
   145d4:      	b.hi	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   145d8:      	and	w9, w9, #0xffffffdf
   145dc:      	cmp	x8, #0x3
   145e0:      	strb	w9, [x2, #0xe]
   145e4:      	b.eq	0x14574 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb560>
   145e8:      	ldrb	w9, [x0, #0x9]
   145ec:      	orr	w10, w9, #0x20
   145f0:      	sub	w10, w10, #0x61
   145f4:      	cmp	w10, #0x19
   145f8:      	b.hi	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   145fc:      	and	w9, w9, #0xffffffdf
   14600:      	cmp	x8, #0x4
   14604:      	strb	w9, [x2, #0xf]
   14608:      	b.eq	0x14574 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb560>
   1460c:      	ldrb	w9, [x0, #0xa]
   14610:      	orr	w10, w9, #0x20
   14614:      	sub	w10, w10, #0x61
   14618:      	cmp	w10, #0x19
   1461c:      	b.hi	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   14620:      	and	w9, w9, #0xffffffdf
   14624:      	cmp	x8, #0x5
   14628:      	strb	w9, [x2, #0x10]
   1462c:      	b.eq	0x14574 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb560>
   14630:      	ldrb	w9, [x0, #0xb]
   14634:      	orr	w10, w9, #0x20
   14638:      	sub	w10, w10, #0x61
   1463c:      	cmp	w10, #0x19
   14640:      	b.hi	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   14644:      	and	w9, w9, #0xffffffdf
   14648:      	cmp	x8, #0x6
   1464c:      	strb	w9, [x2, #0x11]
   14650:      	b.eq	0x14574 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb560>
   14654:      	ldrb	w9, [x0, #0xc]
   14658:      	orr	w10, w9, #0x20
   1465c:      	sub	w10, w10, #0x61
   14660:      	cmp	w10, #0x19
   14664:      	b.hi	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   14668:      	and	w9, w9, #0xffffffdf
   1466c:      	cmp	x8, #0x7
   14670:      	strb	w9, [x2, #0x12]
   14674:      	b.eq	0x14574 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb560>
   14678:      	ldrb	w8, [x0, #0xd]
   1467c:      	orr	w9, w8, #0x20
   14680:      	sub	w9, w9, #0x61
   14684:      	cmp	w9, #0x19
   14688:      	b.hi	0x1469c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb688>
   1468c:      	and	w8, w8, #0xffffffdf
   14690:      	strb	w8, [x2, #0x13]
   14694:      	mov	w0, #0x1                // =1
   14698:      	ret
   1469c:      	mov	w0, wzr
   146a0:      	ret
   146a4:      	add	x8, x0, #0x5
   146a8:      	cmp	x8, x1
   146ac:      	b.hi	0x14744 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb730>
   146b0:      	ldrb	w9, [x0]
   146b4:      	cmp	w9, #0x73
   146b8:      	b.ne	0x14744 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb730>
   146bc:      	ldurh	w9, [x0, #0x1]
   146c0:      	mov	w10, #0x6e75            // =28277
   146c4:      	cmp	w9, w10
   146c8:      	b.ne	0x14744 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb730>
   146cc:      	ldrb	w9, [x0, #0x3]
   146d0:      	sub	w9, w9, #0x30
   146d4:      	cmp	w9, #0x9
   146d8:      	b.hi	0x14744 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb730>
   146dc:      	ldrb	w10, [x0, #0x4]!
   146e0:      	mov	w11, #0xa               // =10
   146e4:      	sub	w10, w10, #0x30
   146e8:      	madd	w11, w9, w11, w10
   146ec:      	cmp	w10, #0x9
   146f0:      	csel	w9, w9, w11, hi
   146f4:      	cmp	x8, x1
   146f8:      	b.ne	0x14704 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb6f0>
   146fc:      	cmp	w10, #0xa
   14700:      	b.lo	0x14744 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb730>
   14704:      	cmp	w10, #0x9
   14708:      	csel	x8, x0, x8, hi
   1470c:      	ldrb	w8, [x8]
   14710:      	cmp	w8, #0x69
   14714:      	b.ne	0x14744 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb730>
   14718:      	adrp	x8, 0x4000
   1471c:      	cmp	w9, #0x32
   14720:      	mov	w0, #0x1                // =1
   14724:      	ldr	d0, [x8, #0xf10]
   14728:      	mov	w8, #0x40               // =64
   1472c:      	ccmp	w2, #0x4, #0x0, eq
   14730:      	csel	w8, w8, wzr, eq
   14734:      	stur	xzr, [x3, #0xc]
   14738:      	str	d0, [x3]
   1473c:      	str	w8, [x3, #0x8]
   14740:      	ret
   14744:      	mov	w0, wzr
   14748:      	ret
   1474c:      	add	x8, x0, #0x7
   14750:      	cmp	x8, x1
   14754:      	b.ne	0x147e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb7d0>
   14758:      	ldrb	w8, [x0, #0x2]
   1475c:      	ldrb	w9, [x0]
   14760:      	ldrb	w10, [x0, #0x1]
   14764:      	orr	w8, w9, w8, lsl #16
   14768:      	orr	w8, w8, w10, lsl #8
   1476c:      	sub	w8, w8, #0x4d4, lsl #12 // =0x4d4000
   14770:      	cmp	w8, #0x342
   14774:      	b.ne	0x147e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb7d0>
   14778:      	ldrb	w8, [x0, #0x3]
   1477c:      	sub	w8, w8, #0x30
   14780:      	cmp	w8, #0x9
   14784:      	b.hi	0x147e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb7d0>
   14788:      	ldrb	w9, [x0, #0x4]
   1478c:      	sub	w9, w9, #0x30
   14790:      	cmp	w9, #0x9
   14794:      	b.hi	0x147e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb7d0>
   14798:      	ldrb	w10, [x0, #0x5]
   1479c:      	sub	w10, w10, #0x30
   147a0:      	cmp	w10, #0x9
   147a4:      	b.hi	0x147e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb7d0>
   147a8:      	ldrb	w11, [x0, #0x6]
   147ac:      	sub	w11, w11, #0x30
   147b0:      	cmp	w11, #0x9
   147b4:      	b.hi	0x147e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb7d0>
   147b8:      	mov	w12, #0xa               // =10
   147bc:      	mov	w0, #0x1                // =1
   147c0:      	stur	xzr, [x2, #0xc]
   147c4:      	madd	w8, w8, w12, w9
   147c8:      	adrp	x9, 0x4000
   147cc:      	ldr	d0, [x9, #0xf70]
   147d0:      	madd	w8, w8, w12, w10
   147d4:      	str	d0, [x2]
   147d8:      	madd	w8, w8, w12, w11
   147dc:      	str	w8, [x2, #0x8]
   147e0:      	ret
   147e4:      	mov	w0, wzr
   147e8:      	ret
   147ec:      	add	x8, x0, #0x7
   147f0:      	cmp	x8, x1
   147f4:      	b.ne	0x14884 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb870>
   147f8:      	ldrb	w8, [x0]
   147fc:      	cmp	w8, #0x74
   14800:      	b.ne	0x14884 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb870>
   14804:      	ldurh	w8, [x0, #0x1]
   14808:      	mov	w9, #0x6363             // =25443
   1480c:      	cmp	w8, w9
   14810:      	b.ne	0x14884 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb870>
   14814:      	ldrb	w8, [x0, #0x3]
   14818:      	sub	w9, w8, #0x30
   1481c:      	cmp	w9, #0x9
   14820:      	b.hi	0x14884 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb870>
   14824:      	ldrb	w8, [x0, #0x4]
   14828:      	sub	w10, w8, #0x30
   1482c:      	cmp	w10, #0x9
   14830:      	b.hi	0x14884 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb870>
   14834:      	ldrb	w8, [x0, #0x5]
   14838:      	sub	w8, w8, #0x30
   1483c:      	cmp	w8, #0x9
   14840:      	b.hi	0x14884 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb870>
   14844:      	ldrb	w11, [x0, #0x6]
   14848:      	cmp	w11, #0x78
   1484c:      	b.ne	0x14884 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb870>
   14850:      	mov	w11, #0xa               // =10
   14854:      	mov	w12, #0x58              // =88
   14858:      	mov	w0, #0x1                // =1
   1485c:      	madd	w9, w9, w11, w10
   14860:      	adrp	x10, 0x4000
   14864:      	stur	wzr, [x2, #0xd]
   14868:      	ldr	d0, [x10, #0xf80]
   1486c:      	strb	w12, [x2, #0xc]
   14870:      	str	wzr, [x2, #0x10]
   14874:      	madd	w8, w9, w11, w8
   14878:      	str	d0, [x2]
   1487c:      	str	w8, [x2, #0x8]
   14880:      	ret
   14884:      	mov	w0, wzr
   14888:      	ret
   1488c:      	sub	sp, sp, #0x50
   14890:      	stp	x29, x30, [sp, #0x20]
   14894:      	stp	x22, x21, [sp, #0x30]
   14898:      	stp	x20, x19, [sp, #0x40]
   1489c:      	add	x29, sp, #0x20
   148a0:      	mrs	x22, TPIDR_EL0
   148a4:      	mov	x19, x8
   148a8:      	mov	w1, #0x5c               // =92
   148ac:      	ldr	x8, [x22, #0x28]
   148b0:      	mov	x20, x0
   148b4:      	stur	x8, [x29, #-0x8]
   148b8:      	bl	0x1d810 <strnlen@plt>
   148bc:      	mov	x21, x0
   148c0:      	add	x1, x20, x0
   148c4:      	mov	x3, sp
   148c8:      	mov	x0, x20
   148cc:      	mov	w2, #0x1                // =1
   148d0:      	bl	0x13a28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaa14>
   148d4:      	tbz	w0, #0x0, 0x148fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb8e8>
   148d8:      	ldr	q0, [sp]
   148dc:      	ldr	w8, [sp, #0x10]
   148e0:      	str	q0, [x19]
   148e4:      	str	w8, [x19, #0x10]
   148e8:      	ldr	x8, [x22, #0x28]
   148ec:      	ldur	x9, [x29, #-0x8]
   148f0:      	cmp	x8, x9
   148f4:      	b.eq	0x14b5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb48>
   148f8:      	b	0x14b9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb88>
   148fc:      	cmp	x21, #0x6
   14900:      	b.ne	0x14970 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb95c>
   14904:      	ldrh	w8, [x20]
   14908:      	mov	w9, #0x4d53             // =19795
   1490c:      	cmp	w8, w9
   14910:      	b.ne	0x14974 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb960>
   14914:      	ldrb	w8, [x20, #0x2]
   14918:      	sub	w8, w8, #0x30
   1491c:      	cmp	w8, #0x9
   14920:      	b.hi	0x14974 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb960>
   14924:      	ldrb	w9, [x20, #0x3]
   14928:      	sub	w9, w9, #0x30
   1492c:      	cmp	w9, #0x9
   14930:      	b.hi	0x14974 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb960>
   14934:      	ldrb	w10, [x20, #0x4]
   14938:      	sub	w10, w10, #0x30
   1493c:      	cmp	w10, #0x9
   14940:      	b.hi	0x14974 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb960>
   14944:      	ldrb	w11, [x20, #0x5]
   14948:      	sub	w11, w11, #0x30
   1494c:      	cmp	w11, #0x9
   14950:      	b.hi	0x14974 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb960>
   14954:      	mov	w12, #0xa               // =10
   14958:      	madd	w8, w8, w12, w9
   1495c:      	adrp	x9, 0x4000
   14960:      	ldr	d0, [x9, #0xf20]
   14964:      	madd	w8, w8, w12, w10
   14968:      	madd	w8, w8, w12, w11
   1496c:      	b	0x14b30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb1c>
   14970:      	b.lt	0x149dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb9c8>
   14974:      	ldrb	w8, [x20, #0x2]
   14978:      	ldrb	w9, [x20]
   1497c:      	ldrb	w10, [x20, #0x1]
   14980:      	orr	w8, w9, w8, lsl #16
   14984:      	orr	w8, w8, w10, lsl #8
   14988:      	sub	w8, w8, #0x4d4, lsl #12 // =0x4d4000
   1498c:      	cmp	w8, #0x453
   14990:      	b.ne	0x149dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb9c8>
   14994:      	ldrb	w8, [x20, #0x3]
   14998:      	sub	w8, w8, #0x30
   1499c:      	cmp	w8, #0x9
   149a0:      	b.hi	0x149dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb9c8>
   149a4:      	ldrb	w9, [x20, #0x4]
   149a8:      	sub	w9, w9, #0x30
   149ac:      	cmp	w9, #0x9
   149b0:      	b.hi	0x149dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb9c8>
   149b4:      	ldrb	w10, [x20, #0x5]
   149b8:      	sub	w10, w10, #0x30
   149bc:      	cmp	w10, #0x9
   149c0:      	b.hi	0x149dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb9c8>
   149c4:      	mov	w11, #0xa               // =10
   149c8:      	madd	w8, w8, w11, w9
   149cc:      	adrp	x9, 0x4000
   149d0:      	ldr	d0, [x9, #0xf20]
   149d4:      	madd	w8, w8, w11, w10
   149d8:      	b	0x14b30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb1c>
   149dc:      	ldr	w8, [x20]
   149e0:      	cmp	x21, #0xa
   149e4:      	b.ne	0x14a64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba50>
   149e8:      	mov	w9, #0x7865             // =30821
   149ec:      	movk	w9, #0x6e79, lsl #16
   149f0:      	cmp	w8, w9
   149f4:      	b.ne	0x14a64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba50>
   149f8:      	ldrh	w9, [x20, #0x4]
   149fc:      	mov	w10, #0x736f            // =29551
   14a00:      	cmp	w9, w10
   14a04:      	b.ne	0x14a64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba50>
   14a08:      	ldrb	w9, [x20, #0x6]
   14a0c:      	sub	w9, w9, #0x30
   14a10:      	cmp	w9, #0x9
   14a14:      	b.hi	0x14a64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba50>
   14a18:      	ldrb	w10, [x20, #0x7]
   14a1c:      	sub	w10, w10, #0x30
   14a20:      	cmp	w10, #0x9
   14a24:      	b.hi	0x14a64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba50>
   14a28:      	ldrb	w11, [x20, #0x8]
   14a2c:      	sub	w11, w11, #0x30
   14a30:      	cmp	w11, #0x9
   14a34:      	b.hi	0x14a64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba50>
   14a38:      	ldrb	w12, [x20, #0x9]
   14a3c:      	sub	w12, w12, #0x30
   14a40:      	cmp	w12, #0x9
   14a44:      	b.hi	0x14a64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba50>
   14a48:      	mov	w8, #0xa                // =10
   14a4c:      	madd	w9, w9, w8, w10
   14a50:      	adrp	x10, 0x4000
   14a54:      	ldr	d0, [x10, #0xf58]
   14a58:      	madd	w9, w9, w8, w11
   14a5c:      	madd	w8, w9, w8, w12
   14a60:      	b	0x14b30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb1c>
   14a64:      	sub	x9, x21, #0xb
   14a68:      	cmp	x9, #0x1
   14a6c:      	b.hi	0x14ad8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbac4>
   14a70:      	mov	w9, #0x6e55             // =28245
   14a74:      	movk	w9, #0x7369, lsl #16
   14a78:      	cmp	w8, w9
   14a7c:      	b.ne	0x14ad8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbac4>
   14a80:      	ldr	w9, [x20, #0x4]
   14a84:      	mov	w10, #0x636f            // =25455
   14a88:      	movk	w10, #0x5420, lsl #16
   14a8c:      	cmp	w9, w10
   14a90:      	b.ne	0x14ad8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbac4>
   14a94:      	mov	w9, wzr
   14a98:      	mov	w10, #0x8               // =8
   14a9c:      	mov	w11, #0xa               // =10
   14aa0:      	ldrb	w12, [x20, x10]
   14aa4:      	sub	w12, w12, #0x30
   14aa8:      	cmp	w12, #0x9
   14aac:      	b.hi	0x14ad8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbac4>
   14ab0:      	madd	w9, w9, w11, w12
   14ab4:      	add	x10, x10, #0x1
   14ab8:      	cmp	w10, w21
   14abc:      	b.lo	0x14aa0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xba8c>
   14ac0:      	adrp	x8, 0x4000
   14ac4:      	stur	xzr, [sp, #0xc]
   14ac8:      	ldr	d0, [x8, #0xf48]
   14acc:      	str	w9, [sp, #0x8]
   14ad0:      	str	d0, [sp]
   14ad4:      	b	0x14b3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb28>
   14ad8:      	cmp	x21, #0x4
   14adc:      	b.lt	0x14b70 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb5c>
   14ae0:      	and	w9, w8, #0xff
   14ae4:      	cmp	w9, #0x54
   14ae8:      	b.ne	0x14b70 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb5c>
   14aec:      	ubfx	w9, w8, #8, #8
   14af0:      	sub	w9, w9, #0x30
   14af4:      	cmp	w9, #0x9
   14af8:      	b.hi	0x14b70 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb5c>
   14afc:      	ubfx	w10, w8, #16, #8
   14b00:      	sub	w10, w10, #0x30
   14b04:      	cmp	w10, #0x9
   14b08:      	b.hi	0x14b70 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb5c>
   14b0c:      	lsr	w8, w8, #24
   14b10:      	sub	w8, w8, #0x30
   14b14:      	cmp	w8, #0x9
   14b18:      	b.hi	0x14b70 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb5c>
   14b1c:      	mov	w11, #0xa               // =10
   14b20:      	madd	w9, w9, w11, w10
   14b24:      	adrp	x10, 0x4000
   14b28:      	ldr	d0, [x10, #0xf48]
   14b2c:      	madd	w8, w9, w11, w8
   14b30:      	str	d0, [sp]
   14b34:      	stur	xzr, [sp, #0xc]
   14b38:      	str	w8, [sp, #0x8]
   14b3c:      	ldr	w8, [sp, #0x10]
   14b40:      	ldr	q0, [sp]
   14b44:      	str	w8, [x19, #0x10]
   14b48:      	str	q0, [x19]
   14b4c:      	ldr	x8, [x22, #0x28]
   14b50:      	ldur	x9, [x29, #-0x8]
   14b54:      	cmp	x8, x9
   14b58:      	b.ne	0x14b9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb88>
   14b5c:      	ldp	x20, x19, [sp, #0x40]
   14b60:      	ldp	x22, x21, [sp, #0x30]
   14b64:      	ldp	x29, x30, [sp, #0x20]
   14b68:      	add	sp, sp, #0x50
   14b6c:      	ret
   14b70:      	ldr	x8, [x22, #0x28]
   14b74:      	ldur	x9, [x29, #-0x8]
   14b78:      	cmp	x8, x9
   14b7c:      	b.ne	0x14b9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb88>
   14b80:      	stp	xzr, xzr, [x19]
   14b84:      	str	wzr, [x19, #0x10]
   14b88:      	ldp	x20, x19, [sp, #0x40]
   14b8c:      	ldp	x22, x21, [sp, #0x30]
   14b90:      	ldp	x29, x30, [sp, #0x20]
   14b94:      	add	sp, sp, #0x50
   14b98:      	ret
   14b9c:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   14ba0:      	add	x8, x0, #0xa
   14ba4:      	cmp	x8, x1
   14ba8:      	b.ne	0x14c3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbc28>
   14bac:      	ldr	w8, [x0]
   14bb0:      	mov	w9, #0x7865             // =30821
   14bb4:      	movk	w9, #0x6e79, lsl #16
   14bb8:      	cmp	w8, w9
   14bbc:      	b.ne	0x14c3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbc28>
   14bc0:      	ldrh	w8, [x0, #0x4]
   14bc4:      	mov	w9, #0x736f             // =29551
   14bc8:      	cmp	w8, w9
   14bcc:      	b.ne	0x14c3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbc28>
   14bd0:      	ldrb	w8, [x0, #0x6]
   14bd4:      	sub	w8, w8, #0x30
   14bd8:      	cmp	w8, #0x9
   14bdc:      	b.hi	0x14c3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbc28>
   14be0:      	ldrb	w9, [x0, #0x7]
   14be4:      	sub	w9, w9, #0x30
   14be8:      	cmp	w9, #0x9
   14bec:      	b.hi	0x14c3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbc28>
   14bf0:      	ldrb	w10, [x0, #0x8]
   14bf4:      	sub	w10, w10, #0x30
   14bf8:      	cmp	w10, #0x9
   14bfc:      	b.hi	0x14c3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbc28>
   14c00:      	ldrb	w11, [x0, #0x9]
   14c04:      	sub	w11, w11, #0x30
   14c08:      	cmp	w11, #0x9
   14c0c:      	b.hi	0x14c3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbc28>
   14c10:      	mov	w12, #0xa               // =10
   14c14:      	mov	w0, #0x1                // =1
   14c18:      	stur	xzr, [x2, #0xc]
   14c1c:      	madd	w8, w8, w12, w9
   14c20:      	adrp	x9, 0x4000
   14c24:      	ldr	d0, [x9, #0xf58]
   14c28:      	madd	w8, w8, w12, w10
   14c2c:      	str	d0, [x2]
   14c30:      	madd	w8, w8, w12, w11
   14c34:      	str	w8, [x2, #0x8]
   14c38:      	ret
   14c3c:      	mov	w0, wzr
   14c40:      	ret
   14c44:      	sub	sp, sp, #0x50
   14c48:      	stp	x29, x30, [sp, #0x20]
   14c4c:      	stp	x22, x21, [sp, #0x30]
   14c50:      	stp	x20, x19, [sp, #0x40]
   14c54:      	add	x29, sp, #0x20
   14c58:      	mrs	x22, TPIDR_EL0
   14c5c:      	mov	x19, x8
   14c60:      	mov	w1, #0x5c               // =92
   14c64:      	ldr	x8, [x22, #0x28]
   14c68:      	mov	x20, x0
   14c6c:      	stur	x8, [x29, #-0x8]
   14c70:      	bl	0x1d810 <strnlen@plt>
   14c74:      	mov	x21, x0
   14c78:      	add	x1, x20, x0
   14c7c:      	mov	x3, sp
   14c80:      	mov	x0, x20
   14c84:      	mov	w2, #0x1                // =1
   14c88:      	bl	0x13a28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaa14>
   14c8c:      	tbz	w0, #0x0, 0x14cc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbcb0>
   14c90:      	ldr	q0, [sp]
   14c94:      	ldr	w8, [sp, #0x10]
   14c98:      	str	q0, [x19]
   14c9c:      	str	w8, [x19, #0x10]
   14ca0:      	ldr	x8, [x22, #0x28]
   14ca4:      	ldur	x9, [x29, #-0x8]
   14ca8:      	cmp	x8, x9
   14cac:      	b.ne	0x14e48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbe34>
   14cb0:      	ldp	x20, x19, [sp, #0x40]
   14cb4:      	ldp	x22, x21, [sp, #0x30]
   14cb8:      	ldp	x29, x30, [sp, #0x20]
   14cbc:      	add	sp, sp, #0x50
   14cc0:      	ret
   14cc4:      	ldr	w8, [x20]
   14cc8:      	cmp	x21, #0xa
   14ccc:      	b.ne	0x14d58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbd44>
   14cd0:      	mov	w9, #0x7865             // =30821
   14cd4:      	movk	w9, #0x6e79, lsl #16
   14cd8:      	cmp	w8, w9
   14cdc:      	b.ne	0x14d58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbd44>
   14ce0:      	ldrh	w8, [x20, #0x4]
   14ce4:      	mov	w9, #0x736f             // =29551
   14ce8:      	cmp	w8, w9
   14cec:      	b.ne	0x14d64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbd50>
   14cf0:      	ldrb	w8, [x20, #0x6]
   14cf4:      	sub	w8, w8, #0x30
   14cf8:      	cmp	w8, #0x9
   14cfc:      	b.hi	0x14d64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbd50>
   14d00:      	ldrb	w9, [x20, #0x7]
   14d04:      	sub	w9, w9, #0x30
   14d08:      	cmp	w9, #0x9
   14d0c:      	b.hi	0x14d64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbd50>
   14d10:      	ldrb	w10, [x20, #0x8]
   14d14:      	sub	w10, w10, #0x30
   14d18:      	cmp	w10, #0x9
   14d1c:      	b.hi	0x14d64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbd50>
   14d20:      	ldrb	w11, [x20, #0x9]
   14d24:      	sub	w11, w11, #0x30
   14d28:      	cmp	w11, #0x9
   14d2c:      	b.hi	0x14d64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbd50>
   14d30:      	mov	w12, #0xa               // =10
   14d34:      	stur	xzr, [sp, #0xc]
   14d38:      	madd	w8, w8, w12, w9
   14d3c:      	adrp	x9, 0x4000
   14d40:      	ldr	d0, [x9, #0xf58]
   14d44:      	madd	w8, w8, w12, w10
   14d48:      	str	d0, [sp]
   14d4c:      	madd	w8, w8, w12, w11
   14d50:      	str	w8, [sp, #0x8]
   14d54:      	b	0x14e28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbe14>
   14d58:      	sub	x9, x21, #0xc
   14d5c:      	cmn	x9, #0x4
   14d60:      	b.hs	0x14d90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbd7c>
   14d64:      	ldr	x8, [x22, #0x28]
   14d68:      	ldur	x9, [x29, #-0x8]
   14d6c:      	cmp	x8, x9
   14d70:      	b.ne	0x14e48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbe34>
   14d74:      	stp	xzr, xzr, [x19]
   14d78:      	str	wzr, [x19, #0x10]
   14d7c:      	ldp	x20, x19, [sp, #0x40]
   14d80:      	ldp	x22, x21, [sp, #0x30]
   14d84:      	ldp	x29, x30, [sp, #0x20]
   14d88:      	add	sp, sp, #0x50
   14d8c:      	ret
   14d90:      	mov	w9, #0xdf               // =223
   14d94:      	and	w8, w8, w9
   14d98:      	cmp	w8, #0x4b
   14d9c:      	b.ne	0x14d64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbd50>
   14da0:      	ldur	w8, [x20, #0x1]
   14da4:      	mov	w9, #0x7269             // =29289
   14da8:      	movk	w9, #0x6e69, lsl #16
   14dac:      	cmp	w8, w9
   14db0:      	b.ne	0x14d64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbd50>
   14db4:      	ldrb	w9, [x20, #0x5]
   14db8:      	mov	w8, #0x5                // =5
   14dbc:      	cmp	w9, #0x20
   14dc0:      	b.hi	0x14de0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbdcc>
   14dc4:      	mov	w10, #0x1               // =1
   14dc8:      	lsl	x9, x10, x9
   14dcc:      	mov	x10, #0x2600            // =9728
   14dd0:      	movk	x10, #0x1, lsl #32
   14dd4:      	tst	x9, x10
   14dd8:      	b.eq	0x14de0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbdcc>
   14ddc:      	mov	w8, #0x6                // =6
   14de0:      	mov	w9, wzr
   14de4:      	mov	w11, #0xa               // =10
   14de8:      	ldrb	w10, [x20, x8]
   14dec:      	sub	w12, w10, #0x30
   14df0:      	cmp	w12, #0x9
   14df4:      	b.hi	0x14e0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbdf8>
   14df8:      	madd	w9, w9, w11, w12
   14dfc:      	add	x8, x8, #0x1
   14e00:      	cmp	x21, x8
   14e04:      	b.hi	0x14de8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbdd4>
   14e08:      	mov	w10, wzr
   14e0c:      	adrp	x8, 0x4000
   14e10:      	str	w9, [sp, #0x8]
   14e14:      	ldr	d0, [x8, #0xf30]
   14e18:      	str	wzr, [sp, #0x10]
   14e1c:      	stur	wzr, [sp, #0xd]
   14e20:      	str	d0, [sp]
   14e24:      	strb	w10, [sp, #0xc]
   14e28:      	ldr	w8, [sp, #0x10]
   14e2c:      	ldr	q0, [sp]
   14e30:      	str	w8, [x19, #0x10]
   14e34:      	str	q0, [x19]
   14e38:      	ldr	x8, [x22, #0x28]
   14e3c:      	ldur	x9, [x29, #-0x8]
   14e40:      	cmp	x8, x9
   14e44:      	b.eq	0x14cb0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbc9c>
   14e48:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   14e4c:      	sub	sp, sp, #0xf0
   14e50:      	stp	x29, x30, [sp, #0xb0]
   14e54:      	str	x23, [sp, #0xc0]
   14e58:      	stp	x22, x21, [sp, #0xd0]
   14e5c:      	stp	x20, x19, [sp, #0xe0]
   14e60:      	add	x29, sp, #0xb0
   14e64:      	mrs	x23, TPIDR_EL0
   14e68:      	mov	x19, x8
   14e6c:      	mov	w1, #0x5c               // =92
   14e70:      	ldr	x8, [x23, #0x28]
   14e74:      	mov	x20, x0
   14e78:      	stur	x8, [x29, #-0x8]
   14e7c:      	bl	0x1d810 <strnlen@plt>
   14e80:      	mov	x21, x0
   14e84:      	add	x1, x20, x0
   14e88:      	add	x2, sp, #0x8
   14e8c:      	mov	x0, x20
   14e90:      	bl	0x1361c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa608>
   14e94:      	tbnz	w0, #0x0, 0x15054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc040>
   14e98:      	cmp	x21, #0x4
   14e9c:      	b.lt	0x14f10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbefc>
   14ea0:      	ldr	w8, [x20]
   14ea4:      	mov	w9, #0x4154             // =16724
   14ea8:      	movk	w9, #0x4f52, lsl #16
   14eac:      	and	w8, w8, #0xdfdfdfdf
   14eb0:      	cmp	w8, w9
   14eb4:      	b.ne	0x14f10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbefc>
   14eb8:      	movi	v0.2d, #0000000000000000
   14ebc:      	adrp	x0, 0x2000
   14ec0:      	add	x0, x0, #0xccc
   14ec4:      	add	x1, sp, #0x20
   14ec8:      	stp	q0, q0, [sp, #0x20]
   14ecc:      	stp	q0, q0, [sp, #0x40]
   14ed0:      	stp	q0, q0, [sp, #0x60]
   14ed4:      	stp	q0, q0, [sp, #0x80]
   14ed8:      	bl	0x1d7f0 <__system_property_get@plt>
   14edc:      	cmp	w0, #0x1
   14ee0:      	mov	w0, wzr
   14ee4:      	b.lt	0x15090 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc07c>
   14ee8:      	ldrb	w8, [sp, #0x20]
   14eec:      	cbz	w8, 0x15090 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc07c>
   14ef0:      	add	x0, sp, #0x20
   14ef4:      	sub	w8, w8, #0x3a
   14ef8:      	cmn	w8, #0xb
   14efc:      	b.hi	0x1508c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc078>
   14f00:      	ldrb	w8, [x0, #0x1]!
   14f04:      	cbnz	w8, 0x14ef4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbee0>
   14f08:      	mov	w0, wzr
   14f0c:      	b	0x15090 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc07c>
   14f10:      	add	x1, x20, x21
   14f14:      	add	x2, sp, #0x8
   14f18:      	mov	x0, x20
   14f1c:      	bl	0x138a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa88c>
   14f20:      	tbnz	w0, #0x0, 0x15054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc040>
   14f24:      	cmp	x21, #0xd
   14f28:      	b.ne	0x14fd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbfc4>
   14f2c:      	ldrb	w8, [x20]
   14f30:      	and	w8, w8, #0xffffffdf
   14f34:      	cmp	w8, #0x55
   14f38:      	b.ne	0x14fd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbfc4>
   14f3c:      	ldur	w8, [x20, #0x1]
   14f40:      	mov	w9, #0x494e             // =18766
   14f44:      	movk	w9, #0x4556, lsl #16
   14f48:      	and	w8, w8, #0xdfdfdfdf
   14f4c:      	cmp	w8, w9
   14f50:      	b.ne	0x14fd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbfc4>
   14f54:      	ldur	w8, [x20, #0x5]
   14f58:      	mov	w9, #-0x20202021        // =-538976289
   14f5c:      	and	w8, w8, w9
   14f60:      	mov	w9, #0x5352             // =21330
   14f64:      	movk	w9, #0x4c41, lsl #16
   14f68:      	cmp	w8, w9
   14f6c:      	b.ne	0x14fd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbfc4>
   14f70:      	ldrb	w8, [x20, #0x9]
   14f74:      	sub	w8, w8, #0x30
   14f78:      	cmp	w8, #0x9
   14f7c:      	b.hi	0x14fd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbfc4>
   14f80:      	ldrb	w9, [x20, #0xa]
   14f84:      	sub	w9, w9, #0x30
   14f88:      	cmp	w9, #0x9
   14f8c:      	b.hi	0x14fd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbfc4>
   14f90:      	ldrb	w10, [x20, #0xb]
   14f94:      	sub	w10, w10, #0x30
   14f98:      	cmp	w10, #0x9
   14f9c:      	b.hi	0x14fd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbfc4>
   14fa0:      	ldrb	w11, [x20, #0xc]
   14fa4:      	sub	w11, w11, #0x30
   14fa8:      	cmp	w11, #0x9
   14fac:      	b.hi	0x14fd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbfc4>
   14fb0:      	mov	w12, #0xa               // =10
   14fb4:      	stur	xzr, [sp, #0x14]
   14fb8:      	madd	w8, w8, w12, w9
   14fbc:      	adrp	x9, 0x4000
   14fc0:      	ldr	d0, [x9, #0xf58]
   14fc4:      	madd	w8, w8, w12, w10
   14fc8:      	str	d0, [sp, #0x8]
   14fcc:      	madd	w8, w8, w12, w11
   14fd0:      	str	w8, [sp, #0x10]
   14fd4:      	b	0x150a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc090>
   14fd8:      	add	x1, x20, x21
   14fdc:      	add	x3, sp, #0x8
   14fe0:      	mov	x0, x20
   14fe4:      	mov	w2, #0x1                // =1
   14fe8:      	bl	0x13a28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaa14>
   14fec:      	tbnz	w0, #0x0, 0x15054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc040>
   14ff0:      	add	x1, x20, x21
   14ff4:      	add	x2, sp, #0x8
   14ff8:      	mov	x0, x20
   14ffc:      	bl	0x14484 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb470>
   15000:      	tbnz	w0, #0x0, 0x15054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc040>
   15004:      	add	x1, x20, x21
   15008:      	add	x2, sp, #0x8
   1500c:      	mov	x0, x20
   15010:      	bl	0x152d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc2c4>
   15014:      	tbnz	w0, #0x0, 0x15054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc040>
   15018:      	add	x1, x20, x21
   1501c:      	add	x2, sp, #0x8
   15020:      	mov	x0, x20
   15024:      	bl	0x142a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb28c>
   15028:      	tbnz	w0, #0x0, 0x15054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc040>
   1502c:      	add	x1, x20, x21
   15030:      	add	x2, sp, #0x8
   15034:      	mov	x0, x20
   15038:      	bl	0x1536c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc358>
   1503c:      	tbnz	w0, #0x0, 0x15054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc040>
   15040:      	add	x1, x20, x21
   15044:      	add	x2, sp, #0x8
   15048:      	mov	x0, x20
   1504c:      	bl	0x159c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9b0>
   15050:      	tbz	w0, #0x0, 0x150b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc0a4>
   15054:      	ldur	q0, [sp, #0x8]
   15058:      	ldr	w8, [sp, #0x18]
   1505c:      	str	q0, [x19]
   15060:      	str	w8, [x19, #0x10]
   15064:      	ldr	x8, [x23, #0x28]
   15068:      	ldur	x9, [x29, #-0x8]
   1506c:      	cmp	x8, x9
   15070:      	b.ne	0x152d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc2c0>
   15074:      	ldp	x20, x19, [sp, #0xe0]
   15078:      	ldr	x23, [sp, #0xc0]
   1507c:      	ldp	x22, x21, [sp, #0xd0]
   15080:      	ldp	x29, x30, [sp, #0xb0]
   15084:      	add	sp, sp, #0xf0
   15088:      	ret
   1508c:      	bl	0x1d7a0 <atoi@plt>
   15090:      	adrp	x8, 0x4000
   15094:      	stur	xzr, [sp, #0x14]
   15098:      	ldr	d0, [x8, #0xf20]
   1509c:      	str	w0, [sp, #0x10]
   150a0:      	str	d0, [sp, #0x8]
   150a4:      	ldr	w8, [sp, #0x18]
   150a8:      	ldur	q0, [sp, #0x8]
   150ac:      	str	w8, [x19, #0x10]
   150b0:      	str	q0, [x19]
   150b4:      	b	0x15064 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc050>
   150b8:      	adrp	x22, 0x2000
   150bc:      	add	x22, x22, #0xcc0
   150c0:      	mov	x1, x20
   150c4:      	mov	x0, x22
   150c8:      	mov	x2, x21
   150cc:      	bl	0x1d8c0 <strncmp@plt>
   150d0:      	cbnz	w0, 0x150dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc0c8>
   150d4:      	ldrb	w8, [x22, x21]
   150d8:      	cbz	w8, 0x1522c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc218>
   150dc:      	adrp	x22, 0x4000
   150e0:      	add	x22, x22, #0xd48
   150e4:      	mov	x1, x20
   150e8:      	mov	x0, x22
   150ec:      	mov	x2, x21
   150f0:      	bl	0x1d8c0 <strncmp@plt>
   150f4:      	cbnz	w0, 0x15100 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc0ec>
   150f8:      	ldrb	w8, [x22, x21]
   150fc:      	cbz	w8, 0x15234 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc220>
   15100:      	adrp	x22, 0x3000
   15104:      	add	x22, x22, #0xed9
   15108:      	mov	x1, x20
   1510c:      	mov	x0, x22
   15110:      	mov	x2, x21
   15114:      	bl	0x1d8c0 <strncmp@plt>
   15118:      	cbnz	w0, 0x15124 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc110>
   1511c:      	ldrb	w8, [x22, x21]
   15120:      	cbz	w8, 0x1523c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc228>
   15124:      	adrp	x22, 0x3000
   15128:      	add	x22, x22, #0x178
   1512c:      	mov	x1, x20
   15130:      	mov	x0, x22
   15134:      	mov	x2, x21
   15138:      	bl	0x1d8c0 <strncmp@plt>
   1513c:      	cbnz	w0, 0x15148 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc134>
   15140:      	ldrb	w8, [x22, x21]
   15144:      	cbz	w8, 0x15244 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc230>
   15148:      	adrp	x22, 0x4000
   1514c:      	add	x22, x22, #0x532
   15150:      	mov	x1, x20
   15154:      	mov	x0, x22
   15158:      	mov	x2, x21
   1515c:      	bl	0x1d8c0 <strncmp@plt>
   15160:      	cbnz	w0, 0x1516c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc158>
   15164:      	ldrb	w8, [x22, x21]
   15168:      	cbz	w8, 0x1524c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc238>
   1516c:      	adrp	x22, 0x4000
   15170:      	add	x22, x22, #0xae2
   15174:      	mov	x1, x20
   15178:      	mov	x0, x22
   1517c:      	mov	x2, x21
   15180:      	bl	0x1d8c0 <strncmp@plt>
   15184:      	cbnz	w0, 0x15190 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc17c>
   15188:      	ldrb	w8, [x22, x21]
   1518c:      	cbz	w8, 0x15254 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc240>
   15190:      	adrp	x22, 0x3000
   15194:      	add	x22, x22, #0x34
   15198:      	mov	x1, x20
   1519c:      	mov	x0, x22
   151a0:      	mov	x2, x21
   151a4:      	bl	0x1d8c0 <strncmp@plt>
   151a8:      	cbnz	w0, 0x151b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc1a0>
   151ac:      	ldrb	w8, [x22, x21]
   151b0:      	cbz	w8, 0x1525c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc248>
   151b4:      	adrp	x22, 0x3000
   151b8:      	add	x22, x22, #0x3d
   151bc:      	mov	x1, x20
   151c0:      	mov	x0, x22
   151c4:      	mov	x2, x21
   151c8:      	bl	0x1d8c0 <strncmp@plt>
   151cc:      	cbnz	w0, 0x151d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc1c4>
   151d0:      	ldrb	w8, [x22, x21]
   151d4:      	cbz	w8, 0x15264 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc250>
   151d8:      	adrp	x22, 0x2000
   151dc:      	add	x22, x22, #0xeaf
   151e0:      	mov	x1, x20
   151e4:      	mov	x0, x22
   151e8:      	mov	x2, x21
   151ec:      	bl	0x1d8c0 <strncmp@plt>
   151f0:      	cbnz	w0, 0x151fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc1e8>
   151f4:      	ldrb	w8, [x22, x21]
   151f8:      	cbz	w8, 0x1526c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc258>
   151fc:      	adrp	x22, 0x4000
   15200:      	add	x22, x22, #0xd52
   15204:      	mov	x1, x20
   15208:      	mov	x0, x22
   1520c:      	mov	x2, x21
   15210:      	bl	0x1d8c0 <strncmp@plt>
   15214:      	cbnz	w0, 0x15220 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc20c>
   15218:      	ldrb	w8, [x22, x21]
   1521c:      	cbz	w8, 0x15274 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc260>
   15220:      	stp	xzr, xzr, [x19]
   15224:      	str	wzr, [x19, #0x10]
   15228:      	b	0x15064 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc050>
   1522c:      	mov	x8, xzr
   15230:      	b	0x15278 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc264>
   15234:      	mov	w8, #0x1                // =1
   15238:      	b	0x15278 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc264>
   1523c:      	mov	w8, #0x2                // =2
   15240:      	b	0x15278 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc264>
   15244:      	mov	w8, #0x3                // =3
   15248:      	b	0x15278 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc264>
   1524c:      	mov	w8, #0x4                // =4
   15250:      	b	0x15278 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc264>
   15254:      	mov	w8, #0x5                // =5
   15258:      	b	0x15278 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc264>
   1525c:      	mov	w8, #0x6                // =6
   15260:      	b	0x15278 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc264>
   15264:      	mov	w8, #0x7                // =7
   15268:      	b	0x15278 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc264>
   1526c:      	mov	w8, #0x8                // =8
   15270:      	b	0x15278 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc264>
   15274:      	mov	w8, #0x9                // =9
   15278:      	nop
   1527c:      	adr	x9, 0x21a68
   15280:      	nop
   15284:      	adr	x10, 0x5270
   15288:      	add	x9, x9, x8, lsl #4
   1528c:      	and	x8, x8, #0xe
   15290:      	cmp	x8, #0x8
   15294:      	stur	wzr, [x19, #0xf]
   15298:      	ldrh	w11, [x9, #0x8]
   1529c:      	ldrb	w8, [x9, #0xb]
   152a0:      	ldrb	w9, [x9, #0xa]
   152a4:      	strb	wzr, [x19, #0x13]
   152a8:      	str	w11, [x19, #0x8]
   152ac:      	mov	w11, #0x52              // =82
   152b0:      	ldr	w10, [x10, w9, uxtw #2]
   152b4:      	strb	w8, [x19, #0xc]
   152b8:      	mov	w8, #0x4f               // =79
   152bc:      	csel	w11, w11, wzr, eq
   152c0:      	csel	w8, w8, wzr, eq
   152c4:      	strb	w11, [x19, #0xd]
   152c8:      	strb	w8, [x19, #0xe]
   152cc:      	stp	w10, w9, [x19]
   152d0:      	b	0x15064 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc050>
   152d4:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   152d8:      	add	x8, x0, #0x7
   152dc:      	cmp	x8, x1
   152e0:      	b.ne	0x15364 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc350>
   152e4:      	ldr	w8, [x0]
   152e8:      	and	w9, w8, #0xffffff
   152ec:      	sub	w9, w9, #0x653, lsl #12 // =0x653000
   152f0:      	cmp	w9, #0x573
   152f4:      	b.ne	0x15364 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc350>
   152f8:      	lsr	w8, w8, #24
   152fc:      	sub	w8, w8, #0x30
   15300:      	cmp	w8, #0x9
   15304:      	b.hi	0x15364 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc350>
   15308:      	ldrb	w9, [x0, #0x4]
   1530c:      	sub	w9, w9, #0x30
   15310:      	cmp	w9, #0x9
   15314:      	b.hi	0x15364 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc350>
   15318:      	ldrb	w10, [x0, #0x5]
   1531c:      	sub	w10, w10, #0x30
   15320:      	cmp	w10, #0x9
   15324:      	b.hi	0x15364 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc350>
   15328:      	ldrb	w11, [x0, #0x6]
   1532c:      	sub	w11, w11, #0x30
   15330:      	cmp	w11, #0x9
   15334:      	b.hi	0x15364 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc350>
   15338:      	mov	w12, #0xa               // =10
   1533c:      	mov	w0, #0x1                // =1
   15340:      	stur	xzr, [x2, #0xc]
   15344:      	madd	w8, w8, w12, w9
   15348:      	adrp	x9, 0x4000
   1534c:      	ldr	d0, [x9, #0xef8]
   15350:      	madd	w8, w8, w12, w10
   15354:      	str	d0, [x2]
   15358:      	madd	w8, w8, w12, w11
   1535c:      	str	w8, [x2, #0x8]
   15360:      	ret
   15364:      	mov	w0, wzr
   15368:      	ret
   1536c:      	sub	x9, x1, x0
   15370:      	mov	w8, wzr
   15374:      	cmp	x9, #0x8
   15378:      	b.hi	0x159bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a8>
   1537c:      	mov	w10, #0x1               // =1
   15380:      	mov	w11, #0x188             // =392
   15384:      	lsl	x10, x10, x9
   15388:      	tst	x10, x11
   1538c:      	b.eq	0x159bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a8>
   15390:      	ldrb	w8, [x0, #0x2]
   15394:      	ldrb	w10, [x0]
   15398:      	ldrb	w11, [x0, #0x1]
   1539c:      	orr	w8, w10, w8, lsl #16
   153a0:      	orr	w10, w8, w11, lsl #8
   153a4:      	mov	w8, #0x4f42             // =20290
   153a8:      	movk	w8, #0x4c, lsl #16
   153ac:      	cmp	w10, w8
   153b0:      	mov	w8, wzr
   153b4:      	b.le	0x15428 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc414>
   153b8:      	mov	w11, #0x414f            // =16719
   153bc:      	movk	w11, #0x52, lsl #16
   153c0:      	cmp	w10, w11
   153c4:      	b.gt	0x15498 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc484>
   153c8:      	mov	w11, #0x434c            // =17228
   153cc:      	movk	w11, #0x4e, lsl #16
   153d0:      	cmp	w10, w11
   153d4:      	b.le	0x155f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc5e4>
   153d8:      	mov	w11, #0x454d            // =17741
   153dc:      	movk	w11, #0x4f, lsl #16
   153e0:      	cmp	w10, w11
   153e4:      	b.gt	0x156d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc6c4>
   153e8:      	mov	w11, #0x434d            // =17229
   153ec:      	movk	w11, #0x4e, lsl #16
   153f0:      	cmp	w10, w11
   153f4:      	b.eq	0x15818 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc804>
   153f8:      	mov	w11, #0x4f4c            // =20300
   153fc:      	movk	w11, #0x4e, lsl #16
   15400:      	cmp	w10, w11
   15404:      	b.ne	0x159bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a8>
   15408:      	mov	w8, #0xd                // =13
   1540c:      	nop
   15410:      	adr	x10, 0x5320
   15414:      	cmp	x9, #0x4
   15418:      	add	x8, x10, x8, lsl #3
   1541c:      	ldr	w8, [x8, #0x4]
   15420:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15424:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15428:      	mov	w11, #0x4955            // =18773
   1542c:      	movk	w11, #0x45, lsl #16
   15430:      	cmp	w10, w11
   15434:      	b.le	0x154f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc4e4>
   15438:      	mov	w11, #0x5452            // =21586
   1543c:      	movk	w11, #0x46, lsl #16
   15440:      	cmp	w10, w11
   15444:      	b.le	0x155a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc594>
   15448:      	mov	w11, #0x4b41            // =19265
   1544c:      	movk	w11, #0x4c, lsl #16
   15450:      	cmp	w10, w11
   15454:      	b.gt	0x15698 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc684>
   15458:      	mov	w11, #0x5453            // =21587
   1545c:      	movk	w11, #0x46, lsl #16
   15460:      	cmp	w10, w11
   15464:      	b.eq	0x157d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc7c4>
   15468:      	mov	w11, #0x5544            // =21828
   1546c:      	movk	w11, #0x4b, lsl #16
   15470:      	cmp	w10, w11
   15474:      	b.ne	0x159bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a8>
   15478:      	mov	w8, #0x7                // =7
   1547c:      	nop
   15480:      	adr	x10, 0x5320
   15484:      	cmp	x9, #0x4
   15488:      	add	x8, x10, x8, lsl #3
   1548c:      	ldr	w8, [x8, #0x4]
   15490:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15494:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15498:      	mov	w11, #0x4c42            // =19522
   1549c:      	movk	w11, #0x54, lsl #16
   154a0:      	cmp	w10, w11
   154a4:      	b.le	0x15648 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc634>
   154a8:      	mov	w11, #0x584d            // =22605
   154ac:      	movk	w11, #0x54, lsl #16
   154b0:      	cmp	w10, w11
   154b4:      	b.gt	0x15718 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc704>
   154b8:      	mov	w11, #0x4c43            // =19523
   154bc:      	movk	w11, #0x54, lsl #16
   154c0:      	cmp	w10, w11
   154c4:      	b.eq	0x15838 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc824>
   154c8:      	mov	w11, #0x4e4b            // =20043
   154cc:      	movk	w11, #0x54, lsl #16
   154d0:      	cmp	w10, w11
   154d4:      	b.ne	0x159bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a8>
   154d8:      	mov	w8, #0xc                // =12
   154dc:      	nop
   154e0:      	adr	x10, 0x5320
   154e4:      	cmp	x9, #0x4
   154e8:      	add	x8, x10, x8, lsl #3
   154ec:      	ldr	w8, [x8, #0x4]
   154f0:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   154f4:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   154f8:      	mov	w11, #0x594b            // =22859
   154fc:      	movk	w11, #0x41, lsl #16
   15500:      	cmp	w10, w11
   15504:      	b.gt	0x15558 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc544>
   15508:      	mov	w11, #0x484d            // =18509
   1550c:      	movk	w11, #0x41, lsl #16
   15510:      	cmp	w10, w11
   15514:      	b.eq	0x15798 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc784>
   15518:      	mov	w11, #0x4c42            // =19522
   1551c:      	movk	w11, #0x41, lsl #16
   15520:      	cmp	w10, w11
   15524:      	b.eq	0x15758 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc744>
   15528:      	mov	w11, #0x5645            // =22085
   1552c:      	movk	w11, #0x41, lsl #16
   15530:      	cmp	w10, w11
   15534:      	b.ne	0x159bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a8>
   15538:      	mov	w8, #0x9                // =9
   1553c:      	nop
   15540:      	adr	x10, 0x5320
   15544:      	cmp	x9, #0x4
   15548:      	add	x8, x10, x8, lsl #3
   1554c:      	ldr	w8, [x8, #0x4]
   15550:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15554:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15558:      	mov	w11, #0x594c            // =22860
   1555c:      	movk	w11, #0x41, lsl #16
   15560:      	cmp	w10, w11
   15564:      	b.eq	0x157b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc7a4>
   15568:      	mov	w11, #0x4142            // =16706
   1556c:      	movk	w11, #0x43, lsl #16
   15570:      	cmp	w10, w11
   15574:      	b.eq	0x15778 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc764>
   15578:      	mov	w11, #0x5246            // =21062
   1557c:      	movk	w11, #0x44, lsl #16
   15580:      	cmp	w10, w11
   15584:      	b.ne	0x159bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a8>
   15588:      	mov	w8, #0xa                // =10
   1558c:      	nop
   15590:      	adr	x10, 0x5320
   15594:      	cmp	x9, #0x4
   15598:      	add	x8, x10, x8, lsl #3
   1559c:      	ldr	w8, [x8, #0x4]
   155a0:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   155a4:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   155a8:      	mov	w11, #0x4956            // =18774
   155ac:      	movk	w11, #0x45, lsl #16
   155b0:      	cmp	w10, w11
   155b4:      	b.eq	0x158f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc8e4>
   155b8:      	mov	w11, #0x4e49            // =20041
   155bc:      	movk	w11, #0x45, lsl #16
   155c0:      	cmp	w10, w11
   155c4:      	b.eq	0x15898 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc884>
   155c8:      	mov	w11, #0x5553            // =21843
   155cc:      	movk	w11, #0x45, lsl #16
   155d0:      	cmp	w10, w11
   155d4:      	b.ne	0x159bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a8>
   155d8:      	mov	w8, #0x17               // =23
   155dc:      	nop
   155e0:      	adr	x10, 0x5320
   155e4:      	cmp	x9, #0x4
   155e8:      	add	x8, x10, x8, lsl #3
   155ec:      	ldr	w8, [x8, #0x4]
   155f0:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   155f4:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   155f8:      	mov	w11, #0x4f43            // =20291
   155fc:      	movk	w11, #0x4c, lsl #16
   15600:      	cmp	w10, w11
   15604:      	b.eq	0x15918 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc904>
   15608:      	mov	w11, #0x5652            // =22098
   1560c:      	movk	w11, #0x4c, lsl #16
   15610:      	cmp	w10, w11
   15614:      	b.eq	0x158b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc8a4>
   15618:      	mov	w11, #0x4150            // =16720
   1561c:      	movk	w11, #0x4e, lsl #16
   15620:      	cmp	w10, w11
   15624:      	b.ne	0x159bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a8>
   15628:      	mov	w8, #0x13               // =19
   1562c:      	nop
   15630:      	adr	x10, 0x5320
   15634:      	cmp	x9, #0x4
   15638:      	add	x8, x10, x8, lsl #3
   1563c:      	ldr	w8, [x8, #0x4]
   15640:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15644:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15648:      	mov	w11, #0x4150            // =16720
   1564c:      	movk	w11, #0x52, lsl #16
   15650:      	cmp	w10, w11
   15654:      	b.eq	0x15938 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc924>
   15658:      	mov	w11, #0x4f43            // =20291
   1565c:      	movk	w11, #0x52, lsl #16
   15660:      	cmp	w10, w11
   15664:      	b.eq	0x158d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc8c4>
   15668:      	mov	w11, #0x5456            // =21590
   1566c:      	movk	w11, #0x52, lsl #16
   15670:      	cmp	w10, w11
   15674:      	b.ne	0x159bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a8>
   15678:      	mov	w8, #0x1a               // =26
   1567c:      	nop
   15680:      	adr	x10, 0x5320
   15684:      	cmp	x9, #0x4
   15688:      	add	x8, x10, x8, lsl #3
   1568c:      	ldr	w8, [x8, #0x4]
   15690:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15694:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15698:      	mov	w11, #0x4b42            // =19266
   1569c:      	movk	w11, #0x4c, lsl #16
   156a0:      	cmp	w10, w11
   156a4:      	b.eq	0x157f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc7e4>
   156a8:      	mov	w11, #0x4d45            // =19781
   156ac:      	movk	w11, #0x4c, lsl #16
   156b0:      	cmp	w10, w11
   156b4:      	b.ne	0x159bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a8>
   156b8:      	mov	w8, #0x8                // =8
   156bc:      	nop
   156c0:      	adr	x10, 0x5320
   156c4:      	cmp	x9, #0x4
   156c8:      	add	x8, x10, x8, lsl #3
   156cc:      	ldr	w8, [x8, #0x4]
   156d0:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   156d4:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   156d8:      	mov	w11, #0x454e            // =17742
   156dc:      	movk	w11, #0x4f, lsl #16
   156e0:      	cmp	w10, w11
   156e4:      	b.eq	0x15858 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc844>
   156e8:      	mov	w11, #0x4c41            // =19521
   156ec:      	movk	w11, #0x50, lsl #16
   156f0:      	cmp	w10, w11
   156f4:      	b.ne	0x159bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a8>
   156f8:      	mov	x8, xzr
   156fc:      	nop
   15700:      	adr	x10, 0x5320
   15704:      	cmp	x9, #0x4
   15708:      	add	x8, x10, x8, lsl #3
   1570c:      	ldr	w8, [x8, #0x4]
   15710:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15714:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15718:      	mov	w11, #0x584e            // =22606
   1571c:      	movk	w11, #0x54, lsl #16
   15720:      	cmp	w10, w11
   15724:      	b.eq	0x15878 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc864>
   15728:      	mov	w11, #0x4b56            // =19286
   1572c:      	movk	w11, #0x59, lsl #16
   15730:      	cmp	w10, w11
   15734:      	b.ne	0x159bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a8>
   15738:      	mov	w8, #0x19               // =25
   1573c:      	nop
   15740:      	adr	x10, 0x5320
   15744:      	cmp	x9, #0x4
   15748:      	add	x8, x10, x8, lsl #3
   1574c:      	ldr	w8, [x8, #0x4]
   15750:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15754:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15758:      	mov	w8, #0x2                // =2
   1575c:      	nop
   15760:      	adr	x10, 0x5320
   15764:      	cmp	x9, #0x4
   15768:      	add	x8, x10, x8, lsl #3
   1576c:      	ldr	w8, [x8, #0x4]
   15770:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15774:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15778:      	mov	w8, #0x1                // =1
   1577c:      	nop
   15780:      	adr	x10, 0x5320
   15784:      	cmp	x9, #0x4
   15788:      	add	x8, x10, x8, lsl #3
   1578c:      	ldr	w8, [x8, #0x4]
   15790:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15794:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15798:      	mov	w8, #0x10               // =16
   1579c:      	nop
   157a0:      	adr	x10, 0x5320
   157a4:      	cmp	x9, #0x4
   157a8:      	add	x8, x10, x8, lsl #3
   157ac:      	ldr	w8, [x8, #0x4]
   157b0:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   157b4:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   157b8:      	mov	w8, #0xe                // =14
   157bc:      	nop
   157c0:      	adr	x10, 0x5320
   157c4:      	cmp	x9, #0x4
   157c8:      	add	x8, x10, x8, lsl #3
   157cc:      	ldr	w8, [x8, #0x4]
   157d0:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   157d4:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   157d8:      	mov	w8, #0x16               // =22
   157dc:      	nop
   157e0:      	adr	x10, 0x5320
   157e4:      	cmp	x9, #0x4
   157e8:      	add	x8, x10, x8, lsl #3
   157ec:      	ldr	w8, [x8, #0x4]
   157f0:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   157f4:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   157f8:      	mov	w8, #0x3                // =3
   157fc:      	nop
   15800:      	adr	x10, 0x5320
   15804:      	cmp	x9, #0x4
   15808:      	add	x8, x10, x8, lsl #3
   1580c:      	ldr	w8, [x8, #0x4]
   15810:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15814:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15818:      	mov	w8, #0xf                // =15
   1581c:      	nop
   15820:      	adr	x10, 0x5320
   15824:      	cmp	x9, #0x4
   15828:      	add	x8, x10, x8, lsl #3
   1582c:      	ldr	w8, [x8, #0x4]
   15830:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15834:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15838:      	mov	w8, #0x4                // =4
   1583c:      	nop
   15840:      	adr	x10, 0x5320
   15844:      	cmp	x9, #0x4
   15848:      	add	x8, x10, x8, lsl #3
   1584c:      	ldr	w8, [x8, #0x4]
   15850:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15854:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15858:      	mov	w8, #0x11               // =17
   1585c:      	nop
   15860:      	adr	x10, 0x5320
   15864:      	cmp	x9, #0x4
   15868:      	add	x8, x10, x8, lsl #3
   1586c:      	ldr	w8, [x8, #0x4]
   15870:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15874:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15878:      	mov	w8, #0x12               // =18
   1587c:      	nop
   15880:      	adr	x10, 0x5320
   15884:      	cmp	x9, #0x4
   15888:      	add	x8, x10, x8, lsl #3
   1588c:      	ldr	w8, [x8, #0x4]
   15890:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15894:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15898:      	mov	w8, #0xb                // =11
   1589c:      	nop
   158a0:      	adr	x10, 0x5320
   158a4:      	cmp	x9, #0x4
   158a8:      	add	x8, x10, x8, lsl #3
   158ac:      	ldr	w8, [x8, #0x4]
   158b0:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   158b4:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   158b8:      	mov	w8, #0x15               // =21
   158bc:      	nop
   158c0:      	adr	x10, 0x5320
   158c4:      	cmp	x9, #0x4
   158c8:      	add	x8, x10, x8, lsl #3
   158cc:      	ldr	w8, [x8, #0x4]
   158d0:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   158d4:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   158d8:      	mov	w8, #0x6                // =6
   158dc:      	nop
   158e0:      	adr	x10, 0x5320
   158e4:      	cmp	x9, #0x4
   158e8:      	add	x8, x10, x8, lsl #3
   158ec:      	ldr	w8, [x8, #0x4]
   158f0:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   158f4:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   158f8:      	mov	w8, #0x18               // =24
   158fc:      	nop
   15900:      	adr	x10, 0x5320
   15904:      	cmp	x9, #0x4
   15908:      	add	x8, x10, x8, lsl #3
   1590c:      	ldr	w8, [x8, #0x4]
   15910:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15914:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15918:      	mov	w8, #0x5                // =5
   1591c:      	nop
   15920:      	adr	x10, 0x5320
   15924:      	cmp	x9, #0x4
   15928:      	add	x8, x10, x8, lsl #3
   1592c:      	ldr	w8, [x8, #0x4]
   15930:      	b.hs	0x15954 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc940>
   15934:      	b	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15938:      	mov	w8, #0x14               // =20
   1593c:      	nop
   15940:      	adr	x10, 0x5320
   15944:      	cmp	x9, #0x4
   15948:      	add	x8, x10, x8, lsl #3
   1594c:      	ldr	w8, [x8, #0x4]
   15950:      	b.lo	0x1599c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc988>
   15954:      	ldrb	w9, [x0, #0x3]
   15958:      	cmp	w9, #0x2d
   1595c:      	b.ne	0x159b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a4>
   15960:      	ldrb	w9, [x0, #0x4]
   15964:      	sub	w9, w9, #0x41
   15968:      	cmp	w9, #0x19
   1596c:      	b.hi	0x159b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a4>
   15970:      	ldurb	w9, [x1, #-0x3]
   15974:      	cmp	w9, #0x4c
   15978:      	b.ne	0x159b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a4>
   1597c:      	ldurb	w9, [x1, #-0x2]
   15980:      	sub	w9, w9, #0x30
   15984:      	cmp	w9, #0x9
   15988:      	b.hi	0x159b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a4>
   1598c:      	ldurb	w9, [x1, #-0x1]
   15990:      	sub	w9, w9, #0x30
   15994:      	cmp	w9, #0x9
   15998:      	b.hi	0x159b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9a4>
   1599c:      	adrp	x9, 0x4000
   159a0:      	mov	w0, #0x1                // =1
   159a4:      	str	w8, [x2, #0x8]
   159a8:      	ldr	d0, [x9, #0xf30]
   159ac:      	stur	xzr, [x2, #0xc]
   159b0:      	str	d0, [x2]
   159b4:      	ret
   159b8:      	mov	w8, wzr
   159bc:      	mov	w0, w8
   159c0:      	ret
   159c4:      	sub	sp, sp, #0xe0
   159c8:      	stp	x29, x30, [sp, #0x90]
   159cc:      	str	x25, [sp, #0xa0]
   159d0:      	stp	x24, x23, [sp, #0xb0]
   159d4:      	stp	x22, x21, [sp, #0xc0]
   159d8:      	stp	x20, x19, [sp, #0xd0]
   159dc:      	add	x29, sp, #0x90
   159e0:      	mrs	x21, TPIDR_EL0
   159e4:      	sub	x23, x1, x0
   159e8:      	ldr	x8, [x21, #0x28]
   159ec:      	cmp	x23, #0x4
   159f0:      	stur	x8, [x29, #-0x8]
   159f4:      	b.hs	0x15a28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xca14>
   159f8:      	mov	w0, wzr
   159fc:      	ldr	x8, [x21, #0x28]
   15a00:      	ldur	x9, [x29, #-0x8]
   15a04:      	cmp	x8, x9
   15a08:      	b.ne	0x15b38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcb24>
   15a0c:      	ldp	x20, x19, [sp, #0xd0]
   15a10:      	ldr	x25, [sp, #0xa0]
   15a14:      	ldp	x22, x21, [sp, #0xc0]
   15a18:      	ldp	x24, x23, [sp, #0xb0]
   15a1c:      	ldp	x29, x30, [sp, #0x90]
   15a20:      	add	sp, sp, #0xe0
   15a24:      	ret
   15a28:      	mov	x19, x0
   15a2c:      	mov	x22, x2
   15a30:      	mov	x24, xzr
   15a34:      	nop
   15a38:      	adr	x25, 0x21df0
   15a3c:      	b	0x15a4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xca38>
   15a40:      	add	x24, x24, #0x8
   15a44:      	cmp	x24, #0x70
   15a48:      	b.eq	0x159f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9e4>
   15a4c:      	ldr	x20, [x25, x24]
   15a50:      	mov	x0, x20
   15a54:      	bl	0x1d510 <strlen@plt>
   15a58:      	cmp	x23, x0
   15a5c:      	b.lo	0x15a40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xca2c>
   15a60:      	ldrb	w8, [x19]
   15a64:      	ldrb	w9, [x20]
   15a68:      	sub	w10, w8, #0x41
   15a6c:      	orr	w11, w8, #0x20
   15a70:      	cmp	w10, #0x1a
   15a74:      	sub	w10, w9, #0x41
   15a78:      	csel	w8, w11, w8, lo
   15a7c:      	orr	w11, w9, #0x20
   15a80:      	cmp	w10, #0x1a
   15a84:      	csel	w9, w11, w9, lo
   15a88:      	cmp	w8, w9
   15a8c:      	b.ne	0x15a40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xca2c>
   15a90:      	sub	x2, x0, #0x1
   15a94:      	add	x0, x19, #0x1
   15a98:      	add	x1, x20, #0x1
   15a9c:      	bl	0x1d8d0 <memcmp@plt>
   15aa0:      	cbnz	w0, 0x15a40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xca2c>
   15aa4:      	movi	v0.2d, #0000000000000000
   15aa8:      	adrp	x8, 0x4000
   15aac:      	mov	x19, x22
   15ab0:      	ldr	d1, [x8, #0xf78]
   15ab4:      	adrp	x0, 0x2000
   15ab8:      	add	x0, x0, #0xccc
   15abc:      	mov	x1, sp
   15ac0:      	str	wzr, [x22, #0x8]
   15ac4:      	str	d1, [x22]
   15ac8:      	str	xzr, [x19, #0xc]!
   15acc:      	stp	q0, q0, [sp]
   15ad0:      	stp	q0, q0, [sp, #0x20]
   15ad4:      	stp	q0, q0, [sp, #0x40]
   15ad8:      	stp	q0, q0, [sp, #0x60]
   15adc:      	bl	0x1d7f0 <__system_property_get@plt>
   15ae0:      	cmp	w0, #0x1
   15ae4:      	b.lt	0x15b24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcb10>
   15ae8:      	ldrb	w8, [sp]
   15aec:      	cbz	w8, 0x15b24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcb10>
   15af0:      	mov	x0, sp
   15af4:      	sub	w8, w8, #0x3a
   15af8:      	cmn	w8, #0xb
   15afc:      	b.hi	0x15b0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcaf8>
   15b00:      	ldrb	w8, [x0, #0x1]!
   15b04:      	cbnz	w8, 0x15af4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcae0>
   15b08:      	b	0x15b24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcb10>
   15b0c:      	bl	0x1d7a0 <atoi@plt>
   15b10:      	cbz	w0, 0x15b24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcb10>
   15b14:      	mov	w3, w0
   15b18:      	mov	x0, x19
   15b1c:      	mov	x1, #-0x1               // =-1
   15b20:      	bl	0x176b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe6a4>
   15b24:      	mov	w0, #0x1                // =1
   15b28:      	ldr	x8, [x21, #0x28]
   15b2c:      	ldur	x9, [x29, #-0x8]
   15b30:      	cmp	x8, x9
   15b34:      	b.eq	0x15a0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9f8>
   15b38:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   15b3c:      	sub	sp, sp, #0xf0
   15b40:      	stp	x29, x30, [sp, #0xb0]
   15b44:      	stp	x24, x23, [sp, #0xc0]
   15b48:      	stp	x22, x21, [sp, #0xd0]
   15b4c:      	stp	x20, x19, [sp, #0xe0]
   15b50:      	add	x29, sp, #0xb0
   15b54:      	mrs	x24, TPIDR_EL0
   15b58:      	mov	x19, x8
   15b5c:      	mov	w1, #0x5c               // =92
   15b60:      	ldr	x8, [x24, #0x28]
   15b64:      	mov	x20, x0
   15b68:      	stur	x8, [x29, #-0x8]
   15b6c:      	bl	0x1d810 <strnlen@plt>
   15b70:      	mov	x21, x0
   15b74:      	add	x1, x20, x0
   15b78:      	add	x2, sp, #0x8
   15b7c:      	mov	x0, x20
   15b80:      	bl	0x1361c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa608>
   15b84:      	tbnz	w0, #0x0, 0x15c48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcc34>
   15b88:      	cmp	x21, #0x4
   15b8c:      	b.ge	0x15c80 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcc6c>
   15b90:      	add	x1, x20, x21
   15b94:      	add	x2, sp, #0x8
   15b98:      	mov	x0, x20
   15b9c:      	bl	0x138a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa88c>
   15ba0:      	tbnz	w0, #0x0, 0x15c48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcc34>
   15ba4:      	add	x1, x20, x21
   15ba8:      	add	x2, sp, #0x8
   15bac:      	mov	x0, x20
   15bb0:      	bl	0x14ba0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbb8c>
   15bb4:      	tbnz	w0, #0x0, 0x15c48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcc34>
   15bb8:      	add	x1, x20, x21
   15bbc:      	add	x2, sp, #0x8
   15bc0:      	mov	x0, x20
   15bc4:      	bl	0x143c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb3ac>
   15bc8:      	tbnz	w0, #0x0, 0x15c48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcc34>
   15bcc:      	add	x1, x20, x21
   15bd0:      	add	x3, sp, #0x8
   15bd4:      	mov	x0, x20
   15bd8:      	mov	w2, #0x1                // =1
   15bdc:      	bl	0x13a28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaa14>
   15be0:      	tbnz	w0, #0x0, 0x15c48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcc34>
   15be4:      	add	x1, x20, x21
   15be8:      	add	x2, sp, #0x8
   15bec:      	mov	x0, x20
   15bf0:      	bl	0x13ce0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaccc>
   15bf4:      	tbnz	w0, #0x0, 0x15c48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcc34>
   15bf8:      	add	x1, x20, x21
   15bfc:      	add	x2, sp, #0x8
   15c00:      	mov	x0, x20
   15c04:      	bl	0x14484 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb470>
   15c08:      	tbnz	w0, #0x0, 0x15c48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcc34>
   15c0c:      	add	x1, x20, x21
   15c10:      	add	x2, sp, #0x8
   15c14:      	mov	x0, x20
   15c18:      	bl	0x13d98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xad84>
   15c1c:      	tbnz	w0, #0x0, 0x15c48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcc34>
   15c20:      	add	x1, x20, x21
   15c24:      	add	x2, sp, #0x8
   15c28:      	mov	x0, x20
   15c2c:      	bl	0x159c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc9b0>
   15c30:      	tbnz	w0, #0x0, 0x15c48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcc34>
   15c34:      	add	x1, x20, x21
   15c38:      	add	x2, sp, #0x8
   15c3c:      	mov	x0, x20
   15c40:      	bl	0x1536c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xc358>
   15c44:      	tbz	w0, #0x0, 0x15f0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcef8>
   15c48:      	ldur	q0, [sp, #0x8]
   15c4c:      	ldr	w8, [sp, #0x18]
   15c50:      	str	q0, [x19]
   15c54:      	str	w8, [x19, #0x10]
   15c58:      	ldr	x8, [x24, #0x28]
   15c5c:      	ldur	x9, [x29, #-0x8]
   15c60:      	cmp	x8, x9
   15c64:      	b.ne	0x161f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1e4>
   15c68:      	ldp	x20, x19, [sp, #0xe0]
   15c6c:      	ldp	x22, x21, [sp, #0xd0]
   15c70:      	ldp	x24, x23, [sp, #0xc0]
   15c74:      	ldp	x29, x30, [sp, #0xb0]
   15c78:      	add	sp, sp, #0xf0
   15c7c:      	ret
   15c80:      	ldr	w8, [x20]
   15c84:      	and	w9, w8, #0xdfdfdfdf
   15c88:      	mov	w8, #0x4154             // =16724
   15c8c:      	movk	w8, #0x4f52, lsl #16
   15c90:      	cmp	w9, w8
   15c94:      	add	x8, sp, #0x20
   15c98:      	b.ne	0x15cf4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcce0>
   15c9c:      	movi	v0.2d, #0000000000000000
   15ca0:      	adrp	x0, 0x2000
   15ca4:      	add	x0, x0, #0xccc
   15ca8:      	add	x1, sp, #0x20
   15cac:      	str	q0, [x8, #0x70]
   15cb0:      	stp	q0, q0, [sp, #0x30]
   15cb4:      	stp	q0, q0, [sp, #0x50]
   15cb8:      	stp	q0, q0, [sp, #0x70]
   15cbc:      	str	q0, [sp, #0x20]
   15cc0:      	bl	0x1d7f0 <__system_property_get@plt>
   15cc4:      	cmp	w0, #0x1
   15cc8:      	mov	w0, wzr
   15ccc:      	b.lt	0x15e18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xce04>
   15cd0:      	ldrb	w8, [sp, #0x20]
   15cd4:      	cbz	w8, 0x15e18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xce04>
   15cd8:      	add	x0, sp, #0x20
   15cdc:      	sub	w8, w8, #0x3a
   15ce0:      	cmn	w8, #0xb
   15ce4:      	b.hi	0x15e14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xce00>
   15ce8:      	ldrb	w8, [x0, #0x1]!
   15cec:      	cbnz	w8, 0x15cdc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xccc8>
   15cf0:      	b	0x15d58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcd44>
   15cf4:      	mov	w10, #0x4f48            // =20296
   15cf8:      	movk	w10, #0x494c, lsl #16
   15cfc:      	cmp	w9, w10
   15d00:      	b.ne	0x15d60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcd4c>
   15d04:      	movi	v0.2d, #0000000000000000
   15d08:      	adrp	x0, 0x2000
   15d0c:      	add	x0, x0, #0xccc
   15d10:      	add	x1, sp, #0x20
   15d14:      	str	q0, [x8, #0x70]
   15d18:      	stp	q0, q0, [sp, #0x30]
   15d1c:      	stp	q0, q0, [sp, #0x50]
   15d20:      	stp	q0, q0, [sp, #0x70]
   15d24:      	str	q0, [sp, #0x20]
   15d28:      	bl	0x1d7f0 <__system_property_get@plt>
   15d2c:      	cmp	w0, #0x1
   15d30:      	mov	w0, wzr
   15d34:      	b.lt	0x15e18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xce04>
   15d38:      	ldrb	w8, [sp, #0x20]
   15d3c:      	cbz	w8, 0x15e18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xce04>
   15d40:      	add	x0, sp, #0x20
   15d44:      	sub	w8, w8, #0x3a
   15d48:      	cmn	w8, #0xb
   15d4c:      	b.hi	0x15e14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xce00>
   15d50:      	ldrb	w8, [x0, #0x1]!
   15d54:      	cbnz	w8, 0x15d44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcd30>
   15d58:      	mov	w0, wzr
   15d5c:      	b	0x15e18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xce04>
   15d60:      	cmp	x21, #0x6
   15d64:      	b.lo	0x15b90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcb7c>
   15d68:      	ldr	w10, [x20]
   15d6c:      	mov	w9, #-0x20202021        // =-538976289
   15d70:      	mov	w11, #0x414b            // =16715
   15d74:      	movk	w11, #0x414c, lsl #16
   15d78:      	and	w10, w10, w9
   15d7c:      	cmp	w10, w11
   15d80:      	b.ne	0x15e40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xce2c>
   15d84:      	ldrb	w10, [x20, #0x4]
   15d88:      	sub	w11, w10, #0x41
   15d8c:      	orr	w12, w10, #0x20
   15d90:      	cmp	w11, #0x1a
   15d94:      	csel	w10, w12, w10, lo
   15d98:      	cmp	w10, #0x6d
   15d9c:      	b.ne	0x15e40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xce2c>
   15da0:      	ldrb	w10, [x20, #0x5]
   15da4:      	sub	w11, w10, #0x41
   15da8:      	orr	w12, w10, #0x20
   15dac:      	cmp	w11, #0x1a
   15db0:      	csel	w10, w12, w10, lo
   15db4:      	cmp	w10, #0x61
   15db8:      	b.ne	0x15e40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xce2c>
   15dbc:      	movi	v0.2d, #0000000000000000
   15dc0:      	adrp	x0, 0x2000
   15dc4:      	add	x0, x0, #0xccc
   15dc8:      	add	x1, sp, #0x20
   15dcc:      	str	q0, [x8, #0x70]
   15dd0:      	stp	q0, q0, [sp, #0x30]
   15dd4:      	stp	q0, q0, [sp, #0x50]
   15dd8:      	stp	q0, q0, [sp, #0x70]
   15ddc:      	str	q0, [sp, #0x20]
   15de0:      	bl	0x1d7f0 <__system_property_get@plt>
   15de4:      	cmp	w0, #0x1
   15de8:      	mov	w0, wzr
   15dec:      	b.lt	0x15e18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xce04>
   15df0:      	ldrb	w8, [sp, #0x20]
   15df4:      	cbz	w8, 0x15e18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xce04>
   15df8:      	add	x0, sp, #0x20
   15dfc:      	sub	w8, w8, #0x3a
   15e00:      	cmn	w8, #0xb
   15e04:      	b.hi	0x15e14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xce00>
   15e08:      	ldrb	w8, [x0, #0x1]!
   15e0c:      	cbnz	w8, 0x15dfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcde8>
   15e10:      	b	0x15d58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcd44>
   15e14:      	bl	0x1d7a0 <atoi@plt>
   15e18:      	adrp	x8, 0x4000
   15e1c:      	stur	xzr, [sp, #0x14]
   15e20:      	ldr	d0, [x8, #0xf20]
   15e24:      	str	w0, [sp, #0x10]
   15e28:      	str	d0, [sp, #0x8]
   15e2c:      	ldr	w8, [sp, #0x18]
   15e30:      	ldur	q0, [sp, #0x8]
   15e34:      	str	w8, [x19, #0x10]
   15e38:      	str	q0, [x19]
   15e3c:      	b	0x15c58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcc44>
   15e40:      	cmp	x21, #0x9
   15e44:      	b.lo	0x15b90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcb7c>
   15e48:      	ldr	w8, [x20]
   15e4c:      	and	w8, w8, w9
   15e50:      	mov	w9, #0x4950             // =18768
   15e54:      	movk	w9, #0x454e, lsl #16
   15e58:      	cmp	w8, w9
   15e5c:      	b.ne	0x15b90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcb7c>
   15e60:      	ldrb	w8, [x20, #0x4]
   15e64:      	sub	w9, w8, #0x41
   15e68:      	orr	w10, w8, #0x20
   15e6c:      	cmp	w9, #0x1a
   15e70:      	csel	w8, w10, w8, lo
   15e74:      	cmp	w8, #0x61
   15e78:      	b.ne	0x15b90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcb7c>
   15e7c:      	ldrb	w8, [x20, #0x5]
   15e80:      	sub	w9, w8, #0x41
   15e84:      	orr	w10, w8, #0x20
   15e88:      	cmp	w9, #0x1a
   15e8c:      	csel	w8, w10, w8, lo
   15e90:      	cmp	w8, #0x70
   15e94:      	b.ne	0x15b90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcb7c>
   15e98:      	ldrb	w8, [x20, #0x6]
   15e9c:      	sub	w9, w8, #0x41
   15ea0:      	orr	w10, w8, #0x20
   15ea4:      	cmp	w9, #0x1a
   15ea8:      	csel	w8, w10, w8, lo
   15eac:      	cmp	w8, #0x70
   15eb0:      	b.ne	0x15b90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcb7c>
   15eb4:      	ldrb	w8, [x20, #0x7]
   15eb8:      	sub	w9, w8, #0x41
   15ebc:      	orr	w10, w8, #0x20
   15ec0:      	cmp	w9, #0x1a
   15ec4:      	csel	w8, w10, w8, lo
   15ec8:      	cmp	w8, #0x6c
   15ecc:      	b.ne	0x15b90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcb7c>
   15ed0:      	ldrb	w8, [x20, #0x8]
   15ed4:      	sub	w9, w8, #0x41
   15ed8:      	orr	w10, w8, #0x20
   15edc:      	cmp	w9, #0x1a
   15ee0:      	csel	w8, w10, w8, lo
   15ee4:      	cmp	w8, #0x65
   15ee8:      	b.ne	0x15b90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcb7c>
   15eec:      	bl	0x1775c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe748>
   15ef0:      	adrp	x8, 0x4000
   15ef4:      	cmp	w0, #0x0
   15ef8:      	stur	xzr, [sp, #0x14]
   15efc:      	ldr	d0, [x8, #0xf20]
   15f00:      	cset	w8, ne
   15f04:      	str	w8, [sp, #0x10]
   15f08:      	b	0x15e28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xce14>
   15f0c:      	cmp	x21, #0x6
   15f10:      	b.hi	0x15f58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcf44>
   15f14:      	ldr	w8, [x20]
   15f18:      	mov	w10, #0x7867            // =30823
   15f1c:      	ldrh	w9, [x20, #0x4]
   15f20:      	movk	w10, #0x6162, lsl #16
   15f24:      	cmp	w8, w10
   15f28:      	mov	w8, #0x7962             // =31074
   15f2c:      	ccmp	w9, w8, #0x0, eq
   15f30:      	b.eq	0x16118 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd104>
   15f34:      	ldr	w9, [x20]
   15f38:      	mov	w8, #0x7867             // =30823
   15f3c:      	movk	w8, #0x6c, lsl #16
   15f40:      	cmp	w9, w8
   15f44:      	b.eq	0x16120 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd10c>
   15f48:      	ldr	w9, [x20]
   15f4c:      	add	w8, w8, #0x10, lsl #12  // =0x10000
   15f50:      	cmp	w8, w9
   15f54:      	b.eq	0x16138 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd124>
   15f58:      	bl	0x1775c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe748>
   15f5c:      	adrp	x23, 0x3000
   15f60:      	add	x23, x23, #0x2d8
   15f64:      	mov	w22, w0
   15f68:      	mov	x0, x23
   15f6c:      	mov	x1, x20
   15f70:      	mov	x2, x21
   15f74:      	bl	0x1d8c0 <strncmp@plt>
   15f78:      	cbnz	w0, 0x15f84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcf70>
   15f7c:      	ldrb	w8, [x23, x21]
   15f80:      	cbz	w8, 0x16128 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd114>
   15f84:      	adrp	x23, 0x4000
   15f88:      	add	x23, x23, #0x381
   15f8c:      	mov	x1, x20
   15f90:      	mov	x0, x23
   15f94:      	mov	x2, x21
   15f98:      	bl	0x1d8c0 <strncmp@plt>
   15f9c:      	cbnz	w0, 0x15fa8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcf94>
   15fa0:      	ldrb	w8, [x23, x21]
   15fa4:      	cbz	w8, 0x16130 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd11c>
   15fa8:      	adrp	x23, 0x3000
   15fac:      	add	x23, x23, #0x44
   15fb0:      	mov	x1, x20
   15fb4:      	mov	x0, x23
   15fb8:      	mov	x2, x21
   15fbc:      	bl	0x1d8c0 <strncmp@plt>
   15fc0:      	cbnz	w0, 0x15fcc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcfb8>
   15fc4:      	ldrb	w8, [x23, x21]
   15fc8:      	cbz	w8, 0x1616c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd158>
   15fcc:      	adrp	x23, 0x4000
   15fd0:      	add	x23, x23, #0x660
   15fd4:      	mov	x1, x20
   15fd8:      	mov	x0, x23
   15fdc:      	mov	x2, x21
   15fe0:      	bl	0x1d8c0 <strncmp@plt>
   15fe4:      	cbnz	w0, 0x15ff0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcfdc>
   15fe8:      	ldrb	w8, [x23, x21]
   15fec:      	cbz	w8, 0x16174 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd160>
   15ff0:      	adrp	x23, 0x2000
   15ff4:      	add	x23, x23, #0xcc0
   15ff8:      	mov	x1, x20
   15ffc:      	mov	x0, x23
   16000:      	mov	x2, x21
   16004:      	bl	0x1d8c0 <strncmp@plt>
   16008:      	cbnz	w0, 0x16014 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd000>
   1600c:      	ldrb	w8, [x23, x21]
   16010:      	cbz	w8, 0x1617c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd168>
   16014:      	adrp	x23, 0x4000
   16018:      	add	x23, x23, #0xd48
   1601c:      	mov	x1, x20
   16020:      	mov	x0, x23
   16024:      	mov	x2, x21
   16028:      	bl	0x1d8c0 <strncmp@plt>
   1602c:      	cbnz	w0, 0x16038 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd024>
   16030:      	ldrb	w8, [x23, x21]
   16034:      	cbz	w8, 0x16184 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd170>
   16038:      	adrp	x23, 0x3000
   1603c:      	add	x23, x23, #0xed9
   16040:      	mov	x1, x20
   16044:      	mov	x0, x23
   16048:      	mov	x2, x21
   1604c:      	bl	0x1d8c0 <strncmp@plt>
   16050:      	cbnz	w0, 0x1605c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd048>
   16054:      	ldrb	w8, [x23, x21]
   16058:      	cbz	w8, 0x1618c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd178>
   1605c:      	adrp	x23, 0x3000
   16060:      	add	x23, x23, #0x178
   16064:      	mov	x1, x20
   16068:      	mov	x0, x23
   1606c:      	mov	x2, x21
   16070:      	bl	0x1d8c0 <strncmp@plt>
   16074:      	cbnz	w0, 0x16080 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd06c>
   16078:      	ldrb	w8, [x23, x21]
   1607c:      	cbz	w8, 0x16194 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd180>
   16080:      	adrp	x23, 0x4000
   16084:      	add	x23, x23, #0x532
   16088:      	mov	x1, x20
   1608c:      	mov	x0, x23
   16090:      	mov	x2, x21
   16094:      	bl	0x1d8c0 <strncmp@plt>
   16098:      	cbnz	w0, 0x160a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd090>
   1609c:      	ldrb	w8, [x23, x21]
   160a0:      	cbz	w8, 0x1619c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd188>
   160a4:      	adrp	x23, 0x2000
   160a8:      	add	x23, x23, #0xeb8
   160ac:      	mov	x1, x20
   160b0:      	mov	x0, x23
   160b4:      	mov	x2, x21
   160b8:      	bl	0x1d8c0 <strncmp@plt>
   160bc:      	cbnz	w0, 0x160c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd0b4>
   160c0:      	ldrb	w8, [x23, x21]
   160c4:      	cbz	w8, 0x161a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd190>
   160c8:      	adrp	x23, 0x2000
   160cc:      	add	x23, x23, #0xaf3
   160d0:      	mov	x1, x20
   160d4:      	mov	x0, x23
   160d8:      	mov	x2, x21
   160dc:      	bl	0x1d8c0 <strncmp@plt>
   160e0:      	cbnz	w0, 0x160ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd0d8>
   160e4:      	ldrb	w8, [x23, x21]
   160e8:      	cbz	w8, 0x161ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd198>
   160ec:      	adrp	x23, 0x4000
   160f0:      	add	x23, x23, #0x9d9
   160f4:      	mov	x1, x20
   160f8:      	mov	x0, x23
   160fc:      	mov	x2, x21
   16100:      	bl	0x1d8c0 <strncmp@plt>
   16104:      	cbnz	w0, 0x16110 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd0fc>
   16108:      	ldrb	w8, [x23, x21]
   1610c:      	cbz	w8, 0x161b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1a0>
   16110:      	stp	xzr, xzr, [x19]
   16114:      	b	0x161f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1dc>
   16118:      	mov	x8, xzr
   1611c:      	b	0x1613c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd128>
   16120:      	mov	w8, #0x1                // =1
   16124:      	b	0x1613c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd128>
   16128:      	mov	x8, xzr
   1612c:      	b	0x161b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1a4>
   16130:      	mov	w8, #0x1                // =1
   16134:      	b	0x161b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1a4>
   16138:      	mov	w8, #0x2                // =2
   1613c:      	mov	w9, #0xc                // =12
   16140:      	nop
   16144:      	adr	x10, 0x52fc
   16148:      	umaddl	x8, w8, w9, x10
   1614c:      	adrp	x9, 0x4000
   16150:      	stur	wzr, [x19, #0xd]
   16154:      	ldr	d0, [x9, #0xf18]
   16158:      	ldrh	w9, [x8, #0x6]
   1615c:      	ldrb	w8, [x8, #0x9]
   16160:      	str	d0, [x19]
   16164:      	str	w9, [x19, #0x8]
   16168:      	b	0x161ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1d8>
   1616c:      	mov	w8, #0x2                // =2
   16170:      	b	0x161b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1a4>
   16174:      	mov	w8, #0x3                // =3
   16178:      	b	0x161b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1a4>
   1617c:      	mov	w8, #0x4                // =4
   16180:      	b	0x161b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1a4>
   16184:      	mov	w8, #0x5                // =5
   16188:      	b	0x161b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1a4>
   1618c:      	mov	w8, #0x6                // =6
   16190:      	b	0x161b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1a4>
   16194:      	mov	w8, #0x7                // =7
   16198:      	b	0x161b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1a4>
   1619c:      	mov	w8, #0x8                // =8
   161a0:      	b	0x161b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1a4>
   161a4:      	mov	w8, #0x9                // =9
   161a8:      	b	0x161b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1a4>
   161ac:      	mov	w8, #0xa                // =10
   161b0:      	b	0x161b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1a4>
   161b4:      	mov	w8, #0xb                // =11
   161b8:      	nop
   161bc:      	adr	x9, 0x21b08
   161c0:      	nop
   161c4:      	adr	x10, 0x5270
   161c8:      	add	x8, x9, x8, lsl #4
   161cc:      	ldrb	w9, [x8, #0xa]
   161d0:      	ldr	w10, [x10, w9, uxtw #2]
   161d4:      	stp	w10, w9, [x19]
   161d8:      	cbnz	w22, 0x161e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1cc>
   161dc:      	ldrh	w22, [x8, #0x8]
   161e0:      	ldrb	w8, [x8, #0xb]
   161e4:      	str	w22, [x19, #0x8]
   161e8:      	stur	wzr, [x19, #0xd]
   161ec:      	strb	w8, [x19, #0xc]
   161f0:      	str	wzr, [x19, #0x10]
   161f4:      	b	0x15c58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcc44>
   161f8:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   161fc:      	sub	sp, sp, #0xe0
   16200:      	stp	x29, x30, [sp, #0xb0]
   16204:      	stp	x22, x21, [sp, #0xc0]
   16208:      	stp	x20, x19, [sp, #0xd0]
   1620c:      	add	x29, sp, #0xb0
   16210:      	mrs	x22, TPIDR_EL0
   16214:      	mov	x19, x8
   16218:      	mov	w1, #0x5c               // =92
   1621c:      	ldr	x8, [x22, #0x28]
   16220:      	mov	x20, x0
   16224:      	stur	x8, [x29, #-0x8]
   16228:      	bl	0x1d810 <strnlen@plt>
   1622c:      	mov	x21, x0
   16230:      	add	x1, x20, x0
   16234:      	add	x2, sp, #0x8
   16238:      	mov	x0, x20
   1623c:      	bl	0x1361c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa608>
   16240:      	tbnz	w0, #0x0, 0x16488 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd474>
   16244:      	cmp	x21, #0x4
   16248:      	b.lt	0x162bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd2a8>
   1624c:      	ldr	w8, [x20]
   16250:      	mov	w9, #0x4154             // =16724
   16254:      	movk	w9, #0x4f52, lsl #16
   16258:      	and	w8, w8, #0xdfdfdfdf
   1625c:      	cmp	w8, w9
   16260:      	b.ne	0x162bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd2a8>
   16264:      	movi	v0.2d, #0000000000000000
   16268:      	adrp	x0, 0x2000
   1626c:      	add	x0, x0, #0xccc
   16270:      	add	x1, sp, #0x20
   16274:      	stp	q0, q0, [sp, #0x20]
   16278:      	stp	q0, q0, [sp, #0x40]
   1627c:      	stp	q0, q0, [sp, #0x60]
   16280:      	stp	q0, q0, [sp, #0x80]
   16284:      	bl	0x1d7f0 <__system_property_get@plt>
   16288:      	cmp	w0, #0x1
   1628c:      	mov	w0, wzr
   16290:      	b.lt	0x164ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd4d8>
   16294:      	ldrb	w8, [sp, #0x20]
   16298:      	cbz	w8, 0x164ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd4d8>
   1629c:      	add	x0, sp, #0x20
   162a0:      	sub	w8, w8, #0x3a
   162a4:      	cmn	w8, #0xb
   162a8:      	b.hi	0x164e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd4d4>
   162ac:      	ldrb	w8, [x0, #0x1]!
   162b0:      	cbnz	w8, 0x162a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd28c>
   162b4:      	mov	w0, wzr
   162b8:      	b	0x164ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd4d8>
   162bc:      	add	x1, x20, x21
   162c0:      	add	x2, sp, #0x8
   162c4:      	mov	x0, x20
   162c8:      	bl	0x138a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xa88c>
   162cc:      	tbnz	w0, #0x0, 0x16488 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd474>
   162d0:      	cmp	x21, #0x6
   162d4:      	b.ne	0x1633c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd328>
   162d8:      	ldrh	w8, [x20]
   162dc:      	mov	w9, #0x4d53             // =19795
   162e0:      	cmp	w8, w9
   162e4:      	b.ne	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   162e8:      	ldrb	w8, [x20, #0x2]
   162ec:      	sub	w8, w8, #0x30
   162f0:      	cmp	w8, #0x9
   162f4:      	b.hi	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   162f8:      	ldrb	w9, [x20, #0x3]
   162fc:      	sub	w9, w9, #0x30
   16300:      	cmp	w9, #0x9
   16304:      	b.hi	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   16308:      	ldrb	w10, [x20, #0x4]
   1630c:      	sub	w10, w10, #0x30
   16310:      	cmp	w10, #0x9
   16314:      	b.hi	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   16318:      	ldrb	w11, [x20, #0x5]
   1631c:      	sub	w11, w11, #0x30
   16320:      	cmp	w11, #0x9
   16324:      	b.hi	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   16328:      	mov	w12, #0xa               // =10
   1632c:      	madd	w8, w8, w12, w9
   16330:      	adrp	x9, 0x4000
   16334:      	ldr	d0, [x9, #0xf20]
   16338:      	b	0x163b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd3a4>
   1633c:      	ldr	w8, [x20]
   16340:      	cmp	x21, #0xa
   16344:      	b.ne	0x163d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd3bc>
   16348:      	mov	w9, #0x7865             // =30821
   1634c:      	movk	w9, #0x6e79, lsl #16
   16350:      	cmp	w8, w9
   16354:      	b.ne	0x163d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd3bc>
   16358:      	ldrh	w8, [x20, #0x4]
   1635c:      	mov	w9, #0x736f             // =29551
   16360:      	cmp	w8, w9
   16364:      	b.ne	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   16368:      	ldrb	w8, [x20, #0x6]
   1636c:      	sub	w8, w8, #0x30
   16370:      	cmp	w8, #0x9
   16374:      	b.hi	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   16378:      	ldrb	w9, [x20, #0x7]
   1637c:      	sub	w9, w9, #0x30
   16380:      	cmp	w9, #0x9
   16384:      	b.hi	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   16388:      	ldrb	w10, [x20, #0x8]
   1638c:      	sub	w10, w10, #0x30
   16390:      	cmp	w10, #0x9
   16394:      	b.hi	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   16398:      	ldrb	w11, [x20, #0x9]
   1639c:      	sub	w11, w11, #0x30
   163a0:      	cmp	w11, #0x9
   163a4:      	b.hi	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   163a8:      	mov	w12, #0xa               // =10
   163ac:      	madd	w8, w8, w12, w9
   163b0:      	adrp	x9, 0x4000
   163b4:      	ldr	d0, [x9, #0xf58]
   163b8:      	madd	w8, w8, w12, w10
   163bc:      	madd	w8, w8, w12, w11
   163c0:      	str	d0, [sp, #0x8]
   163c4:      	stur	xzr, [sp, #0x14]
   163c8:      	str	w8, [sp, #0x10]
   163cc:      	b	0x16500 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd4ec>
   163d0:      	cmp	x21, #0xd
   163d4:      	b.ne	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   163d8:      	mov	w9, #0xdf               // =223
   163dc:      	and	w8, w8, w9
   163e0:      	cmp	w8, #0x55
   163e4:      	b.ne	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   163e8:      	ldur	w8, [x20, #0x1]
   163ec:      	mov	w9, #0x494e             // =18766
   163f0:      	movk	w9, #0x4556, lsl #16
   163f4:      	and	w8, w8, #0xdfdfdfdf
   163f8:      	cmp	w8, w9
   163fc:      	b.ne	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   16400:      	ldur	w8, [x20, #0x5]
   16404:      	mov	w9, #-0x20202021        // =-538976289
   16408:      	and	w8, w8, w9
   1640c:      	mov	w9, #0x5352             // =21330
   16410:      	movk	w9, #0x4c41, lsl #16
   16414:      	cmp	w8, w9
   16418:      	b.ne	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   1641c:      	ldrb	w8, [x20, #0x9]
   16420:      	sub	w8, w8, #0x30
   16424:      	cmp	w8, #0x9
   16428:      	b.hi	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   1642c:      	ldrb	w9, [x20, #0xa]
   16430:      	sub	w9, w9, #0x30
   16434:      	cmp	w9, #0x9
   16438:      	b.hi	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   1643c:      	ldrb	w10, [x20, #0xb]
   16440:      	sub	w10, w10, #0x30
   16444:      	cmp	w10, #0x9
   16448:      	b.hi	0x1645c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd448>
   1644c:      	ldrb	w11, [x20, #0xc]
   16450:      	sub	w11, w11, #0x30
   16454:      	cmp	w11, #0x9
   16458:      	b.ls	0x163a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd394>
   1645c:      	add	x1, x20, x21
   16460:      	add	x3, sp, #0x8
   16464:      	mov	x0, x20
   16468:      	mov	w2, #0x1                // =1
   1646c:      	bl	0x13a28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaa14>
   16470:      	tbnz	w0, #0x0, 0x16488 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd474>
   16474:      	add	x1, x20, x21
   16478:      	add	x2, sp, #0x8
   1647c:      	mov	x0, x20
   16480:      	bl	0x14484 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb470>
   16484:      	tbz	w0, #0x0, 0x164bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd4a8>
   16488:      	ldur	q0, [sp, #0x8]
   1648c:      	ldr	w8, [sp, #0x18]
   16490:      	str	q0, [x19]
   16494:      	str	w8, [x19, #0x10]
   16498:      	ldr	x8, [x22, #0x28]
   1649c:      	ldur	x9, [x29, #-0x8]
   164a0:      	cmp	x8, x9
   164a4:      	b.ne	0x16520 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd50c>
   164a8:      	ldp	x20, x19, [sp, #0xd0]
   164ac:      	ldp	x22, x21, [sp, #0xc0]
   164b0:      	ldp	x29, x30, [sp, #0xb0]
   164b4:      	add	sp, sp, #0xe0
   164b8:      	ret
   164bc:      	ldr	x8, [x22, #0x28]
   164c0:      	ldur	x9, [x29, #-0x8]
   164c4:      	cmp	x8, x9
   164c8:      	b.ne	0x16520 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd50c>
   164cc:      	stp	xzr, xzr, [x19]
   164d0:      	str	wzr, [x19, #0x10]
   164d4:      	ldp	x20, x19, [sp, #0xd0]
   164d8:      	ldp	x22, x21, [sp, #0xc0]
   164dc:      	ldp	x29, x30, [sp, #0xb0]
   164e0:      	add	sp, sp, #0xe0
   164e4:      	ret
   164e8:      	bl	0x1d7a0 <atoi@plt>
   164ec:      	adrp	x8, 0x4000
   164f0:      	stur	xzr, [sp, #0x14]
   164f4:      	ldr	d0, [x8, #0xf20]
   164f8:      	str	w0, [sp, #0x10]
   164fc:      	str	d0, [sp, #0x8]
   16500:      	ldr	w8, [sp, #0x18]
   16504:      	ldur	q0, [sp, #0x8]
   16508:      	str	w8, [x19, #0x10]
   1650c:      	str	q0, [x19]
   16510:      	ldr	x8, [x22, #0x28]
   16514:      	ldur	x9, [x29, #-0x8]
   16518:      	cmp	x8, x9
   1651c:      	b.eq	0x164a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd494>
   16520:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   16524:      	ldr	w8, [x0, #0x4]
   16528:      	cmp	w8, #0x4
   1652c:      	b.le	0x16570 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd55c>
   16530:      	cmp	w8, #0x5
   16534:      	b.eq	0x16594 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd580>
   16538:      	cmp	w8, #0x6
   1653c:      	b.eq	0x165bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd5a8>
   16540:      	cmp	w8, #0x1a
   16544:      	b.ne	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   16548:      	ldr	w8, [x0, #0x8]
   1654c:      	cmp	w8, #0xcd8
   16550:      	b.ne	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   16554:      	cmp	w1, #0x4
   16558:      	b.eq	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   1655c:      	cmp	w1, #0x6
   16560:      	b.ne	0x16784 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd770>
   16564:      	mov	w8, #0xd47              // =3399
   16568:      	str	w8, [x0, #0x8]
   1656c:      	ret
   16570:      	cmp	w8, #0x2
   16574:      	b.eq	0x165e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd5d4>
   16578:      	cmp	w8, #0x3
   1657c:      	b.ne	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   16580:      	ldr	w8, [x0, #0xc]
   16584:      	sub	w8, w8, #0x515, lsl #12 // =0x515000
   16588:      	cmp	w8, #0x41
   1658c:      	b.eq	0x16600 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd5ec>
   16590:      	ret
   16594:      	ldr	w8, [x0, #0x8]
   16598:      	mov	w9, #0x1a60             // =6752
   1659c:      	cmp	w8, w9
   165a0:      	b.ne	0x166a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd68c>
   165a4:      	cmp	w1, #0x4
   165a8:      	b.eq	0x16698 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd684>
   165ac:      	cmp	w1, #0x8
   165b0:      	b.eq	0x166a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd68c>
   165b4:      	mov	w8, wzr
   165b8:      	b	0x1669c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd688>
   165bc:      	ldr	w8, [x0, #0x8]
   165c0:      	mov	w9, #0x1d9c             // =7580
   165c4:      	cmp	w8, w9
   165c8:      	b.ne	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   165cc:      	cmp	w1, #0x8
   165d0:      	b.eq	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   165d4:      	cmp	w1, #0x4
   165d8:      	b.ne	0x16784 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd770>
   165dc:      	mov	w8, #0x1d9a             // =7578
   165e0:      	str	w8, [x0, #0x8]
   165e4:      	ret
   165e8:      	ldrb	w8, [x0, #0xc]
   165ec:      	cbz	w8, 0x1660c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd5f8>
   165f0:      	ldr	w8, [x0, #0xc]
   165f4:      	sub	w9, w8, #0x4d5, lsl #12 // =0x4d5000
   165f8:      	cmp	w9, #0x34d
   165fc:      	b.ne	0x1665c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd648>
   16600:      	strh	wzr, [x0, #0xc]
   16604:      	strb	wzr, [x0, #0xe]
   16608:      	ret
   1660c:      	ldr	w8, [x0, #0x8]
   16610:      	mov	w9, #0x22e8             // =8936
   16614:      	cmp	w8, w9
   16618:      	b.le	0x166e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd6cc>
   1661c:      	mov	w9, #0x22e9             // =8937
   16620:      	cmp	w8, w9
   16624:      	b.eq	0x16748 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd734>
   16628:      	mov	w9, #0x2300             // =8960
   1662c:      	cmp	w8, w9
   16630:      	b.eq	0x16764 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd750>
   16634:      	mov	w9, #0x2324             // =8996
   16638:      	cmp	w8, w9
   1663c:      	b.ne	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   16640:      	cmp	w1, #0x4
   16644:      	b.eq	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   16648:      	cmp	w1, #0x8
   1664c:      	b.ne	0x16784 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd770>
   16650:      	mov	w8, #0x2322             // =8994
   16654:      	str	w8, [x0, #0x8]
   16658:      	ret
   1665c:      	ldr	w9, [x0, #0x8]
   16660:      	mov	w10, #0x2324            // =8996
   16664:      	cmp	w9, w10
   16668:      	b.eq	0x16714 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd700>
   1666c:      	mov	w10, #0x2310            // =8976
   16670:      	cmp	w9, w10
   16674:      	b.ne	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   16678:      	mov	w9, #0x4753             // =18259
   1667c:      	cmp	w8, w9
   16680:      	b.ne	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   16684:      	mov	w8, #0x5250             // =21072
   16688:      	mov	w9, #0x4f               // =79
   1668c:      	strh	w8, [x0, #0xc]
   16690:      	strb	w9, [x0, #0xe]
   16694:      	ret
   16698:      	mov	w8, #0x1a4c             // =6732
   1669c:      	str	w8, [x0, #0x8]
   166a0:      	ldrb	w8, [x0, #0xc]
   166a4:      	cmp	w8, #0x54
   166a8:      	b.ne	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   166ac:      	ldur	w8, [x0, #0xd]
   166b0:      	mov	w9, #0x5552             // =21842
   166b4:      	movk	w9, #0x4f42, lsl #16
   166b8:      	cmp	w8, w9
   166bc:      	b.eq	0x166d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd6bc>
   166c0:      	mov	w9, #0x5255             // =21077
   166c4:      	movk	w9, #0x4f42, lsl #16
   166c8:      	cmp	w8, w9
   166cc:      	b.ne	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   166d0:      	ldrb	w8, [x0, #0x11]
   166d4:      	cbnz	w8, 0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   166d8:      	stur	wzr, [x0, #0xd]
   166dc:      	ret
   166e0:      	mov	w9, #0x2018             // =8216
   166e4:      	cmp	w8, w9
   166e8:      	b.eq	0x1678c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd778>
   166ec:      	mov	w9, #0x22d4             // =8916
   166f0:      	cmp	w8, w9
   166f4:      	b.ne	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   166f8:      	cmp	w1, #0x4
   166fc:      	b.eq	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   16700:      	cmp	w1, #0x8
   16704:      	b.ne	0x16784 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd770>
   16708:      	mov	w8, #0x22eb             // =8939
   1670c:      	str	w8, [x0, #0x8]
   16710:      	ret
   16714:      	mov	w9, #0x5250             // =21072
   16718:      	movk	w9, #0x4f, lsl #16
   1671c:      	cmp	w8, w9
   16720:      	b.ne	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   16724:      	mov	w8, #0x65ff             // =26111
   16728:      	mov	w9, #0x412d             // =16685
   1672c:      	movk	w8, #0x21, lsl #16
   16730:      	sturh	w9, [x0, #0xf]
   16734:      	cmp	w2, w8
   16738:      	mov	w8, #0x42               // =66
   1673c:      	cinc	w8, w8, hi
   16740:      	strb	w8, [x0, #0x11]
   16744:      	ret
   16748:      	cmp	w1, #0x8
   1674c:      	b.eq	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   16750:      	cmp	w1, #0x4
   16754:      	b.ne	0x16784 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd770>
   16758:      	mov	w8, #0x22d5             // =8917
   1675c:      	str	w8, [x0, #0x8]
   16760:      	ret
   16764:      	cmp	w1, #0x2
   16768:      	b.eq	0x16590 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd57c>
   1676c:      	cmp	w1, #0x4
   16770:      	b.ne	0x16784 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd770>
   16774:      	adrp	x8, 0x4000
   16778:      	ldr	d0, [x8, #0xf00]
   1677c:      	stur	d0, [x0, #0x4]
   16780:      	ret
   16784:      	str	wzr, [x0, #0x8]
   16788:      	ret
   1678c:      	mov	w8, #0x22d4             // =8916
   16790:      	str	w8, [x0, #0x8]
   16794:      	ret
   16798:      	sub	sp, sp, #0x50
   1679c:      	stp	x29, x30, [sp, #0x10]
   167a0:      	str	x23, [sp, #0x20]
   167a4:      	stp	x22, x21, [sp, #0x30]
   167a8:      	stp	x20, x19, [sp, #0x40]
   167ac:      	add	x29, sp, #0x10
   167b0:      	ldp	w8, w10, [x0]
   167b4:      	nop
   167b8:      	adr	x9, 0x21bc8
   167bc:      	ldr	w22, [x0, #0x8]
   167c0:      	mov	x21, x1
   167c4:      	cmp	w8, #0x17
   167c8:      	csel	w11, wzr, w8, hi
   167cc:      	cmp	w10, #0x22
   167d0:      	csel	w8, wzr, w10, hi
   167d4:      	ldr	x19, [x9, w11, uxtw #3]
   167d8:      	nop
   167dc:      	adr	x9, 0x21c88
   167e0:      	ldr	x20, [x9, w8, uxtw #3]
   167e4:      	cbz	w22, 0x16838 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd824>
   167e8:      	add	x23, x0, #0xc
   167ec:      	mov	w1, #0x8                // =8
   167f0:      	mov	x0, x23
   167f4:      	bl	0x1d810 <strnlen@plt>
   167f8:      	mov	x7, x0
   167fc:      	adrp	x3, 0x4000
   16800:      	add	x3, x3, #0x654
   16804:      	mov	x0, x21
   16808:      	mov	x1, #-0x1               // =-1
   1680c:      	mov	x4, x19
   16810:      	mov	x5, x20
   16814:      	mov	w6, w22
   16818:      	str	x23, [sp]
   1681c:      	bl	0x168dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd8c8>
   16820:      	ldp	x20, x19, [sp, #0x40]
   16824:      	ldr	x23, [sp, #0x20]
   16828:      	ldp	x22, x21, [sp, #0x30]
   1682c:      	ldp	x29, x30, [sp, #0x10]
   16830:      	add	sp, sp, #0x50
   16834:      	ret
   16838:      	cbz	w8, 0x16888 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd874>
   1683c:      	mov	x22, x0
   16840:      	add	x0, x0, #0xc
   16844:      	mov	w1, #0x8                // =8
   16848:      	bl	0x1d810 <strnlen@plt>
   1684c:      	cbz	x0, 0x168ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd898>
   16850:      	mov	x6, x0
   16854:      	nop
   16858:      	adr	x3, 0x479e
   1685c:      	add	x7, x22, #0xc
   16860:      	mov	x0, x21
   16864:      	mov	x1, #-0x1               // =-1
   16868:      	mov	x4, x19
   1686c:      	mov	x5, x20
   16870:      	ldp	x20, x19, [sp, #0x40]
   16874:      	ldr	x23, [sp, #0x20]
   16878:      	ldp	x22, x21, [sp, #0x30]
   1687c:      	ldp	x29, x30, [sp, #0x10]
   16880:      	add	sp, sp, #0x50
   16884:      	b	0x168dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd8c8>
   16888:      	mov	x0, x21
   1688c:      	mov	x1, x19
   16890:      	mov	w2, #0x80               // =128
   16894:      	ldp	x20, x19, [sp, #0x40]
   16898:      	ldr	x23, [sp, #0x20]
   1689c:      	ldp	x22, x21, [sp, #0x30]
   168a0:      	ldp	x29, x30, [sp, #0x10]
   168a4:      	add	sp, sp, #0x50
   168a8:      	b	0x1d5d0 <strncpy@plt>
   168ac:      	adrp	x3, 0x4000
   168b0:      	add	x3, x3, #0xadc
   168b4:      	mov	x0, x21
   168b8:      	mov	x1, #-0x1               // =-1
   168bc:      	mov	x4, x19
   168c0:      	mov	x5, x20
   168c4:      	ldp	x20, x19, [sp, #0x40]
   168c8:      	ldr	x23, [sp, #0x20]
   168cc:      	ldp	x22, x21, [sp, #0x30]
   168d0:      	ldp	x29, x30, [sp, #0x10]
   168d4:      	add	sp, sp, #0x50
   168d8:      	b	0x168dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd8c8>
   168dc:      	sub	sp, sp, #0x110
   168e0:      	stp	x29, x30, [sp, #0xf0]
   168e4:      	stp	x28, x19, [sp, #0x100]
   168e8:      	add	x29, sp, #0xf0
   168ec:      	stp	x4, x5, [x29, #-0x70]
   168f0:      	sub	x10, x29, #0x70
   168f4:      	mov	x11, sp
   168f8:      	stp	x6, x7, [x29, #-0x60]
   168fc:      	add	x11, x11, #0x80
   16900:      	mov	x8, x3
   16904:      	stp	q0, q1, [sp]
   16908:      	mov	x3, x1
   1690c:      	sub	x5, x29, #0x50
   16910:      	stp	q2, q3, [sp, #0x20]
   16914:      	mov	w1, #0x80               // =128
   16918:      	mov	w2, wzr
   1691c:      	stp	q4, q5, [sp, #0x40]
   16920:      	mov	x4, x8
   16924:      	stp	q6, q7, [sp, #0x60]
   16928:      	mrs	x19, TPIDR_EL0
   1692c:      	ldr	x9, [x19, #0x28]
   16930:      	stur	x9, [x29, #-0x8]
   16934:      	add	x9, x10, #0x20
   16938:      	add	x10, x29, #0x20
   1693c:      	stp	x10, x9, [x29, #-0x28]
   16940:      	mov	x9, #-0x20              // =-32
   16944:      	sub	x10, x29, #0x28
   16948:      	movk	x9, #0xff80, lsl #32
   1694c:      	stp	x11, x9, [x29, #-0x18]
   16950:      	ldp	q0, q1, [x10]
   16954:      	stp	q0, q1, [x29, #-0x50]
   16958:      	bl	0x1d520 <__vsnprintf_chk@plt>
   1695c:      	ldr	x8, [x19, #0x28]
   16960:      	ldur	x9, [x29, #-0x8]
   16964:      	cmp	x8, x9
   16968:      	b.ne	0x1697c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd968>
   1696c:      	ldp	x28, x19, [sp, #0x100]
   16970:      	ldp	x29, x30, [sp, #0xf0]
   16974:      	add	sp, sp, #0x110
   16978:      	ret
   1697c:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   16980:      	sub	sp, sp, #0x190
   16984:      	stp	x29, x30, [sp, #0x130]
   16988:      	stp	x28, x27, [sp, #0x140]
   1698c:      	stp	x26, x25, [sp, #0x150]
   16990:      	stp	x24, x23, [sp, #0x160]
   16994:      	stp	x22, x21, [sp, #0x170]
   16998:      	stp	x20, x19, [sp, #0x180]
   1699c:      	add	x29, sp, #0x130
   169a0:      	mrs	x26, TPIDR_EL0
   169a4:      	mov	x19, x8
   169a8:      	mov	w20, w1
   169ac:      	ldr	x8, [x26, #0x28]
   169b0:      	mov	x21, x0
   169b4:      	sub	x24, x29, #0x40
   169b8:      	add	x0, x0, #0x9c
   169bc:      	mov	w1, #0x5c               // =92
   169c0:      	mov	w28, w2
   169c4:      	stur	x8, [x29, #-0x18]
   169c8:      	stp	xzr, xzr, [x24]
   169cc:      	stur	wzr, [x29, #-0x30]
   169d0:      	bl	0x1d810 <strnlen@plt>
   169d4:      	sub	x8, x0, #0x5
   169d8:      	mov	w3, wzr
   169dc:      	cmp	x8, #0x1
   169e0:      	b.hi	0x16a20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xda0c>
   169e4:      	ldrb	w8, [x21, #0x9c]
   169e8:      	cmp	w8, #0x74
   169ec:      	b.ne	0x16a20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xda0c>
   169f0:      	ldur	w8, [x21, #0x9d]
   169f4:      	mov	w9, #0x6765             // =26469
   169f8:      	movk	w9, #0x6172, lsl #16
   169fc:      	cmp	w8, w9
   16a00:      	b.ne	0x16a20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xda0c>
   16a04:      	cmp	x0, #0x5
   16a08:      	b.ne	0x16a14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xda00>
   16a0c:      	mov	w3, #0x1                // =1
   16a10:      	b	0x16a20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xda0c>
   16a14:      	ldrb	w8, [x21, #0xa1]
   16a18:      	cmp	w8, #0x33
   16a1c:      	cset	w3, eq
   16a20:      	add	x8, sp, #0x3c
   16a24:      	mov	x0, x21
   16a28:      	mov	w1, w20
   16a2c:      	add	x22, sp, #0x3c
   16a30:      	bl	0x12e3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x9e28>
   16a34:      	add	x8, x22, #0x14
   16a38:      	add	x0, x21, #0x40
   16a3c:      	str	x8, [sp, #0x30]
   16a40:      	bl	0x14e4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbe38>
   16a44:      	add	x27, x22, #0x28
   16a48:      	add	x0, x21, #0x9c
   16a4c:      	mov	x8, x27
   16a50:      	bl	0x15b3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xcb28>
   16a54:      	add	x23, x21, #0xf8
   16a58:      	mov	w1, #0x5c               // =92
   16a5c:      	add	x22, x22, #0x3c
   16a60:      	mov	x0, x23
   16a64:      	bl	0x1d810 <strnlen@plt>
   16a68:      	add	x1, x23, x0
   16a6c:      	sub	x3, x29, #0x2c
   16a70:      	mov	x0, x23
   16a74:      	mov	w2, wzr
   16a78:      	bl	0x13a28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xaa14>
   16a7c:      	tbz	w0, #0x0, 0x16a94 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xda80>
   16a80:      	ldur	q0, [x24, #0x14]
   16a84:      	ldur	w8, [x29, #-0x1c]
   16a88:      	str	q0, [x22]
   16a8c:      	str	w8, [x22, #0x10]
   16a90:      	b	0x16a9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xda88>
   16a94:      	stp	xzr, xzr, [x22]
   16a98:      	str	wzr, [x22, #0x10]
   16a9c:      	add	x8, sp, #0x3c
   16aa0:      	add	x0, x21, #0x154
   16aa4:      	mov	w1, #0x5c               // =92
   16aa8:      	add	x24, x8, #0x50
   16aac:      	bl	0x1d810 <strnlen@plt>
   16ab0:      	cmp	x0, #0xa
   16ab4:      	b.ne	0x16b44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdb30>
   16ab8:      	ldr	w8, [x21, #0x154]
   16abc:      	mov	w9, #0x7865             // =30821
   16ac0:      	movk	w9, #0x6e79, lsl #16
   16ac4:      	cmp	w8, w9
   16ac8:      	b.ne	0x16b44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdb30>
   16acc:      	ldrh	w8, [x21, #0x158]
   16ad0:      	mov	w9, #0x736f             // =29551
   16ad4:      	cmp	w8, w9
   16ad8:      	b.ne	0x16b44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdb30>
   16adc:      	ldrb	w8, [x21, #0x15a]
   16ae0:      	sub	w8, w8, #0x30
   16ae4:      	cmp	w8, #0x9
   16ae8:      	b.hi	0x16b44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdb30>
   16aec:      	ldrb	w9, [x21, #0x15b]
   16af0:      	sub	w9, w9, #0x30
   16af4:      	cmp	w9, #0x9
   16af8:      	b.hi	0x16b44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdb30>
   16afc:      	ldrb	w10, [x21, #0x15c]
   16b00:      	sub	w10, w10, #0x30
   16b04:      	cmp	w10, #0x9
   16b08:      	b.hi	0x16b44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdb30>
   16b0c:      	ldrb	w11, [x21, #0x15d]
   16b10:      	sub	w11, w11, #0x30
   16b14:      	cmp	w11, #0x9
   16b18:      	b.hi	0x16b44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdb30>
   16b1c:      	mov	w12, #0xa               // =10
   16b20:      	stur	xzr, [sp, #0x98]
   16b24:      	madd	w8, w8, w12, w9
   16b28:      	adrp	x9, 0x4000
   16b2c:      	ldr	d0, [x9, #0xf58]
   16b30:      	madd	w8, w8, w12, w10
   16b34:      	stur	d0, [sp, #0x8c]
   16b38:      	madd	w8, w8, w12, w11
   16b3c:      	str	w8, [sp, #0x94]
   16b40:      	b	0x16b4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdb38>
   16b44:      	stp	xzr, xzr, [x24]
   16b48:      	str	wzr, [x24, #0x10]
   16b4c:      	add	x25, sp, #0x3c
   16b50:      	add	x0, x21, #0x1b0
   16b54:      	add	x8, x25, #0x64
   16b58:      	str	x8, [sp, #0x28]
   16b5c:      	bl	0x161fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1e8>
   16b60:      	add	x23, x25, #0x78
   16b64:      	add	x0, x21, #0x20c
   16b68:      	mov	x8, x23
   16b6c:      	bl	0x161fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd1e8>
   16b70:      	add	x8, x25, #0x8c
   16b74:      	add	x0, x21, #0x268
   16b78:      	str	x8, [sp, #0x20]
   16b7c:      	bl	0x1488c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xb878>
   16b80:      	add	x8, x25, #0xa0
   16b84:      	add	x0, x21, #0x2c4
   16b88:      	str	x8, [sp, #0x18]
   16b8c:      	bl	0x14c44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xbc30>
   16b90:      	ldr	w25, [sp, #0x3c]
   16b94:      	ldr	w8, [sp, #0x50]
   16b98:      	cbz	w25, 0x16bac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdb98>
   16b9c:      	cbz	w8, 0x16bb4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdba0>
   16ba0:      	cmp	w25, w8
   16ba4:      	b.ne	0x16c7c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc68>
   16ba8:      	b	0x16bb4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdba0>
   16bac:      	mov	w25, w8
   16bb0:      	cbz	w8, 0x16bc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdbb4>
   16bb4:      	ldr	w8, [sp, #0x64]
   16bb8:      	cbz	w8, 0x16bd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdbbc>
   16bbc:      	cmp	w25, w8
   16bc0:      	b.ne	0x16c7c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc68>
   16bc4:      	b	0x16bd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdbbc>
   16bc8:      	ldr	w25, [sp, #0x64]
   16bcc:      	cbz	w25, 0x16bf0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdbdc>
   16bd0:      	ldr	w8, [sp, #0x78]
   16bd4:      	cbz	w8, 0x16bf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdbe4>
   16bd8:      	cbz	w25, 0x16be8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdbd4>
   16bdc:      	cmp	w25, w8
   16be0:      	b.eq	0x16bf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdbe4>
   16be4:      	b	0x16c7c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc68>
   16be8:      	mov	w25, w8
   16bec:      	b	0x16bf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdbe4>
   16bf0:      	ldr	w25, [sp, #0x78]
   16bf4:      	cbz	w25, 0x16d80 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdd6c>
   16bf8:      	ldr	w8, [sp, #0x8c]
   16bfc:      	cbz	w8, 0x16c14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc00>
   16c00:      	cbz	w25, 0x16c10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdbfc>
   16c04:      	cmp	w25, w8
   16c08:      	b.eq	0x16c14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc00>
   16c0c:      	b	0x16c7c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc68>
   16c10:      	mov	w25, w8
   16c14:      	ldr	w8, [sp, #0xa0]
   16c18:      	cbz	w8, 0x16c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc1c>
   16c1c:      	cbz	w25, 0x16c2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc18>
   16c20:      	cmp	w25, w8
   16c24:      	b.eq	0x16c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc1c>
   16c28:      	b	0x16c7c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc68>
   16c2c:      	mov	w25, w8
   16c30:      	ldr	w8, [sp, #0xb4]
   16c34:      	cbz	w8, 0x16c4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc38>
   16c38:      	cbz	w25, 0x16c48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc34>
   16c3c:      	cmp	w25, w8
   16c40:      	b.eq	0x16c4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc38>
   16c44:      	b	0x16c7c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc68>
   16c48:      	mov	w25, w8
   16c4c:      	ldr	w8, [sp, #0xc8]
   16c50:      	cbz	w8, 0x16c68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc54>
   16c54:      	cbz	w25, 0x16c64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc50>
   16c58:      	cmp	w25, w8
   16c5c:      	b.eq	0x16c68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc54>
   16c60:      	b	0x16c7c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc68>
   16c64:      	mov	w25, w8
   16c68:      	ldr	w8, [sp, #0xdc]
   16c6c:      	cbz	w8, 0x16ccc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdcb8>
   16c70:      	cbz	w25, 0x16cd4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdcc0>
   16c74:      	cmp	w25, w8
   16c78:      	b.eq	0x16cd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdcc4>
   16c7c:      	adrp	x0, 0x4000
   16c80:      	add	x0, x0, #0x325
   16c84:      	bl	0x17620 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe60c>
   16c88:      	sub	x23, x29, #0x40
   16c8c:      	ldr	q0, [x23]
   16c90:      	ldr	w8, [x23, #0x10]
   16c94:      	str	q0, [x19]
   16c98:      	str	w8, [x19, #0x10]
   16c9c:      	ldr	x8, [x26, #0x28]
   16ca0:      	ldur	x9, [x29, #-0x18]
   16ca4:      	cmp	x8, x9
   16ca8:      	b.ne	0x1761c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe608>
   16cac:      	ldp	x20, x19, [sp, #0x180]
   16cb0:      	ldp	x22, x21, [sp, #0x170]
   16cb4:      	ldp	x24, x23, [sp, #0x160]
   16cb8:      	ldp	x26, x25, [sp, #0x150]
   16cbc:      	ldp	x28, x27, [sp, #0x140]
   16cc0:      	ldp	x29, x30, [sp, #0x130]
   16cc4:      	add	sp, sp, #0x190
   16cc8:      	ret
   16ccc:      	cbnz	w25, 0x16cd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdcc4>
   16cd0:      	b	0x16c88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc74>
   16cd4:      	mov	w25, w8
   16cd8:      	add	x0, sp, #0x3c
   16cdc:      	mov	w1, w20
   16ce0:      	mov	w2, w28
   16ce4:      	str	x26, [sp, #0x10]
   16ce8:      	mov	x21, x27
   16cec:      	add	x27, sp, #0x3c
   16cf0:      	bl	0x16524 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd510>
   16cf4:      	ldr	x0, [sp, #0x30]
   16cf8:      	mov	w1, w20
   16cfc:      	mov	w2, w28
   16d00:      	bl	0x16524 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd510>
   16d04:      	mov	x0, x21
   16d08:      	mov	w1, w20
   16d0c:      	mov	w2, w28
   16d10:      	str	x21, [sp, #0x8]
   16d14:      	bl	0x16524 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd510>
   16d18:      	mov	x0, x22
   16d1c:      	mov	w1, w20
   16d20:      	mov	w2, w28
   16d24:      	bl	0x16524 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd510>
   16d28:      	mov	x0, x24
   16d2c:      	mov	w1, w20
   16d30:      	mov	w2, w28
   16d34:      	bl	0x16524 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd510>
   16d38:      	ldr	x0, [sp, #0x28]
   16d3c:      	mov	w1, w20
   16d40:      	mov	w2, w28
   16d44:      	bl	0x16524 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd510>
   16d48:      	mov	x0, x23
   16d4c:      	mov	w1, w20
   16d50:      	mov	w2, w28
   16d54:      	bl	0x16524 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd510>
   16d58:      	ldr	x0, [sp, #0x20]
   16d5c:      	mov	w1, w20
   16d60:      	mov	w2, w28
   16d64:      	bl	0x16524 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd510>
   16d68:      	ldr	x0, [sp, #0x18]
   16d6c:      	mov	w1, w20
   16d70:      	mov	w2, w28
   16d74:      	bl	0x16524 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xd510>
   16d78:      	mov	x28, xzr
   16d7c:      	b	0x16dc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xddb4>
   16d80:      	ldr	w25, [sp, #0x8c]
   16d84:      	cbnz	w25, 0x16c14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc00>
   16d88:      	ldr	w25, [sp, #0xa0]
   16d8c:      	cbnz	w25, 0x16c30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc1c>
   16d90:      	ldr	w25, [sp, #0xb4]
   16d94:      	cbnz	w25, 0x16c4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc38>
   16d98:      	ldr	w25, [sp, #0xc8]
   16d9c:      	cbnz	w25, 0x16c68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc54>
   16da0:      	ldr	w25, [sp, #0xdc]
   16da4:      	cbnz	w25, 0x16cd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdcc4>
   16da8:      	b	0x16c88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc74>
   16dac:      	add	x0, x27, #0x98
   16db0:      	add	x1, x26, #0xc
   16db4:      	mov	x2, x20
   16db8:      	bl	0x1d540 <memcpy@plt>
   16dbc:      	add	x28, x28, #0x14
   16dc0:      	cmp	x28, #0xb4
   16dc4:      	b.eq	0x17148 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe134>
   16dc8:      	add	x26, x27, x28
   16dcc:      	mov	w1, #0x8                // =8
   16dd0:      	add	x0, x26, #0xc
   16dd4:      	bl	0x1d810 <strnlen@plt>
   16dd8:      	cbz	x28, 0x16dbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdda8>
   16ddc:      	ldr	w8, [x26, #0x4]
   16de0:      	ldr	w9, [sp, #0x40]
   16de4:      	mov	x20, x0
   16de8:      	cmp	w8, w9
   16dec:      	b.ne	0x16e48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xde34>
   16df0:      	add	x0, x27, #0xc
   16df4:      	mov	w1, #0x8                // =8
   16df8:      	bl	0x1d810 <strnlen@plt>
   16dfc:      	cmp	x20, x0
   16e00:      	b.eq	0x16e48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xde34>
   16e04:      	mov	x21, x0
   16e08:      	csel	x2, x20, x0, lo
   16e0c:      	cbz	x2, 0x16e20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xde0c>
   16e10:      	add	x0, x26, #0xc
   16e14:      	add	x1, x27, #0xc
   16e18:      	bl	0x1d8d0 <memcmp@plt>
   16e1c:      	cbnz	w0, 0x16e48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xde34>
   16e20:      	cmp	x20, x21
   16e24:      	b.ls	0x16e38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xde24>
   16e28:      	add	x0, x27, #0xc
   16e2c:      	add	x1, x26, #0xc
   16e30:      	mov	x2, x20
   16e34:      	b	0x16e44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xde30>
   16e38:      	add	x0, x26, #0xc
   16e3c:      	add	x1, x27, #0xc
   16e40:      	mov	x2, x21
   16e44:      	bl	0x1d540 <memcpy@plt>
   16e48:      	cmp	x28, #0x14
   16e4c:      	b.eq	0x16dbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdda8>
   16e50:      	ldr	w8, [x26, #0x4]
   16e54:      	ldr	w9, [sp, #0x54]
   16e58:      	cmp	w8, w9
   16e5c:      	b.ne	0x16eb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdea4>
   16e60:      	add	x0, x27, #0x20
   16e64:      	mov	w1, #0x8                // =8
   16e68:      	bl	0x1d810 <strnlen@plt>
   16e6c:      	cmp	x20, x0
   16e70:      	b.eq	0x16eb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdea4>
   16e74:      	mov	x21, x0
   16e78:      	csel	x2, x20, x0, lo
   16e7c:      	cbz	x2, 0x16e90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xde7c>
   16e80:      	add	x0, x26, #0xc
   16e84:      	add	x1, x27, #0x20
   16e88:      	bl	0x1d8d0 <memcmp@plt>
   16e8c:      	cbnz	w0, 0x16eb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdea4>
   16e90:      	cmp	x20, x21
   16e94:      	b.ls	0x16ea8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xde94>
   16e98:      	add	x0, x27, #0x20
   16e9c:      	add	x1, x26, #0xc
   16ea0:      	mov	x2, x20
   16ea4:      	b	0x16eb4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdea0>
   16ea8:      	add	x0, x26, #0xc
   16eac:      	add	x1, x27, #0x20
   16eb0:      	mov	x2, x21
   16eb4:      	bl	0x1d540 <memcpy@plt>
   16eb8:      	cmp	x28, #0x28
   16ebc:      	b.eq	0x16dbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdda8>
   16ec0:      	ldr	w8, [x26, #0x4]
   16ec4:      	ldr	w9, [sp, #0x68]
   16ec8:      	cmp	w8, w9
   16ecc:      	b.ne	0x16f28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdf14>
   16ed0:      	add	x0, x27, #0x34
   16ed4:      	mov	w1, #0x8                // =8
   16ed8:      	bl	0x1d810 <strnlen@plt>
   16edc:      	cmp	x20, x0
   16ee0:      	b.eq	0x16f28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdf14>
   16ee4:      	mov	x21, x0
   16ee8:      	csel	x2, x20, x0, lo
   16eec:      	cbz	x2, 0x16f00 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdeec>
   16ef0:      	add	x0, x26, #0xc
   16ef4:      	add	x1, x27, #0x34
   16ef8:      	bl	0x1d8d0 <memcmp@plt>
   16efc:      	cbnz	w0, 0x16f28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdf14>
   16f00:      	cmp	x20, x21
   16f04:      	b.ls	0x16f18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdf04>
   16f08:      	add	x0, x27, #0x34
   16f0c:      	add	x1, x26, #0xc
   16f10:      	mov	x2, x20
   16f14:      	b	0x16f24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdf10>
   16f18:      	add	x0, x26, #0xc
   16f1c:      	add	x1, x27, #0x34
   16f20:      	mov	x2, x21
   16f24:      	bl	0x1d540 <memcpy@plt>
   16f28:      	cmp	x28, #0x3c
   16f2c:      	b.eq	0x16dbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdda8>
   16f30:      	ldr	w8, [x26, #0x4]
   16f34:      	ldr	w9, [sp, #0x7c]
   16f38:      	cmp	w8, w9
   16f3c:      	b.ne	0x16f98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdf84>
   16f40:      	add	x0, x27, #0x48
   16f44:      	mov	w1, #0x8                // =8
   16f48:      	bl	0x1d810 <strnlen@plt>
   16f4c:      	cmp	x20, x0
   16f50:      	b.eq	0x16f98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdf84>
   16f54:      	mov	x21, x0
   16f58:      	csel	x2, x20, x0, lo
   16f5c:      	cbz	x2, 0x16f70 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdf5c>
   16f60:      	add	x0, x26, #0xc
   16f64:      	add	x1, x27, #0x48
   16f68:      	bl	0x1d8d0 <memcmp@plt>
   16f6c:      	cbnz	w0, 0x16f98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdf84>
   16f70:      	cmp	x20, x21
   16f74:      	b.ls	0x16f88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdf74>
   16f78:      	add	x0, x27, #0x48
   16f7c:      	add	x1, x26, #0xc
   16f80:      	mov	x2, x20
   16f84:      	b	0x16f94 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdf80>
   16f88:      	add	x0, x26, #0xc
   16f8c:      	add	x1, x27, #0x48
   16f90:      	mov	x2, x21
   16f94:      	bl	0x1d540 <memcpy@plt>
   16f98:      	cmp	x28, #0x50
   16f9c:      	b.eq	0x16dbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdda8>
   16fa0:      	ldr	w8, [x26, #0x4]
   16fa4:      	ldr	w9, [sp, #0x90]
   16fa8:      	cmp	w8, w9
   16fac:      	b.ne	0x17008 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdff4>
   16fb0:      	add	x0, x27, #0x5c
   16fb4:      	mov	w1, #0x8                // =8
   16fb8:      	bl	0x1d810 <strnlen@plt>
   16fbc:      	cmp	x20, x0
   16fc0:      	b.eq	0x17008 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdff4>
   16fc4:      	mov	x21, x0
   16fc8:      	csel	x2, x20, x0, lo
   16fcc:      	cbz	x2, 0x16fe0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdfcc>
   16fd0:      	add	x0, x26, #0xc
   16fd4:      	add	x1, x27, #0x5c
   16fd8:      	bl	0x1d8d0 <memcmp@plt>
   16fdc:      	cbnz	w0, 0x17008 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdff4>
   16fe0:      	cmp	x20, x21
   16fe4:      	b.ls	0x16ff8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdfe4>
   16fe8:      	add	x0, x27, #0x5c
   16fec:      	add	x1, x26, #0xc
   16ff0:      	mov	x2, x20
   16ff4:      	b	0x17004 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdff0>
   16ff8:      	add	x0, x26, #0xc
   16ffc:      	add	x1, x27, #0x5c
   17000:      	mov	x2, x21
   17004:      	bl	0x1d540 <memcpy@plt>
   17008:      	cmp	x28, #0x64
   1700c:      	b.eq	0x16dbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdda8>
   17010:      	ldr	w8, [x26, #0x4]
   17014:      	ldr	w9, [sp, #0xa4]
   17018:      	cmp	w8, w9
   1701c:      	b.ne	0x17078 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe064>
   17020:      	add	x0, x27, #0x70
   17024:      	mov	w1, #0x8                // =8
   17028:      	bl	0x1d810 <strnlen@plt>
   1702c:      	cmp	x20, x0
   17030:      	b.eq	0x17078 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe064>
   17034:      	mov	x21, x0
   17038:      	csel	x2, x20, x0, lo
   1703c:      	cbz	x2, 0x17050 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe03c>
   17040:      	add	x0, x26, #0xc
   17044:      	add	x1, x27, #0x70
   17048:      	bl	0x1d8d0 <memcmp@plt>
   1704c:      	cbnz	w0, 0x17078 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe064>
   17050:      	cmp	x20, x21
   17054:      	b.ls	0x17068 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe054>
   17058:      	add	x0, x27, #0x70
   1705c:      	add	x1, x26, #0xc
   17060:      	mov	x2, x20
   17064:      	b	0x17074 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe060>
   17068:      	add	x0, x26, #0xc
   1706c:      	add	x1, x27, #0x70
   17070:      	mov	x2, x21
   17074:      	bl	0x1d540 <memcpy@plt>
   17078:      	cmp	x28, #0x78
   1707c:      	b.eq	0x16dbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdda8>
   17080:      	ldr	w8, [x26, #0x4]
   17084:      	ldr	w9, [sp, #0xb8]
   17088:      	cmp	w8, w9
   1708c:      	b.ne	0x170e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe0d4>
   17090:      	add	x0, x27, #0x84
   17094:      	mov	w1, #0x8                // =8
   17098:      	bl	0x1d810 <strnlen@plt>
   1709c:      	cmp	x20, x0
   170a0:      	b.eq	0x170e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe0d4>
   170a4:      	mov	x21, x0
   170a8:      	csel	x2, x20, x0, lo
   170ac:      	cbz	x2, 0x170c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe0ac>
   170b0:      	add	x0, x26, #0xc
   170b4:      	add	x1, x27, #0x84
   170b8:      	bl	0x1d8d0 <memcmp@plt>
   170bc:      	cbnz	w0, 0x170e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe0d4>
   170c0:      	cmp	x20, x21
   170c4:      	b.ls	0x170d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe0c4>
   170c8:      	add	x0, x27, #0x84
   170cc:      	add	x1, x26, #0xc
   170d0:      	mov	x2, x20
   170d4:      	b	0x170e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe0d0>
   170d8:      	add	x0, x26, #0xc
   170dc:      	add	x1, x27, #0x84
   170e0:      	mov	x2, x21
   170e4:      	bl	0x1d540 <memcpy@plt>
   170e8:      	cmp	x28, #0x8c
   170ec:      	b.eq	0x16dbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdda8>
   170f0:      	ldr	w8, [x26, #0x4]
   170f4:      	ldr	w9, [sp, #0xcc]
   170f8:      	cmp	w8, w9
   170fc:      	b.ne	0x16dbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdda8>
   17100:      	add	x0, x27, #0x98
   17104:      	mov	w1, #0x8                // =8
   17108:      	bl	0x1d810 <strnlen@plt>
   1710c:      	cmp	x20, x0
   17110:      	b.eq	0x16dbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdda8>
   17114:      	mov	x21, x0
   17118:      	csel	x2, x20, x0, lo
   1711c:      	cbz	x2, 0x17130 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe11c>
   17120:      	add	x0, x26, #0xc
   17124:      	add	x1, x27, #0x98
   17128:      	bl	0x1d8d0 <memcmp@plt>
   1712c:      	cbnz	w0, 0x16dbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdda8>
   17130:      	cmp	x20, x21
   17134:      	b.hi	0x16dac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdd98>
   17138:      	add	x0, x26, #0xc
   1713c:      	add	x1, x27, #0x98
   17140:      	mov	x2, x21
   17144:      	b	0x16db8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdda4>
   17148:      	ldr	w20, [sp, #0x40]
   1714c:      	sub	x27, x29, #0x40
   17150:      	cbz	w20, 0x17164 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe150>
   17154:      	ldur	q0, [sp, #0x3c]
   17158:      	ldr	w8, [sp, #0x4c]
   1715c:      	str	q0, [x27]
   17160:      	stur	w8, [x29, #-0x30]
   17164:      	ldr	w8, [sp, #0x54]
   17168:      	ldr	x26, [sp, #0x10]
   1716c:      	sub	x21, x29, #0x40
   17170:      	cbz	w8, 0x171c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe1b0>
   17174:      	ldur	w9, [x29, #-0x3c]
   17178:      	cbz	w9, 0x171b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe19c>
   1717c:      	cmp	w8, w9
   17180:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   17184:      	ldr	w8, [sp, #0x58]
   17188:      	ldur	w9, [x29, #-0x38]
   1718c:      	cmp	w8, w9
   17190:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   17194:      	add	x8, sp, #0x3c
   17198:      	add	x1, x21, #0xc
   1719c:      	mov	w2, #0x8                // =8
   171a0:      	add	x0, x8, #0x20
   171a4:      	bl	0x1d8c0 <strncmp@plt>
   171a8:      	cbnz	w0, 0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   171ac:      	b	0x171c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe1b0>
   171b0:      	ldr	x8, [sp, #0x30]
   171b4:      	ldr	q0, [x8]
   171b8:      	ldr	w8, [x8, #0x10]
   171bc:      	str	q0, [x27]
   171c0:      	stur	w8, [x29, #-0x30]
   171c4:      	ldr	w8, [sp, #0x68]
   171c8:      	cbz	w8, 0x1721c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe208>
   171cc:      	ldur	w9, [x29, #-0x3c]
   171d0:      	cbz	w9, 0x17208 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe1f4>
   171d4:      	cmp	w8, w9
   171d8:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   171dc:      	ldr	w8, [sp, #0x6c]
   171e0:      	ldur	w9, [x29, #-0x38]
   171e4:      	cmp	w8, w9
   171e8:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   171ec:      	add	x8, sp, #0x3c
   171f0:      	add	x1, x21, #0xc
   171f4:      	mov	w2, #0x8                // =8
   171f8:      	add	x0, x8, #0x34
   171fc:      	bl	0x1d8c0 <strncmp@plt>
   17200:      	cbnz	w0, 0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   17204:      	b	0x1721c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe208>
   17208:      	ldr	x8, [sp, #0x8]
   1720c:      	ldr	q0, [x8]
   17210:      	ldr	w8, [x8, #0x10]
   17214:      	str	q0, [x27]
   17218:      	stur	w8, [x29, #-0x30]
   1721c:      	ldr	w8, [sp, #0x7c]
   17220:      	cbz	w8, 0x17270 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe25c>
   17224:      	ldur	w9, [x29, #-0x3c]
   17228:      	cbz	w9, 0x17260 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe24c>
   1722c:      	cmp	w8, w9
   17230:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   17234:      	ldr	w8, [sp, #0x80]
   17238:      	ldur	w9, [x29, #-0x38]
   1723c:      	cmp	w8, w9
   17240:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   17244:      	add	x8, sp, #0x3c
   17248:      	add	x1, x21, #0xc
   1724c:      	mov	w2, #0x8                // =8
   17250:      	add	x0, x8, #0x48
   17254:      	bl	0x1d8c0 <strncmp@plt>
   17258:      	cbnz	w0, 0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   1725c:      	b	0x17270 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe25c>
   17260:      	ldr	q0, [x22]
   17264:      	ldr	w8, [x22, #0x10]
   17268:      	str	q0, [x27]
   1726c:      	stur	w8, [x29, #-0x30]
   17270:      	ldr	w8, [sp, #0x90]
   17274:      	cbz	w8, 0x172c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe2b0>
   17278:      	ldur	w9, [x29, #-0x3c]
   1727c:      	cbz	w9, 0x172b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe2a0>
   17280:      	cmp	w8, w9
   17284:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   17288:      	ldr	w8, [sp, #0x94]
   1728c:      	ldur	w9, [x29, #-0x38]
   17290:      	cmp	w8, w9
   17294:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   17298:      	add	x8, sp, #0x3c
   1729c:      	add	x1, x21, #0xc
   172a0:      	mov	w2, #0x8                // =8
   172a4:      	add	x0, x8, #0x5c
   172a8:      	bl	0x1d8c0 <strncmp@plt>
   172ac:      	cbnz	w0, 0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   172b0:      	b	0x172c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe2b0>
   172b4:      	ldr	q0, [x24]
   172b8:      	ldr	w8, [x24, #0x10]
   172bc:      	str	q0, [x27]
   172c0:      	stur	w8, [x29, #-0x30]
   172c4:      	ldr	w8, [sp, #0xa4]
   172c8:      	cbz	w8, 0x1731c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe308>
   172cc:      	ldur	w9, [x29, #-0x3c]
   172d0:      	cbz	w9, 0x17308 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe2f4>
   172d4:      	cmp	w8, w9
   172d8:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   172dc:      	ldr	w8, [sp, #0xa8]
   172e0:      	ldur	w9, [x29, #-0x38]
   172e4:      	cmp	w8, w9
   172e8:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   172ec:      	add	x8, sp, #0x3c
   172f0:      	add	x1, x21, #0xc
   172f4:      	mov	w2, #0x8                // =8
   172f8:      	add	x0, x8, #0x70
   172fc:      	bl	0x1d8c0 <strncmp@plt>
   17300:      	cbnz	w0, 0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   17304:      	b	0x1731c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe308>
   17308:      	ldr	x8, [sp, #0x28]
   1730c:      	ldr	q0, [x8]
   17310:      	ldr	w8, [x8, #0x10]
   17314:      	str	q0, [x27]
   17318:      	stur	w8, [x29, #-0x30]
   1731c:      	ldr	w8, [sp, #0xb8]
   17320:      	cbz	w8, 0x17370 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe35c>
   17324:      	ldur	w9, [x29, #-0x3c]
   17328:      	cbz	w9, 0x17360 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe34c>
   1732c:      	cmp	w8, w9
   17330:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   17334:      	ldr	w8, [sp, #0xbc]
   17338:      	ldur	w9, [x29, #-0x38]
   1733c:      	cmp	w8, w9
   17340:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   17344:      	add	x8, sp, #0x3c
   17348:      	add	x1, x21, #0xc
   1734c:      	mov	w2, #0x8                // =8
   17350:      	add	x0, x8, #0x84
   17354:      	bl	0x1d8c0 <strncmp@plt>
   17358:      	cbnz	w0, 0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   1735c:      	b	0x17370 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe35c>
   17360:      	ldr	q0, [x23]
   17364:      	ldr	w8, [x23, #0x10]
   17368:      	str	q0, [x27]
   1736c:      	stur	w8, [x29, #-0x30]
   17370:      	ldr	w8, [sp, #0xcc]
   17374:      	cbz	w8, 0x173c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3b4>
   17378:      	ldur	w9, [x29, #-0x3c]
   1737c:      	cbz	w9, 0x173b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3a0>
   17380:      	cmp	w8, w9
   17384:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   17388:      	ldr	w8, [sp, #0xd0]
   1738c:      	ldur	w9, [x29, #-0x38]
   17390:      	cmp	w8, w9
   17394:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   17398:      	add	x8, sp, #0x3c
   1739c:      	add	x1, x21, #0xc
   173a0:      	mov	w2, #0x8                // =8
   173a4:      	add	x0, x8, #0x98
   173a8:      	bl	0x1d8c0 <strncmp@plt>
   173ac:      	cbnz	w0, 0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   173b0:      	b	0x173c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3b4>
   173b4:      	ldr	x8, [sp, #0x20]
   173b8:      	ldr	q0, [x8]
   173bc:      	ldr	w8, [x8, #0x10]
   173c0:      	str	q0, [x27]
   173c4:      	stur	w8, [x29, #-0x30]
   173c8:      	ldr	w8, [sp, #0xe0]
   173cc:      	cbz	w8, 0x16c88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc74>
   173d0:      	ldur	w9, [x29, #-0x3c]
   173d4:      	cbz	w9, 0x17604 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe5f0>
   173d8:      	cmp	w8, w9
   173dc:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   173e0:      	ldr	w8, [sp, #0xe4]
   173e4:      	ldur	w9, [x29, #-0x38]
   173e8:      	cmp	w8, w9
   173ec:      	b.ne	0x17408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe3f4>
   173f0:      	add	x8, sp, #0x3c
   173f4:      	add	x1, x21, #0xc
   173f8:      	mov	w2, #0x8                // =8
   173fc:      	add	x0, x8, #0xac
   17400:      	bl	0x1d8c0 <strncmp@plt>
   17404:      	cbz	w0, 0x16c88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc74>
   17408:      	cmp	w25, #0x6
   1740c:      	b.gt	0x1747c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe468>
   17410:      	cmp	w25, #0x2
   17414:      	b.gt	0x174b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe49c>
   17418:      	cmp	w25, #0x1
   1741c:      	b.eq	0x17528 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe514>
   17420:      	cmp	w25, #0x2
   17424:      	b.ne	0x175e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe5d4>
   17428:      	ldr	w8, [sp, #0xa4]
   1742c:      	ldr	x10, [sp, #0x28]
   17430:      	orr	w9, w8, w20
   17434:      	cmp	w8, #0x0
   17438:      	add	x8, sp, #0x3c
   1743c:      	csel	x23, x8, x10, eq
   17440:      	cbnz	w9, 0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   17444:      	ldr	w8, [sp, #0x54]
   17448:      	ldr	x23, [sp, #0x30]
   1744c:      	cbnz	w8, 0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   17450:      	ldr	w8, [sp, #0x68]
   17454:      	ldr	x23, [sp, #0x8]
   17458:      	cbnz	w8, 0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   1745c:      	ldr	w8, [sp, #0xcc]
   17460:      	ldr	x23, [sp, #0x20]
   17464:      	cbnz	w8, 0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   17468:      	ldr	w8, [sp, #0xe0]
   1746c:      	cmp	w8, #0x0
   17470:      	ldr	x8, [sp, #0x18]
   17474:      	csel	x23, x22, x8, eq
   17478:      	b	0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   1747c:      	cmp	w25, #0x10
   17480:      	b.gt	0x174e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe4d0>
   17484:      	cmp	w25, #0x7
   17488:      	b.eq	0x1755c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe548>
   1748c:      	cmp	w25, #0xb
   17490:      	b.ne	0x175e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe5d4>
   17494:      	ldr	w8, [sp, #0x54]
   17498:      	ldr	x10, [sp, #0x30]
   1749c:      	ldr	w9, [sp, #0xa4]
   174a0:      	cmp	w8, #0x0
   174a4:      	add	x8, sp, #0x3c
   174a8:      	csel	x8, x8, x10, eq
   174ac:      	b	0x17518 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe504>
   174b0:      	cmp	w25, #0x3
   174b4:      	b.eq	0x17570 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe55c>
   174b8:      	cmp	w25, #0x4
   174bc:      	b.ne	0x175e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe5d4>
   174c0:      	ldr	w8, [sp, #0x54]
   174c4:      	ldr	x9, [sp, #0x30]
   174c8:      	cmp	w8, #0x0
   174cc:      	ldr	x8, [sp, #0x8]
   174d0:      	csel	x8, x8, x9, eq
   174d4:      	cmp	w20, #0x0
   174d8:      	add	x9, sp, #0x3c
   174dc:      	csel	x23, x8, x9, eq
   174e0:      	b	0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   174e4:      	cmp	w25, #0x11
   174e8:      	b.eq	0x175c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe5b0>
   174ec:      	cmp	w25, #0x12
   174f0:      	b.ne	0x175e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe5d4>
   174f4:      	ldr	w8, [sp, #0x54]
   174f8:      	ldr	x11, [sp, #0x8]
   174fc:      	cmp	w20, #0x0
   17500:      	add	x10, sp, #0x3c
   17504:      	ldr	w9, [sp, #0xa4]
   17508:      	csel	x10, x11, x10, eq
   1750c:      	cmp	w8, #0x0
   17510:      	ldr	x8, [sp, #0x30]
   17514:      	csel	x8, x10, x8, eq
   17518:      	cmp	w9, #0x0
   1751c:      	ldr	x9, [sp, #0x28]
   17520:      	csel	x23, x8, x9, eq
   17524:      	b	0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   17528:      	ldr	w8, [sp, #0xb8]
   1752c:      	cbnz	w8, 0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   17530:      	ldr	w8, [sp, #0xa4]
   17534:      	ldr	x10, [sp, #0x28]
   17538:      	orr	w9, w8, w20
   1753c:      	cmp	w8, #0x0
   17540:      	add	x8, sp, #0x3c
   17544:      	csel	x23, x8, x10, eq
   17548:      	cbnz	w9, 0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   1754c:      	ldr	w8, [sp, #0x54]
   17550:      	ldr	x23, [sp, #0x30]
   17554:      	cbnz	w8, 0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   17558:      	b	0x175a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe58c>
   1755c:      	ldr	x9, [sp, #0x8]
   17560:      	cmp	w20, #0x0
   17564:      	add	x8, sp, #0x3c
   17568:      	csel	x23, x9, x8, eq
   1756c:      	b	0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   17570:      	ldr	w8, [sp, #0x54]
   17574:      	ldr	x23, [sp, #0x30]
   17578:      	cbnz	w8, 0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   1757c:      	ldr	w8, [sp, #0x68]
   17580:      	ldr	x23, [sp, #0x8]
   17584:      	cbnz	w8, 0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   17588:      	ldr	w8, [sp, #0x90]
   1758c:      	mov	x23, x24
   17590:      	cbnz	w8, 0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   17594:      	ldr	w8, [sp, #0xa4]
   17598:      	ldr	x23, [sp, #0x28]
   1759c:      	cbnz	w8, 0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   175a0:      	ldr	w8, [sp, #0xcc]
   175a4:      	ldr	x23, [sp, #0x20]
   175a8:      	cbnz	w8, 0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   175ac:      	ldr	w8, [sp, #0xe0]
   175b0:      	ldr	x9, [sp, #0x18]
   175b4:      	cmp	w8, #0x0
   175b8:      	ldr	x8, [sp, #0x8]
   175bc:      	csel	x23, x8, x9, eq
   175c0:      	b	0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   175c4:      	ldr	w8, [sp, #0x54]
   175c8:      	ldr	x10, [sp, #0x8]
   175cc:      	cmp	w20, #0x0
   175d0:      	add	x9, sp, #0x3c
   175d4:      	csel	x9, x10, x9, eq
   175d8:      	cmp	w8, #0x0
   175dc:      	ldr	x8, [sp, #0x30]
   175e0:      	csel	x23, x9, x8, eq
   175e4:      	b	0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   175e8:      	adrp	x0, 0x4000
   175ec:      	add	x0, x0, #0x99
   175f0:      	bl	0x17620 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe60c>
   175f4:      	stp	xzr, xzr, [x27]
   175f8:      	sub	x23, x29, #0x40
   175fc:      	stur	wzr, [x29, #-0x30]
   17600:      	b	0x16c8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc78>
   17604:      	ldr	x8, [sp, #0x18]
   17608:      	ldr	q0, [x8]
   1760c:      	ldr	w8, [x8, #0x10]
   17610:      	str	q0, [x27]
   17614:      	stur	w8, [x29, #-0x30]
   17618:      	b	0x16c88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xdc74>
   1761c:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   17620:      	sub	sp, sp, #0x130
   17624:      	stp	x29, x30, [sp, #0x110]
   17628:      	stp	x28, x19, [sp, #0x120]
   1762c:      	add	x29, sp, #0x110
   17630:      	stp	x1, x2, [sp, #0x88]
   17634:      	add	x9, sp, #0x88
   17638:      	mov	x10, sp
   1763c:      	stp	x3, x4, [sp, #0x98]
   17640:      	add	x10, x10, #0x80
   17644:      	sub	x1, x29, #0x50
   17648:      	stp	x5, x6, [sp, #0xa8]
   1764c:      	str	x7, [sp, #0xb8]
   17650:      	stp	q0, q1, [sp]
   17654:      	stp	q2, q3, [sp, #0x20]
   17658:      	stp	q4, q5, [sp, #0x40]
   1765c:      	stp	q6, q7, [sp, #0x60]
   17660:      	mrs	x19, TPIDR_EL0
   17664:      	ldr	x8, [x19, #0x28]
   17668:      	stur	x8, [x29, #-0x8]
   1766c:      	add	x8, x9, #0x38
   17670:      	add	x9, x29, #0x20
   17674:      	stp	x9, x8, [x29, #-0x28]
   17678:      	mov	x8, #-0x38              // =-56
   1767c:      	sub	x9, x29, #0x28
   17680:      	movk	x8, #0xff80, lsl #32
   17684:      	stp	x10, x8, [x29, #-0x18]
   17688:      	ldp	q0, q1, [x9]
   1768c:      	stp	q0, q1, [x29, #-0x50]
   17690:      	bl	0xe6c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x56ac>
   17694:      	ldr	x8, [x19, #0x28]
   17698:      	ldur	x9, [x29, #-0x8]
   1769c:      	cmp	x8, x9
   176a0:      	b.ne	0x176b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe6a0>
   176a4:      	ldp	x28, x19, [sp, #0x120]
   176a8:      	ldp	x29, x30, [sp, #0x110]
   176ac:      	add	sp, sp, #0x130
   176b0:      	ret
   176b4:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   176b8:      	sub	sp, sp, #0x120
   176bc:      	stp	x29, x30, [sp, #0x100]
   176c0:      	stp	x28, x19, [sp, #0x110]
   176c4:      	add	x29, sp, #0x100
   176c8:      	stp	x3, x4, [x29, #-0x78]
   176cc:      	sub	x9, x29, #0x78
   176d0:      	mov	x10, sp
   176d4:      	stp	x5, x6, [x29, #-0x68]
   176d8:      	add	x10, x10, #0x80
   176dc:      	mov	x2, x1
   176e0:      	stur	x7, [x29, #-0x58]
   176e4:      	adrp	x3, 0x3000
   176e8:      	add	x3, x3, #0x7aa
   176ec:      	stp	q0, q1, [sp]
   176f0:      	sub	x4, x29, #0x50
   176f4:      	mov	w1, wzr
   176f8:      	stp	q2, q3, [sp, #0x20]
   176fc:      	stp	q4, q5, [sp, #0x40]
   17700:      	stp	q6, q7, [sp, #0x60]
   17704:      	mrs	x19, TPIDR_EL0
   17708:      	ldr	x8, [x19, #0x28]
   1770c:      	stur	x8, [x29, #-0x8]
   17710:      	add	x8, x9, #0x28
   17714:      	add	x9, x29, #0x20
   17718:      	stp	x9, x8, [x29, #-0x28]
   1771c:      	mov	x8, #-0x28              // =-40
   17720:      	sub	x9, x29, #0x28
   17724:      	movk	x8, #0xff80, lsl #32
   17728:      	stp	x10, x8, [x29, #-0x18]
   1772c:      	ldp	q0, q1, [x9]
   17730:      	stp	q0, q1, [x29, #-0x50]
   17734:      	bl	0x1d750 <__vsprintf_chk@plt>
   17738:      	ldr	x8, [x19, #0x28]
   1773c:      	ldur	x9, [x29, #-0x8]
   17740:      	cmp	x8, x9
   17744:      	b.ne	0x17758 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe744>
   17748:      	ldp	x28, x19, [sp, #0x110]
   1774c:      	ldp	x29, x30, [sp, #0x100]
   17750:      	add	sp, sp, #0x120
   17754:      	ret
   17758:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   1775c:      	sub	sp, sp, #0xb0
   17760:      	stp	x29, x30, [sp, #0x90]
   17764:      	str	x19, [sp, #0xa0]
   17768:      	add	x29, sp, #0x90
   1776c:      	movi	v0.2d, #0000000000000000
   17770:      	mrs	x19, TPIDR_EL0
   17774:      	adrp	x0, 0x2000
   17778:      	add	x0, x0, #0xccc
   1777c:      	ldr	x8, [x19, #0x28]
   17780:      	mov	x1, sp
   17784:      	stur	x8, [x29, #-0x8]
   17788:      	stp	q0, q0, [sp]
   1778c:      	stp	q0, q0, [sp, #0x20]
   17790:      	stp	q0, q0, [sp, #0x40]
   17794:      	stp	q0, q0, [sp, #0x60]
   17798:      	bl	0x1d7f0 <__system_property_get@plt>
   1779c:      	cmp	w0, #0x1
   177a0:      	mov	w0, wzr
   177a4:      	b.lt	0x177d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe7c0>
   177a8:      	ldrb	w8, [sp]
   177ac:      	cbz	w8, 0x177d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe7c0>
   177b0:      	mov	x0, sp
   177b4:      	sub	w8, w8, #0x3a
   177b8:      	cmn	w8, #0xb
   177bc:      	b.hi	0x177d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe7bc>
   177c0:      	ldrb	w8, [x0, #0x1]!
   177c4:      	cbnz	w8, 0x177b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe7a0>
   177c8:      	mov	w0, wzr
   177cc:      	b	0x177d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe7c0>
   177d0:      	bl	0x1d7a0 <atoi@plt>
   177d4:      	ldr	x8, [x19, #0x28]
   177d8:      	ldur	x9, [x29, #-0x8]
   177dc:      	cmp	x8, x9
   177e0:      	b.ne	0x177f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe7e0>
   177e4:      	ldp	x29, x30, [sp, #0x90]
   177e8:      	ldr	x19, [sp, #0xa0]
   177ec:      	add	sp, sp, #0xb0
   177f0:      	ret
   177f4:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   177f8:      	sub	sp, sp, #0x70
   177fc:      	stp	x29, x30, [sp, #0x20]
   17800:      	str	x25, [sp, #0x30]
   17804:      	stp	x24, x23, [sp, #0x40]
   17808:      	stp	x22, x21, [sp, #0x50]
   1780c:      	stp	x20, x19, [sp, #0x60]
   17810:      	add	x29, sp, #0x20
   17814:      	mrs	x24, TPIDR_EL0
   17818:      	ldr	x8, [x24, #0x28]
   1781c:      	stur	x8, [x29, #-0x8]
   17820:      	cbz	w1, 0x179d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe9c4>
   17824:      	mov	x20, x3
   17828:      	mov	w4, w2
   1782c:      	mov	x8, xzr
   17830:      	mov	w21, wzr
   17834:      	mov	w19, wzr
   17838:      	mov	w25, w1
   1783c:      	add	x9, x3, #0x34
   17840:      	mov	w10, #0xa0000           // =655360
   17844:      	add	x11, sp, #0xc
   17848:      	mov	w12, #0x38              // =56
   1784c:      	mov	w13, #0x3f0000          // =4128768
   17850:      	mov	w22, w1
   17854:      	mov	w23, w1
   17858:      	b	0x17870 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe85c>
   1785c:      	add	w19, w19, #0x1
   17860:      	add	x8, x8, #0x1
   17864:      	add	x9, x9, #0x38
   17868:      	cmp	x25, x8
   1786c:      	b.eq	0x178fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe8e8>
   17870:      	ldr	w17, [x9]
   17874:      	tbz	w17, #0xc, 0x17860 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe84c>
   17878:      	tst	w17, #0x200000
   1787c:      	and	w15, w17, w10
   17880:      	ldur	w14, [x9, #-0x14]
   17884:      	csel	w23, w23, w8, eq
   17888:      	cmp	w15, #0xa0, lsl #12     // =0xa0000
   1788c:      	csel	w22, w8, w22, eq
   17890:      	cinc	w21, w21, eq
   17894:      	cmp	x8, x14
   17898:      	b.ne	0x178ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe898>
   1789c:      	cmp	w19, #0x2
   178a0:      	b.hi	0x1785c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe848>
   178a4:      	str	w8, [x11, w19, uxtw #2]
   178a8:      	b	0x1785c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe848>
   178ac:      	umaddl	x15, w14, w12, x20
   178b0:      	ldr	w16, [x15, #0x34]!
   178b4:      	bic	w17, w17, w16
   178b8:      	tbz	w17, #0x2, 0x178d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe8bc>
   178bc:      	umaddl	x17, w14, w12, x20
   178c0:      	ldur	w2, [x9, #-0xc]
   178c4:      	orr	w16, w16, #0x4
   178c8:      	str	w16, [x15]
   178cc:      	str	w2, [x17, #0x28]
   178d0:      	bics	wzr, w13, w16
   178d4:      	b.eq	0x17860 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe84c>
   178d8:      	ldr	w17, [x9]
   178dc:      	bics	wzr, w13, w17
   178e0:      	b.ne	0x17860 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe84c>
   178e4:      	umaddl	x14, w14, w12, x20
   178e8:      	ldur	w17, [x9, #-0x28]
   178ec:      	orr	w16, w16, #0x3f0000
   178f0:      	str	w16, [x15]
   178f4:      	str	w17, [x14, #0xc]
   178f8:      	b	0x17860 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe84c>
   178fc:      	cmp	w21, #0x1
   17900:      	b.ne	0x17984 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe970>
   17904:      	cmp	w23, w22
   17908:      	b.ne	0x17984 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe970>
   1790c:      	cmp	w19, #0x2
   17910:      	b.lo	0x17984 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe970>
   17914:      	mov	w21, w1
   17918:      	add	x3, sp, #0xc
   1791c:      	mov	w2, w19
   17920:      	ldp	w8, w1, [x0, #0x4]
   17924:      	mov	x5, x20
   17928:      	mov	w6, wzr
   1792c:      	mov	w0, w8
   17930:      	bl	0x17b18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xeb04>
   17934:      	tbnz	w0, #0x0, 0x17ae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xead0>
   17938:      	add	x3, sp, #0xc
   1793c:      	mov	w0, w19
   17940:      	mov	w1, #0x1                // =1
   17944:      	mov	w2, w23
   17948:      	mov	x4, x20
   1794c:      	mov	w5, wzr
   17950:      	bl	0x17e4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xee38>
   17954:      	cbz	w21, 0x17ae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xead0>
   17958:      	tbnz	w0, #0x0, 0x17ae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xead0>
   1795c:      	mov	w9, #0x38               // =56
   17960:      	mov	x8, xzr
   17964:      	mov	w11, #0x3f0000          // =4128768
   17968:      	umaddl	x10, w23, w9, x20
   1796c:      	ldr	w10, [x10, #0x20]
   17970:      	nop
   17974:      	umaddl	x9, w10, w9, x20
   17978:      	add	x10, x20, #0x34
   1797c:      	ldr	w9, [x9, #0xc]
   17980:      	b	0x179fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe9e8>
   17984:      	cmp	w21, w4
   17988:      	b.hs	0x17ae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xead0>
   1798c:      	cbz	w1, 0x17a20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xea0c>
   17990:      	add	x12, x20, #0x34
   17994:      	mov	w10, #0x1000            // =4096
   17998:      	mov	x9, xzr
   1799c:      	mov	w8, wzr
   179a0:      	movk	w10, #0x3f, lsl #16
   179a4:      	mov	x11, x12
   179a8:      	b	0x179bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe9a8>
   179ac:      	add	x9, x9, #0x1
   179b0:      	mov	x12, x11
   179b4:      	cmp	x25, x9
   179b8:      	b.eq	0x17a24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xea10>
   179bc:      	ldr	w13, [x11], #0x38
   179c0:      	bics	wzr, w10, w13
   179c4:      	b.ne	0x179ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe998>
   179c8:      	ldur	w12, [x12, #-0x14]
   179cc:      	cmp	x9, x12
   179d0:      	cinc	w8, w8, eq
   179d4:      	b	0x179ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe998>
   179d8:      	mov	w19, wzr
   179dc:      	b	0x17ae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xead0>
   179e0:      	orr	w12, w12, #0x3f0000
   179e4:      	stur	w9, [x10, #-0x28]
   179e8:      	str	w12, [x10]
   179ec:      	add	x8, x8, #0x1
   179f0:      	add	x10, x10, #0x38
   179f4:      	cmp	x25, x8
   179f8:      	b.eq	0x17ae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xead0>
   179fc:      	ldr	w12, [x10]
   17a00:      	tbz	w12, #0xc, 0x179ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe9d8>
   17a04:      	ldur	w13, [x10, #-0x14]
   17a08:      	cmp	x8, x13
   17a0c:      	b.ne	0x179ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe9d8>
   17a10:      	bics	wzr, w11, w12
   17a14:      	b.ne	0x179e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe9cc>
   17a18:      	ldur	w9, [x10, #-0x28]
   17a1c:      	b	0x179ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xe9d8>
   17a20:      	mov	w8, wzr
   17a24:      	cmp	w8, w19
   17a28:      	b.hs	0x17ae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xead0>
   17a2c:      	mov	w23, w1
   17a30:      	add	x3, sp, #0xc
   17a34:      	mov	w2, w19
   17a38:      	ldp	w8, w1, [x0, #0x4]
   17a3c:      	mov	x5, x20
   17a40:      	mov	w6, #0x1                // =1
   17a44:      	mov	w0, w8
   17a48:      	bl	0x17b18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xeb04>
   17a4c:      	tbnz	w0, #0x0, 0x17ae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xead0>
   17a50:      	cmp	w22, w25
   17a54:      	b.eq	0x17ae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xead0>
   17a58:      	add	x3, sp, #0xc
   17a5c:      	mov	w0, w19
   17a60:      	mov	w1, w21
   17a64:      	mov	w2, w22
   17a68:      	mov	x4, x20
   17a6c:      	mov	w5, #0x1                // =1
   17a70:      	bl	0x17e4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xee38>
   17a74:      	cbz	w23, 0x17ae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xead0>
   17a78:      	tbnz	w0, #0x0, 0x17ae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xead0>
   17a7c:      	mov	w9, #0x38               // =56
   17a80:      	mov	x8, xzr
   17a84:      	mov	w11, #0x3f0000          // =4128768
   17a88:      	umaddl	x10, w22, w9, x20
   17a8c:      	ldr	w10, [x10, #0x20]
   17a90:      	nop
   17a94:      	umaddl	x9, w10, w9, x20
   17a98:      	add	x10, x20, #0x34
   17a9c:      	ldr	w9, [x9, #0xc]
   17aa0:      	b	0x17ac0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xeaac>
   17aa4:      	orr	w12, w12, #0x3f0000
   17aa8:      	stur	w9, [x10, #-0x28]
   17aac:      	str	w12, [x10]
   17ab0:      	add	x8, x8, #0x1
   17ab4:      	add	x10, x10, #0x38
   17ab8:      	cmp	x25, x8
   17abc:      	b.eq	0x17ae4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xead0>
   17ac0:      	ldr	w12, [x10]
   17ac4:      	tbz	w12, #0xc, 0x17ab0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xea9c>
   17ac8:      	ldur	w13, [x10, #-0x14]
   17acc:      	cmp	x8, x13
   17ad0:      	b.ne	0x17ab0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xea9c>
   17ad4:      	bics	wzr, w11, w12
   17ad8:      	b.ne	0x17aa4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xea90>
   17adc:      	ldur	w9, [x10, #-0x28]
   17ae0:      	b	0x17ab0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xea9c>
   17ae4:      	ldr	x8, [x24, #0x28]
   17ae8:      	ldur	x9, [x29, #-0x8]
   17aec:      	cmp	x8, x9
   17af0:      	b.ne	0x17b14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xeb00>
   17af4:      	mov	w0, w19
   17af8:      	ldp	x20, x19, [sp, #0x60]
   17afc:      	ldr	x25, [sp, #0x30]
   17b00:      	ldp	x22, x21, [sp, #0x50]
   17b04:      	ldp	x24, x23, [sp, #0x40]
   17b08:      	ldp	x29, x30, [sp, #0x20]
   17b0c:      	add	sp, sp, #0x70
   17b10:      	ret
   17b14:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   17b18:      	cmp	w2, #0x3
   17b1c:      	b.hi	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17b20:      	mov	w9, #0x1fec             // =8172
   17b24:      	mov	w8, w0
   17b28:      	mov	w0, wzr
   17b2c:      	cmp	w1, w9
   17b30:      	b.le	0x17b74 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xeb60>
   17b34:      	mov	w9, #0x22fb             // =8955
   17b38:      	cmp	w1, w9
   17b3c:      	b.gt	0x17bb4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xeba0>
   17b40:      	mov	w9, #0x221e             // =8734
   17b44:      	cmp	w1, w9
   17b48:      	b.gt	0x17c38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xec24>
   17b4c:      	mov	w9, #0x1fed             // =8173
   17b50:      	cmp	w1, w9
   17b54:      	b.eq	0x17cb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xeca4>
   17b58:      	mov	w9, #0x1ff0             // =8176
   17b5c:      	cmp	w1, w9
   17b60:      	b.ne	0x17dfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede8>
   17b64:      	cmp	w8, #0x5
   17b68:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17b6c:      	mov	w8, #0xa                // =10
   17b70:      	b	0x17d04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecf0>
   17b74:      	mov	w9, #0x1538             // =5432
   17b78:      	cmp	w1, w9
   17b7c:      	b.le	0x17be8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xebd4>
   17b80:      	mov	w9, #0x1a8e             // =6798
   17b84:      	cmp	w1, w9
   17b88:      	b.gt	0x17c10 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xebfc>
   17b8c:      	mov	w9, #0x1539             // =5433
   17b90:      	cmp	w1, w9
   17b94:      	b.eq	0x17c88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xec74>
   17b98:      	mov	w9, #0x1a8d             // =6797
   17b9c:      	cmp	w1, w9
   17ba0:      	b.ne	0x17dfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede8>
   17ba4:      	cmp	w8, #0x5
   17ba8:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17bac:      	mov	w8, #0xc                // =12
   17bb0:      	b	0x17d04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecf0>
   17bb4:      	mov	w9, #0x231f             // =8991
   17bb8:      	cmp	w1, w9
   17bbc:      	b.gt	0x17c60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xec4c>
   17bc0:      	mov	w9, #0x22fc             // =8956
   17bc4:      	cmp	w1, w9
   17bc8:      	b.eq	0x17cc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecb4>
   17bcc:      	mov	w9, #0x2310             // =8976
   17bd0:      	cmp	w1, w9
   17bd4:      	b.ne	0x17dfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede8>
   17bd8:      	cmp	w8, #0x2
   17bdc:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17be0:      	mov	w8, #0x1                // =1
   17be4:      	b	0x17d04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecf0>
   17be8:      	cmp	w1, #0x3b6
   17bec:      	b.eq	0x17cf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xece4>
   17bf0:      	cmp	w1, #0x3bb
   17bf4:      	b.eq	0x17ca8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xec94>
   17bf8:      	cmp	w1, #0xd47
   17bfc:      	b.ne	0x17dfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede8>
   17c00:      	cmp	w8, #0x1a
   17c04:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17c08:      	mov	w8, #0xe                // =14
   17c0c:      	b	0x17d04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecf0>
   17c10:      	mov	w9, #0x1a8f             // =6799
   17c14:      	cmp	w1, w9
   17c18:      	b.eq	0x17c98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xec84>
   17c1c:      	mov	w9, #0x1cfc             // =7420
   17c20:      	cmp	w1, w9
   17c24:      	b.ne	0x17dfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede8>
   17c28:      	cmp	w8, #0x6
   17c2c:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17c30:      	mov	w8, #0x5                // =5
   17c34:      	b	0x17d04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecf0>
   17c38:      	mov	w9, #0x221f             // =8735
   17c3c:      	cmp	w1, w9
   17c40:      	b.eq	0x17cd8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecc4>
   17c44:      	mov	w9, #0x22ba             // =8890
   17c48:      	cmp	w1, w9
   17c4c:      	b.ne	0x17dfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede8>
   17c50:      	cmp	w8, #0x6
   17c54:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17c58:      	mov	w8, #0x6                // =6
   17c5c:      	b	0x17d04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecf0>
   17c60:      	mov	w9, #0x2320             // =8992
   17c64:      	cmp	w1, w9
   17c68:      	b.eq	0x17ce8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecd4>
   17c6c:      	mov	w9, #0x2322             // =8994
   17c70:      	cmp	w1, w9
   17c74:      	b.ne	0x17dfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede8>
   17c78:      	cmp	w8, #0x2
   17c7c:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17c80:      	mov	w8, #0x3                // =3
   17c84:      	b	0x17d04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecf0>
   17c88:      	cmp	w8, #0x6
   17c8c:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17c90:      	mov	w8, #0x4                // =4
   17c94:      	b	0x17d04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecf0>
   17c98:      	cmp	w8, #0x5
   17c9c:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17ca0:      	mov	w8, #0xd                // =13
   17ca4:      	b	0x17d04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecf0>
   17ca8:      	cmp	w8, #0xa
   17cac:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17cb0:      	mov	w8, #0x8                // =8
   17cb4:      	b	0x17d04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecf0>
   17cb8:      	cmp	w8, #0x5
   17cbc:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17cc0:      	mov	w8, #0x9                // =9
   17cc4:      	b	0x17d04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecf0>
   17cc8:      	cmp	w8, #0x2
   17ccc:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17cd0:      	mov	x8, xzr
   17cd4:      	b	0x17d04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecf0>
   17cd8:      	cmp	w8, #0x5
   17cdc:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17ce0:      	mov	w8, #0xb                // =11
   17ce4:      	b	0x17d04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecf0>
   17ce8:      	cmp	w8, #0x2
   17cec:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17cf0:      	mov	w8, #0x2                // =2
   17cf4:      	b	0x17d04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xecf0>
   17cf8:      	cmp	w8, #0xa
   17cfc:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17d00:      	mov	w8, #0x7                // =7
   17d04:      	mov	w9, #0x14               // =20
   17d08:      	nop
   17d0c:      	adr	x10, 0x53f8
   17d10:      	umull	x9, w8, w9
   17d14:      	ldrb	w9, [x10, x9]
   17d18:      	cmp	w9, w4
   17d1c:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17d20:      	mov	w9, #0x14               // =20
   17d24:      	umaddl	x9, w8, w9, x10
   17d28:      	ldrb	w9, [x9, #0x4]
   17d2c:      	cmp	w9, w2
   17d30:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17d34:      	cbz	w2, 0x17e44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xee30>
   17d38:      	mov	w9, #0x14               // =20
   17d3c:      	mov	w12, #0x38              // =56
   17d40:      	mov	x14, x3
   17d44:      	umaddl	x11, w8, w9, x10
   17d48:      	mov	w9, w2
   17d4c:      	mov	x13, x9
   17d50:      	add	x11, x11, #0x5
   17d54:      	ldr	w15, [x14], #0x4
   17d58:      	ldrb	w16, [x11], #0x1
   17d5c:      	nop
   17d60:      	umaddl	x15, w15, w12, x5
   17d64:      	ldr	w15, [x15, #0x24]
   17d68:      	cmp	w15, w16
   17d6c:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17d70:      	subs	x13, x13, #0x1
   17d74:      	b.ne	0x17d54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xed40>
   17d78:      	tbz	w6, #0x0, 0x17e00 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xedec>
   17d7c:      	mov	w11, #0x14              // =20
   17d80:      	mov	w12, #0x38              // =56
   17d84:      	mov	x13, x9
   17d88:      	umaddl	x11, w8, w11, x10
   17d8c:      	mov	x14, x3
   17d90:      	add	x11, x11, #0x8
   17d94:      	ldr	w15, [x14]
   17d98:      	nop
   17d9c:      	umaddl	x16, w15, w12, x5
   17da0:      	ldr	w17, [x16, #0x34]
   17da4:      	tbz	w17, #0x11, 0x17dec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xedd8>
   17da8:      	mov	w16, #-0x1000000        // =-16777216
   17dac:      	tbz	w17, #0x12, 0x17db4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xeda0>
   17db0:      	orr	w16, w16, #0xf00000
   17db4:      	tbz	w17, #0x13, 0x17dbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xeda8>
   17db8:      	orr	w16, w16, #0xfff0
   17dbc:      	tbz	w17, #0x14, 0x17dc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xedb0>
   17dc0:      	orr	w16, w16, #0xf
   17dc4:      	umaddl	x15, w15, w12, x5
   17dc8:      	ldr	w17, [x11], #0x4
   17dcc:      	ldr	w15, [x15, #0xc]
   17dd0:      	eor	w15, w17, w15
   17dd4:      	tst	w16, w15
   17dd8:      	b.ne	0x17df8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede4>
   17ddc:      	subs	x13, x13, #0x1
   17de0:      	add	x14, x14, #0x4
   17de4:      	b.ne	0x17d94 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xed80>
   17de8:      	b	0x17e00 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xedec>
   17dec:      	mov	w16, wzr
   17df0:      	tbnz	w17, #0x12, 0x17db0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xed9c>
   17df4:      	b	0x17db4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xeda0>
   17df8:      	mov	w0, wzr
   17dfc:      	ret
   17e00:      	cbz	w2, 0x17e44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xee30>
   17e04:      	mov	w11, #0x14              // =20
   17e08:      	mov	w0, #0x1                // =1
   17e0c:      	umaddl	x8, w8, w11, x10
   17e10:      	mov	w10, #0x38              // =56
   17e14:      	add	x8, x8, #0x8
   17e18:      	ldr	w11, [x3], #0x4
   17e1c:      	subs	x9, x9, #0x1
   17e20:      	ldr	w12, [x8], #0x4
   17e24:      	nop
   17e28:      	umaddl	x11, w11, w10, x5
   17e2c:      	ldr	w13, [x11, #0x34]
   17e30:      	str	w12, [x11, #0xc]
   17e34:      	orr	w12, w13, #0x3f0000
   17e38:      	str	w12, [x11, #0x34]
   17e3c:      	b.ne	0x17e18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xee04>
   17e40:      	b	0x17dfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xede8>
   17e44:      	mov	w0, #0x1                // =1
   17e48:      	ret
   17e4c:      	cmp	w0, #0x2
   17e50:      	mov	w0, wzr
   17e54:      	b.ne	0x180ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf098>
   17e58:      	cmp	w1, #0x1
   17e5c:      	b.ne	0x180ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf098>
   17e60:      	mov	w8, #0x38               // =56
   17e64:      	umaddl	x9, w2, w8, x4
   17e68:      	ldr	w9, [x9, #0x20]
   17e6c:      	nop
   17e70:      	umaddl	x12, w9, w8, x4
   17e74:      	ldr	w8, [x12, #0xc]
   17e78:      	and	w9, w8, #0xfffffff0
   17e7c:      	and	w10, w9, #0xff0fffff
   17e80:      	mov	w9, #0xd08f             // =53391
   17e84:      	movk	w9, #0x410f, lsl #16
   17e88:      	cmp	w10, w9
   17e8c:      	mov	w9, #0xc070             // =49264
   17e90:      	movk	w9, #0x410f, lsl #16
   17e94:      	b.le	0x17edc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xeec8>
   17e98:      	mov	w11, #0x2f              // =47
   17e9c:      	movk	w11, #0x4e0f, lsl #16
   17ea0:      	cmp	w10, w11
   17ea4:      	b.le	0x17f2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xef18>
   17ea8:      	mov	w11, #0x30              // =48
   17eac:      	movk	w11, #0x4e0f, lsl #16
   17eb0:      	cmp	w10, w11
   17eb4:      	b.eq	0x180b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf09c>
   17eb8:      	mov	w11, #0x2050            // =8272
   17ebc:      	movk	w11, #0x510f, lsl #16
   17ec0:      	cmp	w10, w11
   17ec4:      	b.eq	0x180b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf0a4>
   17ec8:      	mov	w11, #0x10              // =16
   17ecc:      	movk	w11, #0x530f, lsl #16
   17ed0:      	cmp	w10, w11
   17ed4:      	b.eq	0x17f54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xef40>
   17ed8:      	b	0x180c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf0b0>
   17edc:      	mov	w11, #0xd06f            // =53359
   17ee0:      	movk	w11, #0x410f, lsl #16
   17ee4:      	cmp	w10, w11
   17ee8:      	b.gt	0x17f0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xeef8>
   17eec:      	mov	w11, #0xc0e0            // =49376
   17ef0:      	movk	w11, #0x410f, lsl #16
   17ef4:      	cmp	w10, w11
   17ef8:      	mov	w11, #0xc0f0            // =49392
   17efc:      	movk	w11, #0x410f, lsl #16
   17f00:      	ccmp	w10, w11, #0x4, ne
   17f04:      	b.eq	0x17f58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xef44>
   17f08:      	b	0x180c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf0b0>
   17f0c:      	mov	w11, #0xd070            // =53360
   17f10:      	movk	w11, #0x410f, lsl #16
   17f14:      	cmp	w10, w11
   17f18:      	mov	w11, #0xd080            // =53376
   17f1c:      	movk	w11, #0x410f, lsl #16
   17f20:      	ccmp	w10, w11, #0x4, ne
   17f24:      	b.eq	0x17f54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xef40>
   17f28:      	b	0x180c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf0b0>
   17f2c:      	mov	w11, #0xd090            // =53392
   17f30:      	movk	w11, #0x410f, lsl #16
   17f34:      	cmp	w10, w11
   17f38:      	b.eq	0x17f54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xef40>
   17f3c:      	mov	w11, #0xd0a0            // =53408
   17f40:      	movk	w11, #0x410f, lsl #16
   17f44:      	cmp	w10, w11
   17f48:      	b.ne	0x180c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf0b0>
   17f4c:      	add	w9, w9, #0xfe0
   17f50:      	b	0x17f58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xef44>
   17f54:      	add	w9, w9, #0xfc0
   17f58:      	ldp	w13, w10, [x3]
   17f5c:      	mov	w11, #0x38              // =56
   17f60:      	umaddl	x14, w13, w11, x4
   17f64:      	umaddl	x11, w10, w11, x4
   17f68:      	ldr	w17, [x14, #0x34]!
   17f6c:      	ldr	w15, [x11, #0x34]!
   17f70:      	and	w16, w17, w15
   17f74:      	tbz	w16, #0x2, 0x17fa0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xef8c>
   17f78:      	mov	w16, #0x38              // =56
   17f7c:      	umaddl	x0, w13, w16, x4
   17f80:      	umaddl	x16, w10, w16, x4
   17f84:      	ldr	w0, [x0, #0x28]
   17f88:      	ldr	w16, [x16, #0x28]
   17f8c:      	cmp	w0, w16
   17f90:      	csel	w16, w10, w13, hi
   17f94:      	ldr	w12, [x12, #0x34]
   17f98:      	tbnz	w5, #0x0, 0x17fac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xef98>
   17f9c:      	b	0x18054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf040>
   17fa0:      	mov	w16, w13
   17fa4:      	ldr	w12, [x12, #0x34]
   17fa8:      	tbz	w5, #0x0, 0x18054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf040>
   17fac:      	sbfx	w0, w17, #17, #1
   17fb0:      	tst	w17, #0x40000
   17fb4:      	and	w0, w0, #0xff000000
   17fb8:      	orr	w1, w0, #0xf00000
   17fbc:      	csel	w0, w0, w1, eq
   17fc0:      	mov	w1, #0x38               // =56
   17fc4:      	tst	w17, #0x80000
   17fc8:      	orr	w2, w0, #0xfff0
   17fcc:      	umaddl	x1, w13, w1, x4
   17fd0:      	csel	w0, w0, w2, eq
   17fd4:      	tst	w17, #0x100000
   17fd8:      	orr	w2, w0, #0xf
   17fdc:      	csel	w0, w0, w2, eq
   17fe0:      	cmp	w13, w16
   17fe4:      	ldr	w1, [x1, #0xc]
   17fe8:      	csel	w2, w9, w8, eq
   17fec:      	eor	w1, w1, w2
   17ff0:      	tst	w0, w1
   17ff4:      	b.eq	0x18000 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xefec>
   17ff8:      	mov	w0, wzr
   17ffc:      	ret
   18000:      	sbfx	w0, w15, #17, #1
   18004:      	tst	w15, #0x40000
   18008:      	and	w0, w0, #0xff000000
   1800c:      	orr	w1, w0, #0xf00000
   18010:      	csel	w0, w0, w1, eq
   18014:      	mov	w1, #0x38               // =56
   18018:      	tst	w15, #0x80000
   1801c:      	orr	w2, w0, #0xfff0
   18020:      	umaddl	x1, w10, w1, x4
   18024:      	csel	w0, w0, w2, eq
   18028:      	tst	w15, #0x100000
   1802c:      	orr	w2, w0, #0xf
   18030:      	csel	w0, w0, w2, eq
   18034:      	cmp	w10, w16
   18038:      	ldr	w1, [x1, #0xc]
   1803c:      	csel	w2, w9, w8, eq
   18040:      	eor	w1, w1, w2
   18044:      	tst	w0, w1
   18048:      	b.eq	0x18054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf040>
   1804c:      	mov	w0, wzr
   18050:      	ret
   18054:      	mov	w0, #0x3f0000           // =4128768
   18058:      	and	w12, w12, #0x3f0000
   1805c:      	bics	wzr, w0, w17
   18060:      	b.eq	0x18084 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf070>
   18064:      	mov	w15, #0x38              // =56
   18068:      	cmp	w13, w16
   1806c:      	umaddl	x1, w13, w15, x4
   18070:      	orr	w15, w17, w12
   18074:      	csel	w13, w9, w8, eq
   18078:      	str	w15, [x14]
   1807c:      	ldr	w15, [x11]
   18080:      	str	w13, [x1, #0xc]
   18084:      	bics	wzr, w0, w15
   18088:      	b.eq	0x180a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf094>
   1808c:      	mov	w13, #0x38              // =56
   18090:      	cmp	w10, w16
   18094:      	umaddl	x13, w10, w13, x4
   18098:      	csel	w8, w9, w8, eq
   1809c:      	orr	w9, w15, w12
   180a0:      	str	w9, [x11]
   180a4:      	str	w8, [x13, #0xc]
   180a8:      	mov	w0, #0x1                // =1
   180ac:      	ret
   180b0:      	add	w9, w9, #0x1, lsl #12   // =0x1000
   180b4:      	b	0x17f58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xef44>
   180b8:      	mov	w9, #0x2110             // =8464
   180bc:      	movk	w9, #0x510f, lsl #16
   180c0:      	b	0x17f58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xef44>
   180c4:      	mov	w9, w8
   180c8:      	b	0x17f58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xef44>
   180cc:      	stp	x29, x30, [sp, #-0x20]!
   180d0:      	stp	x20, x19, [sp, #0x10]
   180d4:      	mov	x29, sp
   180d8:      	mov	x20, x0
   180dc:      	mov	w0, #0x10               // =16
   180e0:      	mov	x19, x1
   180e4:      	bl	0x1d800 <getauxval@plt>
   180e8:      	str	w0, [x20]
   180ec:      	mov	w0, #0x1a               // =26
   180f0:      	bl	0x1d800 <getauxval@plt>
   180f4:      	str	w0, [x19]
   180f8:      	ldp	x20, x19, [sp, #0x10]
   180fc:      	ldp	x29, x30, [sp], #0x20
   18100:      	ret
   18104:      	tbnz	w0, #0x3, 0x18134 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf120>
   18108:      	tbnz	w0, #0x4, 0x18140 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf12c>
   1810c:      	tbnz	w0, #0x5, 0x1814c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf138>
   18110:      	tbnz	w0, #0x6, 0x18158 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf144>
   18114:      	tbnz	w0, #0x7, 0x18164 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf150>
   18118:      	tbnz	w0, #0x8, 0x18170 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf15c>
   1811c:      	ldr	w8, [x3, #0x4]
   18120:      	cmp	w8, #0x6
   18124:      	mov	w8, #0xfff0             // =65520
   18128:      	movk	w8, #0xff00, lsl #16
   1812c:      	b.eq	0x1818c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf178>
   18130:      	b	0x1819c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf188>
   18134:      	mov	w8, #0x1                // =1
   18138:      	strb	w8, [x4, #0xb]
   1813c:      	tbz	w0, #0x4, 0x1810c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf0f8>
   18140:      	mov	w8, #0x1                // =1
   18144:      	strb	w8, [x4, #0xe]
   18148:      	tbz	w0, #0x5, 0x18110 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf0fc>
   1814c:      	mov	w8, #0x1                // =1
   18150:      	strb	w8, [x4, #0xc]
   18154:      	tbz	w0, #0x6, 0x18114 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf100>
   18158:      	mov	w8, #0x1                // =1
   1815c:      	strb	w8, [x4, #0xd]
   18160:      	tbz	w0, #0x7, 0x18118 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf104>
   18164:      	mov	w8, #0x1                // =1
   18168:      	strb	w8, [x4, #0xf]
   1816c:      	tbz	w0, #0x8, 0x1811c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf108>
   18170:      	mov	w8, #0x1                // =1
   18174:      	strb	w8, [x4]
   18178:      	ldr	w8, [x3, #0x4]
   1817c:      	cmp	w8, #0x6
   18180:      	mov	w8, #0xfff0             // =65520
   18184:      	movk	w8, #0xff00, lsl #16
   18188:      	b.ne	0x1819c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf188>
   1818c:      	ldr	w9, [x3, #0x8]
   18190:      	mov	w10, #0x2652            // =9810
   18194:      	cmp	w9, w10
   18198:      	b.eq	0x182a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf294>
   1819c:      	mov	w10, #0xd48f            // =54415
   181a0:      	and	w9, w2, w8
   181a4:      	movk	w10, #0x4100, lsl #16
   181a8:      	cmp	w9, w10
   181ac:      	b.le	0x18200 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf1ec>
   181b0:      	mov	w10, #0x801f            // =32799
   181b4:      	movk	w10, #0x5100, lsl #16
   181b8:      	cmp	w9, w10
   181bc:      	b.le	0x1823c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf228>
   181c0:      	mov	w10, #0x7fe0            // =32736
   181c4:      	movk	w10, #0xaeff, lsl #16
   181c8:      	add	w10, w9, w10
   181cc:      	cmp	w10, #0x30
   181d0:      	b.hi	0x181e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf1d0>
   181d4:      	mov	w11, #0x1               // =1
   181d8:      	lsl	x10, x11, x10
   181dc:      	tst	x10, #0x1000100010001
   181e0:      	b.ne	0x18298 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf284>
   181e4:      	mov	w10, #0x40              // =64
   181e8:      	movk	w10, #0x5300, lsl #16
   181ec:      	cmp	w9, w10
   181f0:      	b.eq	0x18298 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf284>
   181f4:      	mov	w10, #0x30              // =48
   181f8:      	movk	w10, #0x5300, lsl #16
   181fc:      	b	0x18290 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf27c>
   18200:      	mov	w10, #0xd0af            // =53423
   18204:      	movk	w10, #0x4100, lsl #16
   18208:      	cmp	w9, w10
   1820c:      	b.le	0x18268 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf254>
   18210:      	mov	w10, #0x2f50            // =12112
   18214:      	movk	w10, #0xbeff, lsl #16
   18218:      	add	w10, w9, w10
   1821c:      	cmp	w10, #0x30
   18220:      	b.hi	0x18234 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf220>
   18224:      	mov	w11, #0x1               // =1
   18228:      	lsl	x10, x11, x10
   1822c:      	tst	x10, #0x1000100010001
   18230:      	b.ne	0x18298 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf284>
   18234:      	mov	w10, #0xd400            // =54272
   18238:      	b	0x1828c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf278>
   1823c:      	mov	w10, #0xd490            // =54416
   18240:      	movk	w10, #0x4100, lsl #16
   18244:      	cmp	w9, w10
   18248:      	b.eq	0x18298 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf284>
   1824c:      	mov	w10, #0xd4f0            // =54512
   18250:      	movk	w10, #0x4100, lsl #16
   18254:      	cmp	w9, w10
   18258:      	b.eq	0x18298 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf284>
   1825c:      	mov	w10, #0xd400            // =54272
   18260:      	movk	w10, #0x4800, lsl #16
   18264:      	b	0x18290 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf27c>
   18268:      	mov	w10, #0xd050            // =53328
   1826c:      	movk	w10, #0x4100, lsl #16
   18270:      	cmp	w9, w10
   18274:      	b.eq	0x18298 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf284>
   18278:      	mov	w10, #0xd060            // =53344
   1827c:      	movk	w10, #0x4100, lsl #16
   18280:      	cmp	w9, w10
   18284:      	b.eq	0x18298 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf284>
   18288:      	mov	w10, #0xd0a0            // =53408
   1828c:      	movk	w10, #0x4100, lsl #16
   18290:      	cmp	w9, w10
   18294:      	b.ne	0x18470 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf45c>
   18298:      	mov	w9, #0x1                // =1
   1829c:      	strb	w9, [x4, #0x6]
   182a0:      	mov	w9, #0x1                // =1
   182a4:      	strb	w9, [x4, #0x5]
   182a8:      	tbz	w1, #0xd, 0x182b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf2a0>
   182ac:      	mov	w9, #0x1                // =1
   182b0:      	strb	w9, [x4, #0x4]
   182b4:      	mov	w9, #0xd48f             // =54415
   182b8:      	and	w8, w2, w8
   182bc:      	movk	w9, #0x4100, lsl #16
   182c0:      	cmp	w8, w9
   182c4:      	b.gt	0x18308 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf2f4>
   182c8:      	mov	w9, #0xd0af             // =53423
   182cc:      	movk	w9, #0x4100, lsl #16
   182d0:      	cmp	w8, w9
   182d4:      	b.le	0x18370 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf35c>
   182d8:      	mov	w9, #0x2f50             // =12112
   182dc:      	movk	w9, #0xbeff, lsl #16
   182e0:      	add	w9, w8, w9
   182e4:      	cmp	w9, #0x30
   182e8:      	b.hi	0x182fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf2e8>
   182ec:      	mov	w10, #0x1               // =1
   182f0:      	lsl	x9, x10, x9
   182f4:      	tst	x9, #0x1000100010001
   182f8:      	b.ne	0x183e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3d0>
   182fc:      	mov	w9, #0xd400             // =54272
   18300:      	movk	w9, #0x4100, lsl #16
   18304:      	b	0x183dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3c8>
   18308:      	mov	w9, #0x803f             // =32831
   1830c:      	movk	w9, #0x5100, lsl #16
   18310:      	cmp	w8, w9
   18314:      	b.gt	0x18344 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf330>
   18318:      	mov	w9, #0xd4ef             // =54511
   1831c:      	movk	w9, #0x4100, lsl #16
   18320:      	cmp	w8, w9
   18324:      	b.gt	0x183a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf394>
   18328:      	mov	w9, #0xd490             // =54416
   1832c:      	movk	w9, #0x4100, lsl #16
   18330:      	cmp	w8, w9
   18334:      	b.eq	0x183e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3d0>
   18338:      	mov	w9, #0xd4a0             // =54432
   1833c:      	movk	w9, #0x4100, lsl #16
   18340:      	b	0x183dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3c8>
   18344:      	mov	w9, #0x2f               // =47
   18348:      	movk	w9, #0x5300, lsl #16
   1834c:      	cmp	w8, w9
   18350:      	b.gt	0x183c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3b0>
   18354:      	mov	w9, #0x8040             // =32832
   18358:      	movk	w9, #0x5100, lsl #16
   1835c:      	cmp	w8, w9
   18360:      	b.eq	0x183e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3d0>
   18364:      	mov	w9, #0x8050             // =32848
   18368:      	movk	w9, #0x5100, lsl #16
   1836c:      	b	0x183dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3c8>
   18370:      	mov	w9, #0xd050             // =53328
   18374:      	movk	w9, #0x4100, lsl #16
   18378:      	cmp	w8, w9
   1837c:      	b.eq	0x1845c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf448>
   18380:      	mov	w9, #0xd060             // =53344
   18384:      	movk	w9, #0x4100, lsl #16
   18388:      	cmp	w8, w9
   1838c:      	b.eq	0x183e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3d0>
   18390:      	mov	w9, #0xd0a0             // =53408
   18394:      	movk	w9, #0x4100, lsl #16
   18398:      	cmp	w8, w9
   1839c:      	b.ne	0x18468 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf454>
   183a0:      	tst	w2, #0xe00000
   183a4:      	b	0x18460 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf44c>
   183a8:      	mov	w9, #0xd4f0             // =54512
   183ac:      	movk	w9, #0x4100, lsl #16
   183b0:      	cmp	w8, w9
   183b4:      	b.eq	0x183e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3d0>
   183b8:      	mov	w9, #0xd400             // =54272
   183bc:      	movk	w9, #0x4800, lsl #16
   183c0:      	b	0x183dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3c8>
   183c4:      	mov	w9, #0x40               // =64
   183c8:      	movk	w9, #0x5300, lsl #16
   183cc:      	cmp	w8, w9
   183d0:      	b.eq	0x183e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3d0>
   183d4:      	mov	w9, #0x30               // =48
   183d8:      	movk	w9, #0x5300, lsl #16
   183dc:      	cmp	w8, w9
   183e0:      	b.ne	0x18468 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf454>
   183e4:      	mov	w8, #0x1                // =1
   183e8:      	strb	w8, [x4, #0x7]
   183ec:      	tbnz	w0, #0xd, 0x18420 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf40c>
   183f0:      	tbnz	w0, #0xe, 0x1842c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf418>
   183f4:      	tbnz	w0, #0x16, 0x18438 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf424>
   183f8:      	tbnz	w1, #0x1, 0x18444 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf430>
   183fc:      	mov	w8, #0x5000             // =20480
   18400:      	tst	w1, w8
   18404:      	b.eq	0x18410 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3fc>
   18408:      	mov	w8, #0x1                // =1
   1840c:      	strb	w8, [x4, #0x1]
   18410:      	tbz	w0, #0x17, 0x1841c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf408>
   18414:      	mov	w8, #0x1                // =1
   18418:      	strb	w8, [x4, #0xa]
   1841c:      	ret
   18420:      	mov	w8, #0x1                // =1
   18424:      	strb	w8, [x4, #0x8]
   18428:      	tbz	w0, #0xe, 0x183f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3e0>
   1842c:      	mov	w8, #0x1                // =1
   18430:      	strb	w8, [x4, #0x9]
   18434:      	tbz	w0, #0x16, 0x183f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3e4>
   18438:      	mov	w8, #0x1                // =1
   1843c:      	strb	w8, [x4, #0x2]
   18440:      	tbz	w1, #0x1, 0x183fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3e8>
   18444:      	mov	w8, #0x1                // =1
   18448:      	strb	w8, [x4, #0x3]
   1844c:      	mov	w8, #0x5000             // =20480
   18450:      	tst	w1, w8
   18454:      	b.ne	0x18408 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3f4>
   18458:      	b	0x18410 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3fc>
   1845c:      	tst	w2, #0xf00000
   18460:      	cset	w8, ne
   18464:      	b	0x183e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3d4>
   18468:      	tbnz	w0, #0x14, 0x183e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3d0>
   1846c:      	b	0x183ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf3d8>
   18470:      	mov	w9, #0x600              // =1536
   18474:      	bics	wzr, w9, w0
   18478:      	b.ne	0x18484 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf470>
   1847c:      	mov	w9, #0x1                // =1
   18480:      	strb	w9, [x4, #0x6]
   18484:      	tbnz	w0, #0xc, 0x182a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf28c>
   18488:      	b	0x182a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf294>
   1848c:      	stp	x29, x30, [sp, #-0x20]!
   18490:      	str	x19, [sp, #0x10]
   18494:      	mov	x29, sp
   18498:      	mov	x19, x0
   1849c:      	nop
   184a0:      	adr	x0, 0x473b
   184a4:      	add	x1, x19, #0x40
   184a8:      	bl	0x1d7f0 <__system_property_get@plt>
   184ac:      	adrp	x0, 0x2000
   184b0:      	add	x0, x0, #0xcae
   184b4:      	add	x1, x19, #0x9c
   184b8:      	bl	0x1d7f0 <__system_property_get@plt>
   184bc:      	adrp	x0, 0x3000
   184c0:      	add	x0, x0, #0x77c
   184c4:      	add	x1, x19, #0xf8
   184c8:      	bl	0x1d7f0 <__system_property_get@plt>
   184cc:      	adrp	x0, 0x2000
   184d0:      	add	x0, x0, #0xfeb
   184d4:      	add	x1, x19, #0x154
   184d8:      	bl	0x1d7f0 <__system_property_get@plt>
   184dc:      	adrp	x0, 0x3000
   184e0:      	add	x0, x0, #0x112
   184e4:      	add	x1, x19, #0x1b0
   184e8:      	bl	0x1d7f0 <__system_property_get@plt>
   184ec:      	adrp	x0, 0x4000
   184f0:      	add	x0, x0, #0xabb
   184f4:      	add	x1, x19, #0x20c
   184f8:      	bl	0x1d7f0 <__system_property_get@plt>
   184fc:      	adrp	x0, 0x2000
   18500:      	add	x0, x0, #0xccc
   18504:      	add	x1, x19, #0x268
   18508:      	bl	0x1d7f0 <__system_property_get@plt>
   1850c:      	adrp	x0, 0x2000
   18510:      	add	x0, x0, #0xba7
   18514:      	add	x1, x19, #0x2c4
   18518:      	ldr	x19, [sp, #0x10]
   1851c:      	ldp	x29, x30, [sp], #0x20
   18520:      	b	0x1d7f0 <__system_property_get@plt>
   18524:      	stp	x29, x30, [sp, #-0x60]!
   18528:      	stp	x28, x27, [sp, #0x10]
   1852c:      	stp	x26, x25, [sp, #0x20]
   18530:      	stp	x24, x23, [sp, #0x30]
   18534:      	stp	x22, x21, [sp, #0x40]
   18538:      	stp	x20, x19, [sp, #0x50]
   1853c:      	mov	x29, sp
   18540:      	sub	sp, sp, #0x10
   18544:      	mrs	x26, TPIDR_EL0
   18548:      	add	x9, x1, #0xf
   1854c:      	mov	x21, x3
   18550:      	ldr	x8, [x26, #0x28]
   18554:      	and	x9, x9, #0xfffffffffffffff0
   18558:      	mov	x20, x2
   1855c:      	mov	x23, x1
   18560:      	stur	x8, [x29, #-0x8]
   18564:      	mov	x8, sp
   18568:      	sub	x22, x8, x9
   1856c:      	mov	sp, x22
   18570:      	mov	w1, wzr
   18574:      	bl	0x1d7c0 <__open_2@plt>
   18578:      	cmn	w0, #0x1
   1857c:      	b.eq	0x18638 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf624>
   18580:      	mov	w19, w0
   18584:      	add	x27, x22, x23
   18588:      	mov	w23, #0x1               // =1
   1858c:      	mov	x25, x22
   18590:      	b	0x185ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf598>
   18594:      	mov	x24, x28
   18598:      	sub	x24, x24, x1
   1859c:      	mov	x0, x22
   185a0:      	mov	x2, x24
   185a4:      	bl	0x1d740 <memmove@plt>
   185a8:      	add	x25, x22, x24
   185ac:      	sub	x2, x27, x25
   185b0:      	mov	w0, w19
   185b4:      	mov	x1, x25
   185b8:      	mov	x3, #-0x1               // =-1
   185bc:      	bl	0x1d7d0 <__read_chk@plt>
   185c0:      	tbnz	x0, #0x3f, 0x1864c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf638>
   185c4:      	add	x24, x25, x0
   185c8:      	cbz	x0, 0x18660 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf64c>
   185cc:      	cmp	x22, x24
   185d0:      	b.eq	0x1862c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf618>
   185d4:      	add	x28, x0, x25
   185d8:      	mov	x1, x22
   185dc:      	mov	x25, x1
   185e0:      	ldrb	w8, [x25]
   185e4:      	cmp	w8, #0xa
   185e8:      	b.eq	0x185fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf5e8>
   185ec:      	add	x25, x25, #0x1
   185f0:      	cmp	x25, x24
   185f4:      	b.ne	0x185e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf5cc>
   185f8:      	b	0x18594 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf580>
   185fc:      	mov	x0, x1
   18600:      	mov	x1, x25
   18604:      	mov	x2, x21
   18608:      	mov	x3, x23
   1860c:      	blr	x20
   18610:      	tbz	w0, #0x0, 0x18658 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf644>
   18614:      	add	x1, x25, #0x1
   18618:      	add	x23, x23, #0x1
   1861c:      	cmp	x1, x24
   18620:      	b.ne	0x185dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf5c8>
   18624:      	mov	x1, x24
   18628:      	b	0x18598 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf584>
   1862c:      	mov	x1, x22
   18630:      	mov	x24, x22
   18634:      	b	0x18598 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf584>
   18638:      	bl	0x1d8e0 <__errno@plt>
   1863c:      	ldr	w0, [x0]
   18640:      	bl	0x1d8f0 <strerror@plt>
   18644:      	mov	w20, wzr
   18648:      	b	0x18680 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf66c>
   1864c:      	bl	0x1d8e0 <__errno@plt>
   18650:      	ldr	w0, [x0]
   18654:      	bl	0x1d8f0 <strerror@plt>
   18658:      	mov	w20, wzr
   1865c:      	b	0x18678 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf664>
   18660:      	mov	x0, x22
   18664:      	mov	x1, x24
   18668:      	mov	x2, x21
   1866c:      	mov	x3, x23
   18670:      	blr	x20
   18674:      	mov	w20, w0
   18678:      	mov	w0, w19
   1867c:      	bl	0x1d7e0 <close@plt>
   18680:      	ldr	x8, [x26, #0x28]
   18684:      	ldur	x9, [x29, #-0x8]
   18688:      	cmp	x8, x9
   1868c:      	b.ne	0x186b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf6a0>
   18690:      	and	w0, w20, #0x1
   18694:      	mov	sp, x29
   18698:      	ldp	x20, x19, [sp, #0x50]
   1869c:      	ldp	x22, x21, [sp, #0x40]
   186a0:      	ldp	x24, x23, [sp, #0x30]
   186a4:      	ldp	x26, x25, [sp, #0x20]
   186a8:      	ldp	x28, x27, [sp, #0x10]
   186ac:      	ldp	x29, x30, [sp], #0x60
   186b0:      	ret
   186b4:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   186b8:      	sub	sp, sp, #0x30
   186bc:      	stp	x29, x30, [sp, #0x10]
   186c0:      	str	x19, [sp, #0x20]
   186c4:      	add	x29, sp, #0x10
   186c8:      	mrs	x19, TPIDR_EL0
   186cc:      	nop
   186d0:      	adr	x0, 0x305d
   186d4:      	ldr	x8, [x19, #0x28]
   186d8:      	nop
   186dc:      	adr	x2, 0x18724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf710>
   186e0:      	add	x3, sp, #0x4
   186e4:      	mov	w1, #0x20               // =32
   186e8:      	str	x8, [sp, #0x8]
   186ec:      	bl	0x190c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x100b4>
   186f0:      	ldr	w8, [sp, #0x4]
   186f4:      	ldr	x9, [x19, #0x28]
   186f8:      	tst	w0, #0x1
   186fc:      	ldr	x10, [sp, #0x8]
   18700:      	mov	w11, #0x400             // =1024
   18704:      	csinc	w0, w11, w8, eq
   18708:      	cmp	x9, x10
   1870c:      	b.ne	0x18720 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf70c>
   18710:      	ldp	x29, x30, [sp, #0x10]
   18714:      	ldr	x19, [sp, #0x20]
   18718:      	add	sp, sp, #0x30
   1871c:      	ret
   18720:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   18724:      	stp	x29, x30, [sp, #-0x10]!
   18728:      	mov	x29, sp
   1872c:      	cmp	x1, x2
   18730:      	b.eq	0x18784 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf770>
   18734:      	mov	x8, x2
   18738:      	mov	w9, wzr
   1873c:      	sub	x2, x2, x1
   18740:      	mov	w11, #0xa               // =10
   18744:      	mov	x10, x1
   18748:      	ldrb	w12, [x10]
   1874c:      	sub	w12, w12, #0x30
   18750:      	cmp	w12, #0x9
   18754:      	b.hi	0x1876c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf758>
   18758:      	madd	w9, w9, w11, w12
   1875c:      	add	x10, x10, #0x1
   18760:      	cmp	x10, x8
   18764:      	b.ne	0x18748 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf734>
   18768:      	mov	x10, x8
   1876c:      	cmp	x10, x1
   18770:      	b.eq	0x187a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf790>
   18774:      	str	w9, [x3]
   18778:      	mov	w0, #0x1                // =1
   1877c:      	ldp	x29, x30, [sp], #0x10
   18780:      	ret
   18784:      	adrp	x0, 0x4000
   18788:      	add	x0, x0, #0x8e7
   1878c:      	nop
   18790:      	adr	x1, 0x305d
   18794:      	bl	0x18db8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfda4>
   18798:      	mov	w0, wzr
   1879c:      	ldp	x29, x30, [sp], #0x10
   187a0:      	ret
   187a4:      	adrp	x8, 0x3000
   187a8:      	add	x8, x8, #0x605
   187ac:      	mov	x9, x0
   187b0:      	mov	x0, x8
   187b4:      	mov	x3, x1
   187b8:      	mov	x1, x9
   187bc:      	bl	0x18db8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfda4>
   187c0:      	mov	w0, wzr
   187c4:      	ldp	x29, x30, [sp], #0x10
   187c8:      	ret
   187cc:      	sub	sp, sp, #0x110
   187d0:      	stp	x29, x30, [sp, #0xf0]
   187d4:      	stp	x28, x19, [sp, #0x100]
   187d8:      	add	x29, sp, #0xf0
   187dc:      	stp	x4, x5, [x29, #-0x70]
   187e0:      	sub	x10, x29, #0x70
   187e4:      	mov	x11, sp
   187e8:      	stp	x6, x7, [x29, #-0x60]
   187ec:      	add	x11, x11, #0x80
   187f0:      	mov	x8, x3
   187f4:      	stp	q0, q1, [sp]
   187f8:      	mov	x3, x1
   187fc:      	sub	x5, x29, #0x50
   18800:      	stp	q2, q3, [sp, #0x20]
   18804:      	mov	x1, x2
   18808:      	mov	w2, wzr
   1880c:      	stp	q4, q5, [sp, #0x40]
   18810:      	mov	x4, x8
   18814:      	stp	q6, q7, [sp, #0x60]
   18818:      	mrs	x19, TPIDR_EL0
   1881c:      	ldr	x9, [x19, #0x28]
   18820:      	stur	x9, [x29, #-0x8]
   18824:      	add	x9, x10, #0x20
   18828:      	add	x10, x29, #0x20
   1882c:      	stp	x10, x9, [x29, #-0x28]
   18830:      	mov	x9, #-0x20              // =-32
   18834:      	sub	x10, x29, #0x28
   18838:      	movk	x9, #0xff80, lsl #32
   1883c:      	stp	x11, x9, [x29, #-0x18]
   18840:      	ldp	q0, q1, [x10]
   18844:      	stp	q0, q1, [x29, #-0x50]
   18848:      	bl	0x1d520 <__vsnprintf_chk@plt>
   1884c:      	ldr	x8, [x19, #0x28]
   18850:      	ldur	x9, [x29, #-0x8]
   18854:      	cmp	x8, x9
   18858:      	b.ne	0x1886c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf858>
   1885c:      	ldp	x28, x19, [sp, #0x100]
   18860:      	ldp	x29, x30, [sp, #0xf0]
   18864:      	add	sp, sp, #0x110
   18868:      	ret
   1886c:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   18870:      	sub	sp, sp, #0x70
   18874:      	stp	x29, x30, [sp, #0x50]
   18878:      	str	x19, [sp, #0x60]
   1887c:      	add	x29, sp, #0x50
   18880:      	mrs	x19, TPIDR_EL0
   18884:      	mov	w4, w0
   18888:      	adrp	x3, 0x3000
   1888c:      	add	x3, x3, #0xb93
   18890:      	ldr	x8, [x19, #0x28]
   18894:      	add	x0, sp, #0x9
   18898:      	mov	w1, #0x3f               // =63
   1889c:      	mov	w2, #0x3f               // =63
   188a0:      	stur	x8, [x29, #-0x8]
   188a4:      	bl	0x187cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf7b8>
   188a8:      	cmp	w0, #0x3e
   188ac:      	b.ls	0x188b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf8a4>
   188b0:      	mov	w0, wzr
   188b4:      	b	0x188dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf8c8>
   188b8:      	nop
   188bc:      	adr	x2, 0x18724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf710>
   188c0:      	add	x0, sp, #0x9
   188c4:      	add	x3, sp, #0x4
   188c8:      	mov	w1, #0x20               // =32
   188cc:      	bl	0x190c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x100b4>
   188d0:      	ldr	w8, [sp, #0x4]
   188d4:      	tst	w0, #0x1
   188d8:      	csel	w0, w8, wzr, ne
   188dc:      	ldr	x8, [x19, #0x28]
   188e0:      	ldur	x9, [x29, #-0x8]
   188e4:      	cmp	x8, x9
   188e8:      	b.ne	0x188fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf8e8>
   188ec:      	ldp	x29, x30, [sp, #0x50]
   188f0:      	ldr	x19, [sp, #0x60]
   188f4:      	add	sp, sp, #0x70
   188f8:      	ret
   188fc:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   18900:      	sub	sp, sp, #0x70
   18904:      	stp	x29, x30, [sp, #0x50]
   18908:      	str	x19, [sp, #0x60]
   1890c:      	add	x29, sp, #0x50
   18910:      	mrs	x19, TPIDR_EL0
   18914:      	mov	w4, w0
   18918:      	adrp	x3, 0x3000
   1891c:      	add	x3, x3, #0x182
   18920:      	ldr	x8, [x19, #0x28]
   18924:      	add	x0, sp, #0x9
   18928:      	mov	w1, #0x3f               // =63
   1892c:      	mov	w2, #0x3f               // =63
   18930:      	stur	x8, [x29, #-0x8]
   18934:      	bl	0x187cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf7b8>
   18938:      	cmp	w0, #0x3e
   1893c:      	b.ls	0x18948 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf934>
   18940:      	mov	w0, wzr
   18944:      	b	0x1896c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf958>
   18948:      	nop
   1894c:      	adr	x2, 0x18724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf710>
   18950:      	add	x0, sp, #0x9
   18954:      	add	x3, sp, #0x4
   18958:      	mov	w1, #0x20               // =32
   1895c:      	bl	0x190c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x100b4>
   18960:      	ldr	w8, [sp, #0x4]
   18964:      	tst	w0, #0x1
   18968:      	csel	w0, w8, wzr, ne
   1896c:      	ldr	x8, [x19, #0x28]
   18970:      	ldur	x9, [x29, #-0x8]
   18974:      	cmp	x8, x9
   18978:      	b.ne	0x1898c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf978>
   1897c:      	ldp	x29, x30, [sp, #0x50]
   18980:      	ldr	x19, [sp, #0x60]
   18984:      	add	sp, sp, #0x70
   18988:      	ret
   1898c:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   18990:      	mov	w0, wzr
   18994:      	cbz	x1, 0x18a40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfa2c>
   18998:      	stp	x29, x30, [sp, #-0x40]!
   1899c:      	str	x23, [sp, #0x10]
   189a0:      	stp	x22, x21, [sp, #0x20]
   189a4:      	stp	x20, x19, [sp, #0x30]
   189a8:      	mov	x29, sp
   189ac:      	mov	x20, x2
   189b0:      	mov	x21, x1
   189b4:      	cmp	x1, x2
   189b8:      	b.hs	0x18a30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfa1c>
   189bc:      	mov	x19, x3
   189c0:      	adrp	x22, 0x2000
   189c4:      	add	x22, x22, #0xefc
   189c8:      	b	0x189d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf9c4>
   189cc:      	add	x21, x23, #0x1
   189d0:      	cmp	x21, x20
   189d4:      	b.hs	0x18a2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfa18>
   189d8:      	mov	x0, x21
   189dc:      	mov	w1, #0xa                // =10
   189e0:      	bl	0x1d790 <strchr@plt>
   189e4:      	cmp	x0, #0x0
   189e8:      	csel	x23, x20, x0, eq
   189ec:      	sub	x8, x23, x21
   189f0:      	cmp	x8, #0x10
   189f4:      	b.lo	0x189cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf9b8>
   189f8:      	mov	x0, x21
   189fc:      	mov	x1, x22
   18a00:      	mov	w2, #0x10               // =16
   18a04:      	bl	0x1d8c0 <strncmp@plt>
   18a08:      	cbnz	w0, 0x189cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf9b8>
   18a0c:      	add	x1, x21, #0x10
   18a10:      	mov	x0, x19
   18a14:      	sub	x20, x23, x1
   18a18:      	mov	x2, x20
   18a1c:      	bl	0x1d5d0 <strncpy@plt>
   18a20:      	strb	wzr, [x19, x20]
   18a24:      	mov	w0, #0x1                // =1
   18a28:      	b	0x18a30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfa1c>
   18a2c:      	mov	w0, wzr
   18a30:      	ldp	x20, x19, [sp, #0x30]
   18a34:      	ldr	x23, [sp, #0x10]
   18a38:      	ldp	x22, x21, [sp, #0x20]
   18a3c:      	ldp	x29, x30, [sp], #0x40
   18a40:      	ret
   18a44:      	sub	sp, sp, #0x190
   18a48:      	stp	x29, x30, [sp, #0x140]
   18a4c:      	str	x28, [sp, #0x150]
   18a50:      	stp	x24, x23, [sp, #0x160]
   18a54:      	stp	x22, x21, [sp, #0x170]
   18a58:      	stp	x20, x19, [sp, #0x180]
   18a5c:      	add	x29, sp, #0x140
   18a60:      	mrs	x23, TPIDR_EL0
   18a64:      	mov	w21, w0
   18a68:      	mov	x19, x2
   18a6c:      	ldr	x8, [x23, #0x28]
   18a70:      	mov	x20, x1
   18a74:      	adrp	x3, 0x4000
   18a78:      	add	x3, x3, #0x667
   18a7c:      	sub	x0, x29, #0x35
   18a80:      	mov	w1, #0x2d               // =45
   18a84:      	mov	w2, #0x2d               // =45
   18a88:      	mov	w4, w21
   18a8c:      	stur	x8, [x29, #-0x8]
   18a90:      	bl	0x187cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf7b8>
   18a94:      	cmp	w0, #0x2d
   18a98:      	b.lo	0x18ab0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfa9c>
   18a9c:      	adrp	x0, 0x2000
   18aa0:      	add	x0, x0, #0xec0
   18aa4:      	mov	w1, w21
   18aa8:      	bl	0x1d560 <printf@plt>
   18aac:      	b	0x18b54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfb40>
   18ab0:      	movi	v0.2d, #0000000000000000
   18ab4:      	nop
   18ab8:      	adr	x2, 0x18990 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf97c>
   18abc:      	sub	x0, x29, #0x35
   18ac0:      	mov	x3, sp
   18ac4:      	mov	w1, #0x100              // =256
   18ac8:      	stp	q0, q0, [sp]
   18acc:      	stp	q0, q0, [sp, #0x20]
   18ad0:      	stp	q0, q0, [sp, #0x40]
   18ad4:      	stp	q0, q0, [sp, #0x60]
   18ad8:      	stp	q0, q0, [sp, #0x80]
   18adc:      	stp	q0, q0, [sp, #0xa0]
   18ae0:      	stp	q0, q0, [sp, #0xc0]
   18ae4:      	stp	q0, q0, [sp, #0xe0]
   18ae8:      	bl	0x190c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x100b4>
   18aec:      	tbz	w0, #0x0, 0x18b54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfb40>
   18af0:      	mov	x0, sp
   18af4:      	mov	w1, #0x2c               // =44
   18af8:      	mov	w2, #0x100              // =256
   18afc:      	mov	x21, sp
   18b00:      	bl	0x1d7b0 <__strchr_chk@plt>
   18b04:      	cbz	x0, 0x18b58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfb44>
   18b08:      	sub	x21, x0, x21
   18b0c:      	mov	x24, x0
   18b10:      	add	x0, x0, #0x1
   18b14:      	bl	0x1d510 <strlen@plt>
   18b18:      	mov	x22, x0
   18b1c:      	mov	x1, sp
   18b20:      	mov	x0, x20
   18b24:      	mov	x2, x21
   18b28:      	mov	x3, #-0x1               // =-1
   18b2c:      	mov	w4, #0x100              // =256
   18b30:      	bl	0x1d5e0 <__strncpy_chk2@plt>
   18b34:      	add	x1, x24, #0x1
   18b38:      	mov	x0, x19
   18b3c:      	mov	x2, x22
   18b40:      	strb	wzr, [x20, x21]
   18b44:      	bl	0x1d5d0 <strncpy@plt>
   18b48:      	mov	w0, #0x1                // =1
   18b4c:      	strb	wzr, [x19, x22]
   18b50:      	b	0x18b58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfb44>
   18b54:      	mov	w0, wzr
   18b58:      	ldr	x8, [x23, #0x28]
   18b5c:      	ldur	x9, [x29, #-0x8]
   18b60:      	cmp	x8, x9
   18b64:      	b.ne	0x18b84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfb70>
   18b68:      	ldp	x20, x19, [sp, #0x180]
   18b6c:      	ldr	x28, [sp, #0x150]
   18b70:      	ldp	x22, x21, [sp, #0x170]
   18b74:      	ldp	x24, x23, [sp, #0x160]
   18b78:      	ldp	x29, x30, [sp, #0x140]
   18b7c:      	add	sp, sp, #0x190
   18b80:      	ret
   18b84:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   18b88:      	sub	sp, sp, #0x70
   18b8c:      	stp	x29, x30, [sp, #0x50]
   18b90:      	str	x19, [sp, #0x60]
   18b94:      	add	x29, sp, #0x50
   18b98:      	mrs	x19, TPIDR_EL0
   18b9c:      	mov	w4, w0
   18ba0:      	adrp	x3, 0x4000
   18ba4:      	add	x3, x3, #0x129
   18ba8:      	ldr	x8, [x19, #0x28]
   18bac:      	add	x0, sp, #0x5
   18bb0:      	mov	w1, #0x43               // =67
   18bb4:      	mov	w2, #0x43               // =67
   18bb8:      	stur	x8, [x29, #-0x8]
   18bbc:      	bl	0x187cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf7b8>
   18bc0:      	cmp	w0, #0x42
   18bc4:      	b.ls	0x18bd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfbbc>
   18bc8:      	mov	w0, wzr
   18bcc:      	b	0x18bf4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfbe0>
   18bd0:      	nop
   18bd4:      	adr	x2, 0x18c18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfc04>
   18bd8:      	add	x0, sp, #0x5
   18bdc:      	mov	x3, sp
   18be0:      	mov	w1, #0x43               // =67
   18be4:      	bl	0x190c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x100b4>
   18be8:      	ldr	w8, [sp]
   18bec:      	tst	w0, #0x1
   18bf0:      	csel	w0, w8, wzr, ne
   18bf4:      	ldr	x8, [x19, #0x28]
   18bf8:      	ldur	x9, [x29, #-0x8]
   18bfc:      	cmp	x8, x9
   18c00:      	b.ne	0x18c14 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfc00>
   18c04:      	ldp	x29, x30, [sp, #0x50]
   18c08:      	ldr	x19, [sp, #0x60]
   18c0c:      	add	sp, sp, #0x70
   18c10:      	ret
   18c14:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   18c18:      	ldrb	w8, [x1]
   18c1c:      	cmp	w8, #0x30
   18c20:      	b.ne	0x18c6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfc58>
   18c24:      	ldrb	w8, [x1, #0x1]
   18c28:      	orr	w8, w8, #0x20
   18c2c:      	cmp	w8, #0x78
   18c30:      	b.ne	0x18c6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfc58>
   18c34:      	stp	x29, x30, [sp, #-0x20]!
   18c38:      	str	x19, [sp, #0x10]
   18c3c:      	mov	x29, sp
   18c40:      	mov	x0, x1
   18c44:      	mov	x1, xzr
   18c48:      	mov	w2, #0x10               // =16
   18c4c:      	mov	x19, x3
   18c50:      	bl	0x1d900 <strtoul@plt>
   18c54:      	mov	x8, x0
   18c58:      	mov	w0, #0x1                // =1
   18c5c:      	str	w8, [x19]
   18c60:      	ldr	x19, [sp, #0x10]
   18c64:      	ldp	x29, x30, [sp], #0x20
   18c68:      	ret
   18c6c:      	mov	w0, wzr
   18c70:      	ret
   18c74:      	sub	sp, sp, #0x70
   18c78:      	stp	x29, x30, [sp, #0x50]
   18c7c:      	stp	x20, x19, [sp, #0x60]
   18c80:      	add	x29, sp, #0x50
   18c84:      	mrs	x20, TPIDR_EL0
   18c88:      	mov	x19, x1
   18c8c:      	mov	w4, w0
   18c90:      	ldr	x8, [x20, #0x28]
   18c94:      	adrp	x3, 0x3000
   18c98:      	add	x3, x3, #0x2f6
   18c9c:      	add	x0, sp, #0x5
   18ca0:      	mov	w1, #0x43               // =67
   18ca4:      	mov	w2, #0x43               // =67
   18ca8:      	stur	x8, [x29, #-0x8]
   18cac:      	bl	0x187cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf7b8>
   18cb0:      	cmp	w0, #0x42
   18cb4:      	b.ls	0x18cc0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfcac>
   18cb8:      	mov	w0, wzr
   18cbc:      	b	0x18ce4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfcd0>
   18cc0:      	nop
   18cc4:      	adr	x2, 0x18724 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf710>
   18cc8:      	add	x0, sp, #0x5
   18ccc:      	mov	x3, sp
   18cd0:      	mov	w1, #0x20               // =32
   18cd4:      	bl	0x190c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x100b4>
   18cd8:      	tbz	w0, #0x0, 0x18ce4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfcd0>
   18cdc:      	ldr	w8, [sp]
   18ce0:      	str	w8, [x19]
   18ce4:      	ldr	x8, [x20, #0x28]
   18ce8:      	ldur	x9, [x29, #-0x8]
   18cec:      	cmp	x8, x9
   18cf0:      	b.ne	0x18d08 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfcf4>
   18cf4:      	and	w0, w0, #0x1
   18cf8:      	ldp	x20, x19, [sp, #0x60]
   18cfc:      	ldp	x29, x30, [sp, #0x50]
   18d00:      	add	sp, sp, #0x70
   18d04:      	ret
   18d08:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   18d0c:      	sub	sp, sp, #0x30
   18d10:      	stp	x29, x30, [sp, #0x10]
   18d14:      	stp	x20, x19, [sp, #0x20]
   18d18:      	add	x29, sp, #0x10
   18d1c:      	mrs	x20, TPIDR_EL0
   18d20:      	mov	w19, w0
   18d24:      	adrp	x0, 0x4000
   18d28:      	add	x0, x0, #0x386
   18d2c:      	ldr	x8, [x20, #0x28]
   18d30:      	nop
   18d34:      	adr	x1, 0x18d9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfd88>
   18d38:      	add	x2, sp, #0x4
   18d3c:      	str	x8, [sp, #0x8]
   18d40:      	str	wzr, [sp, #0x4]
   18d44:      	bl	0x19280 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1026c>
   18d48:      	tbz	w0, #0x0, 0x18d60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfd4c>
   18d4c:      	ldr	w8, [sp, #0x4]
   18d50:      	sub	w9, w19, #0x1
   18d54:      	cmp	w8, w19
   18d58:      	csel	w0, w8, w9, lo
   18d5c:      	b	0x18d78 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfd64>
   18d60:      	adrp	x0, 0x3000
   18d64:      	add	x0, x0, #0x331
   18d68:      	adrp	x1, 0x4000
   18d6c:      	add	x1, x1, #0x386
   18d70:      	bl	0x18db8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfda4>
   18d74:      	mov	w0, #-0x1               // =-1
   18d78:      	ldr	x8, [x20, #0x28]
   18d7c:      	ldr	x9, [sp, #0x8]
   18d80:      	cmp	x8, x9
   18d84:      	b.ne	0x18d98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfd84>
   18d88:      	ldp	x20, x19, [sp, #0x20]
   18d8c:      	ldp	x29, x30, [sp, #0x10]
   18d90:      	add	sp, sp, #0x30
   18d94:      	ret
   18d98:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   18d9c:      	ldr	w9, [x2]
   18da0:      	sub	w8, w1, #0x1
   18da4:      	cmp	w9, w8
   18da8:      	b.hs	0x18db0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfd9c>
   18dac:      	str	w8, [x2]
   18db0:      	mov	w0, #0x1                // =1
   18db4:      	ret
   18db8:      	sub	sp, sp, #0x130
   18dbc:      	stp	x29, x30, [sp, #0x110]
   18dc0:      	stp	x28, x19, [sp, #0x120]
   18dc4:      	add	x29, sp, #0x110
   18dc8:      	stp	x1, x2, [sp, #0x88]
   18dcc:      	add	x9, sp, #0x88
   18dd0:      	mov	x10, sp
   18dd4:      	stp	x3, x4, [sp, #0x98]
   18dd8:      	add	x10, x10, #0x80
   18ddc:      	sub	x1, x29, #0x50
   18de0:      	stp	x5, x6, [sp, #0xa8]
   18de4:      	str	x7, [sp, #0xb8]
   18de8:      	stp	q0, q1, [sp]
   18dec:      	stp	q2, q3, [sp, #0x20]
   18df0:      	stp	q4, q5, [sp, #0x40]
   18df4:      	stp	q6, q7, [sp, #0x60]
   18df8:      	mrs	x19, TPIDR_EL0
   18dfc:      	ldr	x8, [x19, #0x28]
   18e00:      	stur	x8, [x29, #-0x8]
   18e04:      	add	x8, x9, #0x38
   18e08:      	add	x9, x29, #0x20
   18e0c:      	stp	x9, x8, [x29, #-0x28]
   18e10:      	mov	x8, #-0x38              // =-56
   18e14:      	sub	x9, x29, #0x28
   18e18:      	movk	x8, #0xff80, lsl #32
   18e1c:      	stp	x10, x8, [x29, #-0x18]
   18e20:      	ldp	q0, q1, [x9]
   18e24:      	stp	q0, q1, [x29, #-0x50]
   18e28:      	bl	0xe6c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x56ac>
   18e2c:      	ldr	x8, [x19, #0x28]
   18e30:      	ldur	x9, [x29, #-0x8]
   18e34:      	cmp	x8, x9
   18e38:      	b.ne	0x18e4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfe38>
   18e3c:      	ldp	x28, x19, [sp, #0x120]
   18e40:      	ldp	x29, x30, [sp, #0x110]
   18e44:      	add	sp, sp, #0x130
   18e48:      	ret
   18e4c:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   18e50:      	sub	sp, sp, #0x30
   18e54:      	stp	x29, x30, [sp, #0x10]
   18e58:      	stp	x20, x19, [sp, #0x20]
   18e5c:      	add	x29, sp, #0x10
   18e60:      	mrs	x20, TPIDR_EL0
   18e64:      	mov	w19, w0
   18e68:      	adrp	x0, 0x4000
   18e6c:      	add	x0, x0, #0xbcc
   18e70:      	ldr	x8, [x20, #0x28]
   18e74:      	nop
   18e78:      	adr	x1, 0x18d9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfd88>
   18e7c:      	add	x2, sp, #0x4
   18e80:      	str	x8, [sp, #0x8]
   18e84:      	str	wzr, [sp, #0x4]
   18e88:      	bl	0x19280 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1026c>
   18e8c:      	tbz	w0, #0x0, 0x18ea4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfe90>
   18e90:      	ldr	w8, [sp, #0x4]
   18e94:      	sub	w9, w19, #0x1
   18e98:      	cmp	w8, w19
   18e9c:      	csel	w0, w8, w9, lo
   18ea0:      	b	0x18ebc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfea8>
   18ea4:      	adrp	x0, 0x4000
   18ea8:      	add	x0, x0, #0xbec
   18eac:      	adrp	x1, 0x4000
   18eb0:      	add	x1, x1, #0xbcc
   18eb4:      	bl	0x18db8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfda4>
   18eb8:      	mov	w0, #-0x1               // =-1
   18ebc:      	ldr	x8, [x20, #0x28]
   18ec0:      	ldr	x9, [sp, #0x8]
   18ec4:      	cmp	x8, x9
   18ec8:      	b.ne	0x18edc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xfec8>
   18ecc:      	ldp	x20, x19, [sp, #0x20]
   18ed0:      	ldp	x29, x30, [sp, #0x10]
   18ed4:      	add	sp, sp, #0x30
   18ed8:      	ret
   18edc:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   18ee0:      	sub	sp, sp, #0x40
   18ee4:      	stp	x29, x30, [sp, #0x20]
   18ee8:      	str	x19, [sp, #0x30]
   18eec:      	add	x29, sp, #0x20
   18ef0:      	mrs	x19, TPIDR_EL0
   18ef4:      	ldr	x8, [x19, #0x28]
   18ef8:      	stur	x8, [x29, #-0x8]
   18efc:      	str	w0, [sp]
   18f00:      	adrp	x0, 0x4000
   18f04:      	add	x0, x0, #0x386
   18f08:      	str	x1, [sp, #0x8]
   18f0c:      	nop
   18f10:      	adr	x1, 0x18f48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xff34>
   18f14:      	stp	w2, w3, [sp, #0x10]
   18f18:      	mov	x2, sp
   18f1c:      	bl	0x19280 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1026c>
   18f20:      	ldr	x8, [x19, #0x28]
   18f24:      	ldur	x9, [x29, #-0x8]
   18f28:      	cmp	x8, x9
   18f2c:      	b.ne	0x18f44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xff30>
   18f30:      	and	w0, w0, #0x1
   18f34:      	ldp	x29, x30, [sp, #0x20]
   18f38:      	ldr	x19, [sp, #0x30]
   18f3c:      	add	sp, sp, #0x40
   18f40:      	ret
   18f44:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   18f48:      	ldr	w8, [x2]
   18f4c:      	cmp	w1, w8
   18f50:      	csel	w12, w1, w8, lo
   18f54:      	cmp	w12, w0
   18f58:      	b.ls	0x18f84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xff70>
   18f5c:      	ldp	w8, w9, [x2, #0x10]
   18f60:      	ldr	x11, [x2, #0x8]
   18f64:      	sub	x12, x12, w0, uxtw
   18f68:      	mul	w10, w8, w0
   18f6c:      	ldr	w13, [x11, w10, uxtw]
   18f70:      	subs	x12, x12, #0x1
   18f74:      	orr	w13, w13, w9
   18f78:      	str	w13, [x11, w10, uxtw]
   18f7c:      	add	w10, w10, w8
   18f80:      	b.ne	0x18f6c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xff58>
   18f84:      	mov	w0, #0x1                // =1
   18f88:      	ret
   18f8c:      	sub	sp, sp, #0x40
   18f90:      	stp	x29, x30, [sp, #0x20]
   18f94:      	str	x19, [sp, #0x30]
   18f98:      	add	x29, sp, #0x20
   18f9c:      	mrs	x19, TPIDR_EL0
   18fa0:      	ldr	x8, [x19, #0x28]
   18fa4:      	stur	x8, [x29, #-0x8]
   18fa8:      	str	w0, [sp]
   18fac:      	adrp	x0, 0x4000
   18fb0:      	add	x0, x0, #0xbcc
   18fb4:      	str	x1, [sp, #0x8]
   18fb8:      	nop
   18fbc:      	adr	x1, 0x18f48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xff34>
   18fc0:      	stp	w2, w3, [sp, #0x10]
   18fc4:      	mov	x2, sp
   18fc8:      	bl	0x19280 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1026c>
   18fcc:      	ldr	x8, [x19, #0x28]
   18fd0:      	ldur	x9, [x29, #-0x8]
   18fd4:      	cmp	x8, x9
   18fd8:      	b.ne	0x18ff0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xffdc>
   18fdc:      	and	w0, w0, #0x1
   18fe0:      	ldp	x29, x30, [sp, #0x20]
   18fe4:      	ldr	x19, [sp, #0x30]
   18fe8:      	add	sp, sp, #0x40
   18fec:      	ret
   18ff0:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   18ff4:      	mov	w8, w0
   18ff8:      	ldp	x4, x3, [x2, #0x10]
   18ffc:      	ldp	w9, w0, [x2, #0x8]
   19000:      	cmp	w9, w1
   19004:      	csel	w2, w9, w1, lo
   19008:      	mov	w1, w8
   1900c:      	br	x4
   19010:      	sub	sp, sp, #0xb0
   19014:      	stp	x29, x30, [sp, #0x70]
   19018:      	str	x23, [sp, #0x80]
   1901c:      	stp	x22, x21, [sp, #0x90]
   19020:      	stp	x20, x19, [sp, #0xa0]
   19024:      	add	x29, sp, #0x70
   19028:      	mrs	x23, TPIDR_EL0
   1902c:      	mov	w21, w1
   19030:      	mov	x19, x3
   19034:      	ldr	x8, [x23, #0x28]
   19038:      	mov	x20, x2
   1903c:      	mov	w22, w0
   19040:      	adrp	x3, 0x3000
   19044:      	add	x3, x3, #0x8cb
   19048:      	add	x0, sp, #0x26
   1904c:      	mov	w1, #0x42               // =66
   19050:      	mov	w2, #0x42               // =66
   19054:      	mov	w4, w21
   19058:      	stur	x8, [x29, #-0x8]
   1905c:      	bl	0x187cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xf7b8>
   19060:      	cmp	w0, #0x41
   19064:      	b.ls	0x19070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1005c>
   19068:      	mov	w0, wzr
   1906c:      	b	0x19098 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10084>
   19070:      	adrp	x8, 0x3000
   19074:      	add	x8, x8, #0xc12
   19078:      	nop
   1907c:      	adr	x1, 0x18ff4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0xffe0>
   19080:      	add	x0, sp, #0x26
   19084:      	mov	x2, sp
   19088:      	str	x8, [sp]
   1908c:      	stp	w22, w21, [sp, #0x8]
   19090:      	stp	x20, x19, [sp, #0x10]
   19094:      	bl	0x19280 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1026c>
   19098:      	ldr	x8, [x23, #0x28]
   1909c:      	ldur	x9, [x29, #-0x8]
   190a0:      	cmp	x8, x9
   190a4:      	b.ne	0x190c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x100b0>
   190a8:      	and	w0, w0, #0x1
   190ac:      	ldp	x20, x19, [sp, #0xa0]
   190b0:      	ldr	x23, [sp, #0x80]
   190b4:      	ldp	x22, x21, [sp, #0x90]
   190b8:      	ldp	x29, x30, [sp, #0x70]
   190bc:      	add	sp, sp, #0xb0
   190c0:      	ret
   190c4:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   190c8:      	stp	x29, x30, [sp, #-0x50]!
   190cc:      	stp	x26, x25, [sp, #0x10]
   190d0:      	stp	x24, x23, [sp, #0x20]
   190d4:      	stp	x22, x21, [sp, #0x30]
   190d8:      	stp	x20, x19, [sp, #0x40]
   190dc:      	mov	x29, sp
   190e0:      	sub	sp, sp, #0x10
   190e4:      	mrs	x25, TPIDR_EL0
   190e8:      	add	x9, x1, #0xf
   190ec:      	mov	x21, x3
   190f0:      	ldr	x8, [x25, #0x28]
   190f4:      	and	x9, x9, #0xfffffffffffffff0
   190f8:      	mov	x20, x2
   190fc:      	mov	x23, x1
   19100:      	mov	x22, x0
   19104:      	stur	x8, [x29, #-0x8]
   19108:      	mov	x8, sp
   1910c:      	sub	x24, x8, x9
   19110:      	mov	sp, x24
   19114:      	mov	w1, wzr
   19118:      	bl	0x1d7c0 <__open_2@plt>
   1911c:      	cmn	w0, #0x1
   19120:      	b.eq	0x19170 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1015c>
   19124:      	mov	w19, w0
   19128:      	mov	x26, xzr
   1912c:      	sub	x2, x23, x26
   19130:      	add	x1, x24, x26
   19134:      	mov	w0, w19
   19138:      	mov	x3, #-0x1               // =-1
   1913c:      	bl	0x1d7d0 <__read_chk@plt>
   19140:      	tbnz	x0, #0x3f, 0x19184 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10170>
   19144:      	add	x26, x0, x26
   19148:      	cmp	x26, x23
   1914c:      	b.hs	0x19194 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10180>
   19150:      	cbnz	x0, 0x1912c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10118>
   19154:      	add	x2, x24, x26
   19158:      	mov	x0, x22
   1915c:      	mov	x1, x24
   19160:      	mov	x3, x21
   19164:      	blr	x20
   19168:      	mov	w20, w0
   1916c:      	b	0x191a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10190>
   19170:      	bl	0x1d8e0 <__errno@plt>
   19174:      	ldr	w0, [x0]
   19178:      	bl	0x1d8f0 <strerror@plt>
   1917c:      	mov	w20, wzr
   19180:      	b	0x191ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10198>
   19184:      	bl	0x1d8e0 <__errno@plt>
   19188:      	ldr	w0, [x0]
   1918c:      	bl	0x1d8f0 <strerror@plt>
   19190:      	b	0x191a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1018c>
   19194:      	mov	x1, x22
   19198:      	mov	x2, x23
   1919c:      	bl	0x191e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x101cc>
   191a0:      	mov	w20, wzr
   191a4:      	mov	w0, w19
   191a8:      	bl	0x1d7e0 <close@plt>
   191ac:      	ldr	x8, [x25, #0x28]
   191b0:      	ldur	x9, [x29, #-0x8]
   191b4:      	cmp	x8, x9
   191b8:      	b.ne	0x191dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x101c8>
   191bc:      	and	w0, w20, #0x1
   191c0:      	mov	sp, x29
   191c4:      	ldp	x20, x19, [sp, #0x40]
   191c8:      	ldp	x22, x21, [sp, #0x30]
   191cc:      	ldp	x24, x23, [sp, #0x20]
   191d0:      	ldp	x26, x25, [sp, #0x10]
   191d4:      	ldp	x29, x30, [sp], #0x50
   191d8:      	ret
   191dc:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   191e0:      	sub	sp, sp, #0x130
   191e4:      	stp	x29, x30, [sp, #0x110]
   191e8:      	stp	x28, x19, [sp, #0x120]
   191ec:      	add	x29, sp, #0x110
   191f0:      	stp	x1, x2, [sp, #0x88]
   191f4:      	add	x9, sp, #0x88
   191f8:      	mov	x10, sp
   191fc:      	stp	x3, x4, [sp, #0x98]
   19200:      	add	x10, x10, #0x80
   19204:      	nop
   19208:      	adr	x0, 0x4af7
   1920c:      	stp	x5, x6, [sp, #0xa8]
   19210:      	sub	x1, x29, #0x50
   19214:      	str	x7, [sp, #0xb8]
   19218:      	stp	q0, q1, [sp]
   1921c:      	stp	q2, q3, [sp, #0x20]
   19220:      	stp	q4, q5, [sp, #0x40]
   19224:      	stp	q6, q7, [sp, #0x60]
   19228:      	mrs	x19, TPIDR_EL0
   1922c:      	ldr	x8, [x19, #0x28]
   19230:      	stur	x8, [x29, #-0x8]
   19234:      	add	x8, x9, #0x38
   19238:      	add	x9, x29, #0x20
   1923c:      	stp	x9, x8, [x29, #-0x28]
   19240:      	mov	x8, #-0x38              // =-56
   19244:      	sub	x9, x29, #0x28
   19248:      	movk	x8, #0xff80, lsl #32
   1924c:      	stp	x10, x8, [x29, #-0x18]
   19250:      	ldp	q0, q1, [x9]
   19254:      	stp	q0, q1, [x29, #-0x50]
   19258:      	bl	0xe6c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x56ac>
   1925c:      	ldr	x8, [x19, #0x28]
   19260:      	ldur	x9, [x29, #-0x8]
   19264:      	cmp	x8, x9
   19268:      	b.ne	0x1927c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10268>
   1926c:      	ldp	x28, x19, [sp, #0x120]
   19270:      	ldp	x29, x30, [sp, #0x110]
   19274:      	add	sp, sp, #0x130
   19278:      	ret
   1927c:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   19280:      	sub	sp, sp, #0x190
   19284:      	stp	x29, x30, [sp, #0x130]
   19288:      	stp	x28, x27, [sp, #0x140]
   1928c:      	stp	x26, x25, [sp, #0x150]
   19290:      	stp	x24, x23, [sp, #0x160]
   19294:      	stp	x22, x21, [sp, #0x170]
   19298:      	stp	x20, x19, [sp, #0x180]
   1929c:      	add	x29, sp, #0x130
   192a0:      	mrs	x20, TPIDR_EL0
   192a4:      	mov	x22, x1
   192a8:      	mov	w1, wzr
   192ac:      	ldr	x8, [x20, #0x28]
   192b0:      	mov	x21, x2
   192b4:      	stur	x8, [x29, #-0x10]
   192b8:      	bl	0x1d7c0 <__open_2@plt>
   192bc:      	cmn	w0, #0x1
   192c0:      	b.eq	0x195fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x105e8>
   192c4:      	add	x24, sp, #0x20
   192c8:      	mov	x28, #0x2600            // =9728
   192cc:      	mov	w19, w0
   192d0:      	stp	x22, x21, [sp, #0x8]
   192d4:      	mov	w27, #0x1               // =1
   192d8:      	movk	x28, #0x1, lsl #32
   192dc:      	str	x20, [sp, #0x18]
   192e0:      	add	x20, x24, #0x100
   192e4:      	mov	w21, #0xa               // =10
   192e8:      	add	x23, sp, #0x20
   192ec:      	mov	w25, #0x1               // =1
   192f0:      	b	0x19318 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10304>
   192f4:      	mov	x1, x24
   192f8:      	sub	x23, x23, x1
   192fc:      	add	x0, sp, #0x20
   19300:      	mov	w3, #0x100              // =256
   19304:      	mov	x2, x23
   19308:      	bl	0x1d910 <__memmove_chk@plt>
   1930c:      	add	x24, sp, #0x20
   19310:      	add	x23, x24, x23
   19314:      	cbz	x22, 0x19620 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1060c>
   19318:      	sub	x2, x20, x23
   1931c:      	mov	w0, w19
   19320:      	mov	x1, x23
   19324:      	mov	x3, #-0x1               // =-1
   19328:      	bl	0x1d7d0 <__read_chk@plt>
   1932c:      	tbnz	x0, #0x3f, 0x19610 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x105fc>
   19330:      	mov	x22, x0
   19334:      	add	x1, x23, x0
   19338:      	cbz	x0, 0x194c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x104b0>
   1933c:      	cmp	x24, x1
   19340:      	b.eq	0x19544 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10530>
   19344:      	add	x23, x22, x23
   19348:      	add	x24, sp, #0x20
   1934c:      	mov	x26, xzr
   19350:      	neg	x8, x24
   19354:      	ldrb	w9, [x24, x26]
   19358:      	cmp	w9, #0x2c
   1935c:      	b.eq	0x19378 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10364>
   19360:      	add	x26, x26, #0x1
   19364:      	sub	x8, x8, #0x1
   19368:      	add	x9, x24, x26
   1936c:      	cmp	x9, x1
   19370:      	b.ne	0x19354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10340>
   19374:      	b	0x192f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x102e0>
   19378:      	add	x9, x24, x26
   1937c:      	mov	x10, x24
   19380:      	cbz	x26, 0x193b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1039c>
   19384:      	mov	x10, xzr
   19388:      	ldrb	w11, [x24, x10]
   1938c:      	lsl	x12, x27, x11
   19390:      	cmp	w11, #0x20
   19394:      	and	x11, x12, x28
   19398:      	ccmp	x11, #0x0, #0x4, ls
   1939c:      	b.eq	0x19400 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x103ec>
   193a0:      	add	x10, x10, #0x1
   193a4:      	cmp	x26, x10
   193a8:      	b.ne	0x19388 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10374>
   193ac:      	mov	x10, x9
   193b0:      	cmp	x9, x10
   193b4:      	b.eq	0x193e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x103d0>
   193b8:      	mov	x11, x9
   193bc:      	ldrb	w12, [x11, #-0x1]!
   193c0:      	lsl	x13, x27, x12
   193c4:      	cmp	w12, #0x20
   193c8:      	and	x12, x13, x28
   193cc:      	ccmp	x12, #0x0, #0x4, ls
   193d0:      	b.eq	0x19410 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x103fc>
   193d4:      	cmp	x11, x10
   193d8:      	add	x8, x8, #0x1
   193dc:      	mov	x9, x11
   193e0:      	b.ne	0x193bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x103a8>
   193e4:      	mov	w8, wzr
   193e8:      	add	x9, x24, x26
   193ec:      	and	w25, w25, w8
   193f0:      	add	x24, x9, #0x1
   193f4:      	cmp	x24, x1
   193f8:      	b.ne	0x1934c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10338>
   193fc:      	b	0x19544 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10530>
   19400:      	add	x10, x24, x10
   19404:      	cmp	x9, x10
   19408:      	b.ne	0x193b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x103a4>
   1940c:      	b	0x193e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x103d0>
   19410:      	mov	w13, wzr
   19414:      	neg	x11, x8
   19418:      	mov	x12, x10
   1941c:      	cmp	x12, x9
   19420:      	mov	w0, w13
   19424:      	b.eq	0x19440 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1042c>
   19428:      	ldrb	w13, [x12], #0x1
   1942c:      	sub	w14, w13, #0x30
   19430:      	madd	w13, w0, w21, w14
   19434:      	cmp	w14, #0xa
   19438:      	b.lo	0x1941c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10408>
   1943c:      	sub	x11, x12, #0x1
   19440:      	cmp	x11, x10
   19444:      	b.eq	0x193e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x103d0>
   19448:      	cmp	x9, x11
   1944c:      	mov	w10, w0
   19450:      	b.eq	0x194a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10494>
   19454:      	ldrb	w10, [x11]
   19458:      	cmp	w10, #0x2d
   1945c:      	b.ne	0x193e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x103d0>
   19460:      	add	x11, x11, #0x1
   19464:      	mov	w12, wzr
   19468:      	neg	x8, x8
   1946c:      	mov	x13, x11
   19470:      	cmp	x13, x9
   19474:      	mov	w10, w12
   19478:      	b.eq	0x19494 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10480>
   1947c:      	ldrb	w12, [x13], #0x1
   19480:      	sub	w14, w12, #0x30
   19484:      	madd	w12, w10, w21, w14
   19488:      	cmp	w14, #0xa
   1948c:      	b.lo	0x19470 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1045c>
   19490:      	sub	x8, x13, #0x1
   19494:      	cmp	x8, x11
   19498:      	mov	w8, wzr
   1949c:      	b.eq	0x193e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x103d4>
   194a0:      	cmp	w10, w0
   194a4:      	b.lo	0x193e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x103d4>
   194a8:      	ldp	x8, x2, [sp, #0x8]
   194ac:      	str	x1, [sp]
   194b0:      	add	w1, w10, #0x1
   194b4:      	blr	x8
   194b8:      	ldr	x1, [sp]
   194bc:      	mov	w8, w0
   194c0:      	b	0x193e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x103d4>
   194c4:      	add	x8, sp, #0x20
   194c8:      	cmp	x8, x1
   194cc:      	b.eq	0x194fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x104e8>
   194d0:      	add	x8, sp, #0x20
   194d4:      	ldrb	w9, [x8]
   194d8:      	lsl	x10, x27, x9
   194dc:      	cmp	w9, #0x20
   194e0:      	and	x9, x10, x28
   194e4:      	ccmp	x9, #0x0, #0x4, ls
   194e8:      	b.eq	0x194fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x104e8>
   194ec:      	add	x8, x8, #0x1
   194f0:      	cmp	x8, x1
   194f4:      	b.ne	0x194d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x104c0>
   194f8:      	mov	x8, x1
   194fc:      	cmp	x8, x1
   19500:      	b.eq	0x19538 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10524>
   19504:      	add	x9, x22, x23
   19508:      	mov	x10, x1
   1950c:      	neg	x9, x9
   19510:      	ldrb	w11, [x10, #-0x1]!
   19514:      	lsl	x12, x27, x11
   19518:      	cmp	w11, #0x20
   1951c:      	and	x11, x12, x28
   19520:      	ccmp	x11, #0x0, #0x4, ls
   19524:      	b.eq	0x1954c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10538>
   19528:      	cmp	x10, x8
   1952c:      	add	x9, x9, #0x1
   19530:      	mov	x1, x10
   19534:      	b.ne	0x19510 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x104fc>
   19538:      	mov	w8, wzr
   1953c:      	and	w25, w25, wzr
   19540:      	b	0x19314 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10300>
   19544:      	mov	x23, x1
   19548:      	b	0x192f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x102e4>
   1954c:      	mov	w12, wzr
   19550:      	neg	x10, x9
   19554:      	mov	x11, x8
   19558:      	cmp	x11, x1
   1955c:      	mov	w0, w12
   19560:      	b.eq	0x1957c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10568>
   19564:      	ldrb	w12, [x11], #0x1
   19568:      	sub	w13, w12, #0x30
   1956c:      	madd	w12, w0, w21, w13
   19570:      	cmp	w13, #0xa
   19574:      	b.lo	0x19558 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10544>
   19578:      	sub	x10, x11, #0x1
   1957c:      	cmp	x10, x8
   19580:      	b.eq	0x19538 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10524>
   19584:      	cmp	x1, x10
   19588:      	mov	w11, w0
   1958c:      	b.eq	0x195e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x105d0>
   19590:      	ldrb	w8, [x10]
   19594:      	cmp	w8, #0x2d
   19598:      	b.ne	0x19538 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10524>
   1959c:      	add	x8, x10, #0x1
   195a0:      	mov	w12, wzr
   195a4:      	neg	x9, x9
   195a8:      	mov	x10, x8
   195ac:      	cmp	x10, x1
   195b0:      	mov	w11, w12
   195b4:      	b.eq	0x195d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x105bc>
   195b8:      	ldrb	w12, [x10], #0x1
   195bc:      	sub	w13, w12, #0x30
   195c0:      	madd	w12, w11, w21, w13
   195c4:      	cmp	w13, #0xa
   195c8:      	b.lo	0x195ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10598>
   195cc:      	sub	x9, x10, #0x1
   195d0:      	cmp	x9, x8
   195d4:      	mov	w8, wzr
   195d8:      	b.eq	0x195f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x105e0>
   195dc:      	cmp	w11, w0
   195e0:      	b.lo	0x195f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x105e0>
   195e4:      	ldp	x8, x2, [sp, #0x8]
   195e8:      	add	w1, w11, #0x1
   195ec:      	blr	x8
   195f0:      	mov	w8, w0
   195f4:      	and	w25, w25, w8
   195f8:      	b	0x19314 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10300>
   195fc:      	bl	0x1d8e0 <__errno@plt>
   19600:      	ldr	w0, [x0]
   19604:      	bl	0x1d8f0 <strerror@plt>
   19608:      	mov	w25, wzr
   1960c:      	b	0x1962c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10618>
   19610:      	bl	0x1d8e0 <__errno@plt>
   19614:      	ldr	w0, [x0]
   19618:      	bl	0x1d8f0 <strerror@plt>
   1961c:      	mov	w25, wzr
   19620:      	mov	w0, w19
   19624:      	bl	0x1d7e0 <close@plt>
   19628:      	ldr	x20, [sp, #0x18]
   1962c:      	ldr	x8, [x20, #0x28]
   19630:      	ldur	x9, [x29, #-0x10]
   19634:      	cmp	x8, x9
   19638:      	b.ne	0x19660 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1064c>
   1963c:      	and	w0, w25, #0x1
   19640:      	ldp	x20, x19, [sp, #0x180]
   19644:      	ldp	x22, x21, [sp, #0x170]
   19648:      	ldp	x24, x23, [sp, #0x160]
   1964c:      	ldp	x26, x25, [sp, #0x150]
   19650:      	ldp	x28, x27, [sp, #0x140]
   19654:      	ldp	x29, x30, [sp, #0x130]
   19658:      	add	sp, sp, #0x190
   1965c:      	ret
   19660:      	bl	0x1d4a0 <__stack_chk_fail@plt>
   19664:      	paciasp
   19668:      	sub	sp, sp, #0x80
   1966c:      	stp	x29, x30, [sp, #0x50]
   19670:      	stp	x22, x21, [sp, #0x60]
   19674:      	stp	x20, x19, [sp, #0x70]
   19678:      	add	x29, sp, #0x50
   1967c:      	mov	x19, x1
   19680:      	mov	x1, x0
   19684:      	mov	x20, x2
   19688:      	mov	x0, x19
   1968c:      	bl	0x19910 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x108fc>
   19690:      	mov	x0, x19
   19694:      	bl	0x19a34 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10a20>
   19698:      	cbz	w0, 0x19750 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1073c>
   1969c:      	mov	w21, #0x2               // =2
   196a0:      	mov	w22, #0x6               // =6
   196a4:      	b	0x196b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x106a0>
   196a8:      	mov	x0, x19
   196ac:      	bl	0x19a34 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10a20>
   196b0:      	cbz	w0, 0x19750 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1073c>
   196b4:      	tbnz	w0, #0x1f, 0x1977c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10768>
   196b8:      	sub	x2, x29, #0x8
   196bc:      	mov	x0, x19
   196c0:      	mov	w1, #-0x2               // =-2
   196c4:      	bl	0x199b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x109a4>
   196c8:      	mov	x1, sp
   196cc:      	mov	x0, x19
   196d0:      	bl	0x19a48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10a34>
   196d4:      	cbnz	w0, 0x1977c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10768>
   196d8:      	ldr	x8, [sp, #0x18]
   196dc:      	cbz	x8, 0x196a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10694>
   196e0:      	ldur	x9, [x29, #-0x8]
   196e4:      	ldr	x10, [x20, #0x18]
   196e8:      	mov	w0, #0x1                // =1
   196ec:      	ldr	x2, [x20]
   196f0:      	mov	x3, x20
   196f4:      	mov	x4, x19
   196f8:      	cmp	x9, x10
   196fc:      	csel	w1, w22, w21, eq
   19700:      	blr	x8
   19704:      	cmp	w0, #0x8
   19708:      	b.ne	0x1976c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10758>
   1970c:      	ldur	x8, [x29, #-0x8]
   19710:      	ldr	x9, [x20, #0x18]
   19714:      	cmp	x8, x9
   19718:      	b.ne	0x196a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10694>
   1971c:      	adrp	x19, 0x22000
   19720:      	nop
   19724:      	adr	x1, 0x2bb3
   19728:      	ldr	x19, [x19, #0x108]
   1972c:      	adrp	x2, 0x3000
   19730:      	add	x2, x2, #0x7ca
   19734:      	adrp	x3, 0x3000
   19738:      	add	x3, x3, #0xef0
   1973c:      	add	x0, x19, #0x130
   19740:      	bl	0x1d5a0 <fprintf@plt>
   19744:      	add	x0, x19, #0x130
   19748:      	bl	0x1d920 <fflush@plt>
   1974c:      	bl	0x1d4d0 <abort@plt>
   19750:      	mov	w0, #0x5                // =5
   19754:      	ldp	x20, x19, [sp, #0x70]
   19758:      	ldp	x22, x21, [sp, #0x60]
   1975c:      	ldp	x29, x30, [sp, #0x50]
   19760:      	add	sp, sp, #0x80
   19764:      	autiasp
   19768:      	ret
   1976c:      	cmp	w0, #0x7
   19770:      	b.ne	0x1977c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10768>
   19774:      	mov	x0, x19
   19778:      	bl	0x19a88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10a74>
   1977c:      	mov	w0, #0x2                // =2
   19780:      	ldp	x20, x19, [sp, #0x70]
   19784:      	ldp	x22, x21, [sp, #0x60]
   19788:      	ldp	x29, x30, [sp, #0x50]
   1978c:      	add	sp, sp, #0x80
   19790:      	autiasp
   19794:      	ret
   19798:      	paciasp
   1979c:      	stp	x29, x30, [sp, #-0x20]!
   197a0:      	stp	x28, x19, [sp, #0x10]
   197a4:      	mov	x29, sp
   197a8:      	sub	sp, sp, #0x480
   197ac:      	mov	x19, x0
   197b0:      	add	x0, sp, #0x270
   197b4:      	bl	0x1d3bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x143a8>
   197b8:      	ldr	x3, [x19, #0x10]
   197bc:      	cbnz	x3, 0x197d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x107c0>
   197c0:      	add	x0, sp, #0x270
   197c4:      	mov	x1, sp
   197c8:      	mov	x2, x19
   197cc:      	bl	0x19664 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10650>
   197d0:      	b	0x197e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x107d4>
   197d4:      	ldr	x4, [x19, #0x18]
   197d8:      	add	x0, sp, #0x270
   197dc:      	mov	x1, sp
   197e0:      	mov	x2, x19
   197e4:      	bl	0x1981c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10808>
   197e8:      	adrp	x19, 0x22000
   197ec:      	nop
   197f0:      	adr	x1, 0x2bb3
   197f4:      	ldr	x19, [x19, #0x108]
   197f8:      	adrp	x2, 0x4000
   197fc:      	add	x2, x2, #0x90e
   19800:      	adrp	x3, 0x2000
   19804:      	add	x3, x3, #0xf0d
   19808:      	add	x0, x19, #0x130
   1980c:      	bl	0x1d5a0 <fprintf@plt>
   19810:      	add	x0, x19, #0x130
   19814:      	bl	0x1d920 <fflush@plt>
   19818:      	bl	0x1d4d0 <abort@plt>
   1981c:      	paciasp
   19820:      	sub	sp, sp, #0x80
   19824:      	stp	x29, x30, [sp, #0x50]
   19828:      	stp	x22, x21, [sp, #0x60]
   1982c:      	stp	x20, x19, [sp, #0x70]
   19830:      	add	x29, sp, #0x50
   19834:      	mov	x21, x1
   19838:      	mov	x1, x0
   1983c:      	mov	x20, x4
   19840:      	mov	x0, x21
   19844:      	mov	x19, x3
   19848:      	mov	x22, x2
   1984c:      	bl	0x19910 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x108fc>
   19850:      	mov	x0, x21
   19854:      	bl	0x19a34 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10a20>
   19858:      	cmp	w0, #0x1
   1985c:      	b.ge	0x198a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10890>
   19860:      	ldr	x2, [x22]
   19864:      	mov	w0, #0x1                // =1
   19868:      	mov	w1, #0x1a               // =26
   1986c:      	mov	x3, x22
   19870:      	mov	x4, x21
   19874:      	mov	x5, x20
   19878:      	blr	x19
   1987c:      	ldp	x20, x19, [sp, #0x70]
   19880:      	ldp	x22, x21, [sp, #0x60]
   19884:      	ldp	x29, x30, [sp, #0x50]
   19888:      	add	sp, sp, #0x80
   1988c:      	autiasp
   19890:      	ret
   19894:      	mov	x0, x21
   19898:      	bl	0x19a34 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10a20>
   1989c:      	cmp	w0, #0x0
   198a0:      	b.le	0x19860 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1084c>
   198a4:      	add	x1, sp, #0x8
   198a8:      	mov	x0, x21
   198ac:      	bl	0x19a48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10a34>
   198b0:      	cbnz	w0, 0x1987c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10868>
   198b4:      	ldr	x2, [x22]
   198b8:      	mov	w0, #0x1                // =1
   198bc:      	mov	w1, #0xa                // =10
   198c0:      	mov	x3, x22
   198c4:      	mov	x4, x21
   198c8:      	mov	x5, x20
   198cc:      	blr	x19
   198d0:      	cbnz	w0, 0x1987c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10868>
   198d4:      	ldr	x8, [sp, #0x20]
   198d8:      	cbz	x8, 0x19894 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10880>
   198dc:      	ldr	x2, [x22]
   198e0:      	mov	w0, #0x1                // =1
   198e4:      	mov	w1, #0xa                // =10
   198e8:      	mov	x3, x22
   198ec:      	mov	x4, x21
   198f0:      	blr	x8
   198f4:      	cmp	w0, #0x8
   198f8:      	b.eq	0x19894 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10880>
   198fc:      	cmp	w0, #0x7
   19900:      	b.ne	0x1987c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10868>
   19904:      	mov	x0, x21
   19908:      	bl	0x19a88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10a74>
   1990c:      	b	0x19894 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10880>
   19910:      	paciasp
   19914:      	stp	x29, x30, [sp, #-0x20]!
   19918:      	stp	x20, x19, [sp, #0x10]
   1991c:      	mov	x29, sp
   19920:      	adrp	x8, 0x21000 <getpid@plt+0x3690>
   19924:      	add	x8, x8, #0xe70
   19928:      	nop
   1992c:      	adr	x9, 0x269d4
   19930:      	mov	w2, #0x110              // =272
   19934:      	mov	x20, x1
   19938:      	mov	x19, x0
   1993c:      	stp	x8, x9, [x0], #0x10
   19940:      	bl	0x1d540 <memcpy@plt>
   19944:      	ldp	q1, q0, [x20, #0x130]
   19948:      	add	x8, x19, #0x220
   1994c:      	ldp	q3, q2, [x20, #0x110]
   19950:      	mov	x0, x19
   19954:      	mov	w1, wzr
   19958:      	stp	q1, q0, [x19, #0x140]
   1995c:      	stp	q3, q2, [x19, #0x120]
   19960:      	ldp	q1, q0, [x20, #0x170]
   19964:      	ldp	q3, q2, [x20, #0x150]
   19968:      	stp	q1, q0, [x19, #0x180]
   1996c:      	stp	q3, q2, [x19, #0x160]
   19970:      	ldp	q1, q0, [x20, #0x1b0]
   19974:      	ldp	q3, q2, [x20, #0x190]
   19978:      	stp	q1, q0, [x19, #0x1c0]
   1997c:      	stp	q3, q2, [x19, #0x1a0]
   19980:      	movi	v2.2d, #0000000000000000
   19984:      	ldp	q1, q0, [x20, #0x1f0]
   19988:      	ldp	q4, q3, [x20, #0x1d0]
   1998c:      	stp	q1, q0, [x19, #0x200]
   19990:      	stp	q4, q3, [x19, #0x1e0]
   19994:      	stur	q2, [x8, #0x3b]
   19998:      	stp	q2, q2, [x19, #0x220]
   1999c:      	stp	q2, q2, [x19, #0x240]
   199a0:      	bl	0x1a2d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x112c4>
   199a4:      	mov	w0, wzr
   199a8:      	ldp	x20, x19, [sp, #0x10]
   199ac:      	ldp	x29, x30, [sp], #0x20
   199b0:      	autiasp
   199b4:      	ret
   199b8:      	paciasp
   199bc:      	stp	x29, x30, [sp, #-0x30]!
   199c0:      	str	x21, [sp, #0x10]
   199c4:      	stp	x20, x19, [sp, #0x20]
   199c8:      	mov	x29, sp
   199cc:      	ldr	x8, [x0]
   199d0:      	mov	x19, x2
   199d4:      	mov	x20, x0
   199d8:      	mov	w21, w1
   199dc:      	ldr	x8, [x8, #0x10]
   199e0:      	blr	x8
   199e4:      	tbz	w0, #0x0, 0x19a1c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10a08>
   199e8:      	ldr	x8, [x20]
   199ec:      	mov	x0, x20
   199f0:      	mov	w1, w21
   199f4:      	ldr	x8, [x8, #0x18]
   199f8:      	blr	x8
   199fc:      	mov	x8, x0
   19a00:      	mov	w0, wzr
   19a04:      	str	x8, [x19]
   19a08:      	ldp	x20, x19, [sp, #0x20]
   19a0c:      	ldr	x21, [sp, #0x10]
   19a10:      	ldp	x29, x30, [sp], #0x30
   19a14:      	autiasp
   19a18:      	ret
   19a1c:      	mov	w0, #-0x198e            // =-6542
   19a20:      	ldp	x20, x19, [sp, #0x20]
   19a24:      	ldr	x21, [sp, #0x10]
   19a28:      	ldp	x29, x30, [sp], #0x30
   19a2c:      	autiasp
   19a30:      	ret
   19a34:      	bti	c
   19a38:      	ldr	x8, [x0]
   19a3c:      	mov	w1, #0x1                // =1
   19a40:      	ldr	x16, [x8, #0x40]
   19a44:      	br	x16
   19a48:      	paciasp
   19a4c:      	stp	x29, x30, [sp, #-0x20]!
   19a50:      	str	x19, [sp, #0x10]
   19a54:      	mov	x29, sp
   19a58:      	ldr	x8, [x0]
   19a5c:      	mov	x19, x1
   19a60:      	ldr	x8, [x8, #0x48]
   19a64:      	blr	x8
   19a68:      	ldr	x8, [x19, #0x8]
   19a6c:      	cmp	x8, #0x0
   19a70:      	mov	w8, #-0x1995            // =-6549
   19a74:      	csel	w0, w8, wzr, eq
   19a78:      	ldr	x19, [sp, #0x10]
   19a7c:      	ldp	x29, x30, [sp], #0x20
   19a80:      	autiasp
   19a84:      	ret
   19a88:      	paciasp
   19a8c:      	stp	x29, x30, [sp, #-0x10]!
   19a90:      	mov	x29, sp
   19a94:      	ldr	x8, [x0]
   19a98:      	ldr	x8, [x8, #0x50]
   19a9c:      	blr	x8
   19aa0:      	mov	w0, #-0x198c            // =-6540
   19aa4:      	ldp	x29, x30, [sp], #0x10
   19aa8:      	autiasp
   19aac:      	ret
   19ab0:      	paciasp
   19ab4:      	stp	x29, x30, [sp, #-0x60]!
   19ab8:      	str	x27, [sp, #0x10]
   19abc:      	stp	x26, x25, [sp, #0x20]
   19ac0:      	stp	x24, x23, [sp, #0x30]
   19ac4:      	stp	x22, x21, [sp, #0x40]
   19ac8:      	stp	x20, x19, [sp, #0x50]
   19acc:      	mov	x29, sp
   19ad0:      	mov	x23, x1
   19ad4:      	mov	x20, x3
   19ad8:      	mov	x19, x2
   19adc:      	ldr	w22, [x23], #0x4
   19ae0:      	mov	x21, x0
   19ae4:      	cmn	w22, #0x1
   19ae8:      	b.eq	0x19b1c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10b08>
   19aec:      	cbz	x22, 0x19b28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10b14>
   19af0:      	ldr	w8, [x23]
   19af4:      	cbz	w8, 0x19b34 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10b20>
   19af8:      	mov	x25, x1
   19afc:      	sub	x1, x23, x8
   19b00:      	tbz	w4, #0x0, 0x19b40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10b2c>
   19b04:      	ldr	x8, [x20]
   19b08:      	cmp	x8, x1
   19b0c:      	b.eq	0x19b50 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10b3c>
   19b10:      	adrp	x0, 0x4000
   19b14:      	add	x0, x0, #0x9f6
   19b18:      	b	0x19c20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10c0c>
   19b1c:      	ldur	x22, [x1, #0x4]
   19b20:      	add	x23, x1, #0xc
   19b24:      	cbnz	x22, 0x19af0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10adc>
   19b28:      	adrp	x0, 0x3000
   19b2c:      	add	x0, x0, #0x200
   19b30:      	b	0x19c20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10c0c>
   19b34:      	adrp	x0, 0x3000
   19b38:      	add	x0, x0, #0xa0f
   19b3c:      	b	0x19c20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10c0c>
   19b40:      	mov	x0, x21
   19b44:      	mov	x2, x20
   19b48:      	bl	0x19c40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10c2c>
   19b4c:      	cbnz	x0, 0x19c20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10c0c>
   19b50:      	ldrb	w3, [x20, #0x18]
   19b54:      	add	x22, x23, x22
   19b58:      	add	x8, x23, #0x4
   19b5c:      	add	x1, x29, #0x18
   19b60:      	mov	x0, x21
   19b64:      	mov	x2, x22
   19b68:      	mov	x4, xzr
   19b6c:      	str	x8, [x29, #0x18]
   19b70:      	bl	0x1ba98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a84>
   19b74:      	ldrb	w8, [x20, #0x18]
   19b78:      	mov	x23, x0
   19b7c:      	add	x1, x29, #0x18
   19b80:      	mov	x0, x21
   19b84:      	mov	x2, x22
   19b88:      	mov	x4, xzr
   19b8c:      	and	w3, w8, #0xf
   19b90:      	bl	0x1ba98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a84>
   19b94:      	ldrb	w8, [x20, #0x31]
   19b98:      	mov	x24, x0
   19b9c:      	str	xzr, [x19, #0x28]
   19ba0:      	cbz	w8, 0x19c04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10bf0>
   19ba4:      	add	x0, x29, #0x18
   19ba8:      	mov	x1, x22
   19bac:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   19bb0:      	ldrb	w8, [x20, #0x19]
   19bb4:      	ldr	x27, [x29, #0x18]
   19bb8:      	cmp	w8, #0xff
   19bbc:      	add	x26, x27, x0
   19bc0:      	b.eq	0x19c08 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10bf4>
   19bc4:      	add	x1, x29, #0x18
   19bc8:      	and	w3, w8, #0xf
   19bcc:      	mov	x0, x21
   19bd0:      	mov	x2, x22
   19bd4:      	mov	x4, xzr
   19bd8:      	bl	0x1ba98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a84>
   19bdc:      	cbz	x0, 0x19c08 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10bf4>
   19be0:      	ldrb	w3, [x20, #0x19]
   19be4:      	add	x1, x29, #0x18
   19be8:      	mov	x0, x21
   19bec:      	mov	x2, x22
   19bf0:      	mov	x4, xzr
   19bf4:      	str	x27, [x29, #0x18]
   19bf8:      	bl	0x1ba98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a84>
   19bfc:      	str	x0, [x19, #0x28]
   19c00:      	b	0x19c08 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10bf4>
   19c04:      	ldr	x26, [x29, #0x18]
   19c08:      	sub	x8, x22, x25
   19c0c:      	mov	x0, xzr
   19c10:      	stp	x26, x23, [x19, #0x10]
   19c14:      	stp	x25, x8, [x19]
   19c18:      	add	x8, x24, x23
   19c1c:      	str	x8, [x19, #0x20]
   19c20:      	ldp	x20, x19, [sp, #0x50]
   19c24:      	ldr	x27, [sp, #0x10]
   19c28:      	ldp	x22, x21, [sp, #0x40]
   19c2c:      	ldp	x24, x23, [sp, #0x30]
   19c30:      	ldp	x26, x25, [sp, #0x20]
   19c34:      	ldp	x29, x30, [sp], #0x60
   19c38:      	autiasp
   19c3c:      	ret
   19c40:      	paciasp
   19c44:      	sub	sp, sp, #0x50
   19c48:      	stp	x29, x30, [sp, #0x10]
   19c4c:      	stp	x24, x23, [sp, #0x20]
   19c50:      	stp	x22, x21, [sp, #0x30]
   19c54:      	stp	x20, x19, [sp, #0x40]
   19c58:      	add	x29, sp, #0x10
   19c5c:      	movi	d0, #0x00ff000000ff00
   19c60:      	sturh	wzr, [x2, #0x33]
   19c64:      	mov	x8, x1
   19c68:      	stp	xzr, xzr, [x2, #0x20]
   19c6c:      	mov	x19, x2
   19c70:      	mov	x20, x1
   19c74:      	strh	wzr, [x2, #0x30]
   19c78:      	mov	x21, x0
   19c7c:      	str	x1, [x2]
   19c80:      	str	s0, [x2, #0x18]
   19c84:      	ldr	w9, [x8], #0x4
   19c88:      	cmn	w9, #0x1
   19c8c:      	b.eq	0x19cac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10c98>
   19c90:      	add	x22, x8, x9
   19c94:      	cbz	x9, 0x19cbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10ca8>
   19c98:      	ldr	w9, [x8]
   19c9c:      	cbz	w9, 0x19cc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10cb0>
   19ca0:      	adrp	x0, 0x4000
   19ca4:      	add	x0, x0, #0x961
   19ca8:      	b	0x19eb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10ea4>
   19cac:      	ldur	x9, [x20, #0x4]
   19cb0:      	add	x8, x20, #0xc
   19cb4:      	add	x22, x9, x8
   19cb8:      	cbnz	x9, 0x19c98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10c84>
   19cbc:      	mov	x0, xzr
   19cc0:      	b	0x19eb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10ea4>
   19cc4:      	ldrb	w24, [x8, #0x4]
   19cc8:      	and	w9, w24, #0xfffffffd
   19ccc:      	cmp	w9, #0x1
   19cd0:      	b.ne	0x19d7c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10d68>
   19cd4:      	add	x23, x8, #0x5
   19cd8:      	mov	x8, x23
   19cdc:      	ldrb	w9, [x8], #0x1
   19ce0:      	cbnz	w9, 0x19cdc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10cc8>
   19ce4:      	add	x0, sp, #0x8
   19ce8:      	mov	x1, x22
   19cec:      	str	x8, [sp, #0x8]
   19cf0:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   19cf4:      	ldr	x8, [sp, #0x8]
   19cf8:      	mov	x11, xzr
   19cfc:      	mov	x9, xzr
   19d00:      	str	w0, [x19, #0x28]
   19d04:      	mov	x10, x8
   19d08:      	cmp	x10, x22
   19d0c:      	b.eq	0x19ed4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10ec0>
   19d10:      	ldrb	w12, [x10], #0x1
   19d14:      	add	x8, x8, #0x1
   19d18:      	and	x13, x12, #0x7f
   19d1c:      	lsl	x13, x13, x11
   19d20:      	add	x11, x11, #0x7
   19d24:      	orr	x9, x13, x9
   19d28:      	tbnz	w12, #0x7, 0x19d08 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10cf4>
   19d2c:      	sub	w13, w11, #0x7
   19d30:      	mov	x14, #-0x1              // =-1
   19d34:      	str	x8, [sp, #0x8]
   19d38:      	cmp	w13, #0x39
   19d3c:      	mov	w13, #0x3f              // =63
   19d40:      	lsl	x11, x14, x11
   19d44:      	ccmp	w12, w13, #0x0, lo
   19d48:      	csel	w11, w11, wzr, hi
   19d4c:      	cmp	w24, #0x1
   19d50:      	orr	w9, w9, w11
   19d54:      	str	w9, [x19, #0x2c]
   19d58:      	b.ne	0x19d88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10d74>
   19d5c:      	add	x8, x8, #0x1
   19d60:      	str	x8, [sp, #0x8]
   19d64:      	ldrb	w0, [x10]
   19d68:      	strb	w0, [x19, #0x32]
   19d6c:      	ldrb	w8, [x23]
   19d70:      	cmp	w8, #0x7a
   19d74:      	b.eq	0x19da4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10d90>
   19d78:      	b	0x19ea4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10e90>
   19d7c:      	adrp	x0, 0x2000
   19d80:      	add	x0, x0, #0xe50
   19d84:      	b	0x19eb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10ea4>
   19d88:      	add	x0, sp, #0x8
   19d8c:      	mov	x1, x22
   19d90:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   19d94:      	strb	w0, [x19, #0x32]
   19d98:      	ldrb	w8, [x23]
   19d9c:      	cmp	w8, #0x7a
   19da0:      	b.ne	0x19ea4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10e90>
   19da4:      	add	x0, sp, #0x8
   19da8:      	mov	x1, x22
   19dac:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   19db0:      	mov	w24, #0x1               // =1
   19db4:      	b	0x19dc0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10dac>
   19db8:      	strb	w24, [x19, #0x30]
   19dbc:      	add	x23, x23, #0x1
   19dc0:      	ldrb	w8, [x23]
   19dc4:      	cmp	w8, #0x4f
   19dc8:      	b.le	0x19dfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10de8>
   19dcc:      	cmp	w8, #0x52
   19dd0:      	b.gt	0x19e2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10e18>
   19dd4:      	cmp	w8, #0x50
   19dd8:      	b.eq	0x19e68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10e54>
   19ddc:      	cmp	w8, #0x52
   19de0:      	b.ne	0x19e60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10e4c>
   19de4:      	ldr	x8, [sp, #0x8]
   19de8:      	add	x23, x23, #0x1
   19dec:      	ldrb	w9, [x8], #0x1
   19df0:      	str	x8, [sp, #0x8]
   19df4:      	strb	w9, [x19, #0x18]
   19df8:      	b	0x19dc0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10dac>
   19dfc:      	cmp	w8, #0x46
   19e00:      	b.le	0x19e48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10e34>
   19e04:      	cmp	w8, #0x47
   19e08:      	b.eq	0x19e5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10e48>
   19e0c:      	cmp	w8, #0x4c
   19e10:      	b.ne	0x19e60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10e4c>
   19e14:      	ldr	x8, [sp, #0x8]
   19e18:      	add	x23, x23, #0x1
   19e1c:      	ldrb	w9, [x8], #0x1
   19e20:      	str	x8, [sp, #0x8]
   19e24:      	strb	w9, [x19, #0x19]
   19e28:      	b	0x19dc0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10dac>
   19e2c:      	cmp	w8, #0x53
   19e30:      	b.eq	0x19db8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10da4>
   19e34:      	cmp	w8, #0x7a
   19e38:      	b.ne	0x19e60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10e4c>
   19e3c:      	strb	w24, [x19, #0x31]
   19e40:      	add	x23, x23, #0x1
   19e44:      	b	0x19dc0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10dac>
   19e48:      	cmp	w8, #0x42
   19e4c:      	b.ne	0x19ea0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10e8c>
   19e50:      	strb	w24, [x19, #0x33]
   19e54:      	add	x23, x23, #0x1
   19e58:      	b	0x19dc0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10dac>
   19e5c:      	strb	w24, [x19, #0x34]
   19e60:      	add	x23, x23, #0x1
   19e64:      	b	0x19dc0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10dac>
   19e68:      	ldr	x8, [sp, #0x8]
   19e6c:      	add	x1, sp, #0x8
   19e70:      	mov	x0, x21
   19e74:      	mov	x2, x22
   19e78:      	mov	x4, xzr
   19e7c:      	ldrb	w3, [x8], #0x1
   19e80:      	str	x8, [sp, #0x8]
   19e84:      	sub	w8, w8, w20
   19e88:      	strb	w3, [x19, #0x1a]
   19e8c:      	strb	w8, [x19, #0x1b]
   19e90:      	bl	0x1ba98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a84>
   19e94:      	str	x0, [x19, #0x20]
   19e98:      	add	x23, x23, #0x1
   19e9c:      	b	0x19dc0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10dac>
   19ea0:      	cbnz	w8, 0x19e60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10e4c>
   19ea4:      	ldr	x8, [x19]
   19ea8:      	ldr	x9, [sp, #0x8]
   19eac:      	mov	x0, xzr
   19eb0:      	sub	x8, x22, x8
   19eb4:      	stp	x8, x9, [x19, #0x8]
   19eb8:      	ldp	x20, x19, [sp, #0x40]
   19ebc:      	ldp	x22, x21, [sp, #0x30]
   19ec0:      	ldp	x24, x23, [sp, #0x20]
   19ec4:      	ldp	x29, x30, [sp, #0x10]
   19ec8:      	add	sp, sp, #0x50
   19ecc:      	autiasp
   19ed0:      	ret
   19ed4:      	adrp	x19, 0x22000
   19ed8:      	nop
   19edc:      	adr	x1, 0x2bb3
   19ee0:      	ldr	x19, [x19, #0x108]
   19ee4:      	adrp	x2, 0x3000
   19ee8:      	add	x2, x2, #0xe10
   19eec:      	adrp	x3, 0x3000
   19ef0:      	add	x3, x3, #0x63f
   19ef4:      	add	x0, x19, #0x130
   19ef8:      	bl	0x1d5a0 <fprintf@plt>
   19efc:      	add	x0, x19, #0x130
   19f00:      	bl	0x1d920 <fflush@plt>
   19f04:      	bl	0x1d4d0 <abort@plt>
   19f08:      	bti	c
   19f0c:      	ret
   19f10:      	bti	c
   19f14:      	ret
   19f18:      	bti	c
   19f1c:      	cmn	w1, #0x3
   19f20:      	b.ls	0x19f2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10f18>
   19f24:      	mov	w0, #0x1                // =1
   19f28:      	ret
   19f2c:      	cmp	w1, #0x5f
   19f30:      	b.ls	0x19f3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10f28>
   19f34:      	mov	w0, wzr
   19f38:      	ret
   19f3c:      	cmp	w1, #0x22
   19f40:      	b.ne	0x19f4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10f38>
   19f44:      	mov	w0, #0x1                // =1
   19f48:      	ret
   19f4c:      	sub	w8, w1, #0x40
   19f50:      	cmn	w8, #0x1f
   19f54:      	cset	w0, lo
   19f58:      	ret
   19f5c:      	bti	c
   19f60:      	cmp	w1, #0x1d
   19f64:      	b.le	0x19f84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10f70>
   19f68:      	cmp	w1, #0x1f
   19f6c:      	b.gt	0x19fa8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10f94>
   19f70:      	cmp	w1, #0x1e
   19f74:      	b.eq	0x19fe8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10fd4>
   19f78:      	cmp	w1, #0x1f
   19f7c:      	b.eq	0x19fc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10fb0>
   19f80:      	b	0x19fd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10fbc>
   19f84:      	cmn	w1, #0x2
   19f88:      	b.eq	0x19fc4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10fb0>
   19f8c:      	cmn	w1, #0x1
   19f90:      	b.eq	0x19fb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10fa4>
   19f94:      	cmp	w1, #0x1d
   19f98:      	b.ne	0x19fd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10fbc>
   19f9c:      	add	x8, x0, #0xf8
   19fa0:      	ldr	x0, [x8]
   19fa4:      	ret
   19fa8:      	cmp	w1, #0x22
   19fac:      	b.eq	0x19ff4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10fe0>
   19fb0:      	cmp	w1, #0x20
   19fb4:      	b.ne	0x19fd0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10fbc>
   19fb8:      	add	x8, x0, #0x110
   19fbc:      	ldr	x0, [x8]
   19fc0:      	ret
   19fc4:      	add	x8, x0, #0x108
   19fc8:      	ldr	x0, [x8]
   19fcc:      	ret
   19fd0:      	cmp	w1, #0x1c
   19fd4:      	b.hi	0x1a000 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10fec>
   19fd8:      	add	x8, x0, #0x10
   19fdc:      	add	x8, x8, w1, uxtw #3
   19fe0:      	ldr	x0, [x8]
   19fe4:      	ret
   19fe8:      	add	x8, x0, #0x100
   19fec:      	ldr	x0, [x8]
   19ff0:      	ret
   19ff4:      	add	x8, x0, #0x118
   19ff8:      	ldr	x0, [x8]
   19ffc:      	ret
   1a000:      	paciasp
   1a004:      	stp	x29, x30, [sp, #-0x20]!
   1a008:      	str	x19, [sp, #0x10]
   1a00c:      	mov	x29, sp
   1a010:      	adrp	x19, 0x22000
   1a014:      	nop
   1a018:      	adr	x1, 0x2bb3
   1a01c:      	ldr	x19, [x19, #0x108]
   1a020:      	adrp	x2, 0x3000
   1a024:      	add	x2, x2, #0x9fb
   1a028:      	adrp	x3, 0x3000
   1a02c:      	add	x3, x3, #0x479
   1a030:      	add	x0, x19, #0x130
   1a034:      	bl	0x1d5a0 <fprintf@plt>
   1a038:      	add	x0, x19, #0x130
   1a03c:      	bl	0x1d920 <fflush@plt>
   1a040:      	bl	0x1d4d0 <abort@plt>
   1a044:      	bti	c
   1a048:      	cmp	w1, #0x1d
   1a04c:      	b.le	0x1a06c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11058>
   1a050:      	cmp	w1, #0x1f
   1a054:      	b.gt	0x1a090 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1107c>
   1a058:      	cmp	w1, #0x1e
   1a05c:      	b.eq	0x1a0d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x110bc>
   1a060:      	cmp	w1, #0x1f
   1a064:      	b.eq	0x1a0ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11098>
   1a068:      	b	0x1a0b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x110a4>
   1a06c:      	cmn	w1, #0x2
   1a070:      	b.eq	0x1a0ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11098>
   1a074:      	cmn	w1, #0x1
   1a078:      	b.eq	0x1a0a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1108c>
   1a07c:      	cmp	w1, #0x1d
   1a080:      	b.ne	0x1a0b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x110a4>
   1a084:      	add	x8, x0, #0xf8
   1a088:      	str	x2, [x8]
   1a08c:      	ret
   1a090:      	cmp	w1, #0x22
   1a094:      	b.eq	0x1a0dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x110c8>
   1a098:      	cmp	w1, #0x20
   1a09c:      	b.ne	0x1a0b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x110a4>
   1a0a0:      	add	x8, x0, #0x110
   1a0a4:      	str	x2, [x8]
   1a0a8:      	ret
   1a0ac:      	add	x8, x0, #0x108
   1a0b0:      	str	x2, [x8]
   1a0b4:      	ret
   1a0b8:      	cmp	w1, #0x1c
   1a0bc:      	b.hi	0x1a0e8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x110d4>
   1a0c0:      	add	x8, x0, #0x10
   1a0c4:      	add	x8, x8, w1, uxtw #3
   1a0c8:      	str	x2, [x8]
   1a0cc:      	ret
   1a0d0:      	add	x8, x0, #0x100
   1a0d4:      	str	x2, [x8]
   1a0d8:      	ret
   1a0dc:      	add	x8, x0, #0x118
   1a0e0:      	str	x2, [x8]
   1a0e4:      	ret
   1a0e8:      	paciasp
   1a0ec:      	stp	x29, x30, [sp, #-0x20]!
   1a0f0:      	str	x19, [sp, #0x10]
   1a0f4:      	mov	x29, sp
   1a0f8:      	adrp	x19, 0x22000
   1a0fc:      	nop
   1a100:      	adr	x1, 0x2bb3
   1a104:      	ldr	x19, [x19, #0x108]
   1a108:      	adrp	x2, 0x4000
   1a10c:      	add	x2, x2, #0x164
   1a110:      	adrp	x3, 0x3000
   1a114:      	add	x3, x3, #0x479
   1a118:      	add	x0, x19, #0x130
   1a11c:      	bl	0x1d5a0 <fprintf@plt>
   1a120:      	add	x0, x19, #0x130
   1a124:      	bl	0x1d920 <fflush@plt>
   1a128:      	bl	0x1d4d0 <abort@plt>
   1a12c:      	bti	c
   1a130:      	and	w8, w1, #0xffffffe0
   1a134:      	cmp	w8, #0x40
   1a138:      	cset	w0, eq
   1a13c:      	ret
   1a140:      	bti	c
   1a144:      	add	x8, x0, w1, sxtw #3
   1a148:      	ldur	d0, [x8, #-0xe0]
   1a14c:      	ret
   1a150:      	bti	c
   1a154:      	add	x8, x0, w1, sxtw #3
   1a158:      	stur	d0, [x8, #-0xe0]
   1a15c:      	ret
   1a160:      	bti	c
   1a164:      	ldrb	w8, [x0, #0x268]
   1a168:      	cbz	w8, 0x1a174 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11160>
   1a16c:      	mov	w0, wzr
   1a170:      	ret
   1a174:      	paciasp
   1a178:      	stp	x29, x30, [sp, #-0x30]!
   1a17c:      	stp	x28, x21, [sp, #0x10]
   1a180:      	stp	x20, x19, [sp, #0x20]
   1a184:      	mov	x29, sp
   1a188:      	sub	sp, sp, #0x210
   1a18c:      	ldrb	w8, [x0, #0x26a]
   1a190:      	mov	x19, x0
   1a194:      	cbz	w8, 0x1a1d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x111c0>
   1a198:      	mov	x0, sp
   1a19c:      	mov	w1, wzr
   1a1a0:      	mov	w2, #0x210              // =528
   1a1a4:      	bl	0x1d5b0 <memset@plt>
   1a1a8:      	mov	x1, sp
   1a1ac:      	mov	x0, x19
   1a1b0:      	bl	0x1a564 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11550>
   1a1b4:      	cmp	w0, #0x1
   1a1b8:      	b.eq	0x1a210 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x111fc>
   1a1bc:      	add	sp, sp, #0x210
   1a1c0:      	ldp	x20, x19, [sp, #0x20]
   1a1c4:      	ldp	x28, x21, [sp, #0x10]
   1a1c8:      	ldp	x29, x30, [sp], #0x30
   1a1cc:      	autiasp
   1a1d0:      	ret
   1a1d4:      	ldp	x8, x20, [x19]
   1a1d8:      	mov	x0, x19
   1a1dc:      	mov	w21, w1
   1a1e0:      	mov	w1, #-0x1               // =-1
   1a1e4:      	ldr	x8, [x8, #0x18]
   1a1e8:      	blr	x8
   1a1ec:      	ldr	x2, [x19, #0x258]
   1a1f0:      	mov	x1, x0
   1a1f4:      	add	x3, x19, #0x10
   1a1f8:      	add	x4, x19, #0x269
   1a1fc:      	and	w5, w21, #0x1
   1a200:      	mov	x0, x20
   1a204:      	bl	0x1a684 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11670>
   1a208:      	cmp	w0, #0x1
   1a20c:      	b.ne	0x1a1bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x111a8>
   1a210:      	ldr	x8, [x19]
   1a214:      	mov	w20, w0
   1a218:      	mov	x0, x19
   1a21c:      	mov	w1, #0x1                // =1
   1a220:      	ldr	x8, [x8, #0x68]
   1a224:      	blr	x8
   1a228:      	ldrb	w8, [x19, #0x268]
   1a22c:      	mov	w0, w20
   1a230:      	cbz	w8, 0x1a1bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x111a8>
   1a234:      	mov	w0, wzr
   1a238:      	add	sp, sp, #0x210
   1a23c:      	ldp	x20, x19, [sp, #0x20]
   1a240:      	ldp	x28, x21, [sp, #0x10]
   1a244:      	ldp	x29, x30, [sp], #0x30
   1a248:      	autiasp
   1a24c:      	ret
   1a250:      	bti	c
   1a254:      	ldrb	w8, [x0, #0x268]
   1a258:      	cbz	w8, 0x1a270 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1125c>
   1a25c:      	movi	v0.2d, #0000000000000000
   1a260:      	str	xzr, [x1, #0x40]
   1a264:      	stp	q0, q0, [x1]
   1a268:      	stp	q0, q0, [x1, #0x20]
   1a26c:      	ret
   1a270:      	ldr	q0, [x0, #0x220]
   1a274:      	str	q0, [x1]
   1a278:      	ldp	q2, q0, [x0, #0x240]
   1a27c:      	ldr	x8, [x0, #0x260]
   1a280:      	ldr	q1, [x0, #0x230]
   1a284:      	str	x8, [x1, #0x40]
   1a288:      	stp	q2, q0, [x1, #0x20]
   1a28c:      	str	q1, [x1, #0x10]
   1a290:      	ret
   1a294:      	bti	c
   1a298:      	add	x0, x0, #0x10
   1a29c:      	b	0x1d32c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14318>
   1a2a0:      	bti	c
   1a2a4:      	ldrb	w0, [x0, #0x269]
   1a2a8:      	ret
   1a2ac:      	paciasp
   1a2b0:      	stp	x29, x30, [sp, #-0x10]!
   1a2b4:      	mov	x29, sp
   1a2b8:      	ldr	x8, [x0]
   1a2bc:      	mov	w1, #-0x1               // =-1
   1a2c0:      	ldr	x8, [x8, #0x18]
   1a2c4:      	blr	x8
   1a2c8:      	mov	w0, wzr
   1a2cc:      	ldp	x29, x30, [sp], #0x10
   1a2d0:      	autiasp
   1a2d4:      	ret
   1a2d8:      	paciasp
   1a2dc:      	stp	x29, x30, [sp, #-0x30]!
   1a2e0:      	stp	x28, x21, [sp, #0x10]
   1a2e4:      	stp	x20, x19, [sp, #0x20]
   1a2e8:      	mov	x29, sp
   1a2ec:      	sub	sp, sp, #0x6b0
   1a2f0:      	ldr	x8, [x0]
   1a2f4:      	strb	wzr, [x0, #0x26a]
   1a2f8:      	mov	w20, w1
   1a2fc:      	mov	w1, #-0x1               // =-1
   1a300:      	mov	x19, x0
   1a304:      	ldr	x8, [x8, #0x18]
   1a308:      	blr	x8
   1a30c:      	cbz	x0, 0x1a51c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11508>
   1a310:      	ldr	x8, [x19, #0x8]
   1a314:      	and	x9, x20, #0x1
   1a318:      	add	x10, sp, #0x68
   1a31c:      	sub	x20, x0, x9
   1a320:      	nop
   1a324:      	adr	x0, 0x1cc7c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13c68>
   1a328:      	add	x1, sp, #0x98
   1a32c:      	stp	x8, x10, [sp, #0x98]
   1a330:      	str	x20, [sp, #0xa8]
   1a334:      	bl	0x1d950 <dl_iterate_phdr@plt>
   1a338:      	cbz	w0, 0x1a35c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11348>
   1a33c:      	ldr	x8, [sp, #0x78]
   1a340:      	cbz	x8, 0x1a35c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11348>
   1a344:      	add	x2, sp, #0x68
   1a348:      	mov	x0, x19
   1a34c:      	mov	x1, x20
   1a350:      	mov	w3, wzr
   1a354:      	bl	0x1c9a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13994>
   1a358:      	tbnz	w0, #0x0, 0x1a504 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x114f0>
   1a35c:      	nop
   1a360:      	adr	x0, 0x269d8
   1a364:      	bl	0x1d960 <pthread_rwlock_rdlock@plt>
   1a368:      	adrp	x8, 0x26000
   1a36c:      	adrp	x9, 0x26000
   1a370:      	ldr	x8, [x8, #0x3b8]
   1a374:      	ldr	x9, [x9, #0x3c0]
   1a378:      	b	0x1a380 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1136c>
   1a37c:      	add	x8, x8, #0x20
   1a380:      	cmp	x8, x9
   1a384:      	b.hs	0x1a454 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11440>
   1a388:      	ldr	x10, [x8, #0x8]
   1a38c:      	cmp	x10, x20
   1a390:      	b.hi	0x1a37c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11368>
   1a394:      	ldr	x10, [x8, #0x10]
   1a398:      	cmp	x10, x20
   1a39c:      	b.ls	0x1a37c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11368>
   1a3a0:      	ldr	x21, [x8, #0x18]
   1a3a4:      	nop
   1a3a8:      	adr	x0, 0x269d8
   1a3ac:      	bl	0x1d940 <pthread_rwlock_unlock@plt>
   1a3b0:      	cbz	x21, 0x1a460 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1144c>
   1a3b4:      	ldr	x0, [x19, #0x8]
   1a3b8:      	add	x2, sp, #0x38
   1a3bc:      	mov	x3, sp
   1a3c0:      	mov	x1, x21
   1a3c4:      	mov	w4, wzr
   1a3c8:      	bl	0x19ab0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10a9c>
   1a3cc:      	cbnz	x0, 0x1a460 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1144c>
   1a3d0:      	add	x0, sp, #0x98
   1a3d4:      	mov	w1, wzr
   1a3d8:      	mov	w2, #0x618              // =1560
   1a3dc:      	bl	0x1d5b0 <memset@plt>
   1a3e0:      	ldr	x0, [x19, #0x8]
   1a3e4:      	add	x1, sp, #0x38
   1a3e8:      	mov	x2, sp
   1a3ec:      	add	x5, sp, #0x98
   1a3f0:      	mov	x3, x20
   1a3f4:      	mov	w4, #0x4                // =4
   1a3f8:      	bl	0x1ab0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11af8>
   1a3fc:      	tbz	w0, #0x0, 0x1a460 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1144c>
   1a400:      	ldr	x8, [sp, #0x60]
   1a404:      	ldr	x9, [sp, #0x20]
   1a408:      	ldur	q0, [sp, #0x50]
   1a40c:      	str	xzr, [x19, #0x248]
   1a410:      	str	x8, [x19, #0x230]
   1a414:      	ldr	w8, [sp, #0xa8]
   1a418:      	str	x9, [x19, #0x238]
   1a41c:      	mov	w9, #0x3000000          // =50331648
   1a420:      	str	x8, [x19, #0x240]
   1a424:      	str	w9, [x19, #0x250]
   1a428:      	ldp	x8, x9, [sp, #0x38]
   1a42c:      	str	q0, [x19, #0x220]
   1a430:      	str	xzr, [x19, #0x260]
   1a434:      	str	x8, [x19, #0x258]
   1a438:      	str	w9, [x19, #0x254]
   1a43c:      	add	sp, sp, #0x6b0
   1a440:      	ldp	x20, x19, [sp, #0x20]
   1a444:      	ldp	x28, x21, [sp, #0x10]
   1a448:      	ldp	x29, x30, [sp], #0x30
   1a44c:      	autiasp
   1a450:      	ret
   1a454:      	nop
   1a458:      	adr	x0, 0x269d8
   1a45c:      	bl	0x1d940 <pthread_rwlock_unlock@plt>
   1a460:      	ldr	x8, [x19]
   1a464:      	mov	x0, x19
   1a468:      	mov	w1, #-0x1               // =-1
   1a46c:      	ldr	x8, [x8, #0x18]
   1a470:      	blr	x8
   1a474:      	add	x8, sp, #0x38
   1a478:      	mov	w9, #0x8                // =8
   1a47c:      	mov	x20, x0
   1a480:      	stp	x8, x9, [sp, #0x98]
   1a484:      	stp	x0, x9, [sp]
   1a488:      	bl	0x1d970 <getpid@plt>
   1a48c:      	mov	w1, w0
   1a490:      	add	x2, sp, #0x98
   1a494:      	mov	x4, sp
   1a498:      	mov	w0, #0x10e              // =270
   1a49c:      	mov	w3, #0x1                // =1
   1a4a0:      	mov	w5, #0x1                // =1
   1a4a4:      	mov	w6, wzr
   1a4a8:      	mov	w21, #0x1               // =1
   1a4ac:      	bl	0x1d4e0 <syscall@plt>
   1a4b0:      	cmp	x0, #0x8
   1a4b4:      	b.ne	0x1a53c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11528>
   1a4b8:      	ldr	w8, [sp, #0x38]
   1a4bc:      	mov	w9, #0x1168             // =4456
   1a4c0:      	movk	w9, #0xd280, lsl #16
   1a4c4:      	cmp	w8, w9
   1a4c8:      	b.ne	0x1a53c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11528>
   1a4cc:      	ldr	w8, [sp, #0x3c]
   1a4d0:      	mov	w9, #0x1                // =1
   1a4d4:      	movk	w9, #0xd400, lsl #16
   1a4d8:      	cmp	w8, w9
   1a4dc:      	b.ne	0x1a53c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11528>
   1a4e0:      	movi	v0.2d, #0000000000000000
   1a4e4:      	add	x8, x20, #0x4
   1a4e8:      	str	xzr, [x19, #0x260]
   1a4ec:      	str	x8, [x19, #0x228]
   1a4f0:      	mov	w8, #0x1                // =1
   1a4f4:      	str	x20, [x19, #0x220]
   1a4f8:      	strb	w8, [x19, #0x26a]
   1a4fc:      	stp	q0, q0, [x19, #0x240]
   1a500:      	str	q0, [x19, #0x230]
   1a504:      	add	sp, sp, #0x6b0
   1a508:      	ldp	x20, x19, [sp, #0x20]
   1a50c:      	ldp	x28, x21, [sp, #0x10]
   1a510:      	ldp	x29, x30, [sp], #0x30
   1a514:      	autiasp
   1a518:      	ret
   1a51c:      	mov	w8, #0x1                // =1
   1a520:      	strb	w8, [x19, #0x268]
   1a524:      	add	sp, sp, #0x6b0
   1a528:      	ldp	x20, x19, [sp, #0x20]
   1a52c:      	ldp	x28, x21, [sp, #0x10]
   1a530:      	ldp	x29, x30, [sp], #0x30
   1a534:      	autiasp
   1a538:      	ret
   1a53c:      	strb	w21, [x19, #0x268]
   1a540:      	add	sp, sp, #0x6b0
   1a544:      	ldp	x20, x19, [sp, #0x20]
   1a548:      	ldp	x28, x21, [sp, #0x10]
   1a54c:      	ldp	x29, x30, [sp], #0x30
   1a550:      	autiasp
   1a554:      	ret
   1a558:      	bti	c
   1a55c:      	mov	w0, w1
   1a560:      	b	0x1d2fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x142e8>
   1a564:      	bti	c
   1a568:      	ldr	x10, [x0, #0x108]
   1a56c:      	mov	w9, #0x1                // =1
   1a570:      	ldr	x11, [x10, #0x138]
   1a574:      	str	x11, [x0, #0x10]
   1a578:      	ldr	x11, [x10, #0x140]
   1a57c:      	str	x11, [x0, #0x18]
   1a580:      	ldr	x11, [x10, #0x148]
   1a584:      	str	x11, [x0, #0x20]
   1a588:      	ldr	x11, [x10, #0x150]
   1a58c:      	str	x11, [x0, #0x28]
   1a590:      	ldr	x11, [x10, #0x158]
   1a594:      	str	x11, [x0, #0x30]
   1a598:      	ldr	x11, [x10, #0x160]
   1a59c:      	str	x11, [x0, #0x38]
   1a5a0:      	ldr	x11, [x10, #0x168]
   1a5a4:      	str	x11, [x0, #0x40]
   1a5a8:      	ldr	x11, [x10, #0x170]
   1a5ac:      	str	x11, [x0, #0x48]
   1a5b0:      	ldr	x11, [x10, #0x178]
   1a5b4:      	str	x11, [x0, #0x50]
   1a5b8:      	ldr	x11, [x10, #0x180]
   1a5bc:      	str	x11, [x0, #0x58]
   1a5c0:      	ldr	x11, [x10, #0x188]
   1a5c4:      	str	x11, [x0, #0x60]
   1a5c8:      	ldr	x11, [x10, #0x190]
   1a5cc:      	str	x11, [x0, #0x68]
   1a5d0:      	ldr	x11, [x10, #0x198]
   1a5d4:      	str	x11, [x0, #0x70]
   1a5d8:      	ldr	x11, [x10, #0x1a0]
   1a5dc:      	str	x11, [x0, #0x78]
   1a5e0:      	ldr	x11, [x10, #0x1a8]
   1a5e4:      	str	x11, [x0, #0x80]
   1a5e8:      	ldr	x11, [x10, #0x1b0]
   1a5ec:      	str	x11, [x0, #0x88]
   1a5f0:      	ldr	x11, [x10, #0x1b8]
   1a5f4:      	str	x11, [x0, #0x90]
   1a5f8:      	ldr	x11, [x10, #0x1c0]
   1a5fc:      	str	x11, [x0, #0x98]
   1a600:      	ldr	x11, [x10, #0x1c8]
   1a604:      	str	x11, [x0, #0xa0]
   1a608:      	ldr	x11, [x10, #0x1d0]
   1a60c:      	str	x11, [x0, #0xa8]
   1a610:      	ldr	x11, [x10, #0x1d8]
   1a614:      	str	x11, [x0, #0xb0]
   1a618:      	ldr	x11, [x10, #0x1e0]
   1a61c:      	str	x11, [x0, #0xb8]
   1a620:      	ldr	x11, [x10, #0x1e8]
   1a624:      	str	x11, [x0, #0xc0]
   1a628:      	ldr	x11, [x10, #0x1f0]
   1a62c:      	str	x11, [x0, #0xc8]
   1a630:      	ldr	x11, [x10, #0x1f8]
   1a634:      	str	x11, [x0, #0xd0]
   1a638:      	ldr	x11, [x10, #0x200]
   1a63c:      	str	x11, [x0, #0xd8]
   1a640:      	ldr	x11, [x10, #0x208]
   1a644:      	str	x11, [x0, #0xe0]
   1a648:      	ldr	x11, [x10, #0x210]
   1a64c:      	str	x11, [x0, #0xe8]
   1a650:      	ldr	x11, [x10, #0x218]
   1a654:      	str	x11, [x0, #0xf0]
   1a658:      	ldr	x11, [x10, #0x220]
   1a65c:      	str	x11, [x0, #0xf8]
   1a660:      	ldr	x11, [x10, #0x228]
   1a664:      	str	x11, [x0, #0x100]
   1a668:      	ldr	x11, [x10, #0x230]
   1a66c:      	str	x11, [x0, #0x108]
   1a670:      	ldr	x10, [x10, #0x238]
   1a674:      	strb	w9, [x0, #0x269]
   1a678:      	str	x10, [x0, #0x110]
   1a67c:      	mov	w0, #0x1                // =1
   1a680:      	ret
   1a684:      	paciasp
   1a688:      	stp	x29, x30, [sp, #-0x60]!
   1a68c:      	stp	x28, x27, [sp, #0x10]
   1a690:      	stp	x26, x25, [sp, #0x20]
   1a694:      	stp	x24, x23, [sp, #0x30]
   1a698:      	stp	x22, x21, [sp, #0x40]
   1a69c:      	stp	x20, x19, [sp, #0x50]
   1a6a0:      	mov	x29, sp
   1a6a4:      	sub	sp, sp, #0xb10
   1a6a8:      	mov	x8, x2
   1a6ac:      	mov	x21, x4
   1a6b0:      	mov	x19, x3
   1a6b4:      	mov	x22, x1
   1a6b8:      	sub	x2, x29, #0x50
   1a6bc:      	sub	x3, x29, #0x88
   1a6c0:      	mov	x1, x8
   1a6c4:      	mov	w4, wzr
   1a6c8:      	mov	w23, w5
   1a6cc:      	mov	x20, x0
   1a6d0:      	bl	0x19ab0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10a9c>
   1a6d4:      	cbnz	x0, 0x1a7b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117a0>
   1a6d8:      	add	x0, sp, #0x470
   1a6dc:      	mov	w1, wzr
   1a6e0:      	mov	w2, #0x618              // =1560
   1a6e4:      	bl	0x1d5b0 <memset@plt>
   1a6e8:      	sub	x1, x29, #0x50
   1a6ec:      	sub	x2, x29, #0x88
   1a6f0:      	add	x5, sp, #0x470
   1a6f4:      	mov	x0, x20
   1a6f8:      	mov	x3, x22
   1a6fc:      	mov	w4, #0x4                // =4
   1a700:      	bl	0x1ab0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11af8>
   1a704:      	tbz	w0, #0x0, 0x1a7b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117a0>
   1a708:      	add	x1, sp, #0x470
   1a70c:      	mov	x0, x20
   1a710:      	mov	x2, x19
   1a714:      	add	x24, sp, #0x470
   1a718:      	bl	0x1b754 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12740>
   1a71c:      	mov	x22, x0
   1a720:      	tbz	w23, #0x0, 0x1a74c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11738>
   1a724:      	ldurb	w8, [x29, #-0x54]
   1a728:      	cbz	w8, 0x1a74c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11738>
   1a72c:      	ldr	x8, [x19, #0xf8]
   1a730:      	and	x8, x8, #0xfffffffffffffff0
   1a734:      	cmp	x8, x22
   1a738:      	b.hs	0x1a74c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11738>
   1a73c:      	stg	x8, [x8]
   1a740:      	add	x8, x8, #0x10
   1a744:      	cmp	x8, x22
   1a748:      	b.lo	0x1a73c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11728>
   1a74c:      	add	x0, sp, #0x260
   1a750:      	mov	x1, x19
   1a754:      	mov	w2, #0x210              // =528
   1a758:      	add	x25, sp, #0x260
   1a75c:      	bl	0x1d540 <memcpy@plt>
   1a760:      	add	x9, x25, #0xf8
   1a764:      	add	x8, x25, #0xe8
   1a768:      	add	x10, x19, #0xf8
   1a76c:      	stp	x8, x9, [sp, #0x18]
   1a770:      	add	x9, x25, #0x100
   1a774:      	add	x8, x25, #0xf0
   1a778:      	stp	x8, x9, [sp, #0x8]
   1a77c:      	add	x9, x25, #0x108
   1a780:      	add	x8, x19, #0xe8
   1a784:      	stp	x8, x9, [sp, #0x40]
   1a788:      	add	x8, x19, #0x100
   1a78c:      	mov	x26, xzr
   1a790:      	mov	x23, xzr
   1a794:      	add	x28, x19, #0x108
   1a798:      	stp	x10, x8, [sp, #0x30]
   1a79c:      	add	x8, x19, #0xf0
   1a7a0:      	add	x24, x24, #0x18
   1a7a4:      	add	x27, sp, #0x260
   1a7a8:      	str	x22, [sp, #0x358]
   1a7ac:      	str	x8, [sp, #0x28]
   1a7b0:      	b	0x1a80c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117f8>
   1a7b4:      	mov	w0, #-0x1992            // =-6546
   1a7b8:      	add	sp, sp, #0xb10
   1a7bc:      	ldp	x20, x19, [sp, #0x50]
   1a7c0:      	ldp	x22, x21, [sp, #0x40]
   1a7c4:      	ldp	x24, x23, [sp, #0x30]
   1a7c8:      	ldp	x26, x25, [sp, #0x20]
   1a7cc:      	ldp	x28, x27, [sp, #0x10]
   1a7d0:      	ldp	x29, x30, [sp], #0x60
   1a7d4:      	autiasp
   1a7d8:      	ret
   1a7dc:      	ldr	x8, [x24, #0x8]
   1a7e0:      	mov	x9, #-0x4000000000      // =-274877906944
   1a7e4:      	add	x8, x9, x8, lsl #32
   1a7e8:      	add	x8, x19, x8, asr #29
   1a7ec:      	ldr	d0, [x8, #0x110]
   1a7f0:      	add	x8, x25, x26, lsl #3
   1a7f4:      	stur	d0, [x8, #-0xf0]
   1a7f8:      	add	x26, x26, #0x1
   1a7fc:      	add	x24, x24, #0x10
   1a800:      	add	x27, x27, #0x8
   1a804:      	cmp	x26, #0x60
   1a808:      	b.eq	0x1a9cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x119b8>
   1a80c:      	ldr	w8, [x24]
   1a810:      	cbz	w8, 0x1a848 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11834>
   1a814:      	and	w9, w26, #0x60
   1a818:      	cmp	w9, #0x40
   1a81c:      	b.ne	0x1a884 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11870>
   1a820:      	cmp	w8, #0x4
   1a824:      	b.gt	0x1a8ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11898>
   1a828:      	movi	d0, #0000000000000000
   1a82c:      	cmp	w8, #0x1
   1a830:      	b.eq	0x1a7f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117dc>
   1a834:      	cmp	w8, #0x2
   1a838:      	b.ne	0x1aa70 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11a5c>
   1a83c:      	ldr	x8, [x24, #0x8]
   1a840:      	ldr	d0, [x8, x22]
   1a844:      	b	0x1a7f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117dc>
   1a848:      	ldurb	w8, [x29, #-0x56]
   1a84c:      	cmp	x26, x8
   1a850:      	b.ne	0x1a7f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117e4>
   1a854:      	cmp	w8, #0x1e
   1a858:      	b.le	0x1a94c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11938>
   1a85c:      	cmp	w8, #0x22
   1a860:      	mov	x9, x28
   1a864:      	b.eq	0x1a970 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1195c>
   1a868:      	ldr	x9, [sp, #0x38]
   1a86c:      	cmp	w8, #0x20
   1a870:      	b.eq	0x1a970 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1195c>
   1a874:      	ldr	x9, [sp, #0x30]
   1a878:      	cmp	w8, #0x1f
   1a87c:      	b.eq	0x1a970 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1195c>
   1a880:      	b	0x1a964 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11950>
   1a884:      	ldurb	w8, [x29, #-0x56]
   1a888:      	cmp	x26, x8
   1a88c:      	b.ne	0x1a8d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x118c4>
   1a890:      	mov	x0, x20
   1a894:      	mov	x1, x19
   1a898:      	mov	x2, x22
   1a89c:      	mov	x3, x24
   1a8a0:      	bl	0x1b888 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12874>
   1a8a4:      	mov	x23, x0
   1a8a8:      	b	0x1a7f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117e4>
   1a8ac:      	cmp	w8, #0x5
   1a8b0:      	b.eq	0x1a7dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117c8>
   1a8b4:      	cmp	w8, #0x6
   1a8b8:      	b.ne	0x1aa70 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11a5c>
   1a8bc:      	ldr	x0, [x24, #0x8]
   1a8c0:      	mov	x1, x20
   1a8c4:      	mov	x2, x19
   1a8c8:      	mov	x3, x22
   1a8cc:      	bl	0x1bfec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12fd8>
   1a8d0:      	ldr	d0, [x0]
   1a8d4:      	b	0x1a7f0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117dc>
   1a8d8:      	cmp	x26, #0x22
   1a8dc:      	b.ne	0x1a900 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x118ec>
   1a8e0:      	mov	x0, x20
   1a8e4:      	mov	x1, x19
   1a8e8:      	mov	x2, x22
   1a8ec:      	mov	x3, x24
   1a8f0:      	bl	0x1b888 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12874>
   1a8f4:      	ldr	x8, [sp, #0x48]
   1a8f8:      	str	x0, [x8]
   1a8fc:      	b	0x1a7f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117e4>
   1a900:      	sub	w8, w26, #0x40
   1a904:      	cmn	w8, #0x20
   1a908:      	b.hi	0x1aa68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11a54>
   1a90c:      	mov	x0, x20
   1a910:      	mov	x1, x19
   1a914:      	mov	x2, x22
   1a918:      	mov	x3, x24
   1a91c:      	bl	0x1b888 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12874>
   1a920:      	cmp	w26, #0x1e
   1a924:      	b.le	0x1a978 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11964>
   1a928:      	cmp	w26, #0x1f
   1a92c:      	b.eq	0x1a994 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11980>
   1a930:      	cmp	w26, #0x22
   1a934:      	b.eq	0x1a9a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1198c>
   1a938:      	cmp	w26, #0x20
   1a93c:      	b.ne	0x1a9b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x119a4>
   1a940:      	ldr	x8, [sp, #0x10]
   1a944:      	str	x0, [x8]
   1a948:      	b	0x1a7f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117e4>
   1a94c:      	ldr	x9, [sp, #0x40]
   1a950:      	cmp	w8, #0x1d
   1a954:      	b.eq	0x1a970 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1195c>
   1a958:      	ldr	x9, [sp, #0x28]
   1a95c:      	cmp	w8, #0x1e
   1a960:      	b.eq	0x1a970 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1195c>
   1a964:      	cmp	w8, #0x1c
   1a968:      	b.hi	0x1aaa4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11a90>
   1a96c:      	add	x9, x19, x8, lsl #3
   1a970:      	ldr	x23, [x9]
   1a974:      	b	0x1a7f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117e4>
   1a978:      	cmp	w26, #0x1d
   1a97c:      	b.eq	0x1a9ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11998>
   1a980:      	cmp	w26, #0x1e
   1a984:      	b.ne	0x1a9b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x119a4>
   1a988:      	ldr	x8, [sp, #0x8]
   1a98c:      	str	x0, [x8]
   1a990:      	b	0x1a7f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117e4>
   1a994:      	ldr	x8, [sp, #0x20]
   1a998:      	str	x0, [x8]
   1a99c:      	b	0x1a7f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117e4>
   1a9a0:      	ldr	x8, [sp, #0x48]
   1a9a4:      	str	x0, [x8]
   1a9a8:      	b	0x1a7f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117e4>
   1a9ac:      	ldr	x8, [sp, #0x18]
   1a9b0:      	str	x0, [x8]
   1a9b4:      	b	0x1a7f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117e4>
   1a9b8:      	cmp	x26, #0x1d
   1a9bc:      	mov	x8, x27
   1a9c0:      	b.hs	0x1aad8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11ac4>
   1a9c4:      	str	x0, [x8]
   1a9c8:      	b	0x1a7f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117e4>
   1a9cc:      	ldurb	w8, [x29, #-0x58]
   1a9d0:      	add	x0, sp, #0x50
   1a9d4:      	mov	x1, x19
   1a9d8:      	mov	w2, #0x210              // =528
   1a9dc:      	strb	w8, [x21]
   1a9e0:      	bl	0x1d540 <memcpy@plt>
   1a9e4:      	add	x8, sp, #0x470
   1a9e8:      	add	x8, x8, #0x238
   1a9ec:      	ldr	q0, [x8]
   1a9f0:      	stur	q0, [x29, #-0x20]
   1a9f4:      	ldur	w8, [x29, #-0x20]
   1a9f8:      	cbz	w8, 0x1aa18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11a04>
   1a9fc:      	add	x1, sp, #0x50
   1aa00:      	sub	x3, x29, #0x20
   1aa04:      	mov	x0, x20
   1aa08:      	mov	x2, x22
   1aa0c:      	bl	0x1b888 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12874>
   1aa10:      	tbnz	w0, #0x0, 0x1aa20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11a0c>
   1aa14:      	b	0x1aa4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11a38>
   1aa18:      	ldur	x0, [x29, #-0x18]
   1aa1c:      	tbz	w0, #0x0, 0x1aa4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11a38>
   1aa20:      	cbz	x23, 0x1aa4c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11a38>
   1aa24:      	ldurb	w8, [x29, #-0x55]
   1aa28:      	cbz	w8, 0x1aa3c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11a28>
   1aa2c:      	mov	x17, x23
   1aa30:      	mov	x16, x22
   1aa34:      	autib1716
   1aa38:      	b	0x1aa48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11a34>
   1aa3c:      	mov	x17, x23
   1aa40:      	mov	x16, x22
   1aa44:      	autia1716
   1aa48:      	mov	x23, x17
   1aa4c:      	add	x1, sp, #0x260
   1aa50:      	mov	x0, x19
   1aa54:      	mov	w2, #0x210              // =528
   1aa58:      	str	x23, [sp, #0x360]
   1aa5c:      	bl	0x1d540 <memcpy@plt>
   1aa60:      	mov	w0, #0x1                // =1
   1aa64:      	b	0x1a7b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117a4>
   1aa68:      	mov	w0, #-0x198e            // =-6542
   1aa6c:      	b	0x1a7b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x117a4>
   1aa70:      	adrp	x19, 0x22000
   1aa74:      	nop
   1aa78:      	adr	x1, 0x2bb3
   1aa7c:      	ldr	x19, [x19, #0x108]
   1aa80:      	adrp	x2, 0x2000
   1aa84:      	add	x2, x2, #0xc6b
   1aa88:      	adrp	x3, 0x3000
   1aa8c:      	add	x3, x3, #0x7f5
   1aa90:      	add	x0, x19, #0x130
   1aa94:      	bl	0x1d5a0 <fprintf@plt>
   1aa98:      	add	x0, x19, #0x130
   1aa9c:      	bl	0x1d920 <fflush@plt>
   1aaa0:      	bl	0x1d4d0 <abort@plt>
   1aaa4:      	adrp	x19, 0x22000
   1aaa8:      	nop
   1aaac:      	adr	x1, 0x2bb3
   1aab0:      	ldr	x19, [x19, #0x108]
   1aab4:      	adrp	x2, 0x3000
   1aab8:      	add	x2, x2, #0x9fb
   1aabc:      	adrp	x3, 0x3000
   1aac0:      	add	x3, x3, #0x479
   1aac4:      	add	x0, x19, #0x130
   1aac8:      	bl	0x1d5a0 <fprintf@plt>
   1aacc:      	add	x0, x19, #0x130
   1aad0:      	bl	0x1d920 <fflush@plt>
   1aad4:      	bl	0x1d4d0 <abort@plt>
   1aad8:      	adrp	x19, 0x22000
   1aadc:      	nop
   1aae0:      	adr	x1, 0x2bb3
   1aae4:      	ldr	x19, [x19, #0x108]
   1aae8:      	adrp	x2, 0x4000
   1aaec:      	add	x2, x2, #0x164
   1aaf0:      	adrp	x3, 0x3000
   1aaf4:      	add	x3, x3, #0x479
   1aaf8:      	add	x0, x19, #0x130
   1aafc:      	bl	0x1d5a0 <fprintf@plt>
   1ab00:      	add	x0, x19, #0x130
   1ab04:      	bl	0x1d920 <fflush@plt>
   1ab08:      	bl	0x1d4d0 <abort@plt>
   1ab0c:      	paciasp
   1ab10:      	stp	x29, x30, [sp, #-0x60]!
   1ab14:      	stp	x28, x27, [sp, #0x10]
   1ab18:      	stp	x26, x25, [sp, #0x20]
   1ab1c:      	stp	x24, x23, [sp, #0x30]
   1ab20:      	stp	x22, x21, [sp, #0x40]
   1ab24:      	stp	x20, x19, [sp, #0x50]
   1ab28:      	mov	x29, sp
   1ab2c:      	sub	sp, sp, #0x680
   1ab30:      	ldp	x10, x8, [x2, #0x8]
   1ab34:      	mov	x19, sp
   1ab38:      	ldr	x9, [x2]
   1ab3c:      	ldp	x11, x12, [x1, #0x10]
   1ab40:      	mov	x20, x5
   1ab44:      	mov	w28, w4
   1ab48:      	mov	x22, x2
   1ab4c:      	add	x9, x10, x9
   1ab50:      	mov	x27, xzr
   1ab54:      	nop
   1ab58:      	adr	x23, 0x5524
   1ab5c:      	stp	x8, x9, [x29, #-0x38]
   1ab60:      	mov	x8, #-0x1               // =-1
   1ab64:      	ldp	x9, x10, [x1]
   1ab68:      	stp	x8, x11, [x29, #-0x28]
   1ab6c:      	stp	x0, xzr, [x19, #0x18]
   1ab70:      	add	x8, x10, x9
   1ab74:      	sub	x9, x3, x12
   1ab78:      	stp	x8, x9, [x29, #-0x18]
   1ab7c:      	add	x8, x19, #0x28
   1ab80:      	add	x9, x5, #0x238
   1ab84:      	add	x8, x8, #0x238
   1ab88:      	stp	x8, x9, [x19, #0x8]
   1ab8c:      	b	0x1ab9c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b88>
   1ab90:      	add	x27, x27, #0x18
   1ab94:      	cmp	x27, #0x30
   1ab98:      	b.eq	0x1b4c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x124b4>
   1ab9c:      	sub	x8, x29, #0x38
   1aba0:      	add	x8, x8, x27
   1aba4:      	ldp	x9, x24, [x8]
   1aba8:      	ldr	x21, [x8, #0x10]
   1abac:      	cmp	x9, x24
   1abb0:      	stur	x9, [x29, #-0x40]
   1abb4:      	ccmp	x21, #0x0, #0x4, lo
   1abb8:      	b.eq	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1abbc:      	mov	x25, xzr
   1abc0:      	mov	x8, x9
   1abc4:      	ldrb	w10, [x8], #0x1
   1abc8:      	stur	x8, [x29, #-0x40]
   1abcc:      	cmp	w10, #0x2f
   1abd0:      	b.hi	0x1b1c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x121ac>
   1abd4:      	adr	x11, 0x1abe4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11bd0>
   1abd8:      	ldrh	w12, [x23, x10, lsl #1]
   1abdc:      	add	x11, x11, x12, lsl #2
   1abe0:      	br	x11
   1abe4:      	bti	j
   1abe8:      	ldrb	w3, [x22, #0x18]
   1abec:      	ldr	x0, [x19, #0x18]
   1abf0:      	sub	x1, x29, #0x40
   1abf4:      	mov	x2, x24
   1abf8:      	mov	x4, xzr
   1abfc:      	bl	0x1ba98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a84>
   1ac00:      	mov	x25, x0
   1ac04:      	ldur	x9, [x29, #-0x40]
   1ac08:      	cmp	x9, x24
   1ac0c:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1ac10:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1ac14:      	bti	j
   1ac18:      	sub	x0, x29, #0x40
   1ac1c:      	mov	x1, x24
   1ac20:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1ac24:      	ldur	x10, [x29, #-0x40]
   1ac28:      	mov	x9, xzr
   1ac2c:      	mov	x8, xzr
   1ac30:      	mov	x12, x10
   1ac34:      	cmp	x12, x24
   1ac38:      	b.eq	0x1b6b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x126a4>
   1ac3c:      	ldrb	w11, [x12], #0x1
   1ac40:      	add	x10, x10, #0x1
   1ac44:      	and	x13, x11, #0x7f
   1ac48:      	lsl	x13, x13, x9
   1ac4c:      	add	x9, x9, #0x7
   1ac50:      	orr	x8, x13, x8
   1ac54:      	tbnz	w11, #0x7, 0x1ac34 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11c20>
   1ac58:      	cmp	x0, #0x60
   1ac5c:      	stur	x10, [x29, #-0x40]
   1ac60:      	b.hs	0x1b610 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x125fc>
   1ac64:      	sub	w10, w9, #0x7
   1ac68:      	mov	x12, #-0x1              // =-1
   1ac6c:      	cmp	w10, #0x39
   1ac70:      	mov	w10, #0x3f              // =63
   1ac74:      	lsl	x9, x12, x9
   1ac78:      	ccmp	w11, w10, #0x0, lo
   1ac7c:      	ldr	w10, [x22, #0x2c]
   1ac80:      	csel	w9, w9, wzr, hi
   1ac84:      	orr	w8, w8, w9
   1ac88:      	mul	w8, w10, w8
   1ac8c:      	stp	w0, w8, [x20]
   1ac90:      	ldur	x9, [x29, #-0x40]
   1ac94:      	cmp	x9, x24
   1ac98:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1ac9c:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1aca0:      	bti	j
   1aca4:      	sub	x0, x29, #0x40
   1aca8:      	mov	x1, x24
   1acac:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1acb0:      	cmp	x0, #0x60
   1acb4:      	b.hs	0x1b4fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x124e8>
   1acb8:      	ldur	x9, [x29, #-0x40]
   1acbc:      	mov	x10, xzr
   1acc0:      	mov	x8, xzr
   1acc4:      	mov	x12, x9
   1acc8:      	cmp	x12, x24
   1accc:      	b.eq	0x1b720 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1270c>
   1acd0:      	ldrb	w11, [x12], #0x1
   1acd4:      	add	x9, x9, #0x1
   1acd8:      	and	x13, x11, #0x7f
   1acdc:      	lsl	x13, x13, x10
   1ace0:      	add	x10, x10, #0x7
   1ace4:      	orr	x8, x13, x8
   1ace8:      	tbnz	w11, #0x7, 0x1acc8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11cb4>
   1acec:      	add	x12, x20, x0, lsl #4
   1acf0:      	sub	w13, w10, #0x7
   1acf4:      	mov	x15, #-0x1              // =-1
   1acf8:      	cmp	w13, #0x39
   1acfc:      	mov	w14, #0x3f              // =63
   1ad00:      	lsl	x15, x15, x10
   1ad04:      	mov	x13, x12
   1ad08:      	ccmp	w11, w14, #0x0, lo
   1ad0c:      	ldrsw	x10, [x22, #0x2c]
   1ad10:      	ldrb	w16, [x13, #0x1c]!
   1ad14:      	csel	x11, x15, xzr, hi
   1ad18:      	stur	x9, [x29, #-0x40]
   1ad1c:      	cbnz	w16, 0x1ad40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11d2c>
   1ad20:      	lsl	x9, x0, #4
   1ad24:      	add	x15, x19, #0x28
   1ad28:      	add	x14, x20, x9
   1ad2c:      	add	x9, x15, x9
   1ad30:      	ldur	q0, [x14, #0x18]
   1ad34:      	mov	w14, #0x1               // =1
   1ad38:      	strb	w14, [x13]
   1ad3c:      	stur	q0, [x9, #0x18]
   1ad40:      	orr	x8, x8, x11
   1ad44:      	mov	w9, #0x4                // =4
   1ad48:      	b	0x1b354 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12340>
   1ad4c:      	bti	j
   1ad50:      	sub	x0, x29, #0x40
   1ad54:      	mov	x1, x24
   1ad58:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1ad5c:      	cmp	x0, #0x60
   1ad60:      	b.hs	0x1b4d0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x124bc>
   1ad64:      	str	w0, [x20]
   1ad68:      	ldur	x9, [x29, #-0x40]
   1ad6c:      	cmp	x9, x24
   1ad70:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1ad74:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1ad78:      	bti	j
   1ad7c:      	sub	x0, x29, #0x40
   1ad80:      	mov	x1, x24
   1ad84:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1ad88:      	cmp	x0, #0x60
   1ad8c:      	b.hs	0x1b560 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1254c>
   1ad90:      	mov	x26, x0
   1ad94:      	sub	x0, x29, #0x40
   1ad98:      	mov	x1, x24
   1ad9c:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1ada0:      	add	x8, x20, x26, lsl #4
   1ada4:      	ldrsw	x9, [x22, #0x2c]
   1ada8:      	mov	x10, x8
   1adac:      	ldrb	w11, [x10, #0x1c]!
   1adb0:      	cbnz	w11, 0x1add4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11dc0>
   1adb4:      	lsl	x11, x26, #4
   1adb8:      	add	x13, x19, #0x28
   1adbc:      	add	x12, x20, x11
   1adc0:      	add	x11, x13, x11
   1adc4:      	ldur	q0, [x12, #0x18]
   1adc8:      	mov	w12, #0x1               // =1
   1adcc:      	strb	w12, [x10]
   1add0:      	stur	q0, [x11, #0x18]
   1add4:      	mneg	x9, x0, x9
   1add8:      	b	0x1afe4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11fd0>
   1addc:      	bti	j
   1ade0:      	cmp	w28, #0x4
   1ade4:      	b.ne	0x1b490 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1247c>
   1ade8:      	ldrb	w8, [x20, #0x23c]
   1adec:      	cbnz	w8, 0x1ae04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11df0>
   1adf0:      	ldp	x9, x8, [x19, #0x8]
   1adf4:      	ldr	q0, [x8]
   1adf8:      	mov	w8, #0x1                // =1
   1adfc:      	strb	w8, [x20, #0x23c]
   1ae00:      	str	q0, [x9]
   1ae04:      	ldr	x8, [x20, #0x240]
   1ae08:      	eor	x8, x8, #0x1
   1ae0c:      	str	x8, [x20, #0x240]
   1ae10:      	ldur	x9, [x29, #-0x40]
   1ae14:      	cmp	x9, x24
   1ae18:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1ae1c:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1ae20:      	bti	j
   1ae24:      	sub	x26, sp, #0x620
   1ae28:      	mov	sp, x26
   1ae2c:      	ldr	x8, [x19, #0x20]
   1ae30:      	mov	x0, x26
   1ae34:      	mov	x1, x20
   1ae38:      	mov	w2, #0x618              // =1560
   1ae3c:      	str	x8, [x0], #0x8
   1ae40:      	bl	0x1d540 <memcpy@plt>
   1ae44:      	str	x26, [x19, #0x20]
   1ae48:      	ldur	x9, [x29, #-0x40]
   1ae4c:      	cmp	x9, x24
   1ae50:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1ae54:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1ae58:      	bti	j
   1ae5c:      	ldrb	w8, [x9, #0x1]
   1ae60:      	ldr	w10, [x22, #0x28]
   1ae64:      	add	x9, x9, #0x2
   1ae68:      	b	0x1b048 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12034>
   1ae6c:      	bti	j
   1ae70:      	ldur	w8, [x9, #0x1]
   1ae74:      	ldr	w10, [x22, #0x28]
   1ae78:      	add	x9, x9, #0x5
   1ae7c:      	b	0x1b048 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12034>
   1ae80:      	bti	j
   1ae84:      	sub	x0, x29, #0x40
   1ae88:      	mov	x1, x24
   1ae8c:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1ae90:      	cmp	x0, #0x60
   1ae94:      	b.hs	0x1b4e0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x124cc>
   1ae98:      	add	x8, x20, x0, lsl #4
   1ae9c:      	mov	x9, x8
   1aea0:      	ldrb	w10, [x9, #0x1c]!
   1aea4:      	cbnz	w10, 0x1aec8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11eb4>
   1aea8:      	lsl	x10, x0, #4
   1aeac:      	add	x12, x19, #0x28
   1aeb0:      	add	x11, x20, x10
   1aeb4:      	add	x10, x12, x10
   1aeb8:      	ldur	q0, [x11, #0x18]
   1aebc:      	mov	w11, #0x1               // =1
   1aec0:      	strb	w11, [x9]
   1aec4:      	stur	q0, [x10, #0x18]
   1aec8:      	ldur	x9, [x29, #-0x40]
   1aecc:      	mov	w10, #0x7               // =7
   1aed0:      	b	0x1b3c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x123ac>
   1aed4:      	bti	j
   1aed8:      	sub	x0, x29, #0x40
   1aedc:      	mov	x1, x24
   1aee0:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1aee4:      	mov	x26, x0
   1aee8:      	sub	x0, x29, #0x40
   1aeec:      	mov	x1, x24
   1aef0:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1aef4:      	cmp	x26, #0x60
   1aef8:      	b.hs	0x1b57c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12568>
   1aefc:      	stp	w26, w0, [x20]
   1af00:      	ldur	x9, [x29, #-0x40]
   1af04:      	cmp	x9, x24
   1af08:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1af0c:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1af10:      	bti	j
   1af14:      	mov	x10, xzr
   1af18:      	mov	x9, xzr
   1af1c:      	mov	x11, x8
   1af20:      	cmp	x11, x24
   1af24:      	b.eq	0x1b684 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12670>
   1af28:      	ldrb	w12, [x11], #0x1
   1af2c:      	add	x8, x8, #0x1
   1af30:      	and	x13, x12, #0x7f
   1af34:      	lsl	x13, x13, x10
   1af38:      	add	x10, x10, #0x7
   1af3c:      	orr	x9, x13, x9
   1af40:      	tbnz	w12, #0x7, 0x1af20 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11f0c>
   1af44:      	sub	w11, w10, #0x7
   1af48:      	mov	x13, #-0x1              // =-1
   1af4c:      	stur	x8, [x29, #-0x40]
   1af50:      	cmp	w11, #0x39
   1af54:      	mov	w11, #0x3f              // =63
   1af58:      	lsl	x10, x13, x10
   1af5c:      	ccmp	w12, w11, #0x0, lo
   1af60:      	ldr	w11, [x22, #0x2c]
   1af64:      	csel	w10, w10, wzr, hi
   1af68:      	orr	w9, w9, w10
   1af6c:      	mul	w9, w11, w9
   1af70:      	str	w9, [x20, #0x4]
   1af74:      	mov	x9, x8
   1af78:      	cmp	x8, x24
   1af7c:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1af80:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1af84:      	bti	j
   1af88:      	sub	x0, x29, #0x40
   1af8c:      	mov	x1, x24
   1af90:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1af94:      	mov	x26, x0
   1af98:      	sub	x0, x29, #0x40
   1af9c:      	mov	x1, x24
   1afa0:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1afa4:      	cmp	x26, #0x60
   1afa8:      	b.hs	0x1b544 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12530>
   1afac:      	add	x8, x20, x26, lsl #4
   1afb0:      	ldrsw	x9, [x22, #0x2c]
   1afb4:      	mov	x10, x8
   1afb8:      	ldrb	w11, [x10, #0x1c]!
   1afbc:      	cbnz	w11, 0x1afe0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11fcc>
   1afc0:      	lsl	x11, x26, #4
   1afc4:      	add	x13, x19, #0x28
   1afc8:      	add	x12, x20, x11
   1afcc:      	add	x11, x13, x11
   1afd0:      	ldur	q0, [x12, #0x18]
   1afd4:      	mov	w12, #0x1               // =1
   1afd8:      	strb	w12, [x10]
   1afdc:      	stur	q0, [x11, #0x18]
   1afe0:      	mul	x9, x0, x9
   1afe4:      	mov	w10, #0x2               // =2
   1afe8:      	str	w10, [x8, #0x18]
   1afec:      	str	x9, [x8, #0x20]
   1aff0:      	ldur	x9, [x29, #-0x40]
   1aff4:      	cmp	x9, x24
   1aff8:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1affc:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1b000:      	bti	j
   1b004:      	ldr	x8, [x19, #0x20]
   1b008:      	cbz	x8, 0x1b65c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12648>
   1b00c:      	add	x1, x8, #0x8
   1b010:      	mov	x0, x20
   1b014:      	mov	w2, #0x618              // =1560
   1b018:      	mov	x26, x8
   1b01c:      	bl	0x1d540 <memcpy@plt>
   1b020:      	ldr	x26, [x26]
   1b024:      	str	x26, [x19, #0x20]
   1b028:      	ldur	x9, [x29, #-0x40]
   1b02c:      	cmp	x9, x24
   1b030:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1b034:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1b038:      	bti	j
   1b03c:      	ldurh	w8, [x9, #0x1]
   1b040:      	ldr	w10, [x22, #0x28]
   1b044:      	add	x9, x9, #0x3
   1b048:      	mul	w8, w10, w8
   1b04c:      	add	x25, x25, x8
   1b050:      	stur	x9, [x29, #-0x40]
   1b054:      	cmp	x9, x24
   1b058:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1b05c:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1b060:      	bti	j
   1b064:      	sub	x0, x29, #0x40
   1b068:      	mov	x1, x24
   1b06c:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1b070:      	str	w0, [x20, #0x10]
   1b074:      	ldur	x9, [x29, #-0x40]
   1b078:      	cmp	x9, x24
   1b07c:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1b080:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1b084:      	bti	j
   1b088:      	sub	x0, x29, #0x40
   1b08c:      	mov	x1, x24
   1b090:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1b094:      	cmp	x0, #0x60
   1b098:      	b.hs	0x1b528 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12514>
   1b09c:      	add	x8, x20, x0, lsl #4
   1b0a0:      	ldrb	w8, [x8, #0x1c]
   1b0a4:      	cbz	w8, 0x1b490 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1247c>
   1b0a8:      	lsl	x8, x0, #4
   1b0ac:      	b	0x1b47c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12468>
   1b0b0:      	bti	j
   1b0b4:      	sub	x0, x29, #0x40
   1b0b8:      	mov	x1, x24
   1b0bc:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1b0c0:      	cmp	x0, #0x60
   1b0c4:      	b.hs	0x1b598 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12584>
   1b0c8:      	add	x8, x20, x0, lsl #4
   1b0cc:      	mov	x9, x8
   1b0d0:      	ldrb	w10, [x9, #0x1c]!
   1b0d4:      	cbnz	w10, 0x1b0f8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x120e4>
   1b0d8:      	lsl	x10, x0, #4
   1b0dc:      	add	x12, x19, #0x28
   1b0e0:      	add	x11, x20, x10
   1b0e4:      	add	x10, x12, x10
   1b0e8:      	ldur	q0, [x11, #0x18]
   1b0ec:      	mov	w11, #0x1               // =1
   1b0f0:      	strb	w11, [x9]
   1b0f4:      	stur	q0, [x10, #0x18]
   1b0f8:      	mov	w9, #0x1                // =1
   1b0fc:      	str	w9, [x8, #0x18]
   1b100:      	ldur	x9, [x29, #-0x40]
   1b104:      	cmp	x9, x24
   1b108:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1b10c:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1b110:      	bti	j
   1b114:      	sub	x0, x29, #0x40
   1b118:      	mov	x1, x24
   1b11c:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1b120:      	str	w0, [x20, #0x4]
   1b124:      	ldur	x9, [x29, #-0x40]
   1b128:      	cmp	x9, x24
   1b12c:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1b130:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1b134:      	bti	j
   1b138:      	str	wzr, [x20]
   1b13c:      	str	x8, [x20, #0x8]
   1b140:      	b	0x1b3c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x123b4>
   1b144:      	bti	j
   1b148:      	sub	x0, x29, #0x40
   1b14c:      	mov	x1, x24
   1b150:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1b154:      	mov	x26, x0
   1b158:      	sub	x0, x29, #0x40
   1b15c:      	mov	x1, x24
   1b160:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1b164:      	cmp	x26, #0x60
   1b168:      	b.hs	0x1b5e4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x125d0>
   1b16c:      	cmp	x0, #0x60
   1b170:      	b.hs	0x1b62c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12618>
   1b174:      	add	x8, x20, x26, lsl #4
   1b178:      	mov	x9, x8
   1b17c:      	ldrb	w10, [x9, #0x1c]!
   1b180:      	cbnz	w10, 0x1b1a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12190>
   1b184:      	lsl	x10, x26, #4
   1b188:      	add	x12, x19, #0x28
   1b18c:      	add	x11, x20, x10
   1b190:      	add	x10, x12, x10
   1b194:      	ldur	q0, [x11, #0x18]
   1b198:      	mov	w11, #0x1               // =1
   1b19c:      	strb	w11, [x9]
   1b1a0:      	stur	q0, [x10, #0x18]
   1b1a4:      	mov	w9, #0x5                // =5
   1b1a8:      	str	x0, [x8, #0x20]
   1b1ac:      	str	w9, [x8, #0x18]
   1b1b0:      	ldur	x9, [x29, #-0x40]
   1b1b4:      	cmp	x9, x24
   1b1b8:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1b1bc:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1b1c0:      	bti	j
   1b1c4:      	and	w8, w10, #0xc0
   1b1c8:      	and	x26, x10, #0x3f
   1b1cc:      	cmp	w8, #0x40
   1b1d0:      	b.eq	0x1b4ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12498>
   1b1d4:      	cmp	w8, #0xc0
   1b1d8:      	b.eq	0x1b46c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12458>
   1b1dc:      	cmp	w8, #0x80
   1b1e0:      	b.ne	0x1b65c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12648>
   1b1e4:      	sub	x0, x29, #0x40
   1b1e8:      	mov	x1, x24
   1b1ec:      	str	w28, [x19, #0x4]
   1b1f0:      	mov	w28, w26
   1b1f4:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1b1f8:      	add	x8, x20, w26, uxtw #4
   1b1fc:      	ldrsw	x9, [x22, #0x2c]
   1b200:      	ldrb	w10, [x8, #0x1c]!
   1b204:      	cbnz	w10, 0x1b228 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12214>
   1b208:      	lsl	x10, x28, #4
   1b20c:      	add	x11, x20, x10
   1b210:      	ldur	q0, [x11, #0x18]
   1b214:      	add	x11, x19, #0x28
   1b218:      	add	x10, x11, x10
   1b21c:      	stur	q0, [x10, #0x18]
   1b220:      	mov	w10, #0x1               // =1
   1b224:      	strb	w10, [x8]
   1b228:      	mul	x8, x0, x9
   1b22c:      	add	x9, x20, x28, lsl #4
   1b230:      	mov	w10, #0x2               // =2
   1b234:      	ldr	w28, [x19, #0x4]
   1b238:      	str	w10, [x9, #0x18]
   1b23c:      	str	x8, [x9, #0x20]
   1b240:      	ldur	x9, [x29, #-0x40]
   1b244:      	cmp	x9, x24
   1b248:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1b24c:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1b250:      	bti	j
   1b254:      	sub	x0, x29, #0x40
   1b258:      	mov	x1, x24
   1b25c:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1b260:      	cmp	x0, #0x60
   1b264:      	b.hs	0x1b518 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12504>
   1b268:      	add	x8, x20, x0, lsl #4
   1b26c:      	mov	x9, x8
   1b270:      	ldrb	w10, [x9, #0x1c]!
   1b274:      	cbnz	w10, 0x1b298 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12284>
   1b278:      	lsl	x10, x0, #4
   1b27c:      	add	x12, x19, #0x28
   1b280:      	add	x11, x20, x10
   1b284:      	add	x10, x12, x10
   1b288:      	ldur	q0, [x11, #0x18]
   1b28c:      	mov	w11, #0x1               // =1
   1b290:      	strb	w11, [x9]
   1b294:      	stur	q0, [x10, #0x18]
   1b298:      	str	wzr, [x8, #0x18]
   1b29c:      	ldur	x9, [x29, #-0x40]
   1b2a0:      	cmp	x9, x24
   1b2a4:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1b2a8:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1b2ac:      	bti	j
   1b2b0:      	sub	x0, x29, #0x40
   1b2b4:      	mov	x1, x24
   1b2b8:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1b2bc:      	cmp	x0, #0x60
   1b2c0:      	b.hs	0x1b5c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x125b4>
   1b2c4:      	ldur	x9, [x29, #-0x40]
   1b2c8:      	mov	x10, xzr
   1b2cc:      	mov	x8, xzr
   1b2d0:      	mov	x12, x9
   1b2d4:      	cmp	x12, x24
   1b2d8:      	b.eq	0x1b6ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x126d8>
   1b2dc:      	ldrb	w11, [x12], #0x1
   1b2e0:      	add	x9, x9, #0x1
   1b2e4:      	and	x13, x11, #0x7f
   1b2e8:      	lsl	x13, x13, x10
   1b2ec:      	add	x10, x10, #0x7
   1b2f0:      	orr	x8, x13, x8
   1b2f4:      	tbnz	w11, #0x7, 0x1b2d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x122c0>
   1b2f8:      	add	x12, x20, x0, lsl #4
   1b2fc:      	sub	w13, w10, #0x7
   1b300:      	mov	x15, #-0x1              // =-1
   1b304:      	cmp	w13, #0x39
   1b308:      	mov	w14, #0x3f              // =63
   1b30c:      	lsl	x15, x15, x10
   1b310:      	mov	x13, x12
   1b314:      	ccmp	w11, w14, #0x0, lo
   1b318:      	ldrsw	x10, [x22, #0x2c]
   1b31c:      	ldrb	w16, [x13, #0x1c]!
   1b320:      	csel	x11, x15, xzr, hi
   1b324:      	stur	x9, [x29, #-0x40]
   1b328:      	cbnz	w16, 0x1b34c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12338>
   1b32c:      	lsl	x9, x0, #4
   1b330:      	add	x15, x19, #0x28
   1b334:      	add	x14, x20, x9
   1b338:      	add	x9, x15, x9
   1b33c:      	ldur	q0, [x14, #0x18]
   1b340:      	mov	w14, #0x1               // =1
   1b344:      	strb	w14, [x13]
   1b348:      	stur	q0, [x9, #0x18]
   1b34c:      	orr	x8, x8, x11
   1b350:      	mov	w9, #0x2                // =2
   1b354:      	mul	x8, x8, x10
   1b358:      	str	w9, [x12, #0x18]
   1b35c:      	str	x8, [x12, #0x20]
   1b360:      	ldur	x9, [x29, #-0x40]
   1b364:      	cmp	x9, x24
   1b368:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1b36c:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1b370:      	bti	j
   1b374:      	sub	x0, x29, #0x40
   1b378:      	mov	x1, x24
   1b37c:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1b380:      	cmp	x0, #0x60
   1b384:      	b.hs	0x1b600 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x125ec>
   1b388:      	add	x8, x20, x0, lsl #4
   1b38c:      	mov	x9, x8
   1b390:      	ldrb	w10, [x9, #0x1c]!
   1b394:      	cbnz	w10, 0x1b3b8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x123a4>
   1b398:      	lsl	x10, x0, #4
   1b39c:      	add	x12, x19, #0x28
   1b3a0:      	add	x11, x20, x10
   1b3a4:      	add	x10, x12, x10
   1b3a8:      	ldur	q0, [x11, #0x18]
   1b3ac:      	mov	w11, #0x1               // =1
   1b3b0:      	strb	w11, [x9]
   1b3b4:      	stur	q0, [x10, #0x18]
   1b3b8:      	ldur	x9, [x29, #-0x40]
   1b3bc:      	mov	w10, #0x6               // =6
   1b3c0:      	str	w10, [x8, #0x18]
   1b3c4:      	str	x9, [x8, #0x20]
   1b3c8:      	sub	x0, x29, #0x40
   1b3cc:      	mov	x1, x24
   1b3d0:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1b3d4:      	ldur	x8, [x29, #-0x40]
   1b3d8:      	add	x8, x8, x0
   1b3dc:      	stur	x8, [x29, #-0x40]
   1b3e0:      	mov	x9, x8
   1b3e4:      	cmp	x8, x24
   1b3e8:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1b3ec:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1b3f0:      	bti	j
   1b3f4:      	sub	x0, x29, #0x40
   1b3f8:      	mov	x1, x24
   1b3fc:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1b400:      	mov	x26, x0
   1b404:      	cmp	x0, #0x60
   1b408:      	b.hs	0x1b5a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12594>
   1b40c:      	sub	x0, x29, #0x40
   1b410:      	mov	x1, x24
   1b414:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1b418:      	add	x8, x20, x26, lsl #4
   1b41c:      	ldrsw	x9, [x22, #0x2c]
   1b420:      	mov	x10, x8
   1b424:      	ldrb	w11, [x10, #0x1c]!
   1b428:      	cbnz	w11, 0x1b44c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12438>
   1b42c:      	lsl	x11, x26, #4
   1b430:      	add	x13, x19, #0x28
   1b434:      	add	x12, x20, x11
   1b438:      	add	x11, x13, x11
   1b43c:      	ldur	q0, [x12, #0x18]
   1b440:      	mov	w12, #0x1               // =1
   1b444:      	strb	w12, [x10]
   1b448:      	stur	q0, [x11, #0x18]
   1b44c:      	mul	x9, x0, x9
   1b450:      	mov	w10, #0x4               // =4
   1b454:      	str	w10, [x8, #0x18]
   1b458:      	str	x9, [x8, #0x20]
   1b45c:      	ldur	x9, [x29, #-0x40]
   1b460:      	cmp	x9, x24
   1b464:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1b468:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1b46c:      	add	x8, x20, x26, lsl #4
   1b470:      	ldrb	w8, [x8, #0x1c]
   1b474:      	cbz	w8, 0x1b490 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1247c>
   1b478:      	lsl	x8, x26, #4
   1b47c:      	add	x9, x19, #0x28
   1b480:      	add	x9, x9, x8
   1b484:      	add	x8, x20, x8
   1b488:      	ldur	q0, [x9, #0x18]
   1b48c:      	stur	q0, [x8, #0x18]
   1b490:      	bti	j
   1b494:      	ldur	x9, [x29, #-0x40]
   1b498:      	cmp	x9, x24
   1b49c:      	b.hs	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1b4a0:      	cmp	x25, x21
   1b4a4:      	b.lo	0x1abc0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11bac>
   1b4a8:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1b4ac:      	ldr	w8, [x22, #0x28]
   1b4b0:      	mul	w8, w8, w26
   1b4b4:      	add	x25, x25, x8
   1b4b8:      	ldur	x9, [x29, #-0x40]
   1b4bc:      	cmp	x9, x24
   1b4c0:      	b.lo	0x1b4a0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1248c>
   1b4c4:      	b	0x1ab90 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11b7c>
   1b4c8:      	mov	w0, #0x1                // =1
   1b4cc:      	b	0x1b660 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1264c>
   1b4d0:      	adrp	x8, 0x22000
   1b4d4:      	adrp	x0, 0x4000
   1b4d8:      	add	x0, x0, #0x7e8
   1b4dc:      	b	0x1b534 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12520>
   1b4e0:      	adrp	x8, 0x22000
   1b4e4:      	adrp	x0, 0x4000
   1b4e8:      	add	x0, x0, #0x3a7
   1b4ec:      	ldr	x8, [x8, #0x108]
   1b4f0:      	mov	w1, #0x45               // =69
   1b4f4:      	add	x3, x8, #0x130
   1b4f8:      	b	0x1b644 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12630>
   1b4fc:      	adrp	x8, 0x22000
   1b500:      	adrp	x0, 0x4000
   1b504:      	add	x0, x0, #0xc21
   1b508:      	ldr	x8, [x8, #0x108]
   1b50c:      	mov	w1, #0x44               // =68
   1b510:      	add	x3, x8, #0x130
   1b514:      	b	0x1b644 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12630>
   1b518:      	adrp	x8, 0x22000
   1b51c:      	adrp	x0, 0x4000
   1b520:      	add	x0, x0, #0xd59
   1b524:      	b	0x1b61c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12608>
   1b528:      	adrp	x8, 0x22000
   1b52c:      	adrp	x0, 0x4000
   1b530:      	add	x0, x0, #0x1d1
   1b534:      	ldr	x8, [x8, #0x108]
   1b538:      	add	x3, x8, #0x130
   1b53c:      	mov	w1, #0x47               // =71
   1b540:      	b	0x1b644 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12630>
   1b544:      	adrp	x8, 0x22000
   1b548:      	adrp	x0, 0x3000
   1b54c:      	add	x0, x0, #0x1b9
   1b550:      	ldr	x8, [x8, #0x108]
   1b554:      	mov	w1, #0x46               // =70
   1b558:      	add	x3, x8, #0x130
   1b55c:      	b	0x1b644 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12630>
   1b560:      	adrp	x8, 0x22000
   1b564:      	adrp	x0, 0x4000
   1b568:      	add	x0, x0, #0x68c
   1b56c:      	ldr	x8, [x8, #0x108]
   1b570:      	mov	w1, #0x53               // =83
   1b574:      	add	x3, x8, #0x130
   1b578:      	b	0x1b644 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12630>
   1b57c:      	adrp	x8, 0x22000
   1b580:      	adrp	x0, 0x2000
   1b584:      	add	x0, x0, #0xcd9
   1b588:      	ldr	x8, [x8, #0x108]
   1b58c:      	mov	w1, #0x3e               // =62
   1b590:      	add	x3, x8, #0x130
   1b594:      	b	0x1b644 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12630>
   1b598:      	adrp	x8, 0x22000
   1b59c:      	adrp	x0, 0x4000
   1b5a0:      	add	x0, x0, #0x91d
   1b5a4:      	b	0x1b638 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12624>
   1b5a8:      	adrp	x8, 0x22000
   1b5ac:      	adrp	x1, 0x2000
   1b5b0:      	add	x1, x1, #0xded
   1b5b4:      	ldr	x8, [x8, #0x108]
   1b5b8:      	mov	x2, x26
   1b5bc:      	add	x0, x8, #0x130
   1b5c0:      	bl	0x1d5a0 <fprintf@plt>
   1b5c4:      	b	0x1b64c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12638>
   1b5c8:      	adrp	x8, 0x22000
   1b5cc:      	adrp	x0, 0x3000
   1b5d0:      	add	x0, x0, #0xc9c
   1b5d4:      	ldr	x8, [x8, #0x108]
   1b5d8:      	mov	w1, #0x49               // =73
   1b5dc:      	add	x3, x8, #0x130
   1b5e0:      	b	0x1b644 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12630>
   1b5e4:      	adrp	x8, 0x22000
   1b5e8:      	adrp	x0, 0x4000
   1b5ec:      	add	x0, x0, #0x7a8
   1b5f0:      	ldr	x8, [x8, #0x108]
   1b5f4:      	mov	w1, #0x3f               // =63
   1b5f8:      	add	x3, x8, #0x130
   1b5fc:      	b	0x1b644 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12630>
   1b600:      	adrp	x8, 0x22000
   1b604:      	adrp	x0, 0x3000
   1b608:      	add	x0, x0, #0xbca
   1b60c:      	b	0x1b61c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12608>
   1b610:      	adrp	x8, 0x22000
   1b614:      	adrp	x0, 0x2000
   1b618:      	add	x0, x0, #0xf2b
   1b61c:      	ldr	x8, [x8, #0x108]
   1b620:      	add	x3, x8, #0x130
   1b624:      	mov	w1, #0x41               // =65
   1b628:      	b	0x1b644 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12630>
   1b62c:      	adrp	x8, 0x22000
   1b630:      	adrp	x0, 0x3000
   1b634:      	add	x0, x0, #0x905
   1b638:      	ldr	x8, [x8, #0x108]
   1b63c:      	add	x3, x8, #0x130
   1b640:      	mov	w1, #0x40               // =64
   1b644:      	mov	w2, #0x1                // =1
   1b648:      	bl	0x1d5c0 <fwrite@plt>
   1b64c:      	adrp	x8, 0x22000
   1b650:      	ldr	x8, [x8, #0x108]
   1b654:      	add	x0, x8, #0x130
   1b658:      	bl	0x1d920 <fflush@plt>
   1b65c:      	mov	w0, wzr
   1b660:      	mov	sp, x29
   1b664:      	ldp	x20, x19, [sp, #0x50]
   1b668:      	ldp	x22, x21, [sp, #0x40]
   1b66c:      	ldp	x24, x23, [sp, #0x30]
   1b670:      	ldp	x26, x25, [sp, #0x20]
   1b674:      	ldp	x28, x27, [sp, #0x10]
   1b678:      	ldp	x29, x30, [sp], #0x60
   1b67c:      	autiasp
   1b680:      	ret
   1b684:      	adrp	x20, 0x22000
   1b688:      	nop
   1b68c:      	adr	x1, 0x2bb3
   1b690:      	ldr	x20, [x20, #0x108]
   1b694:      	adrp	x2, 0x3000
   1b698:      	add	x2, x2, #0xe10
   1b69c:      	adrp	x3, 0x3000
   1b6a0:      	add	x3, x3, #0x63f
   1b6a4:      	add	x0, x20, #0x130
   1b6a8:      	bl	0x1d5a0 <fprintf@plt>
   1b6ac:      	add	x0, x20, #0x130
   1b6b0:      	bl	0x1d920 <fflush@plt>
   1b6b4:      	bl	0x1d4d0 <abort@plt>
   1b6b8:      	adrp	x20, 0x22000
   1b6bc:      	nop
   1b6c0:      	adr	x1, 0x2bb3
   1b6c4:      	ldr	x20, [x20, #0x108]
   1b6c8:      	adrp	x2, 0x3000
   1b6cc:      	add	x2, x2, #0xe10
   1b6d0:      	adrp	x3, 0x3000
   1b6d4:      	add	x3, x3, #0x63f
   1b6d8:      	add	x0, x20, #0x130
   1b6dc:      	bl	0x1d5a0 <fprintf@plt>
   1b6e0:      	add	x0, x20, #0x130
   1b6e4:      	bl	0x1d920 <fflush@plt>
   1b6e8:      	bl	0x1d4d0 <abort@plt>
   1b6ec:      	adrp	x20, 0x22000
   1b6f0:      	nop
   1b6f4:      	adr	x1, 0x2bb3
   1b6f8:      	ldr	x20, [x20, #0x108]
   1b6fc:      	adrp	x2, 0x3000
   1b700:      	add	x2, x2, #0xe10
   1b704:      	adrp	x3, 0x3000
   1b708:      	add	x3, x3, #0x63f
   1b70c:      	add	x0, x20, #0x130
   1b710:      	bl	0x1d5a0 <fprintf@plt>
   1b714:      	add	x0, x20, #0x130
   1b718:      	bl	0x1d920 <fflush@plt>
   1b71c:      	bl	0x1d4d0 <abort@plt>
   1b720:      	adrp	x20, 0x22000
   1b724:      	nop
   1b728:      	adr	x1, 0x2bb3
   1b72c:      	ldr	x20, [x20, #0x108]
   1b730:      	adrp	x2, 0x3000
   1b734:      	add	x2, x2, #0xe10
   1b738:      	adrp	x3, 0x3000
   1b73c:      	add	x3, x3, #0x63f
   1b740:      	add	x0, x20, #0x130
   1b744:      	bl	0x1d5a0 <fprintf@plt>
   1b748:      	add	x0, x20, #0x130
   1b74c:      	bl	0x1d920 <fflush@plt>
   1b750:      	bl	0x1d4d0 <abort@plt>
   1b754:      	bti	c
   1b758:      	ldr	w8, [x1]
   1b75c:      	cmp	w8, #0x1d
   1b760:      	b.gt	0x1b77c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12768>
   1b764:      	tbz	w8, #0x1f, 0x1b7a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12794>
   1b768:      	cmn	w8, #0x2
   1b76c:      	b.eq	0x1b794 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12780>
   1b770:      	cmn	w8, #0x1
   1b774:      	b.eq	0x1b7d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x127c4>
   1b778:      	b	0x1b828 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12814>
   1b77c:      	cmp	w8, #0x1f
   1b780:      	b.gt	0x1b7c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x127b4>
   1b784:      	cmp	w8, #0x1e
   1b788:      	b.eq	0x1b7ec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x127d8>
   1b78c:      	cmp	w8, #0x1f
   1b790:      	b.ne	0x1b828 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12814>
   1b794:      	add	x8, x2, #0xf8
   1b798:      	ldr	x8, [x8]
   1b79c:      	ldrsw	x9, [x1, #0x4]
   1b7a0:      	add	x0, x8, x9
   1b7a4:      	ret
   1b7a8:      	cbz	w8, 0x1b800 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x127ec>
   1b7ac:      	cmp	w8, #0x1d
   1b7b0:      	b.ne	0x1b828 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12814>
   1b7b4:      	add	x8, x2, #0xe8
   1b7b8:      	ldr	x8, [x8]
   1b7bc:      	ldrsw	x9, [x1, #0x4]
   1b7c0:      	add	x0, x8, x9
   1b7c4:      	ret
   1b7c8:      	cmp	w8, #0x22
   1b7cc:      	b.eq	0x1b814 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12800>
   1b7d0:      	cmp	w8, #0x20
   1b7d4:      	b.ne	0x1b828 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12814>
   1b7d8:      	add	x8, x2, #0x100
   1b7dc:      	ldr	x8, [x8]
   1b7e0:      	ldrsw	x9, [x1, #0x4]
   1b7e4:      	add	x0, x8, x9
   1b7e8:      	ret
   1b7ec:      	add	x8, x2, #0xf0
   1b7f0:      	ldr	x8, [x8]
   1b7f4:      	ldrsw	x9, [x1, #0x4]
   1b7f8:      	add	x0, x8, x9
   1b7fc:      	ret
   1b800:      	ldr	x8, [x1, #0x8]
   1b804:      	mov	x1, x0
   1b808:      	mov	x3, xzr
   1b80c:      	mov	x0, x8
   1b810:      	b	0x1bfec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12fd8>
   1b814:      	add	x8, x2, #0x108
   1b818:      	ldr	x8, [x8]
   1b81c:      	ldrsw	x9, [x1, #0x4]
   1b820:      	add	x0, x8, x9
   1b824:      	ret
   1b828:      	cmp	w8, #0x1c
   1b82c:      	b.hi	0x1b844 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12830>
   1b830:      	add	x8, x2, x8, lsl #3
   1b834:      	ldr	x8, [x8]
   1b838:      	ldrsw	x9, [x1, #0x4]
   1b83c:      	add	x0, x8, x9
   1b840:      	ret
   1b844:      	paciasp
   1b848:      	stp	x29, x30, [sp, #-0x20]!
   1b84c:      	str	x19, [sp, #0x10]
   1b850:      	mov	x29, sp
   1b854:      	adrp	x19, 0x22000
   1b858:      	nop
   1b85c:      	adr	x1, 0x2bb3
   1b860:      	ldr	x19, [x19, #0x108]
   1b864:      	adrp	x2, 0x3000
   1b868:      	add	x2, x2, #0x9fb
   1b86c:      	adrp	x3, 0x3000
   1b870:      	add	x3, x3, #0x479
   1b874:      	add	x0, x19, #0x130
   1b878:      	bl	0x1d5a0 <fprintf@plt>
   1b87c:      	add	x0, x19, #0x130
   1b880:      	bl	0x1d920 <fflush@plt>
   1b884:      	bl	0x1d4d0 <abort@plt>
   1b888:      	paciasp
   1b88c:      	stp	x29, x30, [sp, #-0x20]!
   1b890:      	str	x19, [sp, #0x10]
   1b894:      	mov	x29, sp
   1b898:      	ldr	w9, [x3]
   1b89c:      	mov	x8, x2
   1b8a0:      	cmp	w9, #0x4
   1b8a4:      	b.gt	0x1b8d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x128c4>
   1b8a8:      	cmp	w9, #0x1
   1b8ac:      	b.eq	0x1b930 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1291c>
   1b8b0:      	cmp	w9, #0x2
   1b8b4:      	b.eq	0x1b8c0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x128ac>
   1b8b8:      	cmp	w9, #0x3
   1b8bc:      	b.ne	0x1ba30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a1c>
   1b8c0:      	ldr	x9, [x3, #0x8]
   1b8c4:      	ldr	x0, [x9, x8]
   1b8c8:      	ldr	x19, [sp, #0x10]
   1b8cc:      	ldp	x29, x30, [sp], #0x20
   1b8d0:      	autiasp
   1b8d4:      	ret
   1b8d8:      	mov	x2, x1
   1b8dc:      	cmp	w9, #0x5
   1b8e0:      	b.eq	0x1b944 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12930>
   1b8e4:      	mov	x1, x0
   1b8e8:      	cmp	w9, #0x6
   1b8ec:      	b.eq	0x1b910 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x128fc>
   1b8f0:      	cmp	w9, #0x7
   1b8f4:      	b.ne	0x1ba30 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a1c>
   1b8f8:      	ldr	x0, [x3, #0x8]
   1b8fc:      	mov	x3, x8
   1b900:      	ldr	x19, [sp, #0x10]
   1b904:      	ldp	x29, x30, [sp], #0x20
   1b908:      	autiasp
   1b90c:      	b	0x1bfec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12fd8>
   1b910:      	ldr	x0, [x3, #0x8]
   1b914:      	mov	x3, x8
   1b918:      	bl	0x1bfec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12fd8>
   1b91c:      	ldr	x0, [x0]
   1b920:      	ldr	x19, [sp, #0x10]
   1b924:      	ldp	x29, x30, [sp], #0x20
   1b928:      	autiasp
   1b92c:      	ret
   1b930:      	mov	x0, xzr
   1b934:      	ldr	x19, [sp, #0x10]
   1b938:      	ldp	x29, x30, [sp], #0x20
   1b93c:      	autiasp
   1b940:      	ret
   1b944:      	ldr	x8, [x3, #0x8]
   1b948:      	cmp	w8, #0x1d
   1b94c:      	b.le	0x1b96c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12958>
   1b950:      	cmp	w8, #0x1f
   1b954:      	b.gt	0x1b99c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12988>
   1b958:      	cmp	w8, #0x1e
   1b95c:      	b.eq	0x1ba00 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x129ec>
   1b960:      	cmp	w8, #0x1f
   1b964:      	b.eq	0x1b9c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x129b0>
   1b968:      	b	0x1b9dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x129c8>
   1b96c:      	cmn	w8, #0x2
   1b970:      	b.eq	0x1b9c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x129b0>
   1b974:      	cmn	w8, #0x1
   1b978:      	b.eq	0x1b9ac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12998>
   1b97c:      	cmp	w8, #0x1d
   1b980:      	b.ne	0x1b9dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x129c8>
   1b984:      	add	x8, x2, #0xe8
   1b988:      	ldr	x0, [x8]
   1b98c:      	ldr	x19, [sp, #0x10]
   1b990:      	ldp	x29, x30, [sp], #0x20
   1b994:      	autiasp
   1b998:      	ret
   1b99c:      	cmp	w8, #0x22
   1b9a0:      	b.eq	0x1ba18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a04>
   1b9a4:      	cmp	w8, #0x20
   1b9a8:      	b.ne	0x1b9dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x129c8>
   1b9ac:      	add	x8, x2, #0x100
   1b9b0:      	ldr	x0, [x8]
   1b9b4:      	ldr	x19, [sp, #0x10]
   1b9b8:      	ldp	x29, x30, [sp], #0x20
   1b9bc:      	autiasp
   1b9c0:      	ret
   1b9c4:      	add	x8, x2, #0xf8
   1b9c8:      	ldr	x0, [x8]
   1b9cc:      	ldr	x19, [sp, #0x10]
   1b9d0:      	ldp	x29, x30, [sp], #0x20
   1b9d4:      	autiasp
   1b9d8:      	ret
   1b9dc:      	cmp	w8, #0x1c
   1b9e0:      	b.hi	0x1ba64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a50>
   1b9e4:      	and	x8, x8, #0xffffffff
   1b9e8:      	add	x8, x2, x8, lsl #3
   1b9ec:      	ldr	x0, [x8]
   1b9f0:      	ldr	x19, [sp, #0x10]
   1b9f4:      	ldp	x29, x30, [sp], #0x20
   1b9f8:      	autiasp
   1b9fc:      	ret
   1ba00:      	add	x8, x2, #0xf0
   1ba04:      	ldr	x0, [x8]
   1ba08:      	ldr	x19, [sp, #0x10]
   1ba0c:      	ldp	x29, x30, [sp], #0x20
   1ba10:      	autiasp
   1ba14:      	ret
   1ba18:      	add	x8, x2, #0x108
   1ba1c:      	ldr	x0, [x8]
   1ba20:      	ldr	x19, [sp, #0x10]
   1ba24:      	ldp	x29, x30, [sp], #0x20
   1ba28:      	autiasp
   1ba2c:      	ret
   1ba30:      	adrp	x19, 0x22000
   1ba34:      	nop
   1ba38:      	adr	x1, 0x2bb3
   1ba3c:      	ldr	x19, [x19, #0x108]
   1ba40:      	adrp	x2, 0x3000
   1ba44:      	add	x2, x2, #0x976
   1ba48:      	adrp	x3, 0x3000
   1ba4c:      	add	x3, x3, #0x494
   1ba50:      	add	x0, x19, #0x130
   1ba54:      	bl	0x1d5a0 <fprintf@plt>
   1ba58:      	add	x0, x19, #0x130
   1ba5c:      	bl	0x1d920 <fflush@plt>
   1ba60:      	bl	0x1d4d0 <abort@plt>
   1ba64:      	adrp	x19, 0x22000
   1ba68:      	nop
   1ba6c:      	adr	x1, 0x2bb3
   1ba70:      	ldr	x19, [x19, #0x108]
   1ba74:      	adrp	x2, 0x3000
   1ba78:      	add	x2, x2, #0x9fb
   1ba7c:      	adrp	x3, 0x3000
   1ba80:      	add	x3, x3, #0x479
   1ba84:      	add	x0, x19, #0x130
   1ba88:      	bl	0x1d5a0 <fprintf@plt>
   1ba8c:      	add	x0, x19, #0x130
   1ba90:      	bl	0x1d920 <fflush@plt>
   1ba94:      	bl	0x1d4d0 <abort@plt>
   1ba98:      	paciasp
   1ba9c:      	stp	x29, x30, [sp, #-0x30]!
   1baa0:      	str	x21, [sp, #0x10]
   1baa4:      	stp	x20, x19, [sp, #0x20]
   1baa8:      	mov	x29, sp
   1baac:      	and	w8, w3, #0xf
   1bab0:      	ldr	x19, [x1]
   1bab4:      	cmp	w8, #0x3
   1bab8:      	b.le	0x1bae0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12acc>
   1babc:      	cmp	w8, #0x9
   1bac0:      	b.le	0x1bb54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12b40>
   1bac4:      	cmp	w8, #0xa
   1bac8:      	b.eq	0x1bc24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12c10>
   1bacc:      	cmp	w8, #0xb
   1bad0:      	b.eq	0x1bc44 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12c30>
   1bad4:      	cmp	w8, #0xc
   1bad8:      	b.eq	0x1bbe4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12bd0>
   1badc:      	b	0x1bdf0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12ddc>
   1bae0:      	cmp	w8, #0x1
   1bae4:      	b.gt	0x1bb24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12b10>
   1bae8:      	cbz	w8, 0x1bbe4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12bd0>
   1baec:      	cmp	w8, #0x1
   1baf0:      	b.ne	0x1bdf0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12ddc>
   1baf4:      	mov	x0, x1
   1baf8:      	mov	x1, x2
   1bafc:      	mov	w20, w3
   1bb00:      	mov	x21, x4
   1bb04:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1bb08:      	mov	x4, x21
   1bb0c:      	mov	w3, w20
   1bb10:      	and	w8, w20, #0xff
   1bb14:      	ubfx	w8, w8, #4, #3
   1bb18:      	cmp	w8, #0x1
   1bb1c:      	b.le	0x1bc60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12c4c>
   1bb20:      	b	0x1bbcc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12bb8>
   1bb24:      	cmp	w8, #0x2
   1bb28:      	b.eq	0x1bc04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12bf0>
   1bb2c:      	cmp	w8, #0x3
   1bb30:      	b.ne	0x1bdf0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12ddc>
   1bb34:      	mov	x8, x19
   1bb38:      	ldr	w0, [x8], #0x4
   1bb3c:      	str	x8, [x1]
   1bb40:      	and	w8, w3, #0xff
   1bb44:      	ubfx	w8, w8, #4, #3
   1bb48:      	cmp	w8, #0x1
   1bb4c:      	b.le	0x1bc60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12c4c>
   1bb50:      	b	0x1bbcc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12bb8>
   1bb54:      	cmp	w8, #0x4
   1bb58:      	b.eq	0x1bbe4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12bd0>
   1bb5c:      	cmp	w8, #0x9
   1bb60:      	b.ne	0x1bdf0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12ddc>
   1bb64:      	mov	x10, xzr
   1bb68:      	mov	x8, xzr
   1bb6c:      	mov	x9, x19
   1bb70:      	mov	x11, x19
   1bb74:      	cmp	x11, x2
   1bb78:      	b.eq	0x1bca0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12c8c>
   1bb7c:      	ldrb	w12, [x11], #0x1
   1bb80:      	add	x9, x9, #0x1
   1bb84:      	and	x13, x12, #0x7f
   1bb88:      	lsl	x13, x13, x10
   1bb8c:      	add	x10, x10, #0x7
   1bb90:      	orr	x8, x13, x8
   1bb94:      	tbnz	w12, #0x7, 0x1bb74 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12b60>
   1bb98:      	sub	w11, w10, #0x7
   1bb9c:      	mov	x13, #-0x1              // =-1
   1bba0:      	str	x9, [x1]
   1bba4:      	cmp	w11, #0x39
   1bba8:      	mov	w11, #0x3f              // =63
   1bbac:      	lsl	x10, x13, x10
   1bbb0:      	ccmp	w12, w11, #0x0, lo
   1bbb4:      	csel	x10, x10, xzr, hi
   1bbb8:      	orr	x0, x8, x10
   1bbbc:      	and	w8, w3, #0xff
   1bbc0:      	ubfx	w8, w8, #4, #3
   1bbc4:      	cmp	w8, #0x1
   1bbc8:      	b.le	0x1bc60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12c4c>
   1bbcc:      	cmp	w8, #0x3
   1bbd0:      	b.gt	0x1bcd4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12cc0>
   1bbd4:      	b.ne	0x1bd18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12d04>
   1bbd8:      	cbz	x4, 0x1bd88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12d74>
   1bbdc:      	add	x0, x0, x4
   1bbe0:      	b	0x1bc70 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12c5c>
   1bbe4:      	mov	x8, x19
   1bbe8:      	ldr	x0, [x8], #0x8
   1bbec:      	str	x8, [x1]
   1bbf0:      	and	w8, w3, #0xff
   1bbf4:      	ubfx	w8, w8, #4, #3
   1bbf8:      	cmp	w8, #0x1
   1bbfc:      	b.le	0x1bc60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12c4c>
   1bc00:      	b	0x1bbcc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12bb8>
   1bc04:      	mov	x8, x19
   1bc08:      	ldrh	w0, [x8], #0x2
   1bc0c:      	str	x8, [x1]
   1bc10:      	and	w8, w3, #0xff
   1bc14:      	ubfx	w8, w8, #4, #3
   1bc18:      	cmp	w8, #0x1
   1bc1c:      	b.le	0x1bc60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12c4c>
   1bc20:      	b	0x1bbcc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12bb8>
   1bc24:      	mov	x8, x19
   1bc28:      	ldrsh	x0, [x8], #0x2
   1bc2c:      	str	x8, [x1]
   1bc30:      	and	w8, w3, #0xff
   1bc34:      	ubfx	w8, w8, #4, #3
   1bc38:      	cmp	w8, #0x1
   1bc3c:      	b.le	0x1bc60 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12c4c>
   1bc40:      	b	0x1bbcc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12bb8>
   1bc44:      	mov	x8, x19
   1bc48:      	ldrsw	x0, [x8], #0x4
   1bc4c:      	str	x8, [x1]
   1bc50:      	and	w8, w3, #0xff
   1bc54:      	ubfx	w8, w8, #4, #3
   1bc58:      	cmp	w8, #0x1
   1bc5c:      	b.gt	0x1bbcc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12bb8>
   1bc60:      	cbz	w8, 0x1bc70 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12c5c>
   1bc64:      	cmp	w8, #0x1
   1bc68:      	b.ne	0x1bdbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12da8>
   1bc6c:      	add	x0, x0, x19
   1bc70:      	tbnz	w3, #0x7, 0x1bc88 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12c74>
   1bc74:      	ldp	x20, x19, [sp, #0x20]
   1bc78:      	ldr	x21, [sp, #0x10]
   1bc7c:      	ldp	x29, x30, [sp], #0x30
   1bc80:      	autiasp
   1bc84:      	ret
   1bc88:      	ldr	x0, [x0]
   1bc8c:      	ldp	x20, x19, [sp, #0x20]
   1bc90:      	ldr	x21, [sp, #0x10]
   1bc94:      	ldp	x29, x30, [sp], #0x30
   1bc98:      	autiasp
   1bc9c:      	ret
   1bca0:      	adrp	x19, 0x22000
   1bca4:      	nop
   1bca8:      	adr	x1, 0x2bb3
   1bcac:      	ldr	x19, [x19, #0x108]
   1bcb0:      	adrp	x2, 0x3000
   1bcb4:      	add	x2, x2, #0xe10
   1bcb8:      	adrp	x3, 0x3000
   1bcbc:      	add	x3, x3, #0x63f
   1bcc0:      	add	x0, x19, #0x130
   1bcc4:      	bl	0x1d5a0 <fprintf@plt>
   1bcc8:      	add	x0, x19, #0x130
   1bccc:      	bl	0x1d920 <fflush@plt>
   1bcd0:      	bl	0x1d4d0 <abort@plt>
   1bcd4:      	cmp	w8, #0x4
   1bcd8:      	b.eq	0x1bd54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12d40>
   1bcdc:      	cmp	w8, #0x5
   1bce0:      	b.ne	0x1bdbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12da8>
   1bce4:      	adrp	x19, 0x22000
   1bce8:      	nop
   1bcec:      	adr	x1, 0x2bb3
   1bcf0:      	ldr	x19, [x19, #0x108]
   1bcf4:      	adrp	x2, 0x4000
   1bcf8:      	add	x2, x2, #0xc66
   1bcfc:      	adrp	x3, 0x3000
   1bd00:      	add	x3, x3, #0x946
   1bd04:      	add	x0, x19, #0x130
   1bd08:      	bl	0x1d5a0 <fprintf@plt>
   1bd0c:      	add	x0, x19, #0x130
   1bd10:      	bl	0x1d920 <fflush@plt>
   1bd14:      	bl	0x1d4d0 <abort@plt>
   1bd18:      	cmp	w8, #0x2
   1bd1c:      	b.ne	0x1bdbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12da8>
   1bd20:      	adrp	x19, 0x22000
   1bd24:      	nop
   1bd28:      	adr	x1, 0x2bb3
   1bd2c:      	ldr	x19, [x19, #0x108]
   1bd30:      	adrp	x2, 0x4000
   1bd34:      	add	x2, x2, #0xc66
   1bd38:      	adrp	x3, 0x4000
   1bd3c:      	add	x3, x3, #0x219
   1bd40:      	add	x0, x19, #0x130
   1bd44:      	bl	0x1d5a0 <fprintf@plt>
   1bd48:      	add	x0, x19, #0x130
   1bd4c:      	bl	0x1d920 <fflush@plt>
   1bd50:      	bl	0x1d4d0 <abort@plt>
   1bd54:      	adrp	x19, 0x22000
   1bd58:      	nop
   1bd5c:      	adr	x1, 0x2bb3
   1bd60:      	ldr	x19, [x19, #0x108]
   1bd64:      	adrp	x2, 0x4000
   1bd68:      	add	x2, x2, #0xc66
   1bd6c:      	adrp	x3, 0x2000
   1bd70:      	add	x3, x3, #0xbc7
   1bd74:      	add	x0, x19, #0x130
   1bd78:      	bl	0x1d5a0 <fprintf@plt>
   1bd7c:      	add	x0, x19, #0x130
   1bd80:      	bl	0x1d920 <fflush@plt>
   1bd84:      	bl	0x1d4d0 <abort@plt>
   1bd88:      	adrp	x19, 0x22000
   1bd8c:      	nop
   1bd90:      	adr	x1, 0x2bb3
   1bd94:      	ldr	x19, [x19, #0x108]
   1bd98:      	adrp	x2, 0x4000
   1bd9c:      	add	x2, x2, #0xc66
   1bda0:      	adrp	x3, 0x4000
   1bda4:      	add	x3, x3, #0x543
   1bda8:      	add	x0, x19, #0x130
   1bdac:      	bl	0x1d5a0 <fprintf@plt>
   1bdb0:      	add	x0, x19, #0x130
   1bdb4:      	bl	0x1d920 <fflush@plt>
   1bdb8:      	bl	0x1d4d0 <abort@plt>
   1bdbc:      	adrp	x19, 0x22000
   1bdc0:      	nop
   1bdc4:      	adr	x1, 0x2bb3
   1bdc8:      	ldr	x19, [x19, #0x108]
   1bdcc:      	adrp	x2, 0x4000
   1bdd0:      	add	x2, x2, #0xc66
   1bdd4:      	adrp	x3, 0x3000
   1bdd8:      	add	x3, x3, #0xdf7
   1bddc:      	add	x0, x19, #0x130
   1bde0:      	bl	0x1d5a0 <fprintf@plt>
   1bde4:      	add	x0, x19, #0x130
   1bde8:      	bl	0x1d920 <fflush@plt>
   1bdec:      	bl	0x1d4d0 <abort@plt>
   1bdf0:      	adrp	x19, 0x22000
   1bdf4:      	nop
   1bdf8:      	adr	x1, 0x2bb3
   1bdfc:      	ldr	x19, [x19, #0x108]
   1be00:      	adrp	x2, 0x4000
   1be04:      	add	x2, x2, #0xc66
   1be08:      	adrp	x3, 0x3000
   1be0c:      	add	x3, x3, #0xdf7
   1be10:      	add	x0, x19, #0x130
   1be14:      	bl	0x1d5a0 <fprintf@plt>
   1be18:      	add	x0, x19, #0x130
   1be1c:      	bl	0x1d920 <fflush@plt>
   1be20:      	bl	0x1d4d0 <abort@plt>
   1be24:      	paciasp
   1be28:      	stp	x29, x30, [sp, #-0x20]!
   1be2c:      	str	x19, [sp, #0x10]
   1be30:      	mov	x29, sp
   1be34:      	ldr	x9, [x0]
   1be38:      	cmp	x9, x1
   1be3c:      	b.eq	0x1bf84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12f70>
   1be40:      	mov	x10, x9
   1be44:      	mov	x8, x0
   1be48:      	ldrb	w11, [x10], #0x1
   1be4c:      	and	x0, x11, #0x7f
   1be50:      	tbnz	w11, #0x7, 0x1be68 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e54>
   1be54:      	str	x10, [x8]
   1be58:      	ldr	x19, [sp, #0x10]
   1be5c:      	ldp	x29, x30, [sp], #0x20
   1be60:      	autiasp
   1be64:      	ret
   1be68:      	cmp	x10, x1
   1be6c:      	b.eq	0x1bf84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12f70>
   1be70:      	ldrsb	w11, [x9, #0x1]
   1be74:      	and	w10, w11, #0x7f
   1be78:      	orr	x0, x0, x10, lsl #7
   1be7c:      	add	x10, x9, #0x2
   1be80:      	tbz	w11, #0x1f, 0x1be54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e40>
   1be84:      	cmp	x10, x1
   1be88:      	b.eq	0x1bf84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12f70>
   1be8c:      	ldrsb	w11, [x9, #0x2]
   1be90:      	and	w10, w11, #0x7f
   1be94:      	orr	x0, x0, x10, lsl #14
   1be98:      	add	x10, x9, #0x3
   1be9c:      	tbz	w11, #0x1f, 0x1be54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e40>
   1bea0:      	cmp	x10, x1
   1bea4:      	b.eq	0x1bf84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12f70>
   1bea8:      	ldrsb	w11, [x9, #0x3]
   1beac:      	and	w10, w11, #0x7f
   1beb0:      	orr	x0, x0, x10, lsl #21
   1beb4:      	add	x10, x9, #0x4
   1beb8:      	tbz	w11, #0x1f, 0x1be54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e40>
   1bebc:      	cmp	x10, x1
   1bec0:      	b.eq	0x1bf84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12f70>
   1bec4:      	ldrsb	w11, [x9, #0x4]
   1bec8:      	and	w10, w11, #0x7f
   1becc:      	orr	x0, x0, x10, lsl #28
   1bed0:      	add	x10, x9, #0x5
   1bed4:      	tbz	w11, #0x1f, 0x1be54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e40>
   1bed8:      	cmp	x10, x1
   1bedc:      	b.eq	0x1bf84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12f70>
   1bee0:      	ldrsb	w11, [x9, #0x5]
   1bee4:      	and	w10, w11, #0x7f
   1bee8:      	orr	x0, x0, x10, lsl #35
   1beec:      	add	x10, x9, #0x6
   1bef0:      	tbz	w11, #0x1f, 0x1be54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e40>
   1bef4:      	cmp	x10, x1
   1bef8:      	b.eq	0x1bf84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12f70>
   1befc:      	ldrsb	w11, [x9, #0x6]
   1bf00:      	and	w10, w11, #0x7f
   1bf04:      	orr	x0, x0, x10, lsl #42
   1bf08:      	add	x10, x9, #0x7
   1bf0c:      	tbz	w11, #0x1f, 0x1be54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e40>
   1bf10:      	cmp	x10, x1
   1bf14:      	b.eq	0x1bf84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12f70>
   1bf18:      	ldrsb	w11, [x9, #0x7]
   1bf1c:      	and	w10, w11, #0x7f
   1bf20:      	orr	x0, x0, x10, lsl #49
   1bf24:      	add	x10, x9, #0x8
   1bf28:      	tbz	w11, #0x1f, 0x1be54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e40>
   1bf2c:      	cmp	x10, x1
   1bf30:      	b.eq	0x1bf84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12f70>
   1bf34:      	ldrsb	w11, [x9, #0x8]
   1bf38:      	and	w10, w11, #0x7f
   1bf3c:      	orr	x0, x0, x10, lsl #56
   1bf40:      	add	x10, x9, #0x9
   1bf44:      	tbz	w11, #0x1f, 0x1be54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e40>
   1bf48:      	cmp	x10, x1
   1bf4c:      	b.eq	0x1bf84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12f70>
   1bf50:      	ldrb	w11, [x10]
   1bf54:      	tst	w11, #0x7e
   1bf58:      	b.ne	0x1bfb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12fa4>
   1bf5c:      	add	x10, x9, #0xa
   1bf60:      	tbnz	w11, #0x7, 0x1bf7c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12f68>
   1bf64:      	orr	x0, x0, x11, lsl #63
   1bf68:      	str	x10, [x8]
   1bf6c:      	ldr	x19, [sp, #0x10]
   1bf70:      	ldp	x29, x30, [sp], #0x20
   1bf74:      	autiasp
   1bf78:      	ret
   1bf7c:      	cmp	x10, x1
   1bf80:      	b.ne	0x1bfb8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12fa4>
   1bf84:      	adrp	x19, 0x22000
   1bf88:      	nop
   1bf8c:      	adr	x1, 0x2bb3
   1bf90:      	ldr	x19, [x19, #0x108]
   1bf94:      	adrp	x2, 0x3000
   1bf98:      	add	x2, x2, #0x80
   1bf9c:      	adrp	x3, 0x3000
   1bfa0:      	add	x3, x3, #0x367
   1bfa4:      	add	x0, x19, #0x130
   1bfa8:      	bl	0x1d5a0 <fprintf@plt>
   1bfac:      	add	x0, x19, #0x130
   1bfb0:      	bl	0x1d920 <fflush@plt>
   1bfb4:      	bl	0x1d4d0 <abort@plt>
   1bfb8:      	adrp	x19, 0x22000
   1bfbc:      	nop
   1bfc0:      	adr	x1, 0x2bb3
   1bfc4:      	ldr	x19, [x19, #0x108]
   1bfc8:      	adrp	x2, 0x3000
   1bfcc:      	add	x2, x2, #0x80
   1bfd0:      	adrp	x3, 0x3000
   1bfd4:      	add	x3, x3, #0x7d8
   1bfd8:      	add	x0, x19, #0x130
   1bfdc:      	bl	0x1d5a0 <fprintf@plt>
   1bfe0:      	add	x0, x19, #0x130
   1bfe4:      	bl	0x1d920 <fflush@plt>
   1bfe8:      	bl	0x1d4d0 <abort@plt>
   1bfec:      	paciasp
   1bff0:      	stp	x29, x30, [sp, #-0x60]!
   1bff4:      	stp	x28, x27, [sp, #0x10]
   1bff8:      	stp	x26, x25, [sp, #0x20]
   1bffc:      	stp	x24, x23, [sp, #0x30]
   1c000:      	stp	x22, x21, [sp, #0x40]
   1c004:      	stp	x20, x19, [sp, #0x50]
   1c008:      	mov	x29, sp
   1c00c:      	sub	sp, sp, #0x330
   1c010:      	mov	x8, x0
   1c014:      	stur	x0, [x29, #-0x8]
   1c018:      	sub	x0, x29, #0x8
   1c01c:      	add	x1, x8, #0x14
   1c020:      	mov	x21, x3
   1c024:      	mov	x19, x2
   1c028:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1c02c:      	ldur	x10, [x29, #-0x8]
   1c030:      	str	x21, [sp, #0x10]
   1c034:      	add	x20, x10, x0
   1c038:      	cmp	x10, x20
   1c03c:      	b.hs	0x1c76c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13758>
   1c040:      	add	x8, sp, #0x8
   1c044:      	add	x21, x19, #0xf0
   1c048:      	add	x22, x19, #0xe8
   1c04c:      	add	x23, x19, #0x108
   1c050:      	add	x24, x19, #0xf8
   1c054:      	add	x27, x8, #0x8
   1c058:      	add	x25, x19, #0x100
   1c05c:      	nop
   1c060:      	adr	x26, 0x5584
   1c064:      	b	0x1c07c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13068>
   1c068:      	ldr	x8, [x8]
   1c06c:      	str	x8, [x27, #0x8]!
   1c070:      	ldur	x10, [x29, #-0x8]
   1c074:      	cmp	x10, x20
   1c078:      	b.hs	0x1c768 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13754>
   1c07c:      	add	x8, x10, #0x1
   1c080:      	stur	x8, [x29, #-0x8]
   1c084:      	ldrb	w9, [x10]
   1c088:      	sub	w11, w9, #0x3
   1c08c:      	cmp	w11, #0x91
   1c090:      	b.hi	0x1c864 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13850>
   1c094:      	adr	x12, 0x1c0a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13090>
   1c098:      	ldrh	w13, [x26, x11, lsl #1]
   1c09c:      	add	x12, x12, x13, lsl #2
   1c0a0:      	br	x12
   1c0a4:      	bti	j
   1c0a8:      	sub	w8, w9, #0x30
   1c0ac:      	b	0x1c06c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13058>
   1c0b0:      	bti	j
   1c0b4:      	mov	x12, xzr
   1c0b8:      	mov	x10, xzr
   1c0bc:      	sub	w11, w9, #0x70
   1c0c0:      	mov	x13, x8
   1c0c4:      	cmp	x13, x20
   1c0c8:      	b.eq	0x1c794 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13780>
   1c0cc:      	ldrb	w14, [x13], #0x1
   1c0d0:      	add	x8, x8, #0x1
   1c0d4:      	and	x15, x14, #0x7f
   1c0d8:      	lsl	x15, x15, x12
   1c0dc:      	add	x12, x12, #0x7
   1c0e0:      	orr	x10, x15, x10
   1c0e4:      	tbnz	w14, #0x7, 0x1c0c4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x130b0>
   1c0e8:      	sub	w13, w12, #0x7
   1c0ec:      	mov	x15, #-0x1              // =-1
   1c0f0:      	stur	x8, [x29, #-0x8]
   1c0f4:      	cmp	w13, #0x39
   1c0f8:      	mov	w13, #0x3f              // =63
   1c0fc:      	lsl	x12, x15, x12
   1c100:      	ccmp	w14, w13, #0x0, lo
   1c104:      	csel	x12, x12, xzr, hi
   1c108:      	cmp	w9, #0x8d
   1c10c:      	b.le	0x1c168 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13154>
   1c110:      	cmp	w9, #0x8f
   1c114:      	b.gt	0x1c190 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1317c>
   1c118:      	cmp	w9, #0x8e
   1c11c:      	mov	x8, x21
   1c120:      	b.eq	0x1c1b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x131a0>
   1c124:      	cmp	w9, #0x8f
   1c128:      	mov	x8, x24
   1c12c:      	b.eq	0x1c1b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x131a0>
   1c130:      	b	0x1c1a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13194>
   1c134:      	bti	j
   1c138:      	cmp	w9, #0x6f
   1c13c:      	mov	x8, x24
   1c140:      	b.eq	0x1c068 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13054>
   1c144:      	cmp	w9, #0x6e
   1c148:      	mov	x8, x21
   1c14c:      	b.eq	0x1c068 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13054>
   1c150:      	cmp	w9, #0x6d
   1c154:      	mov	x8, x22
   1c158:      	b.eq	0x1c068 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13054>
   1c15c:      	sub	w8, w9, #0x50
   1c160:      	add	x8, x19, w8, uxtw #3
   1c164:      	b	0x1c068 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13054>
   1c168:      	cmp	w9, #0x6e
   1c16c:      	mov	x8, x24
   1c170:      	b.eq	0x1c1b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x131a0>
   1c174:      	cmp	w9, #0x6f
   1c178:      	mov	x8, x25
   1c17c:      	b.eq	0x1c1b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x131a0>
   1c180:      	cmp	w9, #0x8d
   1c184:      	mov	x8, x22
   1c188:      	b.eq	0x1c1b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x131a0>
   1c18c:      	b	0x1c1a8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13194>
   1c190:      	cmp	w9, #0x90
   1c194:      	mov	x8, x25
   1c198:      	b.eq	0x1c1b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x131a0>
   1c19c:      	cmp	w9, #0x92
   1c1a0:      	mov	x8, x23
   1c1a4:      	b.eq	0x1c1b4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x131a0>
   1c1a8:      	cmp	w11, #0x1c
   1c1ac:      	b.hi	0x1c830 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1381c>
   1c1b0:      	add	x8, x19, w11, uxtw #3
   1c1b4:      	ldr	x8, [x8]
   1c1b8:      	orr	x9, x10, x12
   1c1bc:      	add	x8, x8, x9
   1c1c0:      	b	0x1c06c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13058>
   1c1c4:      	bti	j
   1c1c8:      	ldur	x8, [x10, #0x1]
   1c1cc:      	add	x9, x10, #0x9
   1c1d0:      	b	0x1c4d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x134c0>
   1c1d4:      	bti	j
   1c1d8:      	sub	x0, x29, #0x8
   1c1dc:      	mov	x1, x20
   1c1e0:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1c1e4:      	ldur	x10, [x29, #-0x8]
   1c1e8:      	mov	x9, xzr
   1c1ec:      	mov	x8, xzr
   1c1f0:      	mov	x11, x10
   1c1f4:      	cmp	x11, x20
   1c1f8:      	b.eq	0x1c7c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x137b4>
   1c1fc:      	ldrb	w12, [x11], #0x1
   1c200:      	add	x10, x10, #0x1
   1c204:      	and	x13, x12, #0x7f
   1c208:      	lsl	x13, x13, x9
   1c20c:      	add	x9, x9, #0x7
   1c210:      	orr	x8, x13, x8
   1c214:      	tbnz	w12, #0x7, 0x1c1f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x131e0>
   1c218:      	sub	w11, w9, #0x7
   1c21c:      	mov	x13, #-0x1              // =-1
   1c220:      	stur	x10, [x29, #-0x8]
   1c224:      	cmp	w11, #0x39
   1c228:      	mov	w11, #0x3f              // =63
   1c22c:      	lsl	x9, x13, x9
   1c230:      	ccmp	w12, w11, #0x0, lo
   1c234:      	csel	x9, x9, xzr, hi
   1c238:      	cmp	w0, #0x1d
   1c23c:      	b.le	0x1c6cc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x136b8>
   1c240:      	cmp	w0, #0x1f
   1c244:      	b.gt	0x1c71c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13708>
   1c248:      	cmp	w0, #0x1e
   1c24c:      	mov	x10, x21
   1c250:      	b.eq	0x1c740 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1372c>
   1c254:      	cmp	w0, #0x1f
   1c258:      	mov	x10, x24
   1c25c:      	b.eq	0x1c740 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1372c>
   1c260:      	b	0x1c734 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13720>
   1c264:      	bti	j
   1c268:      	mov	x8, x27
   1c26c:      	ldr	x9, [x27]
   1c270:      	ldr	x10, [x8, #-0x8]!
   1c274:      	cmp	x10, x9
   1c278:      	cset	w9, lo
   1c27c:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c280:      	bti	j
   1c284:      	mov	x8, x27
   1c288:      	ldr	x9, [x27]
   1c28c:      	ldr	x10, [x8, #-0x8]!
   1c290:      	cmp	x10, x9
   1c294:      	cset	w9, ls
   1c298:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c29c:      	bti	j
   1c2a0:      	mov	x8, x27
   1c2a4:      	ldr	x9, [x27]
   1c2a8:      	ldr	x10, [x8, #-0x8]!
   1c2ac:      	sdiv	x11, x10, x9
   1c2b0:      	msub	x9, x11, x9, x10
   1c2b4:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c2b8:      	bti	j
   1c2bc:      	mov	x8, x27
   1c2c0:      	ldr	x9, [x27]
   1c2c4:      	ldr	x10, [x8, #-0x8]!
   1c2c8:      	cmp	x10, x9
   1c2cc:      	cset	w9, eq
   1c2d0:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c2d4:      	bti	j
   1c2d8:      	ldursh	x8, [x10, #0x1]
   1c2dc:      	add	x9, x10, #0x3
   1c2e0:      	b	0x1c4d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x134c0>
   1c2e4:      	bti	j
   1c2e8:      	ldr	x11, [x27], #-0x8
   1c2ec:      	ldursh	x8, [x10, #0x1]
   1c2f0:      	add	x9, x10, #0x3
   1c2f4:      	stur	x9, [x29, #-0x8]
   1c2f8:      	cbz	x11, 0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c2fc:      	add	x8, x9, x8
   1c300:      	stur	x8, [x29, #-0x8]
   1c304:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c308:      	bti	j
   1c30c:      	mov	x8, x27
   1c310:      	ldr	x9, [x27]
   1c314:      	ldr	x10, [x8, #-0x8]!
   1c318:      	cmp	x10, x9
   1c31c:      	cset	w9, hs
   1c320:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c324:      	bti	j
   1c328:      	mov	x10, xzr
   1c32c:      	mov	x9, xzr
   1c330:      	mov	x11, x8
   1c334:      	cmp	x11, x20
   1c338:      	b.eq	0x1c7fc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x137e8>
   1c33c:      	ldrb	w12, [x11], #0x1
   1c340:      	add	x8, x8, #0x1
   1c344:      	and	x13, x12, #0x7f
   1c348:      	lsl	x13, x13, x10
   1c34c:      	add	x10, x10, #0x7
   1c350:      	orr	x9, x13, x9
   1c354:      	tbnz	w12, #0x7, 0x1c334 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13320>
   1c358:      	sub	w11, w10, #0x7
   1c35c:      	mov	x13, #-0x1              // =-1
   1c360:      	stur	x8, [x29, #-0x8]
   1c364:      	cmp	w11, #0x39
   1c368:      	mov	w11, #0x3f              // =63
   1c36c:      	lsl	x10, x13, x10
   1c370:      	ccmp	w12, w11, #0x0, lo
   1c374:      	csel	x10, x10, xzr, hi
   1c378:      	orr	x9, x9, x10
   1c37c:      	str	x9, [x27, #0x8]!
   1c380:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c384:      	bti	j
   1c388:      	mov	x8, x27
   1c38c:      	ldr	x9, [x27]
   1c390:      	ldr	x10, [x8, #-0x8]!
   1c394:      	and	x9, x10, x9
   1c398:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c39c:      	bti	j
   1c3a0:      	mov	x8, x27
   1c3a4:      	ldr	x9, [x27]
   1c3a8:      	ldr	x10, [x8, #-0x8]!
   1c3ac:      	cmp	x10, x9
   1c3b0:      	cset	w9, hi
   1c3b4:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c3b8:      	bti	j
   1c3bc:      	ldursw	x8, [x10, #0x1]
   1c3c0:      	add	x9, x10, #0x5
   1c3c4:      	b	0x1c4d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x134c0>
   1c3c8:      	bti	j
   1c3cc:      	mov	x8, x27
   1c3d0:      	ldr	x9, [x27]
   1c3d4:      	ldr	x10, [x8, #-0x8]!
   1c3d8:      	eor	x9, x10, x9
   1c3dc:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c3e0:      	bti	j
   1c3e4:      	ldr	x8, [x27]
   1c3e8:      	tbz	x8, #0x3f, 0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c3ec:      	b	0x1c60c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x135f8>
   1c3f0:      	bti	j
   1c3f4:      	ldrsb	x8, [x10, #0x1]
   1c3f8:      	b	0x1c438 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13424>
   1c3fc:      	bti	j
   1c400:      	ldr	x8, [x27]
   1c404:      	b	0x1c06c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13058>
   1c408:      	bti	j
   1c40c:      	sub	x0, x29, #0x8
   1c410:      	mov	x1, x20
   1c414:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1c418:      	str	x0, [x27, #0x8]!
   1c41c:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c420:      	bti	j
   1c424:      	ldur	w8, [x10, #0x1]
   1c428:      	add	x9, x10, #0x5
   1c42c:      	b	0x1c4d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x134c0>
   1c430:      	bti	j
   1c434:      	ldrb	w8, [x10, #0x1]
   1c438:      	add	x9, x10, #0x2
   1c43c:      	b	0x1c4d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x134c0>
   1c440:      	bti	j
   1c444:      	sub	x27, x27, #0x8
   1c448:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c44c:      	bti	j
   1c450:      	ldurh	w8, [x10, #0x1]
   1c454:      	add	x9, x10, #0x3
   1c458:      	b	0x1c4d4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x134c0>
   1c45c:      	bti	j
   1c460:      	ldr	x8, [x27]
   1c464:      	ldr	x8, [x8]
   1c468:      	str	x8, [x27]
   1c46c:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c470:      	bti	j
   1c474:      	ldur	q0, [x27, #-0x10]
   1c478:      	ldr	x8, [x27]
   1c47c:      	stur	q0, [x27, #-0x8]
   1c480:      	stur	x8, [x27, #-0x10]
   1c484:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c488:      	bti	j
   1c48c:      	mov	x8, x27
   1c490:      	ldr	x9, [x27]
   1c494:      	ldr	x10, [x8, #-0x8]!
   1c498:      	sdiv	x9, x10, x9
   1c49c:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c4a0:      	bti	j
   1c4a4:      	ldur	x8, [x27, #-0x8]
   1c4a8:      	b	0x1c06c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13058>
   1c4ac:      	bti	j
   1c4b0:      	ldur	q0, [x27, #-0x8]
   1c4b4:      	ext	v0.16b, v0.16b, v0.16b, #0x8
   1c4b8:      	stur	q0, [x27, #-0x8]
   1c4bc:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c4c0:      	bti	j
   1c4c4:      	ldrb	w8, [x10, #0x1]
   1c4c8:      	add	x9, x10, #0x2
   1c4cc:      	sub	x8, x27, x8, lsl #3
   1c4d0:      	ldr	x8, [x8]
   1c4d4:      	stur	x9, [x29, #-0x8]
   1c4d8:      	b	0x1c06c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13058>
   1c4dc:      	bti	j
   1c4e0:      	ldr	x8, [x27]
   1c4e4:      	mvn	x8, x8
   1c4e8:      	str	x8, [x27]
   1c4ec:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c4f0:      	bti	j
   1c4f4:      	mov	x8, x27
   1c4f8:      	ldr	x9, [x27]
   1c4fc:      	ldr	x10, [x8, #-0x8]!
   1c500:      	lsl	x9, x10, x9
   1c504:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c508:      	bti	j
   1c50c:      	mov	x8, x27
   1c510:      	ldr	x9, [x27]
   1c514:      	ldr	x10, [x8, #-0x8]!
   1c518:      	lsr	x9, x10, x9
   1c51c:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c520:      	bti	j
   1c524:      	mov	x8, x27
   1c528:      	ldr	x9, [x27]
   1c52c:      	ldr	x10, [x8, #-0x8]!
   1c530:      	add	x9, x10, x9
   1c534:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c538:      	bti	j
   1c53c:      	add	x8, x10, #0x2
   1c540:      	stur	x8, [x29, #-0x8]
   1c544:      	ldr	x8, [x27]
   1c548:      	ldrb	w9, [x10, #0x1]
   1c54c:      	cmp	w9, #0x3
   1c550:      	b.gt	0x1c690 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1367c>
   1c554:      	cmp	w9, #0x1
   1c558:      	b.eq	0x1c750 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1373c>
   1c55c:      	cmp	w9, #0x2
   1c560:      	b.ne	0x1c90c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x138f8>
   1c564:      	ldrh	w8, [x8]
   1c568:      	str	x8, [x27]
   1c56c:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c570:      	bti	j
   1c574:      	sub	x0, x29, #0x8
   1c578:      	mov	x1, x20
   1c57c:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1c580:      	ldr	x8, [x27]
   1c584:      	add	x8, x8, x0
   1c588:      	str	x8, [x27]
   1c58c:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c590:      	bti	j
   1c594:      	mov	x8, x27
   1c598:      	ldr	x9, [x27]
   1c59c:      	ldr	x10, [x8, #-0x8]!
   1c5a0:      	asr	x9, x10, x9
   1c5a4:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c5a8:      	bti	j
   1c5ac:      	ldr	x8, [x27]
   1c5b0:      	ldr	x8, [x8]
   1c5b4:      	str	x8, [x27, #-0x8]!
   1c5b8:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c5bc:      	bti	j
   1c5c0:      	mov	x8, x27
   1c5c4:      	ldr	x9, [x27]
   1c5c8:      	ldr	x10, [x8, #-0x8]!
   1c5cc:      	mul	x9, x10, x9
   1c5d0:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c5d4:      	bti	j
   1c5d8:      	mov	x8, x27
   1c5dc:      	ldr	x9, [x27]
   1c5e0:      	ldr	x10, [x8, #-0x8]!
   1c5e4:      	sub	x9, x10, x9
   1c5e8:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c5ec:      	bti	j
   1c5f0:      	mov	x8, x27
   1c5f4:      	ldr	x9, [x27]
   1c5f8:      	ldr	x10, [x8, #-0x8]!
   1c5fc:      	orr	x9, x10, x9
   1c600:      	b	0x1c630 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1361c>
   1c604:      	bti	j
   1c608:      	ldr	x8, [x27]
   1c60c:      	neg	x8, x8
   1c610:      	str	x8, [x27]
   1c614:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c618:      	bti	j
   1c61c:      	mov	x8, x27
   1c620:      	ldr	x9, [x27]
   1c624:      	ldr	x10, [x8, #-0x8]!
   1c628:      	cmp	x10, x9
   1c62c:      	cset	w9, ne
   1c630:      	str	x9, [x8]
   1c634:      	mov	x27, x8
   1c638:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c63c:      	bti	j
   1c640:      	ldursh	x8, [x10, #0x1]
   1c644:      	add	x8, x10, x8
   1c648:      	add	x8, x8, #0x3
   1c64c:      	stur	x8, [x29, #-0x8]
   1c650:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c654:      	bti	j
   1c658:      	sub	x0, x29, #0x8
   1c65c:      	mov	x1, x20
   1c660:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1c664:      	cmp	w0, #0x1d
   1c668:      	b.le	0x1c6a4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13690>
   1c66c:      	cmp	w0, #0x1f
   1c670:      	b.gt	0x1c6f4 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x136e0>
   1c674:      	cmp	w0, #0x1e
   1c678:      	mov	x8, x21
   1c67c:      	b.eq	0x1c068 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13054>
   1c680:      	cmp	w0, #0x1f
   1c684:      	mov	x8, x24
   1c688:      	b.eq	0x1c068 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13054>
   1c68c:      	b	0x1c70c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x136f8>
   1c690:      	cmp	w9, #0x4
   1c694:      	b.eq	0x1c75c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13748>
   1c698:      	cmp	w9, #0x8
   1c69c:      	b.eq	0x1c464 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13450>
   1c6a0:      	b	0x1c90c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x138f8>
   1c6a4:      	cmn	w0, #0x2
   1c6a8:      	mov	x8, x24
   1c6ac:      	b.eq	0x1c068 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13054>
   1c6b0:      	cmn	w0, #0x1
   1c6b4:      	mov	x8, x25
   1c6b8:      	b.eq	0x1c068 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13054>
   1c6bc:      	cmp	w0, #0x1d
   1c6c0:      	mov	x8, x22
   1c6c4:      	b.eq	0x1c068 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13054>
   1c6c8:      	b	0x1c70c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x136f8>
   1c6cc:      	cmn	w0, #0x2
   1c6d0:      	mov	x10, x24
   1c6d4:      	b.eq	0x1c740 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1372c>
   1c6d8:      	cmn	w0, #0x1
   1c6dc:      	mov	x10, x25
   1c6e0:      	b.eq	0x1c740 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1372c>
   1c6e4:      	cmp	w0, #0x1d
   1c6e8:      	mov	x10, x22
   1c6ec:      	b.eq	0x1c740 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1372c>
   1c6f0:      	b	0x1c734 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13720>
   1c6f4:      	cmp	w0, #0x20
   1c6f8:      	mov	x8, x25
   1c6fc:      	b.eq	0x1c068 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13054>
   1c700:      	cmp	w0, #0x22
   1c704:      	mov	x8, x23
   1c708:      	b.eq	0x1c068 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13054>
   1c70c:      	cmp	w0, #0x1c
   1c710:      	b.hi	0x1c974 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13960>
   1c714:      	add	x8, x19, w0, uxtw #3
   1c718:      	b	0x1c068 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13054>
   1c71c:      	cmp	w0, #0x20
   1c720:      	mov	x10, x25
   1c724:      	b.eq	0x1c740 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1372c>
   1c728:      	cmp	w0, #0x22
   1c72c:      	mov	x10, x23
   1c730:      	b.eq	0x1c740 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1372c>
   1c734:      	cmp	w0, #0x1c
   1c738:      	b.hi	0x1c940 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1392c>
   1c73c:      	add	x10, x19, w0, uxtw #3
   1c740:      	ldr	x10, [x10]
   1c744:      	orr	x8, x8, x9
   1c748:      	add	x8, x10, x8
   1c74c:      	b	0x1c06c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13058>
   1c750:      	ldrb	w8, [x8]
   1c754:      	str	x8, [x27]
   1c758:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c75c:      	ldr	w8, [x8]
   1c760:      	str	x8, [x27]
   1c764:      	b	0x1c070 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1305c>
   1c768:      	ldr	x21, [x27]
   1c76c:      	mov	x0, x21
   1c770:      	add	sp, sp, #0x330
   1c774:      	ldp	x20, x19, [sp, #0x50]
   1c778:      	ldp	x22, x21, [sp, #0x40]
   1c77c:      	ldp	x24, x23, [sp, #0x30]
   1c780:      	ldp	x26, x25, [sp, #0x20]
   1c784:      	ldp	x28, x27, [sp, #0x10]
   1c788:      	ldp	x29, x30, [sp], #0x60
   1c78c:      	autiasp
   1c790:      	ret
   1c794:      	adrp	x19, 0x22000
   1c798:      	nop
   1c79c:      	adr	x1, 0x2bb3
   1c7a0:      	ldr	x19, [x19, #0x108]
   1c7a4:      	adrp	x2, 0x3000
   1c7a8:      	add	x2, x2, #0xe10
   1c7ac:      	adrp	x3, 0x3000
   1c7b0:      	add	x3, x3, #0x63f
   1c7b4:      	add	x0, x19, #0x130
   1c7b8:      	bl	0x1d5a0 <fprintf@plt>
   1c7bc:      	add	x0, x19, #0x130
   1c7c0:      	bl	0x1d920 <fflush@plt>
   1c7c4:      	bl	0x1d4d0 <abort@plt>
   1c7c8:      	adrp	x19, 0x22000
   1c7cc:      	nop
   1c7d0:      	adr	x1, 0x2bb3
   1c7d4:      	ldr	x19, [x19, #0x108]
   1c7d8:      	adrp	x2, 0x3000
   1c7dc:      	add	x2, x2, #0xe10
   1c7e0:      	adrp	x3, 0x3000
   1c7e4:      	add	x3, x3, #0x63f
   1c7e8:      	add	x0, x19, #0x130
   1c7ec:      	bl	0x1d5a0 <fprintf@plt>
   1c7f0:      	add	x0, x19, #0x130
   1c7f4:      	bl	0x1d920 <fflush@plt>
   1c7f8:      	bl	0x1d4d0 <abort@plt>
   1c7fc:      	adrp	x19, 0x22000
   1c800:      	nop
   1c804:      	adr	x1, 0x2bb3
   1c808:      	ldr	x19, [x19, #0x108]
   1c80c:      	adrp	x2, 0x3000
   1c810:      	add	x2, x2, #0xe10
   1c814:      	adrp	x3, 0x3000
   1c818:      	add	x3, x3, #0x63f
   1c81c:      	add	x0, x19, #0x130
   1c820:      	bl	0x1d5a0 <fprintf@plt>
   1c824:      	add	x0, x19, #0x130
   1c828:      	bl	0x1d920 <fflush@plt>
   1c82c:      	bl	0x1d4d0 <abort@plt>
   1c830:      	adrp	x19, 0x22000
   1c834:      	nop
   1c838:      	adr	x1, 0x2bb3
   1c83c:      	ldr	x19, [x19, #0x108]
   1c840:      	adrp	x2, 0x3000
   1c844:      	add	x2, x2, #0x9fb
   1c848:      	adrp	x3, 0x3000
   1c84c:      	add	x3, x3, #0x479
   1c850:      	add	x0, x19, #0x130
   1c854:      	bl	0x1d5a0 <fprintf@plt>
   1c858:      	add	x0, x19, #0x130
   1c85c:      	bl	0x1d920 <fflush@plt>
   1c860:      	bl	0x1d4d0 <abort@plt>
   1c864:      	bti	j
   1c868:      	adrp	x19, 0x22000
   1c86c:      	nop
   1c870:      	adr	x1, 0x2bb3
   1c874:      	ldr	x19, [x19, #0x108]
   1c878:      	adrp	x2, 0x3000
   1c87c:      	add	x2, x2, #0x6fe
   1c880:      	adrp	x3, 0x4000
   1c884:      	add	x3, x3, #0x249
   1c888:      	add	x0, x19, #0x130
   1c88c:      	bl	0x1d5a0 <fprintf@plt>
   1c890:      	add	x0, x19, #0x130
   1c894:      	bl	0x1d920 <fflush@plt>
   1c898:      	bl	0x1d4d0 <abort@plt>
   1c89c:      	bti	j
   1c8a0:      	adrp	x19, 0x22000
   1c8a4:      	nop
   1c8a8:      	adr	x1, 0x2bb3
   1c8ac:      	ldr	x19, [x19, #0x108]
   1c8b0:      	adrp	x2, 0x3000
   1c8b4:      	add	x2, x2, #0x6fe
   1c8b8:      	adrp	x3, 0x3000
   1c8bc:      	add	x3, x3, #0x65c
   1c8c0:      	add	x0, x19, #0x130
   1c8c4:      	bl	0x1d5a0 <fprintf@plt>
   1c8c8:      	add	x0, x19, #0x130
   1c8cc:      	bl	0x1d920 <fflush@plt>
   1c8d0:      	bl	0x1d4d0 <abort@plt>
   1c8d4:      	bti	j
   1c8d8:      	adrp	x19, 0x22000
   1c8dc:      	nop
   1c8e0:      	adr	x1, 0x2bb3
   1c8e4:      	ldr	x19, [x19, #0x108]
   1c8e8:      	adrp	x2, 0x3000
   1c8ec:      	add	x2, x2, #0x6fe
   1c8f0:      	adrp	x3, 0x4000
   1c8f4:      	add	x3, x3, #0xc72
   1c8f8:      	add	x0, x19, #0x130
   1c8fc:      	bl	0x1d5a0 <fprintf@plt>
   1c900:      	add	x0, x19, #0x130
   1c904:      	bl	0x1d920 <fflush@plt>
   1c908:      	bl	0x1d4d0 <abort@plt>
   1c90c:      	adrp	x19, 0x22000
   1c910:      	nop
   1c914:      	adr	x1, 0x2bb3
   1c918:      	ldr	x19, [x19, #0x108]
   1c91c:      	adrp	x2, 0x3000
   1c920:      	add	x2, x2, #0x6fe
   1c924:      	adrp	x3, 0x3000
   1c928:      	add	x3, x3, #0xe1b
   1c92c:      	add	x0, x19, #0x130
   1c930:      	bl	0x1d5a0 <fprintf@plt>
   1c934:      	add	x0, x19, #0x130
   1c938:      	bl	0x1d920 <fflush@plt>
   1c93c:      	bl	0x1d4d0 <abort@plt>
   1c940:      	adrp	x19, 0x22000
   1c944:      	nop
   1c948:      	adr	x1, 0x2bb3
   1c94c:      	ldr	x19, [x19, #0x108]
   1c950:      	adrp	x2, 0x3000
   1c954:      	add	x2, x2, #0x9fb
   1c958:      	adrp	x3, 0x3000
   1c95c:      	add	x3, x3, #0x479
   1c960:      	add	x0, x19, #0x130
   1c964:      	bl	0x1d5a0 <fprintf@plt>
   1c968:      	add	x0, x19, #0x130
   1c96c:      	bl	0x1d920 <fflush@plt>
   1c970:      	bl	0x1d4d0 <abort@plt>
   1c974:      	adrp	x19, 0x22000
   1c978:      	nop
   1c97c:      	adr	x1, 0x2bb3
   1c980:      	ldr	x19, [x19, #0x108]
   1c984:      	adrp	x2, 0x3000
   1c988:      	add	x2, x2, #0x9fb
   1c98c:      	adrp	x3, 0x3000
   1c990:      	add	x3, x3, #0x479
   1c994:      	add	x0, x19, #0x130
   1c998:      	bl	0x1d5a0 <fprintf@plt>
   1c99c:      	add	x0, x19, #0x130
   1c9a0:      	bl	0x1d920 <fflush@plt>
   1c9a4:      	bl	0x1d4d0 <abort@plt>
   1c9a8:      	paciasp
   1c9ac:      	stp	x29, x30, [sp, #-0x60]!
   1c9b0:      	stp	x28, x27, [sp, #0x10]
   1c9b4:      	stp	x26, x25, [sp, #0x20]
   1c9b8:      	stp	x24, x23, [sp, #0x30]
   1c9bc:      	stp	x22, x21, [sp, #0x40]
   1c9c0:      	stp	x20, x19, [sp, #0x50]
   1c9c4:      	mov	x29, sp
   1c9c8:      	sub	sp, sp, #0x6a0
   1c9cc:      	mov	w21, w3
   1c9d0:      	mov	x19, x2
   1c9d4:      	mov	x22, x1
   1c9d8:      	mov	x20, x0
   1c9dc:      	cbz	w3, 0x1ca00 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x139ec>
   1c9e0:      	ldp	x2, x3, [x19, #0x10]
   1c9e4:      	add	x5, sp, #0x50
   1c9e8:      	ldr	x0, [x20, #0x8]
   1c9ec:      	add	x6, sp, #0x18
   1c9f0:      	mov	x1, x22
   1c9f4:      	add	x4, x2, w21, uxtw
   1c9f8:      	bl	0x1ced0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13ebc>
   1c9fc:      	tbnz	w0, #0x0, 0x1cb18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13b04>
   1ca00:      	ldr	x2, [x19, #0x20]
   1ca04:      	cbz	x2, 0x1ca24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13a10>
   1ca08:      	ldr	x0, [x20, #0x8]
   1ca0c:      	ldr	w3, [x19, #0x28]
   1ca10:      	add	x4, sp, #0x50
   1ca14:      	add	x5, sp, #0x18
   1ca18:      	mov	x1, x22
   1ca1c:      	bl	0x1d098 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14084>
   1ca20:      	tbnz	w0, #0x0, 0x1cb18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13b04>
   1ca24:      	ldr	x23, [x19]
   1ca28:      	nop
   1ca2c:      	adr	x0, 0x269d8
   1ca30:      	bl	0x1d960 <pthread_rwlock_rdlock@plt>
   1ca34:      	adrp	x8, 0x26000
   1ca38:      	adrp	x9, 0x26000
   1ca3c:      	ldr	x8, [x8, #0x3b8]
   1ca40:      	ldr	x9, [x9, #0x3c0]
   1ca44:      	cmp	x8, x9
   1ca48:      	b.hs	0x1caec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13ad8>
   1ca4c:      	cmn	x23, #0x1
   1ca50:      	b.ne	0x1ca64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13a50>
   1ca54:      	b	0x1ca98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13a84>
   1ca58:      	add	x8, x8, #0x20
   1ca5c:      	cmp	x8, x9
   1ca60:      	b.hs	0x1caec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13ad8>
   1ca64:      	ldr	x10, [x8]
   1ca68:      	cmp	x10, x23
   1ca6c:      	b.ne	0x1ca58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13a44>
   1ca70:      	ldr	x10, [x8, #0x8]
   1ca74:      	cmp	x10, x22
   1ca78:      	b.hi	0x1ca58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13a44>
   1ca7c:      	ldr	x10, [x8, #0x10]
   1ca80:      	cmp	x10, x22
   1ca84:      	b.ls	0x1ca58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13a44>
   1ca88:      	b	0x1cab0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13a9c>
   1ca8c:      	add	x8, x8, #0x20
   1ca90:      	cmp	x8, x9
   1ca94:      	b.hs	0x1caec <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13ad8>
   1ca98:      	ldr	x10, [x8, #0x8]
   1ca9c:      	cmp	x10, x22
   1caa0:      	b.hi	0x1ca8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13a78>
   1caa4:      	ldr	x10, [x8, #0x10]
   1caa8:      	cmp	x10, x22
   1caac:      	b.ls	0x1ca8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13a78>
   1cab0:      	ldr	x23, [x8, #0x18]
   1cab4:      	nop
   1cab8:      	adr	x0, 0x269d8
   1cabc:      	bl	0x1d940 <pthread_rwlock_unlock@plt>
   1cac0:      	cbz	x23, 0x1caf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13ae4>
   1cac4:      	ldp	x2, x3, [x19, #0x10]
   1cac8:      	add	x5, sp, #0x50
   1cacc:      	ldr	x0, [x20, #0x8]
   1cad0:      	add	x6, sp, #0x18
   1cad4:      	mov	x1, x22
   1cad8:      	mov	x4, x23
   1cadc:      	bl	0x1ced0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13ebc>
   1cae0:      	tbz	w0, #0x0, 0x1caf8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13ae4>
   1cae4:      	mov	w24, wzr
   1cae8:      	b	0x1cb1c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13b08>
   1caec:      	nop
   1caf0:      	adr	x0, 0x269d8
   1caf4:      	bl	0x1d940 <pthread_rwlock_unlock@plt>
   1caf8:      	ldp	x2, x3, [x19, #0x10]
   1cafc:      	add	x5, sp, #0x50
   1cb00:      	ldr	x0, [x20, #0x8]
   1cb04:      	add	x6, sp, #0x18
   1cb08:      	mov	x1, x22
   1cb0c:      	mov	x4, xzr
   1cb10:      	bl	0x1ced0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13ebc>
   1cb14:      	tbz	w0, #0x0, 0x1cc54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13c40>
   1cb18:      	mov	w24, #0x1               // =1
   1cb1c:      	ldr	x25, [x19]
   1cb20:      	add	x0, sp, #0x80
   1cb24:      	mov	w1, wzr
   1cb28:      	mov	w2, #0x618              // =1560
   1cb2c:      	bl	0x1d5b0 <memset@plt>
   1cb30:      	ldr	x0, [x20, #0x8]
   1cb34:      	add	x1, sp, #0x50
   1cb38:      	add	x2, sp, #0x18
   1cb3c:      	add	x5, sp, #0x80
   1cb40:      	mov	x3, x22
   1cb44:      	mov	w4, #0x4                // =4
   1cb48:      	bl	0x1ab0c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x11af8>
   1cb4c:      	tbz	w0, #0x0, 0x1cc54 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13c40>
   1cb50:      	ldr	q0, [sp, #0x70]
   1cb54:      	add	x8, x20, #0x220
   1cb58:      	ldr	x9, [sp, #0x38]
   1cb5c:      	ldr	x22, [sp, #0x68]
   1cb60:      	cmp	w21, #0x0
   1cb64:      	mov	w0, #0x1                // =1
   1cb68:      	stur	q0, [x8, #0x8]
   1cb6c:      	ldr	w8, [sp, #0x90]
   1cb70:      	str	x9, [x20, #0x238]
   1cb74:      	eor	w9, w24, #0x1
   1cb78:      	str	x8, [x20, #0x240]
   1cb7c:      	mov	w8, #0x3000000          // =50331648
   1cb80:      	str	w8, [x20, #0x250]
   1cb84:      	ldp	x23, x8, [sp, #0x50]
   1cb88:      	str	x22, [x20, #0x220]
   1cb8c:      	str	xzr, [x20, #0x248]
   1cb90:      	str	w8, [x20, #0x254]
   1cb94:      	csinc	w8, w9, wzr, eq
   1cb98:      	str	x23, [x20, #0x258]
   1cb9c:      	str	x25, [x20, #0x260]
   1cba0:      	tbnz	w8, #0x0, 0x1cc58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13c44>
   1cba4:      	ldr	x8, [x19, #0x20]
   1cba8:      	cbnz	x8, 0x1cc58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13c44>
   1cbac:      	ldr	x24, [x19]
   1cbb0:      	nop
   1cbb4:      	adr	x0, 0x269d8
   1cbb8:      	str	q0, [sp]
   1cbbc:      	bl	0x1d930 <pthread_rwlock_wrlock@plt>
   1cbc0:      	adrp	x25, 0x26000
   1cbc4:      	adrp	x26, 0x26000
   1cbc8:      	ldr	x8, [x25, #0x3c0]
   1cbcc:      	ldr	x9, [x26, #0x3c8]
   1cbd0:      	cmp	x8, x9
   1cbd4:      	b.lo	0x1cc28 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13c14>
   1cbd8:      	adrp	x27, 0x26000
   1cbdc:      	ldr	x21, [x27, #0x3b8]
   1cbe0:      	sub	x19, x9, x21
   1cbe4:      	lsl	x0, x19, #2
   1cbe8:      	asr	x28, x19, #3
   1cbec:      	bl	0x1d870 <malloc@plt>
   1cbf0:      	mov	x1, x21
   1cbf4:      	mov	x2, x19
   1cbf8:      	mov	x20, x0
   1cbfc:      	bl	0x1d540 <memcpy@plt>
   1cc00:      	nop
   1cc04:      	adr	x8, 0x26a10
   1cc08:      	cmp	x21, x8
   1cc0c:      	b.eq	0x1cc18 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13c04>
   1cc10:      	mov	x0, x21
   1cc14:      	bl	0x1d880 <free@plt>
   1cc18:      	add	x9, x20, x28, lsl #5
   1cc1c:      	add	x8, x20, x19
   1cc20:      	str	x20, [x27, #0x3b8]
   1cc24:      	str	x9, [x26, #0x3c8]
   1cc28:      	ldr	q0, [sp]
   1cc2c:      	stp	x24, x22, [x8]
   1cc30:      	nop
   1cc34:      	adr	x0, 0x269d8
   1cc38:      	str	x23, [x8, #0x18]
   1cc3c:      	str	d0, [x8, #0x10]
   1cc40:      	add	x8, x8, #0x20
   1cc44:      	str	x8, [x25, #0x3c0]
   1cc48:      	bl	0x1d940 <pthread_rwlock_unlock@plt>
   1cc4c:      	mov	w0, #0x1                // =1
   1cc50:      	b	0x1cc58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13c44>
   1cc54:      	mov	w0, wzr
   1cc58:      	add	sp, sp, #0x6a0
   1cc5c:      	ldp	x20, x19, [sp, #0x50]
   1cc60:      	ldp	x22, x21, [sp, #0x40]
   1cc64:      	ldp	x24, x23, [sp, #0x30]
   1cc68:      	ldp	x26, x25, [sp, #0x20]
   1cc6c:      	ldp	x28, x27, [sp, #0x10]
   1cc70:      	ldp	x29, x30, [sp], #0x60
   1cc74:      	autiasp
   1cc78:      	ret
   1cc7c:      	paciasp
   1cc80:      	sub	sp, sp, #0x70
   1cc84:      	stp	x29, x30, [sp, #0x20]
   1cc88:      	str	x25, [sp, #0x30]
   1cc8c:      	stp	x24, x23, [sp, #0x40]
   1cc90:      	stp	x22, x21, [sp, #0x50]
   1cc94:      	stp	x20, x19, [sp, #0x60]
   1cc98:      	add	x29, sp, #0x20
   1cc9c:      	ldrh	w21, [x0, #0x18]
   1cca0:      	cbz	x21, 0x1ccbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13ca8>
   1cca4:      	ldr	x8, [x2, #0x10]
   1cca8:      	ldr	x22, [x0]
   1ccac:      	mov	x20, x0
   1ccb0:      	mov	x19, x2
   1ccb4:      	cmp	x8, x22
   1ccb8:      	b.hs	0x1cce0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13ccc>
   1ccbc:      	mov	w0, wzr
   1ccc0:      	ldp	x20, x19, [sp, #0x60]
   1ccc4:      	ldr	x25, [sp, #0x30]
   1ccc8:      	ldp	x22, x21, [sp, #0x50]
   1cccc:      	ldp	x24, x23, [sp, #0x40]
   1ccd0:      	ldp	x29, x30, [sp, #0x20]
   1ccd4:      	add	sp, sp, #0x70
   1ccd8:      	autiasp
   1ccdc:      	ret
   1cce0:      	ldr	x11, [x20, #0x10]
   1cce4:      	mov	x9, x21
   1cce8:      	mov	x10, x11
   1ccec:      	b	0x1ccfc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13ce8>
   1ccf0:      	subs	x9, x9, #0x1
   1ccf4:      	mov	x11, x10
   1ccf8:      	b.eq	0x1ccbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13ca8>
   1ccfc:      	ldr	w12, [x10], #0x38
   1cd00:      	cmp	w12, #0x1
   1cd04:      	b.ne	0x1ccf0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13cdc>
   1cd08:      	ldr	x12, [x11, #0x10]
   1cd0c:      	add	x12, x12, x22
   1cd10:      	cmp	x8, x12
   1cd14:      	b.lo	0x1ccf0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13cdc>
   1cd18:      	ldr	x11, [x11, #0x28]
   1cd1c:      	add	x13, x11, x12
   1cd20:      	cmp	x8, x13
   1cd24:      	b.hs	0x1ccf0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13cdc>
   1cd28:      	ldr	x8, [x19, #0x8]
   1cd2c:      	mov	w9, #-0x1               // =-1
   1cd30:      	mov	w25, #0xe550            // =58704
   1cd34:      	add	x23, x21, x9
   1cd38:      	mov	w24, #0x38              // =56
   1cd3c:      	movk	w25, #0x6474, lsl #16
   1cd40:      	stp	x12, x11, [x8]
   1cd44:      	b	0x1cd58 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13d44>
   1cd48:      	sub	w21, w21, #0x1
   1cd4c:      	sub	x23, x23, #0x1
   1cd50:      	and	w8, w21, #0xffff
   1cd54:      	cbz	w8, 0x1ccbc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13ca8>
   1cd58:      	and	x8, x23, #0xffffffff
   1cd5c:      	ldr	x9, [x20, #0x10]
   1cd60:      	umull	x10, w8, w24
   1cd64:      	ldr	w10, [x9, x10]
   1cd68:      	cmp	w10, w25
   1cd6c:      	b.ne	0x1cd48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13d34>
   1cd70:      	umaddl	x8, w8, w24, x9
   1cd74:      	ldp	x0, x10, [x19]
   1cd78:      	mov	x3, sp
   1cd7c:      	ldr	x9, [x8, #0x10]
   1cd80:      	ldr	x8, [x8, #0x28]
   1cd84:      	add	x1, x9, x22
   1cd88:      	add	x2, x8, x1
   1cd8c:      	stp	x1, x8, [x10, #0x20]
   1cd90:      	bl	0x1cdb0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13d9c>
   1cd94:      	tbz	w0, #0x0, 0x1cd48 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13d34>
   1cd98:      	ldr	x8, [sp]
   1cd9c:      	ldr	x9, [x19, #0x8]
   1cda0:      	mov	x10, #-0x1              // =-1
   1cda4:      	mov	w0, #0x1                // =1
   1cda8:      	stp	x8, x10, [x9, #0x10]
   1cdac:      	b	0x1ccc0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13cac>
   1cdb0:      	paciasp
   1cdb4:      	stp	x29, x30, [sp, #-0x40]!
   1cdb8:      	str	x23, [sp, #0x10]
   1cdbc:      	stp	x22, x21, [sp, #0x20]
   1cdc0:      	stp	x20, x19, [sp, #0x30]
   1cdc4:      	mov	x29, sp
   1cdc8:      	mov	x20, x3
   1cdcc:      	sub	x3, x2, x1
   1cdd0:      	mov	x19, x1
   1cdd4:      	cmp	x3, #0x3
   1cdd8:      	b.hi	0x1ce04 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13df0>
   1cddc:      	cmp	x2, x19
   1cde0:      	b.eq	0x1ce8c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13e78>
   1cde4:      	adrp	x20, 0x22000
   1cde8:      	adrp	x1, 0x3000
   1cdec:      	add	x1, x1, #0xf53
   1cdf0:      	ldr	x20, [x20, #0x108]
   1cdf4:      	mov	x2, x19
   1cdf8:      	add	x0, x20, #0x130
   1cdfc:      	bl	0x1d5a0 <fprintf@plt>
   1ce00:      	b	0x1ce84 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13e70>
   1ce04:      	ldrb	w8, [x19]
   1ce08:      	cmp	w8, #0x1
   1ce0c:      	b.ne	0x1ce64 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13e50>
   1ce10:      	add	x8, x19, #0x4
   1ce14:      	ldrb	w21, [x19, #0x2]
   1ce18:      	ldrb	w3, [x19, #0x1]
   1ce1c:      	str	x8, [x29, #0x18]
   1ce20:      	add	x1, x29, #0x18
   1ce24:      	mov	x4, x19
   1ce28:      	ldrb	w8, [x19, #0x3]
   1ce2c:      	mov	x23, x0
   1ce30:      	mov	x22, x2
   1ce34:      	strb	w8, [x20, #0x18]
   1ce38:      	bl	0x1ba98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a84>
   1ce3c:      	cmp	w21, #0xff
   1ce40:      	str	x0, [x20]
   1ce44:      	b.eq	0x1cea8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13e94>
   1ce48:      	add	x1, x29, #0x18
   1ce4c:      	mov	x0, x23
   1ce50:      	mov	x2, x22
   1ce54:      	mov	w3, w21
   1ce58:      	mov	x4, x19
   1ce5c:      	bl	0x1ba98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a84>
   1ce60:      	b	0x1ceac <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13e98>
   1ce64:      	adrp	x20, 0x22000
   1ce68:      	adrp	x1, 0x3000
   1ce6c:      	add	x1, x1, #0x384
   1ce70:      	ldr	x20, [x20, #0x108]
   1ce74:      	mov	w2, w8
   1ce78:      	mov	x3, x19
   1ce7c:      	add	x0, x20, #0x130
   1ce80:      	bl	0x1d5a0 <fprintf@plt>
   1ce84:      	add	x0, x20, #0x130
   1ce88:      	bl	0x1d920 <fflush@plt>
   1ce8c:      	mov	w0, wzr
   1ce90:      	ldp	x20, x19, [sp, #0x30]
   1ce94:      	ldr	x23, [sp, #0x10]
   1ce98:      	ldp	x22, x21, [sp, #0x20]
   1ce9c:      	ldp	x29, x30, [sp], #0x40
   1cea0:      	autiasp
   1cea4:      	ret
   1cea8:      	mov	x0, xzr
   1ceac:      	ldr	x8, [x29, #0x18]
   1ceb0:      	stp	x0, x8, [x20, #0x8]
   1ceb4:      	mov	w0, #0x1                // =1
   1ceb8:      	ldp	x20, x19, [sp, #0x30]
   1cebc:      	ldr	x23, [sp, #0x10]
   1cec0:      	ldp	x22, x21, [sp, #0x20]
   1cec4:      	ldp	x29, x30, [sp], #0x40
   1cec8:      	autiasp
   1cecc:      	ret
   1ced0:      	paciasp
   1ced4:      	sub	sp, sp, #0x70
   1ced8:      	stp	x29, x30, [sp, #0x10]
   1cedc:      	stp	x28, x27, [sp, #0x20]
   1cee0:      	stp	x26, x25, [sp, #0x30]
   1cee4:      	stp	x24, x23, [sp, #0x40]
   1cee8:      	stp	x22, x21, [sp, #0x50]
   1ceec:      	stp	x20, x19, [sp, #0x60]
   1cef0:      	add	x29, sp, #0x10
   1cef4:      	cmp	x4, #0x0
   1cef8:      	add	x8, x3, x2
   1cefc:      	csel	x22, x2, x4, eq
   1cf00:      	cmn	x3, #0x1
   1cf04:      	csinv	x27, x8, xzr, ne
   1cf08:      	str	x22, [sp, #0x8]
   1cf0c:      	cmp	x22, x27
   1cf10:      	b.hs	0x1d054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14040>
   1cf14:      	mov	x21, x6
   1cf18:      	mov	x19, x5
   1cf1c:      	mov	x23, x2
   1cf20:      	mov	x24, x1
   1cf24:      	mov	x20, x0
   1cf28:      	b	0x1cf38 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13f24>
   1cf2c:      	cmp	x22, x27
   1cf30:      	str	x22, [sp, #0x8]
   1cf34:      	b.hs	0x1d054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14040>
   1cf38:      	mov	x8, x22
   1cf3c:      	mov	x26, x22
   1cf40:      	ldr	w9, [x8], #0x4
   1cf44:      	str	x8, [sp, #0x8]
   1cf48:      	cmn	w9, #0x1
   1cf4c:      	b.ne	0x1cf5c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13f48>
   1cf50:      	ldur	x9, [x26, #0x4]
   1cf54:      	add	x8, x26, #0xc
   1cf58:      	str	x8, [sp, #0x8]
   1cf5c:      	cbz	x9, 0x1d054 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14040>
   1cf60:      	ldr	w10, [x8]
   1cf64:      	add	x22, x8, x9
   1cf68:      	cbz	w10, 0x1cf2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13f18>
   1cf6c:      	sub	x1, x8, x10
   1cf70:      	cmp	x1, x23
   1cf74:      	b.lo	0x1cf2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13f18>
   1cf78:      	cmp	x1, x27
   1cf7c:      	b.hs	0x1cf2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13f18>
   1cf80:      	mov	x0, x20
   1cf84:      	mov	x2, x21
   1cf88:      	bl	0x19c40 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10c2c>
   1cf8c:      	cbnz	x0, 0x1cf2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13f18>
   1cf90:      	ldr	x8, [sp, #0x8]
   1cf94:      	ldrb	w3, [x21, #0x18]
   1cf98:      	add	x1, sp, #0x8
   1cf9c:      	mov	x0, x20
   1cfa0:      	mov	x2, x22
   1cfa4:      	mov	x4, xzr
   1cfa8:      	add	x8, x8, #0x4
   1cfac:      	str	x8, [sp, #0x8]
   1cfb0:      	bl	0x1ba98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a84>
   1cfb4:      	ldrb	w8, [x21, #0x18]
   1cfb8:      	mov	x25, x0
   1cfbc:      	add	x1, sp, #0x8
   1cfc0:      	mov	x0, x20
   1cfc4:      	mov	x2, x22
   1cfc8:      	mov	x4, xzr
   1cfcc:      	and	w3, w8, #0xf
   1cfd0:      	bl	0x1ba98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a84>
   1cfd4:      	cmp	x25, x24
   1cfd8:      	b.hs	0x1cf2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13f18>
   1cfdc:      	add	x28, x0, x25
   1cfe0:      	cmp	x28, x24
   1cfe4:      	b.lo	0x1cf2c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13f18>
   1cfe8:      	ldrb	w8, [x21, #0x31]
   1cfec:      	str	xzr, [x19, #0x28]
   1cff0:      	cbz	w8, 0x1d07c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14068>
   1cff4:      	add	x0, sp, #0x8
   1cff8:      	mov	x1, x22
   1cffc:      	bl	0x1be24 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12e10>
   1d000:      	ldrb	w8, [x21, #0x19]
   1d004:      	ldr	x24, [sp, #0x8]
   1d008:      	cmp	w8, #0xff
   1d00c:      	add	x23, x24, x0
   1d010:      	b.eq	0x1d080 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1406c>
   1d014:      	add	x1, sp, #0x8
   1d018:      	and	w3, w8, #0xf
   1d01c:      	mov	x0, x20
   1d020:      	mov	x2, x22
   1d024:      	mov	x4, xzr
   1d028:      	bl	0x1ba98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a84>
   1d02c:      	cbz	x0, 0x1d080 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1406c>
   1d030:      	ldrb	w3, [x21, #0x19]
   1d034:      	add	x1, sp, #0x8
   1d038:      	mov	x0, x20
   1d03c:      	mov	x2, x22
   1d040:      	mov	x4, xzr
   1d044:      	str	x24, [sp, #0x8]
   1d048:      	bl	0x1ba98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a84>
   1d04c:      	str	x0, [x19, #0x28]
   1d050:      	b	0x1d080 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1406c>
   1d054:      	mov	w0, wzr
   1d058:      	ldp	x20, x19, [sp, #0x60]
   1d05c:      	ldp	x22, x21, [sp, #0x50]
   1d060:      	ldp	x24, x23, [sp, #0x40]
   1d064:      	ldp	x26, x25, [sp, #0x30]
   1d068:      	ldp	x28, x27, [sp, #0x20]
   1d06c:      	ldp	x29, x30, [sp, #0x10]
   1d070:      	add	sp, sp, #0x70
   1d074:      	autiasp
   1d078:      	ret
   1d07c:      	ldr	x23, [sp, #0x8]
   1d080:      	sub	x8, x22, x26
   1d084:      	stp	x23, x25, [x19, #0x10]
   1d088:      	mov	w0, #0x1                // =1
   1d08c:      	stp	x26, x8, [x19]
   1d090:      	str	x28, [x19, #0x20]
   1d094:      	b	0x1d058 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14044>
   1d098:      	paciasp
   1d09c:      	sub	sp, sp, #0xa0
   1d0a0:      	stp	x29, x30, [sp, #0x40]
   1d0a4:      	stp	x28, x27, [sp, #0x50]
   1d0a8:      	stp	x26, x25, [sp, #0x60]
   1d0ac:      	stp	x24, x23, [sp, #0x70]
   1d0b0:      	stp	x22, x21, [sp, #0x80]
   1d0b4:      	stp	x20, x19, [sp, #0x90]
   1d0b8:      	add	x29, sp, #0x40
   1d0bc:      	add	x24, x2, w3, uxtw
   1d0c0:      	mov	x23, x2
   1d0c4:      	mov	x20, x1
   1d0c8:      	add	x3, sp, #0x20
   1d0cc:      	mov	x1, x2
   1d0d0:      	mov	x21, x5
   1d0d4:      	mov	x2, x24
   1d0d8:      	mov	x19, x4
   1d0dc:      	mov	x22, x0
   1d0e0:      	bl	0x1cdb0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x13d9c>
   1d0e4:      	tbz	w0, #0x0, 0x1d1d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x141c4>
   1d0e8:      	ldr	x8, [sp, #0x28]
   1d0ec:      	cbz	x8, 0x1d1d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x141c4>
   1d0f0:      	ldrb	w0, [sp, #0x38]
   1d0f4:      	stp	x21, x19, [sp, #0x8]
   1d0f8:      	bl	0x1d200 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x141ec>
   1d0fc:      	ldr	x27, [sp, #0x28]
   1d100:      	mov	x25, x0
   1d104:      	mov	x26, xzr
   1d108:      	cmp	x27, #0x1
   1d10c:      	b.ls	0x1d158 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14144>
   1d110:      	lsr	x21, x27, #1
   1d114:      	ldr	x8, [sp, #0x30]
   1d118:      	ldrb	w3, [sp, #0x38]
   1d11c:      	add	x1, sp, #0x18
   1d120:      	mov	x0, x22
   1d124:      	mov	x2, x24
   1d128:      	add	x19, x21, x26
   1d12c:      	mov	x4, x23
   1d130:      	mul	x28, x19, x25
   1d134:      	add	x8, x8, x28
   1d138:      	str	x8, [sp, #0x18]
   1d13c:      	bl	0x1ba98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a84>
   1d140:      	sub	x8, x27, x21
   1d144:      	cmp	x0, x20
   1d148:      	csel	x26, x26, x19, hs
   1d14c:      	csel	x27, x21, x8, hs
   1d150:      	b.ne	0x1d108 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x140f4>
   1d154:      	b	0x1d15c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14148>
   1d158:      	mul	x28, x26, x25
   1d15c:      	ldr	x8, [sp, #0x30]
   1d160:      	ldrb	w25, [sp, #0x38]
   1d164:      	add	x1, sp, #0x18
   1d168:      	mov	x0, x22
   1d16c:      	mov	x2, x24
   1d170:      	mov	x4, x23
   1d174:      	add	x8, x8, x28
   1d178:      	mov	w3, w25
   1d17c:      	str	x8, [sp, #0x18]
   1d180:      	bl	0x1ba98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a84>
   1d184:      	add	x1, sp, #0x18
   1d188:      	mov	x0, x22
   1d18c:      	mov	x2, x24
   1d190:      	mov	w3, w25
   1d194:      	mov	x4, x23
   1d198:      	bl	0x1ba98 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x12a84>
   1d19c:      	ldp	x3, x19, [sp, #0x8]
   1d1a0:      	mov	x1, x0
   1d1a4:      	mov	x0, x22
   1d1a8:      	mov	w4, wzr
   1d1ac:      	mov	x2, x19
   1d1b0:      	bl	0x19ab0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x10a9c>
   1d1b4:      	cbnz	x0, 0x1d1d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x141c4>
   1d1b8:      	ldr	x8, [x19, #0x18]
   1d1bc:      	cmp	x8, x20
   1d1c0:      	b.hi	0x1d1d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x141c4>
   1d1c4:      	ldr	x8, [x19, #0x20]
   1d1c8:      	cmp	x8, x20
   1d1cc:      	b.ls	0x1d1d8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x141c4>
   1d1d0:      	mov	w0, #0x1                // =1
   1d1d4:      	b	0x1d1dc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x141c8>
   1d1d8:      	mov	w0, wzr
   1d1dc:      	ldp	x20, x19, [sp, #0x90]
   1d1e0:      	ldp	x22, x21, [sp, #0x80]
   1d1e4:      	ldp	x24, x23, [sp, #0x70]
   1d1e8:      	ldp	x26, x25, [sp, #0x60]
   1d1ec:      	ldp	x28, x27, [sp, #0x50]
   1d1f0:      	ldp	x29, x30, [sp, #0x40]
   1d1f4:      	add	sp, sp, #0xa0
   1d1f8:      	autiasp
   1d1fc:      	ret
   1d200:      	paciasp
   1d204:      	stp	x29, x30, [sp, #-0x20]!
   1d208:      	str	x19, [sp, #0x10]
   1d20c:      	mov	x29, sp
   1d210:      	and	w8, w0, #0xf
   1d214:      	mov	w0, #0x4                // =4
   1d218:      	cmp	w8, #0x8
   1d21c:      	b.gt	0x1d23c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14228>
   1d220:      	cmp	w8, #0x2
   1d224:      	b.le	0x1d27c <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14268>
   1d228:      	cmp	w8, #0x3
   1d22c:      	b.eq	0x1d254 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14240>
   1d230:      	cmp	w8, #0x4
   1d234:      	b.eq	0x1d268 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14254>
   1d238:      	b	0x1d288 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14274>
   1d23c:      	cmp	w8, #0xa
   1d240:      	b.le	0x1d2bc <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x142a8>
   1d244:      	cmp	w8, #0xc
   1d248:      	b.eq	0x1d268 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14254>
   1d24c:      	cmp	w8, #0xb
   1d250:      	b.ne	0x1d288 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14274>
   1d254:      	mov	w0, #0x8                // =8
   1d258:      	ldr	x19, [sp, #0x10]
   1d25c:      	ldp	x29, x30, [sp], #0x20
   1d260:      	autiasp
   1d264:      	ret
   1d268:      	mov	w0, #0x10               // =16
   1d26c:      	ldr	x19, [sp, #0x10]
   1d270:      	ldp	x29, x30, [sp], #0x20
   1d274:      	autiasp
   1d278:      	ret
   1d27c:      	b.eq	0x1d258 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14244>
   1d280:      	cmp	w8, #0x1
   1d284:      	b.eq	0x1d2c8 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x142b4>
   1d288:      	adrp	x19, 0x22000
   1d28c:      	nop
   1d290:      	adr	x1, 0x2bb3
   1d294:      	ldr	x19, [x19, #0x108]
   1d298:      	adrp	x2, 0x3000
   1d29c:      	add	x2, x2, #0x4be
   1d2a0:      	adrp	x3, 0x4000
   1d2a4:      	add	x3, x3, #0x577
   1d2a8:      	add	x0, x19, #0x130
   1d2ac:      	bl	0x1d5a0 <fprintf@plt>
   1d2b0:      	add	x0, x19, #0x130
   1d2b4:      	bl	0x1d920 <fflush@plt>
   1d2b8:      	bl	0x1d4d0 <abort@plt>
   1d2bc:      	b.eq	0x1d258 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14244>
   1d2c0:      	cmp	w8, #0x9
   1d2c4:      	b.ne	0x1d288 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x14274>
   1d2c8:      	adrp	x19, 0x22000
   1d2cc:      	nop
   1d2d0:      	adr	x1, 0x2bb3
   1d2d4:      	ldr	x19, [x19, #0x108]
   1d2d8:      	adrp	x2, 0x3000
   1d2dc:      	add	x2, x2, #0x4be
   1d2e0:      	adrp	x3, 0x2000
   1d2e4:      	add	x3, x3, #0xf6d
   1d2e8:      	add	x0, x19, #0x130
   1d2ec:      	bl	0x1d5a0 <fprintf@plt>
   1d2f0:      	add	x0, x19, #0x130
   1d2f4:      	bl	0x1d920 <fflush@plt>
   1d2f8:      	bl	0x1d4d0 <abort@plt>
   1d2fc:      	bti	c
   1d300:      	add	w8, w0, #0x2
   1d304:      	cmp	w8, #0x61
   1d308:      	b.hi	0x1d320 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz+0x1430c>
   1d30c:      	nop
   1d310:      	adr	x9, 0x56a8
   1d314:      	ldrsw	x8, [x9, w8, uxtw #2]
   1d318:      	add	x0, x9, x8
   1d31c:      	ret
   1d320:      	adrp	x0, 0x4000
   1d324:      	add	x0, x0, #0x46d
   1d328:      	ret
   1d32c:      	bti	c
   1d330:      	ldp	x2, x3, [x0, #0x10]
   1d334:      	ldp	x4, x5, [x0, #0x20]
   1d338:      	ldp	x6, x7, [x0, #0x30]
   1d33c:      	ldp	x8, x9, [x0, #0x40]
   1d340:      	ldp	x10, x11, [x0, #0x50]
   1d344:      	ldp	x12, x13, [x0, #0x60]
   1d348:      	ldp	x14, x15, [x0, #0x70]
   1d34c:      	ldp	x18, x19, [x0, #0x90]
   1d350:      	ldp	x20, x21, [x0, #0xa0]
   1d354:      	ldp	x22, x23, [x0, #0xb0]
   1d358:      	ldp	x24, x25, [x0, #0xc0]
   1d35c:      	ldp	x26, x27, [x0, #0xd0]
   1d360:      	ldp	x28, x29, [x0, #0xe0]
   1d364:      	ldr	x30, [x0, #0x100]
   1d368:      	ldp	d0, d1, [x0, #0x110]
   1d36c:      	ldp	d2, d3, [x0, #0x120]
   1d370:      	ldp	d4, d5, [x0, #0x130]
   1d374:      	ldp	d6, d7, [x0, #0x140]
   1d378:      	ldp	d8, d9, [x0, #0x150]
   1d37c:      	ldp	d10, d11, [x0, #0x160]
   1d380:      	ldp	d12, d13, [x0, #0x170]
   1d384:      	ldp	d14, d15, [x0, #0x180]
   1d388:      	ldp	d16, d17, [x0, #0x190]
   1d38c:      	ldp	d18, d19, [x0, #0x1a0]
   1d390:      	ldp	d20, d21, [x0, #0x1b0]
   1d394:      	ldp	d22, d23, [x0, #0x1c0]
   1d398:      	ldp	d24, d25, [x0, #0x1d0]
   1d39c:      	ldp	d26, d27, [x0, #0x1e0]
   1d3a0:      	ldp	d28, d29, [x0, #0x1f0]
   1d3a4:      	ldr	d30, [x0, #0x200]
   1d3a8:      	ldr	d31, [x0, #0x208]
   1d3ac:      	ldr	x16, [x0, #0xf8]
   1d3b0:      	ldp	x0, x1, [x0]
   1d3b4:      	mov	sp, x16
   1d3b8:      	ret
   1d3bc:      	bti	c
   1d3c0:      	stp	x0, x1, [x0]
   1d3c4:      	stp	x2, x3, [x0, #0x10]
   1d3c8:      	stp	x4, x5, [x0, #0x20]
   1d3cc:      	stp	x6, x7, [x0, #0x30]
   1d3d0:      	stp	x8, x9, [x0, #0x40]
   1d3d4:      	stp	x10, x11, [x0, #0x50]
   1d3d8:      	stp	x12, x13, [x0, #0x60]
   1d3dc:      	stp	x14, x15, [x0, #0x70]
   1d3e0:      	stp	x16, x17, [x0, #0x80]
   1d3e4:      	stp	x18, x19, [x0, #0x90]
   1d3e8:      	stp	x20, x21, [x0, #0xa0]
   1d3ec:      	stp	x22, x23, [x0, #0xb0]
   1d3f0:      	stp	x24, x25, [x0, #0xc0]
   1d3f4:      	stp	x26, x27, [x0, #0xd0]
   1d3f8:      	stp	x28, x29, [x0, #0xe0]
   1d3fc:      	str	x30, [x0, #0xf0]
   1d400:      	mov	x1, sp
   1d404:      	str	x1, [x0, #0xf8]
   1d408:      	str	x30, [x0, #0x100]
   1d40c:      	stp	d0, d1, [x0, #0x110]
   1d410:      	stp	d2, d3, [x0, #0x120]
   1d414:      	stp	d4, d5, [x0, #0x130]
   1d418:      	stp	d6, d7, [x0, #0x140]
   1d41c:      	stp	d8, d9, [x0, #0x150]
   1d420:      	stp	d10, d11, [x0, #0x160]
   1d424:      	stp	d12, d13, [x0, #0x170]
   1d428:      	stp	d14, d15, [x0, #0x180]
   1d42c:      	stp	d16, d17, [x0, #0x190]
   1d430:      	stp	d18, d19, [x0, #0x1a0]
   1d434:      	stp	d20, d21, [x0, #0x1b0]
   1d438:      	stp	d22, d23, [x0, #0x1c0]
   1d43c:      	stp	d24, d25, [x0, #0x1d0]
   1d440:      	stp	d26, d27, [x0, #0x1e0]
   1d444:      	stp	d28, d29, [x0, #0x1f0]
   1d448:      	str	d30, [x0, #0x200]
   1d44c:      	str	d31, [x0, #0x208]
   1d450:      	mov	x0, #0x0                // =0
   1d454:      	ret

Disassembly of section .plt:

000000000001d460 <.plt>:
   1d460:      	stp	x16, x30, [sp, #-0x10]!
   1d464:      	adrp	x16, 0x22000
   1d468:      	ldr	x17, [x16, #0x128]
   1d46c:      	add	x16, x16, #0x128
   1d470:      	br	x17
   1d474:      	nop
   1d478:      	nop
   1d47c:      	nop

000000000001d480 <__cxa_finalize@plt>:
   1d480:      	adrp	x16, 0x22000
   1d484:      	ldr	x17, [x16, #0x130]
   1d488:      	add	x16, x16, #0x130
   1d48c:      	br	x17

000000000001d490 <__cxa_atexit@plt>:
   1d490:      	adrp	x16, 0x22000
   1d494:      	ldr	x17, [x16, #0x138]
   1d498:      	add	x16, x16, #0x138
   1d49c:      	br	x17

000000000001d4a0 <__stack_chk_fail@plt>:
   1d4a0:      	adrp	x16, 0x22000
   1d4a4:      	ldr	x17, [x16, #0x140]
   1d4a8:      	add	x16, x16, #0x140
   1d4ac:      	br	x17

000000000001d4b0 <_ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz@plt>:
   1d4b0:      	adrp	x16, 0x22000
   1d4b4:      	ldr	x17, [x16, #0x148]
   1d4b8:      	add	x16, x16, #0x148
   1d4bc:      	br	x17

000000000001d4c0 <__android_log_print@plt>:
   1d4c0:      	adrp	x16, 0x22000
   1d4c4:      	ldr	x17, [x16, #0x150]
   1d4c8:      	add	x16, x16, #0x150
   1d4cc:      	br	x17

000000000001d4d0 <abort@plt>:
   1d4d0:      	adrp	x16, 0x22000
   1d4d4:      	ldr	x17, [x16, #0x158]
   1d4d8:      	add	x16, x16, #0x158
   1d4dc:      	br	x17

000000000001d4e0 <syscall@plt>:
   1d4e0:      	adrp	x16, 0x22000
   1d4e4:      	ldr	x17, [x16, #0x160]
   1d4e8:      	add	x16, x16, #0x160
   1d4ec:      	br	x17

000000000001d4f0 <strstr@plt>:
   1d4f0:      	adrp	x16, 0x22000
   1d4f4:      	ldr	x17, [x16, #0x168]
   1d4f8:      	add	x16, x16, #0x168
   1d4fc:      	br	x17

000000000001d500 <__strlen_chk@plt>:
   1d500:      	adrp	x16, 0x22000
   1d504:      	ldr	x17, [x16, #0x170]
   1d508:      	add	x16, x16, #0x170
   1d50c:      	br	x17

000000000001d510 <strlen@plt>:
   1d510:      	adrp	x16, 0x22000
   1d514:      	ldr	x17, [x16, #0x178]
   1d518:      	add	x16, x16, #0x178
   1d51c:      	br	x17

000000000001d520 <__vsnprintf_chk@plt>:
   1d520:      	adrp	x16, 0x22000
   1d524:      	ldr	x17, [x16, #0x180]
   1d528:      	add	x16, x16, #0x180
   1d52c:      	br	x17

000000000001d530 <_Znwm@plt>:
   1d530:      	adrp	x16, 0x22000
   1d534:      	ldr	x17, [x16, #0x188]
   1d538:      	add	x16, x16, #0x188
   1d53c:      	br	x17

000000000001d540 <memcpy@plt>:
   1d540:      	adrp	x16, 0x22000
   1d544:      	ldr	x17, [x16, #0x190]
   1d548:      	add	x16, x16, #0x190
   1d54c:      	br	x17

000000000001d550 <_ZdlPv@plt>:
   1d550:      	adrp	x16, 0x22000
   1d554:      	ldr	x17, [x16, #0x198]
   1d558:      	add	x16, x16, #0x198
   1d55c:      	br	x17

000000000001d560 <printf@plt>:
   1d560:      	adrp	x16, 0x22000
   1d564:      	ldr	x17, [x16, #0x1a0]
   1d568:      	add	x16, x16, #0x1a0
   1d56c:      	br	x17

000000000001d570 <regcomp@plt>:
   1d570:      	adrp	x16, 0x22000
   1d574:      	ldr	x17, [x16, #0x1a8]
   1d578:      	add	x16, x16, #0x1a8
   1d57c:      	br	x17

000000000001d580 <regerror@plt>:
   1d580:      	adrp	x16, 0x22000
   1d584:      	ldr	x17, [x16, #0x1b0]
   1d588:      	add	x16, x16, #0x1b0
   1d58c:      	br	x17

000000000001d590 <regexec@plt>:
   1d590:      	adrp	x16, 0x22000
   1d594:      	ldr	x17, [x16, #0x1b8]
   1d598:      	add	x16, x16, #0x1b8
   1d59c:      	br	x17

000000000001d5a0 <fprintf@plt>:
   1d5a0:      	adrp	x16, 0x22000
   1d5a4:      	ldr	x17, [x16, #0x1c0]
   1d5a8:      	add	x16, x16, #0x1c0
   1d5ac:      	br	x17

000000000001d5b0 <memset@plt>:
   1d5b0:      	adrp	x16, 0x22000
   1d5b4:      	ldr	x17, [x16, #0x1c8]
   1d5b8:      	add	x16, x16, #0x1c8
   1d5bc:      	br	x17

000000000001d5c0 <fwrite@plt>:
   1d5c0:      	adrp	x16, 0x22000
   1d5c4:      	ldr	x17, [x16, #0x1d0]
   1d5c8:      	add	x16, x16, #0x1d0
   1d5cc:      	br	x17

000000000001d5d0 <strncpy@plt>:
   1d5d0:      	adrp	x16, 0x22000
   1d5d4:      	ldr	x17, [x16, #0x1d8]
   1d5d8:      	add	x16, x16, #0x1d8
   1d5dc:      	br	x17

000000000001d5e0 <__strncpy_chk2@plt>:
   1d5e0:      	adrp	x16, 0x22000
   1d5e4:      	ldr	x17, [x16, #0x1e0]
   1d5e8:      	add	x16, x16, #0x1e0
   1d5ec:      	br	x17

000000000001d5f0 <_ZNSt6__ndk15mutex4lockEv@plt>:
   1d5f0:      	adrp	x16, 0x22000
   1d5f4:      	ldr	x17, [x16, #0x1e8]
   1d5f8:      	add	x16, x16, #0x1e8
   1d5fc:      	br	x17

000000000001d600 <dlopen@plt>:
   1d600:      	adrp	x16, 0x22000
   1d604:      	ldr	x17, [x16, #0x1f0]
   1d608:      	add	x16, x16, #0x1f0
   1d60c:      	br	x17

000000000001d610 <eglGetError@plt>:
   1d610:      	adrp	x16, 0x22000
   1d614:      	ldr	x17, [x16, #0x1f8]
   1d618:      	add	x16, x16, #0x1f8
   1d61c:      	br	x17

000000000001d620 <eglGetDisplay@plt>:
   1d620:      	adrp	x16, 0x22000
   1d624:      	ldr	x17, [x16, #0x200]
   1d628:      	add	x16, x16, #0x200
   1d62c:      	br	x17

000000000001d630 <eglInitialize@plt>:
   1d630:      	adrp	x16, 0x22000
   1d634:      	ldr	x17, [x16, #0x208]
   1d638:      	add	x16, x16, #0x208
   1d63c:      	br	x17

000000000001d640 <eglChooseConfig@plt>:
   1d640:      	adrp	x16, 0x22000
   1d644:      	ldr	x17, [x16, #0x210]
   1d648:      	add	x16, x16, #0x210
   1d64c:      	br	x17

000000000001d650 <eglCreatePbufferSurface@plt>:
   1d650:      	adrp	x16, 0x22000
   1d654:      	ldr	x17, [x16, #0x218]
   1d658:      	add	x16, x16, #0x218
   1d65c:      	br	x17

000000000001d660 <eglCreateContext@plt>:
   1d660:      	adrp	x16, 0x22000
   1d664:      	ldr	x17, [x16, #0x220]
   1d668:      	add	x16, x16, #0x220
   1d66c:      	br	x17

000000000001d670 <eglMakeCurrent@plt>:
   1d670:      	adrp	x16, 0x22000
   1d674:      	ldr	x17, [x16, #0x228]
   1d678:      	add	x16, x16, #0x228
   1d67c:      	br	x17

000000000001d680 <glGetString@plt>:
   1d680:      	adrp	x16, 0x22000
   1d684:      	ldr	x17, [x16, #0x230]
   1d688:      	add	x16, x16, #0x230
   1d68c:      	br	x17

000000000001d690 <eglDestroySurface@plt>:
   1d690:      	adrp	x16, 0x22000
   1d694:      	ldr	x17, [x16, #0x238]
   1d698:      	add	x16, x16, #0x238
   1d69c:      	br	x17

000000000001d6a0 <eglDestroyContext@plt>:
   1d6a0:      	adrp	x16, 0x22000
   1d6a4:      	ldr	x17, [x16, #0x240]
   1d6a8:      	add	x16, x16, #0x240
   1d6ac:      	br	x17

000000000001d6b0 <dlclose@plt>:
   1d6b0:      	adrp	x16, 0x22000
   1d6b4:      	ldr	x17, [x16, #0x248]
   1d6b8:      	add	x16, x16, #0x248
   1d6bc:      	br	x17

000000000001d6c0 <_ZNSt6__ndk15mutex6unlockEv@plt>:
   1d6c0:      	adrp	x16, 0x22000
   1d6c4:      	ldr	x17, [x16, #0x250]
   1d6c8:      	add	x16, x16, #0x250
   1d6cc:      	br	x17

000000000001d6d0 <eglGetCurrentContext@plt>:
   1d6d0:      	adrp	x16, 0x22000
   1d6d4:      	ldr	x17, [x16, #0x258]
   1d6d8:      	add	x16, x16, #0x258
   1d6dc:      	br	x17

000000000001d6e0 <glGetError@plt>:
   1d6e0:      	adrp	x16, 0x22000
   1d6e4:      	ldr	x17, [x16, #0x260]
   1d6e8:      	add	x16, x16, #0x260
   1d6ec:      	br	x17

000000000001d6f0 <dlsym@plt>:
   1d6f0:      	adrp	x16, 0x22000
   1d6f4:      	ldr	x17, [x16, #0x268]
   1d6f8:      	add	x16, x16, #0x268
   1d6fc:      	br	x17

000000000001d700 <_Znam@plt>:
   1d700:      	adrp	x16, 0x22000
   1d704:      	ldr	x17, [x16, #0x270]
   1d708:      	add	x16, x16, #0x270
   1d70c:      	br	x17

000000000001d710 <_ZdaPv@plt>:
   1d710:      	adrp	x16, 0x22000
   1d714:      	ldr	x17, [x16, #0x278]
   1d718:      	add	x16, x16, #0x278
   1d71c:      	br	x17

000000000001d720 <memchr@plt>:
   1d720:      	adrp	x16, 0x22000
   1d724:      	ldr	x17, [x16, #0x280]
   1d728:      	add	x16, x16, #0x280
   1d72c:      	br	x17

000000000001d730 <_ZNKSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE4findEcm@plt>:
   1d730:      	adrp	x16, 0x22000
   1d734:      	ldr	x17, [x16, #0x288]
   1d738:      	add	x16, x16, #0x288
   1d73c:      	br	x17

000000000001d740 <memmove@plt>:
   1d740:      	adrp	x16, 0x22000
   1d744:      	ldr	x17, [x16, #0x290]
   1d748:      	add	x16, x16, #0x290
   1d74c:      	br	x17

000000000001d750 <__vsprintf_chk@plt>:
   1d750:      	adrp	x16, 0x22000
   1d754:      	ldr	x17, [x16, #0x298]
   1d758:      	add	x16, x16, #0x298
   1d75c:      	br	x17

000000000001d760 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6resizeEmc@plt>:
   1d760:      	adrp	x16, 0x22000
   1d764:      	ldr	x17, [x16, #0x2a0]
   1d768:      	add	x16, x16, #0x2a0
   1d76c:      	br	x17

000000000001d770 <_ZNSt6__ndk122__libcpp_verbose_abortEPKcz@plt>:
   1d770:      	adrp	x16, 0x22000
   1d774:      	ldr	x17, [x16, #0x2a8]
   1d778:      	add	x16, x16, #0x2a8
   1d77c:      	br	x17

000000000001d780 <pthread_once@plt>:
   1d780:      	adrp	x16, 0x22000
   1d784:      	ldr	x17, [x16, #0x2b0]
   1d788:      	add	x16, x16, #0x2b0
   1d78c:      	br	x17

000000000001d790 <strchr@plt>:
   1d790:      	adrp	x16, 0x22000
   1d794:      	ldr	x17, [x16, #0x2b8]
   1d798:      	add	x16, x16, #0x2b8
   1d79c:      	br	x17

000000000001d7a0 <atoi@plt>:
   1d7a0:      	adrp	x16, 0x22000
   1d7a4:      	ldr	x17, [x16, #0x2c0]
   1d7a8:      	add	x16, x16, #0x2c0
   1d7ac:      	br	x17

000000000001d7b0 <__strchr_chk@plt>:
   1d7b0:      	adrp	x16, 0x22000
   1d7b4:      	ldr	x17, [x16, #0x2c8]
   1d7b8:      	add	x16, x16, #0x2c8
   1d7bc:      	br	x17

000000000001d7c0 <__open_2@plt>:
   1d7c0:      	adrp	x16, 0x22000
   1d7c4:      	ldr	x17, [x16, #0x2d0]
   1d7c8:      	add	x16, x16, #0x2d0
   1d7cc:      	br	x17

000000000001d7d0 <__read_chk@plt>:
   1d7d0:      	adrp	x16, 0x22000
   1d7d4:      	ldr	x17, [x16, #0x2d8]
   1d7d8:      	add	x16, x16, #0x2d8
   1d7dc:      	br	x17

000000000001d7e0 <close@plt>:
   1d7e0:      	adrp	x16, 0x22000
   1d7e4:      	ldr	x17, [x16, #0x2e0]
   1d7e8:      	add	x16, x16, #0x2e0
   1d7ec:      	br	x17

000000000001d7f0 <__system_property_get@plt>:
   1d7f0:      	adrp	x16, 0x22000
   1d7f4:      	ldr	x17, [x16, #0x2e8]
   1d7f8:      	add	x16, x16, #0x2e8
   1d7fc:      	br	x17

000000000001d800 <getauxval@plt>:
   1d800:      	adrp	x16, 0x22000
   1d804:      	ldr	x17, [x16, #0x2f0]
   1d808:      	add	x16, x16, #0x2f0
   1d80c:      	br	x17

000000000001d810 <strnlen@plt>:
   1d810:      	adrp	x16, 0x22000
   1d814:      	ldr	x17, [x16, #0x2f8]
   1d818:      	add	x16, x16, #0x2f8
   1d81c:      	br	x17

000000000001d820 <fopen@plt>:
   1d820:      	adrp	x16, 0x22000
   1d824:      	ldr	x17, [x16, #0x300]
   1d828:      	add	x16, x16, #0x300
   1d82c:      	br	x17

000000000001d830 <feof@plt>:
   1d830:      	adrp	x16, 0x22000
   1d834:      	ldr	x17, [x16, #0x308]
   1d838:      	add	x16, x16, #0x308
   1d83c:      	br	x17

000000000001d840 <fgets@plt>:
   1d840:      	adrp	x16, 0x22000
   1d844:      	ldr	x17, [x16, #0x310]
   1d848:      	add	x16, x16, #0x310
   1d84c:      	br	x17

000000000001d850 <fclose@plt>:
   1d850:      	adrp	x16, 0x22000
   1d854:      	ldr	x17, [x16, #0x318]
   1d858:      	add	x16, x16, #0x318
   1d85c:      	br	x17

000000000001d860 <calloc@plt>:
   1d860:      	adrp	x16, 0x22000
   1d864:      	ldr	x17, [x16, #0x320]
   1d868:      	add	x16, x16, #0x320
   1d86c:      	br	x17

000000000001d870 <malloc@plt>:
   1d870:      	adrp	x16, 0x22000
   1d874:      	ldr	x17, [x16, #0x328]
   1d878:      	add	x16, x16, #0x328
   1d87c:      	br	x17

000000000001d880 <free@plt>:
   1d880:      	adrp	x16, 0x22000
   1d884:      	ldr	x17, [x16, #0x330]
   1d888:      	add	x16, x16, #0x330
   1d88c:      	br	x17

000000000001d890 <__android_log_vprint@plt>:
   1d890:      	adrp	x16, 0x22000
   1d894:      	ldr	x17, [x16, #0x338]
   1d898:      	add	x16, x16, #0x338
   1d89c:      	br	x17

000000000001d8a0 <qsort@plt>:
   1d8a0:      	adrp	x16, 0x22000
   1d8a4:      	ldr	x17, [x16, #0x340]
   1d8a8:      	add	x16, x16, #0x340
   1d8ac:      	br	x17

000000000001d8b0 <strcmp@plt>:
   1d8b0:      	adrp	x16, 0x22000
   1d8b4:      	ldr	x17, [x16, #0x348]
   1d8b8:      	add	x16, x16, #0x348
   1d8bc:      	br	x17

000000000001d8c0 <strncmp@plt>:
   1d8c0:      	adrp	x16, 0x22000
   1d8c4:      	ldr	x17, [x16, #0x350]
   1d8c8:      	add	x16, x16, #0x350
   1d8cc:      	br	x17

000000000001d8d0 <memcmp@plt>:
   1d8d0:      	adrp	x16, 0x22000
   1d8d4:      	ldr	x17, [x16, #0x358]
   1d8d8:      	add	x16, x16, #0x358
   1d8dc:      	br	x17

000000000001d8e0 <__errno@plt>:
   1d8e0:      	adrp	x16, 0x22000
   1d8e4:      	ldr	x17, [x16, #0x360]
   1d8e8:      	add	x16, x16, #0x360
   1d8ec:      	br	x17

000000000001d8f0 <strerror@plt>:
   1d8f0:      	adrp	x16, 0x22000
   1d8f4:      	ldr	x17, [x16, #0x368]
   1d8f8:      	add	x16, x16, #0x368
   1d8fc:      	br	x17

000000000001d900 <strtoul@plt>:
   1d900:      	adrp	x16, 0x22000
   1d904:      	ldr	x17, [x16, #0x370]
   1d908:      	add	x16, x16, #0x370
   1d90c:      	br	x17

000000000001d910 <__memmove_chk@plt>:
   1d910:      	adrp	x16, 0x22000
   1d914:      	ldr	x17, [x16, #0x378]
   1d918:      	add	x16, x16, #0x378
   1d91c:      	br	x17

000000000001d920 <fflush@plt>:
   1d920:      	adrp	x16, 0x22000
   1d924:      	ldr	x17, [x16, #0x380]
   1d928:      	add	x16, x16, #0x380
   1d92c:      	br	x17

000000000001d930 <pthread_rwlock_wrlock@plt>:
   1d930:      	adrp	x16, 0x22000
   1d934:      	ldr	x17, [x16, #0x388]
   1d938:      	add	x16, x16, #0x388
   1d93c:      	br	x17

000000000001d940 <pthread_rwlock_unlock@plt>:
   1d940:      	adrp	x16, 0x22000
   1d944:      	ldr	x17, [x16, #0x390]
   1d948:      	add	x16, x16, #0x390
   1d94c:      	br	x17

000000000001d950 <dl_iterate_phdr@plt>:
   1d950:      	adrp	x16, 0x22000
   1d954:      	ldr	x17, [x16, #0x398]
   1d958:      	add	x16, x16, #0x398
   1d95c:      	br	x17

000000000001d960 <pthread_rwlock_rdlock@plt>:
   1d960:      	adrp	x16, 0x22000
   1d964:      	ldr	x17, [x16, #0x3a0]
   1d968:      	add	x16, x16, #0x3a0
   1d96c:      	br	x17

000000000001d970 <getpid@plt>:
   1d970:      	adrp	x16, 0x22000
   1d974:      	ldr	x17, [x16, #0x3a8]
   1d978:      	add	x16, x16, #0x3a8
   1d97c:      	br	x17
