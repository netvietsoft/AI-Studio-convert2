
F:\CONVERT\com.mt.mtxx.mtxx\SOURCE\extracted_native_libs\lib\arm64-v8a\libMtlabSign.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000001c44 <.text>:
    1c44:      	bti	c
    1c48:      	nop
    1c4c:      	adr	x0, 0x8af0
    1c50:      	b	0x4850 <__cxa_finalize@plt>
    1c54:      	bti	c
    1c58:      	ret
    1c5c:      	bti	c
    1c60:      	b	0x1c54 <.text+0x10>
    1c64:      	bti	c
    1c68:      	cbz	x0, 0x1c74 <.text+0x30>
    1c6c:      	mov	x16, x0
    1c70:      	br	x16
    1c74:      	ret
    1c78:      	bti	c
    1c7c:      	mov	x1, x0
    1c80:      	nop
    1c84:      	adr	x0, 0x1c64 <.text+0x20>
    1c88:      	nop
    1c8c:      	adr	x2, 0x8af0
    1c90:      	b	0x4860 <__cxa_atexit@plt>

0000000000001c94 <_Z11jstring2strP7_JNIEnvP8_jstring>:
    1c94:      	stp	x29, x30, [sp, #-0x40]!
    1c98:      	stp	x24, x23, [sp, #0x10]
    1c9c:      	stp	x22, x21, [sp, #0x20]
    1ca0:      	stp	x20, x19, [sp, #0x30]
    1ca4:      	mov	x29, sp
    1ca8:      	ldr	x9, [x0]
    1cac:      	mov	x21, x1
    1cb0:      	nop
    1cb4:      	adr	x1, 0x15d0
    1cb8:      	mov	x20, x0
    1cbc:      	mov	x19, x8
    1cc0:      	ldr	x9, [x9, #0x30]
    1cc4:      	blr	x9
    1cc8:      	ldr	x8, [x20]
    1ccc:      	mov	x22, x0
    1cd0:      	adrp	x1, 0x1000
    1cd4:      	add	x1, x1, #0x653
    1cd8:      	mov	x0, x20
    1cdc:      	ldr	x8, [x8, #0x538]
    1ce0:      	blr	x8
    1ce4:      	ldr	x8, [x20]
    1ce8:      	mov	x23, x0
    1cec:      	adrp	x2, 0x1000
    1cf0:      	add	x2, x2, #0x560
    1cf4:      	adrp	x3, 0x1000
    1cf8:      	add	x3, x3, #0x572
    1cfc:      	ldr	x8, [x8, #0x108]
    1d00:      	mov	x0, x20
    1d04:      	mov	x1, x22
    1d08:      	blr	x8
    1d0c:      	mov	x2, x0
    1d10:      	mov	x0, x20
    1d14:      	mov	x1, x21
    1d18:      	mov	x3, x23
    1d1c:      	bl	0x4880 <_ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz@plt>
    1d20:      	ldr	x8, [x20]
    1d24:      	mov	x22, x0
    1d28:      	mov	x0, x20
    1d2c:      	mov	x1, x22
    1d30:      	ldr	x8, [x8, #0x558]
    1d34:      	blr	x8
    1d38:      	cmp	w0, #0x1
    1d3c:      	b.lt	0x1dc8 <_Z11jstring2strP7_JNIEnvP8_jstring+0x134>
    1d40:      	ldr	x8, [x20]
    1d44:      	mov	w23, w0
    1d48:      	mov	x0, x20
    1d4c:      	mov	x1, x22
    1d50:      	mov	x2, xzr
    1d54:      	ldr	x8, [x8, #0x5c0]
    1d58:      	blr	x8
    1d5c:      	mov	x24, x0
    1d60:      	add	w0, w23, #0x1
    1d64:      	bl	0x4890 <malloc@plt>
    1d68:      	mov	w23, w23
    1d6c:      	mov	x1, x24
    1d70:      	mov	x21, x0
    1d74:      	mov	x2, x23
    1d78:      	bl	0x48a0 <memcpy@plt>
    1d7c:      	ldr	x8, [x20]
    1d80:      	mov	x0, x20
    1d84:      	mov	x1, x22
    1d88:      	mov	x2, x24
    1d8c:      	mov	w3, wzr
    1d90:      	strb	wzr, [x21, x23]
    1d94:      	ldr	x8, [x8, #0x600]
    1d98:      	blr	x8
    1d9c:      	mov	x0, x21
    1da0:      	bl	0x48b0 <strlen@plt>
    1da4:      	cmn	x0, #0x10
    1da8:      	b.hs	0x1e28 <_Z11jstring2strP7_JNIEnvP8_jstring+0x194>
    1dac:      	mov	x20, x0
    1db0:      	cmp	x0, #0x17
    1db4:      	b.hs	0x1de0 <_Z11jstring2strP7_JNIEnvP8_jstring+0x14c>
    1db8:      	lsl	w8, w20, #1
    1dbc:      	strb	w8, [x19], #0x1
    1dc0:      	cbnz	x20, 0x1dfc <_Z11jstring2strP7_JNIEnvP8_jstring+0x168>
    1dc4:      	b	0x1e0c <_Z11jstring2strP7_JNIEnvP8_jstring+0x178>
    1dc8:      	strh	wzr, [x19]
    1dcc:      	ldp	x20, x19, [sp, #0x30]
    1dd0:      	ldp	x22, x21, [sp, #0x20]
    1dd4:      	ldp	x24, x23, [sp, #0x10]
    1dd8:      	ldp	x29, x30, [sp], #0x40
    1ddc:      	ret
    1de0:      	orr	x22, x20, #0xf
    1de4:      	add	x0, x22, #0x1
    1de8:      	bl	0x48c0 <_Znwm@plt>
    1dec:      	add	x8, x22, #0x2
    1df0:      	stp	x20, x0, [x19, #0x8]
    1df4:      	str	x8, [x19]
    1df8:      	mov	x19, x0
    1dfc:      	mov	x0, x19
    1e00:      	mov	x1, x21
    1e04:      	mov	x2, x20
    1e08:      	bl	0x48a0 <memcpy@plt>
    1e0c:      	mov	x0, x21
    1e10:      	strb	wzr, [x19, x20]
    1e14:      	ldp	x20, x19, [sp, #0x30]
    1e18:      	ldp	x22, x21, [sp, #0x20]
    1e1c:      	ldp	x24, x23, [sp, #0x10]
    1e20:      	ldp	x29, x30, [sp], #0x40
    1e24:      	b	0x48d0 <free@plt>
    1e28:      	mov	x0, x19
    1e2c:      	bl	0x24ec <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x318>

0000000000001e30 <_ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz>:
    1e30:      	sub	sp, sp, #0x120
    1e34:      	stp	x29, x30, [sp, #0x100]
    1e38:      	stp	x28, x19, [sp, #0x110]
    1e3c:      	add	x29, sp, #0x100
    1e40:      	stp	x3, x4, [x29, #-0x78]
    1e44:      	sub	x9, x29, #0x78
    1e48:      	mov	x10, sp
    1e4c:      	stp	x5, x6, [x29, #-0x68]
    1e50:      	add	x10, x10, #0x80
    1e54:      	sub	x3, x29, #0x50
    1e58:      	stur	x7, [x29, #-0x58]
    1e5c:      	stp	q0, q1, [sp]
    1e60:      	stp	q2, q3, [sp, #0x20]
    1e64:      	stp	q4, q5, [sp, #0x40]
    1e68:      	stp	q6, q7, [sp, #0x60]
    1e6c:      	mrs	x19, TPIDR_EL0
    1e70:      	ldr	x8, [x19, #0x28]
    1e74:      	stur	x8, [x29, #-0x8]
    1e78:      	add	x8, x9, #0x28
    1e7c:      	add	x9, x29, #0x20
    1e80:      	stp	x9, x8, [x29, #-0x28]
    1e84:      	mov	x8, #-0x28              // =-40
    1e88:      	sub	x9, x29, #0x28
    1e8c:      	movk	x8, #0xff80, lsl #32
    1e90:      	stp	x10, x8, [x29, #-0x18]
    1e94:      	ldr	x8, [x0]
    1e98:      	ldp	q0, q1, [x9]
    1e9c:      	ldr	x8, [x8, #0x118]
    1ea0:      	stp	q0, q1, [x29, #-0x50]
    1ea4:      	blr	x8
    1ea8:      	ldr	x8, [x19, #0x28]
    1eac:      	ldur	x9, [x29, #-0x8]
    1eb0:      	cmp	x8, x9
    1eb4:      	b.ne	0x1ec8 <_ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz+0x98>
    1eb8:      	ldp	x28, x19, [sp, #0x110]
    1ebc:      	ldp	x29, x30, [sp, #0x100]
    1ec0:      	add	sp, sp, #0x120
    1ec4:      	ret
    1ec8:      	bl	0x48e0 <__stack_chk_fail@plt>

0000000000001ecc <_Z10getSignKeyP7_JNIEnvP8_jstringS2_S2_>:
    1ecc:      	sub	sp, sp, #0x1c0
    1ed0:      	stp	x29, x30, [sp, #0x160]
    1ed4:      	stp	x28, x27, [sp, #0x170]
    1ed8:      	stp	x26, x25, [sp, #0x180]
    1edc:      	stp	x24, x23, [sp, #0x190]
    1ee0:      	stp	x22, x21, [sp, #0x1a0]
    1ee4:      	stp	x20, x19, [sp, #0x1b0]
    1ee8:      	add	x29, sp, #0x160
    1eec:      	mrs	x24, TPIDR_EL0
    1ef0:      	mov	x19, x8
    1ef4:      	mov	x20, x2
    1ef8:      	ldr	x8, [x24, #0x28]
    1efc:      	mov	x22, x1
    1f00:      	mov	x21, x0
    1f04:      	add	x25, sp, #0x38
    1f08:      	stur	x8, [x29, #-0x10]
    1f0c:      	strh	wzr, [x19]
    1f10:      	cbz	x3, 0x1f7c <_Z10getSignKeyP7_JNIEnvP8_jstringS2_S2_+0xb0>
    1f14:      	adrp	x1, 0x1000
    1f18:      	add	x1, x1, #0x5cd
    1f1c:      	mov	x0, x19
    1f20:      	mov	x23, x3
    1f24:      	bl	0x4900 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>
    1f28:      	add	x8, sp, #0x38
    1f2c:      	mov	x0, x21
    1f30:      	mov	x1, x23
    1f34:      	bl	0x4870 <_Z11jstring2strP7_JNIEnvP8_jstring@plt>
    1f38:      	ldrb	w8, [sp, #0x38]
    1f3c:      	ldp	x10, x9, [sp, #0x40]
    1f40:      	orr	x12, x25, #0x1
    1f44:      	mov	x0, x19
    1f48:      	lsr	x11, x8, #1
    1f4c:      	tst	w8, #0x1
    1f50:      	csel	x1, x12, x9, eq
    1f54:      	csel	x2, x11, x10, eq
    1f58:      	bl	0x4910 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm@plt>
    1f5c:      	ldrb	w8, [sp, #0x38]
    1f60:      	tbz	w8, #0x0, 0x1f6c <_Z10getSignKeyP7_JNIEnvP8_jstringS2_S2_+0xa0>
    1f64:      	ldr	x0, [sp, #0x48]
    1f68:      	bl	0x4920 <_ZdlPv@plt>
    1f6c:      	adrp	x1, 0x1000
    1f70:      	add	x1, x1, #0x589
    1f74:      	mov	x0, x19
    1f78:      	bl	0x4900 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>
    1f7c:      	adrp	x1, 0x1000
    1f80:      	add	x1, x1, #0x62e
    1f84:      	mov	x0, x19
    1f88:      	bl	0x4900 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>
    1f8c:      	add	x8, sp, #0x20
    1f90:      	mov	x0, x21
    1f94:      	mov	x1, x22
    1f98:      	add	x22, sp, #0x20
    1f9c:      	bl	0x4870 <_Z11jstring2strP7_JNIEnvP8_jstring@plt>
    1fa0:      	ldrb	w8, [sp, #0x20]
    1fa4:      	ldp	x10, x9, [sp, #0x28]
    1fa8:      	orr	x12, x22, #0x1
    1fac:      	mov	x0, x19
    1fb0:      	lsr	x11, x8, #1
    1fb4:      	tst	w8, #0x1
    1fb8:      	csel	x1, x12, x9, eq
    1fbc:      	csel	x2, x11, x10, eq
    1fc0:      	bl	0x4910 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm@plt>
    1fc4:      	adrp	x1, 0x1000
    1fc8:      	add	x1, x1, #0x64f
    1fcc:      	mov	x0, x19
    1fd0:      	bl	0x4900 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>
    1fd4:      	add	x8, sp, #0x38
    1fd8:      	mov	x0, x21
    1fdc:      	mov	x1, x20
    1fe0:      	bl	0x4870 <_Z11jstring2strP7_JNIEnvP8_jstring@plt>
    1fe4:      	ldrb	w8, [sp, #0x38]
    1fe8:      	ldp	x10, x9, [sp, #0x40]
    1fec:      	orr	x12, x25, #0x1
    1ff0:      	mov	x0, x19
    1ff4:      	lsr	x11, x8, #1
    1ff8:      	tst	w8, #0x1
    1ffc:      	csel	x1, x12, x9, eq
    2000:      	csel	x2, x11, x10, eq
    2004:      	bl	0x4910 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm@plt>
    2008:      	ldrb	w8, [sp, #0x38]
    200c:      	tbz	w8, #0x0, 0x2018 <_Z10getSignKeyP7_JNIEnvP8_jstringS2_S2_+0x14c>
    2010:      	ldr	x0, [sp, #0x48]
    2014:      	bl	0x4920 <_ZdlPv@plt>
    2018:      	adrp	x1, 0x1000
    201c:      	add	x1, x1, #0x56c
    2020:      	mov	x0, x19
    2024:      	bl	0x4900 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>
    2028:      	adrp	x26, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    202c:      	adrp	x22, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    2030:      	add	x23, sp, #0x38
    2034:      	ldr	x26, [x26, #0xcc8]
    2038:      	ldr	x22, [x22, #0xcd0]
    203c:      	add	x1, x23, #0x18
    2040:      	add	x20, x23, #0x10
    2044:      	ldp	x8, x9, [x22, #0x10]
    2048:      	add	x27, x26, #0x68
    204c:      	add	x28, x26, #0x40
    2050:      	str	x27, [sp, #0xb8]
    2054:      	str	x28, [sp, #0x48]
    2058:      	str	x8, [sp, #0x38]
    205c:      	ldur	x8, [x8, #-0x18]
    2060:      	str	x9, [x23, x8]
    2064:      	ldr	x8, [sp, #0x38]
    2068:      	str	xzr, [sp, #0x40]
    206c:      	ldur	x8, [x8, #-0x18]
    2070:      	add	x21, x23, x8
    2074:      	mov	x0, x21
    2078:      	bl	0x4930 <_ZNSt6__ndk18ios_base4initEPv@plt>
    207c:      	mov	w8, #-0x1               // =-1
    2080:      	str	xzr, [x21, #0x88]
    2084:      	ldr	x10, [x22, #0x8]
    2088:      	str	w8, [x21, #0x90]
    208c:      	ldp	x9, x8, [x22, #0x20]
    2090:      	add	x0, x23, #0x18
    2094:      	str	x9, [sp, #0x48]
    2098:      	ldur	x9, [x9, #-0x18]
    209c:      	str	x8, [x20, x9]
    20a0:      	ldr	x9, [x22, #0x30]
    20a4:      	str	x10, [sp, #0x38]
    20a8:      	ldur	x8, [x10, #-0x18]
    20ac:      	str	x9, [x23, x8]
    20b0:      	add	x8, x26, #0x18
    20b4:      	str	x27, [sp, #0xb8]
    20b8:      	str	x8, [sp, #0x38]
    20bc:      	str	x28, [sp, #0x48]
    20c0:      	bl	0x4940 <_ZNSt6__ndk115basic_streambufIcNS_11char_traitsIcEEEC2Ev@plt>
    20c4:      	adrp	x8, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    20c8:      	movi	v0.2d, #0000000000000000
    20cc:      	ldr	x8, [x8, #0xcd8]
    20d0:      	add	x21, x8, #0x10
    20d4:      	mov	w8, #0x18               // =24
    20d8:      	str	x21, [sp, #0x50]
    20dc:      	stur	q0, [x25, #0x58]
    20e0:      	stur	q0, [x25, #0x68]
    20e4:      	str	w8, [sp, #0xb0]
    20e8:      	bl	0x4950 <rand@plt>
    20ec:      	mov	w1, w0
    20f0:      	mov	x0, x20
    20f4:      	bl	0x4960 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEElsEi@plt>
    20f8:      	add	x8, sp, #0x8
    20fc:      	add	x0, x23, #0x18
    2100:      	add	x20, sp, #0x8
    2104:      	bl	0x4970 <_ZNKSt6__ndk115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strEv@plt>
    2108:      	ldrb	w8, [sp, #0x8]
    210c:      	ldp	x10, x9, [sp, #0x10]
    2110:      	orr	x12, x20, #0x1
    2114:      	mov	x0, x19
    2118:      	lsr	x11, x8, #1
    211c:      	tst	w8, #0x1
    2120:      	csel	x1, x12, x9, eq
    2124:      	csel	x2, x11, x10, eq
    2128:      	bl	0x4910 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm@plt>
    212c:      	ldrb	w8, [sp, #0x8]
    2130:      	tbz	w8, #0x0, 0x213c <_Z10getSignKeyP7_JNIEnvP8_jstringS2_S2_+0x270>
    2134:      	ldr	x0, [sp, #0x18]
    2138:      	bl	0x4920 <_ZdlPv@plt>
    213c:      	adrp	x1, 0x1000
    2140:      	add	x1, x1, #0x5e1
    2144:      	mov	x0, x19
    2148:      	bl	0x4900 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>
    214c:      	ldr	x8, [x22]
    2150:      	ldp	x9, x10, [x22, #0x40]
    2154:      	str	x8, [sp, #0x38]
    2158:      	ldur	x8, [x8, #-0x18]
    215c:      	str	x9, [x23, x8]
    2160:      	ldrb	w8, [sp, #0x90]
    2164:      	stp	x10, x21, [sp, #0x48]
    2168:      	tbz	w8, #0x0, 0x2174 <_Z10getSignKeyP7_JNIEnvP8_jstringS2_S2_+0x2a8>
    216c:      	ldr	x0, [sp, #0xa0]
    2170:      	bl	0x4920 <_ZdlPv@plt>
    2174:      	add	x0, x23, #0x18
    2178:      	bl	0x4980 <_ZNSt6__ndk115basic_streambufIcNS_11char_traitsIcEEED2Ev@plt>
    217c:      	add	x0, sp, #0x38
    2180:      	add	x1, x22, #0x8
    2184:      	bl	0x4990 <_ZNSt6__ndk114basic_iostreamIcNS_11char_traitsIcEEED2Ev@plt>
    2188:      	add	x0, x23, #0x80
    218c:      	bl	0x49a0 <_ZNSt6__ndk19basic_iosIcNS_11char_traitsIcEEED2Ev@plt>
    2190:      	ldrb	w8, [sp, #0x20]
    2194:      	tbz	w8, #0x0, 0x21a0 <_Z10getSignKeyP7_JNIEnvP8_jstringS2_S2_+0x2d4>
    2198:      	ldr	x0, [sp, #0x30]
    219c:      	bl	0x4920 <_ZdlPv@plt>
    21a0:      	ldr	x8, [x24, #0x28]
    21a4:      	ldur	x9, [x29, #-0x10]
    21a8:      	cmp	x8, x9
    21ac:      	b.ne	0x21d0 <_Z10getSignKeyP7_JNIEnvP8_jstringS2_S2_+0x304>
    21b0:      	ldp	x20, x19, [sp, #0x1b0]
    21b4:      	ldp	x22, x21, [sp, #0x1a0]
    21b8:      	ldp	x24, x23, [sp, #0x190]
    21bc:      	ldp	x26, x25, [sp, #0x180]
    21c0:      	ldp	x28, x27, [sp, #0x170]
    21c4:      	ldp	x29, x30, [sp, #0x160]
    21c8:      	add	sp, sp, #0x1c0
    21cc:      	ret
    21d0:      	bl	0x48e0 <__stack_chk_fail@plt>

00000000000021d4 <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign>:
    21d4:      	stp	x29, x30, [sp, #-0x60]!
    21d8:      	stp	x28, x27, [sp, #0x10]
    21dc:      	stp	x26, x25, [sp, #0x20]
    21e0:      	stp	x24, x23, [sp, #0x30]
    21e4:      	stp	x22, x21, [sp, #0x40]
    21e8:      	stp	x20, x19, [sp, #0x50]
    21ec:      	mov	x29, sp
    21f0:      	sub	sp, sp, #0x210
    21f4:      	mrs	x25, TPIDR_EL0
    21f8:      	mov	x19, sp
    21fc:      	mov	x1, x3
    2200:      	ldr	x8, [x25, #0x28]
    2204:      	mov	x3, x2
    2208:      	add	x9, x19, #0x58
    220c:      	mov	x2, x5
    2210:      	mov	x21, x4
    2214:      	mov	x20, x0
    2218:      	stur	x8, [x29, #-0x8]
    221c:      	add	x8, x19, #0x70
    2220:      	orr	x24, x9, #0x1
    2224:      	orr	x22, x8, #0x1
    2228:      	add	x8, x19, #0x40
    222c:      	strh	wzr, [x19, #0x70]
    2230:      	strh	wzr, [x19, #0x58]
    2234:      	add	x23, x19, #0x40
    2238:      	bl	0x48f0 <_Z10getSignKeyP7_JNIEnvP8_jstringS2_S2_@plt>
    223c:      	adrp	x1, 0x1000
    2240:      	add	x1, x1, #0x570
    2244:      	add	x0, x19, #0x58
    2248:      	bl	0x4900 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>
    224c:      	ldrb	w8, [x19, #0x40]
    2250:      	ldp	x10, x9, [x19, #0x48]
    2254:      	orr	x23, x23, #0x1
    2258:      	add	x0, x19, #0x58
    225c:      	lsr	x11, x8, #1
    2260:      	tst	w8, #0x1
    2264:      	csel	x1, x23, x9, eq
    2268:      	csel	x2, x11, x10, eq
    226c:      	bl	0x4910 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm@plt>
    2270:      	add	x8, x19, #0x28
    2274:      	mov	x0, x20
    2278:      	mov	x1, x21
    227c:      	add	x21, x19, #0x28
    2280:      	bl	0x4870 <_Z11jstring2strP7_JNIEnvP8_jstring@plt>
    2284:      	ldrb	w8, [x19, #0x28]
    2288:      	ldp	x10, x9, [x19, #0x30]
    228c:      	orr	x12, x21, #0x1
    2290:      	add	x0, x19, #0x70
    2294:      	lsr	x11, x8, #1
    2298:      	tst	w8, #0x1
    229c:      	csel	x1, x12, x9, eq
    22a0:      	csel	x2, x11, x10, eq
    22a4:      	bl	0x4910 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm@plt>
    22a8:      	ldrb	w8, [x19, #0x40]
    22ac:      	ldr	x9, [x19, #0x50]
    22b0:      	add	x0, x19, #0x88
    22b4:      	ldrb	w10, [x19, #0x70]
    22b8:      	tst	w8, #0x1
    22bc:      	ldr	x8, [x19, #0x80]
    22c0:      	csel	x21, x23, x9, eq
    22c4:      	tst	w10, #0x1
    22c8:      	csel	x22, x22, x8, eq
    22cc:      	bl	0x49b0 <_ZN5CSHA1C2Ev@plt>
    22d0:      	mov	w0, #0x1000             // =4096
    22d4:      	bl	0x49c0 <_Znam@plt>
    22d8:      	str	x0, [x19, #0x1d0]
    22dc:      	mov	w0, #0x1000             // =4096
    22e0:      	bl	0x49c0 <_Znam@plt>
    22e4:      	str	x0, [x19, #0x1d8]
    22e8:      	mov	w0, #0x1000             // =4096
    22ec:      	bl	0x49c0 <_Znam@plt>
    22f0:      	str	x0, [x19, #0x1e0]
    22f4:      	mov	w0, #0x1000             // =4096
    22f8:      	bl	0x49c0 <_Znam@plt>
    22fc:      	str	x0, [x19, #0x1e8]
    2300:      	mov	x0, x21
    2304:      	bl	0x48b0 <strlen@plt>
    2308:      	mov	x23, x0
    230c:      	mov	x0, x22
    2310:      	bl	0x48b0 <strlen@plt>
    2314:      	mov	x4, x0
    2318:      	add	x0, x19, #0x88
    231c:      	sub	x5, x29, #0x1c
    2320:      	mov	x1, x21
    2324:      	mov	w2, w23
    2328:      	mov	x3, x22
    232c:      	bl	0x49d0 <_ZN10CHMAC_SHA19HMAC_SHA1EPhiS0_iS0_@plt>
    2330:      	ldrb	w8, [x19, #0x58]
    2334:      	ldr	x9, [x19, #0x60]
    2338:      	mov	x26, sp
    233c:      	lsr	x10, x8, #1
    2340:      	tst	w8, #0x1
    2344:      	csel	x27, x10, x9, eq
    2348:      	mov	x9, sp
    234c:      	and	x21, x27, #0xffffffff
    2350:      	add	x8, x21, #0xf
    2354:      	and	x8, x8, #0x1fffffff0
    2358:      	sub	x22, x9, x8
    235c:      	mov	sp, x22
    2360:      	ldrb	w8, [x19, #0x58]
    2364:      	ldp	x10, x9, [x19, #0x60]
    2368:      	mov	x0, x22
    236c:      	lsr	x11, x8, #1
    2370:      	tst	w8, #0x1
    2374:      	csel	x1, x24, x9, eq
    2378:      	csel	x2, x11, x10, eq
    237c:      	bl	0x48a0 <memcpy@plt>
    2380:      	add	w23, w27, #0x14
    2384:      	mov	x9, sp
    2388:      	add	x8, x23, #0xf
    238c:      	and	x8, x8, #0x1fffffff0
    2390:      	sub	x24, x9, x8
    2394:      	mov	sp, x24
    2398:      	ldur	q0, [x29, #-0x1c]
    239c:      	ldur	w8, [x29, #-0xc]
    23a0:      	cmp	w27, #0x1
    23a4:      	str	q0, [x24]
    23a8:      	str	w8, [x24, #0x10]
    23ac:      	b.lt	0x23c0 <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x1ec>
    23b0:      	add	x0, x24, #0x14
    23b4:      	mov	x1, x22
    23b8:      	mov	x2, x21
    23bc:      	bl	0x48a0 <memcpy@plt>
    23c0:      	add	x8, x19, #0x8
    23c4:      	add	x0, x19, #0x27
    23c8:      	mov	x1, x24
    23cc:      	mov	w2, w23
    23d0:      	add	x21, x19, #0x8
    23d4:      	bl	0x49e0 <_ZN7ZBase646EncodeEPKhi@plt>
    23d8:      	ldrb	w8, [x19, #0x8]
    23dc:      	ldr	x9, [x20]
    23e0:      	orr	x11, x21, #0x1
    23e4:      	ldr	x10, [x19, #0x18]
    23e8:      	mov	x0, x20
    23ec:      	tst	w8, #0x1
    23f0:      	ldr	x8, [x9, #0x538]
    23f4:      	csel	x1, x11, x10, eq
    23f8:      	blr	x8
    23fc:      	ldrb	w8, [x19, #0x8]
    2400:      	mov	x20, x0
    2404:      	tbz	w8, #0x0, 0x2410 <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x23c>
    2408:      	ldr	x0, [x19, #0x18]
    240c:      	bl	0x4920 <_ZdlPv@plt>
    2410:      	mov	sp, x26
    2414:      	ldr	x0, [x19, #0x1d0]
    2418:      	cbz	x0, 0x2420 <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x24c>
    241c:      	bl	0x49f0 <_ZdaPv@plt>
    2420:      	ldr	x0, [x19, #0x1e0]
    2424:      	cbz	x0, 0x242c <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x258>
    2428:      	bl	0x49f0 <_ZdaPv@plt>
    242c:      	ldr	x0, [x19, #0x1e8]
    2430:      	cbz	x0, 0x2438 <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x264>
    2434:      	bl	0x49f0 <_ZdaPv@plt>
    2438:      	ldr	x0, [x19, #0x1d8]
    243c:      	cbz	x0, 0x2444 <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x270>
    2440:      	bl	0x49f0 <_ZdaPv@plt>
    2444:      	add	x0, x19, #0x88
    2448:      	bl	0x4a00 <_ZN5CSHA1D2Ev@plt>
    244c:      	ldrb	w8, [x19, #0x28]
    2450:      	tbnz	w8, #0x0, 0x24a0 <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x2cc>
    2454:      	ldrb	w8, [x19, #0x40]
    2458:      	tbnz	w8, #0x0, 0x24b0 <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x2dc>
    245c:      	ldrb	w8, [x19, #0x58]
    2460:      	tbnz	w8, #0x0, 0x24c0 <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x2ec>
    2464:      	ldrb	w8, [x19, #0x70]
    2468:      	tbnz	w8, #0x0, 0x24d0 <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x2fc>
    246c:      	ldr	x8, [x25, #0x28]
    2470:      	ldur	x9, [x29, #-0x8]
    2474:      	cmp	x8, x9
    2478:      	b.ne	0x24e8 <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x314>
    247c:      	mov	x0, x20
    2480:      	mov	sp, x29
    2484:      	ldp	x20, x19, [sp, #0x50]
    2488:      	ldp	x22, x21, [sp, #0x40]
    248c:      	ldp	x24, x23, [sp, #0x30]
    2490:      	ldp	x26, x25, [sp, #0x20]
    2494:      	ldp	x28, x27, [sp, #0x10]
    2498:      	ldp	x29, x30, [sp], #0x60
    249c:      	ret
    24a0:      	ldr	x0, [x19, #0x38]
    24a4:      	bl	0x4920 <_ZdlPv@plt>
    24a8:      	ldrb	w8, [x19, #0x40]
    24ac:      	tbz	w8, #0x0, 0x245c <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x288>
    24b0:      	ldr	x0, [x19, #0x50]
    24b4:      	bl	0x4920 <_ZdlPv@plt>
    24b8:      	ldrb	w8, [x19, #0x58]
    24bc:      	tbz	w8, #0x0, 0x2464 <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x290>
    24c0:      	ldr	x0, [x19, #0x68]
    24c4:      	bl	0x4920 <_ZdlPv@plt>
    24c8:      	ldrb	w8, [x19, #0x70]
    24cc:      	tbz	w8, #0x0, 0x246c <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x298>
    24d0:      	ldr	x0, [x19, #0x80]
    24d4:      	bl	0x4920 <_ZdlPv@plt>
    24d8:      	ldr	x8, [x25, #0x28]
    24dc:      	ldur	x9, [x29, #-0x8]
    24e0:      	cmp	x8, x9
    24e4:      	b.eq	0x247c <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x2a8>
    24e8:      	bl	0x48e0 <__stack_chk_fail@plt>
    24ec:      	stp	x29, x30, [sp, #-0x10]!
    24f0:      	mov	x29, sp
    24f4:      	adrp	x0, 0x1000
    24f8:      	add	x0, x0, #0x659
    24fc:      	bl	0x2500 <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x32c>
    2500:      	stp	x29, x30, [sp, #-0x10]!
    2504:      	mov	x29, sp
    2508:      	mov	x1, x0
    250c:      	adrp	x0, 0x1000
    2510:      	add	x0, x0, #0x58b
    2514:      	bl	0x4a10 <_ZNSt6__ndk122__libcpp_verbose_abortEPKcz@plt>

0000000000002518 <_ZN5CSHA1C2Ev>:
    2518:      	adrp	x8, 0x1000
    251c:      	adrp	x9, 0x1000
    2520:      	add	x10, x0, #0x80
    2524:      	ldr	q0, [x8, #0x670]
    2528:      	ldr	d1, [x9, #0x680]
    252c:      	str	x10, [x0, #0xc0]
    2530:      	str	wzr, [x0, #0x18]
    2534:      	str	q0, [x0]
    2538:      	str	d1, [x0, #0x10]
    253c:      	ret

0000000000002540 <_ZN5CSHA15ResetEv>:
    2540:      	adrp	x8, 0x1000
    2544:      	adrp	x9, 0x1000
    2548:      	str	wzr, [x0, #0x18]
    254c:      	ldr	q0, [x8, #0x670]
    2550:      	ldr	d1, [x9, #0x680]
    2554:      	str	q0, [x0]
    2558:      	str	d1, [x0, #0x10]
    255c:      	ret

0000000000002560 <_ZN5CSHA1D2Ev>:
    2560:      	adrp	x8, 0x1000
    2564:      	adrp	x9, 0x1000
    2568:      	str	wzr, [x0, #0x18]
    256c:      	ldr	q0, [x8, #0x670]
    2570:      	ldr	d1, [x9, #0x680]
    2574:      	str	q0, [x0]
    2578:      	str	d1, [x0, #0x10]
    257c:      	ret

0000000000002580 <_ZN5CSHA19TransformEPjPh>:
    2580:      	sub	sp, sp, #0xf0
    2584:      	stp	x29, x30, [sp, #0x90]
    2588:      	stp	x28, x27, [sp, #0xa0]
    258c:      	stp	x26, x25, [sp, #0xb0]
    2590:      	stp	x24, x23, [sp, #0xc0]
    2594:      	stp	x22, x21, [sp, #0xd0]
    2598:      	stp	x20, x19, [sp, #0xe0]
    259c:      	ldp	q0, q1, [x2, #0x20]
    25a0:      	ldr	x10, [x0, #0xc0]
    25a4:      	ldp	q2, q3, [x2]
    25a8:      	str	x1, [sp, #0x88]
    25ac:      	ldp	w16, w30, [x1]
    25b0:      	ldp	w25, w23, [x1, #0x8]
    25b4:      	ldr	w1, [x1, #0x10]
    25b8:      	stp	q2, q3, [x10]
    25bc:      	stp	q0, q1, [x10, #0x20]
    25c0:      	ldr	x10, [x0, #0xc0]
    25c4:      	ldr	w11, [x10]
    25c8:      	rev	w19, w11
    25cc:      	ror	w11, w16, #0x1b
    25d0:      	str	w19, [x10]
    25d4:      	ldr	x12, [x0, #0xc0]
    25d8:      	add	w11, w11, w1
    25dc:      	ldr	w10, [x12, #0x4]
    25e0:      	rev	w7, w10
    25e4:      	str	w7, [x12, #0x4]
    25e8:      	ldr	x12, [x0, #0xc0]
    25ec:      	ldr	w13, [x12, #0x8]
    25f0:      	rev	w21, w13
    25f4:      	str	w21, [x12, #0x8]
    25f8:      	ldr	x14, [x0, #0xc0]
    25fc:      	ldr	w12, [x14, #0xc]
    2600:      	rev	w20, w12
    2604:      	str	w20, [x14, #0xc]
    2608:      	ldr	x14, [x0, #0xc0]
    260c:      	ldr	w15, [x14, #0x10]
    2610:      	rev	w24, w15
    2614:      	str	w24, [x14, #0x10]
    2618:      	ldr	x17, [x0, #0xc0]
    261c:      	ldr	w14, [x17, #0x14]
    2620:      	rev	w15, w14
    2624:      	str	w15, [x17, #0x14]
    2628:      	ldr	x17, [x0, #0xc0]
    262c:      	ldr	w2, [x17, #0x18]
    2630:      	rev	w27, w2
    2634:      	str	w27, [x17, #0x18]
    2638:      	ldr	x17, [x0, #0xc0]
    263c:      	ldr	w2, [x17, #0x1c]
    2640:      	rev	w26, w2
    2644:      	str	w26, [x17, #0x1c]
    2648:      	ldr	x17, [x0, #0xc0]
    264c:      	ldr	w2, [x17, #0x20]
    2650:      	rev	w9, w2
    2654:      	str	w9, [x17, #0x20]
    2658:      	ldr	x17, [x0, #0xc0]
    265c:      	ldr	w2, [x17, #0x24]
    2660:      	rev	w8, w2
    2664:      	str	w8, [x17, #0x24]
    2668:      	ldr	x17, [x0, #0xc0]
    266c:      	stp	w8, w9, [sp, #0x28]
    2670:      	ldr	w2, [x17, #0x28]
    2674:      	rev	w8, w2
    2678:      	str	w8, [x17, #0x28]
    267c:      	ldr	x17, [x0, #0xc0]
    2680:      	str	w8, [sp, #0x4c]
    2684:      	ldr	w2, [x17, #0x2c]
    2688:      	rev	w8, w2
    268c:      	str	w8, [x17, #0x2c]
    2690:      	ldr	x17, [x0, #0xc0]
    2694:      	str	w8, [sp, #0x38]
    2698:      	ldr	w2, [x17, #0x30]
    269c:      	rev	w8, w2
    26a0:      	str	w8, [x17, #0x30]
    26a4:      	ldr	x17, [x0, #0xc0]
    26a8:      	str	w8, [sp, #0x68]
    26ac:      	ldr	w2, [x17, #0x34]
    26b0:      	rev	w8, w2
    26b4:      	str	w8, [x17, #0x34]
    26b8:      	ldr	x17, [x0, #0xc0]
    26bc:      	str	w8, [sp, #0x58]
    26c0:      	ldr	w2, [x17, #0x38]
    26c4:      	rev	w8, w2
    26c8:      	str	w8, [x17, #0x38]
    26cc:      	ldr	x17, [x0, #0xc0]
    26d0:      	str	w8, [sp, #0x70]
    26d4:      	ldr	w2, [x17, #0x3c]
    26d8:      	rev	w8, w2
    26dc:      	str	w8, [x17, #0x3c]
    26e0:      	ldr	x17, [x0, #0xc0]
    26e4:      	str	w8, [sp, #0x78]
    26e8:      	ldr	w2, [x17, #0x34]
    26ec:      	ldr	w3, [x17, #0x20]
    26f0:      	ldr	w4, [x17, #0x8]
    26f4:      	ldr	w5, [x17]
    26f8:      	eor	w2, w3, w2
    26fc:      	eor	w3, w4, w5
    2700:      	eor	w2, w2, w3
    2704:      	ror	w8, w2, #0x1f
    2708:      	str	w8, [x17]
    270c:      	ldr	x17, [x0, #0xc0]
    2710:      	str	w8, [sp, #0x84]
    2714:      	ldr	w2, [x17, #0x38]
    2718:      	ldr	w3, [x17, #0x24]
    271c:      	ldr	w4, [x17, #0xc]
    2720:      	ldr	w5, [x17, #0x4]
    2724:      	eor	w2, w3, w2
    2728:      	eor	w3, w4, w5
    272c:      	eor	w2, w2, w3
    2730:      	ror	w9, w2, #0x1f
    2734:      	str	w9, [x17, #0x4]
    2738:      	ldr	x17, [x0, #0xc0]
    273c:      	ldr	w2, [x17, #0x3c]
    2740:      	ldr	w3, [x17, #0x28]
    2744:      	ldr	w4, [x17, #0x10]
    2748:      	ldr	w5, [x17, #0x8]
    274c:      	eor	w2, w3, w2
    2750:      	eor	w3, w4, w5
    2754:      	eor	w2, w2, w3
    2758:      	ror	w8, w2, #0x1f
    275c:      	str	w8, [x17, #0x8]
    2760:      	ldr	x17, [x0, #0xc0]
    2764:      	stp	w9, w8, [sp, #0x7c]
    2768:      	ldr	w2, [x17]
    276c:      	ldr	w3, [x17, #0x2c]
    2770:      	ldr	w4, [x17, #0x14]
    2774:      	ldr	w5, [x17, #0xc]
    2778:      	eor	w2, w3, w2
    277c:      	eor	w3, w4, w5
    2780:      	eor	w2, w2, w3
    2784:      	ror	w8, w2, #0x1f
    2788:      	str	w8, [x17, #0xc]
    278c:      	ldr	x17, [x0, #0xc0]
    2790:      	str	w8, [sp, #0x6c]
    2794:      	ldr	w2, [x17, #0x4]
    2798:      	ldr	w3, [x17, #0x30]
    279c:      	ldr	w4, [x17, #0x18]
    27a0:      	ldr	w5, [x17, #0x10]
    27a4:      	eor	w2, w3, w2
    27a8:      	eor	w3, w4, w5
    27ac:      	eor	w2, w2, w3
    27b0:      	ror	w8, w2, #0x1f
    27b4:      	str	w8, [x17, #0x10]
    27b8:      	ldr	x17, [x0, #0xc0]
    27bc:      	str	w8, [sp, #0x60]
    27c0:      	ldr	w2, [x17, #0x8]
    27c4:      	ldr	w3, [x17, #0x34]
    27c8:      	ldr	w4, [x17, #0x1c]
    27cc:      	ldr	w5, [x17, #0x14]
    27d0:      	eor	w2, w3, w2
    27d4:      	eor	w3, w4, w5
    27d8:      	eor	w2, w2, w3
    27dc:      	ror	w8, w2, #0x1f
    27e0:      	str	w8, [x17, #0x14]
    27e4:      	ldr	x17, [x0, #0xc0]
    27e8:      	str	w8, [sp, #0x74]
    27ec:      	ldr	w2, [x17, #0xc]
    27f0:      	ldr	w3, [x17, #0x38]
    27f4:      	ldr	w4, [x17, #0x20]
    27f8:      	ldr	w5, [x17, #0x18]
    27fc:      	eor	w2, w3, w2
    2800:      	eor	w3, w4, w5
    2804:      	eor	w2, w2, w3
    2808:      	ror	w8, w2, #0x1f
    280c:      	str	w8, [x17, #0x18]
    2810:      	ldr	x17, [x0, #0xc0]
    2814:      	str	w8, [sp, #0x5c]
    2818:      	ldr	w2, [x17, #0x10]
    281c:      	ldr	w3, [x17, #0x3c]
    2820:      	ldr	w4, [x17, #0x24]
    2824:      	ldr	w5, [x17, #0x1c]
    2828:      	eor	w2, w3, w2
    282c:      	eor	w3, w4, w5
    2830:      	eor	w2, w2, w3
    2834:      	ror	w8, w2, #0x1f
    2838:      	str	w8, [x17, #0x1c]
    283c:      	ldr	x17, [x0, #0xc0]
    2840:      	str	w8, [sp, #0x64]
    2844:      	ldr	w2, [x17, #0x14]
    2848:      	ldr	w3, [x17]
    284c:      	ldr	w4, [x17, #0x28]
    2850:      	ldr	w5, [x17, #0x20]
    2854:      	eor	w2, w3, w2
    2858:      	eor	w3, w4, w5
    285c:      	eor	w2, w2, w3
    2860:      	ror	w8, w2, #0x1f
    2864:      	str	w8, [x17, #0x20]
    2868:      	ldr	x17, [x0, #0xc0]
    286c:      	str	w8, [sp, #0x50]
    2870:      	ldr	w2, [x17, #0x18]
    2874:      	ldr	w3, [x17, #0x4]
    2878:      	ldr	w4, [x17, #0x2c]
    287c:      	ldr	w5, [x17, #0x24]
    2880:      	eor	w2, w3, w2
    2884:      	eor	w3, w4, w5
    2888:      	eor	w2, w2, w3
    288c:      	ror	w8, w2, #0x1f
    2890:      	str	w8, [x17, #0x24]
    2894:      	ldr	x17, [x0, #0xc0]
    2898:      	str	w8, [sp, #0x44]
    289c:      	ldr	w2, [x17, #0x1c]
    28a0:      	ldr	w3, [x17, #0x8]
    28a4:      	ldr	w4, [x17, #0x30]
    28a8:      	ldr	w5, [x17, #0x28]
    28ac:      	eor	w2, w3, w2
    28b0:      	eor	w3, w4, w5
    28b4:      	eor	w2, w2, w3
    28b8:      	ror	w8, w2, #0x1f
    28bc:      	str	w8, [x17, #0x28]
    28c0:      	ldr	x17, [x0, #0xc0]
    28c4:      	str	w8, [sp, #0x54]
    28c8:      	ldr	w2, [x17, #0x20]
    28cc:      	ldr	w3, [x17, #0xc]
    28d0:      	ldr	w4, [x17, #0x34]
    28d4:      	ldr	w5, [x17, #0x2c]
    28d8:      	eor	w2, w3, w2
    28dc:      	eor	w3, w4, w5
    28e0:      	eor	w2, w2, w3
    28e4:      	ror	w8, w2, #0x1f
    28e8:      	str	w8, [x17, #0x2c]
    28ec:      	ldr	x17, [x0, #0xc0]
    28f0:      	str	w8, [sp, #0x40]
    28f4:      	ldr	w2, [x17, #0x24]
    28f8:      	ldr	w3, [x17, #0x10]
    28fc:      	ldr	w4, [x17, #0x38]
    2900:      	ldr	w5, [x17, #0x30]
    2904:      	eor	w2, w3, w2
    2908:      	eor	w3, w4, w5
    290c:      	eor	w2, w2, w3
    2910:      	ror	w8, w2, #0x1f
    2914:      	str	w8, [x17, #0x30]
    2918:      	ldr	x17, [x0, #0xc0]
    291c:      	str	w8, [sp, #0x48]
    2920:      	ldr	w2, [x17, #0x28]
    2924:      	ldr	w3, [x17, #0x14]
    2928:      	ldr	w4, [x17, #0x3c]
    292c:      	ldr	w5, [x17, #0x34]
    2930:      	eor	w2, w3, w2
    2934:      	eor	w3, w4, w5
    2938:      	eor	w2, w2, w3
    293c:      	ror	w8, w2, #0x1f
    2940:      	str	w8, [x17, #0x34]
    2944:      	ldr	x17, [x0, #0xc0]
    2948:      	str	w8, [sp, #0x34]
    294c:      	ldr	w2, [x17, #0x2c]
    2950:      	ldr	w3, [x17, #0x18]
    2954:      	ldr	w4, [x17]
    2958:      	ldr	w5, [x17, #0x38]
    295c:      	eor	w2, w3, w2
    2960:      	eor	w3, w4, w5
    2964:      	eor	w2, w2, w3
    2968:      	ror	w8, w2, #0x1f
    296c:      	str	w8, [x17, #0x38]
    2970:      	ldr	x17, [x0, #0xc0]
    2974:      	str	w8, [sp, #0x24]
    2978:      	ldr	w2, [x17, #0x30]
    297c:      	ldr	w3, [x17, #0x1c]
    2980:      	ldr	w4, [x17, #0x4]
    2984:      	ldr	w5, [x17, #0x3c]
    2988:      	eor	w2, w3, w2
    298c:      	eor	w3, w4, w5
    2990:      	eor	w2, w2, w3
    2994:      	ror	w8, w2, #0x1f
    2998:      	str	w8, [x17, #0x3c]
    299c:      	ldr	x17, [x0, #0xc0]
    29a0:      	str	w8, [sp, #0x3c]
    29a4:      	ldr	w2, [x17, #0x34]
    29a8:      	ldr	w3, [x17, #0x20]
    29ac:      	ldr	w4, [x17, #0x8]
    29b0:      	ldr	w5, [x17]
    29b4:      	eor	w2, w3, w2
    29b8:      	eor	w3, w4, w5
    29bc:      	eor	w2, w2, w3
    29c0:      	ror	w8, w2, #0x1f
    29c4:      	str	w8, [x17]
    29c8:      	ldr	x17, [x0, #0xc0]
    29cc:      	str	w8, [sp, #0x20]
    29d0:      	ldr	w2, [x17, #0x38]
    29d4:      	ldr	w3, [x17, #0x24]
    29d8:      	ldr	w4, [x17, #0xc]
    29dc:      	ldr	w5, [x17, #0x4]
    29e0:      	eor	w2, w3, w2
    29e4:      	eor	w3, w4, w5
    29e8:      	eor	w2, w2, w3
    29ec:      	ror	w8, w2, #0x1f
    29f0:      	str	w8, [x17, #0x4]
    29f4:      	ldr	x17, [x0, #0xc0]
    29f8:      	str	w8, [sp, #0x30]
    29fc:      	ldr	w2, [x17, #0x3c]
    2a00:      	ldr	w3, [x17, #0x28]
    2a04:      	ldr	w4, [x17, #0x10]
    2a08:      	ldr	w5, [x17, #0x8]
    2a0c:      	eor	w2, w3, w2
    2a10:      	eor	w3, w4, w5
    2a14:      	eor	w2, w2, w3
    2a18:      	ror	w8, w2, #0x1f
    2a1c:      	str	w8, [x17, #0x8]
    2a20:      	ldr	x17, [x0, #0xc0]
    2a24:      	str	w8, [sp, #0x1c]
    2a28:      	ldr	w2, [x17]
    2a2c:      	ldr	w3, [x17, #0x2c]
    2a30:      	ldr	w4, [x17, #0x14]
    2a34:      	ldr	w5, [x17, #0xc]
    2a38:      	eor	w2, w3, w2
    2a3c:      	eor	w3, w4, w5
    2a40:      	eor	w2, w2, w3
    2a44:      	ror	w28, w2, #0x1f
    2a48:      	str	w28, [x17, #0xc]
    2a4c:      	ldr	x17, [x0, #0xc0]
    2a50:      	ldr	w2, [x17, #0x4]
    2a54:      	ldr	w3, [x17, #0x30]
    2a58:      	ldr	w4, [x17, #0x18]
    2a5c:      	ldr	w5, [x17, #0x10]
    2a60:      	eor	w2, w3, w2
    2a64:      	eor	w3, w4, w5
    2a68:      	eor	w2, w2, w3
    2a6c:      	ror	w8, w2, #0x1f
    2a70:      	str	w8, [x17, #0x10]
    2a74:      	ldr	x17, [x0, #0xc0]
    2a78:      	str	w8, [sp, #0x18]
    2a7c:      	ldr	w2, [x17, #0x8]
    2a80:      	ldr	w3, [x17, #0x34]
    2a84:      	ldr	w4, [x17, #0x1c]
    2a88:      	ldr	w5, [x17, #0x14]
    2a8c:      	eor	w2, w3, w2
    2a90:      	eor	w3, w4, w5
    2a94:      	eor	w2, w2, w3
    2a98:      	ror	w5, w2, #0x1f
    2a9c:      	str	w5, [x17, #0x14]
    2aa0:      	ldr	x17, [x0, #0xc0]
    2aa4:      	ldr	w2, [x17, #0xc]
    2aa8:      	ldr	w3, [x17, #0x38]
    2aac:      	ldr	w4, [x17, #0x20]
    2ab0:      	ldr	w6, [x17, #0x18]
    2ab4:      	eor	w2, w3, w2
    2ab8:      	eor	w3, w4, w6
    2abc:      	eor	w2, w2, w3
    2ac0:      	ror	w29, w2, #0x1f
    2ac4:      	str	w29, [x17, #0x18]
    2ac8:      	ldr	x17, [x0, #0xc0]
    2acc:      	ldr	w2, [x17, #0x10]
    2ad0:      	ldr	w3, [x17, #0x3c]
    2ad4:      	ldr	w4, [x17, #0x24]
    2ad8:      	ldr	w6, [x17, #0x1c]
    2adc:      	eor	w2, w3, w2
    2ae0:      	eor	w3, w4, w6
    2ae4:      	eor	w2, w2, w3
    2ae8:      	ror	w2, w2, #0x1f
    2aec:      	str	w2, [x17, #0x1c]
    2af0:      	ldr	x17, [x0, #0xc0]
    2af4:      	ldr	w3, [x17, #0x14]
    2af8:      	ldr	w4, [x17]
    2afc:      	ldr	w6, [x17, #0x28]
    2b00:      	ldr	w22, [x17, #0x20]
    2b04:      	eor	w3, w4, w3
    2b08:      	eor	w4, w6, w22
    2b0c:      	eor	w3, w3, w4
    2b10:      	ror	w22, w3, #0x1f
    2b14:      	str	w22, [x17, #0x20]
    2b18:      	ldr	x17, [x0, #0xc0]
    2b1c:      	ldr	w3, [x17, #0x18]
    2b20:      	ldr	w4, [x17, #0x4]
    2b24:      	ldr	w6, [x17, #0x2c]
    2b28:      	ldr	w8, [x17, #0x24]
    2b2c:      	eor	w3, w4, w3
    2b30:      	eor	w8, w6, w8
    2b34:      	eor	w8, w3, w8
    2b38:      	ror	w3, w8, #0x1f
    2b3c:      	str	w3, [x17, #0x24]
    2b40:      	ldr	x8, [x0, #0xc0]
    2b44:      	ldr	w17, [x8, #0x1c]
    2b48:      	ldr	w4, [x8, #0x8]
    2b4c:      	ldr	w6, [x8, #0x30]
    2b50:      	ldr	w9, [x8, #0x28]
    2b54:      	eor	w17, w4, w17
    2b58:      	eor	w9, w6, w9
    2b5c:      	eor	w9, w17, w9
    2b60:      	ror	w9, w9, #0x1f
    2b64:      	str	w9, [x8, #0x28]
    2b68:      	ldr	x8, [x0, #0xc0]
    2b6c:      	str	w9, [sp, #0x14]
    2b70:      	ldr	w10, [x8, #0x20]
    2b74:      	ldr	w17, [x8, #0xc]
    2b78:      	ldr	w4, [x8, #0x34]
    2b7c:      	ldr	w9, [x8, #0x2c]
    2b80:      	eor	w10, w17, w10
    2b84:      	mov	w17, #0x7999            // =31129
    2b88:      	eor	w9, w4, w9
    2b8c:      	movk	w17, #0x5a82, lsl #16
    2b90:      	eor	w9, w10, w9
    2b94:      	bic	w10, w23, w30
    2b98:      	ror	w6, w9, #0x1f
    2b9c:      	str	w6, [x8, #0x2c]
    2ba0:      	and	w8, w25, w30
    2ba4:      	ldr	x9, [x0, #0xc0]
    2ba8:      	orr	w8, w8, w10
    2bac:      	add	w11, w11, w8
    2bb0:      	ldr	w14, [x9, #0x24]
    2bb4:      	ldr	w13, [x9, #0x10]
    2bb8:      	ldr	w4, [x9, #0x38]
    2bbc:      	ldr	w12, [x9, #0x30]
    2bc0:      	eor	w10, w13, w14
    2bc4:      	bic	w13, w25, w16
    2bc8:      	eor	w12, w4, w12
    2bcc:      	eor	w10, w10, w12
    2bd0:      	ror	w12, w30, #0x2
    2bd4:      	ror	w4, w10, #0x1f
    2bd8:      	add	w10, w19, w17
    2bdc:      	and	w14, w12, w16
    2be0:      	add	w11, w11, w10
    2be4:      	ror	w10, w16, #0x2
    2be8:      	str	w4, [x9, #0x30]
    2bec:      	orr	w13, w14, w13
    2bf0:      	add	w9, w23, w7
    2bf4:      	ldr	x14, [x0, #0xc0]
    2bf8:      	add	w9, w9, w13
    2bfc:      	ror	w13, w11, #0x1b
    2c00:      	add	w9, w9, w17
    2c04:      	bic	w16, w12, w11
    2c08:      	and	w1, w10, w11
    2c0c:      	ldr	w7, [x14, #0x28]
    2c10:      	ldr	w19, [x14, #0x14]
    2c14:      	ldr	w23, [x14, #0x3c]
    2c18:      	ldr	w8, [x14, #0x34]
    2c1c:      	add	w13, w9, w13
    2c20:      	orr	w16, w1, w16
    2c24:      	eor	w9, w19, w7
    2c28:      	add	w1, w25, w21
    2c2c:      	ror	w7, w11, #0x2
    2c30:      	eor	w8, w23, w8
    2c34:      	add	w11, w1, w16
    2c38:      	bic	w16, w10, w13
    2c3c:      	eor	w8, w9, w8
    2c40:      	add	w11, w11, w17
    2c44:      	and	w1, w7, w13
    2c48:      	ror	w9, w8, #0x1f
    2c4c:      	ror	w8, w13, #0x1b
    2c50:      	orr	w16, w1, w16
    2c54:      	add	w12, w12, w20
    2c58:      	add	w10, w10, w24
    2c5c:      	str	w9, [x14, #0x34]
    2c60:      	add	w8, w11, w8
    2c64:      	ror	w11, w13, #0x2
    2c68:      	ldr	x13, [x0, #0xc0]
    2c6c:      	add	w12, w12, w16
    2c70:      	ror	w14, w8, #0x1b
    2c74:      	bic	w16, w7, w8
    2c78:      	and	w1, w11, w8
    2c7c:      	add	w12, w12, w17
    2c80:      	ldr	w19, [x13, #0x2c]
    2c84:      	ldr	w20, [x13, #0x18]
    2c88:      	ldr	w21, [x13]
    2c8c:      	ldr	w23, [x13, #0x38]
    2c90:      	orr	w16, w1, w16
    2c94:      	add	w12, w12, w14
    2c98:      	eor	w14, w20, w19
    2c9c:      	str	w9, [sp, #0x10]
    2ca0:      	ror	w8, w8, #0x2
    2ca4:      	eor	w1, w21, w23
    2ca8:      	add	w16, w10, w16
    2cac:      	eor	w14, w14, w1
    2cb0:      	add	w16, w16, w17
    2cb4:      	bic	w1, w11, w12
    2cb8:      	ror	w9, w14, #0x1f
    2cbc:      	ror	w14, w12, #0x1b
    2cc0:      	and	w19, w8, w12
    2cc4:      	orr	w1, w19, w1
    2cc8:      	ror	w12, w12, #0x2
    2ccc:      	add	w11, w11, w27
    2cd0:      	str	w9, [x13, #0x38]
    2cd4:      	add	w13, w7, w15
    2cd8:      	add	w14, w16, w14
    2cdc:      	ldr	x15, [x0, #0xc0]
    2ce0:      	add	w13, w13, w1
    2ce4:      	ror	w16, w14, #0x1b
    2ce8:      	bic	w1, w8, w14
    2cec:      	and	w7, w12, w14
    2cf0:      	add	w13, w13, w17
    2cf4:      	ldr	w19, [x15, #0x30]
    2cf8:      	ldr	w20, [x15, #0x1c]
    2cfc:      	ldr	w21, [x15, #0x4]
    2d00:      	ldr	w23, [x15, #0x3c]
    2d04:      	orr	w1, w7, w1
    2d08:      	add	w13, w13, w16
    2d0c:      	eor	w16, w20, w19
    2d10:      	str	w9, [sp, #0xc]
    2d14:      	ror	w14, w14, #0x2
    2d18:      	eor	w7, w21, w23
    2d1c:      	add	w1, w11, w1
    2d20:      	add	w8, w8, w26
    2d24:      	eor	w16, w16, w7
    2d28:      	add	w1, w1, w17
    2d2c:      	bic	w7, w12, w13
    2d30:      	ror	w9, w16, #0x1f
    2d34:      	ror	w16, w13, #0x1b
    2d38:      	and	w19, w14, w13
    2d3c:      	orr	w7, w19, w7
    2d40:      	ror	w13, w13, #0x2
    2d44:      	ldr	w11, [sp, #0x54]
    2d48:      	str	w9, [x15, #0x3c]
    2d4c:      	add	w16, w1, w16
    2d50:      	add	w8, w8, w7
    2d54:      	ldr	x15, [x0, #0xc0]
    2d58:      	ror	w1, w16, #0x1b
    2d5c:      	bic	w7, w14, w16
    2d60:      	and	w19, w13, w16
    2d64:      	add	w8, w8, w17
    2d68:      	str	w9, [sp, #0x8]
    2d6c:      	ldr	w20, [x15, #0x34]
    2d70:      	ldr	w21, [x15, #0x20]
    2d74:      	ldr	w23, [x15, #0x8]
    2d78:      	ldr	w24, [x15]
    2d7c:      	orr	w7, w19, w7
    2d80:      	add	w8, w8, w1
    2d84:      	eor	w1, w21, w20
    2d88:      	ldr	w9, [sp, #0x2c]
    2d8c:      	ror	w16, w16, #0x2
    2d90:      	eor	w19, w23, w24
    2d94:      	eor	w1, w1, w19
    2d98:      	add	w12, w12, w9
    2d9c:      	bic	w19, w13, w8
    2da0:      	ror	w9, w1, #0x1f
    2da4:      	add	w7, w12, w7
    2da8:      	ror	w1, w8, #0x1b
    2dac:      	add	w7, w7, w17
    2db0:      	and	w20, w16, w8
    2db4:      	str	w9, [sp, #0x2c]
    2db8:      	orr	w19, w20, w19
    2dbc:      	add	w1, w7, w1
    2dc0:      	str	w9, [x15]
    2dc4:      	ldr	w9, [sp, #0x28]
    2dc8:      	ror	w7, w1, #0x1b
    2dcc:      	add	w15, w14, w9
    2dd0:      	ror	w14, w8, #0x2
    2dd4:      	ldr	x8, [x0, #0xc0]
    2dd8:      	add	w15, w15, w19
    2ddc:      	bic	w19, w16, w1
    2de0:      	ldr	w9, [sp, #0x4c]
    2de4:      	ldr	w21, [x8, #0x38]
    2de8:      	ldr	w23, [x8, #0x24]
    2dec:      	ldr	w24, [x8, #0xc]
    2df0:      	ldr	w25, [x8, #0x4]
    2df4:      	and	w20, w14, w1
    2df8:      	add	w15, w15, w17
    2dfc:      	orr	w19, w20, w19
    2e00:      	ror	w1, w1, #0x2
    2e04:      	add	w15, w15, w7
    2e08:      	eor	w7, w23, w21
    2e0c:      	eor	w20, w24, w25
    2e10:      	eor	w7, w7, w20
    2e14:      	bic	w20, w14, w15
    2e18:      	and	w21, w1, w15
    2e1c:      	ror	w10, w7, #0x1f
    2e20:      	orr	w20, w21, w20
    2e24:      	add	w21, w13, w9
    2e28:      	add	w7, w21, w19
    2e2c:      	ldr	w9, [sp, #0x38]
    2e30:      	ror	w19, w15, #0x1b
    2e34:      	str	w10, [x8, #0x4]
    2e38:      	add	w8, w7, w17
    2e3c:      	ror	w15, w15, #0x2
    2e40:      	ldr	x7, [x0, #0xc0]
    2e44:      	add	w16, w16, w9
    2e48:      	add	w8, w8, w19
    2e4c:      	add	w16, w16, w20
    2e50:      	ror	w19, w8, #0x1b
    2e54:      	bic	w20, w1, w8
    2e58:      	ldr	w23, [x7, #0x3c]
    2e5c:      	ldr	w24, [x7, #0x28]
    2e60:      	ldr	w25, [x7, #0x10]
    2e64:      	ldr	w26, [x7, #0x8]
    2e68:      	and	w21, w15, w8
    2e6c:      	add	w16, w16, w17
    2e70:      	ldr	w9, [sp, #0x68]
    2e74:      	orr	w20, w21, w20
    2e78:      	add	w16, w16, w19
    2e7c:      	eor	w19, w24, w23
    2e80:      	eor	w21, w25, w26
    2e84:      	ror	w8, w8, #0x2
    2e88:      	add	w14, w14, w9
    2e8c:      	eor	w19, w19, w21
    2e90:      	str	w10, [sp, #0x4c]
    2e94:      	add	w20, w14, w20
    2e98:      	ror	w10, w19, #0x1f
    2e9c:      	ror	w19, w16, #0x1b
    2ea0:      	ldr	w9, [sp, #0x58]
    2ea4:      	bic	w23, w15, w16
    2ea8:      	and	w24, w8, w16
    2eac:      	add	w20, w20, w17
    2eb0:      	orr	w23, w24, w23
    2eb4:      	ror	w16, w16, #0x2
    2eb8:      	add	w1, w1, w9
    2ebc:      	add	w19, w20, w19
    2ec0:      	str	w10, [x7, #0x8]
    2ec4:      	add	w1, w1, w23
    2ec8:      	ror	w7, w19, #0x1b
    2ecc:      	ldr	x23, [x0, #0xc0]
    2ed0:      	ldr	w9, [sp, #0x70]
    2ed4:      	bic	w20, w8, w19
    2ed8:      	and	w21, w16, w19
    2edc:      	ror	w19, w19, #0x2
    2ee0:      	add	w1, w1, w17
    2ee4:      	orr	w20, w21, w20
    2ee8:      	add	w1, w1, w7
    2eec:      	add	w15, w15, w9
    2ef0:      	ldr	w24, [x23]
    2ef4:      	ldr	w25, [x23, #0x2c]
    2ef8:      	ldr	w26, [x23, #0x14]
    2efc:      	ldr	w27, [x23, #0xc]
    2f00:      	bic	w7, w16, w1
    2f04:      	and	w21, w19, w1
    2f08:      	add	w15, w15, w20
    2f0c:      	ror	w20, w1, #0x1b
    2f10:      	ldr	w9, [sp, #0x78]
    2f14:      	orr	w7, w21, w7
    2f18:      	eor	w21, w25, w24
    2f1c:      	eor	w24, w26, w27
    2f20:      	add	w15, w15, w17
    2f24:      	add	w20, w15, w20
    2f28:      	add	w8, w8, w9
    2f2c:      	eor	w15, w21, w24
    2f30:      	add	w8, w8, w7
    2f34:      	ror	w9, w15, #0x1f
    2f38:      	ror	w7, w20, #0x1b
    2f3c:      	ror	w1, w1, #0x2
    2f40:      	add	w8, w8, w17
    2f44:      	bic	w21, w19, w20
    2f48:      	add	w8, w8, w7
    2f4c:      	str	w9, [x23, #0xc]
    2f50:      	ror	w7, w20, #0x2
    2f54:      	and	w20, w1, w20
    2f58:      	ldr	x23, [x0, #0xc0]
    2f5c:      	str	w9, [sp, #0x78]
    2f60:      	orr	w20, w20, w21
    2f64:      	bic	w21, w1, w8
    2f68:      	and	w24, w7, w8
    2f6c:      	add	w16, w16, w20
    2f70:      	orr	w20, w24, w21
    2f74:      	ldr	w21, [x23, #0x4]
    2f78:      	ldr	w24, [x23, #0x30]
    2f7c:      	ldr	w25, [x23, #0x18]
    2f80:      	ldr	w26, [x23, #0x10]
    2f84:      	ldr	w9, [sp, #0x84]
    2f88:      	add	w19, w19, w20
    2f8c:      	str	w10, [sp, #0x68]
    2f90:      	eor	w20, w24, w21
    2f94:      	eor	w21, w25, w26
    2f98:      	ror	w24, w8, #0x1b
    2f9c:      	add	w16, w16, w9
    2fa0:      	ror	w9, w8, #0x2
    2fa4:      	ldr	w8, [sp, #0x7c]
    2fa8:      	eor	w20, w20, w21
    2fac:      	add	w16, w16, w17
    2fb0:      	ldr	w10, [sp, #0x6c]
    2fb4:      	add	w21, w16, w24
    2fb8:      	add	w24, w19, w8
    2fbc:      	ror	w8, w20, #0x1f
    2fc0:      	ror	w20, w21, #0x1b
    2fc4:      	bic	w19, w7, w21
    2fc8:      	and	w25, w9, w21
    2fcc:      	orr	w25, w25, w19
    2fd0:      	ror	w19, w21, #0x2
    2fd4:      	add	w21, w24, w17
    2fd8:      	str	w8, [x23, #0x10]
    2fdc:      	add	w20, w21, w20
    2fe0:      	add	w1, w1, w25
    2fe4:      	str	w8, [sp, #0x84]
    2fe8:      	ldr	x24, [x0, #0xc0]
    2fec:      	ldr	w8, [sp, #0x80]
    2ff0:      	bic	w21, w9, w20
    2ff4:      	and	w23, w19, w20
    2ff8:      	mov	w14, #0xeba1            // =60321
    2ffc:      	orr	w21, w23, w21
    3000:      	add	w1, w1, w8
    3004:      	ror	w23, w20, #0x1b
    3008:      	ldr	w25, [x24, #0x8]
    300c:      	ldr	w26, [x24, #0x34]
    3010:      	ldr	w27, [x24, #0x1c]
    3014:      	ldr	w8, [x24, #0x14]
    3018:      	add	w1, w1, w17
    301c:      	ror	w20, w20, #0x2
    3020:      	add	w7, w7, w21
    3024:      	add	w1, w1, w23
    3028:      	eor	w21, w26, w25
    302c:      	eor	w8, w27, w8
    3030:      	add	w7, w7, w10
    3034:      	ror	w23, w1, #0x1b
    3038:      	eor	w8, w21, w8
    303c:      	eor	w21, w20, w19
    3040:      	add	w17, w7, w17
    3044:      	eor	w21, w21, w1
    3048:      	ror	w16, w8, #0x1f
    304c:      	ldr	w10, [sp, #0x60]
    3050:      	add	w8, w9, w21
    3054:      	add	w9, w17, w23
    3058:      	ror	w1, w1, #0x2
    305c:      	add	w17, w8, w10
    3060:      	str	w16, [x24, #0x14]
    3064:      	movk	w14, #0x6ed9, lsl #16
    3068:      	ror	w21, w9, #0x1b
    306c:      	ror	w23, w9, #0x2
    3070:      	add	w17, w17, w14
    3074:      	eor	w24, w1, w20
    3078:      	ldr	x25, [x0, #0xc0]
    307c:      	ldr	w8, [sp, #0x74]
    3080:      	eor	w9, w24, w9
    3084:      	add	w17, w17, w21
    3088:      	eor	w21, w23, w1
    308c:      	add	w9, w19, w9
    3090:      	eor	w19, w21, w17
    3094:      	ldr	w21, [x25, #0xc]
    3098:      	ldr	w24, [x25, #0x38]
    309c:      	ldr	w26, [x25, #0x20]
    30a0:      	ldr	w27, [x25, #0x18]
    30a4:      	add	w19, w20, w19
    30a8:      	add	w9, w9, w8
    30ac:      	ldr	w8, [sp, #0x5c]
    30b0:      	eor	w20, w24, w21
    30b4:      	ror	w24, w17, #0x1b
    30b8:      	eor	w21, w26, w27
    30bc:      	ror	w17, w17, #0x2
    30c0:      	add	w9, w9, w14
    30c4:      	eor	w20, w20, w21
    30c8:      	add	w9, w9, w24
    30cc:      	add	w21, w19, w8
    30d0:      	ror	w15, w20, #0x1f
    30d4:      	eor	w20, w17, w23
    30d8:      	ror	w24, w9, #0x1b
    30dc:      	ror	w26, w9, #0x2
    30e0:      	eor	w9, w20, w9
    30e4:      	add	w20, w21, w14
    30e8:      	str	w15, [x25, #0x18]
    30ec:      	add	w20, w20, w24
    30f0:      	eor	w21, w26, w17
    30f4:      	add	w9, w1, w9
    30f8:      	eor	w1, w21, w20
    30fc:      	ldr	x21, [x0, #0xc0]
    3100:      	ldr	w8, [sp, #0x64]
    3104:      	add	w1, w23, w1
    3108:      	ror	w23, w20, #0x1b
    310c:      	ror	w20, w20, #0x2
    3110:      	add	w9, w9, w8
    3114:      	ldr	w24, [x21, #0x10]
    3118:      	ldr	w25, [x21, #0x3c]
    311c:      	ldr	w27, [x21, #0x24]
    3120:      	ldr	w8, [x21, #0x1c]
    3124:      	add	w9, w9, w14
    3128:      	ldr	w10, [sp, #0x50]
    312c:      	add	w9, w9, w23
    3130:      	eor	w23, w25, w24
    3134:      	eor	w8, w27, w8
    3138:      	eor	w24, w20, w26
    313c:      	ldr	w13, [sp, #0x3c]
    3140:      	add	w1, w1, w10
    3144:      	eor	w8, w23, w8
    3148:      	eor	w23, w24, w9
    314c:      	ldr	w10, [sp, #0x44]
    3150:      	ror	w24, w9, #0x1b
    3154:      	add	w17, w17, w23
    3158:      	ror	w30, w8, #0x1f
    315c:      	add	w1, w1, w14
    3160:      	add	w17, w17, w10
    3164:      	ror	w10, w9, #0x2
    3168:      	add	w8, w1, w24
    316c:      	str	w30, [x21, #0x1c]
    3170:      	ror	w1, w8, #0x1b
    3174:      	ror	w21, w8, #0x2
    3178:      	eor	w23, w10, w20
    317c:      	ldr	x24, [x0, #0xc0]
    3180:      	add	w17, w17, w14
    3184:      	eor	w8, w23, w8
    3188:      	add	w17, w17, w1
    318c:      	eor	w1, w21, w10
    3190:      	add	w9, w26, w8
    3194:      	ldr	w23, [x24, #0x14]
    3198:      	ldr	w26, [x24]
    319c:      	eor	w1, w1, w17
    31a0:      	ldr	w27, [x24, #0x28]
    31a4:      	ldr	w8, [x24, #0x20]
    31a8:      	add	w1, w20, w1
    31ac:      	add	w9, w9, w11
    31b0:      	eor	w20, w26, w23
    31b4:      	ror	w23, w17, #0x1b
    31b8:      	eor	w8, w27, w8
    31bc:      	ror	w17, w17, #0x2
    31c0:      	add	w9, w9, w14
    31c4:      	ldr	w11, [sp, #0x40]
    31c8:      	eor	w8, w20, w8
    31cc:      	add	w9, w9, w23
    31d0:      	ror	w26, w8, #0x1f
    31d4:      	eor	w8, w17, w21
    31d8:      	add	w1, w1, w11
    31dc:      	ror	w20, w9, #0x1b
    31e0:      	ror	w27, w9, #0x2
    31e4:      	eor	w8, w8, w9
    31e8:      	add	w9, w1, w14
    31ec:      	str	w26, [x24, #0x20]
    31f0:      	add	w9, w9, w20
    31f4:      	eor	w1, w27, w17
    31f8:      	ldr	w11, [sp, #0x48]
    31fc:      	add	w8, w10, w8
    3200:      	eor	w10, w1, w9
    3204:      	ldr	x1, [x0, #0xc0]
    3208:      	add	w8, w8, w11
    320c:      	add	w10, w21, w10
    3210:      	ror	w20, w9, #0x1b
    3214:      	ror	w12, w9, #0x2
    3218:      	add	w9, w8, w14
    321c:      	ldr	w21, [x1, #0x18]
    3220:      	ldr	w23, [x1, #0x4]
    3224:      	ldr	w24, [x1, #0x2c]
    3228:      	ldr	w8, [x1, #0x24]
    322c:      	ldr	w11, [sp, #0x34]
    3230:      	add	w9, w9, w20
    3234:      	eor	w20, w23, w21
    3238:      	eor	w8, w24, w8
    323c:      	eor	w21, w12, w27
    3240:      	add	w10, w10, w11
    3244:      	eor	w8, w20, w8
    3248:      	eor	w20, w21, w9
    324c:      	ror	w21, w9, #0x1b
    3250:      	add	w10, w10, w14
    3254:      	ror	w25, w8, #0x1f
    3258:      	add	w17, w17, w20
    325c:      	ror	w11, w9, #0x2
    3260:      	add	w8, w10, w21
    3264:      	ldr	w10, [sp, #0x24]
    3268:      	str	w25, [x1, #0x24]
    326c:      	ror	w1, w8, #0x2
    3270:      	ldr	x21, [x0, #0xc0]
    3274:      	eor	w20, w11, w12
    3278:      	add	w10, w17, w10
    327c:      	ror	w17, w8, #0x1b
    3280:      	eor	w8, w20, w8
    3284:      	add	w10, w10, w14
    3288:      	ldr	w20, [x21, #0x1c]
    328c:      	ldr	w24, [x21, #0x8]
    3290:      	add	w10, w10, w17
    3294:      	eor	w17, w1, w11
    3298:      	add	w9, w27, w8
    329c:      	eor	w17, w17, w10
    32a0:      	ldr	w27, [x21, #0x30]
    32a4:      	ldr	w8, [x21, #0x28]
    32a8:      	add	w12, w12, w17
    32ac:      	add	w9, w9, w13
    32b0:      	eor	w17, w24, w20
    32b4:      	ror	w20, w10, #0x1b
    32b8:      	eor	w8, w27, w8
    32bc:      	ror	w10, w10, #0x2
    32c0:      	add	w9, w9, w14
    32c4:      	ldr	w13, [sp, #0x20]
    32c8:      	eor	w8, w17, w8
    32cc:      	add	w9, w9, w20
    32d0:      	ror	w27, w8, #0x1f
    32d4:      	eor	w8, w10, w1
    32d8:      	add	w12, w12, w13
    32dc:      	ror	w17, w9, #0x1b
    32e0:      	ror	w20, w9, #0x2
    32e4:      	eor	w8, w8, w9
    32e8:      	add	w9, w12, w14
    32ec:      	str	w27, [x21, #0x28]
    32f0:      	add	w9, w9, w17
    32f4:      	eor	w12, w20, w10
    32f8:      	add	w8, w11, w8
    32fc:      	eor	w11, w12, w9
    3300:      	ldr	x12, [x0, #0xc0]
    3304:      	ror	w17, w9, #0x1b
    3308:      	add	w13, w1, w11
    330c:      	ldr	w11, [sp, #0x30]
    3310:      	ldr	w1, [x12, #0x20]
    3314:      	ldr	w21, [x12, #0xc]
    3318:      	ldr	w24, [x12, #0x34]
    331c:      	add	w8, w8, w11
    3320:      	ror	w11, w9, #0x2
    3324:      	add	w9, w8, w14
    3328:      	ldr	w8, [x12, #0x2c]
    332c:      	add	w9, w9, w17
    3330:      	ldr	w17, [sp, #0x1c]
    3334:      	eor	w8, w24, w8
    3338:      	add	w13, w13, w17
    333c:      	eor	w17, w21, w1
    3340:      	eor	w1, w11, w20
    3344:      	eor	w8, w17, w8
    3348:      	eor	w17, w1, w9
    334c:      	ror	w1, w9, #0x1b
    3350:      	add	w13, w13, w14
    3354:      	ror	w24, w8, #0x1f
    3358:      	add	w10, w10, w17
    335c:      	add	w8, w13, w1
    3360:      	add	w10, w10, w28
    3364:      	ror	w9, w9, #0x2
    3368:      	str	w24, [x12, #0x2c]
    336c:      	ror	w12, w8, #0x1b
    3370:      	ror	w13, w8, #0x2
    3374:      	add	w10, w10, w14
    3378:      	eor	w17, w9, w11
    337c:      	ldr	x1, [x0, #0xc0]
    3380:      	add	w10, w10, w12
    3384:      	eor	w12, w13, w9
    3388:      	eor	w8, w17, w8
    338c:      	eor	w12, w12, w10
    3390:      	add	w8, w20, w8
    3394:      	ldr	w17, [x1, #0x24]
    3398:      	ldr	w20, [x1, #0x10]
    339c:      	add	w11, w11, w12
    33a0:      	ldr	w12, [sp, #0x18]
    33a4:      	ldr	w21, [x1, #0x38]
    33a8:      	ldr	w28, [x1, #0x30]
    33ac:      	add	w8, w8, w12
    33b0:      	eor	w12, w20, w17
    33b4:      	ror	w20, w10, #0x1b
    33b8:      	eor	w17, w21, w28
    33bc:      	add	w8, w8, w14
    33c0:      	ror	w28, w10, #0x2
    33c4:      	eor	w12, w12, w17
    33c8:      	add	w8, w8, w20
    33cc:      	add	w10, w11, w5
    33d0:      	ror	w23, w12, #0x1f
    33d4:      	ror	w12, w8, #0x1b
    33d8:      	ror	w17, w8, #0x2
    33dc:      	eor	w11, w28, w13
    33e0:      	add	w10, w10, w14
    33e4:      	eor	w8, w11, w8
    33e8:      	add	w10, w10, w12
    33ec:      	str	w23, [x1, #0x30]
    33f0:      	eor	w11, w17, w28
    33f4:      	add	w8, w9, w8
    33f8:      	ror	w12, w10, #0x1b
    33fc:      	eor	w9, w11, w10
    3400:      	ldr	x11, [x0, #0xc0]
    3404:      	add	w8, w8, w29
    3408:      	add	w9, w13, w9
    340c:      	add	w8, w8, w14
    3410:      	ror	w29, w10, #0x2
    3414:      	ldr	w13, [x11, #0x28]
    3418:      	ldr	w1, [x11, #0x14]
    341c:      	ldr	w20, [x11, #0x3c]
    3420:      	ldr	w21, [x11, #0x34]
    3424:      	add	w8, w8, w12
    3428:      	add	w9, w9, w2
    342c:      	eor	w12, w1, w13
    3430:      	ror	w10, w8, #0x1b
    3434:      	add	w9, w9, w14
    3438:      	eor	w13, w20, w21
    343c:      	ror	w20, w8, #0x2
    3440:      	mov	w2, #0xbcdc             // =48348
    3444:      	eor	w12, w12, w13
    3448:      	orr	w13, w8, w29
    344c:      	add	w9, w9, w10
    3450:      	ror	w19, w12, #0x1f
    3454:      	and	w8, w8, w29
    3458:      	and	w10, w13, w17
    345c:      	orr	w8, w10, w8
    3460:      	orr	w10, w9, w20
    3464:      	movk	w2, #0x8f1b, lsl #16
    3468:      	str	w19, [x11, #0x34]
    346c:      	and	w11, w9, w20
    3470:      	and	w10, w10, w29
    3474:      	ldr	x12, [x0, #0xc0]
    3478:      	orr	w10, w10, w11
    347c:      	add	w8, w28, w8
    3480:      	add	w10, w17, w10
    3484:      	ror	w11, w9, #0x1b
    3488:      	add	w8, w8, w22
    348c:      	ldr	w13, [x12, #0x2c]
    3490:      	ldr	w14, [x12, #0x18]
    3494:      	ldr	w17, [x12]
    3498:      	ldr	w1, [x12, #0x38]
    349c:      	add	w11, w8, w11
    34a0:      	ror	w22, w9, #0x2
    34a4:      	eor	w13, w14, w13
    34a8:      	add	w9, w11, w2
    34ac:      	add	w10, w10, w3
    34b0:      	eor	w14, w17, w1
    34b4:      	ror	w11, w9, #0x1b
    34b8:      	add	w10, w10, w2
    34bc:      	eor	w13, w13, w14
    34c0:      	ror	w21, w9, #0x2
    34c4:      	ldr	w8, [sp, #0x14]
    34c8:      	ror	w7, w13, #0x1f
    34cc:      	orr	w13, w9, w22
    34d0:      	add	w10, w10, w11
    34d4:      	and	w9, w9, w22
    34d8:      	and	w11, w13, w20
    34dc:      	ror	w13, w10, #0x1b
    34e0:      	str	w7, [x12, #0x38]
    34e4:      	orr	w9, w11, w9
    34e8:      	orr	w11, w10, w21
    34ec:      	ldr	x12, [x0, #0xc0]
    34f0:      	add	w9, w29, w9
    34f4:      	and	w11, w11, w22
    34f8:      	add	w9, w9, w8
    34fc:      	and	w1, w10, w21
    3500:      	ror	w10, w10, #0x2
    3504:      	ldr	w14, [x12, #0x30]
    3508:      	ldr	w17, [x12, #0x1c]
    350c:      	ldr	w28, [x12, #0x4]
    3510:      	ldr	w29, [x12, #0x3c]
    3514:      	add	w9, w9, w13
    3518:      	orr	w11, w11, w1
    351c:      	eor	w13, w17, w14
    3520:      	add	w9, w9, w2
    3524:      	add	w11, w20, w11
    3528:      	eor	w14, w28, w29
    352c:      	ror	w1, w9, #0x1b
    3530:      	add	w11, w11, w6
    3534:      	eor	w13, w13, w14
    3538:      	orr	w14, w9, w10
    353c:      	ror	w20, w9, #0x2
    3540:      	ror	w17, w13, #0x1f
    3544:      	and	w13, w9, w10
    3548:      	add	w9, w11, w2
    354c:      	and	w11, w14, w21
    3550:      	add	w9, w9, w1
    3554:      	ldr	w8, [sp, #0x10]
    3558:      	str	w17, [x12, #0x3c]
    355c:      	orr	w11, w11, w13
    3560:      	ror	w14, w9, #0x1b
    3564:      	ldr	x13, [x0, #0xc0]
    3568:      	add	w11, w22, w11
    356c:      	orr	w12, w9, w20
    3570:      	add	w11, w11, w4
    3574:      	and	w12, w12, w10
    3578:      	and	w6, w9, w20
    357c:      	ldr	w1, [x13, #0x34]
    3580:      	ldr	w4, [x13, #0x20]
    3584:      	ldr	w22, [x13, #0x8]
    3588:      	ldr	w29, [x13]
    358c:      	add	w11, w11, w14
    3590:      	ror	w28, w9, #0x2
    3594:      	eor	w14, w4, w1
    3598:      	add	w9, w11, w2
    359c:      	orr	w12, w12, w6
    35a0:      	eor	w11, w22, w29
    35a4:      	add	w12, w21, w12
    35a8:      	ror	w1, w9, #0x1b
    35ac:      	eor	w11, w14, w11
    35b0:      	orr	w14, w9, w28
    35b4:      	and	w21, w9, w28
    35b8:      	ror	w5, w11, #0x1f
    35bc:      	ror	w6, w9, #0x2
    35c0:      	and	w9, w14, w20
    35c4:      	add	w11, w12, w8
    35c8:      	orr	w9, w9, w21
    35cc:      	ldr	w8, [sp, #0xc]
    35d0:      	add	w11, w11, w2
    35d4:      	str	w5, [x13]
    35d8:      	add	w9, w10, w9
    35dc:      	add	w10, w11, w1
    35e0:      	ldr	x11, [x0, #0xc0]
    35e4:      	add	w9, w9, w8
    35e8:      	ror	w12, w10, #0x1b
    35ec:      	orr	w13, w10, w6
    35f0:      	and	w14, w10, w6
    35f4:      	ldr	w1, [x11, #0x38]
    35f8:      	ldr	w21, [x11, #0x24]
    35fc:      	ldr	w29, [x11, #0xc]
    3600:      	ldr	w8, [x11, #0x4]
    3604:      	and	w13, w13, w28
    3608:      	add	w9, w9, w12
    360c:      	orr	w13, w13, w14
    3610:      	ror	w22, w10, #0x2
    3614:      	eor	w10, w21, w1
    3618:      	eor	w8, w29, w8
    361c:      	add	w12, w20, w13
    3620:      	add	w13, w9, w2
    3624:      	eor	w8, w10, w8
    3628:      	ldr	w9, [sp, #0x8]
    362c:      	ror	w10, w13, #0x1b
    3630:      	ror	w4, w8, #0x1f
    3634:      	orr	w14, w13, w22
    3638:      	ror	w20, w13, #0x2
    363c:      	add	w12, w12, w9
    3640:      	and	w8, w13, w22
    3644:      	and	w13, w14, w6
    3648:      	add	w12, w12, w2
    364c:      	str	w4, [x11, #0x4]
    3650:      	orr	w8, w13, w8
    3654:      	add	w10, w12, w10
    3658:      	ldr	x11, [x0, #0xc0]
    365c:      	ldr	w9, [sp, #0x2c]
    3660:      	orr	w13, w10, w20
    3664:      	add	w8, w28, w8
    3668:      	ror	w12, w10, #0x1b
    366c:      	and	w14, w10, w20
    3670:      	and	w13, w13, w22
    3674:      	ldr	w1, [x11, #0x3c]
    3678:      	ldr	w28, [x11, #0x28]
    367c:      	ldr	w29, [x11, #0x10]
    3680:      	ldr	w21, [x11, #0x8]
    3684:      	orr	w13, w13, w14
    3688:      	add	w14, w8, w9
    368c:      	ror	w9, w10, #0x2
    3690:      	add	w10, w14, w12
    3694:      	eor	w12, w28, w1
    3698:      	eor	w14, w29, w21
    369c:      	add	w1, w10, w2
    36a0:      	eor	w10, w12, w14
    36a4:      	ldr	w8, [sp, #0x4c]
    36a8:      	add	w13, w6, w13
    36ac:      	ror	w3, w10, #0x1f
    36b0:      	ror	w14, w1, #0x1b
    36b4:      	add	w13, w13, w8
    36b8:      	orr	w6, w1, w9
    36bc:      	and	w21, w1, w9
    36c0:      	add	w13, w13, w2
    36c4:      	str	w3, [x11, #0x8]
    36c8:      	ror	w12, w1, #0x2
    36cc:      	and	w1, w6, w20
    36d0:      	add	w13, w13, w14
    36d4:      	ldr	x14, [x0, #0xc0]
    36d8:      	orr	w11, w1, w21
    36dc:      	ldr	w10, [sp, #0x68]
    36e0:      	ror	w1, w13, #0x1b
    36e4:      	add	w11, w22, w11
    36e8:      	orr	w6, w13, w12
    36ec:      	ldr	w22, [x14]
    36f0:      	ldr	w28, [x14, #0x2c]
    36f4:      	ldr	w29, [x14, #0x14]
    36f8:      	ldr	w8, [x14, #0xc]
    36fc:      	and	w21, w13, w12
    3700:      	and	w6, w6, w9
    3704:      	add	w11, w11, w10
    3708:      	orr	w21, w6, w21
    370c:      	ror	w6, w13, #0x2
    3710:      	add	w11, w11, w1
    3714:      	eor	w13, w28, w22
    3718:      	eor	w8, w29, w8
    371c:      	ldr	w10, [sp, #0x78]
    3720:      	add	w1, w20, w21
    3724:      	add	w20, w11, w2
    3728:      	eor	w8, w13, w8
    372c:      	ror	w21, w20, #0x1b
    3730:      	ror	w11, w8, #0x1f
    3734:      	add	w1, w1, w10
    3738:      	orr	w22, w20, w6
    373c:      	ror	w13, w20, #0x2
    3740:      	add	w1, w1, w2
    3744:      	and	w8, w20, w6
    3748:      	and	w20, w22, w12
    374c:      	str	w11, [x14, #0xc]
    3750:      	add	w14, w1, w21
    3754:      	orr	w8, w20, w8
    3758:      	ldr	x1, [x0, #0xc0]
    375c:      	orr	w20, w14, w13
    3760:      	and	w21, w14, w13
    3764:      	add	w10, w9, w8
    3768:      	and	w20, w20, w6
    376c:      	ror	w9, w14, #0x1b
    3770:      	ldr	w22, [x1, #0x4]
    3774:      	orr	w21, w20, w21
    3778:      	ror	w20, w14, #0x2
    377c:      	ldr	w14, [sp, #0x84]
    3780:      	ldr	w28, [x1, #0x30]
    3784:      	ldr	w29, [x1, #0x18]
    3788:      	ldr	w8, [x1, #0x10]
    378c:      	add	w10, w10, w14
    3790:      	add	w21, w12, w21
    3794:      	add	w9, w10, w9
    3798:      	eor	w10, w28, w22
    379c:      	eor	w8, w29, w8
    37a0:      	eor	w8, w10, w8
    37a4:      	add	w9, w9, w2
    37a8:      	ror	w12, w8, #0x1f
    37ac:      	ror	w10, w9, #0x1b
    37b0:      	orr	w22, w9, w20
    37b4:      	and	w8, w9, w20
    37b8:      	ror	w14, w9, #0x2
    37bc:      	add	w9, w21, w16
    37c0:      	add	w9, w9, w2
    37c4:      	str	w12, [x1, #0x10]
    37c8:      	and	w16, w22, w13
    37cc:      	add	w9, w9, w10
    37d0:      	ldr	x10, [x0, #0xc0]
    37d4:      	orr	w8, w16, w8
    37d8:      	add	w8, w6, w8
    37dc:      	ror	w16, w9, #0x1b
    37e0:      	orr	w1, w9, w14
    37e4:      	ldr	w21, [x10, #0x8]
    37e8:      	ldr	w22, [x10, #0x34]
    37ec:      	ldr	w28, [x10, #0x1c]
    37f0:      	ldr	w29, [x10, #0x14]
    37f4:      	add	w8, w8, w15
    37f8:      	and	w6, w9, w14
    37fc:      	and	w1, w1, w20
    3800:      	ror	w15, w9, #0x2
    3804:      	add	w8, w8, w16
    3808:      	eor	w9, w22, w21
    380c:      	eor	w16, w28, w29
    3810:      	orr	w1, w1, w6
    3814:      	eor	w9, w9, w16
    3818:      	add	w1, w13, w1
    381c:      	add	w8, w8, w2
    3820:      	ror	w13, w9, #0x1f
    3824:      	orr	w21, w8, w15
    3828:      	ror	w6, w8, #0x1b
    382c:      	and	w9, w8, w15
    3830:      	ror	w16, w8, #0x2
    3834:      	add	w8, w1, w30
    3838:      	and	w1, w21, w14
    383c:      	str	w13, [x10, #0x14]
    3840:      	add	w8, w8, w2
    3844:      	orr	w9, w1, w9
    3848:      	ldr	x10, [x0, #0xc0]
    384c:      	add	w8, w8, w6
    3850:      	add	w9, w20, w9
    3854:      	ror	w1, w8, #0x1b
    3858:      	orr	w20, w8, w16
    385c:      	add	w9, w9, w26
    3860:      	ldr	w21, [x10, #0xc]
    3864:      	ldr	w22, [x10, #0x38]
    3868:      	ldr	w26, [x10, #0x20]
    386c:      	ldr	w28, [x10, #0x18]
    3870:      	and	w29, w8, w16
    3874:      	ror	w6, w8, #0x2
    3878:      	and	w8, w20, w15
    387c:      	add	w9, w9, w1
    3880:      	eor	w1, w22, w21
    3884:      	eor	w20, w26, w28
    3888:      	orr	w8, w8, w29
    388c:      	eor	w1, w1, w20
    3890:      	add	w9, w9, w2
    3894:      	add	w8, w14, w8
    3898:      	ror	w14, w1, #0x1f
    389c:      	ror	w20, w9, #0x1b
    38a0:      	add	w8, w8, w25
    38a4:      	orr	w1, w9, w6
    38a8:      	and	w21, w9, w6
    38ac:      	ror	w9, w9, #0x2
    38b0:      	add	w8, w8, w2
    38b4:      	str	w14, [x10, #0x18]
    38b8:      	and	w10, w1, w16
    38bc:      	add	w8, w8, w20
    38c0:      	ldr	x1, [x0, #0xc0]
    38c4:      	orr	w10, w10, w21
    38c8:      	orr	w20, w8, w9
    38cc:      	and	w21, w8, w9
    38d0:      	add	w10, w15, w10
    38d4:      	and	w20, w20, w6
    38d8:      	ldr	w22, [x1, #0x10]
    38dc:      	ldr	w25, [x1, #0x3c]
    38e0:      	ldr	w26, [x1, #0x24]
    38e4:      	ldr	w28, [x1, #0x1c]
    38e8:      	orr	w15, w20, w21
    38ec:      	ror	w20, w8, #0x1b
    38f0:      	add	w10, w10, w27
    38f4:      	eor	w21, w25, w22
    38f8:      	eor	w22, w26, w28
    38fc:      	ror	w25, w8, #0x2
    3900:      	add	w16, w16, w15
    3904:      	add	w8, w10, w20
    3908:      	eor	w10, w21, w22
    390c:      	add	w16, w16, w24
    3910:      	add	w20, w8, w2
    3914:      	ror	w15, w10, #0x1f
    3918:      	add	w16, w16, w2
    391c:      	ror	w8, w20, #0x1b
    3920:      	ror	w10, w20, #0x2
    3924:      	eor	w21, w25, w9
    3928:      	str	w15, [x1, #0x1c]
    392c:      	eor	w20, w21, w20
    3930:      	eor	w1, w10, w25
    3934:      	add	w16, w16, w8
    3938:      	ldr	x2, [x0, #0xc0]
    393c:      	eor	w1, w1, w16
    3940:      	mov	w8, #0xc1d6             // =49622
    3944:      	add	w6, w6, w20
    3948:      	add	w9, w9, w1
    394c:      	ldr	w1, [x2, #0x14]
    3950:      	ldr	w20, [x2]
    3954:      	ldr	w21, [x2, #0x28]
    3958:      	ldr	w22, [x2, #0x20]
    395c:      	movk	w8, #0xca62, lsl #16
    3960:      	add	w6, w6, w23
    3964:      	ror	w23, w16, #0x1b
    3968:      	ror	w24, w16, #0x2
    396c:      	eor	w16, w20, w1
    3970:      	add	w1, w6, w8
    3974:      	eor	w6, w21, w22
    3978:      	eor	w16, w16, w6
    397c:      	eor	w20, w24, w10
    3980:      	add	w1, w1, w23
    3984:      	ror	w16, w16, #0x1f
    3988:      	ror	w6, w1, #0x1b
    398c:      	add	w9, w9, w19
    3990:      	eor	w19, w20, w1
    3994:      	ror	w1, w1, #0x2
    3998:      	add	w9, w9, w8
    399c:      	str	w16, [x2, #0x20]
    39a0:      	add	w19, w25, w19
    39a4:      	add	w9, w9, w6
    39a8:      	eor	w2, w1, w24
    39ac:      	ldr	x20, [x0, #0xc0]
    39b0:      	add	w7, w19, w7
    39b4:      	eor	w2, w2, w9
    39b8:      	ror	w6, w9, #0x1b
    39bc:      	ror	w9, w9, #0x2
    39c0:      	add	w10, w10, w2
    39c4:      	add	w2, w7, w8
    39c8:      	ldr	w7, [x20, #0x18]
    39cc:      	ldr	w19, [x20, #0x4]
    39d0:      	ldr	w21, [x20, #0x2c]
    39d4:      	ldr	w22, [x20, #0x24]
    39d8:      	add	w10, w10, w17
    39dc:      	add	w2, w2, w6
    39e0:      	eor	w6, w9, w1
    39e4:      	eor	w17, w19, w7
    39e8:      	eor	w7, w21, w22
    39ec:      	ror	w19, w2, #0x1b
    39f0:      	eor	w17, w17, w7
    39f4:      	ror	w7, w2, #0x2
    39f8:      	eor	w2, w6, w2
    39fc:      	ror	w17, w17, #0x1f
    3a00:      	add	w10, w10, w8
    3a04:      	add	w6, w24, w2
    3a08:      	eor	w21, w7, w9
    3a0c:      	add	w10, w10, w19
    3a10:      	add	w5, w6, w5
    3a14:      	str	w17, [x20, #0x24]
    3a18:      	ror	w19, w10, #0x1b
    3a1c:      	ror	w2, w10, #0x2
    3a20:      	eor	w10, w21, w10
    3a24:      	ldr	x6, [x0, #0xc0]
    3a28:      	add	w5, w5, w8
    3a2c:      	add	w10, w1, w10
    3a30:      	add	w5, w5, w19
    3a34:      	eor	w1, w2, w7
    3a38:      	ldr	w19, [x6, #0x1c]
    3a3c:      	ldr	w20, [x6, #0x8]
    3a40:      	add	w10, w10, w4
    3a44:      	ldr	w4, [x6, #0x30]
    3a48:      	ldr	w21, [x6, #0x28]
    3a4c:      	eor	w1, w1, w5
    3a50:      	eor	w19, w20, w19
    3a54:      	ror	w20, w5, #0x1b
    3a58:      	ror	w5, w5, #0x2
    3a5c:      	eor	w4, w4, w21
    3a60:      	add	w1, w9, w1
    3a64:      	add	w10, w10, w8
    3a68:      	eor	w9, w19, w4
    3a6c:      	add	w10, w10, w20
    3a70:      	eor	w4, w5, w2
    3a74:      	ror	w9, w9, #0x1f
    3a78:      	ror	w19, w10, #0x1b
    3a7c:      	eor	w4, w4, w10
    3a80:      	ror	w20, w10, #0x2
    3a84:      	add	w10, w1, w3
    3a88:      	add	w1, w7, w4
    3a8c:      	str	w9, [x6, #0x28]
    3a90:      	add	w10, w10, w8
    3a94:      	add	w11, w1, w11
    3a98:      	ldr	x4, [x0, #0xc0]
    3a9c:      	eor	w3, w20, w5
    3aa0:      	add	w10, w10, w19
    3aa4:      	ror	w6, w10, #0x1b
    3aa8:      	eor	w3, w3, w10
    3aac:      	ror	w1, w10, #0x2
    3ab0:      	add	w10, w11, w8
    3ab4:      	ldr	w11, [x4, #0x20]
    3ab8:      	ldr	w7, [x4, #0xc]
    3abc:      	ldr	w19, [x4, #0x34]
    3ac0:      	ldr	w21, [x4, #0x2c]
    3ac4:      	add	w2, w2, w3
    3ac8:      	eor	w11, w7, w11
    3acc:      	add	w10, w10, w6
    3ad0:      	eor	w6, w1, w20
    3ad4:      	eor	w3, w19, w21
    3ad8:      	eor	w6, w6, w10
    3adc:      	ror	w7, w10, #0x2
    3ae0:      	eor	w11, w11, w3
    3ae4:      	ror	w3, w10, #0x1b
    3ae8:      	add	w12, w2, w12
    3aec:      	ror	w10, w11, #0x1f
    3af0:      	add	w12, w12, w8
    3af4:      	add	w11, w5, w6
    3af8:      	add	w12, w12, w3
    3afc:      	add	w11, w11, w13
    3b00:      	eor	w2, w7, w1
    3b04:      	str	w10, [x4, #0x2c]
    3b08:      	ror	w3, w12, #0x1b
    3b0c:      	add	w11, w11, w8
    3b10:      	ldr	x4, [x0, #0xc0]
    3b14:      	eor	w2, w2, w12
    3b18:      	ror	w12, w12, #0x2
    3b1c:      	add	w11, w11, w3
    3b20:      	add	w2, w20, w2
    3b24:      	ldr	w13, [x4, #0x24]
    3b28:      	ldr	w5, [x4, #0x10]
    3b2c:      	ldr	w3, [x4, #0x38]
    3b30:      	ldr	w6, [x4, #0x30]
    3b34:      	add	w14, w2, w14
    3b38:      	eor	w2, w12, w7
    3b3c:      	eor	w13, w5, w13
    3b40:      	ror	w5, w11, #0x1b
    3b44:      	eor	w2, w2, w11
    3b48:      	eor	w3, w3, w6
    3b4c:      	ror	w6, w11, #0x2
    3b50:      	add	w11, w14, w8
    3b54:      	eor	w13, w13, w3
    3b58:      	add	w14, w1, w2
    3b5c:      	add	w1, w11, w5
    3b60:      	ror	w11, w13, #0x1f
    3b64:      	eor	w13, w6, w12
    3b68:      	ror	w2, w1, #0x1b
    3b6c:      	add	w14, w14, w15
    3b70:      	ror	w15, w1, #0x2
    3b74:      	eor	w13, w13, w1
    3b78:      	str	w11, [x4, #0x30]
    3b7c:      	add	w14, w14, w8
    3b80:      	add	w13, w7, w13
    3b84:      	ldr	x1, [x0, #0xc0]
    3b88:      	add	w14, w14, w2
    3b8c:      	eor	w2, w15, w6
    3b90:      	add	w13, w13, w16
    3b94:      	eor	w2, w2, w14
    3b98:      	ror	w3, w14, #0x1b
    3b9c:      	ldr	w16, [x1, #0x28]
    3ba0:      	ldr	w4, [x1, #0x14]
    3ba4:      	ldr	w5, [x1, #0x3c]
    3ba8:      	ldr	w7, [x1, #0x34]
    3bac:      	add	w12, w12, w2
    3bb0:      	ror	w14, w14, #0x2
    3bb4:      	eor	w16, w4, w16
    3bb8:      	add	w13, w13, w8
    3bbc:      	add	w17, w12, w17
    3bc0:      	eor	w2, w5, w7
    3bc4:      	add	w13, w13, w3
    3bc8:      	eor	w3, w14, w15
    3bcc:      	eor	w16, w16, w2
    3bd0:      	ror	w4, w13, #0x1b
    3bd4:      	ror	w2, w13, #0x2
    3bd8:      	ror	w12, w16, #0x1f
    3bdc:      	eor	w13, w3, w13
    3be0:      	add	w16, w17, w8
    3be4:      	eor	w17, w2, w14
    3be8:      	add	w16, w16, w4
    3bec:      	add	w13, w6, w13
    3bf0:      	str	w12, [x1, #0x34]
    3bf4:      	eor	w17, w17, w16
    3bf8:      	ror	w3, w16, #0x1b
    3bfc:      	ldr	x1, [x0, #0xc0]
    3c00:      	add	w9, w13, w9
    3c04:      	ror	w16, w16, #0x2
    3c08:      	add	w15, w15, w17
    3c0c:      	add	w9, w9, w8
    3c10:      	ldr	w13, [x1, #0x2c]
    3c14:      	ldr	w17, [x1, #0x18]
    3c18:      	ldr	w4, [x1]
    3c1c:      	ldr	w5, [x1, #0x38]
    3c20:      	add	w9, w9, w3
    3c24:      	add	w10, w15, w10
    3c28:      	eor	w13, w17, w13
    3c2c:      	eor	w15, w16, w2
    3c30:      	ror	w3, w9, #0x1b
    3c34:      	eor	w17, w4, w5
    3c38:      	eor	w15, w15, w9
    3c3c:      	add	w10, w10, w8
    3c40:      	eor	w13, w13, w17
    3c44:      	ror	w9, w9, #0x2
    3c48:      	add	w14, w14, w15
    3c4c:      	add	w10, w10, w3
    3c50:      	ror	w13, w13, #0x1f
    3c54:      	add	w11, w14, w11
    3c58:      	ror	w17, w10, #0x1b
    3c5c:      	eor	w15, w9, w16
    3c60:      	add	w11, w11, w8
    3c64:      	str	w13, [x1, #0x38]
    3c68:      	eor	w15, w15, w10
    3c6c:      	ror	w10, w10, #0x2
    3c70:      	add	w11, w11, w17
    3c74:      	ldr	x17, [x0, #0xc0]
    3c78:      	add	w14, w2, w15
    3c7c:      	eor	w15, w10, w9
    3c80:      	ror	w0, w11, #0x1b
    3c84:      	add	w12, w14, w12
    3c88:      	ldr	w14, [x17, #0x30]
    3c8c:      	ldr	w1, [x17, #0x1c]
    3c90:      	ldr	w2, [x17, #0x4]
    3c94:      	ldr	w3, [x17, #0x3c]
    3c98:      	eor	w15, w15, w11
    3c9c:      	ror	w11, w11, #0x2
    3ca0:      	add	w12, w12, w8
    3ca4:      	add	w15, w16, w15
    3ca8:      	eor	w14, w1, w14
    3cac:      	add	w12, w12, w0
    3cb0:      	eor	w0, w2, w3
    3cb4:      	eor	w16, w11, w10
    3cb8:      	ror	w1, w12, #0x1b
    3cbc:      	add	w13, w15, w13
    3cc0:      	eor	w14, w14, w0
    3cc4:      	eor	w15, w16, w12
    3cc8:      	add	w13, w13, w8
    3ccc:      	ror	w14, w14, #0x1f
    3cd0:      	add	w9, w9, w15
    3cd4:      	add	w13, w13, w1
    3cd8:      	ror	w15, w13, #0x1b
    3cdc:      	add	w9, w9, w14
    3ce0:      	str	w14, [x17, #0x3c]
    3ce4:      	add	w8, w9, w8
    3ce8:      	ldr	x9, [sp, #0x88]
    3cec:      	add	w8, w8, w15
    3cf0:      	ldp	x20, x19, [sp, #0xe0]
    3cf4:      	fmov	s0, w8
    3cf8:      	ror	w8, w12, #0x2
    3cfc:      	ldr	q1, [x9]
    3d00:      	ldp	x22, x21, [sp, #0xd0]
    3d04:      	ldp	x24, x23, [sp, #0xc0]
    3d08:      	mov	v0.s[1], w13
    3d0c:      	ldp	x26, x25, [sp, #0xb0]
    3d10:      	ldp	x28, x27, [sp, #0xa0]
    3d14:      	ldp	x29, x30, [sp, #0x90]
    3d18:      	mov	v0.s[2], w8
    3d1c:      	ldr	w8, [x9, #0x10]
    3d20:      	add	w8, w8, w10
    3d24:      	str	w8, [x9, #0x10]
    3d28:      	mov	v0.s[3], w11
    3d2c:      	add	v0.4s, v0.4s, v1.4s
    3d30:      	str	q0, [x9]
    3d34:      	add	sp, sp, #0xf0
    3d38:      	ret

0000000000003d3c <_ZN5CSHA16UpdateEPhj>:
    3d3c:      	stp	x29, x30, [sp, #-0x40]!
    3d40:      	stp	x24, x23, [sp, #0x10]
    3d44:      	stp	x22, x21, [sp, #0x20]
    3d48:      	stp	x20, x19, [sp, #0x30]
    3d4c:      	mov	x29, sp
    3d50:      	ldp	w8, w9, [x0, #0x14]
    3d54:      	lsr	w10, w2, #29
    3d58:      	mov	w19, w2
    3d5c:      	mov	x21, x1
    3d60:      	mov	x20, x0
    3d64:      	ubfx	x24, x8, #3, #6
    3d68:      	adds	w8, w8, w2, lsl #3
    3d6c:      	adc	w9, w10, w9
    3d70:      	add	w11, w24, w2
    3d74:      	stp	w8, w9, [x0, #0x14]
    3d78:      	cmp	w11, #0x40
    3d7c:      	b.lo	0x3de4 <_ZN5CSHA16UpdateEPhj+0xa8>
    3d80:      	mov	w8, #0x40               // =64
    3d84:      	add	x23, x20, #0x20
    3d88:      	mov	x1, x21
    3d8c:      	sub	w22, w8, w24
    3d90:      	add	x0, x23, x24
    3d94:      	mov	x2, x22
    3d98:      	bl	0x48a0 <memcpy@plt>
    3d9c:      	mov	x0, x20
    3da0:      	mov	x1, x20
    3da4:      	mov	x2, x23
    3da8:      	bl	0x4a30 <_ZN5CSHA19TransformEPjPh@plt>
    3dac:      	eor	w23, w24, #0x7f
    3db0:      	cmp	w23, w19
    3db4:      	b.hs	0x3df0 <_ZN5CSHA16UpdateEPhj+0xb4>
    3db8:      	sub	w8, w23, #0x3f
    3dbc:      	mov	x0, x20
    3dc0:      	mov	x1, x20
    3dc4:      	add	x2, x21, x8
    3dc8:      	bl	0x4a30 <_ZN5CSHA19TransformEPjPh@plt>
    3dcc:      	add	w23, w23, #0x40
    3dd0:      	cmp	w23, w19
    3dd4:      	b.lo	0x3db8 <_ZN5CSHA16UpdateEPhj+0x7c>
    3dd8:      	mov	x8, xzr
    3ddc:      	sub	w22, w23, #0x3f
    3de0:      	b	0x3df4 <_ZN5CSHA16UpdateEPhj+0xb8>
    3de4:      	mov	w22, wzr
    3de8:      	mov	w8, w24
    3dec:      	b	0x3df4 <_ZN5CSHA16UpdateEPhj+0xb8>
    3df0:      	mov	x8, xzr
    3df4:      	add	x8, x20, x8
    3df8:      	add	x1, x21, w22, uxtw
    3dfc:      	sub	w2, w19, w22
    3e00:      	add	x0, x8, #0x20
    3e04:      	ldp	x20, x19, [sp, #0x30]
    3e08:      	ldp	x22, x21, [sp, #0x20]
    3e0c:      	ldp	x24, x23, [sp, #0x10]
    3e10:      	ldp	x29, x30, [sp], #0x40
    3e14:      	b	0x48a0 <memcpy@plt>

0000000000003e18 <_ZN5CSHA18HashFileEPc>:
    3e18:      	stp	x29, x30, [sp, #-0x40]!
    3e1c:      	stp	x28, x23, [sp, #0x10]
    3e20:      	stp	x22, x21, [sp, #0x20]
    3e24:      	stp	x20, x19, [sp, #0x30]
    3e28:      	mov	x29, sp
    3e2c:      	sub	sp, sp, #0x1, lsl #12   // =0x1000
    3e30:      	sub	sp, sp, #0xf50
    3e34:      	mrs	x22, TPIDR_EL0
    3e38:      	ldr	x8, [x22, #0x28]
    3e3c:      	stur	x8, [x29, #-0x8]
    3e40:      	cbz	x1, 0x3f1c <_ZN5CSHA18HashFileEPc+0x104>
    3e44:      	nop
    3e48:      	adr	x8, 0x15ea
    3e4c:      	mov	x19, x0
    3e50:      	mov	x0, x1
    3e54:      	mov	x1, x8
    3e58:      	bl	0x4a50 <fopen@plt>
    3e5c:      	cbz	x0, 0x3f20 <_ZN5CSHA18HashFileEPc+0x108>
    3e60:      	mov	x1, xzr
    3e64:      	mov	w2, #0x2                // =2
    3e68:      	mov	x20, x0
    3e6c:      	bl	0x4a60 <fseek@plt>
    3e70:      	mov	x0, x20
    3e74:      	bl	0x4a70 <ftell@plt>
    3e78:      	mov	x21, x0
    3e7c:      	mov	x0, x20
    3e80:      	mov	x1, xzr
    3e84:      	mov	w2, wzr
    3e88:      	bl	0x4a60 <fseek@plt>
    3e8c:      	cbz	x21, 0x3f0c <_ZN5CSHA18HashFileEPc+0xf4>
    3e90:      	mov	x9, #0x3f7d             // =16253
    3e94:      	lsr	x8, x21, #6
    3e98:      	movk	x9, #0x5e35, lsl #16
    3e9c:      	movk	x9, #0x49ba, lsl #32
    3ea0:      	cmp	x8, #0x7d
    3ea4:      	movk	x9, #0x20c, lsl #48
    3ea8:      	umulh	x23, x8, x9
    3eac:      	mov	w9, #0x1f40             // =8000
    3eb0:      	msub	x21, x23, x9, x21
    3eb4:      	b.lo	0x3ee4 <_ZN5CSHA18HashFileEPc+0xcc>
    3eb8:      	add	x0, sp, #0x8
    3ebc:      	mov	w1, #0x1                // =1
    3ec0:      	mov	w2, #0x1f40             // =8000
    3ec4:      	mov	x3, x20
    3ec8:      	bl	0x4a80 <fread@plt>
    3ecc:      	add	x1, sp, #0x8
    3ed0:      	mov	x0, x19
    3ed4:      	mov	w2, #0x1f40             // =8000
    3ed8:      	bl	0x4a40 <_ZN5CSHA16UpdateEPhj@plt>
    3edc:      	subs	x23, x23, #0x1
    3ee0:      	b.ne	0x3eb8 <_ZN5CSHA18HashFileEPc+0xa0>
    3ee4:      	cbz	x21, 0x3f0c <_ZN5CSHA18HashFileEPc+0xf4>
    3ee8:      	add	x0, sp, #0x8
    3eec:      	mov	w1, #0x1                // =1
    3ef0:      	mov	x2, x21
    3ef4:      	mov	x3, x20
    3ef8:      	bl	0x4a80 <fread@plt>
    3efc:      	add	x1, sp, #0x8
    3f00:      	mov	x0, x19
    3f04:      	mov	w2, w21
    3f08:      	bl	0x4a40 <_ZN5CSHA16UpdateEPhj@plt>
    3f0c:      	mov	x0, x20
    3f10:      	bl	0x4a90 <fclose@plt>
    3f14:      	mov	w0, #0x1                // =1
    3f18:      	b	0x3f20 <_ZN5CSHA18HashFileEPc+0x108>
    3f1c:      	mov	w0, wzr
    3f20:      	ldr	x8, [x22, #0x28]
    3f24:      	ldur	x9, [x29, #-0x8]
    3f28:      	cmp	x8, x9
    3f2c:      	b.ne	0x3f4c <_ZN5CSHA18HashFileEPc+0x134>
    3f30:      	add	sp, sp, #0x1, lsl #12   // =0x1000
    3f34:      	add	sp, sp, #0xf50
    3f38:      	ldp	x20, x19, [sp, #0x30]
    3f3c:      	ldp	x22, x21, [sp, #0x20]
    3f40:      	ldp	x28, x23, [sp, #0x10]
    3f44:      	ldp	x29, x30, [sp], #0x40
    3f48:      	ret
    3f4c:      	bl	0x48e0 <__stack_chk_fail@plt>

0000000000003f50 <_ZN5CSHA15FinalEv>:
    3f50:      	sub	sp, sp, #0x40
    3f54:      	stp	x29, x30, [sp, #0x10]
    3f58:      	str	x21, [sp, #0x20]
    3f5c:      	stp	x20, x19, [sp, #0x30]
    3f60:      	add	x29, sp, #0x10
    3f64:      	mrs	x21, TPIDR_EL0
    3f68:      	adrp	x1, 0x1000
    3f6c:      	add	x1, x1, #0x5e5
    3f70:      	ldr	x8, [x21, #0x28]
    3f74:      	mov	w2, #0x1                // =1
    3f78:      	mov	x19, x0
    3f7c:      	str	x8, [sp, #0x8]
    3f80:      	ldp	w9, w8, [x0, #0x14]
    3f84:      	rev	w8, w8
    3f88:      	rev	w9, w9
    3f8c:      	stp	w8, w9, [sp]
    3f90:      	bl	0x4a40 <_ZN5CSHA16UpdateEPhj@plt>
    3f94:      	ldr	w8, [x19, #0x14]
    3f98:      	and	w8, w8, #0x1f8
    3f9c:      	cmp	w8, #0x1c0
    3fa0:      	b.eq	0x3fcc <_ZN5CSHA15FinalEv+0x7c>
    3fa4:      	nop
    3fa8:      	adr	x20, 0x1688
    3fac:      	mov	x0, x19
    3fb0:      	mov	x1, x20
    3fb4:      	mov	w2, #0x1                // =1
    3fb8:      	bl	0x4a40 <_ZN5CSHA16UpdateEPhj@plt>
    3fbc:      	ldr	w8, [x19, #0x14]
    3fc0:      	and	w8, w8, #0x1f8
    3fc4:      	cmp	w8, #0x1c0
    3fc8:      	b.ne	0x3fac <_ZN5CSHA15FinalEv+0x5c>
    3fcc:      	mov	x1, sp
    3fd0:      	mov	x0, x19
    3fd4:      	mov	w2, #0x8                // =8
    3fd8:      	bl	0x4a40 <_ZN5CSHA16UpdateEPhj@plt>
    3fdc:      	ldp	w8, w9, [x19]
    3fe0:      	movi	v0.2d, #0000000000000000
    3fe4:      	mov	x2, x19
    3fe8:      	stur	xzr, [x19, #0x14]
    3fec:      	rev	w8, w8
    3ff0:      	rev	w9, w9
    3ff4:      	stp	w8, w9, [x19, #0x60]
    3ff8:      	ldr	w9, [x19, #0x10]
    3ffc:      	ldp	w8, w10, [x19, #0x8]
    4000:      	str	q0, [x2, #0x20]!
    4004:      	stp	q0, q0, [x19, #0x30]
    4008:      	rev	w8, w8
    400c:      	rev	w10, w10
    4010:      	str	q0, [x19, #0x50]
    4014:      	stp	w8, w10, [x19, #0x68]
    4018:      	rev	w8, w9
    401c:      	str	w8, [x19, #0x70]
    4020:      	stp	xzr, xzr, [x19]
    4024:      	str	wzr, [x19, #0x10]
    4028:      	ldr	x8, [x21, #0x28]
    402c:      	ldr	x9, [sp, #0x8]
    4030:      	cmp	x8, x9
    4034:      	b.ne	0x4054 <_ZN5CSHA15FinalEv+0x104>
    4038:      	mov	x0, x19
    403c:      	mov	x1, x19
    4040:      	ldp	x20, x19, [sp, #0x30]
    4044:      	ldr	x21, [sp, #0x20]
    4048:      	ldp	x29, x30, [sp, #0x10]
    404c:      	add	sp, sp, #0x40
    4050:      	b	0x4a30 <_ZN5CSHA19TransformEPjPh@plt>
    4054:      	bl	0x48e0 <__stack_chk_fail@plt>

0000000000004058 <_ZN5CSHA110ReportHashEPch>:
    4058:      	sub	sp, sp, #0x40
    405c:      	stp	x29, x30, [sp, #0x20]
    4060:      	str	x19, [sp, #0x30]
    4064:      	add	x29, sp, #0x20
    4068:      	mrs	x19, TPIDR_EL0
    406c:      	ldr	x8, [x19, #0x28]
    4070:      	stur	x8, [x29, #-0x8]
    4074:      	cbz	x1, 0x412c <_ZN5CSHA110ReportHashEPch+0xd4>
    4078:      	and	w8, w2, #0xff
    407c:      	mov	x0, x1
    4080:      	cmp	w8, #0x1
    4084:      	b.eq	0x408c <_ZN5CSHA110ReportHashEPch+0x34>
    4088:      	cbnz	w8, 0x414c <_ZN5CSHA110ReportHashEPch+0xf4>
    408c:      	add	x1, sp, #0x8
    4090:      	bl	0x4ab0 <strcat@plt>
    4094:      	add	x1, sp, #0x8
    4098:      	bl	0x4ab0 <strcat@plt>
    409c:      	add	x1, sp, #0x8
    40a0:      	bl	0x4ab0 <strcat@plt>
    40a4:      	add	x1, sp, #0x8
    40a8:      	bl	0x4ab0 <strcat@plt>
    40ac:      	add	x1, sp, #0x8
    40b0:      	bl	0x4ab0 <strcat@plt>
    40b4:      	add	x1, sp, #0x8
    40b8:      	bl	0x4ab0 <strcat@plt>
    40bc:      	add	x1, sp, #0x8
    40c0:      	bl	0x4ab0 <strcat@plt>
    40c4:      	add	x1, sp, #0x8
    40c8:      	bl	0x4ab0 <strcat@plt>
    40cc:      	add	x1, sp, #0x8
    40d0:      	bl	0x4ab0 <strcat@plt>
    40d4:      	add	x1, sp, #0x8
    40d8:      	bl	0x4ab0 <strcat@plt>
    40dc:      	add	x1, sp, #0x8
    40e0:      	bl	0x4ab0 <strcat@plt>
    40e4:      	add	x1, sp, #0x8
    40e8:      	bl	0x4ab0 <strcat@plt>
    40ec:      	add	x1, sp, #0x8
    40f0:      	bl	0x4ab0 <strcat@plt>
    40f4:      	add	x1, sp, #0x8
    40f8:      	bl	0x4ab0 <strcat@plt>
    40fc:      	add	x1, sp, #0x8
    4100:      	bl	0x4ab0 <strcat@plt>
    4104:      	add	x1, sp, #0x8
    4108:      	bl	0x4ab0 <strcat@plt>
    410c:      	add	x1, sp, #0x8
    4110:      	bl	0x4ab0 <strcat@plt>
    4114:      	add	x1, sp, #0x8
    4118:      	bl	0x4ab0 <strcat@plt>
    411c:      	add	x1, sp, #0x8
    4120:      	bl	0x4ab0 <strcat@plt>
    4124:      	add	x1, sp, #0x8
    4128:      	bl	0x4ab0 <strcat@plt>
    412c:      	ldr	x8, [x19, #0x28]
    4130:      	ldur	x9, [x29, #-0x8]
    4134:      	cmp	x8, x9
    4138:      	b.ne	0x4184 <_ZN5CSHA110ReportHashEPch+0x12c>
    413c:      	ldp	x29, x30, [sp, #0x20]
    4140:      	ldr	x19, [sp, #0x30]
    4144:      	add	sp, sp, #0x40
    4148:      	ret
    414c:      	ldr	x8, [x19, #0x28]
    4150:      	ldur	x9, [x29, #-0x8]
    4154:      	cmp	x8, x9
    4158:      	b.ne	0x4184 <_ZN5CSHA110ReportHashEPch+0x12c>
    415c:      	adrp	x8, 0x1000
    4160:      	add	x8, x8, #0x631
    4164:      	ldr	q0, [x8]
    4168:      	ldur	q1, [x8, #0xc]
    416c:      	str	q0, [x0]
    4170:      	stur	q1, [x0, #0xc]
    4174:      	ldp	x29, x30, [sp, #0x20]
    4178:      	ldr	x19, [sp, #0x30]
    417c:      	add	sp, sp, #0x40
    4180:      	ret
    4184:      	bl	0x48e0 <__stack_chk_fail@plt>

0000000000004188 <_ZN5CSHA17GetHashEPh>:
    4188:      	ldr	w8, [x0, #0x70]
    418c:      	ldr	q0, [x0, #0x60]
    4190:      	str	w8, [x1, #0x10]
    4194:      	str	q0, [x1]
    4198:      	ret

000000000000419c <_ZN10CHMAC_SHA19HMAC_SHA1EPhiS0_iS0_>:
    419c:      	stp	x29, x30, [sp, #-0x50]!
    41a0:      	stp	x26, x25, [sp, #0x10]
    41a4:      	stp	x24, x23, [sp, #0x20]
    41a8:      	stp	x22, x21, [sp, #0x30]
    41ac:      	stp	x20, x19, [sp, #0x40]
    41b0:      	mov	x29, sp
    41b4:      	movi	v0.2d, #0000000000000000
    41b8:      	ldr	x8, [x0, #0x150]
    41bc:      	movi	v1.16b, #0x36
    41c0:      	mov	x26, x0
    41c4:      	mov	x19, x5
    41c8:      	mov	w24, w4
    41cc:      	mov	x23, x3
    41d0:      	mov	w21, w2
    41d4:      	mov	x22, x1
    41d8:      	mov	x20, x0
    41dc:      	cmp	w4, #0x41
    41e0:      	stp	q0, q0, [x8]
    41e4:      	stp	q0, q0, [x8, #0x20]
    41e8:      	movi	v0.16b, #0x5c
    41ec:      	str	q1, [x26, #0xc8]!
    41f0:      	mov	x25, x26
    41f4:      	stp	q1, q1, [x26, #0x20]
    41f8:      	str	q1, [x26, #0x10]
    41fc:      	stp	q0, q0, [x25, #0x40]!
    4200:      	stp	q0, q0, [x25, #0x20]
    4204:      	b.lt	0x4238 <_ZN10CHMAC_SHA19HMAC_SHA1EPhiS0_iS0_+0x9c>
    4208:      	mov	x0, x20
    420c:      	bl	0x4a20 <_ZN5CSHA15ResetEv@plt>
    4210:      	mov	x0, x20
    4214:      	mov	x1, x23
    4218:      	mov	w2, w24
    421c:      	bl	0x4a40 <_ZN5CSHA16UpdateEPhj@plt>
    4220:      	mov	x0, x20
    4224:      	bl	0x4aa0 <_ZN5CSHA15FinalEv@plt>
    4228:      	ldr	x1, [x20, #0x150]
    422c:      	mov	x0, x20
    4230:      	bl	0x4ac0 <_ZN5CSHA17GetHashEPh@plt>
    4234:      	b	0x4248 <_ZN10CHMAC_SHA19HMAC_SHA1EPhiS0_iS0_+0xac>
    4238:      	ldr	x0, [x20, #0x150]
    423c:      	sxtw	x2, w24
    4240:      	mov	x1, x23
    4244:      	bl	0x48a0 <memcpy@plt>
    4248:      	mov	x8, xzr
    424c:      	ldr	x9, [x20, #0x150]
    4250:      	add	x10, x20, x8
    4254:      	ldrb	w11, [x10, #0xc8]
    4258:      	ldrb	w9, [x9, x8]
    425c:      	add	x8, x8, #0x1
    4260:      	cmp	x8, #0x40
    4264:      	eor	w9, w11, w9
    4268:      	strb	w9, [x10, #0xc8]
    426c:      	b.ne	0x424c <_ZN10CHMAC_SHA19HMAC_SHA1EPhiS0_iS0_+0xb0>
    4270:      	ldp	q1, q0, [x26, #0x20]
    4274:      	sxtw	x2, w21
    4278:      	ldp	q2, q3, [x26]
    427c:      	mov	x1, x22
    4280:      	ldr	x8, [x20, #0x158]
    4284:      	stp	q2, q3, [x8]
    4288:      	stp	q1, q0, [x8, #0x20]
    428c:      	ldr	x8, [x20, #0x158]
    4290:      	add	x0, x8, #0x40
    4294:      	bl	0x48a0 <memcpy@plt>
    4298:      	mov	x0, x20
    429c:      	bl	0x4a20 <_ZN5CSHA15ResetEv@plt>
    42a0:      	ldr	x1, [x20, #0x158]
    42a4:      	add	w2, w21, #0x40
    42a8:      	mov	x0, x20
    42ac:      	bl	0x4a40 <_ZN5CSHA16UpdateEPhj@plt>
    42b0:      	mov	x0, x20
    42b4:      	bl	0x4aa0 <_ZN5CSHA15FinalEv@plt>
    42b8:      	ldr	x1, [x20, #0x148]
    42bc:      	mov	x0, x20
    42c0:      	bl	0x4ac0 <_ZN5CSHA17GetHashEPh@plt>
    42c4:      	mov	x8, xzr
    42c8:      	ldr	x9, [x20, #0x150]
    42cc:      	add	x10, x20, x8
    42d0:      	ldrb	w11, [x10, #0x108]
    42d4:      	ldrb	w9, [x9, x8]
    42d8:      	add	x8, x8, #0x1
    42dc:      	cmp	x8, #0x40
    42e0:      	eor	w9, w11, w9
    42e4:      	strb	w9, [x10, #0x108]
    42e8:      	b.ne	0x42c8 <_ZN10CHMAC_SHA19HMAC_SHA1EPhiS0_iS0_+0x12c>
    42ec:      	ldp	q1, q0, [x25, #0x20]
    42f0:      	mov	x0, x20
    42f4:      	ldp	q2, q3, [x25]
    42f8:      	ldr	x8, [x20, #0x160]
    42fc:      	stp	q1, q0, [x8, #0x20]
    4300:      	stp	q2, q3, [x8]
    4304:      	ldr	x8, [x20, #0x148]
    4308:      	ldr	x9, [x20, #0x160]
    430c:      	ldr	w10, [x8, #0x10]
    4310:      	ldr	q0, [x8]
    4314:      	str	w10, [x9, #0x50]
    4318:      	str	q0, [x9, #0x40]
    431c:      	bl	0x4a20 <_ZN5CSHA15ResetEv@plt>
    4320:      	ldr	x1, [x20, #0x160]
    4324:      	mov	x0, x20
    4328:      	mov	w2, #0x54               // =84
    432c:      	bl	0x4a40 <_ZN5CSHA16UpdateEPhj@plt>
    4330:      	mov	x0, x20
    4334:      	bl	0x4aa0 <_ZN5CSHA15FinalEv@plt>
    4338:      	mov	x0, x20
    433c:      	mov	x1, x19
    4340:      	ldp	x20, x19, [sp, #0x40]
    4344:      	ldp	x22, x21, [sp, #0x30]
    4348:      	ldp	x24, x23, [sp, #0x20]
    434c:      	ldp	x26, x25, [sp, #0x10]
    4350:      	ldp	x29, x30, [sp], #0x50
    4354:      	b	0x4ac0 <_ZN5CSHA17GetHashEPh@plt>

0000000000004358 <_ZN10CHMAC_SHA112byteToHexStrEPhi>:
    4358:      	sub	sp, sp, #0xc0
    435c:      	stp	x29, x30, [sp, #0x60]
    4360:      	stp	x28, x27, [sp, #0x70]
    4364:      	stp	x26, x25, [sp, #0x80]
    4368:      	stp	x24, x23, [sp, #0x90]
    436c:      	stp	x22, x21, [sp, #0xa0]
    4370:      	stp	x20, x19, [sp, #0xb0]
    4374:      	add	x29, sp, #0x60
    4378:      	mov	x20, x8
    437c:      	mrs	x8, TPIDR_EL0
    4380:      	str	x8, [sp, #0x8]
    4384:      	cmp	w2, #0x1
    4388:      	ldr	x8, [x8, #0x28]
    438c:      	stur	x8, [x29, #-0x8]
    4390:      	stp	xzr, xzr, [x20]
    4394:      	str	xzr, [x20, #0x10]
    4398:      	b.lt	0x4504 <_ZN10CHMAC_SHA112byteToHexStrEPhi+0x1ac>
    439c:      	add	x8, sp, #0x30
    43a0:      	mov	x19, x1
    43a4:      	mov	x23, xzr
    43a8:      	mov	w25, wzr
    43ac:      	orr	x10, x8, #0x1
    43b0:      	add	x9, x20, #0x1
    43b4:      	orr	x24, x8, #0x2
    43b8:      	mov	w28, w2
    43bc:      	stp	x10, x9, [sp, #0x10]
    43c0:      	b	0x43cc <_ZN10CHMAC_SHA112byteToHexStrEPhi+0x74>
    43c4:      	subs	x28, x28, #0x1
    43c8:      	b.eq	0x4504 <_ZN10CHMAC_SHA112byteToHexStrEPhi+0x1ac>
    43cc:      	ldrb	w8, [x19], #0x1
    43d0:      	mov	w10, #0x30              // =48
    43d4:      	lsr	w9, w8, #4
    43d8:      	and	w11, w8, #0xf
    43dc:      	cmp	w8, #0xa0
    43e0:      	bfxil	w10, w8, #0, #4
    43e4:      	add	w8, w11, #0x37
    43e8:      	orr	w12, w9, #0x30
    43ec:      	add	w9, w9, #0x37
    43f0:      	csel	w26, w12, w9, lo
    43f4:      	cmp	w11, #0xa
    43f8:      	ldr	x9, [x20, #0x8]
    43fc:      	lsr	w11, w25, #1
    4400:      	csel	w21, w10, w8, lo
    4404:      	tst	w25, #0x1
    4408:      	csel	x22, x11, x9, eq
    440c:      	add	x27, x22, #0x1
    4410:      	cmn	x27, #0x10
    4414:      	b.hs	0x4538 <_ZN10CHMAC_SHA112byteToHexStrEPhi+0x1e0>
    4418:      	cmp	x27, #0x17
    441c:      	str	x23, [sp, #0x28]
    4420:      	b.hs	0x4440 <_ZN10CHMAC_SHA112byteToHexStrEPhi+0xe8>
    4424:      	lsl	w8, w27, #1
    4428:      	ldr	x23, [sp, #0x10]
    442c:      	stp	xzr, xzr, [sp, #0x30]
    4430:      	str	xzr, [sp, #0x40]
    4434:      	strb	w8, [sp, #0x30]
    4438:      	cbnz	x22, 0x446c <_ZN10CHMAC_SHA112byteToHexStrEPhi+0x114>
    443c:      	b	0x4488 <_ZN10CHMAC_SHA112byteToHexStrEPhi+0x130>
    4440:      	str	x19, [sp, #0x20]
    4444:      	mov	x19, x24
    4448:      	orr	x24, x27, #0xf
    444c:      	add	x0, x24, #0x1
    4450:      	bl	0x48c0 <_Znwm@plt>
    4454:      	add	x8, x24, #0x2
    4458:      	mov	x24, x19
    445c:      	ldr	x19, [sp, #0x20]
    4460:      	mov	x23, x0
    4464:      	stp	x27, x0, [sp, #0x38]
    4468:      	str	x8, [sp, #0x30]
    446c:      	ldr	x8, [sp, #0x18]
    4470:      	ldr	x9, [sp, #0x28]
    4474:      	tst	w25, #0x1
    4478:      	mov	x0, x23
    447c:      	mov	x2, x22
    4480:      	csel	x1, x8, x9, eq
    4484:      	bl	0x4ad0 <memmove@plt>
    4488:      	add	x8, x23, x22
    448c:      	add	x0, sp, #0x30
    4490:      	mov	w1, w21
    4494:      	strb	w26, [x8]
    4498:      	strb	wzr, [x8, #0x1]
    449c:      	bl	0x4ae0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt>
    44a0:      	ldr	x9, [x24]
    44a4:      	ldur	x10, [x24, #0x6]
    44a8:      	mov	w8, wzr
    44ac:      	ldr	x23, [sp, #0x40]
    44b0:      	ldrb	w25, [sp, #0x30]
    44b4:      	ldrb	w21, [sp, #0x31]
    44b8:      	stur	x9, [x29, #-0x18]
    44bc:      	ldrb	w9, [x20]
    44c0:      	stp	xzr, xzr, [sp, #0x38]
    44c4:      	stur	x10, [x29, #-0x12]
    44c8:      	str	xzr, [sp, #0x30]
    44cc:      	tbz	w9, #0x0, 0x44dc <_ZN10CHMAC_SHA112byteToHexStrEPhi+0x184>
    44d0:      	ldr	x0, [x20, #0x10]
    44d4:      	bl	0x4920 <_ZdlPv@plt>
    44d8:      	ldrb	w8, [sp, #0x30]
    44dc:      	ldur	x9, [x29, #-0x18]
    44e0:      	ldur	x10, [x29, #-0x12]
    44e4:      	strb	w25, [x20]
    44e8:      	strb	w21, [x20, #0x1]
    44ec:      	stur	x9, [x20, #0x2]
    44f0:      	stp	x10, x23, [x20, #0x8]
    44f4:      	tbz	w8, #0x0, 0x43c4 <_ZN10CHMAC_SHA112byteToHexStrEPhi+0x6c>
    44f8:      	ldr	x0, [sp, #0x40]
    44fc:      	bl	0x4920 <_ZdlPv@plt>
    4500:      	b	0x43c4 <_ZN10CHMAC_SHA112byteToHexStrEPhi+0x6c>
    4504:      	ldr	x8, [sp, #0x8]
    4508:      	ldr	x8, [x8, #0x28]
    450c:      	ldur	x9, [x29, #-0x8]
    4510:      	cmp	x8, x9
    4514:      	b.ne	0x4540 <_ZN10CHMAC_SHA112byteToHexStrEPhi+0x1e8>
    4518:      	ldp	x20, x19, [sp, #0xb0]
    451c:      	ldp	x22, x21, [sp, #0xa0]
    4520:      	ldp	x24, x23, [sp, #0x90]
    4524:      	ldp	x26, x25, [sp, #0x80]
    4528:      	ldp	x28, x27, [sp, #0x70]
    452c:      	ldp	x29, x30, [sp, #0x60]
    4530:      	add	sp, sp, #0xc0
    4534:      	ret
    4538:      	add	x0, sp, #0x30
    453c:      	bl	0x24ec <Java_com_meitu_mtlab_hmacsha_HmacSHA1Sign_getSign+0x318>
    4540:      	bl	0x48e0 <__stack_chk_fail@plt>

0000000000004544 <_ZN7ZBase646EncodeEPKhi>:
    4544:      	sub	sp, sp, #0x70
    4548:      	stp	x29, x30, [sp, #0x10]
    454c:      	stp	x28, x27, [sp, #0x20]
    4550:      	stp	x26, x25, [sp, #0x30]
    4554:      	stp	x24, x23, [sp, #0x40]
    4558:      	stp	x22, x21, [sp, #0x50]
    455c:      	stp	x20, x19, [sp, #0x60]
    4560:      	add	x29, sp, #0x10
    4564:      	mov	x19, x8
    4568:      	mov	w8, #0x5556             // =21846
    456c:      	mov	w21, w2
    4570:      	movk	w8, #0x5555, lsl #16
    4574:      	mov	x20, x1
    4578:      	cmp	w2, #0x3
    457c:      	smull	x8, w2, w8
    4580:      	nop
    4584:      	adr	x23, 0x15ed
    4588:      	stp	xzr, xzr, [x19]
    458c:      	str	xzr, [x19, #0x10]
    4590:      	lsr	x9, x8, #63
    4594:      	lsr	x8, x8, #32
    4598:      	add	w25, w8, w9
    459c:      	b.lt	0x4638 <_ZN7ZBase646EncodeEPKhi+0xf4>
    45a0:      	mov	w26, wzr
    45a4:      	adrp	x22, 0x1000
    45a8:      	add	x22, x22, #0x5e7
    45ac:      	stur	w25, [x29, #-0x4]
    45b0:      	b	0x45c0 <_ZN7ZBase646EncodeEPKhi+0x7c>
    45b4:      	subs	w25, w25, #0x1
    45b8:      	add	x20, x20, #0x3
    45bc:      	b.eq	0x4634 <_ZN7ZBase646EncodeEPKhi+0xf0>
    45c0:      	ldrb	w27, [x20]
    45c4:      	ldrb	w28, [x20, #0x1]
    45c8:      	mov	x0, x19
    45cc:      	ldrb	w24, [x20, #0x2]
    45d0:      	lsr	x8, x27, #2
    45d4:      	ldrb	w1, [x23, x8]
    45d8:      	bl	0x4ae0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt>
    45dc:      	lsr	x8, x28, #4
    45e0:      	mov	x0, x19
    45e4:      	bfi	x8, x27, #4, #2
    45e8:      	ldrb	w1, [x23, x8]
    45ec:      	bl	0x4ae0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt>
    45f0:      	lsr	x8, x24, #6
    45f4:      	mov	x0, x19
    45f8:      	bfi	x8, x28, #2, #4
    45fc:      	ldrb	w1, [x23, x8]
    4600:      	bl	0x4ae0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt>
    4604:      	and	x8, x24, #0x3f
    4608:      	mov	x0, x19
    460c:      	ldrb	w1, [x23, x8]
    4610:      	bl	0x4ae0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt>
    4614:      	add	w26, w26, #0x4
    4618:      	cmp	w26, #0x4c
    461c:      	b.ne	0x45b4 <_ZN7ZBase646EncodeEPKhi+0x70>
    4620:      	mov	x0, x19
    4624:      	mov	x1, x22
    4628:      	bl	0x4900 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>
    462c:      	mov	w26, wzr
    4630:      	b	0x45b4 <_ZN7ZBase646EncodeEPKhi+0x70>
    4634:      	ldur	w25, [x29, #-0x4]
    4638:      	add	w8, w25, w25, lsl #1
    463c:      	sub	w8, w21, w8
    4640:      	cmp	w8, #0x1
    4644:      	b.eq	0x468c <_ZN7ZBase646EncodeEPKhi+0x148>
    4648:      	cmp	w8, #0x2
    464c:      	b.ne	0x46e0 <_ZN7ZBase646EncodeEPKhi+0x19c>
    4650:      	ldrb	w21, [x20]
    4654:      	ldrb	w20, [x20, #0x1]
    4658:      	mov	x0, x19
    465c:      	lsr	x8, x21, #2
    4660:      	ldrb	w1, [x23, x8]
    4664:      	bl	0x4ae0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt>
    4668:      	ubfx	x8, x20, #4, #4
    466c:      	mov	x0, x19
    4670:      	bfi	x8, x21, #4, #2
    4674:      	ldrb	w1, [x23, x8]
    4678:      	bl	0x4ae0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt>
    467c:      	ubfiz	w8, w20, #2, #4
    4680:      	adrp	x20, 0x1000
    4684:      	add	x20, x20, #0x64d
    4688:      	b	0x46ac <_ZN7ZBase646EncodeEPKhi+0x168>
    468c:      	ldrb	w20, [x20]
    4690:      	mov	x0, x19
    4694:      	ubfx	x8, x20, #2, #6
    4698:      	ldrb	w1, [x23, x8]
    469c:      	bl	0x4ae0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt>
    46a0:      	ubfiz	w8, w20, #4, #2
    46a4:      	adrp	x20, 0x1000
    46a8:      	add	x20, x20, #0x569
    46ac:      	ldrb	w1, [x23, w8, uxtw]
    46b0:      	mov	x0, x19
    46b4:      	bl	0x4ae0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt>
    46b8:      	mov	x0, x19
    46bc:      	mov	x1, x20
    46c0:      	ldp	x20, x19, [sp, #0x60]
    46c4:      	ldp	x22, x21, [sp, #0x50]
    46c8:      	ldp	x24, x23, [sp, #0x40]
    46cc:      	ldp	x26, x25, [sp, #0x30]
    46d0:      	ldp	x28, x27, [sp, #0x20]
    46d4:      	ldp	x29, x30, [sp, #0x10]
    46d8:      	add	sp, sp, #0x70
    46dc:      	b	0x4900 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>
    46e0:      	ldp	x20, x19, [sp, #0x60]
    46e4:      	ldp	x22, x21, [sp, #0x50]
    46e8:      	ldp	x24, x23, [sp, #0x40]
    46ec:      	ldp	x26, x25, [sp, #0x30]
    46f0:      	ldp	x28, x27, [sp, #0x20]
    46f4:      	ldp	x29, x30, [sp, #0x10]
    46f8:      	add	sp, sp, #0x70
    46fc:      	ret

0000000000004700 <_ZN7ZBase646DecodeEPKciRi>:
    4700:      	cmp	w2, #0x1
    4704:      	stp	xzr, xzr, [x8]
    4708:      	str	xzr, [x8, #0x10]
    470c:      	b.lt	0x4828 <_ZN7ZBase646DecodeEPKciRi+0x128>
    4710:      	stp	x29, x30, [sp, #-0x50]!
    4714:      	stp	x26, x25, [sp, #0x10]
    4718:      	stp	x24, x23, [sp, #0x20]
    471c:      	stp	x22, x21, [sp, #0x30]
    4720:      	stp	x20, x19, [sp, #0x40]
    4724:      	mov	x29, sp
    4728:      	mov	x19, x3
    472c:      	mov	w20, w2
    4730:      	mov	x22, x1
    4734:      	mov	x21, x8
    4738:      	mov	w23, wzr
    473c:      	nop
    4740:      	adr	x24, 0x168a
    4744:      	b	0x475c <_ZN7ZBase646DecodeEPKciRi+0x5c>
    4748:      	add	x22, x22, #0x1
    474c:      	mov	w8, #0x1                // =1
    4750:      	add	w23, w23, w8
    4754:      	cmp	w23, w20
    4758:      	b.ge	0x4814 <_ZN7ZBase646DecodeEPKciRi+0x114>
    475c:      	ldrb	w8, [x22]
    4760:      	cmp	w8, #0xa
    4764:      	b.eq	0x4748 <_ZN7ZBase646DecodeEPKciRi+0x48>
    4768:      	cmp	w8, #0xd
    476c:      	b.eq	0x4748 <_ZN7ZBase646DecodeEPKciRi+0x48>
    4770:      	ldrb	w9, [x22, #0x1]
    4774:      	ldrb	w8, [x24, w8, uxtw]
    4778:      	mov	x0, x21
    477c:      	ldrb	w9, [x24, x9]
    4780:      	lsl	w26, w9, #12
    4784:      	add	w8, w26, w8, lsl #18
    4788:      	lsr	w1, w8, #16
    478c:      	bl	0x4ae0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt>
    4790:      	ldr	w8, [x19]
    4794:      	mov	x9, x22
    4798:      	add	w8, w8, #0x1
    479c:      	str	w8, [x19]
    47a0:      	ldrb	w8, [x9, #0x2]!
    47a4:      	cmp	x8, #0x3d
    47a8:      	b.eq	0x47e0 <_ZN7ZBase646DecodeEPKciRi+0xe0>
    47ac:      	ldrb	w8, [x24, x8]
    47b0:      	mov	x0, x21
    47b4:      	lsl	w25, w8, #6
    47b8:      	add	w8, w25, w26
    47bc:      	lsr	w1, w8, #8
    47c0:      	bl	0x4ae0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt>
    47c4:      	ldr	w8, [x19]
    47c8:      	mov	x9, x22
    47cc:      	add	w8, w8, #0x1
    47d0:      	str	w8, [x19]
    47d4:      	ldrb	w8, [x9, #0x3]!
    47d8:      	cmp	x8, #0x3d
    47dc:      	b.ne	0x47ec <_ZN7ZBase646DecodeEPKciRi+0xec>
    47e0:      	mov	w8, #0x4                // =4
    47e4:      	mov	x22, x9
    47e8:      	b	0x4750 <_ZN7ZBase646DecodeEPKciRi+0x50>
    47ec:      	ldrb	w8, [x24, x8]
    47f0:      	mov	x0, x21
    47f4:      	add	x22, x22, #0x4
    47f8:      	add	w1, w8, w25
    47fc:      	bl	0x4ae0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt>
    4800:      	ldr	w8, [x19]
    4804:      	add	w8, w8, #0x1
    4808:      	str	w8, [x19]
    480c:      	mov	w8, #0x4                // =4
    4810:      	b	0x4750 <_ZN7ZBase646DecodeEPKciRi+0x50>
    4814:      	ldp	x20, x19, [sp, #0x40]
    4818:      	ldp	x22, x21, [sp, #0x30]
    481c:      	ldp	x24, x23, [sp, #0x20]
    4820:      	ldp	x26, x25, [sp, #0x10]
    4824:      	ldp	x29, x30, [sp], #0x50
    4828:      	ret

Disassembly of section .plt:

0000000000004830 <.plt>:
    4830:      	stp	x16, x30, [sp, #-0x10]!
    4834:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4838:      	ldr	x17, [x16, #0xcf0]
    483c:      	add	x16, x16, #0xcf0
    4840:      	br	x17
    4844:      	nop
    4848:      	nop
    484c:      	nop

0000000000004850 <__cxa_finalize@plt>:
    4850:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4854:      	ldr	x17, [x16, #0xcf8]
    4858:      	add	x16, x16, #0xcf8
    485c:      	br	x17

0000000000004860 <__cxa_atexit@plt>:
    4860:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4864:      	ldr	x17, [x16, #0xd00]
    4868:      	add	x16, x16, #0xd00
    486c:      	br	x17

0000000000004870 <_Z11jstring2strP7_JNIEnvP8_jstring@plt>:
    4870:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4874:      	ldr	x17, [x16, #0xd08]
    4878:      	add	x16, x16, #0xd08
    487c:      	br	x17

0000000000004880 <_ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz@plt>:
    4880:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4884:      	ldr	x17, [x16, #0xd10]
    4888:      	add	x16, x16, #0xd10
    488c:      	br	x17

0000000000004890 <malloc@plt>:
    4890:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4894:      	ldr	x17, [x16, #0xd18]
    4898:      	add	x16, x16, #0xd18
    489c:      	br	x17

00000000000048a0 <memcpy@plt>:
    48a0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    48a4:      	ldr	x17, [x16, #0xd20]
    48a8:      	add	x16, x16, #0xd20
    48ac:      	br	x17

00000000000048b0 <strlen@plt>:
    48b0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    48b4:      	ldr	x17, [x16, #0xd28]
    48b8:      	add	x16, x16, #0xd28
    48bc:      	br	x17

00000000000048c0 <_Znwm@plt>:
    48c0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    48c4:      	ldr	x17, [x16, #0xd30]
    48c8:      	add	x16, x16, #0xd30
    48cc:      	br	x17

00000000000048d0 <free@plt>:
    48d0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    48d4:      	ldr	x17, [x16, #0xd38]
    48d8:      	add	x16, x16, #0xd38
    48dc:      	br	x17

00000000000048e0 <__stack_chk_fail@plt>:
    48e0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    48e4:      	ldr	x17, [x16, #0xd40]
    48e8:      	add	x16, x16, #0xd40
    48ec:      	br	x17

00000000000048f0 <_Z10getSignKeyP7_JNIEnvP8_jstringS2_S2_@plt>:
    48f0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    48f4:      	ldr	x17, [x16, #0xd48]
    48f8:      	add	x16, x16, #0xd48
    48fc:      	br	x17

0000000000004900 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>:
    4900:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4904:      	ldr	x17, [x16, #0xd50]
    4908:      	add	x16, x16, #0xd50
    490c:      	br	x17

0000000000004910 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm@plt>:
    4910:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4914:      	ldr	x17, [x16, #0xd58]
    4918:      	add	x16, x16, #0xd58
    491c:      	br	x17

0000000000004920 <_ZdlPv@plt>:
    4920:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4924:      	ldr	x17, [x16, #0xd60]
    4928:      	add	x16, x16, #0xd60
    492c:      	br	x17

0000000000004930 <_ZNSt6__ndk18ios_base4initEPv@plt>:
    4930:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4934:      	ldr	x17, [x16, #0xd68]
    4938:      	add	x16, x16, #0xd68
    493c:      	br	x17

0000000000004940 <_ZNSt6__ndk115basic_streambufIcNS_11char_traitsIcEEEC2Ev@plt>:
    4940:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4944:      	ldr	x17, [x16, #0xd70]
    4948:      	add	x16, x16, #0xd70
    494c:      	br	x17

0000000000004950 <rand@plt>:
    4950:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4954:      	ldr	x17, [x16, #0xd78]
    4958:      	add	x16, x16, #0xd78
    495c:      	br	x17

0000000000004960 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEElsEi@plt>:
    4960:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4964:      	ldr	x17, [x16, #0xd80]
    4968:      	add	x16, x16, #0xd80
    496c:      	br	x17

0000000000004970 <_ZNKSt6__ndk115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strEv@plt>:
    4970:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4974:      	ldr	x17, [x16, #0xd88]
    4978:      	add	x16, x16, #0xd88
    497c:      	br	x17

0000000000004980 <_ZNSt6__ndk115basic_streambufIcNS_11char_traitsIcEEED2Ev@plt>:
    4980:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4984:      	ldr	x17, [x16, #0xd90]
    4988:      	add	x16, x16, #0xd90
    498c:      	br	x17

0000000000004990 <_ZNSt6__ndk114basic_iostreamIcNS_11char_traitsIcEEED2Ev@plt>:
    4990:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4994:      	ldr	x17, [x16, #0xd98]
    4998:      	add	x16, x16, #0xd98
    499c:      	br	x17

00000000000049a0 <_ZNSt6__ndk19basic_iosIcNS_11char_traitsIcEEED2Ev@plt>:
    49a0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    49a4:      	ldr	x17, [x16, #0xda0]
    49a8:      	add	x16, x16, #0xda0
    49ac:      	br	x17

00000000000049b0 <_ZN5CSHA1C2Ev@plt>:
    49b0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    49b4:      	ldr	x17, [x16, #0xda8]
    49b8:      	add	x16, x16, #0xda8
    49bc:      	br	x17

00000000000049c0 <_Znam@plt>:
    49c0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    49c4:      	ldr	x17, [x16, #0xdb0]
    49c8:      	add	x16, x16, #0xdb0
    49cc:      	br	x17

00000000000049d0 <_ZN10CHMAC_SHA19HMAC_SHA1EPhiS0_iS0_@plt>:
    49d0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    49d4:      	ldr	x17, [x16, #0xdb8]
    49d8:      	add	x16, x16, #0xdb8
    49dc:      	br	x17

00000000000049e0 <_ZN7ZBase646EncodeEPKhi@plt>:
    49e0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    49e4:      	ldr	x17, [x16, #0xdc0]
    49e8:      	add	x16, x16, #0xdc0
    49ec:      	br	x17

00000000000049f0 <_ZdaPv@plt>:
    49f0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    49f4:      	ldr	x17, [x16, #0xdc8]
    49f8:      	add	x16, x16, #0xdc8
    49fc:      	br	x17

0000000000004a00 <_ZN5CSHA1D2Ev@plt>:
    4a00:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4a04:      	ldr	x17, [x16, #0xdd0]
    4a08:      	add	x16, x16, #0xdd0
    4a0c:      	br	x17

0000000000004a10 <_ZNSt6__ndk122__libcpp_verbose_abortEPKcz@plt>:
    4a10:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4a14:      	ldr	x17, [x16, #0xdd8]
    4a18:      	add	x16, x16, #0xdd8
    4a1c:      	br	x17

0000000000004a20 <_ZN5CSHA15ResetEv@plt>:
    4a20:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4a24:      	ldr	x17, [x16, #0xde0]
    4a28:      	add	x16, x16, #0xde0
    4a2c:      	br	x17

0000000000004a30 <_ZN5CSHA19TransformEPjPh@plt>:
    4a30:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4a34:      	ldr	x17, [x16, #0xde8]
    4a38:      	add	x16, x16, #0xde8
    4a3c:      	br	x17

0000000000004a40 <_ZN5CSHA16UpdateEPhj@plt>:
    4a40:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4a44:      	ldr	x17, [x16, #0xdf0]
    4a48:      	add	x16, x16, #0xdf0
    4a4c:      	br	x17

0000000000004a50 <fopen@plt>:
    4a50:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4a54:      	ldr	x17, [x16, #0xdf8]
    4a58:      	add	x16, x16, #0xdf8
    4a5c:      	br	x17

0000000000004a60 <fseek@plt>:
    4a60:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4a64:      	ldr	x17, [x16, #0xe00]
    4a68:      	add	x16, x16, #0xe00
    4a6c:      	br	x17

0000000000004a70 <ftell@plt>:
    4a70:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4a74:      	ldr	x17, [x16, #0xe08]
    4a78:      	add	x16, x16, #0xe08
    4a7c:      	br	x17

0000000000004a80 <fread@plt>:
    4a80:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4a84:      	ldr	x17, [x16, #0xe10]
    4a88:      	add	x16, x16, #0xe10
    4a8c:      	br	x17

0000000000004a90 <fclose@plt>:
    4a90:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4a94:      	ldr	x17, [x16, #0xe18]
    4a98:      	add	x16, x16, #0xe18
    4a9c:      	br	x17

0000000000004aa0 <_ZN5CSHA15FinalEv@plt>:
    4aa0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4aa4:      	ldr	x17, [x16, #0xe20]
    4aa8:      	add	x16, x16, #0xe20
    4aac:      	br	x17

0000000000004ab0 <strcat@plt>:
    4ab0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4ab4:      	ldr	x17, [x16, #0xe28]
    4ab8:      	add	x16, x16, #0xe28
    4abc:      	br	x17

0000000000004ac0 <_ZN5CSHA17GetHashEPh@plt>:
    4ac0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4ac4:      	ldr	x17, [x16, #0xe30]
    4ac8:      	add	x16, x16, #0xe30
    4acc:      	br	x17

0000000000004ad0 <memmove@plt>:
    4ad0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4ad4:      	ldr	x17, [x16, #0xe38]
    4ad8:      	add	x16, x16, #0xe38
    4adc:      	br	x17

0000000000004ae0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt>:
    4ae0:      	adrp	x16, 0x8000 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt+0x3520>
    4ae4:      	ldr	x17, [x16, #0xe40]
    4ae8:      	add	x16, x16, #0xe40
    4aec:      	br	x17
