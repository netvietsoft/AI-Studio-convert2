
F:\CONVERT\com.mt.mtxx.mtxx\SOURCE\extracted_native_libs\lib\arm64-v8a\libbytehook.so:	file format elf64-littleaarch64

Disassembly of section .text:

00000000000055ec <.text>:
    55ec:      	bti	c
    55f0:      	adrp	x0, 0x11000 <siglongjmp@plt+0x3870>
    55f4:      	add	x0, x0, #0x7a0
    55f8:      	b	0xd230 <__cxa_finalize@plt>
    55fc:      	bti	c
    5600:      	ret
    5604:      	bti	c
    5608:      	b	0x55fc <.text+0x10>
    560c:      	bti	c
    5610:      	cbz	x0, 0x561c <.text+0x30>
    5614:      	mov	x16, x0
    5618:      	br	x16
    561c:      	ret
    5620:      	bti	c
    5624:      	adrp	x8, 0x5000
    5628:      	add	x8, x8, #0x60c
    562c:      	adrp	x2, 0x11000 <siglongjmp@plt+0x3870>
    5630:      	add	x2, x2, #0x7a0
    5634:      	mov	x1, x0
    5638:      	mov	x0, x8
    563c:      	b	0xd240 <__cxa_atexit@plt>
    5640:      	stp	x29, x30, [sp, #-0x30]!
    5644:      	str	x21, [sp, #0x10]
    5648:      	stp	x20, x19, [sp, #0x20]
    564c:      	mov	x29, sp
    5650:      	ldp	x9, x8, [x0, #0x8]
    5654:      	mov	x19, x0
    5658:      	mov	x20, x1
    565c:      	cmp	x9, x8
    5660:      	b.hs	0x5690 <.text+0xa4>
    5664:      	ldr	x0, [x19]
    5668:      	str	x20, [x0, x9, lsl #3]
    566c:      	ldr	x9, [x19, #0x8]
    5670:      	mov	w8, wzr
    5674:      	add	x9, x9, #0x1
    5678:      	str	x9, [x19, #0x8]
    567c:      	ldp	x20, x19, [sp, #0x20]
    5680:      	ldr	x21, [sp, #0x10]
    5684:      	mov	w0, w8
    5688:      	ldp	x29, x30, [sp], #0x30
    568c:      	ret
    5690:      	ldr	x21, [x19]
    5694:      	add	x10, x19, #0x18
    5698:      	lsl	x9, x8, #1
    569c:      	str	x9, [x19, #0x10]
    56a0:      	cmp	x21, x10
    56a4:      	b.eq	0x56c4 <.text+0xd8>
    56a8:      	lsl	x1, x8, #4
    56ac:      	mov	x0, x21
    56b0:      	bl	0xd250 <realloc@plt>
    56b4:      	cbnz	x0, 0x56e0 <.text+0xf4>
    56b8:      	ldr	x0, [x19]
    56bc:      	bl	0xd260 <free@plt>
    56c0:      	b	0x56ec <.text+0x100>
    56c4:      	lsl	x0, x8, #4
    56c8:      	bl	0xd270 <malloc@plt>
    56cc:      	cbz	x0, 0x56ec <.text+0x100>
    56d0:      	ldp	q1, q0, [x21, #0x20]
    56d4:      	ldp	q3, q2, [x21]
    56d8:      	stp	q1, q0, [x0, #0x20]
    56dc:      	stp	q3, q2, [x0]
    56e0:      	ldr	x9, [x19, #0x8]
    56e4:      	str	x0, [x19]
    56e8:      	b	0x5668 <.text+0x7c>
    56ec:      	mov	w8, #-0x1               // =-1
    56f0:      	b	0x567c <.text+0x90>
    56f4:      	mov	x8, x0
    56f8:      	ldr	x0, [x8], #0x18
    56fc:      	cmp	x0, x8
    5700:      	b.ne	0x5708 <.text+0x11c>
    5704:      	ret
    5708:      	b	0xd260 <free@plt>
    570c:      	stp	x29, x30, [sp, #-0x20]!
    5710:      	stp	x20, x19, [sp, #0x10]
    5714:      	mov	x29, sp
    5718:      	adrp	x0, 0x2000
    571c:      	add	x0, x0, #0x350
    5720:      	mov	w1, #0x2                // =2
    5724:      	bl	0xd280 <dlopen@plt>
    5728:      	cbz	x0, 0x576c <.text+0x180>
    572c:      	adrp	x1, 0x2000
    5730:      	add	x1, x1, #0x5c6
    5734:      	mov	x19, x0
    5738:      	bl	0xd290 <dlsym@plt>
    573c:      	adrp	x20, 0x15000
    5740:      	add	x20, x20, #0xe30
    5744:      	adrp	x1, 0x2000
    5748:      	str	x0, [x20]
    574c:      	add	x1, x1, #0x429
    5750:      	mov	x0, x19
    5754:      	bl	0xd290 <dlsym@plt>
    5758:      	str	x0, [x20, #0x8]
    575c:      	mov	x0, x19
    5760:      	ldp	x20, x19, [sp, #0x10]
    5764:      	ldp	x29, x30, [sp], #0x20
    5768:      	b	0xd2a0 <dlclose@plt>
    576c:      	ldp	x20, x19, [sp, #0x10]
    5770:      	ldp	x29, x30, [sp], #0x20
    5774:      	ret
    5778:      	sub	sp, sp, #0x170
    577c:      	stp	x29, x30, [sp, #0x120]
    5780:      	str	x28, [sp, #0x130]
    5784:      	stp	x24, x23, [sp, #0x140]
    5788:      	stp	x22, x21, [sp, #0x150]
    578c:      	stp	x20, x19, [sp, #0x160]
    5790:      	add	x29, sp, #0x120
    5794:      	mrs	x23, TPIDR_EL0
    5798:      	ldr	x8, [x23, #0x28]
    579c:      	stur	x8, [x29, #-0x8]
    57a0:      	bl	0xba68 <JNI_OnLoad+0x290c>
    57a4:      	cmp	w0, #0x1a
    57a8:      	b.ge	0x57b4 <.text+0x1c8>
    57ac:      	mov	w0, wzr
    57b0:      	b	0x5864 <.text+0x278>
    57b4:      	adrp	x24, 0x15000
    57b8:      	add	x24, x24, #0xe30
    57bc:      	ldr	x8, [x24]
    57c0:      	mov	w0, #-0x1               // =-1
    57c4:      	cbz	x8, 0x5864 <.text+0x278>
    57c8:      	ldr	x9, [x24, #0x8]
    57cc:      	mov	x10, x9
    57d0:      	cbz	x9, 0x5864 <.text+0x278>
    57d4:      	cmp	x8, x9
    57d8:      	csel	x19, x9, x8, hi
    57dc:      	csel	x8, x8, x9, hi
    57e0:      	add	x20, x8, #0x4
    57e4:      	mov	w2, #0x7                // =7
    57e8:      	mov	x0, x19
    57ec:      	mov	x1, x20
    57f0:      	bl	0xb9a8 <JNI_OnLoad+0x284c>
    57f4:      	cbnz	w0, 0x5860 <.text+0x274>
    57f8:      	bl	0xd2b0 <gettid@plt>
    57fc:      	mov	w21, w0
    5800:      	cbnz	w0, 0x5814 <.text+0x228>
    5804:      	mov	w8, #0xb2               // =178
    5808:      	mov	w0, w8
    580c:      	bl	0xd2c0 <syscall@plt>
    5810:      	mov	w21, w0
    5814:      	mov	x8, #0xb                // =11
    5818:      	movk	x8, #0x7, lsl #32
    581c:      	str	x8, [sp, #0x8]
    5820:      	mov	w8, #0x2                // =2
    5824:      	add	x22, sp, #0x10
    5828:      	add	x2, sp, #0x8
    582c:      	mov	w3, w8
    5830:      	mov	w0, w21
    5834:      	mov	x1, x22
    5838:      	bl	0xce14 <bytehook_del_dlopen_callback+0x2ec>
    583c:      	mov	w1, #0x1                // =1
    5840:      	mov	x0, x22
    5844:      	bl	0xd2d0 <sigsetjmp@plt>
    5848:      	cbz	w0, 0x5890 <.text+0x2a4>
    584c:      	mov	w8, #0x2                // =2
    5850:      	add	x1, sp, #0x8
    5854:      	mov	w2, w8
    5858:      	mov	w0, w21
    585c:      	bl	0xceb4 <bytehook_del_dlopen_callback+0x38c>
    5860:      	mov	w0, #-0x1               // =-1
    5864:      	ldr	x8, [x23, #0x28]
    5868:      	ldur	x9, [x29, #-0x8]
    586c:      	cmp	x8, x9
    5870:      	b.ne	0x58cc <.text+0x2e0>
    5874:      	ldp	x20, x19, [sp, #0x160]
    5878:      	ldp	x22, x21, [sp, #0x150]
    587c:      	ldp	x24, x23, [sp, #0x140]
    5880:      	ldr	x28, [sp, #0x130]
    5884:      	ldp	x29, x30, [sp, #0x120]
    5888:      	add	sp, sp, #0x170
    588c:      	ret
    5890:      	ldr	x8, [x24]
    5894:      	mov	w9, #0x3c0              // =960
    5898:      	movk	w9, #0xd65f, lsl #16
    589c:      	add	x1, sp, #0x8
    58a0:      	str	w9, [x8]
    58a4:      	ldr	x8, [x24, #0x8]
    58a8:      	mov	w0, w21
    58ac:      	str	w9, [x8]
    58b0:      	mov	w8, #0x2                // =2
    58b4:      	mov	w2, w8
    58b8:      	bl	0xceb4 <bytehook_del_dlopen_callback+0x38c>
    58bc:      	mov	x0, x19
    58c0:      	mov	x1, x20
    58c4:      	bl	0xd170 <bytehook_del_dlopen_callback+0x648>
    58c8:      	b	0x57ac <.text+0x1c0>
    58cc:      	bl	0xd2e0 <__stack_chk_fail@plt>
    58d0:      	sub	sp, sp, #0xf0
    58d4:      	stp	x29, x30, [sp, #0x90]
    58d8:      	stp	x28, x27, [sp, #0xa0]
    58dc:      	stp	x26, x25, [sp, #0xb0]
    58e0:      	stp	x24, x23, [sp, #0xc0]
    58e4:      	stp	x22, x21, [sp, #0xd0]
    58e8:      	stp	x20, x19, [sp, #0xe0]
    58ec:      	add	x29, sp, #0x90
    58f0:      	mrs	x26, TPIDR_EL0
    58f4:      	adrp	x9, 0x11000 <siglongjmp@plt+0x3870>
    58f8:      	ldr	x8, [x26, #0x28]
    58fc:      	ldr	x9, [x9, #0xaa0]
    5900:      	stur	x8, [x29, #-0x8]
    5904:      	cbz	x9, 0x59e4 <.text+0x3f8>
    5908:      	mov	w0, #0x7                // =7
    590c:      	bl	0xd2f0 <getauxval@plt>
    5910:      	cbz	x0, 0x59e4 <.text+0x3f8>
    5914:      	ldr	w8, [x0]
    5918:      	mov	w9, #0x457f             // =17791
    591c:      	movk	w9, #0x464c, lsl #16
    5920:      	mov	x23, x0
    5924:      	cmp	w8, w9
    5928:      	b.ne	0x59e4 <.text+0x3f8>
    592c:      	ldr	x9, [x23, #0x20]
    5930:      	ldrh	w8, [x23, #0x38]
    5934:      	mov	x20, #-0x1              // =-1
    5938:      	add	x9, x9, x23
    593c:      	add	x9, x9, #0x10
    5940:      	cbz	x8, 0x5968 <.text+0x37c>
    5944:      	ldur	w10, [x9, #-0x10]
    5948:      	cmp	w10, #0x1
    594c:      	b.ne	0x595c <.text+0x370>
    5950:      	ldr	x10, [x9]
    5954:      	cmp	x20, x10
    5958:      	csel	x20, x10, x20, hi
    595c:      	sub	x8, x8, #0x1
    5960:      	add	x9, x9, #0x38
    5964:      	cbnz	x8, 0x5944 <.text+0x358>
    5968:      	cmn	x20, #0x1
    596c:      	ccmp	x23, x20, #0x0, ne
    5970:      	b.lo	0x59e4 <.text+0x3f8>
    5974:      	mov	w0, #0x1                // =1
    5978:      	mov	w1, #0x30               // =48
    597c:      	bl	0xd300 <calloc@plt>
    5980:      	mov	x19, x0
    5984:      	cbz	x0, 0x59e8 <.text+0x3fc>
    5988:      	adrp	x0, 0x2000
    598c:      	sub	x8, x23, x20
    5990:      	add	x0, x0, #0x43d
    5994:      	mov	w1, #0x80000            // =524288
    5998:      	stp	x8, x23, [x19]
    599c:      	bl	0xd310 <__open_2@plt>
    59a0:      	tbnz	w0, #0x1f, 0x59dc <.text+0x3f0>
    59a4:      	add	x1, sp, #0x8
    59a8:      	mov	w20, w0
    59ac:      	bl	0xd320 <fstat@plt>
    59b0:      	cbz	w0, 0x5a1c <.text+0x430>
    59b4:      	mov	x23, xzr
    59b8:      	mov	x22, xzr
    59bc:      	mov	x21, xzr
    59c0:      	mov	w0, w20
    59c4:      	bl	0xd330 <close@plt>
    59c8:      	bl	0x5cd8 <.text+0x6ec>
    59cc:      	mov	x0, x22
    59d0:      	bl	0xd260 <free@plt>
    59d4:      	mov	x0, x23
    59d8:      	bl	0xd260 <free@plt>
    59dc:      	mov	x0, x19
    59e0:      	bl	0xd260 <free@plt>
    59e4:      	mov	x19, xzr
    59e8:      	ldr	x8, [x26, #0x28]
    59ec:      	ldur	x9, [x29, #-0x8]
    59f0:      	cmp	x8, x9
    59f4:      	b.ne	0x5b54 <.text+0x568>
    59f8:      	mov	x0, x19
    59fc:      	ldp	x20, x19, [sp, #0xe0]
    5a00:      	ldp	x22, x21, [sp, #0xd0]
    5a04:      	ldp	x24, x23, [sp, #0xc0]
    5a08:      	ldp	x26, x25, [sp, #0xb0]
    5a0c:      	ldp	x28, x27, [sp, #0xa0]
    5a10:      	ldp	x29, x30, [sp, #0x90]
    5a14:      	add	sp, sp, #0xf0
    5a18:      	ret
    5a1c:      	ldrh	w8, [x23, #0x3c]
    5a20:      	cbz	x8, 0x59b4 <.text+0x3c8>
    5a24:      	ldr	x24, [sp, #0x38]
    5a28:      	ldrh	w9, [x23, #0x3a]
    5a2c:      	ldr	x2, [x23, #0x28]
    5a30:      	mov	w0, w20
    5a34:      	mov	x1, x24
    5a38:      	mul	x3, x9, x8
    5a3c:      	bl	0x5c20 <.text+0x634>
    5a40:      	mov	x21, x0
    5a44:      	cbz	x0, 0x5ad8 <.text+0x4ec>
    5a48:      	ldrh	w8, [x23, #0x3e]
    5a4c:      	mov	w0, w20
    5a50:      	mov	x1, x24
    5a54:      	add	x2, x21, x8, lsl #6
    5a58:      	bl	0x5ccc <.text+0x6e0>
    5a5c:      	mov	x22, x0
    5a60:      	cbz	x0, 0x5ad0 <.text+0x4e4>
    5a64:      	ldrh	w27, [x23, #0x3c]
    5a68:      	adrp	x23, 0x2000
    5a6c:      	mov	x25, xzr
    5a70:      	add	x23, x23, #0xa15
    5a74:      	lsl	x28, x27, #6
    5a78:      	str	x24, [sp]
    5a7c:      	cmp	x28, x25
    5a80:      	b.eq	0x5ad0 <.text+0x4e4>
    5a84:      	add	x8, x21, x25
    5a88:      	ldr	w8, [x8, #0x4]
    5a8c:      	cmp	w8, #0x2
    5a90:      	b.ne	0x5ac8 <.text+0x4dc>
    5a94:      	ldr	w8, [x21, x25]
    5a98:      	mov	x0, x23
    5a9c:      	add	x1, x22, x8
    5aa0:      	bl	0xd340 <strcmp@plt>
    5aa4:      	cbnz	w0, 0x5ac8 <.text+0x4dc>
    5aa8:      	add	x8, x21, x25
    5aac:      	ldr	w24, [x8, #0x28]
    5ab0:      	cmp	w24, w27
    5ab4:      	b.hs	0x5ac8 <.text+0x4dc>
    5ab8:      	add	x8, x21, x24, lsl #6
    5abc:      	ldr	w8, [x8, #0x4]
    5ac0:      	cmp	w8, #0x3
    5ac4:      	b.eq	0x5ae4 <.text+0x4f8>
    5ac8:      	add	x25, x25, #0x40
    5acc:      	b	0x5a7c <.text+0x490>
    5ad0:      	mov	x23, xzr
    5ad4:      	b	0x59c0 <.text+0x3d4>
    5ad8:      	mov	x23, xzr
    5adc:      	mov	x22, xzr
    5ae0:      	b	0x59c0 <.text+0x3d4>
    5ae4:      	ldr	x27, [sp]
    5ae8:      	add	x25, x21, x25
    5aec:      	mov	w0, w20
    5af0:      	mov	x2, x25
    5af4:      	mov	x1, x27
    5af8:      	bl	0x5ccc <.text+0x6e0>
    5afc:      	mov	x23, x0
    5b00:      	str	x0, [x19, #0x10]
    5b04:      	cbz	x0, 0x59c0 <.text+0x3d4>
    5b08:      	ldr	x8, [x25, #0x20]
    5b0c:      	ldr	x9, [x25, #0x38]
    5b10:      	add	x25, x21, x24, lsl #6
    5b14:      	mov	w0, w20
    5b18:      	mov	x1, x27
    5b1c:      	udiv	x8, x8, x9
    5b20:      	mov	x2, x25
    5b24:      	str	x8, [x19, #0x18]
    5b28:      	bl	0x5ccc <.text+0x6e0>
    5b2c:      	str	x0, [x19, #0x20]
    5b30:      	cbz	x0, 0x59c0 <.text+0x3d4>
    5b34:      	ldr	x8, [x25, #0x20]
    5b38:      	mov	w0, w20
    5b3c:      	str	x8, [x19, #0x28]
    5b40:      	bl	0xd330 <close@plt>
    5b44:      	bl	0x5cd8 <.text+0x6ec>
    5b48:      	mov	x0, x22
    5b4c:      	bl	0xd260 <free@plt>
    5b50:      	b	0x59e8 <.text+0x3fc>
    5b54:      	bl	0xd2e0 <__stack_chk_fail@plt>
    5b58:      	stp	x29, x30, [sp, #-0x20]!
    5b5c:      	str	x19, [sp, #0x10]
    5b60:      	mov	x29, sp
    5b64:      	mov	x19, x0
    5b68:      	ldr	x0, [x0, #0x10]
    5b6c:      	bl	0xd260 <free@plt>
    5b70:      	ldr	x0, [x19, #0x20]
    5b74:      	bl	0xd260 <free@plt>
    5b78:      	mov	x0, x19
    5b7c:      	ldr	x19, [sp, #0x10]
    5b80:      	ldp	x29, x30, [sp], #0x20
    5b84:      	b	0xd260 <free@plt>
    5b88:      	stp	x29, x30, [sp, #-0x40]!
    5b8c:      	stp	x24, x23, [sp, #0x10]
    5b90:      	stp	x22, x21, [sp, #0x20]
    5b94:      	stp	x20, x19, [sp, #0x30]
    5b98:      	mov	x29, sp
    5b9c:      	ldr	x22, [x0, #0x18]
    5ba0:      	mov	x20, x1
    5ba4:      	mov	x19, x0
    5ba8:      	mov	x21, xzr
    5bac:      	mov	w23, #0xfefe            // =65278
    5bb0:      	cbz	x22, 0x5bf4 <.text+0x608>
    5bb4:      	ldr	x24, [x19, #0x10]
    5bb8:      	add	x8, x24, x21
    5bbc:      	ldrh	w8, [x8, #0x6]
    5bc0:      	sub	w8, w8, #0x1
    5bc4:      	cmp	w23, w8, uxth
    5bc8:      	b.lo	0x5be8 <.text+0x5fc>
    5bcc:      	ldr	w8, [x24, x21]
    5bd0:      	ldp	x9, x10, [x19, #0x20]
    5bd4:      	mov	x1, x20
    5bd8:      	add	x0, x9, x8
    5bdc:      	sub	x2, x10, x8
    5be0:      	bl	0xd350 <strncmp@plt>
    5be4:      	cbz	w0, 0x5bfc <.text+0x610>
    5be8:      	add	x21, x21, #0x18
    5bec:      	sub	x22, x22, #0x1
    5bf0:      	cbnz	x22, 0x5bb4 <.text+0x5c8>
    5bf4:      	mov	x0, xzr
    5bf8:      	b	0x5c0c <.text+0x620>
    5bfc:      	add	x9, x24, x21
    5c00:      	ldr	x8, [x19]
    5c04:      	ldr	x9, [x9, #0x8]
    5c08:      	add	x0, x9, x8
    5c0c:      	ldp	x20, x19, [sp, #0x30]
    5c10:      	ldp	x22, x21, [sp, #0x20]
    5c14:      	ldp	x24, x23, [sp, #0x10]
    5c18:      	ldp	x29, x30, [sp], #0x40
    5c1c:      	ret
    5c20:      	stp	x29, x30, [sp, #-0x30]!
    5c24:      	stp	x22, x21, [sp, #0x10]
    5c28:      	stp	x20, x19, [sp, #0x20]
    5c2c:      	mov	x29, sp
    5c30:      	mov	x21, xzr
    5c34:      	cbz	x3, 0x5cb8 <.text+0x6cc>
    5c38:      	add	x8, x3, x2
    5c3c:      	mov	x19, x3
    5c40:      	mov	x22, x2
    5c44:      	cmp	x8, x1
    5c48:      	b.hi	0x5cb8 <.text+0x6cc>
    5c4c:      	mov	x1, x22
    5c50:      	mov	w2, wzr
    5c54:      	mov	w20, w0
    5c58:      	bl	0xd360 <lseek@plt>
    5c5c:      	cmp	x0, x22
    5c60:      	b.ne	0x5cb4 <.text+0x6c8>
    5c64:      	mov	x0, x19
    5c68:      	bl	0xd270 <malloc@plt>
    5c6c:      	mov	x21, x0
    5c70:      	cbz	x0, 0x5cb8 <.text+0x6cc>
    5c74:      	bl	0xd370 <__errno@plt>
    5c78:      	mov	x22, x0
    5c7c:      	mov	x3, #-0x1               // =-1
    5c80:      	mov	w0, w20
    5c84:      	mov	x1, x21
    5c88:      	mov	x2, x19
    5c8c:      	str	wzr, [x22]
    5c90:      	bl	0xd380 <__read_chk@plt>
    5c94:      	cmn	x0, #0x1
    5c98:      	b.ne	0x5ca8 <.text+0x6bc>
    5c9c:      	ldr	w8, [x22]
    5ca0:      	cmp	w8, #0x4
    5ca4:      	b.eq	0x5c7c <.text+0x690>
    5ca8:      	cmp	x0, x19
    5cac:      	b.eq	0x5cb8 <.text+0x6cc>
    5cb0:      	bl	0x5cd8 <.text+0x6ec>
    5cb4:      	mov	x21, xzr
    5cb8:      	mov	x0, x21
    5cbc:      	ldp	x20, x19, [sp, #0x20]
    5cc0:      	ldp	x22, x21, [sp, #0x10]
    5cc4:      	ldp	x29, x30, [sp], #0x30
    5cc8:      	ret
    5ccc:      	ldp	x8, x3, [x2, #0x18]
    5cd0:      	mov	x2, x8
    5cd4:      	b	0x5c20 <.text+0x634>
    5cd8:      	mov	x0, x21
    5cdc:      	b	0xd260 <free@plt>
    5ce0:      	sub	sp, sp, #0xb0
    5ce4:      	stp	x29, x30, [sp, #0x70]
    5ce8:      	stp	x24, x23, [sp, #0x80]
    5cec:      	stp	x22, x21, [sp, #0x90]
    5cf0:      	stp	x20, x19, [sp, #0xa0]
    5cf4:      	add	x29, sp, #0x70
    5cf8:      	mrs	x22, TPIDR_EL0
    5cfc:      	ldr	x8, [x22, #0x28]
    5d00:      	mov	x19, x1
    5d04:      	mov	x20, x0
    5d08:      	stur	x8, [x29, #-0x8]
    5d0c:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    5d10:      	ldr	x8, [x8, #0xaa8]
    5d14:      	ldr	w8, [x8]
    5d18:      	cmp	w8, #0x4
    5d1c:      	b.ls	0x5e00 <.text+0x814>
    5d20:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    5d24:      	ldr	x8, [x8, #0xab0]
    5d28:      	cbnz	x8, 0x5d34 <.text+0x748>
    5d2c:      	mov	w21, #-0x1              // =-1
    5d30:      	b	0x5dcc <.text+0x7e0>
    5d34:      	adrp	x1, 0x2000
    5d38:      	add	x1, x1, #0x43d
    5d3c:      	add	x2, sp, #0x8
    5d40:      	mov	w0, #0x7                // =7
    5d44:      	bl	0x5e20 <.text+0x834>
    5d48:      	cbz	w0, 0x5dac <.text+0x7c0>
    5d4c:      	mov	x23, #-0x1              // =-1
    5d50:      	adrp	x1, 0x2000
    5d54:      	add	x1, x1, #0xb06
    5d58:      	add	x2, sp, #0x8
    5d5c:      	mov	w0, #0x3                // =3
    5d60:      	bl	0x5e20 <.text+0x834>
    5d64:      	cbz	w0, 0x5dc0 <.text+0x7d4>
    5d68:      	mov	x21, #-0x1              // =-1
    5d6c:      	bl	0xba68 <JNI_OnLoad+0x290c>
    5d70:      	sub	w24, w0, #0x15
    5d74:      	cmp	w24, #0x1
    5d78:      	b.hi	0x5d80 <.text+0x794>
    5d7c:      	bl	0x94e4 <JNI_OnLoad+0x388>
    5d80:      	adrp	x0, 0x5000
    5d84:      	add	x0, x0, #0xee4
    5d88:      	sub	x1, x29, #0x28
    5d8c:      	stp	x20, x19, [x29, #-0x28]
    5d90:      	stp	x23, x21, [x29, #-0x18]
    5d94:      	bl	0xd390 <dl_iterate_phdr@plt>
    5d98:      	cmp	w24, #0x1
    5d9c:      	mov	w21, w0
    5da0:      	b.hi	0x5dcc <.text+0x7e0>
    5da4:      	bl	0x94f8 <JNI_OnLoad+0x39c>
    5da8:      	b	0x5dcc <.text+0x7e0>
    5dac:      	bl	0x5f24 <.text+0x938>
    5db0:      	mov	w21, w0
    5db4:      	cbnz	w0, 0x5dcc <.text+0x7e0>
    5db8:      	ldr	x23, [sp, #0x8]
    5dbc:      	b	0x5d50 <.text+0x764>
    5dc0:      	bl	0x5f24 <.text+0x938>
    5dc4:      	mov	w21, w0
    5dc8:      	cbz	w0, 0x5df8 <.text+0x80c>
    5dcc:      	ldr	x8, [x22, #0x28]
    5dd0:      	ldur	x9, [x29, #-0x8]
    5dd4:      	cmp	x8, x9
    5dd8:      	b.ne	0x5e1c <.text+0x830>
    5ddc:      	mov	w0, w21
    5de0:      	ldp	x20, x19, [sp, #0xa0]
    5de4:      	ldp	x22, x21, [sp, #0x90]
    5de8:      	ldp	x24, x23, [sp, #0x80]
    5dec:      	ldp	x29, x30, [sp, #0x70]
    5df0:      	add	sp, sp, #0xb0
    5df4:      	ret
    5df8:      	ldr	x21, [sp, #0x8]
    5dfc:      	b	0x5d6c <.text+0x780>
    5e00:      	adrp	x1, 0x2000
    5e04:      	adrp	x2, 0x2000
    5e08:      	add	x1, x1, #0x94c
    5e0c:      	add	x2, x2, #0x7ec
    5e10:      	mov	w0, #0x4                // =4
    5e14:      	bl	0xd3a0 <__android_log_print@plt>
    5e18:      	b	0x5d20 <.text+0x734>
    5e1c:      	bl	0xd2e0 <__stack_chk_fail@plt>
    5e20:      	stp	x29, x30, [sp, #-0x30]!
    5e24:      	str	x21, [sp, #0x10]
    5e28:      	stp	x20, x19, [sp, #0x20]
    5e2c:      	mov	x29, sp
    5e30:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    5e34:      	ldr	x8, [x8, #0xaa0]
    5e38:      	cbz	x8, 0x5ec0 <.text+0x8d4>
    5e3c:      	mov	x19, x2
    5e40:      	mov	x20, x1
    5e44:      	mov	x21, x0
    5e48:      	bl	0xd2f0 <getauxval@plt>
    5e4c:      	cbz	x0, 0x5ec0 <.text+0x8d4>
    5e50:      	and	x8, x0, #0xfffffffffffff000
    5e54:      	cmp	x21, #0x3
    5e58:      	csel	x8, x8, x0, eq
    5e5c:      	ldr	w9, [x8]
    5e60:      	mov	w10, #0x457f            // =17791
    5e64:      	movk	w10, #0x464c, lsl #16
    5e68:      	cmp	w9, w10
    5e6c:      	b.ne	0x5ec0 <.text+0x8d4>
    5e70:      	ldr	x9, [x8, #0x20]
    5e74:      	add	x9, x9, x8
    5e78:      	str	x9, [x19, #0x10]
    5e7c:      	ldrh	w10, [x8, #0x38]
    5e80:      	add	x11, x9, #0x10
    5e84:      	mov	x9, #-0x1               // =-1
    5e88:      	strh	w10, [x19, #0x18]
    5e8c:      	cbz	x10, 0x5eb4 <.text+0x8c8>
    5e90:      	ldur	w12, [x11, #-0x10]
    5e94:      	cmp	w12, #0x1
    5e98:      	b.ne	0x5ea8 <.text+0x8bc>
    5e9c:      	ldr	x12, [x11]
    5ea0:      	cmp	x9, x12
    5ea4:      	csel	x9, x12, x9, hi
    5ea8:      	add	x11, x11, #0x38
    5eac:      	sub	x10, x10, #0x1
    5eb0:      	cbnz	x10, 0x5e90 <.text+0x8a4>
    5eb4:      	cmn	x9, #0x1
    5eb8:      	ccmp	x8, x9, #0x0, ne
    5ebc:      	b.hs	0x5ed4 <.text+0x8e8>
    5ec0:      	mov	w0, #-0x1               // =-1
    5ec4:      	ldp	x20, x19, [sp, #0x20]
    5ec8:      	ldr	x21, [sp, #0x10]
    5ecc:      	ldp	x29, x30, [sp], #0x30
    5ed0:      	ret
    5ed4:      	mov	w0, wzr
    5ed8:      	sub	x8, x8, x9
    5edc:      	stp	x8, x20, [x19]
    5ee0:      	b	0x5ec4 <.text+0x8d8>
    5ee4:      	ldr	x8, [x0]
    5ee8:      	cbz	x8, 0x5f14 <.text+0x928>
    5eec:      	ldr	x9, [x0, #0x8]
    5ef0:      	cbz	x9, 0x5f14 <.text+0x928>
    5ef4:      	ldrb	w9, [x9]
    5ef8:      	cbz	w9, 0x5f14 <.text+0x928>
    5efc:      	ldr	x9, [x2, #0x10]
    5f00:      	cmp	x9, x8
    5f04:      	b.eq	0x5f14 <.text+0x928>
    5f08:      	ldr	x9, [x2, #0x18]
    5f0c:      	cmp	x9, x8
    5f10:      	b.ne	0x5f1c <.text+0x930>
    5f14:      	mov	w0, wzr
    5f18:      	ret
    5f1c:      	ldp	x3, x2, [x2]
    5f20:      	br	x3
    5f24:      	add	x0, sp, #0x8
    5f28:      	mov	w1, #0x40               // =64
    5f2c:      	mov	x2, x19
    5f30:      	br	x20
    5f34:      	sub	sp, sp, #0x40
    5f38:      	stp	x29, x30, [sp, #0x10]
    5f3c:      	stp	x22, x21, [sp, #0x20]
    5f40:      	stp	x20, x19, [sp, #0x30]
    5f44:      	add	x29, sp, #0x10
    5f48:      	mrs	x21, TPIDR_EL0
    5f4c:      	ldr	x8, [x21, #0x28]
    5f50:      	adrp	x19, 0x15000
    5f54:      	str	x8, [sp, #0x8]
    5f58:      	ldrb	w8, [x19, #0xe78]
    5f5c:      	cmp	w8, #0x1
    5f60:      	b.ne	0x5f74 <.text+0x988>
    5f64:      	adrp	x8, 0x15000
    5f68:      	ldrb	w8, [x8, #0xe79]
    5f6c:      	sub	w19, w8, #0x1
    5f70:      	b	0x6174 <.text+0xb88>
    5f74:      	adrp	x20, 0x15000
    5f78:      	add	x20, x20, #0xe78
    5f7c:      	add	x0, x20, #0x48
    5f80:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    5f84:      	ldrb	w8, [x20]
    5f88:      	tbz	w8, #0x0, 0x5f9c <.text+0x9b0>
    5f8c:      	adrp	x8, 0x15000
    5f90:      	ldrb	w8, [x8, #0xe79]
    5f94:      	sub	w19, w8, #0x1
    5f98:      	b	0x6168 <.text+0xb7c>
    5f9c:      	adrp	x22, 0x11000 <siglongjmp@plt+0x3870>
    5fa0:      	ldr	x22, [x22, #0xaa8]
    5fa4:      	mov	w9, #0x1                // =1
    5fa8:      	strb	w9, [x19, #0xe78]
    5fac:      	ldr	w8, [x22]
    5fb0:      	cmp	w8, #0x4
    5fb4:      	b.ls	0x619c <.text+0xbb0>
    5fb8:      	bl	0xba68 <JNI_OnLoad+0x290c>
    5fbc:      	and	w8, w0, #0xfffffffe
    5fc0:      	mov	w19, w0
    5fc4:      	cmp	w8, #0x18
    5fc8:      	b.ne	0x6028 <.text+0xa3c>
    5fcc:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    5fd0:      	ldr	x8, [x8, #0xab8]
    5fd4:      	ldr	x8, [x8]
    5fd8:      	cbz	x8, 0x6034 <.text+0xa48>
    5fdc:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    5fe0:      	ldr	x8, [x8, #0xac0]
    5fe4:      	ldr	x8, [x8]
    5fe8:      	cbnz	x8, 0x6034 <.text+0xa48>
    5fec:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    5ff0:      	ldr	x8, [x8, #0xac8]
    5ff4:      	ldr	x8, [x8]
    5ff8:      	cbz	x8, 0x6034 <.text+0xa48>
    5ffc:      	adrp	x0, 0x15000
    6000:      	adrp	x1, 0x6000 <.text+0xa14>
    6004:      	add	x0, x0, #0xe7c
    6008:      	add	x1, x1, #0x36c
    600c:      	bl	0xd3c0 <pthread_key_create@plt>
    6010:      	cbz	w0, 0x6034 <.text+0xa48>
    6014:      	ldr	w8, [x22]
    6018:      	cmp	w8, #0x6
    601c:      	b.ls	0x61d4 <.text+0xbe8>
    6020:      	mov	w19, #-0x1              // =-1
    6024:      	b	0x6168 <.text+0xb7c>
    6028:      	sub	w8, w19, #0x10
    602c:      	cmp	w8, #0x9
    6030:      	b.hi	0x60bc <.text+0xad0>
    6034:      	bl	0xd3d0 <bytehook_get_mode@plt>
    6038:      	adrp	x8, 0x6000 <.text+0xa14>
    603c:      	add	x8, x8, #0x4d4
    6040:      	cmp	w0, #0x1
    6044:      	adrp	x1, 0x2000
    6048:      	adrp	x2, 0x6000 <.text+0xa14>
    604c:      	csel	x3, x8, xzr, eq
    6050:      	add	x1, x1, #0xa1d
    6054:      	add	x2, x2, #0x370
    6058:      	bl	0x6aec <.text+0x1500>
    605c:      	cbz	x0, 0x6070 <.text+0xa84>
    6060:      	mov	x20, x0
    6064:      	bl	0xb270 <JNI_OnLoad+0x2114>
    6068:      	mov	x0, x20
    606c:      	bl	0xb30c <JNI_OnLoad+0x21b0>
    6070:      	sub	w8, w19, #0x15
    6074:      	cmp	w8, #0x4
    6078:      	b.hi	0x614c <.text+0xb60>
    607c:      	bl	0xd3d0 <bytehook_get_mode@plt>
    6080:      	adrp	x8, 0x6000 <.text+0xa14>
    6084:      	add	x8, x8, #0x650
    6088:      	cmp	w0, #0x1
    608c:      	adrp	x1, 0x2000
    6090:      	adrp	x2, 0x6000 <.text+0xa14>
    6094:      	csel	x3, x8, xzr, eq
    6098:      	add	x1, x1, #0x482
    609c:      	add	x2, x2, #0x4f0
    60a0:      	bl	0x6aec <.text+0x1500>
    60a4:      	cbz	x0, 0x614c <.text+0xb60>
    60a8:      	mov	x19, x0
    60ac:      	bl	0xb270 <JNI_OnLoad+0x2114>
    60b0:      	mov	x0, x19
    60b4:      	bl	0xb30c <JNI_OnLoad+0x21b0>
    60b8:      	b	0x614c <.text+0xb60>
    60bc:      	cmp	w19, #0x1a
    60c0:      	b.lt	0x614c <.text+0xb60>
    60c4:      	bl	0xd3d0 <bytehook_get_mode@plt>
    60c8:      	adrp	x8, 0x6000 <.text+0xa14>
    60cc:      	add	x8, x8, #0x720
    60d0:      	cmp	w0, #0x1
    60d4:      	adrp	x0, 0x2000
    60d8:      	adrp	x2, 0x2000
    60dc:      	adrp	x3, 0x6000 <.text+0xa14>
    60e0:      	csel	x4, x8, xzr, eq
    60e4:      	add	x0, x0, #0x350
    60e8:      	add	x2, x2, #0x359
    60ec:      	add	x3, x3, #0x66c
    60f0:      	bl	0x6afc <.text+0x1510>
    60f4:      	str	x0, [sp]
    60f8:      	cbz	x0, 0x6108 <.text+0xb1c>
    60fc:      	bl	0xad20 <JNI_OnLoad+0x1bc4>
    6100:      	mov	x0, sp
    6104:      	bl	0xaccc <JNI_OnLoad+0x1b70>
    6108:      	bl	0xd3d0 <bytehook_get_mode@plt>
    610c:      	adrp	x8, 0x6000 <.text+0xa14>
    6110:      	add	x8, x8, #0x804
    6114:      	cmp	w0, #0x1
    6118:      	adrp	x0, 0x2000
    611c:      	adrp	x2, 0x2000
    6120:      	adrp	x3, 0x6000 <.text+0xa14>
    6124:      	csel	x4, x8, xzr, eq
    6128:      	add	x0, x0, #0x350
    612c:      	add	x2, x2, #0x9d6
    6130:      	add	x3, x3, #0x73c
    6134:      	bl	0x6afc <.text+0x1510>
    6138:      	str	x0, [sp]
    613c:      	cbz	x0, 0x614c <.text+0xb60>
    6140:      	bl	0xad20 <JNI_OnLoad+0x1bc4>
    6144:      	mov	x0, sp
    6148:      	bl	0xaccc <JNI_OnLoad+0x1b70>
    614c:      	ldr	w8, [x22]
    6150:      	adrp	x9, 0x15000
    6154:      	mov	w10, #0x1               // =1
    6158:      	strb	w10, [x9, #0xe79]
    615c:      	cmp	w8, #0x4
    6160:      	b.ls	0x61b8 <.text+0xbcc>
    6164:      	mov	w19, wzr
    6168:      	adrp	x0, 0x15000
    616c:      	add	x0, x0, #0xec0
    6170:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    6174:      	ldr	x8, [x21, #0x28]
    6178:      	ldr	x9, [sp, #0x8]
    617c:      	cmp	x8, x9
    6180:      	b.ne	0x61f0 <.text+0xc04>
    6184:      	mov	w0, w19
    6188:      	ldp	x20, x19, [sp, #0x30]
    618c:      	ldp	x22, x21, [sp, #0x20]
    6190:      	ldp	x29, x30, [sp, #0x10]
    6194:      	add	sp, sp, #0x40
    6198:      	ret
    619c:      	adrp	x1, 0x2000
    61a0:      	adrp	x2, 0x2000
    61a4:      	add	x1, x1, #0x94c
    61a8:      	add	x2, x2, #0x9c1
    61ac:      	mov	w0, #0x4                // =4
    61b0:      	bl	0xd3a0 <__android_log_print@plt>
    61b4:      	b	0x5fb8 <.text+0x9cc>
    61b8:      	adrp	x1, 0x2000
    61bc:      	adrp	x2, 0x2000
    61c0:      	add	x1, x1, #0x94c
    61c4:      	add	x2, x2, #0xa6c
    61c8:      	mov	w0, #0x4                // =4
    61cc:      	bl	0xd3a0 <__android_log_print@plt>
    61d0:      	b	0x6164 <.text+0xb78>
    61d4:      	adrp	x1, 0x2000
    61d8:      	adrp	x2, 0x2000
    61dc:      	add	x1, x1, #0x94c
    61e0:      	add	x2, x2, #0xad1
    61e4:      	mov	w0, #0x6                // =6
    61e8:      	bl	0xd3a0 <__android_log_print@plt>
    61ec:      	b	0x6020 <.text+0xa34>
    61f0:      	bl	0xd2e0 <__stack_chk_fail@plt>
    61f4:      	stp	x29, x30, [sp, #-0x30]!
    61f8:      	stp	x22, x21, [sp, #0x10]
    61fc:      	stp	x20, x19, [sp, #0x20]
    6200:      	mov	x29, sp
    6204:      	mov	x20, x2
    6208:      	mov	x21, x1
    620c:      	mov	x22, x0
    6210:      	cbnz	x0, 0x6218 <.text+0xc2c>
    6214:      	cbz	x21, 0x6274 <.text+0xc88>
    6218:      	mov	w0, #0x28               // =40
    621c:      	bl	0xd270 <malloc@plt>
    6220:      	cbz	x0, 0x6274 <.text+0xc88>
    6224:      	mov	x19, x0
    6228:      	stp	x22, x21, [x0]
    622c:      	str	x20, [x0, #0x10]
    6230:      	bl	0x5f34 <.text+0x948>
    6234:      	bl	0x6b20 <.text+0x1534>
    6238:      	adrp	x8, 0x15000
    623c:      	add	x8, x8, #0xdd8
    6240:      	ldr	x8, [x8]
    6244:      	cbz	x8, 0x6280 <.text+0xc94>
    6248:      	ldr	x9, [x8]
    624c:      	cmp	x9, x22
    6250:      	b.ne	0x626c <.text+0xc80>
    6254:      	ldr	x9, [x8, #0x8]
    6258:      	cmp	x9, x21
    625c:      	b.ne	0x626c <.text+0xc80>
    6260:      	ldr	x9, [x8, #0x10]
    6264:      	cmp	x9, x20
    6268:      	b.eq	0x62a0 <.text+0xcb4>
    626c:      	add	x8, x8, #0x18
    6270:      	b	0x6240 <.text+0xc54>
    6274:      	bl	0x6ab0 <.text+0x14c4>
    6278:      	ldp	x29, x30, [sp], #0x30
    627c:      	ret
    6280:      	adrp	x8, 0x15000
    6284:      	ldr	x9, [x8, #0xde0]
    6288:      	mov	x10, x19
    628c:      	str	xzr, [x10, #0x18]!
    6290:      	str	x9, [x19, #0x20]
    6294:      	str	x19, [x9]
    6298:      	mov	x19, xzr
    629c:      	str	x10, [x8, #0xde0]
    62a0:      	bl	0x6ac8 <.text+0x14dc>
    62a4:      	bl	0xd3f0 <pthread_rwlock_unlock@plt>
    62a8:      	mov	x0, x19
    62ac:      	bl	0x6ab0 <.text+0x14c4>
    62b0:      	ldp	x29, x30, [sp], #0x30
    62b4:      	b	0xd260 <free@plt>
    62b8:      	stp	x29, x30, [sp, #-0x30]!
    62bc:      	stp	x22, x21, [sp, #0x10]
    62c0:      	stp	x20, x19, [sp, #0x20]
    62c4:      	mov	x29, sp
    62c8:      	mov	x20, x2
    62cc:      	mov	x21, x1
    62d0:      	mov	x22, x0
    62d4:      	cbnz	x0, 0x62e8 <.text+0xcfc>
    62d8:      	cbnz	x21, 0x62e8 <.text+0xcfc>
    62dc:      	bl	0x6ab0 <.text+0x14c4>
    62e0:      	ldp	x29, x30, [sp], #0x30
    62e4:      	ret
    62e8:      	bl	0x6b20 <.text+0x1534>
    62ec:      	adrp	x8, 0x15000
    62f0:      	ldr	x8, [x8, #0xdd8]
    62f4:      	cbz	x8, 0x6338 <.text+0xd4c>
    62f8:      	ldr	x9, [x8]
    62fc:      	mov	x19, x8
    6300:      	ldr	x8, [x8, #0x18]
    6304:      	cmp	x9, x22
    6308:      	b.ne	0x62f4 <.text+0xd08>
    630c:      	ldr	x9, [x19, #0x8]
    6310:      	cmp	x9, x21
    6314:      	b.ne	0x62f4 <.text+0xd08>
    6318:      	ldr	x9, [x19, #0x10]
    631c:      	cmp	x9, x20
    6320:      	b.ne	0x62f4 <.text+0xd08>
    6324:      	ldr	x9, [x19, #0x20]
    6328:      	cbz	x8, 0x6348 <.text+0xd5c>
    632c:      	str	x9, [x8, #0x20]
    6330:      	ldr	x9, [x19, #0x20]
    6334:      	b	0x6350 <.text+0xd64>
    6338:      	bl	0x6ab0 <.text+0x14c4>
    633c:      	bl	0x6ac8 <.text+0x14dc>
    6340:      	ldp	x29, x30, [sp], #0x30
    6344:      	b	0xd3f0 <pthread_rwlock_unlock@plt>
    6348:      	adrp	x10, 0x15000
    634c:      	str	x9, [x10, #0xde0]
    6350:      	bl	0x6ac8 <.text+0x14dc>
    6354:      	str	x8, [x9]
    6358:      	bl	0xd3f0 <pthread_rwlock_unlock@plt>
    635c:      	mov	x0, x19
    6360:      	bl	0x6ab0 <.text+0x14c4>
    6364:      	ldp	x29, x30, [sp], #0x30
    6368:      	b	0xd260 <free@plt>
    636c:      	b	0xd260 <free@plt>
    6370:      	stp	x29, x30, [sp, #-0x30]!
    6374:      	stp	x22, x21, [sp, #0x10]
    6378:      	stp	x20, x19, [sp, #0x20]
    637c:      	mov	x29, sp
    6380:      	mov	x19, x30
    6384:      	mov	w21, w1
    6388:      	bl	0x6ae4 <.text+0x14f8>
    638c:      	bl	0xba68 <JNI_OnLoad+0x290c>
    6390:      	and	w8, w0, #0xfffffff8
    6394:      	cmp	w8, #0x10
    6398:      	b.ne	0x63b4 <.text+0xdc8>
    639c:      	bl	0xd3d0 <bytehook_get_mode@plt>
    63a0:      	cmp	w0, #0x1
    63a4:      	b.ne	0x63d8 <.text+0xdec>
    63a8:      	adrp	x8, 0x15000
    63ac:      	ldr	x8, [x8, #0xea0]
    63b0:      	b	0x63e8 <.text+0xdfc>
    63b4:      	and	w8, w0, #0xfffffffe
    63b8:      	cmp	w8, #0x18
    63bc:      	b.ne	0x63f8 <.text+0xe0c>
    63c0:      	bl	0xd3d0 <bytehook_get_mode@plt>
    63c4:      	cbz	w0, 0x6404 <.text+0xe18>
    63c8:      	mov	x30, x19
    63cc:      	xpaclri
    63d0:      	mov	x22, x30
    63d4:      	b	0x640c <.text+0xe20>
    63d8:      	adrp	x0, 0x6000 <.text+0xa14>
    63dc:      	add	x0, x0, #0x370
    63e0:      	bl	0xd400 <bytehook_get_prev_func@plt>
    63e4:      	mov	x8, x0
    63e8:      	mov	x0, x20
    63ec:      	mov	w1, w21
    63f0:      	blr	x8
    63f4:      	b	0x6430 <.text+0xe44>
    63f8:      	mov	x21, xzr
    63fc:      	cbnz	x21, 0x6438 <.text+0xe4c>
    6400:      	b	0x6454 <.text+0xe68>
    6404:      	bl	0xd410 <bytehook_get_return_address@plt>
    6408:      	mov	x22, x0
    640c:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    6410:      	ldr	x8, [x8, #0xad0]
    6414:      	ldr	x8, [x8]
    6418:      	cbz	x8, 0x6480 <.text+0xe94>
    641c:      	mov	x0, x20
    6420:      	mov	w1, w21
    6424:      	mov	x2, xzr
    6428:      	mov	x3, x22
    642c:      	blr	x8
    6430:      	mov	x21, x0
    6434:      	cbz	x21, 0x6454 <.text+0xe68>
    6438:      	bl	0x6b2c <.text+0x1540>
    643c:      	cbz	x8, 0x6454 <.text+0xe68>
    6440:      	bl	0x950c <JNI_OnLoad+0x3b0>
    6444:      	tbnz	w0, #0x0, 0x6454 <.text+0xe68>
    6448:      	bl	0x6a9c <.text+0x14b0>
    644c:      	b.ls	0x64bc <.text+0xed0>
    6450:      	bl	0x6a7c <.text+0x1490>
    6454:      	bl	0x6a8c <.text+0x14a0>
    6458:      	bl	0xd3d0 <bytehook_get_mode@plt>
    645c:      	cbnz	w0, 0x6470 <.text+0xe84>
    6460:      	mov	x30, x19
    6464:      	xpaclri
    6468:      	mov	x0, x30
    646c:      	bl	0xd420 <bytehook_pop_stack@plt>
    6470:      	mov	x0, x21
    6474:      	bl	0x6ab0 <.text+0x14c4>
    6478:      	ldp	x29, x30, [sp], #0x30
    647c:      	ret
    6480:      	bl	0x94e4 <JNI_OnLoad+0x388>
    6484:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    6488:      	ldr	x8, [x8, #0xab8]
    648c:      	mov	x0, x20
    6490:      	mov	w1, w21
    6494:      	mov	x2, xzr
    6498:      	ldr	x8, [x8]
    649c:      	mov	x3, x22
    64a0:      	blr	x8
    64a4:      	mov	x21, x0
    64a8:      	cbnz	x0, 0x64b0 <.text+0xec4>
    64ac:      	bl	0x688c <.text+0x12a0>
    64b0:      	bl	0x94f8 <JNI_OnLoad+0x39c>
    64b4:      	cbnz	x21, 0x6438 <.text+0xe4c>
    64b8:      	b	0x6454 <.text+0xe68>
    64bc:      	adrp	x1, 0x2000
    64c0:      	adrp	x2, 0x2000
    64c4:      	add	x1, x1, #0x94c
    64c8:      	add	x2, x2, #0x704
    64cc:      	bl	0x6abc <.text+0x14d0>
    64d0:      	b	0x6450 <.text+0xe64>
    64d4:      	adrp	x8, 0x15000
    64d8:      	ldr	x9, [x8, #0xea0]
    64dc:      	cmp	w1, #0x17
    64e0:      	ccmp	x9, x5, #0x4, eq
    64e4:      	b.eq	0x64ec <.text+0xf00>
    64e8:      	str	x5, [x8, #0xea0]
    64ec:      	ret
    64f0:      	stp	x29, x30, [sp, #-0x40]!
    64f4:      	str	x23, [sp, #0x10]
    64f8:      	stp	x22, x21, [sp, #0x20]
    64fc:      	stp	x20, x19, [sp, #0x30]
    6500:      	mov	x29, sp
    6504:      	mov	x19, x30
    6508:      	mov	x21, x2
    650c:      	mov	w22, w1
    6510:      	bl	0x6ae4 <.text+0x14f8>
    6514:      	bl	0xba68 <JNI_OnLoad+0x290c>
    6518:      	sub	w8, w0, #0x15
    651c:      	cmp	w8, #0x2
    6520:      	b.hi	0x653c <.text+0xf50>
    6524:      	bl	0xd3d0 <bytehook_get_mode@plt>
    6528:      	cmp	w0, #0x1
    652c:      	b.ne	0x6560 <.text+0xf74>
    6530:      	adrp	x8, 0x15000
    6534:      	ldr	x8, [x8, #0xea8]
    6538:      	b	0x6570 <.text+0xf84>
    653c:      	and	w8, w0, #0xfffffffe
    6540:      	cmp	w8, #0x18
    6544:      	b.ne	0x6578 <.text+0xf8c>
    6548:      	bl	0xd3d0 <bytehook_get_mode@plt>
    654c:      	cbz	w0, 0x6584 <.text+0xf98>
    6550:      	mov	x30, x19
    6554:      	xpaclri
    6558:      	mov	x23, x30
    655c:      	b	0x658c <.text+0xfa0>
    6560:      	adrp	x0, 0x6000 <.text+0xa14>
    6564:      	add	x0, x0, #0x4f0
    6568:      	bl	0xd400 <bytehook_get_prev_func@plt>
    656c:      	mov	x8, x0
    6570:      	bl	0x6ad4 <.text+0x14e8>
    6574:      	b	0x65b0 <.text+0xfc4>
    6578:      	mov	x21, xzr
    657c:      	cbnz	x21, 0x65b8 <.text+0xfcc>
    6580:      	b	0x65d4 <.text+0xfe8>
    6584:      	bl	0xd410 <bytehook_get_return_address@plt>
    6588:      	mov	x23, x0
    658c:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    6590:      	ldr	x8, [x8, #0xad0]
    6594:      	ldr	x8, [x8]
    6598:      	cbz	x8, 0x65fc <.text+0x1010>
    659c:      	mov	x0, x20
    65a0:      	mov	w1, w22
    65a4:      	mov	x2, x21
    65a8:      	mov	x3, x23
    65ac:      	blr	x8
    65b0:      	mov	x21, x0
    65b4:      	cbz	x21, 0x65d4 <.text+0xfe8>
    65b8:      	bl	0x6b2c <.text+0x1540>
    65bc:      	cbz	x8, 0x65d4 <.text+0xfe8>
    65c0:      	bl	0x950c <JNI_OnLoad+0x3b0>
    65c4:      	tbnz	w0, #0x0, 0x65d4 <.text+0xfe8>
    65c8:      	bl	0x6a9c <.text+0x14b0>
    65cc:      	b.ls	0x6638 <.text+0x104c>
    65d0:      	bl	0x6a7c <.text+0x1490>
    65d4:      	bl	0x6a8c <.text+0x14a0>
    65d8:      	bl	0xd3d0 <bytehook_get_mode@plt>
    65dc:      	cbnz	w0, 0x65f0 <.text+0x1004>
    65e0:      	mov	x30, x19
    65e4:      	xpaclri
    65e8:      	mov	x0, x30
    65ec:      	bl	0xd420 <bytehook_pop_stack@plt>
    65f0:      	bl	0x6b0c <.text+0x1520>
    65f4:      	ldp	x29, x30, [sp], #0x40
    65f8:      	ret
    65fc:      	bl	0x94e4 <JNI_OnLoad+0x388>
    6600:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    6604:      	ldr	x8, [x8, #0xab8]
    6608:      	mov	x0, x20
    660c:      	mov	w1, w22
    6610:      	mov	x2, x21
    6614:      	ldr	x8, [x8]
    6618:      	mov	x3, x23
    661c:      	blr	x8
    6620:      	mov	x21, x0
    6624:      	cbnz	x0, 0x662c <.text+0x1040>
    6628:      	bl	0x688c <.text+0x12a0>
    662c:      	bl	0x94f8 <JNI_OnLoad+0x39c>
    6630:      	cbnz	x21, 0x65b8 <.text+0xfcc>
    6634:      	b	0x65d4 <.text+0xfe8>
    6638:      	adrp	x1, 0x2000
    663c:      	adrp	x2, 0x2000
    6640:      	add	x1, x1, #0x94c
    6644:      	add	x2, x2, #0x684
    6648:      	bl	0x6abc <.text+0x14d0>
    664c:      	b	0x65d0 <.text+0xfe4>
    6650:      	adrp	x8, 0x15000
    6654:      	ldr	x9, [x8, #0xea8]
    6658:      	cmp	w1, #0x17
    665c:      	ccmp	x9, x5, #0x4, eq
    6660:      	b.eq	0x6668 <.text+0x107c>
    6664:      	str	x5, [x8, #0xea8]
    6668:      	ret
    666c:      	stp	x29, x30, [sp, #-0x30]!
    6670:      	stp	x22, x21, [sp, #0x10]
    6674:      	stp	x20, x19, [sp, #0x20]
    6678:      	mov	x29, sp
    667c:      	mov	x19, x30
    6680:      	mov	x21, x2
    6684:      	mov	w22, w1
    6688:      	bl	0x6ae4 <.text+0x14f8>
    668c:      	bl	0xd3d0 <bytehook_get_mode@plt>
    6690:      	cmp	w0, #0x1
    6694:      	b.ne	0x66a4 <.text+0x10b8>
    6698:      	adrp	x8, 0x15000
    669c:      	ldr	x8, [x8, #0xeb0]
    66a0:      	b	0x66b4 <.text+0x10c8>
    66a4:      	adrp	x0, 0x6000 <.text+0xa14>
    66a8:      	add	x0, x0, #0x66c
    66ac:      	bl	0xd400 <bytehook_get_prev_func@plt>
    66b0:      	mov	x8, x0
    66b4:      	bl	0x6ad4 <.text+0x14e8>
    66b8:      	mov	x21, x0
    66bc:      	cbz	x0, 0x66dc <.text+0x10f0>
    66c0:      	bl	0x6b2c <.text+0x1540>
    66c4:      	cbz	x8, 0x66dc <.text+0x10f0>
    66c8:      	bl	0x950c <JNI_OnLoad+0x3b0>
    66cc:      	tbnz	w0, #0x0, 0x66dc <.text+0x10f0>
    66d0:      	bl	0x6a9c <.text+0x14b0>
    66d4:      	b.ls	0x6708 <.text+0x111c>
    66d8:      	bl	0x6a7c <.text+0x1490>
    66dc:      	bl	0x6a8c <.text+0x14a0>
    66e0:      	bl	0xd3d0 <bytehook_get_mode@plt>
    66e4:      	cbnz	w0, 0x66f8 <.text+0x110c>
    66e8:      	mov	x30, x19
    66ec:      	xpaclri
    66f0:      	mov	x0, x30
    66f4:      	bl	0xd420 <bytehook_pop_stack@plt>
    66f8:      	mov	x0, x21
    66fc:      	bl	0x6ab0 <.text+0x14c4>
    6700:      	ldp	x29, x30, [sp], #0x30
    6704:      	ret
    6708:      	adrp	x1, 0x2000
    670c:      	adrp	x2, 0x2000
    6710:      	add	x1, x1, #0x94c
    6714:      	add	x2, x2, #0xc73
    6718:      	bl	0x6abc <.text+0x14d0>
    671c:      	b	0x66d8 <.text+0x10ec>
    6720:      	adrp	x8, 0x15000
    6724:      	ldr	x9, [x8, #0xeb0]
    6728:      	cmp	w1, #0x17
    672c:      	ccmp	x9, x5, #0x4, eq
    6730:      	b.eq	0x6738 <.text+0x114c>
    6734:      	str	x5, [x8, #0xeb0]
    6738:      	ret
    673c:      	stp	x29, x30, [sp, #-0x40]!
    6740:      	str	x23, [sp, #0x10]
    6744:      	stp	x22, x21, [sp, #0x20]
    6748:      	stp	x20, x19, [sp, #0x30]
    674c:      	mov	x29, sp
    6750:      	mov	x19, x30
    6754:      	mov	x21, x3
    6758:      	mov	x22, x2
    675c:      	mov	w23, w1
    6760:      	bl	0x6ae4 <.text+0x14f8>
    6764:      	bl	0xd3d0 <bytehook_get_mode@plt>
    6768:      	cmp	w0, #0x1
    676c:      	b.ne	0x677c <.text+0x1190>
    6770:      	adrp	x8, 0x15000
    6774:      	ldr	x8, [x8, #0xeb8]
    6778:      	b	0x678c <.text+0x11a0>
    677c:      	adrp	x0, 0x6000 <.text+0xa14>
    6780:      	add	x0, x0, #0x73c
    6784:      	bl	0xd400 <bytehook_get_prev_func@plt>
    6788:      	mov	x8, x0
    678c:      	mov	x0, x20
    6790:      	mov	w1, w23
    6794:      	mov	x2, x22
    6798:      	mov	x3, x21
    679c:      	blr	x8
    67a0:      	mov	x21, x0
    67a4:      	cbz	x0, 0x67c4 <.text+0x11d8>
    67a8:      	bl	0x6b2c <.text+0x1540>
    67ac:      	cbz	x8, 0x67c4 <.text+0x11d8>
    67b0:      	bl	0x950c <JNI_OnLoad+0x3b0>
    67b4:      	tbnz	w0, #0x0, 0x67c4 <.text+0x11d8>
    67b8:      	bl	0x6a9c <.text+0x14b0>
    67bc:      	b.ls	0x67ec <.text+0x1200>
    67c0:      	bl	0x6a7c <.text+0x1490>
    67c4:      	bl	0x6a8c <.text+0x14a0>
    67c8:      	bl	0xd3d0 <bytehook_get_mode@plt>
    67cc:      	cbnz	w0, 0x67e0 <.text+0x11f4>
    67d0:      	mov	x30, x19
    67d4:      	xpaclri
    67d8:      	mov	x0, x30
    67dc:      	bl	0xd420 <bytehook_pop_stack@plt>
    67e0:      	bl	0x6b0c <.text+0x1520>
    67e4:      	ldp	x29, x30, [sp], #0x40
    67e8:      	ret
    67ec:      	adrp	x1, 0x2000
    67f0:      	adrp	x2, 0x2000
    67f4:      	add	x1, x1, #0x94c
    67f8:      	add	x2, x2, #0x495
    67fc:      	bl	0x6abc <.text+0x14d0>
    6800:      	b	0x67c0 <.text+0x11d4>
    6804:      	adrp	x8, 0x15000
    6808:      	ldr	x9, [x8, #0xeb8]
    680c:      	cmp	w1, #0x17
    6810:      	ccmp	x9, x5, #0x4, eq
    6814:      	b.eq	0x681c <.text+0x1230>
    6818:      	str	x5, [x8, #0xeb8]
    681c:      	ret
    6820:      	stp	x29, x30, [sp, #-0x20]!
    6824:      	stp	x20, x19, [sp, #0x10]
    6828:      	mov	x29, sp
    682c:      	adrp	x8, 0x15000
    6830:      	ldr	x8, [x8, #0xdd8]
    6834:      	cbz	x8, 0x6880 <.text+0x1294>
    6838:      	mov	x19, x0
    683c:      	bl	0x6ac8 <.text+0x14dc>
    6840:      	bl	0xd430 <pthread_rwlock_rdlock@plt>
    6844:      	adrp	x8, 0x15000
    6848:      	add	x8, x8, #0xdd8
    684c:      	ldr	x20, [x8]
    6850:      	cbz	x20, 0x6870 <.text+0x1284>
    6854:      	ldr	x8, [x20]
    6858:      	cbz	x8, 0x6868 <.text+0x127c>
    685c:      	ldr	x1, [x20, #0x10]
    6860:      	mov	x0, x19
    6864:      	blr	x8
    6868:      	add	x8, x20, #0x18
    686c:      	b	0x684c <.text+0x1260>
    6870:      	ldp	x20, x19, [sp, #0x10]
    6874:      	bl	0x6ac8 <.text+0x14dc>
    6878:      	ldp	x29, x30, [sp], #0x20
    687c:      	b	0xd3f0 <pthread_rwlock_unlock@plt>
    6880:      	ldp	x20, x19, [sp, #0x10]
    6884:      	ldp	x29, x30, [sp], #0x20
    6888:      	ret
    688c:      	stp	x29, x30, [sp, #-0x30]!
    6890:      	stp	x22, x21, [sp, #0x10]
    6894:      	stp	x20, x19, [sp, #0x20]
    6898:      	mov	x29, sp
    689c:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    68a0:      	ldr	x8, [x8, #0xac8]
    68a4:      	ldr	x8, [x8]
    68a8:      	cbz	x8, 0x68b8 <.text+0x12cc>
    68ac:      	blr	x8
    68b0:      	mov	x19, x0
    68b4:      	b	0x68c0 <.text+0x12d4>
    68b8:      	adrp	x19, 0x2000
    68bc:      	add	x19, x19, #0xb30
    68c0:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    68c4:      	ldr	x8, [x8, #0xac0]
    68c8:      	ldr	x2, [x8]
    68cc:      	cbz	x2, 0x68e8 <.text+0x12fc>
    68d0:      	mov	x1, x19
    68d4:      	bl	0x6ab0 <.text+0x14c4>
    68d8:      	adrp	x0, 0x2000
    68dc:      	add	x0, x0, #0xc12
    68e0:      	ldp	x29, x30, [sp], #0x30
    68e4:      	br	x2
    68e8:      	ldrb	w8, [x19]
    68ec:      	mrs	x21, TPIDR_EL0
    68f0:      	cbz	w8, 0x6940 <.text+0x1354>
    68f4:      	adrp	x22, 0x15000
    68f8:      	ldr	w0, [x22, #0xe7c]
    68fc:      	bl	0xd440 <pthread_getspecific@plt>
    6900:      	mov	x20, x0
    6904:      	cbnz	x0, 0x6924 <.text+0x1338>
    6908:      	mov	w0, #0x100              // =256
    690c:      	bl	0xd270 <malloc@plt>
    6910:      	cbz	x0, 0x6940 <.text+0x1354>
    6914:      	mov	x20, x0
    6918:      	ldr	w0, [x22, #0xe7c]
    691c:      	mov	x1, x20
    6920:      	bl	0xd450 <pthread_setspecific@plt>
    6924:      	adrp	x4, 0x2000
    6928:      	add	x4, x4, #0xc12
    692c:      	mov	x1, #-0x1               // =-1
    6930:      	mov	x0, x20
    6934:      	mov	x5, x19
    6938:      	bl	0x69d8 <.text+0x13ec>
    693c:      	b	0x6948 <.text+0x135c>
    6940:      	adrp	x20, 0x2000
    6944:      	add	x20, x20, #0xc12
    6948:      	str	x20, [x21, #0x30]
    694c:      	bl	0x6ab0 <.text+0x14c4>
    6950:      	ldp	x29, x30, [sp], #0x30
    6954:      	ret
    6958:      	stp	x29, x30, [sp, #-0x30]!
    695c:      	str	x21, [sp, #0x10]
    6960:      	stp	x20, x19, [sp, #0x20]
    6964:      	mov	x29, sp
    6968:      	adrp	x8, 0x15000
    696c:      	ldr	x8, [x8, #0xdd8]
    6970:      	cbz	x8, 0x69c8 <.text+0x13dc>
    6974:      	mov	x20, x0
    6978:      	bl	0x6ac8 <.text+0x14dc>
    697c:      	mov	w19, w1
    6980:      	bl	0xd430 <pthread_rwlock_rdlock@plt>
    6984:      	adrp	x8, 0x15000
    6988:      	add	x8, x8, #0xdd8
    698c:      	ldr	x21, [x8]
    6990:      	cbz	x21, 0x69b4 <.text+0x13c8>
    6994:      	ldr	x8, [x21, #0x8]
    6998:      	cbz	x8, 0x69ac <.text+0x13c0>
    699c:      	ldr	x2, [x21, #0x10]
    69a0:      	mov	x0, x20
    69a4:      	mov	w1, w19
    69a8:      	blr	x8
    69ac:      	add	x8, x21, #0x18
    69b0:      	b	0x698c <.text+0x13a0>
    69b4:      	ldp	x20, x19, [sp, #0x20]
    69b8:      	ldr	x21, [sp, #0x10]
    69bc:      	bl	0x6ac8 <.text+0x14dc>
    69c0:      	ldp	x29, x30, [sp], #0x30
    69c4:      	b	0xd3f0 <pthread_rwlock_unlock@plt>
    69c8:      	ldp	x20, x19, [sp, #0x20]
    69cc:      	ldr	x21, [sp, #0x10]
    69d0:      	ldp	x29, x30, [sp], #0x30
    69d4:      	ret
    69d8:      	sub	sp, sp, #0x110
    69dc:      	stp	x29, x30, [sp, #0xf0]
    69e0:      	stp	x28, x19, [sp, #0x100]
    69e4:      	add	x29, sp, #0xf0
    69e8:      	stp	x4, x5, [x29, #-0x70]
    69ec:      	stp	x6, x7, [x29, #-0x60]
    69f0:      	stp	q0, q1, [sp]
    69f4:      	stp	q2, q3, [sp, #0x20]
    69f8:      	stp	q4, q5, [sp, #0x40]
    69fc:      	stp	q6, q7, [sp, #0x60]
    6a00:      	mrs	x19, TPIDR_EL0
    6a04:      	ldr	x9, [x19, #0x28]
    6a08:      	mov	x10, #-0x20             // =-32
    6a0c:      	mov	x11, sp
    6a10:      	sub	x12, x29, #0x70
    6a14:      	movk	x10, #0xff80, lsl #32
    6a18:      	stur	x9, [x29, #-0x8]
    6a1c:      	add	x9, x29, #0x20
    6a20:      	add	x11, x11, #0x80
    6a24:      	add	x12, x12, #0x20
    6a28:      	sub	x8, x29, #0x28
    6a2c:      	stp	x11, x10, [x29, #-0x18]
    6a30:      	stp	x9, x12, [x29, #-0x28]
    6a34:      	ldp	q0, q1, [x8]
    6a38:      	adrp	x4, 0x2000
    6a3c:      	mov	x3, x1
    6a40:      	add	x4, x4, #0x6e7
    6a44:      	sub	x5, x29, #0x50
    6a48:      	mov	w1, #0x100              // =256
    6a4c:      	mov	w2, wzr
    6a50:      	stp	q0, q1, [x29, #-0x50]
    6a54:      	bl	0xd460 <__vsnprintf_chk@plt>
    6a58:      	ldr	x8, [x19, #0x28]
    6a5c:      	ldur	x9, [x29, #-0x8]
    6a60:      	cmp	x8, x9
    6a64:      	b.ne	0x6a78 <.text+0x148c>
    6a68:      	ldp	x28, x19, [sp, #0x100]
    6a6c:      	ldp	x29, x30, [sp, #0xf0]
    6a70:      	add	sp, sp, #0x110
    6a74:      	ret
    6a78:      	bl	0xd2e0 <__stack_chk_fail@plt>
    6a7c:      	adrp	x8, 0x15000
    6a80:      	add	x8, x8, #0xe80
    6a84:      	ldp	x0, x9, [x8]
    6a88:      	br	x9
    6a8c:      	cmp	x21, #0x0
    6a90:      	csetm	w1, eq
    6a94:      	mov	x0, x20
    6a98:      	b	0x6958 <.text+0x136c>
    6a9c:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    6aa0:      	ldr	x8, [x8, #0xaa8]
    6aa4:      	ldr	w8, [x8]
    6aa8:      	cmp	w8, #0x4
    6aac:      	ret
    6ab0:      	ldp	x20, x19, [sp, #0x20]
    6ab4:      	ldp	x22, x21, [sp, #0x10]
    6ab8:      	ret
    6abc:      	mov	w0, #0x4                // =4
    6ac0:      	mov	x3, x20
    6ac4:      	b	0xd3a0 <__android_log_print@plt>
    6ac8:      	adrp	x0, 0x15000
    6acc:      	add	x0, x0, #0xe40
    6ad0:      	ret
    6ad4:      	mov	x0, x20
    6ad8:      	mov	w1, w22
    6adc:      	mov	x2, x21
    6ae0:      	br	x8
    6ae4:      	mov	x20, x0
    6ae8:      	b	0x6820 <.text+0x1234>
    6aec:      	mov	w5, #0x1                // =1
    6af0:      	mov	x0, xzr
    6af4:      	mov	x4, xzr
    6af8:      	b	0xaca0 <JNI_OnLoad+0x1b44>
    6afc:      	mov	w6, #0x1                // =1
    6b00:      	mov	x1, xzr
    6b04:      	mov	x5, xzr
    6b08:      	b	0xab60 <JNI_OnLoad+0x1a04>
    6b0c:      	mov	x0, x21
    6b10:      	ldp	x20, x19, [sp, #0x30]
    6b14:      	ldp	x22, x21, [sp, #0x20]
    6b18:      	ldr	x23, [sp, #0x10]
    6b1c:      	ret
    6b20:      	adrp	x0, 0x15000
    6b24:      	add	x0, x0, #0xe40
    6b28:      	b	0xd470 <pthread_rwlock_wrlock@plt>
    6b2c:      	adrp	x8, 0x15000
    6b30:      	ldr	x8, [x8, #0xe88]
    6b34:      	ret
    6b38:      	stp	x29, x30, [sp, #-0x30]!
    6b3c:      	str	x21, [sp, #0x10]
    6b40:      	stp	x20, x19, [sp, #0x20]
    6b44:      	mov	x29, sp
    6b48:      	ldr	x8, [x0, #0x10]
    6b4c:      	cbz	x8, 0x6bf8 <.text+0x160c>
    6b50:      	ldr	x21, [x0, #0x8]
    6b54:      	mov	x20, x0
    6b58:      	cbz	x21, 0x6bf8 <.text+0x160c>
    6b5c:      	ldrh	w8, [x20, #0x18]
    6b60:      	cbz	w8, 0x6bf8 <.text+0x160c>
    6b64:      	mov	w0, #0x1                // =1
    6b68:      	mov	w1, #0x1a0              // =416
    6b6c:      	bl	0xd300 <calloc@plt>
    6b70:      	mov	x19, x0
    6b74:      	cbz	x0, 0x6bfc <.text+0x1610>
    6b78:      	mov	x0, x21
    6b7c:      	bl	0xd480 <strdup@plt>
    6b80:      	str	x0, [x19, #0xa0]
    6b84:      	cbz	x0, 0x6bf0 <.text+0x1604>
    6b88:      	bl	0xa2f4 <JNI_OnLoad+0x1198>
    6b8c:      	str	x0, [x19, #0x68]
    6b90:      	cbz	x0, 0x6be8 <.text+0x15fc>
    6b94:      	add	x0, x19, #0x4
    6b98:      	mov	x1, xzr
    6b9c:      	str	wzr, [x19]
    6ba0:      	bl	0xd490 <pthread_mutex_init@plt>
    6ba4:      	add	x0, x19, #0x2c
    6ba8:      	mov	x1, xzr
    6bac:      	bl	0xd4a0 <pthread_cond_init@plt>
    6bb0:      	add	x0, x19, #0x74
    6bb4:      	mov	x1, xzr
    6bb8:      	str	wzr, [x19, #0x70]
    6bbc:      	bl	0xd490 <pthread_mutex_init@plt>
    6bc0:      	ldr	x9, [x20]
    6bc4:      	ldr	x8, [x20, #0x10]
    6bc8:      	add	x0, x19, #0xc4
    6bcc:      	mov	x1, xzr
    6bd0:      	stp	x9, x8, [x19, #0xa8]
    6bd4:      	ldrh	w8, [x20, #0x18]
    6bd8:      	strb	wzr, [x19, #0xc0]
    6bdc:      	str	x8, [x19, #0xb8]
    6be0:      	bl	0xd490 <pthread_mutex_init@plt>
    6be4:      	b	0x6bfc <.text+0x1610>
    6be8:      	ldr	x0, [x19, #0xa0]
    6bec:      	bl	0xd260 <free@plt>
    6bf0:      	mov	x0, x19
    6bf4:      	bl	0xd260 <free@plt>
    6bf8:      	mov	x19, xzr
    6bfc:      	mov	x0, x19
    6c00:      	ldp	x20, x19, [sp, #0x20]
    6c04:      	ldr	x21, [sp, #0x10]
    6c08:      	ldp	x29, x30, [sp], #0x30
    6c0c:      	ret
    6c10:      	stp	x29, x30, [sp, #-0x20]!
    6c14:      	str	x19, [sp, #0x10]
    6c18:      	mov	x29, sp
    6c1c:      	cbz	x0, 0x6c7c <.text+0x1690>
    6c20:      	ldr	x8, [x0]
    6c24:      	mov	x19, x0
    6c28:      	cbz	x8, 0x6c7c <.text+0x1690>
    6c2c:      	ldr	x0, [x8, #0x68]
    6c30:      	bl	0xa330 <JNI_OnLoad+0x11d4>
    6c34:      	ldr	x8, [x19]
    6c38:      	add	x0, x8, #0x4
    6c3c:      	bl	0xd4b0 <pthread_mutex_destroy@plt>
    6c40:      	ldr	x8, [x19]
    6c44:      	add	x0, x8, #0x2c
    6c48:      	bl	0xd4c0 <pthread_cond_destroy@plt>
    6c4c:      	ldr	x8, [x19]
    6c50:      	add	x0, x8, #0xc4
    6c54:      	bl	0xd4b0 <pthread_mutex_destroy@plt>
    6c58:      	ldr	x8, [x19]
    6c5c:      	add	x0, x8, #0x74
    6c60:      	bl	0xd4b0 <pthread_mutex_destroy@plt>
    6c64:      	ldr	x8, [x19]
    6c68:      	ldr	x0, [x8, #0xa0]
    6c6c:      	bl	0xd260 <free@plt>
    6c70:      	ldr	x0, [x19]
    6c74:      	bl	0xd260 <free@plt>
    6c78:      	str	xzr, [x19]
    6c7c:      	ldr	x19, [sp, #0x10]
    6c80:      	ldp	x29, x30, [sp], #0x20
    6c84:      	ret
    6c88:      	stp	x29, x30, [sp, #-0x10]!
    6c8c:      	mov	x29, sp
    6c90:      	ldaxr	w8, [x0]
    6c94:      	add	w9, w8, #0x1
    6c98:      	stlxr	w10, w9, [x0]
    6c9c:      	cbnz	w10, 0x6c90 <.text+0x16a4>
    6ca0:      	mov	w9, #0x7fffffff         // =2147483647
    6ca4:      	cmp	w8, w9
    6ca8:      	b.eq	0x6cb4 <.text+0x16c8>
    6cac:      	ldp	x29, x30, [sp], #0x10
    6cb0:      	ret
    6cb4:      	bl	0xd4d0 <abort@plt>
    6cb8:      	stp	x29, x30, [sp, #-0x20]!
    6cbc:      	stp	x20, x19, [sp, #0x10]
    6cc0:      	mov	x29, sp
    6cc4:      	mov	x20, x0
    6cc8:      	ldaxr	w8, [x20]
    6ccc:      	subs	w9, w8, #0x1
    6cd0:      	stlxr	w10, w9, [x20]
    6cd4:      	cbnz	w10, 0x6cc8 <.text+0x16dc>
    6cd8:      	b.eq	0x6cec <.text+0x1700>
    6cdc:      	cbz	w8, 0x6d14 <.text+0x1728>
    6ce0:      	ldp	x20, x19, [sp, #0x10]
    6ce4:      	ldp	x29, x30, [sp], #0x20
    6ce8:      	ret
    6cec:      	add	x19, x20, #0x4
    6cf0:      	mov	x0, x19
    6cf4:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    6cf8:      	ldr	w8, [x20, #0x5c]
    6cfc:      	cmp	w8, #0x1
    6d00:      	b.ge	0x6d18 <.text+0x172c>
    6d04:      	mov	x0, x19
    6d08:      	ldp	x20, x19, [sp, #0x10]
    6d0c:      	ldp	x29, x30, [sp], #0x20
    6d10:      	b	0xd3e0 <pthread_mutex_unlock@plt>
    6d14:      	bl	0xd4d0 <abort@plt>
    6d18:      	add	x0, x20, #0x2c
    6d1c:      	bl	0xd4e0 <pthread_cond_signal@plt>
    6d20:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    6d24:      	ldr	x8, [x8, #0xaa8]
    6d28:      	ldr	w8, [x8]
    6d2c:      	cmp	w8, #0x4
    6d30:      	b.hi	0x6d04 <.text+0x1718>
    6d34:      	adrp	x1, 0x2000
    6d38:      	adrp	x2, 0x2000
    6d3c:      	add	x1, x1, #0x94c
    6d40:      	add	x2, x2, #0x3a4
    6d44:      	mov	w0, #0x4                // =4
    6d48:      	bl	0xd3a0 <__android_log_print@plt>
    6d4c:      	b	0x6d04 <.text+0x1718>
    6d50:      	ldr	x0, [x0, #0xa0]
    6d54:      	b	0x9514 <JNI_OnLoad+0x3b8>
    6d58:      	ldrb	w0, [x0, #0x70]
    6d5c:      	ret
    6d60:      	add	x0, x0, #0x74
    6d64:      	b	0xd3b0 <pthread_mutex_lock@plt>
    6d68:      	add	x0, x0, #0x74
    6d6c:      	b	0xd3e0 <pthread_mutex_unlock@plt>
    6d70:      	sub	sp, sp, #0x170
    6d74:      	stp	x29, x30, [sp, #0x120]
    6d78:      	str	x28, [sp, #0x130]
    6d7c:      	stp	x24, x23, [sp, #0x140]
    6d80:      	stp	x22, x21, [sp, #0x150]
    6d84:      	stp	x20, x19, [sp, #0x160]
    6d88:      	add	x29, sp, #0x120
    6d8c:      	bl	0x79d8 <.text+0x23ec>
    6d90:      	cbnz	w8, 0x6da4 <.text+0x17b8>
    6d94:      	mov	x19, x0
    6d98:      	mov	x21, x1
    6d9c:      	bl	0x6e7c <.text+0x1890>
    6da0:      	cbz	w0, 0x6dc8 <.text+0x17dc>
    6da4:      	mov	x0, xzr
    6da8:      	ldr	x8, [x24, #0x28]
    6dac:      	ldur	x9, [x29, #-0x8]
    6db0:      	cmp	x8, x9
    6db4:      	b.ne	0x6e78 <.text+0x188c>
    6db8:      	bl	0x7a08 <.text+0x241c>
    6dbc:      	ldp	x29, x30, [sp, #0x120]
    6dc0:      	add	sp, sp, #0x170
    6dc4:      	ret
    6dc8:      	bl	0xd2b0 <gettid@plt>
    6dcc:      	mov	w20, w0
    6dd0:      	cbnz	w0, 0x6ddc <.text+0x17f0>
    6dd4:      	bl	0x7988 <.text+0x239c>
    6dd8:      	mov	w20, w0
    6ddc:      	bl	0x7954 <.text+0x2368>
    6de0:      	mov	w0, w20
    6de4:      	mov	x1, x23
    6de8:      	bl	0xce14 <bytehook_del_dlopen_callback+0x2ec>
    6dec:      	bl	0x79c8 <.text+0x23dc>
    6df0:      	cbz	w0, 0x6e08 <.text+0x181c>
    6df4:      	mov	w8, #0x2                // =2
    6df8:      	bl	0x79b8 <.text+0x23cc>
    6dfc:      	mov	x0, xzr
    6e00:      	strb	w22, [x19, #0x70]
    6e04:      	b	0x6da8 <.text+0x17bc>
    6e08:      	ldr	w8, [x19, #0x158]
    6e0c:      	cbz	w8, 0x6e2c <.text+0x1840>
    6e10:      	mov	x0, x19
    6e14:      	mov	x1, x21
    6e18:      	bl	0x75ac <.text+0x1fc0>
    6e1c:      	cbz	x0, 0x6e2c <.text+0x1840>
    6e20:      	ldrh	w9, [x0, #0x6]
    6e24:      	mov	x8, x0
    6e28:      	cbnz	w9, 0x6e50 <.text+0x1864>
    6e2c:      	ldr	w8, [x19, #0x138]
    6e30:      	cbz	w8, 0x6e60 <.text+0x1874>
    6e34:      	mov	x0, x19
    6e38:      	mov	x1, x21
    6e3c:      	bl	0x76d8 <.text+0x20ec>
    6e40:      	cbz	x0, 0x6e64 <.text+0x1878>
    6e44:      	ldrh	w9, [x0, #0x6]
    6e48:      	mov	x8, x0
    6e4c:      	cbz	w9, 0x6e60 <.text+0x1874>
    6e50:      	ldr	x9, [x19, #0xa8]
    6e54:      	ldr	x8, [x8, #0x8]
    6e58:      	add	x0, x8, x9
    6e5c:      	b	0x6e64 <.text+0x1878>
    6e60:      	mov	x0, xzr
    6e64:      	mov	w8, #0x2                // =2
    6e68:      	mov	x19, x0
    6e6c:      	bl	0x79b8 <.text+0x23cc>
    6e70:      	mov	x0, x19
    6e74:      	b	0x6da8 <.text+0x17bc>
    6e78:      	bl	0xd2e0 <__stack_chk_fail@plt>
    6e7c:      	sub	sp, sp, #0x170
    6e80:      	stp	x29, x30, [sp, #0x120]
    6e84:      	str	x28, [sp, #0x130]
    6e88:      	stp	x24, x23, [sp, #0x140]
    6e8c:      	stp	x22, x21, [sp, #0x150]
    6e90:      	stp	x20, x19, [sp, #0x160]
    6e94:      	add	x29, sp, #0x120
    6e98:      	bl	0x79d8 <.text+0x23ec>
    6e9c:      	cbz	w8, 0x6ea8 <.text+0x18bc>
    6ea0:      	mov	w0, #-0x1               // =-1
    6ea4:      	b	0x7174 <.text+0x1b88>
    6ea8:      	ldrb	w8, [x0, #0xc0]
    6eac:      	mov	x19, x0
    6eb0:      	cbz	w8, 0x6ebc <.text+0x18d0>
    6eb4:      	mov	w0, wzr
    6eb8:      	b	0x7174 <.text+0x1b88>
    6ebc:      	add	x0, x19, #0xc4
    6ec0:      	mov	x20, x0
    6ec4:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    6ec8:      	ldrb	w8, [x19, #0xc0]
    6ecc:      	cbnz	w8, 0x7164 <.text+0x1b78>
    6ed0:      	mov	w8, #0x1                // =1
    6ed4:      	strb	w8, [x19, #0xc0]
    6ed8:      	bl	0xd2b0 <gettid@plt>
    6edc:      	mov	w21, w0
    6ee0:      	cbnz	w0, 0x6eec <.text+0x1900>
    6ee4:      	bl	0x7988 <.text+0x239c>
    6ee8:      	mov	w21, w0
    6eec:      	bl	0x7954 <.text+0x2368>
    6ef0:      	mov	w0, w21
    6ef4:      	mov	x1, x23
    6ef8:      	bl	0xce14 <bytehook_del_dlopen_callback+0x2ec>
    6efc:      	bl	0x79c8 <.text+0x23dc>
    6f00:      	cbz	w0, 0x6f10 <.text+0x1924>
    6f04:      	bl	0x7974 <.text+0x2388>
    6f08:      	strb	w22, [x19, #0x70]
    6f0c:      	b	0x7164 <.text+0x1b78>
    6f10:      	ldr	x8, [x19, #0xb8]
    6f14:      	mov	x9, xzr
    6f18:      	mov	x0, xzr
    6f1c:      	cbz	x8, 0x70f0 <.text+0x1b04>
    6f20:      	ldr	x10, [x19, #0xb0]
    6f24:      	ldr	w11, [x10, x9]
    6f28:      	cmp	w11, #0x2
    6f2c:      	b.eq	0x6f40 <.text+0x1954>
    6f30:      	add	x9, x9, #0x38
    6f34:      	sub	x8, x8, #0x1
    6f38:      	cbnz	x8, 0x6f20 <.text+0x1934>
    6f3c:      	b	0x70f0 <.text+0x1b04>
    6f40:      	add	x9, x10, x9
    6f44:      	ldr	x8, [x19, #0xa8]
    6f48:      	ldr	x9, [x9, #0x10]
    6f4c:      	adds	x11, x9, x8
    6f50:      	b.eq	0x70f0 <.text+0x1b04>
    6f54:      	mov	w15, #0xfef5            // =65269
    6f58:      	movk	w15, #0x6fff, lsl #16
    6f5c:      	add	x17, x11, #0x8
    6f60:      	mov	x11, #-0xf              // =-15
    6f64:      	adrp	x12, 0x2000
    6f68:      	mov	w13, #0x18              // =24
    6f6c:      	mov	w14, w15
    6f70:      	adrp	x15, 0x2000
    6f74:      	mov	x9, x8
    6f78:      	add	x10, x8, #0x10
    6f7c:      	movk	x11, #0x9fff, lsl #16
    6f80:      	add	x12, x12, #0xd12
    6f84:      	add	x15, x15, #0xcfa
    6f88:      	mov	w16, w13
    6f8c:      	ldur	x0, [x17, #-0x8]
    6f90:      	cmp	x0, #0x17
    6f94:      	b.hi	0x6fb8 <.text+0x19cc>
    6f98:      	adr	x1, 0x6fa8 <.text+0x19bc>
    6f9c:      	ldrb	w2, [x15, x0]
    6fa0:      	add	x1, x1, x2, lsl #2
    6fa4:      	br	x1
    6fa8:      	ldr	x0, [x17]
    6fac:      	add	x0, x0, x8
    6fb0:      	str	x0, [x19, #0x100]
    6fb4:      	b	0x70e8 <.text+0x1afc>
    6fb8:      	add	x1, x0, x11
    6fbc:      	cmp	x1, #0x3
    6fc0:      	b.hi	0x6ff8 <.text+0x1a0c>
    6fc4:      	adr	x0, 0x6fd4 <.text+0x19e8>
    6fc8:      	ldrb	w2, [x12, x1]
    6fcc:      	add	x0, x0, x2, lsl #2
    6fd0:      	br	x0
    6fd4:      	ldr	x0, [x17]
    6fd8:      	add	x0, x0, x8
    6fdc:      	str	x0, [x19, #0x110]
    6fe0:      	b	0x70e8 <.text+0x1afc>
    6fe4:      	ldr	x0, [x17]
    6fe8:      	mov	w1, w13
    6fec:      	udiv	x0, x0, x1
    6ff0:      	str	x0, [x19, #0x108]
    6ff4:      	b	0x70e8 <.text+0x1afc>
    6ff8:      	cmp	x0, x14
    6ffc:      	b.ne	0x70e8 <.text+0x1afc>
    7000:      	ldr	x0, [x17]
    7004:      	ldr	w0, [x0, x9]
    7008:      	mov	w1, w0
    700c:      	str	w0, [x19, #0x158]
    7010:      	ldr	x1, [x17]
    7014:      	add	x1, x1, x8
    7018:      	ldr	w1, [x1, #0x4]
    701c:      	str	w1, [x19, #0x168]
    7020:      	ldr	x1, [x17]
    7024:      	add	x1, x1, x8
    7028:      	ldr	w1, [x1, #0x8]
    702c:      	mov	w2, w1
    7030:      	str	w1, [x19, #0x178]
    7034:      	ldr	x2, [x17]
    7038:      	add	x2, x2, x8
    703c:      	ldr	w2, [x2, #0xc]
    7040:      	str	w2, [x19, #0x17c]
    7044:      	ldr	x2, [x17]
    7048:      	add	x2, x10, x2
    704c:      	add	x1, x2, x1, lsl #3
    7050:      	add	x0, x1, x0, lsl #2
    7054:      	str	x2, [x19, #0x170]
    7058:      	str	x1, [x19, #0x150]
    705c:      	str	x0, [x19, #0x160]
    7060:      	b	0x70e8 <.text+0x1afc>
    7064:      	ldr	x0, [x17]
    7068:      	str	x0, [x19, #0x118]
    706c:      	b	0x70e8 <.text+0x1afc>
    7070:      	ldr	x0, [x17]
    7074:      	ldr	w0, [x0, x9]
    7078:      	mov	w1, w0
    707c:      	str	w0, [x19, #0x138]
    7080:      	ldr	x1, [x17]
    7084:      	add	x1, x1, x8
    7088:      	ldr	w1, [x1, #0x4]
    708c:      	str	w1, [x19, #0x148]
    7090:      	ldr	x1, [x17]
    7094:      	add	x1, x1, x8
    7098:      	add	x1, x1, #0x8
    709c:      	add	x0, x1, x0, lsl #2
    70a0:      	str	x1, [x19, #0x130]
    70a4:      	str	x0, [x19, #0x140]
    70a8:      	b	0x70e8 <.text+0x1afc>
    70ac:      	ldr	x0, [x17]
    70b0:      	add	x0, x0, x8
    70b4:      	str	x0, [x19, #0xf0]
    70b8:      	b	0x70e8 <.text+0x1afc>
    70bc:      	ldr	x0, [x17]
    70c0:      	udiv	x0, x0, x16
    70c4:      	str	x0, [x19, #0xf8]
    70c8:      	b	0x70e8 <.text+0x1afc>
    70cc:      	ldr	x0, [x17]
    70d0:      	add	x0, x0, x8
    70d4:      	str	x0, [x19, #0x128]
    70d8:      	b	0x70e8 <.text+0x1afc>
    70dc:      	ldr	x0, [x17]
    70e0:      	add	x0, x0, x8
    70e4:      	str	x0, [x19, #0x120]
    70e8:      	add	x17, x17, #0x10
    70ec:      	b	0x6f8c <.text+0x19a0>
    70f0:      	mov	w8, #0x1                // =1
    70f4:      	strb	w8, [x19, #0x70]
    70f8:      	b	0x7160 <.text+0x1b74>
    70fc:      	ldr	x8, [x19, #0x110]
    7100:      	cbz	x8, 0x7160 <.text+0x1b74>
    7104:      	ldr	x9, [x19, #0x118]
    7108:      	subs	x9, x9, #0x4
    710c:      	b.lo	0x7154 <.text+0x1b68>
    7110:      	ldrb	w11, [x8]
    7114:      	cmp	w11, #0x41
    7118:      	b.ne	0x7154 <.text+0x1b68>
    711c:      	ldrb	w11, [x8, #0x1]
    7120:      	mov	x10, x8
    7124:      	cmp	w11, #0x50
    7128:      	b.ne	0x7154 <.text+0x1b68>
    712c:      	ldrb	w11, [x10, #0x2]
    7130:      	cmp	w11, #0x53
    7134:      	b.ne	0x7154 <.text+0x1b68>
    7138:      	ldrb	w10, [x10, #0x3]
    713c:      	cmp	w10, #0x32
    7140:      	b.ne	0x7154 <.text+0x1b68>
    7144:      	add	x8, x8, #0x4
    7148:      	str	x8, [x19, #0x110]
    714c:      	mov	x8, x9
    7150:      	b	0x715c <.text+0x1b70>
    7154:      	mov	x8, xzr
    7158:      	str	xzr, [x19, #0x110]
    715c:      	str	x8, [x19, #0x118]
    7160:      	bl	0x7974 <.text+0x2388>
    7164:      	mov	x0, x20
    7168:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    716c:      	ldrb	w8, [x19, #0x70]
    7170:      	sbfx	w0, w8, #0, #1
    7174:      	ldr	x8, [x24, #0x28]
    7178:      	ldur	x9, [x29, #-0x8]
    717c:      	cmp	x8, x9
    7180:      	b.ne	0x7194 <.text+0x1ba8>
    7184:      	bl	0x7a08 <.text+0x241c>
    7188:      	ldp	x29, x30, [sp, #0x120]
    718c:      	add	sp, sp, #0x170
    7190:      	ret
    7194:      	bl	0xd2e0 <__stack_chk_fail@plt>
    7198:      	sub	sp, sp, #0x1f0
    719c:      	stp	x29, x30, [sp, #0x190]
    71a0:      	stp	x28, x27, [sp, #0x1a0]
    71a4:      	stp	x26, x25, [sp, #0x1b0]
    71a8:      	stp	x24, x23, [sp, #0x1c0]
    71ac:      	stp	x22, x21, [sp, #0x1d0]
    71b0:      	stp	x20, x19, [sp, #0x1e0]
    71b4:      	add	x29, sp, #0x190
    71b8:      	mrs	x28, TPIDR_EL0
    71bc:      	ldr	x8, [x28, #0x28]
    71c0:      	stur	x8, [x29, #-0x10]
    71c4:      	ldrb	w8, [x0, #0x70]
    71c8:      	cbnz	w8, 0x71e8 <.text+0x1bfc>
    71cc:      	mov	x20, x4
    71d0:      	mov	x21, x3
    71d4:      	mov	x22, x2
    71d8:      	mov	x19, x0
    71dc:      	mov	x24, x1
    71e0:      	bl	0x6e7c <.text+0x1890>
    71e4:      	cbz	w0, 0x721c <.text+0x1c30>
    71e8:      	mov	x0, xzr
    71ec:      	ldr	x8, [x28, #0x28]
    71f0:      	ldur	x9, [x29, #-0x10]
    71f4:      	cmp	x8, x9
    71f8:      	b.ne	0x75a8 <.text+0x1fbc>
    71fc:      	ldp	x20, x19, [sp, #0x1e0]
    7200:      	ldp	x22, x21, [sp, #0x1d0]
    7204:      	ldp	x24, x23, [sp, #0x1c0]
    7208:      	ldp	x26, x25, [sp, #0x1b0]
    720c:      	ldp	x28, x27, [sp, #0x1a0]
    7210:      	ldp	x29, x30, [sp, #0x190]
    7214:      	add	sp, sp, #0x1f0
    7218:      	ret
    721c:      	bl	0xd2b0 <gettid@plt>
    7220:      	mov	w23, w0
    7224:      	cbnz	w0, 0x7230 <.text+0x1c44>
    7228:      	bl	0x7988 <.text+0x239c>
    722c:      	mov	w23, w0
    7230:      	mov	x8, #0xb                // =11
    7234:      	movk	x8, #0x7, lsl #32
    7238:      	str	x8, [sp, #0x18]
    723c:      	mov	w8, #0x2                // =2
    7240:      	add	x26, sp, #0x78
    7244:      	add	x2, sp, #0x18
    7248:      	mov	w3, w8
    724c:      	mov	w0, w23
    7250:      	mov	x1, x26
    7254:      	bl	0xce14 <bytehook_del_dlopen_callback+0x2ec>
    7258:      	mov	w25, #0x1               // =1
    725c:      	mov	x0, x26
    7260:      	mov	w1, w25
    7264:      	bl	0xd2d0 <sigsetjmp@plt>
    7268:      	cbz	w0, 0x7280 <.text+0x1c94>
    726c:      	mov	w8, #0x2                // =2
    7270:      	bl	0x79a8 <.text+0x23bc>
    7274:      	mov	x0, xzr
    7278:      	strb	w25, [x19, #0x70]
    727c:      	b	0x71ec <.text+0x1c00>
    7280:      	mov	x8, xzr
    7284:      	str	xzr, [sp, #0x30]
    7288:      	ldr	w8, [x19, #0x138]
    728c:      	str	w23, [sp, #0x14]
    7290:      	cbz	w8, 0x72a8 <.text+0x1cbc>
    7294:      	mov	x0, x19
    7298:      	mov	x1, x24
    729c:      	bl	0x76d8 <.text+0x20ec>
    72a0:      	str	x0, [sp, #0x30]
    72a4:      	cbnz	x0, 0x72c0 <.text+0x1cd4>
    72a8:      	ldr	w8, [x19, #0x158]
    72ac:      	cbz	w8, 0x72c0 <.text+0x1cd4>
    72b0:      	mov	x0, x19
    72b4:      	mov	x1, x24
    72b8:      	bl	0x75ac <.text+0x1fc0>
    72bc:      	str	x0, [sp, #0x30]
    72c0:      	mov	x8, #-0x1               // =-1
    72c4:      	add	x25, sp, #0x30
    72c8:      	mov	w26, #0x1               // =1
    72cc:      	mov	x9, xzr
    72d0:      	mov	x0, xzr
    72d4:      	ldr	x10, [x19, #0xf8]
    72d8:      	add	x23, x8, #0x1
    72dc:      	cmp	x23, x10
    72e0:      	b.hs	0x7320 <.text+0x1d34>
    72e4:      	ldr	x10, [x19, #0xf0]
    72e8:      	mov	x0, x19
    72ec:      	mov	x2, x24
    72f0:      	mov	x3, x22
    72f4:      	add	x1, x10, x9
    72f8:      	mov	x4, x21
    72fc:      	mov	x5, x20
    7300:      	mov	x6, x25
    7304:      	mov	w7, w26
    7308:      	add	x27, x9, #0x18
    730c:      	bl	0x779c <.text+0x21b0>
    7310:      	mov	x8, x23
    7314:      	mov	x9, x27
    7318:      	cbz	w0, 0x72d4 <.text+0x1ce8>
    731c:      	b	0x737c <.text+0x1d90>
    7320:      	mov	x8, #-0x1               // =-1
    7324:      	add	x25, sp, #0x30
    7328:      	mov	x9, xzr
    732c:      	mov	x0, xzr
    7330:      	ldr	x10, [x19, #0x108]
    7334:      	add	x8, x8, #0x1
    7338:      	cmp	x8, x10
    733c:      	b.hs	0x7388 <.text+0x1d9c>
    7340:      	ldr	x10, [x19, #0x100]
    7344:      	mov	w7, wzr
    7348:      	mov	x0, x19
    734c:      	mov	x2, x24
    7350:      	add	x1, x10, x9
    7354:      	mov	x3, x22
    7358:      	mov	x4, x21
    735c:      	mov	x5, x20
    7360:      	mov	x6, x25
    7364:      	add	x23, x9, #0x18
    7368:      	mov	x26, x8
    736c:      	bl	0x779c <.text+0x21b0>
    7370:      	mov	x8, x26
    7374:      	mov	x9, x23
    7378:      	cbz	w0, 0x7330 <.text+0x1d44>
    737c:      	ldr	w23, [sp, #0x14]
    7380:      	mov	x0, xzr
    7384:      	b	0x73cc <.text+0x1de0>
    7388:      	ldr	x1, [x19, #0x110]
    738c:      	ldr	w23, [sp, #0x14]
    7390:      	cbz	x1, 0x73c4 <.text+0x1dd8>
    7394:      	ldr	x2, [x19, #0x118]
    7398:      	add	x25, sp, #0x20
    739c:      	mov	x0, x25
    73a0:      	bl	0xa280 <JNI_OnLoad+0x1124>
    73a4:      	add	x1, sp, #0x70
    73a8:      	mov	x0, x25
    73ac:      	bl	0xa28c <JNI_OnLoad+0x1130>
    73b0:      	cbnz	w0, 0x73c4 <.text+0x1dd8>
    73b4:      	add	x0, sp, #0x20
    73b8:      	add	x1, sp, #0x58
    73bc:      	bl	0xa28c <JNI_OnLoad+0x1130>
    73c0:      	cbz	w0, 0x73e0 <.text+0x1df4>
    73c4:      	ldr	x8, [sp, #0x30]
    73c8:      	mov	x0, x8
    73cc:      	mov	w8, #0x2                // =2
    73d0:      	mov	x19, x0
    73d4:      	bl	0x79a8 <.text+0x23bc>
    73d8:      	mov	x0, x19
    73dc:      	b	0x71ec <.text+0x1c00>
    73e0:      	add	x8, sp, #0x58
    73e4:      	mov	x27, xzr
    73e8:      	add	x8, x8, #0x8
    73ec:      	add	x26, sp, #0x20
    73f0:      	add	x25, sp, #0x50
    73f4:      	str	x8, [sp, #0x8]
    73f8:      	ldr	x8, [sp, #0x70]
    73fc:      	cmp	x27, x8
    7400:      	b.hs	0x73c4 <.text+0x1dd8>
    7404:      	mov	x0, x26
    7408:      	mov	x1, x25
    740c:      	bl	0xa28c <JNI_OnLoad+0x1130>
    7410:      	cbnz	w0, 0x73c4 <.text+0x1dd8>
    7414:      	mov	x0, x26
    7418:      	add	x1, sp, #0x48
    741c:      	bl	0xa28c <JNI_OnLoad+0x1130>
    7420:      	cbz	w0, 0x742c <.text+0x1e40>
    7424:      	mov	w8, #0x1                // =1
    7428:      	b	0x75a0 <.text+0x1fb4>
    742c:      	ldr	x9, [sp, #0x48]
    7430:      	mov	x8, xzr
    7434:      	str	xzr, [sp, #0x40]
    7438:      	mov	x0, x9
    743c:      	mov	w8, w9
    7440:      	tbz	w9, #0x1, 0x7458 <.text+0x1e6c>
    7444:      	mov	x0, x26
    7448:      	add	x1, sp, #0x40
    744c:      	bl	0xa28c <JNI_OnLoad+0x1130>
    7450:      	cbnz	w0, 0x7494 <.text+0x1ea8>
    7454:      	ldr	x0, [sp, #0x48]
    7458:      	mov	x8, x0
    745c:      	mov	w9, w0
    7460:      	tbz	w0, #0x0, 0x7478 <.text+0x1e8c>
    7464:      	ldr	x1, [sp, #0x8]
    7468:      	mov	x0, x26
    746c:      	bl	0xa28c <JNI_OnLoad+0x1130>
    7470:      	cbnz	w0, 0x7494 <.text+0x1ea8>
    7474:      	ldr	x8, [sp, #0x48]
    7478:      	and	x8, x8, #0xc
    747c:      	cmp	x8, #0xc
    7480:      	str	x8, [sp]
    7484:      	b.ne	0x749c <.text+0x1eb0>
    7488:      	mov	x0, x26
    748c:      	bl	0x7a00 <.text+0x2414>
    7490:      	cbz	w0, 0x74ac <.text+0x1ec0>
    7494:      	mov	w0, #0x1                // =1
    7498:      	b	0x759c <.text+0x1fb0>
    749c:      	add	x25, sp, #0x20
    74a0:      	mov	x8, xzr
    74a4:      	str	xzr, [sp, #0x68]
    74a8:      	b	0x74c0 <.text+0x1ed4>
    74ac:      	ldr	x8, [sp, #0x38]
    74b0:      	ldr	x9, [sp, #0x68]
    74b4:      	add	x25, sp, #0x20
    74b8:      	add	x8, x9, x8
    74bc:      	str	x8, [sp, #0x68]
    74c0:      	mov	x9, #-0x1               // =-1
    74c4:      	ldr	x8, [sp, #0x50]
    74c8:      	add	x26, x9, #0x1
    74cc:      	cmp	x26, x8
    74d0:      	b.hs	0x758c <.text+0x1fa0>
    74d4:      	ldr	x8, [sp, #0x48]
    74d8:      	mov	w9, w8
    74dc:      	tbnz	w8, #0x1, 0x7504 <.text+0x1f18>
    74e0:      	mov	x0, x25
    74e4:      	bl	0x7a00 <.text+0x2414>
    74e8:      	cbnz	w0, 0x7584 <.text+0x1f98>
    74ec:      	ldr	x8, [sp, #0x38]
    74f0:      	ldr	x9, [sp, #0x58]
    74f4:      	ldr	x0, [sp, #0x48]
    74f8:      	add	x8, x9, x8
    74fc:      	str	x8, [sp, #0x58]
    7500:      	b	0x7518 <.text+0x1f2c>
    7504:      	ldr	x9, [sp, #0x40]
    7508:      	ldr	x10, [sp, #0x58]
    750c:      	mov	x0, x8
    7510:      	add	x9, x10, x9
    7514:      	str	x9, [sp, #0x58]
    7518:      	mov	w8, w0
    751c:      	tbnz	w0, #0x0, 0x7530 <.text+0x1f44>
    7520:      	ldr	x1, [sp, #0x8]
    7524:      	mov	x0, x25
    7528:      	bl	0xa28c <JNI_OnLoad+0x1130>
    752c:      	cbnz	w0, 0x7584 <.text+0x1f98>
    7530:      	ldr	x8, [sp]
    7534:      	cmp	x8, #0x8
    7538:      	b.ne	0x7558 <.text+0x1f6c>
    753c:      	mov	x0, x25
    7540:      	bl	0x7a00 <.text+0x2414>
    7544:      	cbnz	w0, 0x7584 <.text+0x1f98>
    7548:      	ldr	x8, [sp, #0x38]
    754c:      	ldr	x9, [sp, #0x68]
    7550:      	add	x8, x9, x8
    7554:      	str	x8, [sp, #0x68]
    7558:      	mov	w7, wzr
    755c:      	mov	x0, x19
    7560:      	add	x1, sp, #0x58
    7564:      	mov	x2, x24
    7568:      	mov	x3, x22
    756c:      	mov	x4, x21
    7570:      	mov	x5, x20
    7574:      	add	x6, sp, #0x30
    7578:      	bl	0x779c <.text+0x21b0>
    757c:      	mov	x9, x26
    7580:      	cbz	w0, 0x74c4 <.text+0x1ed8>
    7584:      	mov	w0, #0x1                // =1
    7588:      	b	0x7594 <.text+0x1fa8>
    758c:      	mov	w0, wzr
    7590:      	add	x27, x8, x27
    7594:      	add	x26, sp, #0x20
    7598:      	add	x25, sp, #0x50
    759c:      	mov	w8, w0
    75a0:      	cbz	w8, 0x73f8 <.text+0x1e0c>
    75a4:      	b	0x73c4 <.text+0x1dd8>
    75a8:      	bl	0xd2e0 <__stack_chk_fail@plt>
    75ac:      	stp	x29, x30, [sp, #-0x60]!
    75b0:      	stp	x28, x27, [sp, #0x10]
    75b4:      	stp	x26, x25, [sp, #0x20]
    75b8:      	stp	x24, x23, [sp, #0x30]
    75bc:      	stp	x22, x21, [sp, #0x40]
    75c0:      	stp	x20, x19, [sp, #0x50]
    75c4:      	mov	x29, sp
    75c8:      	mov	x19, x1
    75cc:      	mov	x20, x0
    75d0:      	mov	w8, #0x1505             // =5381
    75d4:      	mov	x9, x1
    75d8:      	ldrb	w10, [x9]
    75dc:      	cbz	w10, 0x75f0 <.text+0x2004>
    75e0:      	add	w8, w8, w8, lsl #5
    75e4:      	add	x9, x9, #0x1
    75e8:      	add	w8, w8, w10
    75ec:      	b	0x75d8 <.text+0x1fec>
    75f0:      	ldr	w11, [x20, #0x178]
    75f4:      	ldr	x9, [x20, #0x170]
    75f8:      	lsr	w10, w8, #6
    75fc:      	ldr	w13, [x20, #0x17c]
    7600:      	udiv	w15, w10, w11
    7604:      	msub	w10, w15, w11, w10
    7608:      	ldr	x9, [x9, w10, uxtw #3]
    760c:      	mov	w10, w8
    7610:      	mov	w12, #0x1               // =1
    7614:      	lsr	x10, x10, x13
    7618:      	lsl	x14, x12, x8
    761c:      	lsl	x10, x12, x10
    7620:      	orr	x10, x10, x14
    7624:      	bics	xzr, x10, x9
    7628:      	b.ne	0x76b4 <.text+0x20c8>
    762c:      	ldr	w9, [x20, #0x158]
    7630:      	ldr	x10, [x20, #0x150]
    7634:      	udiv	w11, w8, w9
    7638:      	msub	w9, w11, w9, w8
    763c:      	ldr	w9, [x10, w9, uxtw #2]
    7640:      	ldr	w10, [x20, #0x168]
    7644:      	cmp	w9, w10
    7648:      	b.lo	0x76b4 <.text+0x20c8>
    764c:      	ldr	x22, [x20, #0x120]
    7650:      	ldr	x23, [x20, #0x160]
    7654:      	orr	w24, w8, #0x1
    7658:      	neg	w25, w10
    765c:      	mov	w26, #0x18              // =24
    7660:      	add	w8, w25, w9
    7664:      	ldr	w27, [x23, w8, uxtw #2]
    7668:      	mov	w28, w9
    766c:      	orr	w8, w27, #0x1
    7670:      	cmp	w24, w8
    7674:      	b.ne	0x76ac <.text+0x20c0>
    7678:      	madd	x8, x28, x26, x22
    767c:      	ldrb	w8, [x8, #0x4]
    7680:      	and	w8, w8, #0xf
    7684:      	cmp	w8, #0xa
    7688:      	b.hi	0x76ac <.text+0x20c0>
    768c:      	mov	w10, #0x1               // =1
    7690:      	lsl	w8, w10, w8
    7694:      	mov	w10, #0x405             // =1029
    7698:      	tst	w8, w10
    769c:      	b.eq	0x76ac <.text+0x20c0>
    76a0:      	umaddl	x21, w9, w26, x22
    76a4:      	bl	0x7994 <.text+0x23a8>
    76a8:      	cbz	w0, 0x76b8 <.text+0x20cc>
    76ac:      	add	w9, w28, #0x1
    76b0:      	tbz	w27, #0x0, 0x7660 <.text+0x2074>
    76b4:      	mov	x21, xzr
    76b8:      	mov	x0, x21
    76bc:      	ldp	x20, x19, [sp, #0x50]
    76c0:      	ldp	x22, x21, [sp, #0x40]
    76c4:      	ldp	x24, x23, [sp, #0x30]
    76c8:      	ldp	x26, x25, [sp, #0x20]
    76cc:      	ldp	x28, x27, [sp, #0x10]
    76d0:      	ldp	x29, x30, [sp], #0x60
    76d4:      	ret
    76d8:      	stp	x29, x30, [sp, #-0x50]!
    76dc:      	str	x25, [sp, #0x10]
    76e0:      	stp	x24, x23, [sp, #0x20]
    76e4:      	stp	x22, x21, [sp, #0x30]
    76e8:      	stp	x20, x19, [sp, #0x40]
    76ec:      	mov	x29, sp
    76f0:      	mov	x19, x1
    76f4:      	mov	x20, x0
    76f8:      	mov	w8, wzr
    76fc:      	mov	x9, x1
    7700:      	ldrb	w10, [x9]
    7704:      	cbz	w10, 0x7724 <.text+0x2138>
    7708:      	add	w8, w10, w8, lsl #4
    770c:      	and	w10, w8, #0xfffffff
    7710:      	lsr	w8, w8, #24
    7714:      	and	w8, w8, #0xf0
    7718:      	add	x9, x9, #0x1
    771c:      	eor	w8, w8, w10
    7720:      	b	0x7700 <.text+0x2114>
    7724:      	ldr	w9, [x20, #0x138]
    7728:      	ldr	x10, [x20, #0x130]
    772c:      	mov	w22, #0x18              // =24
    7730:      	mov	w23, #0x1               // =1
    7734:      	udiv	w11, w8, w9
    7738:      	msub	w8, w11, w9, w8
    773c:      	add	x8, x10, w8, uxtw #2
    7740:      	mov	w24, #0x405             // =1029
    7744:      	ldr	w25, [x8]
    7748:      	cbz	w25, 0x7788 <.text+0x219c>
    774c:      	ldr	x8, [x20, #0x120]
    7750:      	nop
    7754:      	madd	x21, x25, x22, x8
    7758:      	ldrb	w8, [x21, #0x4]
    775c:      	and	w8, w8, #0xf
    7760:      	cmp	w8, #0xa
    7764:      	b.hi	0x777c <.text+0x2190>
    7768:      	lsl	w8, w23, w8
    776c:      	tst	w8, w24
    7770:      	b.eq	0x777c <.text+0x2190>
    7774:      	bl	0x7994 <.text+0x23a8>
    7778:      	cbz	w0, 0x778c <.text+0x21a0>
    777c:      	ldr	x8, [x20, #0x140]
    7780:      	add	x8, x8, x25, lsl #2
    7784:      	b	0x7744 <.text+0x2158>
    7788:      	mov	x21, xzr
    778c:      	mov	x0, x21
    7790:      	bl	0x79ec <.text+0x2400>
    7794:      	ldp	x29, x30, [sp], #0x50
    7798:      	ret
    779c:      	stp	x29, x30, [sp, #-0x50]!
    77a0:      	str	x25, [sp, #0x10]
    77a4:      	stp	x24, x23, [sp, #0x20]
    77a8:      	stp	x22, x21, [sp, #0x30]
    77ac:      	stp	x20, x19, [sp, #0x40]
    77b0:      	mov	x29, sp
    77b4:      	ldr	x8, [x0, #0xa8]
    77b8:      	ldp	x10, x9, [x1]
    77bc:      	mov	x24, x6
    77c0:      	mov	x19, x5
    77c4:      	mov	x21, x4
    77c8:      	mov	x23, x3
    77cc:      	mov	x20, x0
    77d0:      	tbz	w7, #0x0, 0x77e0 <.text+0x21f4>
    77d4:      	cmp	w9, #0x402
    77d8:      	b.eq	0x77f0 <.text+0x2204>
    77dc:      	b	0x7838 <.text+0x224c>
    77e0:      	cmp	w9, #0x401
    77e4:      	b.eq	0x77f0 <.text+0x2204>
    77e8:      	cmp	w9, #0x101
    77ec:      	b.ne	0x7838 <.text+0x224c>
    77f0:      	ldr	x11, [x24]
    77f4:      	lsr	x9, x9, #32
    77f8:      	add	x22, x10, x8
    77fc:      	cbz	x11, 0x7818 <.text+0x222c>
    7800:      	ldr	x8, [x20, #0x120]
    7804:      	mov	w10, #0x18              // =24
    7808:      	madd	x8, x9, x10, x8
    780c:      	cmp	x8, x11
    7810:      	b.ne	0x7838 <.text+0x224c>
    7814:      	b	0x7844 <.text+0x2258>
    7818:      	ldp	x8, x10, [x20, #0x120]
    781c:      	mov	w11, #0x18              // =24
    7820:      	mov	x1, x2
    7824:      	madd	x25, x9, x11, x8
    7828:      	ldr	w8, [x25]
    782c:      	add	x0, x10, x8
    7830:      	bl	0xd340 <strcmp@plt>
    7834:      	cbz	w0, 0x7840 <.text+0x2254>
    7838:      	mov	w0, wzr
    783c:      	b	0x7884 <.text+0x2298>
    7840:      	str	x25, [x24]
    7844:      	cbz	x23, 0x7854 <.text+0x2268>
    7848:      	ldr	x8, [x22]
    784c:      	cmp	x8, x23
    7850:      	b.ne	0x7880 <.text+0x2294>
    7854:      	mov	x0, x21
    7858:      	mov	x1, x22
    785c:      	bl	0x5640 <.text+0x54>
    7860:      	cbnz	w0, 0x7880 <.text+0x2294>
    7864:      	mov	x0, x20
    7868:      	mov	x1, x22
    786c:      	bl	0x7890 <.text+0x22a4>
    7870:      	sxtw	x1, w0
    7874:      	mov	x0, x19
    7878:      	bl	0x5640 <.text+0x54>
    787c:      	cbz	w0, 0x7838 <.text+0x224c>
    7880:      	mov	w0, #-0x1               // =-1
    7884:      	bl	0x79ec <.text+0x2400>
    7888:      	ldp	x29, x30, [sp], #0x50
    788c:      	ret
    7890:      	ldr	x8, [x0, #0xb8]
    7894:      	mov	w10, #0xe552            // =58706
    7898:      	mov	x9, xzr
    789c:      	movk	w10, #0x6474, lsl #16
    78a0:      	mov	x11, x8
    78a4:      	cbz	x11, 0x78ec <.text+0x2300>
    78a8:      	ldr	x12, [x0, #0xb0]
    78ac:      	ldr	w13, [x12, x9]
    78b0:      	cmp	w13, w10
    78b4:      	b.ne	0x78e0 <.text+0x22f4>
    78b8:      	add	x12, x12, x9
    78bc:      	ldr	x13, [x0, #0xa8]
    78c0:      	ldr	x14, [x12, #0x10]
    78c4:      	add	x13, x14, x13
    78c8:      	cmp	x13, x1
    78cc:      	b.hi	0x78e0 <.text+0x22f4>
    78d0:      	ldr	x12, [x12, #0x28]
    78d4:      	add	x12, x12, x13
    78d8:      	cmp	x12, x1
    78dc:      	b.hi	0x7938 <.text+0x234c>
    78e0:      	sub	x11, x11, #0x1
    78e4:      	add	x9, x9, #0x38
    78e8:      	cbnz	x11, 0x78a8 <.text+0x22bc>
    78ec:      	mov	x9, xzr
    78f0:      	cbz	x8, 0x7938 <.text+0x234c>
    78f4:      	ldr	x10, [x0, #0xb0]
    78f8:      	ldr	w11, [x10, x9]
    78fc:      	cmp	w11, #0x1
    7900:      	b.ne	0x792c <.text+0x2340>
    7904:      	add	x11, x10, x9
    7908:      	ldr	x12, [x0, #0xa8]
    790c:      	ldr	x13, [x11, #0x10]
    7910:      	add	x12, x13, x12
    7914:      	cmp	x12, x1
    7918:      	b.hi	0x792c <.text+0x2340>
    791c:      	ldr	x11, [x11, #0x28]
    7920:      	add	x11, x11, x12
    7924:      	cmp	x11, x1
    7928:      	b.hi	0x7940 <.text+0x2354>
    792c:      	add	x9, x9, #0x38
    7930:      	sub	x8, x8, #0x1
    7934:      	cbnz	x8, 0x78f4 <.text+0x2308>
    7938:      	mov	w0, #0x1                // =1
    793c:      	ret
    7940:      	add	x8, x10, x9
    7944:      	ldr	w8, [x8, #0x4]
    7948:      	rbit	w8, w8
    794c:      	lsr	w0, w8, #29
    7950:      	ret
    7954:      	mov	x8, #0xb                // =11
    7958:      	movk	x8, #0x7, lsl #32
    795c:      	str	x8, [sp, #0x8]
    7960:      	mov	w8, #0x2                // =2
    7964:      	add	x23, sp, #0x10
    7968:      	add	x2, sp, #0x8
    796c:      	mov	w3, w8
    7970:      	ret
    7974:      	mov	w8, #0x2                // =2
    7978:      	add	x1, sp, #0x8
    797c:      	mov	w2, w8
    7980:      	mov	w0, w21
    7984:      	b	0xceb4 <bytehook_del_dlopen_callback+0x38c>
    7988:      	mov	w8, #0xb2               // =178
    798c:      	mov	w0, w8
    7990:      	b	0xd2c0 <syscall@plt>
    7994:      	ldr	x8, [x20, #0x128]
    7998:      	ldr	w9, [x21]
    799c:      	mov	x1, x19
    79a0:      	add	x0, x8, x9
    79a4:      	b	0xd340 <strcmp@plt>
    79a8:      	add	x1, sp, #0x18
    79ac:      	mov	w2, w8
    79b0:      	mov	w0, w23
    79b4:      	b	0xceb4 <bytehook_del_dlopen_callback+0x38c>
    79b8:      	add	x1, sp, #0x8
    79bc:      	mov	w2, w8
    79c0:      	mov	w0, w20
    79c4:      	b	0xceb4 <bytehook_del_dlopen_callback+0x38c>
    79c8:      	mov	w22, #0x1               // =1
    79cc:      	mov	x0, x23
    79d0:      	mov	w1, w22
    79d4:      	b	0xd2d0 <sigsetjmp@plt>
    79d8:      	mrs	x24, TPIDR_EL0
    79dc:      	ldr	x8, [x24, #0x28]
    79e0:      	stur	x8, [x29, #-0x8]
    79e4:      	ldrb	w8, [x0, #0x70]
    79e8:      	ret
    79ec:      	ldp	x20, x19, [sp, #0x40]
    79f0:      	ldp	x22, x21, [sp, #0x30]
    79f4:      	ldp	x24, x23, [sp, #0x20]
    79f8:      	ldr	x25, [sp, #0x10]
    79fc:      	ret
    7a00:      	add	x1, sp, #0x38
    7a04:      	b	0xa28c <JNI_OnLoad+0x1130>
    7a08:      	ldp	x20, x19, [sp, #0x160]
    7a0c:      	ldp	x22, x21, [sp, #0x150]
    7a10:      	ldp	x24, x23, [sp, #0x140]
    7a14:      	ldr	x28, [sp, #0x130]
    7a18:      	ret
    7a1c:      	stp	x29, x30, [sp, #-0x30]!
    7a20:      	str	x21, [sp, #0x10]
    7a24:      	stp	x20, x19, [sp, #0x20]
    7a28:      	mov	x29, sp
    7a2c:      	mov	x20, x0
    7a30:      	mov	w0, #0x18               // =24
    7a34:      	bl	0xd270 <malloc@plt>
    7a38:      	cbz	x0, 0x7a88 <.text+0x249c>
    7a3c:      	mov	x19, x0
    7a40:      	mov	x0, x20
    7a44:      	bl	0xd480 <strdup@plt>
    7a48:      	str	x0, [x19]
    7a4c:      	cbz	x0, 0x7a80 <.text+0x2494>
    7a50:      	adrp	x0, 0x15000
    7a54:      	add	x0, x0, #0xee8
    7a58:      	bl	0xd470 <pthread_rwlock_wrlock@plt>
    7a5c:      	adrp	x21, 0x15000
    7a60:      	add	x21, x21, #0xde8
    7a64:      	ldr	x21, [x21]
    7a68:      	cbz	x21, 0x7a90 <.text+0x24a4>
    7a6c:      	ldr	x0, [x21], #0x8
    7a70:      	mov	x1, x20
    7a74:      	bl	0xd340 <strcmp@plt>
    7a78:      	cbnz	w0, 0x7a64 <.text+0x2478>
    7a7c:      	b	0x7ab0 <.text+0x24c4>
    7a80:      	mov	x0, x19
    7a84:      	bl	0xd260 <free@plt>
    7a88:      	mov	w0, #-0x1               // =-1
    7a8c:      	b	0x7ad4 <.text+0x24e8>
    7a90:      	adrp	x8, 0x15000
    7a94:      	ldr	x9, [x8, #0xdf0]
    7a98:      	mov	x10, x19
    7a9c:      	str	xzr, [x10, #0x8]!
    7aa0:      	str	x9, [x19, #0x10]
    7aa4:      	str	x19, [x9]
    7aa8:      	mov	x19, xzr
    7aac:      	str	x10, [x8, #0xdf0]
    7ab0:      	adrp	x0, 0x15000
    7ab4:      	add	x0, x0, #0xee8
    7ab8:      	bl	0xd3f0 <pthread_rwlock_unlock@plt>
    7abc:      	cbz	x19, 0x7ad0 <.text+0x24e4>
    7ac0:      	ldr	x0, [x19]
    7ac4:      	bl	0xd260 <free@plt>
    7ac8:      	mov	x0, x19
    7acc:      	bl	0xd260 <free@plt>
    7ad0:      	mov	w0, wzr
    7ad4:      	ldp	x20, x19, [sp, #0x20]
    7ad8:      	ldr	x21, [sp, #0x10]
    7adc:      	ldp	x29, x30, [sp], #0x30
    7ae0:      	ret
    7ae4:      	stp	x29, x30, [sp, #-0x40]!
    7ae8:      	str	x23, [sp, #0x10]
    7aec:      	stp	x22, x21, [sp, #0x20]
    7af0:      	stp	x20, x19, [sp, #0x30]
    7af4:      	mov	x29, sp
    7af8:      	adrp	x21, 0x15000
    7afc:      	adrp	x23, 0x15000
    7b00:      	mov	x19, x1
    7b04:      	mov	x20, x0
    7b08:      	mov	x22, xzr
    7b0c:      	add	x21, x21, #0xf20
    7b10:      	add	x23, x23, #0xdf8
    7b14:      	mov	x0, x21
    7b18:      	bl	0xd430 <pthread_rwlock_rdlock@plt>
    7b1c:      	add	x8, x22, #0x180
    7b20:      	cmp	x22, #0x0
    7b24:      	csel	x8, x23, x8, eq
    7b28:      	ldr	x22, [x8]
    7b2c:      	cbz	x22, 0x7b74 <.text+0x2588>
    7b30:      	ldr	x8, [x22, #0x60]
    7b34:      	cmp	x8, #0x0
    7b38:      	b.gt	0x7b44 <.text+0x2558>
    7b3c:      	ldrb	w8, [x22, #0x70]
    7b40:      	cbz	w8, 0x7b4c <.text+0x2560>
    7b44:      	add	x8, x22, #0x180
    7b48:      	b	0x7b28 <.text+0x253c>
    7b4c:      	mov	x0, x22
    7b50:      	bl	0x6c88 <.text+0x169c>
    7b54:      	mov	x0, x21
    7b58:      	bl	0xd3f0 <pthread_rwlock_unlock@plt>
    7b5c:      	mov	x0, x22
    7b60:      	mov	x1, x19
    7b64:      	blr	x20
    7b68:      	mov	x0, x22
    7b6c:      	bl	0x6cb8 <.text+0x16cc>
    7b70:      	b	0x7b14 <.text+0x2528>
    7b74:      	ldp	x20, x19, [sp, #0x30]
    7b78:      	ldp	x22, x21, [sp, #0x20]
    7b7c:      	ldr	x23, [sp, #0x10]
    7b80:      	adrp	x0, 0x15000
    7b84:      	add	x0, x0, #0xf20
    7b88:      	ldp	x29, x30, [sp], #0x40
    7b8c:      	b	0xd3f0 <pthread_rwlock_unlock@plt>
    7b90:      	stp	x29, x30, [sp, #-0x20]!
    7b94:      	stp	x20, x19, [sp, #0x10]
    7b98:      	mov	x29, sp
    7b9c:      	mov	x19, x0
    7ba0:      	adrp	x0, 0x15000
    7ba4:      	add	x0, x0, #0xf20
    7ba8:      	bl	0xd430 <pthread_rwlock_rdlock@plt>
    7bac:      	adrp	x8, 0x15000
    7bb0:      	add	x8, x8, #0xdf8
    7bb4:      	ldr	x20, [x8]
    7bb8:      	cbz	x20, 0x7bec <.text+0x2600>
    7bbc:      	ldr	x8, [x20, #0x60]
    7bc0:      	cbnz	x8, 0x7bdc <.text+0x25f0>
    7bc4:      	ldrb	w8, [x20, #0x70]
    7bc8:      	cbnz	w8, 0x7bdc <.text+0x25f0>
    7bcc:      	mov	x0, x20
    7bd0:      	mov	x1, x19
    7bd4:      	bl	0x6d50 <.text+0x1764>
    7bd8:      	tbnz	w0, #0x0, 0x7be4 <.text+0x25f8>
    7bdc:      	add	x8, x20, #0x180
    7be0:      	b	0x7bb4 <.text+0x25c8>
    7be4:      	mov	x0, x20
    7be8:      	bl	0x6c88 <.text+0x169c>
    7bec:      	bl	0x808c <.text+0x2aa0>
    7bf0:      	mov	x0, x20
    7bf4:      	ldp	x20, x19, [sp, #0x10]
    7bf8:      	ldp	x29, x30, [sp], #0x20
    7bfc:      	ret
    7c00:      	stp	x29, x30, [sp, #-0x20]!
    7c04:      	stp	x20, x19, [sp, #0x10]
    7c08:      	mov	x29, sp
    7c0c:      	mov	x19, x1
    7c10:      	bl	0x7b90 <.text+0x25a4>
    7c14:      	cbz	x0, 0x7c34 <.text+0x2648>
    7c18:      	mov	x1, x19
    7c1c:      	mov	x20, x0
    7c20:      	bl	0x6d70 <.text+0x1784>
    7c24:      	mov	x19, x0
    7c28:      	mov	x0, x20
    7c2c:      	bl	0x6cb8 <.text+0x16cc>
    7c30:      	mov	x0, x19
    7c34:      	ldp	x20, x19, [sp, #0x10]
    7c38:      	ldp	x29, x30, [sp], #0x20
    7c3c:      	ret
    7c40:      	adrp	x0, 0x7000 <.text+0x1a14>
    7c44:      	add	x0, x0, #0xc50
    7c48:      	mov	x1, xzr
    7c4c:      	b	0x5ce0 <.text+0x6f4>
    7c50:      	stp	x29, x30, [sp, #-0x10]!
    7c54:      	mov	x29, sp
    7c58:      	mov	w1, wzr
    7c5c:      	bl	0x7c74 <.text+0x2688>
    7c60:      	mov	w0, wzr
    7c64:      	ldp	x29, x30, [sp], #0x10
    7c68:      	ret
    7c6c:      	mov	w1, #0x1                // =1
    7c70:      	b	0x7c74 <.text+0x2688>
    7c74:      	sub	sp, sp, #0x40
    7c78:      	stp	x29, x30, [sp, #0x10]
    7c7c:      	stp	x22, x21, [sp, #0x20]
    7c80:      	stp	x20, x19, [sp, #0x30]
    7c84:      	add	x29, sp, #0x10
    7c88:      	mrs	x22, TPIDR_EL0
    7c8c:      	ldr	x8, [x22, #0x28]
    7c90:      	mov	x19, x0
    7c94:      	mov	w21, w1
    7c98:      	str	x8, [sp, #0x8]
    7c9c:      	ldr	x0, [x0, #0x8]
    7ca0:      	bl	0x7fb8 <.text+0x29cc>
    7ca4:      	tbnz	w0, #0x0, 0x7d40 <.text+0x2754>
    7ca8:      	mov	x0, x19
    7cac:      	bl	0x6b38 <.text+0x154c>
    7cb0:      	str	x0, [sp]
    7cb4:      	cbz	x0, 0x7d40 <.text+0x2754>
    7cb8:      	mov	x20, x0
    7cbc:      	tbz	w21, #0x0, 0x7cc8 <.text+0x26dc>
    7cc0:      	mov	x0, x20
    7cc4:      	bl	0x6c88 <.text+0x169c>
    7cc8:      	bl	0x80a0 <.text+0x2ab4>
    7ccc:      	cbnz	w0, 0x7d3c <.text+0x2750>
    7cd0:      	adrp	x8, 0x15000
    7cd4:      	add	x8, x8, #0xdf8
    7cd8:      	ldr	x8, [x8]
    7cdc:      	cbz	x8, 0x7d00 <.text+0x2714>
    7ce0:      	ldr	x9, [x8, #0x60]
    7ce4:      	cbnz	x9, 0x7cf8 <.text+0x270c>
    7ce8:      	ldr	x9, [x8, #0xa8]
    7cec:      	ldr	x10, [x19]
    7cf0:      	cmp	x9, x10
    7cf4:      	b.eq	0x7d38 <.text+0x274c>
    7cf8:      	add	x8, x8, #0x180
    7cfc:      	b	0x7cd8 <.text+0x26ec>
    7d00:      	adrp	x8, 0x15000
    7d04:      	ldr	x9, [x8, #0xe00]
    7d08:      	adrp	x0, 0x15000
    7d0c:      	add	x0, x0, #0xf20
    7d10:      	stp	xzr, x9, [x20, #0x180]
    7d14:      	str	x20, [x9]
    7d18:      	ldr	x19, [sp]
    7d1c:      	add	x9, x19, #0x180
    7d20:      	str	x9, [x8, #0xe00]
    7d24:      	bl	0xd3f0 <pthread_rwlock_unlock@plt>
    7d28:      	bl	0x80ac <.text+0x2ac0>
    7d2c:      	b.hi	0x7d44 <.text+0x2758>
    7d30:      	bl	0x8070 <.text+0x2a84>
    7d34:      	b	0x7d44 <.text+0x2758>
    7d38:      	bl	0x808c <.text+0x2aa0>
    7d3c:      	bl	0x8098 <.text+0x2aac>
    7d40:      	mov	x19, xzr
    7d44:      	ldr	x8, [x22, #0x28]
    7d48:      	ldr	x9, [sp, #0x8]
    7d4c:      	cmp	x8, x9
    7d50:      	b.ne	0x7d6c <.text+0x2780>
    7d54:      	mov	x0, x19
    7d58:      	ldp	x20, x19, [sp, #0x30]
    7d5c:      	ldp	x22, x21, [sp, #0x20]
    7d60:      	ldp	x29, x30, [sp, #0x10]
    7d64:      	add	sp, sp, #0x40
    7d68:      	ret
    7d6c:      	bl	0xd2e0 <__stack_chk_fail@plt>
    7d70:      	sub	sp, sp, #0x90
    7d74:      	stp	x29, x30, [sp, #0x30]
    7d78:      	str	x27, [sp, #0x40]
    7d7c:      	stp	x26, x25, [sp, #0x50]
    7d80:      	stp	x24, x23, [sp, #0x60]
    7d84:      	stp	x22, x21, [sp, #0x70]
    7d88:      	stp	x20, x19, [sp, #0x80]
    7d8c:      	add	x29, sp, #0x30
    7d90:      	mrs	x23, TPIDR_EL0
    7d94:      	ldr	x8, [x23, #0x28]
    7d98:      	mov	x19, x0
    7d9c:      	add	x9, sp, #0x18
    7da0:      	add	x0, sp, #0x8
    7da4:      	mov	x1, xzr
    7da8:      	stur	x8, [x29, #-0x8]
    7dac:      	stp	xzr, x9, [sp, #0x18]
    7db0:      	bl	0xd4f0 <gettimeofday@plt>
    7db4:      	bl	0x80a0 <.text+0x2ab4>
    7db8:      	cbnz	w0, 0x7f84 <.text+0x2998>
    7dbc:      	adrp	x8, 0x15000
    7dc0:      	adrp	x24, 0x11000 <siglongjmp@plt+0x3870>
    7dc4:      	ldr	x22, [sp, #0x8]
    7dc8:      	ldr	x27, [x8, #0xdf8]
    7dcc:      	ldr	x24, [x24, #0xaa8]
    7dd0:      	adrp	x20, 0x2000
    7dd4:      	adrp	x21, 0x2000
    7dd8:      	mov	x25, xzr
    7ddc:      	add	x20, x20, #0x94c
    7de0:      	add	x21, x21, #0xb89
    7de4:      	adrp	x26, 0x15000
    7de8:      	cbz	x27, 0x7e88 <.text+0x289c>
    7dec:      	mov	x8, x27
    7df0:      	ldr	x9, [x27, #0x60]
    7df4:      	ldr	x27, [x27, #0x180]
    7df8:      	cbz	x9, 0x7e28 <.text+0x283c>
    7dfc:      	sub	x10, x22, x9
    7e00:      	cmp	x9, #0x1
    7e04:      	ccmp	x10, #0x1f, #0x8, ge
    7e08:      	b.lt	0x7de8 <.text+0x27fc>
    7e0c:      	ldr	w9, [x8]
    7e10:      	cbnz	w9, 0x7de8 <.text+0x27fc>
    7e14:      	ldr	x9, [x8, #0x188]
    7e18:      	cbz	x27, 0x7e68 <.text+0x287c>
    7e1c:      	str	x9, [x27, #0x188]
    7e20:      	ldr	x9, [x8, #0x188]
    7e24:      	b	0x7e6c <.text+0x2880>
    7e28:      	ldr	x3, [x8, #0xa8]
    7e2c:      	ldr	x9, [x19]
    7e30:      	cmp	x3, x9
    7e34:      	b.ne	0x7de8 <.text+0x27fc>
    7e38:      	str	x22, [x8, #0x60]
    7e3c:      	ldr	w9, [x24]
    7e40:      	mov	x25, x8
    7e44:      	cmp	w9, #0x4
    7e48:      	b.hi	0x7de8 <.text+0x27fc>
    7e4c:      	ldr	x4, [x8, #0xa0]
    7e50:      	mov	w0, #0x4                // =4
    7e54:      	mov	x1, x20
    7e58:      	mov	x2, x21
    7e5c:      	mov	x25, x8
    7e60:      	bl	0xd3a0 <__android_log_print@plt>
    7e64:      	b	0x7de8 <.text+0x27fc>
    7e68:      	str	x9, [x26, #0xe00]
    7e6c:      	str	x27, [x9]
    7e70:      	ldr	x9, [sp, #0x20]
    7e74:      	add	x10, x8, #0x180
    7e78:      	stp	xzr, x9, [x8, #0x180]
    7e7c:      	str	x8, [x9]
    7e80:      	str	x10, [sp, #0x20]
    7e84:      	b	0x7de8 <.text+0x27fc>
    7e88:      	bl	0x808c <.text+0x2aa0>
    7e8c:      	ldr	x8, [sp, #0x18]
    7e90:      	adrp	x19, 0x2000
    7e94:      	adrp	x20, 0x2000
    7e98:      	add	x19, x19, #0x94c
    7e9c:      	add	x20, x20, #0x5d5
    7ea0:      	str	x8, [sp]
    7ea4:      	cbz	x8, 0x7ef8 <.text+0x290c>
    7ea8:      	ldp	x21, x9, [x8, #0x180]
    7eac:      	cbz	x21, 0x7ebc <.text+0x28d0>
    7eb0:      	str	x9, [x21, #0x188]
    7eb4:      	ldr	x9, [x8, #0x188]
    7eb8:      	b	0x7ec0 <.text+0x28d4>
    7ebc:      	str	x9, [sp, #0x20]
    7ec0:      	str	x21, [x9]
    7ec4:      	ldr	w8, [x24]
    7ec8:      	cmp	w8, #0x4
    7ecc:      	b.ls	0x7edc <.text+0x28f0>
    7ed0:      	bl	0x8098 <.text+0x2aac>
    7ed4:      	mov	x8, x21
    7ed8:      	b	0x7ea0 <.text+0x28b4>
    7edc:      	ldr	x8, [sp]
    7ee0:      	mov	w0, #0x4                // =4
    7ee4:      	mov	x1, x19
    7ee8:      	mov	x2, x20
    7eec:      	ldp	x4, x3, [x8, #0xa0]
    7ef0:      	bl	0xd3a0 <__android_log_print@plt>
    7ef4:      	b	0x7ed0 <.text+0x28e4>
    7ef8:      	cbz	x25, 0x7f84 <.text+0x2998>
    7efc:      	add	x19, x25, #0x4
    7f00:      	mov	x0, x19
    7f04:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    7f08:      	add	x26, x25, #0x5c
    7f0c:      	ldxr	w8, [x26]
    7f10:      	add	w8, w8, #0x1
    7f14:      	stxr	w9, w8, [x26]
    7f18:      	cbnz	w9, 0x7f0c <.text+0x2920>
    7f1c:      	adrp	x21, 0x2000
    7f20:      	adrp	x22, 0x2000
    7f24:      	add	x20, x25, #0x2c
    7f28:      	add	x21, x21, #0x94c
    7f2c:      	add	x22, x22, #0x4ef
    7f30:      	ldr	w3, [x25]
    7f34:      	cmp	w3, #0x0
    7f38:      	b.le	0x7f6c <.text+0x2980>
    7f3c:      	ldr	w8, [x24]
    7f40:      	cmp	w8, #0x4
    7f44:      	b.ls	0x7f58 <.text+0x296c>
    7f48:      	mov	x0, x20
    7f4c:      	mov	x1, x19
    7f50:      	bl	0xd500 <pthread_cond_wait@plt>
    7f54:      	b	0x7f30 <.text+0x2944>
    7f58:      	mov	w0, #0x4                // =4
    7f5c:      	mov	x1, x21
    7f60:      	mov	x2, x22
    7f64:      	bl	0xd3a0 <__android_log_print@plt>
    7f68:      	b	0x7f48 <.text+0x295c>
    7f6c:      	ldxr	w8, [x26]
    7f70:      	sub	w8, w8, #0x1
    7f74:      	stxr	w9, w8, [x26]
    7f78:      	cbnz	w9, 0x7f6c <.text+0x2980>
    7f7c:      	mov	x0, x19
    7f80:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    7f84:      	ldr	x8, [x23, #0x28]
    7f88:      	ldur	x9, [x29, #-0x8]
    7f8c:      	cmp	x8, x9
    7f90:      	b.ne	0x7fb4 <.text+0x29c8>
    7f94:      	ldp	x20, x19, [sp, #0x80]
    7f98:      	ldp	x22, x21, [sp, #0x70]
    7f9c:      	ldp	x24, x23, [sp, #0x60]
    7fa0:      	ldp	x26, x25, [sp, #0x50]
    7fa4:      	ldr	x27, [sp, #0x40]
    7fa8:      	ldp	x29, x30, [sp, #0x30]
    7fac:      	add	sp, sp, #0x90
    7fb0:      	ret
    7fb4:      	bl	0xd2e0 <__stack_chk_fail@plt>
    7fb8:      	stp	x29, x30, [sp, #-0x30]!
    7fbc:      	str	x21, [sp, #0x10]
    7fc0:      	stp	x20, x19, [sp, #0x20]
    7fc4:      	mov	x29, sp
    7fc8:      	ldrb	w8, [x0]
    7fcc:      	cmp	w8, #0x5b
    7fd0:      	b.eq	0x8068 <.text+0x2a7c>
    7fd4:      	adrp	x1, 0x2000
    7fd8:      	add	x1, x1, #0x959
    7fdc:      	mov	x19, x0
    7fe0:      	bl	0xba0c <JNI_OnLoad+0x28b0>
    7fe4:      	tbnz	w0, #0x0, 0x8068 <.text+0x2a7c>
    7fe8:      	adrp	x1, 0x2000
    7fec:      	add	x1, x1, #0x521
    7ff0:      	mov	x0, x19
    7ff4:      	bl	0xba0c <JNI_OnLoad+0x28b0>
    7ff8:      	tbnz	w0, #0x0, 0x8068 <.text+0x2a7c>
    7ffc:      	adrp	x1, 0x2000
    8000:      	add	x1, x1, #0xa86
    8004:      	mov	x0, x19
    8008:      	bl	0xba0c <JNI_OnLoad+0x28b0>
    800c:      	tbnz	w0, #0x0, 0x8068 <.text+0x2a7c>
    8010:      	adrp	x0, 0x15000
    8014:      	add	x0, x0, #0xee8
    8018:      	bl	0xd430 <pthread_rwlock_rdlock@plt>
    801c:      	adrp	x21, 0x15000
    8020:      	add	x21, x21, #0xde8
    8024:      	ldr	x20, [x21]
    8028:      	cbz	x20, 0x8040 <.text+0x2a54>
    802c:      	mov	x21, x20
    8030:      	ldr	x1, [x21], #0x8
    8034:      	mov	x0, x19
    8038:      	bl	0x9514 <JNI_OnLoad+0x3b8>
    803c:      	tbz	w0, #0x0, 0x8024 <.text+0x2a38>
    8040:      	adrp	x0, 0x15000
    8044:      	cmp	x20, #0x0
    8048:      	add	x0, x0, #0xee8
    804c:      	cset	w19, ne
    8050:      	bl	0xd3f0 <pthread_rwlock_unlock@plt>
    8054:      	mov	w0, w19
    8058:      	ldp	x20, x19, [sp, #0x20]
    805c:      	ldr	x21, [sp, #0x10]
    8060:      	ldp	x29, x30, [sp], #0x30
    8064:      	ret
    8068:      	mov	w19, #0x1               // =1
    806c:      	b	0x8054 <.text+0x2a68>
    8070:      	ldp	x4, x3, [x19, #0xa0]
    8074:      	adrp	x1, 0x2000
    8078:      	adrp	x2, 0x2000
    807c:      	add	x1, x1, #0x94c
    8080:      	add	x2, x2, #0xba4
    8084:      	mov	w0, #0x4                // =4
    8088:      	b	0xd3a0 <__android_log_print@plt>
    808c:      	adrp	x0, 0x15000
    8090:      	add	x0, x0, #0xf20
    8094:      	b	0xd3f0 <pthread_rwlock_unlock@plt>
    8098:      	mov	x0, sp
    809c:      	b	0x6c10 <.text+0x1624>
    80a0:      	adrp	x0, 0x15000
    80a4:      	add	x0, x0, #0xf20
    80a8:      	b	0xd470 <pthread_rwlock_wrlock@plt>
    80ac:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    80b0:      	ldr	x8, [x8, #0xaa8]
    80b4:      	ldr	w8, [x8]
    80b8:      	cmp	w8, #0x4
    80bc:      	ret
    80c0:      	sub	sp, sp, #0xf0
    80c4:      	stp	x29, x30, [sp, #0xc0]
    80c8:      	str	x21, [sp, #0xd0]
    80cc:      	stp	x20, x19, [sp, #0xe0]
    80d0:      	add	x29, sp, #0xc0
    80d4:      	mrs	x21, TPIDR_EL0
    80d8:      	ldr	x8, [x21, #0x28]
    80dc:      	bl	0x871c <.text+0x3130>
    80e0:      	tbz	w0, #0x0, 0x80f4 <.text+0x2b08>
    80e4:      	ldr	x2, [x20, #0xa0]
    80e8:      	mov	w1, #0x15               // =21
    80ec:      	bl	0x8710 <.text+0x3124>
    80f0:      	b	0x8244 <.text+0x2c58>
    80f4:      	bl	0xba68 <JNI_OnLoad+0x290c>
    80f8:      	cmp	w0, #0x1a
    80fc:      	b.lt	0x8178 <.text+0x2b8c>
    8100:      	ldrb	w8, [x20, #0x72]
    8104:      	cbnz	w8, 0x8170 <.text+0x2b84>
    8108:      	mov	x0, x20
    810c:      	bl	0x6d60 <.text+0x1774>
    8110:      	ldrb	w8, [x20, #0x72]
    8114:      	cbnz	w8, 0x8168 <.text+0x2b7c>
    8118:      	adrp	x1, 0x2000
    811c:      	adrp	x2, 0x8000 <.text+0x2a14>
    8120:      	add	x1, x1, #0x5c6
    8124:      	add	x2, x2, #0x708
    8128:      	mov	x0, x20
    812c:      	bl	0x8578 <.text+0x2f8c>
    8130:      	cbz	w0, 0x813c <.text+0x2b50>
    8134:      	mov	w8, wzr
    8138:      	b	0x815c <.text+0x2b70>
    813c:      	adrp	x1, 0x2000
    8140:      	adrp	x2, 0x8000 <.text+0x2a14>
    8144:      	add	x1, x1, #0x429
    8148:      	add	x2, x2, #0x70c
    814c:      	mov	x0, x20
    8150:      	bl	0x8578 <.text+0x2f8c>
    8154:      	cmp	w0, #0x0
    8158:      	cset	w8, eq
    815c:      	strb	w8, [x20, #0x73]
    8160:      	mov	w8, #0x1                // =1
    8164:      	strb	w8, [x20, #0x72]
    8168:      	mov	x0, x20
    816c:      	bl	0x6d68 <.text+0x177c>
    8170:      	ldrb	w8, [x20, #0x73]
    8174:      	cbz	w8, 0x8218 <.text+0x2c2c>
    8178:      	bl	0x872c <.text+0x3140>
    817c:      	mov	w8, #0x8                // =8
    8180:      	add	x9, sp, #0x60
    8184:      	stur	q0, [sp, #0x68]
    8188:      	str	x8, [sp, #0x70]
    818c:      	stp	q0, q0, [sp, #0x10]
    8190:      	str	x8, [sp, #0x18]
    8194:      	add	x8, sp, #0x8
    8198:      	add	x9, x9, #0x18
    819c:      	add	x8, x8, #0x18
    81a0:      	stur	q0, [sp, #0x78]
    81a4:      	stp	q0, q0, [sp, #0x40]
    81a8:      	stur	q0, [sp, #0x30]
    81ac:      	str	x9, [sp, #0x60]
    81b0:      	str	x8, [sp, #0x8]
    81b4:      	ldp	x2, x1, [x19, #0x38]
    81b8:      	add	x3, sp, #0x60
    81bc:      	add	x4, sp, #0x8
    81c0:      	mov	x0, x20
    81c4:      	bl	0x7198 <.text+0x1bac>
    81c8:      	cbz	x0, 0x8204 <.text+0x2c18>
    81cc:      	ldr	x8, [sp, #0x68]
    81d0:      	cbz	x8, 0x8204 <.text+0x2c18>
    81d4:      	str	xzr, [sp]
    81d8:      	ldrb	w8, [x19, #0xc]
    81dc:      	ldr	x5, [x19, #0x48]
    81e0:      	mov	x2, x0
    81e4:      	add	x3, sp, #0x60
    81e8:      	add	x4, sp, #0x8
    81ec:      	mov	x6, sp
    81f0:      	mov	x0, x20
    81f4:      	mov	x1, x19
    81f8:      	cbz	w8, 0x8224 <.text+0x2c38>
    81fc:      	bl	0xa784 <JNI_OnLoad+0x1628>
    8200:      	b	0x8228 <.text+0x2c3c>
    8204:      	ldr	x2, [x20, #0xa0]
    8208:      	mov	w1, #0xd                // =13
    820c:      	mov	x0, x19
    8210:      	mov	x3, xzr
    8214:      	b	0x8238 <.text+0x2c4c>
    8218:      	ldr	x2, [x20, #0xa0]
    821c:      	mov	w1, #0x16               // =22
    8220:      	b	0x80ec <.text+0x2b00>
    8224:      	bl	0xa3c0 <JNI_OnLoad+0x1264>
    8228:      	ldr	x2, [x20, #0xa0]
    822c:      	ldr	x3, [sp]
    8230:      	mov	w1, w0
    8234:      	mov	x0, x19
    8238:      	bl	0xb0ac <JNI_OnLoad+0x1f50>
    823c:      	bl	0x874c <.text+0x3160>
    8240:      	bl	0x8744 <.text+0x3158>
    8244:      	ldr	x8, [x21, #0x28]
    8248:      	ldur	x9, [x29, #-0x8]
    824c:      	cmp	x8, x9
    8250:      	b.ne	0x8268 <.text+0x2c7c>
    8254:      	ldp	x20, x19, [sp, #0xe0]
    8258:      	ldr	x21, [sp, #0xd0]
    825c:      	ldp	x29, x30, [sp, #0xc0]
    8260:      	add	sp, sp, #0xf0
    8264:      	ret
    8268:      	bl	0xd2e0 <__stack_chk_fail@plt>
    826c:      	sub	sp, sp, #0xf0
    8270:      	stp	x29, x30, [sp, #0xc0]
    8274:      	stp	x22, x21, [sp, #0xd0]
    8278:      	stp	x20, x19, [sp, #0xe0]
    827c:      	add	x29, sp, #0xc0
    8280:      	mrs	x22, TPIDR_EL0
    8284:      	ldr	x8, [x22, #0x28]
    8288:      	bl	0x871c <.text+0x3130>
    828c:      	tbz	w0, #0x0, 0x82a0 <.text+0x2cb4>
    8290:      	ldr	x2, [x20, #0xa0]
    8294:      	mov	w1, #0x15               // =21
    8298:      	bl	0x8710 <.text+0x3124>
    829c:      	b	0x8348 <.text+0x2d5c>
    82a0:      	bl	0x872c <.text+0x3140>
    82a4:      	add	x8, x8, #0x18
    82a8:      	str	x8, [sp, #0x60]
    82ac:      	add	x8, sp, #0x8
    82b0:      	mov	w9, #0x8                // =8
    82b4:      	add	x8, x8, #0x18
    82b8:      	stur	q0, [sp, #0x68]
    82bc:      	stur	q0, [sp, #0x78]
    82c0:      	str	x9, [sp, #0x70]
    82c4:      	stp	q0, q0, [sp, #0x10]
    82c8:      	stp	q0, q0, [sp, #0x40]
    82cc:      	stur	q0, [sp, #0x30]
    82d0:      	str	x8, [sp, #0x8]
    82d4:      	str	x9, [sp, #0x18]
    82d8:      	ldr	x21, [x19, #0x40]
    82dc:      	bl	0xd3d0 <bytehook_get_mode@plt>
    82e0:      	cmp	w0, #0x1
    82e4:      	b.ne	0x82f0 <.text+0x2d04>
    82e8:      	ldr	x2, [x19, #0x48]
    82ec:      	b	0x82f4 <.text+0x2d08>
    82f0:      	mov	x2, xzr
    82f4:      	add	x3, sp, #0x60
    82f8:      	add	x4, sp, #0x8
    82fc:      	mov	x0, x20
    8300:      	mov	x1, x21
    8304:      	bl	0x7198 <.text+0x1bac>
    8308:      	cbz	x0, 0x8334 <.text+0x2d48>
    830c:      	ldr	x8, [sp, #0x68]
    8310:      	cbz	x8, 0x8334 <.text+0x2d48>
    8314:      	ldr	x4, [x19, #0x48]
    8318:      	mov	x1, x0
    831c:      	add	x2, sp, #0x60
    8320:      	add	x3, sp, #0x8
    8324:      	mov	x0, x20
    8328:      	bl	0xa880 <JNI_OnLoad+0x1724>
    832c:      	mov	w1, w0
    8330:      	b	0x8338 <.text+0x2d4c>
    8334:      	mov	w1, #0xd                // =13
    8338:      	ldr	x2, [x20, #0xa0]
    833c:      	bl	0x8710 <.text+0x3124>
    8340:      	bl	0x874c <.text+0x3160>
    8344:      	bl	0x8744 <.text+0x3158>
    8348:      	ldr	x8, [x22, #0x28]
    834c:      	ldur	x9, [x29, #-0x8]
    8350:      	cmp	x8, x9
    8354:      	b.ne	0x836c <.text+0x2d80>
    8358:      	ldp	x20, x19, [sp, #0xe0]
    835c:      	ldp	x22, x21, [sp, #0xd0]
    8360:      	ldp	x29, x30, [sp, #0xc0]
    8364:      	add	sp, sp, #0xf0
    8368:      	ret
    836c:      	bl	0xd2e0 <__stack_chk_fail@plt>
    8370:      	sub	sp, sp, #0x1b0
    8374:      	stp	x29, x30, [sp, #0x150]
    8378:      	stp	x28, x27, [sp, #0x160]
    837c:      	stp	x26, x25, [sp, #0x170]
    8380:      	stp	x24, x23, [sp, #0x180]
    8384:      	stp	x22, x21, [sp, #0x190]
    8388:      	stp	x20, x19, [sp, #0x1a0]
    838c:      	add	x29, sp, #0x150
    8390:      	stp	x3, x4, [sp, #0x18]
    8394:      	mrs	x8, TPIDR_EL0
    8398:      	str	x8, [sp, #0x28]
    839c:      	ldr	x8, [x8, #0x28]
    83a0:      	mov	x23, x5
    83a4:      	mov	x21, x2
    83a8:      	mov	x22, x1
    83ac:      	mov	x24, x0
    83b0:      	stur	x8, [x29, #-0x10]
    83b4:      	bl	0xd2b0 <gettid@plt>
    83b8:      	mov	w19, w0
    83bc:      	mov	w25, w0
    83c0:      	cbnz	w0, 0x83d4 <.text+0x2de8>
    83c4:      	mov	w8, #0xb2               // =178
    83c8:      	mov	w0, w8
    83cc:      	bl	0xd2c0 <syscall@plt>
    83d0:      	mov	w25, w0
    83d4:      	mov	x27, #0xb               // =11
    83d8:      	mov	w8, #0x2                // =2
    83dc:      	add	x26, sp, #0x38
    83e0:      	movk	x27, #0x7, lsl #32
    83e4:      	add	x2, sp, #0x30
    83e8:      	mov	w3, w8
    83ec:      	mov	w0, w25
    83f0:      	mov	x1, x26
    83f4:      	str	x27, [sp, #0x30]
    83f8:      	bl	0xce14 <bytehook_del_dlopen_callback+0x2ec>
    83fc:      	mov	w1, #0x1                // =1
    8400:      	mov	x0, x26
    8404:      	bl	0xd2d0 <sigsetjmp@plt>
    8408:      	mov	w20, w0
    840c:      	cbz	w0, 0x8418 <.text+0x2e2c>
    8410:      	mov	x26, xzr
    8414:      	b	0x8424 <.text+0x2e38>
    8418:      	ldr	x8, [x21]
    841c:      	ldr	x8, [x8]
    8420:      	ldr	x26, [x8]
    8424:      	mov	w8, #0x2                // =2
    8428:      	add	x1, sp, #0x30
    842c:      	mov	w2, w8
    8430:      	mov	w0, w25
    8434:      	bl	0xceb4 <bytehook_del_dlopen_callback+0x38c>
    8438:      	cbz	w20, 0x8474 <.text+0x2e88>
    843c:      	mov	w0, #0x15               // =21
    8440:      	ldr	x8, [sp, #0x28]
    8444:      	ldr	x8, [x8, #0x28]
    8448:      	ldur	x9, [x29, #-0x10]
    844c:      	cmp	x8, x9
    8450:      	b.ne	0x8574 <.text+0x2f88>
    8454:      	ldp	x20, x19, [sp, #0x1a0]
    8458:      	ldp	x22, x21, [sp, #0x190]
    845c:      	ldp	x24, x23, [sp, #0x180]
    8460:      	ldp	x26, x25, [sp, #0x170]
    8464:      	ldp	x28, x27, [sp, #0x160]
    8468:      	ldp	x29, x30, [sp, #0x150]
    846c:      	add	sp, sp, #0x1b0
    8470:      	ret
    8474:      	cbz	x23, 0x847c <.text+0x2e90>
    8478:      	str	x26, [x23]
    847c:      	ldr	x1, [x24, #0xa0]
    8480:      	mov	x0, x22
    8484:      	mov	x2, x26
    8488:      	str	x27, [sp, #0x10]
    848c:      	bl	0xb148 <JNI_OnLoad+0x1fec>
    8490:      	mov	w10, #0x2               // =2
    8494:      	mov	x26, xzr
    8498:      	mov	w20, #0x15              // =21
    849c:      	mov	w9, #0xb2               // =178
    84a0:      	add	x22, sp, #0x38
    84a4:      	add	x23, sp, #0x30
    84a8:      	mov	w25, w10
    84ac:      	str	x9, [sp, #0x8]
    84b0:      	ldr	x8, [x21, #0x8]
    84b4:      	cmp	x26, x8
    84b8:      	b.hs	0x8564 <.text+0x2f78>
    84bc:      	ldr	x9, [sp, #0x18]
    84c0:      	ldr	x8, [x21]
    84c4:      	lsl	x10, x26, #3
    84c8:      	ldr	x9, [x9]
    84cc:      	ldr	x27, [x8, x26, lsl #3]
    84d0:      	ldr	w8, [x9, x10]
    84d4:      	tbnz	w8, #0x1, 0x84e8 <.text+0x2efc>
    84d8:      	orr	w1, w8, #0x2
    84dc:      	mov	x0, x27
    84e0:      	bl	0xb974 <JNI_OnLoad+0x2818>
    84e4:      	cbnz	w0, 0x856c <.text+0x2f80>
    84e8:      	mov	w28, w19
    84ec:      	cbnz	w19, 0x84fc <.text+0x2f10>
    84f0:      	ldr	x0, [sp, #0x8]
    84f4:      	bl	0xd2c0 <syscall@plt>
    84f8:      	mov	w28, w0
    84fc:      	ldr	x8, [sp, #0x10]
    8500:      	mov	w0, w28
    8504:      	mov	x1, x22
    8508:      	mov	x2, x23
    850c:      	mov	x3, x25
    8510:      	str	x8, [sp, #0x30]
    8514:      	bl	0xce14 <bytehook_del_dlopen_callback+0x2ec>
    8518:      	mov	x0, x22
    851c:      	mov	w1, #0x1                // =1
    8520:      	bl	0xd2d0 <sigsetjmp@plt>
    8524:      	mov	w24, w0
    8528:      	cbz	w0, 0x8534 <.text+0x2f48>
    852c:      	mov	w20, #0x10              // =16
    8530:      	b	0x853c <.text+0x2f50>
    8534:      	ldr	x8, [sp, #0x20]
    8538:      	stlr	x8, [x27]
    853c:      	mov	w8, #0x2                // =2
    8540:      	mov	w2, w8
    8544:      	mov	w0, w28
    8548:      	mov	x1, x23
    854c:      	mov	w27, w20
    8550:      	bl	0xceb4 <bytehook_del_dlopen_callback+0x38c>
    8554:      	add	x26, x26, #0x1
    8558:      	mov	w0, w20
    855c:      	cbz	w24, 0x84b0 <.text+0x2ec4>
    8560:      	b	0x8440 <.text+0x2e54>
    8564:      	mov	w0, wzr
    8568:      	b	0x8440 <.text+0x2e54>
    856c:      	mov	w0, #0xf                // =15
    8570:      	b	0x8440 <.text+0x2e54>
    8574:      	bl	0xd2e0 <__stack_chk_fail@plt>
    8578:      	sub	sp, sp, #0xf0
    857c:      	stp	x29, x30, [sp, #0xc0]
    8580:      	stp	x22, x21, [sp, #0xd0]
    8584:      	stp	x20, x19, [sp, #0xe0]
    8588:      	add	x29, sp, #0xc0
    858c:      	mrs	x22, TPIDR_EL0
    8590:      	ldr	x8, [x22, #0x28]
    8594:      	add	x9, sp, #0x60
    8598:      	movi	v0.2d, #0000000000000000
    859c:      	mov	x21, x2
    85a0:      	stur	x8, [x29, #-0x8]
    85a4:      	stur	q0, [x9, #0x48]
    85a8:      	stur	q0, [x9, #0x38]
    85ac:      	stur	q0, [x9, #0x28]
    85b0:      	add	x9, x9, #0x18
    85b4:      	str	x9, [sp, #0x60]
    85b8:      	add	x9, sp, #0x8
    85bc:      	mov	w8, #0x8                // =8
    85c0:      	add	x9, x9, #0x18
    85c4:      	add	x3, sp, #0x60
    85c8:      	add	x4, sp, #0x8
    85cc:      	mov	x2, xzr
    85d0:      	mov	x19, x1
    85d4:      	mov	x20, x0
    85d8:      	stur	q0, [sp, #0x68]
    85dc:      	stur	q0, [sp, #0x78]
    85e0:      	str	x8, [sp, #0x70]
    85e4:      	stp	q0, q0, [sp, #0x10]
    85e8:      	stp	q0, q0, [sp, #0x40]
    85ec:      	stur	q0, [sp, #0x30]
    85f0:      	str	x9, [sp, #0x8]
    85f4:      	str	x8, [sp, #0x18]
    85f8:      	bl	0x7198 <.text+0x1bac>
    85fc:      	cbz	x0, 0x8658 <.text+0x306c>
    8600:      	ldr	x8, [sp, #0x68]
    8604:      	cbz	x8, 0x8658 <.text+0x306c>
    8608:      	add	x2, sp, #0x60
    860c:      	add	x3, sp, #0x8
    8610:      	mov	x0, x20
    8614:      	mov	x1, xzr
    8618:      	mov	x4, x21
    861c:      	mov	x5, xzr
    8620:      	bl	0x8370 <.text+0x2d84>
    8624:      	mov	w21, w0
    8628:      	bl	0x874c <.text+0x3160>
    862c:      	bl	0x8744 <.text+0x3158>
    8630:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    8634:      	ldr	x8, [x8, #0xaa8]
    8638:      	cbz	w21, 0x8694 <.text+0x30a8>
    863c:      	cmp	w21, #0xd
    8640:      	b.eq	0x8660 <.text+0x3074>
    8644:      	ldr	w8, [x8]
    8648:      	cmp	w8, #0x4
    864c:      	b.ls	0x86dc <.text+0x30f0>
    8650:      	mov	w0, #-0x1               // =-1
    8654:      	b	0x8670 <.text+0x3084>
    8658:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    865c:      	ldr	x8, [x8, #0xaa8]
    8660:      	ldr	w8, [x8]
    8664:      	cmp	w8, #0x4
    8668:      	b.ls	0x86b8 <.text+0x30cc>
    866c:      	mov	w0, wzr
    8670:      	ldr	x8, [x22, #0x28]
    8674:      	ldur	x9, [x29, #-0x8]
    8678:      	cmp	x8, x9
    867c:      	b.ne	0x8704 <.text+0x3118>
    8680:      	ldp	x20, x19, [sp, #0xe0]
    8684:      	ldp	x22, x21, [sp, #0xd0]
    8688:      	ldp	x29, x30, [sp, #0xc0]
    868c:      	add	sp, sp, #0xf0
    8690:      	ret
    8694:      	ldr	w8, [x8]
    8698:      	cmp	w8, #0x4
    869c:      	b.hi	0x866c <.text+0x3080>
    86a0:      	ldr	x3, [x20, #0xa0]
    86a4:      	adrp	x1, 0x2000
    86a8:      	adrp	x2, 0x2000
    86ac:      	add	x1, x1, #0x94c
    86b0:      	add	x2, x2, #0x5a3
    86b4:      	b	0x86cc <.text+0x30e0>
    86b8:      	ldr	x3, [x20, #0xa0]
    86bc:      	adrp	x1, 0x2000
    86c0:      	adrp	x2, 0x2000
    86c4:      	add	x1, x1, #0x94c
    86c8:      	add	x2, x2, #0x8d0
    86cc:      	mov	w0, #0x4                // =4
    86d0:      	mov	x4, x19
    86d4:      	bl	0xd3a0 <__android_log_print@plt>
    86d8:      	b	0x866c <.text+0x3080>
    86dc:      	ldr	x3, [x20, #0xa0]
    86e0:      	adrp	x1, 0x2000
    86e4:      	adrp	x2, 0x2000
    86e8:      	add	x1, x1, #0x94c
    86ec:      	add	x2, x2, #0x5f4
    86f0:      	mov	w0, #0x4                // =4
    86f4:      	mov	x4, x19
    86f8:      	mov	w5, w21
    86fc:      	bl	0xd3a0 <__android_log_print@plt>
    8700:      	b	0x8650 <.text+0x3064>
    8704:      	bl	0xd2e0 <__stack_chk_fail@plt>
    8708:      	ret
    870c:      	ret
    8710:      	mov	x0, x19
    8714:      	mov	x3, xzr
    8718:      	b	0xb0ac <JNI_OnLoad+0x1f50>
    871c:      	mov	x19, x1
    8720:      	mov	x20, x0
    8724:      	stur	x8, [x29, #-0x8]
    8728:      	b	0x6d58 <.text+0x176c>
    872c:      	add	x8, sp, #0x60
    8730:      	movi	v0.2d, #0000000000000000
    8734:      	stur	q0, [x8, #0x48]
    8738:      	stur	q0, [x8, #0x38]
    873c:      	stur	q0, [x8, #0x28]
    8740:      	ret
    8744:      	add	x0, sp, #0x8
    8748:      	b	0x56f4 <.text+0x108>
    874c:      	add	x0, sp, #0x60
    8750:      	b	0x56f4 <.text+0x108>
    8754:      	stp	x29, x30, [sp, #-0x20]!
    8758:      	str	x19, [sp, #0x10]
    875c:      	mov	x29, sp
    8760:      	adrp	x19, 0x15000
    8764:      	add	x19, x19, #0xf58
    8768:      	add	x0, x19, #0x20
    876c:      	mov	x1, xzr
    8770:      	str	xzr, [x19, #0x8]
    8774:      	bl	0xd490 <pthread_mutex_init@plt>
    8778:      	adrp	x1, 0x8000 <.text+0x2a14>
    877c:      	add	x1, x1, #0x818
    8780:      	mov	x0, x19
    8784:      	bl	0xd3c0 <pthread_key_create@plt>
    8788:      	cbnz	w0, 0x8810 <.text+0x3224>
    878c:      	adrp	x0, 0x15000
    8790:      	add	x0, x0, #0xf5c
    8794:      	mov	x1, xzr
    8798:      	bl	0xd3c0 <pthread_key_create@plt>
    879c:      	cbnz	w0, 0x8810 <.text+0x3224>
    87a0:      	mov	w0, #0x2000             // =8192
    87a4:      	movk	w0, #0x6, lsl #16
    87a8:      	bl	0xd270 <malloc@plt>
    87ac:      	adrp	x8, 0x15000
    87b0:      	str	x0, [x8, #0xf68]
    87b4:      	cbz	x0, 0x8810 <.text+0x3224>
    87b8:      	mov	w0, #0x400              // =1024
    87bc:      	mov	w1, #0x1                // =1
    87c0:      	bl	0xd300 <calloc@plt>
    87c4:      	adrp	x8, 0x15000
    87c8:      	str	x0, [x8, #0xf70]
    87cc:      	cbz	x0, 0x8810 <.text+0x3224>
    87d0:      	adrp	x8, 0x9000 <.text+0x3a14>
    87d4:      	adrp	x9, 0x9000 <.text+0x3a14>
    87d8:      	add	x8, x8, #0xa4
    87dc:      	add	x9, x9, #0x104
    87e0:      	sub	x8, x9, x8
    87e4:      	adrp	x0, 0x15000
    87e8:      	adrp	x1, 0x2000
    87ec:      	add	x2, x8, #0x10
    87f0:      	add	x0, x0, #0xfa0
    87f4:      	add	x1, x1, #0x3ce
    87f8:      	mov	w3, #0x5                // =5
    87fc:      	bl	0xb5c4 <JNI_OnLoad+0x2468>
    8800:      	mov	w0, wzr
    8804:      	ldr	x19, [sp, #0x10]
    8808:      	ldp	x29, x30, [sp], #0x20
    880c:      	ret
    8810:      	mov	w0, #-0x1               // =-1
    8814:      	b	0x8804 <.text+0x3218>
    8818:      	stp	x29, x30, [sp, #-0x10]!
    881c:      	mov	x29, sp
    8820:      	cbz	x0, 0x8848 <.text+0x325c>
    8824:      	adrp	x8, 0x15000
    8828:      	ldr	x8, [x8, #0xf68]
    882c:      	add	x9, x8, #0x62, lsl #12  // =0x62000
    8830:      	cmp	x8, x0
    8834:      	ccmp	x9, x0, #0x0, ls
    8838:      	b.hi	0x8850 <.text+0x3264>
    883c:      	mov	w1, #0x1000             // =4096
    8840:      	bl	0xa20c <JNI_OnLoad+0x10b0>
    8844:      	b	0x8878 <.text+0x328c>
    8848:      	ldp	x29, x30, [sp], #0x10
    884c:      	ret
    8850:      	adrp	x9, 0x15000
    8854:      	ldr	x9, [x9, #0xf70]
    8858:      	sub	x8, x0, x8
    885c:      	mov	w10, #0x188             // =392
    8860:      	udiv	x8, x8, x10
    8864:      	ldrb	w10, [x9, x8]
    8868:      	cmp	w10, #0x1
    886c:      	b.ne	0x888c <.text+0x32a0>
    8870:      	add	x8, x9, x8
    8874:      	stlrb	wzr, [x8]
    8878:      	adrp	x8, 0x15000
    887c:      	ldr	w0, [x8, #0xf5c]
    8880:      	mov	w1, #0x1                // =1
    8884:      	ldp	x29, x30, [sp], #0x10
    8888:      	b	0xa194 <JNI_OnLoad+0x1038>
    888c:      	bl	0xd4d0 <abort@plt>
    8890:      	stp	x29, x30, [sp, #-0x20]!
    8894:      	str	x19, [sp, #0x10]
    8898:      	mov	x29, sp
    889c:      	bl	0x9128 <.text+0x3b3c>
    88a0:      	ldr	x8, [x0]
    88a4:      	cbz	x8, 0x88c4 <.text+0x32d8>
    88a8:      	sub	x8, x8, #0x1
    88ac:      	mov	w9, #0x18               // =24
    88b0:      	madd	x9, x8, x9, x0
    88b4:      	ldr	x9, [x9, #0x18]
    88b8:      	cmp	x9, x19
    88bc:      	b.ne	0x88c4 <.text+0x32d8>
    88c0:      	str	x8, [x0]
    88c4:      	ldr	x19, [sp, #0x10]
    88c8:      	ldp	x29, x30, [sp], #0x20
    88cc:      	ret
    88d0:      	sub	sp, sp, #0x180
    88d4:      	stp	x29, x30, [sp, #0x120]
    88d8:      	str	x28, [sp, #0x130]
    88dc:      	stp	x26, x25, [sp, #0x140]
    88e0:      	stp	x24, x23, [sp, #0x150]
    88e4:      	stp	x22, x21, [sp, #0x160]
    88e8:      	stp	x20, x19, [sp, #0x170]
    88ec:      	add	x29, sp, #0x120
    88f0:      	mrs	x23, TPIDR_EL0
    88f4:      	ldr	x8, [x23, #0x28]
    88f8:      	mov	x19, x0
    88fc:      	stur	x8, [x29, #-0x8]
    8900:      	mov	w8, #0x58               // =88
    8904:      	mov	w0, w8
    8908:      	bl	0xd270 <malloc@plt>
    890c:      	cbz	x0, 0x8a54 <.text+0x3468>
    8910:      	mov	x20, x0
    8914:      	str	xzr, [x0], #0x8
    8918:      	mov	x1, xzr
    891c:      	mov	x21, xzr
    8920:      	bl	0xd490 <pthread_mutex_init@plt>
    8924:      	adrp	x0, 0x15000
    8928:      	add	x0, x0, #0xfa0
    892c:      	str	x21, [x20, #0x30]
    8930:      	bl	0xb610 <JNI_OnLoad+0x24b4>
    8934:      	str	x0, [x20, #0x38]
    8938:      	cbz	x0, 0x89e8 <.text+0x33fc>
    893c:      	bl	0xd2b0 <gettid@plt>
    8940:      	mov	w22, w0
    8944:      	cbnz	w0, 0x8958 <.text+0x336c>
    8948:      	mov	w8, #0xb2               // =178
    894c:      	mov	w0, w8
    8950:      	bl	0xd2c0 <syscall@plt>
    8954:      	mov	w22, w0
    8958:      	mov	x8, #0xb                // =11
    895c:      	movk	x8, #0x7, lsl #32
    8960:      	str	x8, [sp, #0x8]
    8964:      	mov	w8, #0x2                // =2
    8968:      	add	x21, sp, #0x10
    896c:      	add	x2, sp, #0x8
    8970:      	mov	w3, w8
    8974:      	mov	w0, w22
    8978:      	mov	x1, x21
    897c:      	bl	0xce14 <bytehook_del_dlopen_callback+0x2ec>
    8980:      	mov	w1, #0x1                // =1
    8984:      	mov	x0, x21
    8988:      	bl	0xd2d0 <sigsetjmp@plt>
    898c:      	adrp	x24, 0x11000 <siglongjmp@plt+0x3870>
    8990:      	ldr	x24, [x24, #0xaa8]
    8994:      	adrp	x21, 0x9000 <.text+0x3a14>
    8998:      	adrp	x25, 0x9000 <.text+0x3a14>
    899c:      	mov	w26, w0
    89a0:      	add	x21, x21, #0xa4
    89a4:      	add	x25, x25, #0x104
    89a8:      	cbz	w0, 0x89f4 <.text+0x3408>
    89ac:      	bl	0x9114 <.text+0x3b28>
    89b0:      	ldr	x1, [x20, #0x38]
    89b4:      	bl	0x913c <.text+0x3b50>
    89b8:      	mov	x0, x20
    89bc:      	bl	0xd260 <free@plt>
    89c0:      	ldr	w8, [x24]
    89c4:      	cmp	w8, #0x5
    89c8:      	b.hi	0x8a08 <.text+0x341c>
    89cc:      	adrp	x1, 0x2000
    89d0:      	adrp	x2, 0x2000
    89d4:      	add	x1, x1, #0x94c
    89d8:      	add	x2, x2, #0xa9f
    89dc:      	mov	w0, #0x5                // =5
    89e0:      	bl	0xd3a0 <__android_log_print@plt>
    89e4:      	b	0x8a08 <.text+0x341c>
    89e8:      	mov	x0, x20
    89ec:      	bl	0xd260 <free@plt>
    89f0:      	b	0x8a0c <.text+0x3420>
    89f4:      	ldr	x0, [x20, #0x38]
    89f8:      	sub	x2, x25, x21
    89fc:      	mov	x1, x21
    8a00:      	bl	0xd510 <memcpy@plt>
    8a04:      	bl	0x9114 <.text+0x3b28>
    8a08:      	cbz	w26, 0x8a14 <.text+0x3428>
    8a0c:      	mov	x0, xzr
    8a10:      	b	0x8a54 <.text+0x3468>
    8a14:      	ldr	x0, [x20, #0x38]
    8a18:      	sub	x21, x25, x21
    8a1c:      	adrp	x8, 0x8000 <.text+0x2a14>
    8a20:      	add	x22, x21, #0x10
    8a24:      	add	x8, x8, #0xab8
    8a28:      	add	x9, x0, x21
    8a2c:      	mov	x1, x22
    8a30:      	mov	x26, x20
    8a34:      	stp	x8, x20, [x9]
    8a38:      	bl	0xb9d8 <JNI_OnLoad+0x287c>
    8a3c:      	ldr	x3, [x20, #0x38]
    8a40:      	mov	x0, x20
    8a44:      	str	x3, [x19]
    8a48:      	ldr	w8, [x24]
    8a4c:      	cmp	w8, #0x4
    8a50:      	b.ls	0x8a84 <.text+0x3498>
    8a54:      	ldr	x8, [x23, #0x28]
    8a58:      	ldur	x9, [x29, #-0x8]
    8a5c:      	cmp	x8, x9
    8a60:      	b.ne	0x8ab4 <.text+0x34c8>
    8a64:      	ldp	x20, x19, [sp, #0x170]
    8a68:      	ldp	x22, x21, [sp, #0x160]
    8a6c:      	ldp	x24, x23, [sp, #0x150]
    8a70:      	ldp	x26, x25, [sp, #0x140]
    8a74:      	ldr	x28, [sp, #0x130]
    8a78:      	ldp	x29, x30, [sp, #0x120]
    8a7c:      	add	sp, sp, #0x180
    8a80:      	ret
    8a84:      	adrp	x1, 0x2000
    8a88:      	adrp	x2, 0x2000
    8a8c:      	mov	w8, #0x10               // =16
    8a90:      	add	x1, x1, #0x94c
    8a94:      	add	x2, x2, #0xa3c
    8a98:      	mov	w0, #0x4                // =4
    8a9c:      	mov	w5, w8
    8aa0:      	mov	x4, x21
    8aa4:      	mov	x6, x22
    8aa8:      	bl	0xd3a0 <__android_log_print@plt>
    8aac:      	mov	x0, x20
    8ab0:      	b	0x8a54 <.text+0x3468>
    8ab4:      	bl	0xd2e0 <__stack_chk_fail@plt>
    8ab8:      	stp	x29, x30, [sp, #-0x30]!
    8abc:      	stp	x22, x21, [sp, #0x10]
    8ac0:      	stp	x20, x19, [sp, #0x20]
    8ac4:      	mov	x29, sp
    8ac8:      	adrp	x8, 0x15000
    8acc:      	ldr	w8, [x8, #0xf5c]
    8ad0:      	mov	x20, x0
    8ad4:      	mov	x19, x1
    8ad8:      	mov	w0, w8
    8adc:      	bl	0xa188 <JNI_OnLoad+0x102c>
    8ae0:      	cbnz	x0, 0x8b50 <.text+0x3564>
    8ae4:      	adrp	x22, 0x15000
    8ae8:      	ldr	w0, [x22, #0xf58]
    8aec:      	bl	0xa188 <JNI_OnLoad+0x102c>
    8af0:      	mov	x21, x0
    8af4:      	cbz	x0, 0x8b8c <.text+0x35a0>
    8af8:      	ldr	x8, [x21]
    8afc:      	mov	w9, #0x18               // =24
    8b00:      	madd	x9, x8, x9, x21
    8b04:      	sub	x10, x9, #0x8
    8b08:      	mov	x9, #-0x1               // =-1
    8b0c:      	add	x9, x9, #0x1
    8b10:      	cmp	x8, x9
    8b14:      	b.eq	0x8b2c <.text+0x3540>
    8b18:      	ldr	x11, [x10], #-0x18
    8b1c:      	ldr	x12, [x20, #0x30]
    8b20:      	cmp	x11, x12
    8b24:      	b.ne	0x8b0c <.text+0x3520>
    8b28:      	b	0x8b50 <.text+0x3564>
    8b2c:      	mov	x9, x20
    8b30:      	ldr	x9, [x9]
    8b34:      	cbz	x9, 0x8b50 <.text+0x3564>
    8b38:      	ldrb	w10, [x9, #0x8]
    8b3c:      	cbnz	w10, 0x8b48 <.text+0x355c>
    8b40:      	add	x9, x9, #0x10
    8b44:      	b	0x8b30 <.text+0x3544>
    8b48:      	cmp	x8, #0xf
    8b4c:      	b.ls	0x8b64 <.text+0x3578>
    8b50:      	ldr	x0, [x20, #0x30]
    8b54:      	ldp	x20, x19, [sp, #0x20]
    8b58:      	ldp	x22, x21, [sp, #0x10]
    8b5c:      	ldp	x29, x30, [sp], #0x30
    8b60:      	ret
    8b64:      	add	x10, x8, #0x1
    8b68:      	str	x10, [x21]
    8b6c:      	ldr	x10, [x20]
    8b70:      	mov	w11, #0x18              // =24
    8b74:      	madd	x8, x8, x11, x21
    8b78:      	str	x10, [x8, #0x8]
    8b7c:      	ldr	x10, [x20, #0x30]
    8b80:      	stp	x10, x19, [x8, #0x10]
    8b84:      	ldr	x0, [x9]
    8b88:      	b	0x8b54 <.text+0x3568>
    8b8c:      	mov	x8, xzr
    8b90:      	adrp	x9, 0x15000
    8b94:      	mov	w10, #0x1               // =1
    8b98:      	cmp	x8, #0x400
    8b9c:      	b.eq	0x8bf4 <.text+0x3608>
    8ba0:      	ldr	x11, [x9, #0xf70]
    8ba4:      	add	x11, x11, x8
    8ba8:      	ldrb	w12, [x11]
    8bac:      	cbnz	w12, 0x8bc8 <.text+0x35dc>
    8bb0:      	b	0x8bbc <.text+0x35d0>
    8bb4:      	stxrb	w12, w10, [x11]
    8bb8:      	cbz	w12, 0x8bd0 <.text+0x35e4>
    8bbc:      	ldaxrb	w12, [x11]
    8bc0:      	cbz	w12, 0x8bb4 <.text+0x35c8>
    8bc4:      	clrex
    8bc8:      	add	x8, x8, #0x1
    8bcc:      	b	0x8b98 <.text+0x35ac>
    8bd0:      	adrp	x9, 0x15000
    8bd4:      	ldr	x9, [x9, #0xf68]
    8bd8:      	mov	w10, #0x188             // =392
    8bdc:      	madd	x21, x8, x10, x9
    8be0:      	str	xzr, [x21]
    8be4:      	ldr	w0, [x22, #0xf58]
    8be8:      	mov	x1, x21
    8bec:      	bl	0xa194 <JNI_OnLoad+0x1038>
    8bf0:      	b	0x8af8 <.text+0x350c>
    8bf4:      	mov	w1, #0x1000             // =4096
    8bf8:      	mov	w2, #0x3                // =3
    8bfc:      	mov	w3, #0x22               // =34
    8c00:      	mov	w4, #-0x1               // =-1
    8c04:      	mov	x0, xzr
    8c08:      	mov	x5, xzr
    8c0c:      	bl	0xa1cc <JNI_OnLoad+0x1070>
    8c10:      	cmn	x0, #0x1
    8c14:      	b.eq	0x8b50 <.text+0x3564>
    8c18:      	mov	x21, x0
    8c1c:      	adrp	x4, 0x2000
    8c20:      	mov	w0, #0x4d41             // =19777
    8c24:      	add	x4, x4, #0x532
    8c28:      	movk	w0, #0x5356, lsl #16
    8c2c:      	mov	w3, #0x1000             // =4096
    8c30:      	mov	x1, xzr
    8c34:      	mov	x2, x21
    8c38:      	bl	0xa240 <JNI_OnLoad+0x10e4>
    8c3c:      	b	0x8be0 <.text+0x35f4>
    8c40:      	sub	sp, sp, #0x60
    8c44:      	stp	x29, x30, [sp, #0x20]
    8c48:      	stp	x24, x23, [sp, #0x30]
    8c4c:      	stp	x22, x21, [sp, #0x40]
    8c50:      	stp	x20, x19, [sp, #0x50]
    8c54:      	add	x29, sp, #0x20
    8c58:      	mrs	x21, TPIDR_EL0
    8c5c:      	ldr	x8, [x21, #0x28]
    8c60:      	mov	w20, w1
    8c64:      	mov	x19, x0
    8c68:      	add	x0, sp, #0x8
    8c6c:      	mov	x1, xzr
    8c70:      	stur	x8, [x29, #-0x8]
    8c74:      	bl	0xd4f0 <gettimeofday@plt>
    8c78:      	adrp	x8, 0x15000
    8c7c:      	ldr	x8, [x8, #0xf60]
    8c80:      	adrp	x22, 0x15000
    8c84:      	add	x22, x22, #0xf60
    8c88:      	cbz	x8, 0x8cdc <.text+0x36f0>
    8c8c:      	add	x0, x22, #0x18
    8c90:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    8c94:      	ldr	x24, [x22]
    8c98:      	ldr	x23, [sp, #0x8]
    8c9c:      	cbz	x24, 0x8cd0 <.text+0x36e4>
    8ca0:      	mov	x0, x24
    8ca4:      	ldp	x8, x24, [x24, #0x40]
    8ca8:      	sub	x8, x23, x8
    8cac:      	cmp	x8, #0xb
    8cb0:      	b.lt	0x8c9c <.text+0x36b0>
    8cb4:      	cbz	x24, 0x8cc0 <.text+0x36d4>
    8cb8:      	ldr	x8, [x0, #0x50]
    8cbc:      	str	x8, [x24, #0x50]
    8cc0:      	ldr	x8, [x0, #0x50]
    8cc4:      	str	x24, [x8]
    8cc8:      	bl	0x8d60 <.text+0x3774>
    8ccc:      	b	0x8c9c <.text+0x36b0>
    8cd0:      	adrp	x0, 0x15000
    8cd4:      	add	x0, x0, #0xf78
    8cd8:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    8cdc:      	tbz	w20, #0x0, 0x8d2c <.text+0x3740>
    8ce0:      	ldr	x8, [sp, #0x8]
    8ce4:      	ldr	x1, [x19, #0x38]
    8ce8:      	add	x0, x22, #0x40
    8cec:      	str	x8, [x19, #0x40]
    8cf0:      	bl	0xb860 <JNI_OnLoad+0x2704>
    8cf4:      	add	x20, x22, #0x18
    8cf8:      	mov	x0, x20
    8cfc:      	str	xzr, [x19, #0x38]
    8d00:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    8d04:      	ldr	x8, [x22]
    8d08:      	mov	x9, x19
    8d0c:      	str	x8, [x9, #0x48]!
    8d10:      	cbz	x8, 0x8d18 <.text+0x372c>
    8d14:      	str	x9, [x8, #0x50]
    8d18:      	mov	x0, x20
    8d1c:      	str	x19, [x22]
    8d20:      	str	x22, [x19, #0x50]
    8d24:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    8d28:      	b	0x8d34 <.text+0x3748>
    8d2c:      	mov	x0, x19
    8d30:      	bl	0x8d60 <.text+0x3774>
    8d34:      	ldr	x8, [x21, #0x28]
    8d38:      	ldur	x9, [x29, #-0x8]
    8d3c:      	cmp	x8, x9
    8d40:      	b.ne	0x8d5c <.text+0x3770>
    8d44:      	ldp	x20, x19, [sp, #0x50]
    8d48:      	ldp	x22, x21, [sp, #0x40]
    8d4c:      	ldp	x24, x23, [sp, #0x30]
    8d50:      	ldp	x29, x30, [sp, #0x20]
    8d54:      	add	sp, sp, #0x60
    8d58:      	ret
    8d5c:      	bl	0xd2e0 <__stack_chk_fail@plt>
    8d60:      	stp	x29, x30, [sp, #-0x20]!
    8d64:      	str	x19, [sp, #0x10]
    8d68:      	mov	x29, sp
    8d6c:      	mov	x19, x0
    8d70:      	add	x0, x0, #0x8
    8d74:      	bl	0xd4b0 <pthread_mutex_destroy@plt>
    8d78:      	ldr	x1, [x19, #0x38]
    8d7c:      	cbz	x1, 0x8d94 <.text+0x37a8>
    8d80:      	bl	0x913c <.text+0x3b50>
    8d84:      	b	0x8d94 <.text+0x37a8>
    8d88:      	ldr	x8, [x0, #0x10]
    8d8c:      	str	x8, [x19]
    8d90:      	bl	0xd260 <free@plt>
    8d94:      	ldr	x0, [x19]
    8d98:      	cbnz	x0, 0x8d88 <.text+0x379c>
    8d9c:      	mov	x0, x19
    8da0:      	ldr	x19, [sp, #0x10]
    8da4:      	ldp	x29, x30, [sp], #0x20
    8da8:      	b	0xd260 <free@plt>
    8dac:      	ldr	x0, [x0, #0x30]
    8db0:      	ret
    8db4:      	add	x0, x0, #0x30
    8db8:      	ret
    8dbc:      	stp	x29, x30, [sp, #-0x30]!
    8dc0:      	str	x21, [sp, #0x10]
    8dc4:      	stp	x20, x19, [sp, #0x20]
    8dc8:      	mov	x29, sp
    8dcc:      	add	x19, x0, #0x8
    8dd0:      	mov	x21, x0
    8dd4:      	mov	x0, x19
    8dd8:      	mov	x20, x1
    8ddc:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    8de0:      	mov	x8, x21
    8de4:      	ldr	x8, [x8]
    8de8:      	cbz	x8, 0x8e08 <.text+0x381c>
    8dec:      	ldrb	w9, [x8, #0x8]
    8df0:      	cbz	w9, 0x8e00 <.text+0x3814>
    8df4:      	ldr	x9, [x8]
    8df8:      	cmp	x9, x20
    8dfc:      	b.eq	0x8e28 <.text+0x383c>
    8e00:      	add	x8, x8, #0x10
    8e04:      	b	0x8de4 <.text+0x37f8>
    8e08:      	mov	x8, x21
    8e0c:      	ldr	x8, [x8]
    8e10:      	cbz	x8, 0x8e30 <.text+0x3844>
    8e14:      	ldr	x9, [x8]
    8e18:      	cmp	x9, x20
    8e1c:      	b.eq	0x8e70 <.text+0x3884>
    8e20:      	add	x8, x8, #0x10
    8e24:      	b	0x8e0c <.text+0x3820>
    8e28:      	mov	w20, #0x1d              // =29
    8e2c:      	b	0x8e90 <.text+0x38a4>
    8e30:      	mov	w0, #0x18               // =24
    8e34:      	bl	0xd270 <malloc@plt>
    8e38:      	cbz	x0, 0x8eac <.text+0x38c0>
    8e3c:      	mov	w8, #0x1                // =1
    8e40:      	str	x20, [x0]
    8e44:      	strb	w8, [x0, #0x8]
    8e48:      	ldr	x8, [x21]
    8e4c:      	str	x8, [x0, #0x10]
    8e50:      	stlr	x0, [x21]
    8e54:      	bl	0x9148 <.text+0x3b5c>
    8e58:      	b.hi	0x8e8c <.text+0x38a0>
    8e5c:      	adrp	x1, 0x2000
    8e60:      	adrp	x2, 0x2000
    8e64:      	add	x1, x1, #0x94c
    8e68:      	add	x2, x2, #0x8f6
    8e6c:      	b	0x8ec4 <.text+0x38d8>
    8e70:      	ldrb	w9, [x8, #0x8]
    8e74:      	cbnz	w9, 0x8e84 <.text+0x3898>
    8e78:      	add	x8, x8, #0x8
    8e7c:      	mov	w9, #0x1                // =1
    8e80:      	stlrb	w9, [x8]
    8e84:      	bl	0x9148 <.text+0x3b5c>
    8e88:      	b.ls	0x8eb4 <.text+0x38c8>
    8e8c:      	mov	w20, wzr
    8e90:      	mov	x0, x19
    8e94:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    8e98:      	mov	w0, w20
    8e9c:      	ldp	x20, x19, [sp, #0x20]
    8ea0:      	ldr	x21, [sp, #0x10]
    8ea4:      	ldp	x29, x30, [sp], #0x30
    8ea8:      	ret
    8eac:      	mov	w20, #0x1c              // =28
    8eb0:      	b	0x8e90 <.text+0x38a4>
    8eb4:      	adrp	x1, 0x2000
    8eb8:      	adrp	x2, 0x2000
    8ebc:      	add	x1, x1, #0x94c
    8ec0:      	add	x2, x2, #0x968
    8ec4:      	mov	w0, #0x4                // =4
    8ec8:      	mov	x3, x20
    8ecc:      	bl	0xd3a0 <__android_log_print@plt>
    8ed0:      	b	0x8e8c <.text+0x38a0>
    8ed4:      	stp	x29, x30, [sp, #-0x60]!
    8ed8:      	str	x27, [sp, #0x10]
    8edc:      	stp	x26, x25, [sp, #0x20]
    8ee0:      	stp	x24, x23, [sp, #0x30]
    8ee4:      	stp	x22, x21, [sp, #0x40]
    8ee8:      	stp	x20, x19, [sp, #0x50]
    8eec:      	mov	x29, sp
    8ef0:      	add	x19, x0, #0x8
    8ef4:      	mov	x24, x0
    8ef8:      	mov	x0, x19
    8efc:      	mov	x20, x2
    8f00:      	mov	x21, x1
    8f04:      	strb	wzr, [x2]
    8f08:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    8f0c:      	adrp	x25, 0x11000 <siglongjmp@plt+0x3870>
    8f10:      	ldr	x25, [x25, #0xaa8]
    8f14:      	adrp	x22, 0x2000
    8f18:      	adrp	x23, 0x2000
    8f1c:      	mov	w27, wzr
    8f20:      	add	x22, x22, #0x94c
    8f24:      	add	x23, x23, #0x3e7
    8f28:      	mov	w26, #0x1               // =1
    8f2c:      	ldr	x24, [x24]
    8f30:      	cbz	x24, 0x8fac <.text+0x39c0>
    8f34:      	ldr	x8, [x24]
    8f38:      	cmp	x8, x21
    8f3c:      	b.ne	0x8f60 <.text+0x3974>
    8f40:      	ldrb	w8, [x24, #0x8]
    8f44:      	cbz	w8, 0x8f50 <.text+0x3964>
    8f48:      	add	x8, x24, #0x8
    8f4c:      	stlrb	wzr, [x8]
    8f50:      	ldr	w8, [x25]
    8f54:      	cmp	w8, #0x4
    8f58:      	b.ls	0x8f90 <.text+0x39a4>
    8f5c:      	mov	w27, #0x1               // =1
    8f60:      	ldrb	w8, [x24, #0x8]
    8f64:      	cbz	w8, 0x8f70 <.text+0x3984>
    8f68:      	ldrb	w8, [x20]
    8f6c:      	cbz	w8, 0x8f84 <.text+0x3998>
    8f70:      	tbz	w27, #0x0, 0x8f7c <.text+0x3990>
    8f74:      	ldrb	w8, [x20]
    8f78:      	cbnz	w8, 0x8fa8 <.text+0x39bc>
    8f7c:      	add	x24, x24, #0x10
    8f80:      	b	0x8f2c <.text+0x3940>
    8f84:      	strb	w26, [x20]
    8f88:      	tbnz	w27, #0x0, 0x8f74 <.text+0x3988>
    8f8c:      	b	0x8f7c <.text+0x3990>
    8f90:      	mov	w0, #0x4                // =4
    8f94:      	mov	x1, x22
    8f98:      	mov	x2, x23
    8f9c:      	mov	x3, x21
    8fa0:      	bl	0xd3a0 <__android_log_print@plt>
    8fa4:      	b	0x8f5c <.text+0x3970>
    8fa8:      	mov	w27, #0x1               // =1
    8fac:      	mov	x0, x19
    8fb0:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    8fb4:      	and	w8, w27, #0x1
    8fb8:      	ldp	x20, x19, [sp, #0x50]
    8fbc:      	ldp	x22, x21, [sp, #0x40]
    8fc0:      	ldp	x24, x23, [sp, #0x30]
    8fc4:      	ldp	x26, x25, [sp, #0x20]
    8fc8:      	ldr	x27, [sp, #0x10]
    8fcc:      	sub	w0, w8, #0x1
    8fd0:      	ldp	x29, x30, [sp], #0x60
    8fd4:      	ret
    8fd8:      	stp	x29, x30, [sp, #-0x20]!
    8fdc:      	stp	x20, x19, [sp, #0x10]
    8fe0:      	mov	x29, sp
    8fe4:      	bl	0x9128 <.text+0x3b3c>
    8fe8:      	ldr	x9, [x0]
    8fec:      	mov	x20, x0
    8ff0:      	cbnz	x9, 0x8ffc <.text+0x3a10>
    8ff4:      	bl	0xa1c0 <JNI_OnLoad+0x1064>
    8ff8:      	ldr	x9, [x20]
    8ffc:      	add	x8, x20, #0x8
    9000:      	sub	x9, x9, #0x1
    9004:      	mov	w11, #0x18              // =24
    9008:      	mov	w10, wzr
    900c:      	madd	x11, x9, x11, x8
    9010:      	ldr	x11, [x11]
    9014:      	cbz	x11, 0x9040 <.text+0x3a54>
    9018:      	tbz	w10, #0x0, 0x902c <.text+0x3a40>
    901c:      	ldrb	w10, [x11, #0x8]
    9020:      	cbnz	w10, 0x9050 <.text+0x3a64>
    9024:      	mov	w10, #0x1               // =1
    9028:      	b	0x9038 <.text+0x3a4c>
    902c:      	ldr	x10, [x11]
    9030:      	cmp	x10, x19
    9034:      	cset	w10, eq
    9038:      	add	x11, x11, #0x10
    903c:      	b	0x9010 <.text+0x3a24>
    9040:      	mov	w10, #0x18              // =24
    9044:      	madd	x8, x9, x10, x8
    9048:      	ldr	x0, [x8, #0x8]
    904c:      	b	0x9054 <.text+0x3a68>
    9050:      	ldr	x0, [x11]
    9054:      	ldp	x20, x19, [sp, #0x10]
    9058:      	ldp	x29, x30, [sp], #0x20
    905c:      	ret
    9060:      	stp	x29, x30, [sp, #-0x20]!
    9064:      	str	x19, [sp, #0x10]
    9068:      	mov	x29, sp
    906c:      	adrp	x8, 0x15000
    9070:      	ldr	w0, [x8, #0xf58]
    9074:      	bl	0xa188 <JNI_OnLoad+0x102c>
    9078:      	ldr	x8, [x0]
    907c:      	mov	x19, x0
    9080:      	cbnz	x8, 0x908c <.text+0x3aa0>
    9084:      	bl	0xa1c0 <JNI_OnLoad+0x1064>
    9088:      	ldr	x8, [x19]
    908c:      	mov	w9, #0x18               // =24
    9090:      	mul	x8, x8, x9
    9094:      	ldr	x0, [x8, x19]
    9098:      	ldr	x19, [sp, #0x10]
    909c:      	ldp	x29, x30, [sp], #0x20
    90a0:      	ret
    90a4:      	stp	x0, x1, [sp, #-0xd0]!
    90a8:      	stp	x2, x3, [sp, #0x10]
    90ac:      	stp	x4, x5, [sp, #0x20]
    90b0:      	stp	x6, x7, [sp, #0x30]
    90b4:      	stp	x8, x30, [sp, #0x40]
    90b8:      	stp	q0, q1, [sp, #0x50]
    90bc:      	stp	q2, q3, [sp, #0x70]
    90c0:      	stp	q4, q5, [sp, #0x90]
    90c4:      	stp	q6, q7, [sp, #0xb0]
    90c8:      	ldr	x0, 0x910c <.text+0x3b20>
    90cc:      	mov	x1, x30
    90d0:      	ldr	x16, 0x9104 <.text+0x3b18>
    90d4:      	blr	x16
    90d8:      	mov	x16, x0
    90dc:      	ldp	q6, q7, [sp, #0xb0]
    90e0:      	ldp	q4, q5, [sp, #0x90]
    90e4:      	ldp	q2, q3, [sp, #0x70]
    90e8:      	ldp	q0, q1, [sp, #0x50]
    90ec:      	ldp	x8, x30, [sp, #0x40]
    90f0:      	ldp	x6, x7, [sp, #0x30]
    90f4:      	ldp	x4, x5, [sp, #0x20]
    90f8:      	ldp	x2, x3, [sp, #0x10]
    90fc:      	ldp	x0, x1, [sp], #0xd0
    9100:      	br	x16
		...
    9114:      	mov	w8, #0x2                // =2
    9118:      	add	x1, sp, #0x8
    911c:      	mov	w2, w8
    9120:      	mov	w0, w22
    9124:      	b	0xceb4 <bytehook_del_dlopen_callback+0x38c>
    9128:      	adrp	x8, 0x15000
    912c:      	ldr	w8, [x8, #0xf58]
    9130:      	mov	x19, x0
    9134:      	mov	w0, w8
    9138:      	b	0xa188 <JNI_OnLoad+0x102c>
    913c:      	adrp	x0, 0x15000
    9140:      	add	x0, x0, #0xfa0
    9144:      	b	0xb860 <JNI_OnLoad+0x2704>
    9148:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    914c:      	ldr	x8, [x8, #0xaa8]
    9150:      	ldr	w8, [x8]
    9154:      	cmp	w8, #0x4
    9158:      	ret

000000000000915c <JNI_OnLoad>:
    915c:      	sub	sp, sp, #0x130
    9160:      	stp	x29, x30, [sp, #0x100]
    9164:      	stp	x28, x21, [sp, #0x110]
    9168:      	stp	x20, x19, [sp, #0x120]
    916c:      	add	x29, sp, #0x100
    9170:      	mrs	x20, TPIDR_EL0
    9174:      	ldr	x8, [x20, #0x28]
    9178:      	stur	x8, [x29, #-0x8]
    917c:      	cbz	x0, 0x9228 <JNI_OnLoad+0xcc>
    9180:      	ldr	x8, [x0]
    9184:      	mov	w2, #0x6                // =6
    9188:      	mov	w21, #0x6               // =6
    918c:      	mov	x1, sp
    9190:      	ldr	x8, [x8, #0x30]
    9194:      	movk	w2, #0x1, lsl #16
    9198:      	movk	w21, #0x1, lsl #16
    919c:      	blr	x8
    91a0:      	cbnz	w0, 0x9228 <JNI_OnLoad+0xcc>
    91a4:      	ldr	x0, [sp]
    91a8:      	cbz	x0, 0x9228 <JNI_OnLoad+0xcc>
    91ac:      	ldr	x8, [x0]
    91b0:      	cbz	x8, 0x9228 <JNI_OnLoad+0xcc>
    91b4:      	ldr	x8, [x8, #0x30]
    91b8:      	adrp	x1, 0x2000
    91bc:      	add	x1, x1, #0x985
    91c0:      	blr	x8
    91c4:      	cbz	x0, 0x9228 <JNI_OnLoad+0xcc>
    91c8:      	adrp	x1, 0x11000 <siglongjmp@plt+0x3870>
    91cc:      	mov	x19, x0
    91d0:      	add	x1, x1, #0x7a8
    91d4:      	add	x0, sp, #0x8
    91d8:      	mov	w2, #0xf0               // =240
    91dc:      	bl	0xd510 <memcpy@plt>
    91e0:      	ldr	x0, [sp]
    91e4:      	add	x2, sp, #0x8
    91e8:      	mov	w3, #0xa                // =10
    91ec:      	mov	x1, x19
    91f0:      	ldr	x8, [x0]
    91f4:      	ldr	x8, [x8, #0x6b8]
    91f8:      	blr	x8
    91fc:      	cmp	w0, #0x0
    9200:      	csinv	w0, w21, wzr, eq
    9204:      	ldr	x8, [x20, #0x28]
    9208:      	ldur	x9, [x29, #-0x8]
    920c:      	cmp	x8, x9
    9210:      	b.ne	0x9230 <JNI_OnLoad+0xd4>
    9214:      	ldp	x20, x19, [sp, #0x120]
    9218:      	ldp	x28, x21, [sp, #0x110]
    921c:      	ldp	x29, x30, [sp, #0x100]
    9220:      	add	sp, sp, #0x130
    9224:      	ret
    9228:      	mov	w0, #-0x1               // =-1
    922c:      	b	0x9204 <JNI_OnLoad+0xa8>
    9230:      	bl	0xd2e0 <__stack_chk_fail@plt>
    9234:      	stp	x29, x30, [sp, #-0x20]!
    9238:      	str	x19, [sp, #0x10]
    923c:      	mov	x29, sp
    9240:      	ldr	x8, [x0]
    9244:      	mov	x19, x0
    9248:      	ldr	x0, [x8, #0x538]
    924c:      	str	x0, [x29, #0x18]
    9250:      	bl	0xd520 <bytehook_get_version@plt>
    9254:      	mov	x1, x0
    9258:      	mov	x0, x19
    925c:      	ldr	x2, [x29, #0x18]
    9260:      	ldr	x19, [sp, #0x10]
    9264:      	ldp	x29, x30, [sp], #0x20
    9268:      	br	x2
    926c:      	tst	w3, #0xff
    9270:      	cset	w1, ne
    9274:      	mov	w0, w2
    9278:      	b	0xd530 <bytehook_init@plt>
    927c:      	stp	x29, x30, [sp, #-0x30]!
    9280:      	stp	x22, x21, [sp, #0x10]
    9284:      	stp	x20, x19, [sp, #0x20]
    9288:      	mov	x29, sp
    928c:      	cbz	x2, 0x92dc <JNI_OnLoad+0x180>
    9290:      	ldr	x8, [x0]
    9294:      	mov	x19, x2
    9298:      	mov	x1, x2
    929c:      	mov	x2, xzr
    92a0:      	ldr	x8, [x8, #0x548]
    92a4:      	mov	x20, x0
    92a8:      	blr	x8
    92ac:      	cbz	x0, 0x92dc <JNI_OnLoad+0x180>
    92b0:      	mov	x21, x0
    92b4:      	bl	0xd540 <bytehook_add_ignore@plt>
    92b8:      	ldr	x8, [x20]
    92bc:      	mov	w22, w0
    92c0:      	mov	x0, x20
    92c4:      	mov	x1, x19
    92c8:      	ldr	x8, [x8, #0x550]
    92cc:      	mov	x2, x21
    92d0:      	blr	x8
    92d4:      	mov	w0, w22
    92d8:      	b	0x92e0 <JNI_OnLoad+0x184>
    92dc:      	mov	w0, #0x19               // =25
    92e0:      	ldp	x20, x19, [sp, #0x20]
    92e4:      	ldp	x22, x21, [sp, #0x10]
    92e8:      	ldp	x29, x30, [sp], #0x30
    92ec:      	ret
    92f0:      	stp	x29, x30, [sp, #-0x10]!
    92f4:      	mov	x29, sp
    92f8:      	bl	0xd3d0 <bytehook_get_mode@plt>
    92fc:      	cmp	w0, #0x0
    9300:      	cset	w0, ne
    9304:      	ldp	x29, x30, [sp], #0x10
    9308:      	ret
    930c:      	stp	x29, x30, [sp, #-0x10]!
    9310:      	mov	x29, sp
    9314:      	bl	0xd550 <bytehook_get_debug@plt>
    9318:      	and	w0, w0, #0x1
    931c:      	ldp	x29, x30, [sp], #0x10
    9320:      	ret
    9324:      	tst	w2, #0xff
    9328:      	cset	w0, ne
    932c:      	b	0xd560 <bytehook_set_debug@plt>
    9330:      	stp	x29, x30, [sp, #-0x10]!
    9334:      	mov	x29, sp
    9338:      	bl	0xd570 <bytehook_get_recordable@plt>
    933c:      	and	w0, w0, #0x1
    9340:      	ldp	x29, x30, [sp], #0x10
    9344:      	ret
    9348:      	tst	w2, #0xff
    934c:      	cset	w0, ne
    9350:      	b	0xd580 <bytehook_set_recordable@plt>
    9354:      	stp	x29, x30, [sp, #-0x20]!
    9358:      	stp	x20, x19, [sp, #0x10]
    935c:      	mov	x29, sp
    9360:      	mov	x20, x0
    9364:      	mov	w0, w2
    9368:      	bl	0xd590 <bytehook_get_records@plt>
    936c:      	cbz	x0, 0x9398 <JNI_OnLoad+0x23c>
    9370:      	ldr	x8, [x20]
    9374:      	mov	x19, x0
    9378:      	mov	x0, x20
    937c:      	mov	x1, x19
    9380:      	ldr	x8, [x8, #0x538]
    9384:      	blr	x8
    9388:      	mov	x20, x0
    938c:      	mov	x0, x19
    9390:      	bl	0xd260 <free@plt>
    9394:      	mov	x0, x20
    9398:      	ldp	x20, x19, [sp, #0x10]
    939c:      	ldp	x29, x30, [sp], #0x20
    93a0:      	ret
    93a4:      	ldr	x8, [x0]
    93a8:      	adrp	x1, 0x2000
    93ac:      	add	x1, x1, #0xac4
    93b0:      	ldr	x2, [x8, #0x538]
    93b4:      	br	x2
    93b8:      	stp	x29, x30, [sp, #-0x40]!
    93bc:      	str	x23, [sp, #0x10]
    93c0:      	stp	x22, x21, [sp, #0x20]
    93c4:      	stp	x20, x19, [sp, #0x30]
    93c8:      	mov	x29, sp
    93cc:      	bl	0xba68 <JNI_OnLoad+0x290c>
    93d0:      	mov	w20, w0
    93d4:      	bl	0x58d0 <.text+0x2e4>
    93d8:      	adrp	x21, 0x11000 <siglongjmp@plt+0x3870>
    93dc:      	adrp	x22, 0x11000 <siglongjmp@plt+0x3870>
    93e0:      	ldr	x21, [x21, #0xab8]
    93e4:      	ldr	x22, [x22, #0xad0]
    93e8:      	adrp	x23, 0x16000
    93ec:      	cbz	x0, 0x94a0 <JNI_OnLoad+0x344>
    93f0:      	mov	x19, x0
    93f4:      	cmp	w20, #0x19
    93f8:      	b.hi	0x9424 <JNI_OnLoad+0x2c8>
    93fc:      	mov	w8, #0x1                // =1
    9400:      	lsl	w8, w8, w20
    9404:      	mov	w9, #0x3600000          // =56623104
    9408:      	tst	w8, w9
    940c:      	b.eq	0x9424 <JNI_OnLoad+0x2c8>
    9410:      	adrp	x1, 0x2000
    9414:      	add	x1, x1, #0x90d
    9418:      	bl	0x9554 <JNI_OnLoad+0x3f8>
    941c:      	str	x0, [x23, #0x8]
    9420:      	cbz	x0, 0x9498 <JNI_OnLoad+0x33c>
    9424:      	and	w8, w20, #0xfffffffe
    9428:      	cmp	w8, #0x18
    942c:      	b.ne	0x9488 <JNI_OnLoad+0x32c>
    9430:      	adrp	x1, 0x2000
    9434:      	add	x1, x1, #0x3f9
    9438:      	bl	0x9554 <JNI_OnLoad+0x3f8>
    943c:      	str	x0, [x22]
    9440:      	cbnz	x0, 0x9488 <JNI_OnLoad+0x32c>
    9444:      	adrp	x1, 0x2000
    9448:      	add	x1, x1, #0xc39
    944c:      	bl	0x9554 <JNI_OnLoad+0x3f8>
    9450:      	str	x0, [x21]
    9454:      	cbz	x0, 0x9498 <JNI_OnLoad+0x33c>
    9458:      	adrp	x1, 0x2000
    945c:      	add	x1, x1, #0x460
    9460:      	bl	0x9554 <JNI_OnLoad+0x3f8>
    9464:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    9468:      	ldr	x8, [x8, #0xac8]
    946c:      	adrp	x1, 0x2000
    9470:      	add	x1, x1, #0x64f
    9474:      	str	x0, [x8]
    9478:      	bl	0x9554 <JNI_OnLoad+0x3f8>
    947c:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    9480:      	ldr	x8, [x8, #0xac0]
    9484:      	str	x0, [x8]
    9488:      	mov	x0, x19
    948c:      	bl	0x5b58 <.text+0x56c>
    9490:      	mov	w0, wzr
    9494:      	b	0x94c8 <JNI_OnLoad+0x36c>
    9498:      	mov	x0, x19
    949c:      	bl	0x5b58 <.text+0x56c>
    94a0:      	str	xzr, [x21]
    94a4:      	str	xzr, [x22]
    94a8:      	str	xzr, [x23, #0x8]
    94ac:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    94b0:      	adrp	x9, 0x11000 <siglongjmp@plt+0x3870>
    94b4:      	ldr	x8, [x8, #0xac8]
    94b8:      	ldr	x9, [x9, #0xac0]
    94bc:      	mov	w0, #-0x1               // =-1
    94c0:      	str	xzr, [x8]
    94c4:      	str	xzr, [x9]
    94c8:      	ldp	x20, x19, [sp, #0x30]
    94cc:      	ldp	x22, x21, [sp, #0x20]
    94d0:      	ldr	x23, [sp, #0x10]
    94d4:      	ldp	x29, x30, [sp], #0x40
    94d8:      	ret
    94dc:      	mov	w0, #0x1                // =1
    94e0:      	ret
    94e4:      	adrp	x8, 0x16000
    94e8:      	ldr	x0, [x8, #0x8]
    94ec:      	cbz	x0, 0x94f4 <JNI_OnLoad+0x398>
    94f0:      	b	0xd3b0 <pthread_mutex_lock@plt>
    94f4:      	ret
    94f8:      	adrp	x8, 0x16000
    94fc:      	ldr	x0, [x8, #0x8]
    9500:      	cbz	x0, 0x9508 <JNI_OnLoad+0x3ac>
    9504:      	b	0xd3e0 <pthread_mutex_unlock@plt>
    9508:      	ret
    950c:      	mov	w0, wzr
    9510:      	ret
    9514:      	stp	x29, x30, [sp, #-0x10]!
    9518:      	mov	x29, sp
    951c:      	ldrb	w8, [x1]
    9520:      	cmp	w8, #0x2f
    9524:      	mov	x8, x0
    9528:      	b.eq	0x9538 <JNI_OnLoad+0x3dc>
    952c:      	mov	x0, x8
    9530:      	ldp	x29, x30, [sp], #0x10
    9534:      	b	0xba0c <JNI_OnLoad+0x28b0>
    9538:      	mov	x0, x1
    953c:      	mov	x1, x8
    9540:      	bl	0xd340 <strcmp@plt>
    9544:      	cmp	w0, #0x0
    9548:      	cset	w0, eq
    954c:      	ldp	x29, x30, [sp], #0x10
    9550:      	ret
    9554:      	mov	x0, x19
    9558:      	b	0x5b88 <.text+0x59c>
    955c:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    9560:      	ldr	x8, [x8, #0xaa8]
    9564:      	ldr	w8, [x8]
    9568:      	cmp	w8, #0x5
    956c:      	cset	w0, lo
    9570:      	ret
    9574:      	tst	w0, #0x1
    9578:      	mov	w8, #0x8                // =8
    957c:      	mov	w9, #0x4                // =4
    9580:      	csel	w8, w9, w8, ne
    9584:      	adrp	x9, 0x11000 <siglongjmp@plt+0x3870>
    9588:      	ldr	x9, [x9, #0xaa8]
    958c:      	str	w8, [x9]
    9590:      	ret
    9594:      	adrp	x8, 0x16000
    9598:      	ldrb	w0, [x8, #0x10]
    959c:      	ret
    95a0:      	and	w8, w0, #0x1
    95a4:      	adrp	x9, 0x16000
    95a8:      	strb	w8, [x9, #0x10]
    95ac:      	ret
    95b0:      	stp	x29, x30, [sp, #-0x60]!
    95b4:      	bl	0xa07c <JNI_OnLoad+0xf20>
    95b8:      	sub	sp, sp, #0x240
    95bc:      	mrs	x27, TPIDR_EL0
    95c0:      	ldr	x8, [x27, #0x28]
    95c4:      	stur	x8, [x29, #-0x10]
    95c8:      	adrp	x8, 0x16000
    95cc:      	ldrb	w8, [x8, #0x10]
    95d0:      	cbz	w8, 0x972c <JNI_OnLoad+0x5d0>
    95d4:      	adrp	x28, 0x16000
    95d8:      	ldrb	w8, [x28, #0x11]
    95dc:      	tbz	w8, #0x0, 0x95e8 <JNI_OnLoad+0x48c>
    95e0:      	mov	w0, #-0x1               // =-1
    95e4:      	b	0x9730 <JNI_OnLoad+0x5d4>
    95e8:      	mov	x24, x5
    95ec:      	mov	x20, x4
    95f0:      	mov	x19, x3
    95f4:      	mov	x22, x2
    95f8:      	mov	x23, x1
    95fc:      	mov	w21, w0
    9600:      	cbz	x1, 0x9624 <JNI_OnLoad+0x4c8>
    9604:      	mov	w1, #0x2f               // =47
    9608:      	mov	x0, x23
    960c:      	bl	0xd5a0 <strrchr@plt>
    9610:      	cbz	x0, 0x962c <JNI_OnLoad+0x4d0>
    9614:      	ldrb	w8, [x0, #0x1]!
    9618:      	cbz	w8, 0x962c <JNI_OnLoad+0x4d0>
    961c:      	mov	x23, x0
    9620:      	b	0x962c <JNI_OnLoad+0x4d0>
    9624:      	adrp	x23, 0x2000
    9628:      	add	x23, x23, #0x795
    962c:      	mov	x0, x23
    9630:      	bl	0xd5b0 <strlen@plt>
    9634:      	mov	x25, x0
    9638:      	mov	w0, #-0x1               // =-1
    963c:      	cbz	x22, 0x9730 <JNI_OnLoad+0x5d4>
    9640:      	sub	x8, x25, #0x1
    9644:      	cmp	x8, #0x1ff
    9648:      	b.hi	0x9730 <JNI_OnLoad+0x5d4>
    964c:      	mov	x0, x22
    9650:      	bl	0xd5b0 <strlen@plt>
    9654:      	sub	x8, x0, #0x1
    9658:      	cmp	x8, #0x3ff
    965c:      	b.hi	0x95e0 <JNI_OnLoad+0x484>
    9660:      	mov	x26, x0
    9664:      	add	x1, sp, #0x30
    9668:      	mov	x0, x24
    966c:      	bl	0x9754 <JNI_OnLoad+0x5f8>
    9670:      	add	x0, sp, #0x30
    9674:      	mov	w1, #0x200              // =512
    9678:      	bl	0xd5c0 <__strlen_chk@plt>
    967c:      	mov	x24, x0
    9680:      	add	x2, sp, #0x2c
    9684:      	mov	x0, x23
    9688:      	mov	x1, x25
    968c:      	bl	0x97e8 <JNI_OnLoad+0x68c>
    9690:      	cbnz	w0, 0x9720 <JNI_OnLoad+0x5c4>
    9694:      	add	x2, sp, #0x28
    9698:      	mov	x0, x22
    969c:      	mov	x1, x26
    96a0:      	bl	0x97e8 <JNI_OnLoad+0x68c>
    96a4:      	cbnz	w0, 0x9720 <JNI_OnLoad+0x5c4>
    96a8:      	add	x0, sp, #0x30
    96ac:      	add	x2, sp, #0x24
    96b0:      	mov	x1, x24
    96b4:      	bl	0x97e8 <JNI_OnLoad+0x68c>
    96b8:      	cbnz	w0, 0x9720 <JNI_OnLoad+0x5c4>
    96bc:      	ubfiz	w21, w21, #8, #8
    96c0:      	str	x21, [sp]
    96c4:      	bl	0x9914 <JNI_OnLoad+0x7b8>
    96c8:      	ldrh	w8, [sp, #0x24]
    96cc:      	ldrh	w9, [sp, #0x2c]
    96d0:      	ldrh	w10, [sp, #0x28]
    96d4:      	stur	x19, [sp, #0x16]
    96d8:      	adrp	x19, 0x16000
    96dc:      	bfi	x21, x0, #16, #48
    96e0:      	add	x19, x19, #0x20
    96e4:      	stp	x21, x20, [sp]
    96e8:      	add	x20, x19, #0x18
    96ec:      	mov	x0, x20
    96f0:      	strh	w8, [sp, #0x10]
    96f4:      	strh	w9, [sp, #0x12]
    96f8:      	strh	w10, [sp, #0x14]
    96fc:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    9700:      	mov	x3, sp
    9704:      	mov	w1, #0x8000             // =32768
    9708:      	mov	w2, #0x60000            // =393216
    970c:      	mov	w4, #0x1e               // =30
    9710:      	mov	x0, x19
    9714:      	bl	0xa040 <JNI_OnLoad+0xee4>
    9718:      	bl	0xa0c4 <JNI_OnLoad+0xf68>
    971c:      	cbz	w19, 0x972c <JNI_OnLoad+0x5d0>
    9720:      	mov	w8, #0x1                // =1
    9724:      	strb	w8, [x28, #0x11]
    9728:      	b	0x95e0 <JNI_OnLoad+0x484>
    972c:      	mov	w0, wzr
    9730:      	ldr	x8, [x27, #0x28]
    9734:      	ldur	x9, [x29, #-0x10]
    9738:      	cmp	x8, x9
    973c:      	b.ne	0x9750 <JNI_OnLoad+0x5f4>
    9740:      	add	sp, sp, #0x240
    9744:      	bl	0xa098 <JNI_OnLoad+0xf3c>
    9748:      	ldp	x29, x30, [sp], #0x60
    974c:      	ret
    9750:      	bl	0xd2e0 <__stack_chk_fail@plt>
    9754:      	sub	sp, sp, #0x50
    9758:      	stp	x29, x30, [sp, #0x30]
    975c:      	stp	x20, x19, [sp, #0x40]
    9760:      	add	x29, sp, #0x30
    9764:      	mrs	x20, TPIDR_EL0
    9768:      	ldr	x8, [x20, #0x28]
    976c:      	mov	x19, x1
    9770:      	add	x1, sp, #0x8
    9774:      	stur	x8, [x29, #-0x8]
    9778:      	bl	0xd5d0 <dladdr@plt>
    977c:      	cbz	w0, 0x97b0 <JNI_OnLoad+0x654>
    9780:      	ldr	x0, [sp, #0x8]
    9784:      	cbz	x0, 0x97b0 <JNI_OnLoad+0x654>
    9788:      	ldrb	w8, [x0]
    978c:      	cbz	w8, 0x97b0 <JNI_OnLoad+0x654>
    9790:      	mov	w1, #0x2f               // =47
    9794:      	bl	0xd5a0 <strrchr@plt>
    9798:      	cbz	x0, 0x97a8 <JNI_OnLoad+0x64c>
    979c:      	mov	x1, x0
    97a0:      	ldrb	w8, [x1, #0x1]!
    97a4:      	cbnz	w8, 0x97b8 <JNI_OnLoad+0x65c>
    97a8:      	ldr	x1, [sp, #0x8]
    97ac:      	b	0x97b8 <JNI_OnLoad+0x65c>
    97b0:      	adrp	x1, 0x2000
    97b4:      	add	x1, x1, #0x795
    97b8:      	mov	w2, #0x200              // =512
    97bc:      	mov	x0, x19
    97c0:      	bl	0xd5e0 <strlcpy@plt>
    97c4:      	ldr	x8, [x20, #0x28]
    97c8:      	ldur	x9, [x29, #-0x8]
    97cc:      	cmp	x8, x9
    97d0:      	b.ne	0x97e4 <JNI_OnLoad+0x688>
    97d4:      	ldp	x20, x19, [sp, #0x40]
    97d8:      	ldp	x29, x30, [sp, #0x30]
    97dc:      	add	sp, sp, #0x50
    97e0:      	ret
    97e4:      	bl	0xd2e0 <__stack_chk_fail@plt>
    97e8:      	sub	sp, sp, #0x70
    97ec:      	stp	x29, x30, [sp, #0x10]
    97f0:      	str	x27, [sp, #0x20]
    97f4:      	stp	x26, x25, [sp, #0x30]
    97f8:      	stp	x24, x23, [sp, #0x40]
    97fc:      	stp	x22, x21, [sp, #0x50]
    9800:      	stp	x20, x19, [sp, #0x60]
    9804:      	add	x29, sp, #0x10
    9808:      	mrs	x22, TPIDR_EL0
    980c:      	ldr	x8, [x22, #0x28]
    9810:      	adrp	x23, 0x16000
    9814:      	add	x23, x23, #0x60
    9818:      	mov	x20, x0
    981c:      	add	x0, x23, #0x18
    9820:      	mov	x19, x2
    9824:      	mov	x21, x1
    9828:      	str	x8, [sp, #0x8]
    982c:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    9830:      	ldr	x24, [x23, #0x10]
    9834:      	ldr	x25, [x23]
    9838:      	mov	x26, xzr
    983c:      	mov	w23, wzr
    9840:      	cmp	x26, x24
    9844:      	b.hs	0x988c <JNI_OnLoad+0x730>
    9848:      	add	x8, x26, x25
    984c:      	ldrh	w27, [x8]
    9850:      	cmp	x27, x21
    9854:      	b.ne	0x986c <JNI_OnLoad+0x710>
    9858:      	add	x0, x8, #0x2
    985c:      	mov	x1, x20
    9860:      	mov	x2, x21
    9864:      	bl	0xd5f0 <memcmp@plt>
    9868:      	cbz	w0, 0x98c8 <JNI_OnLoad+0x76c>
    986c:      	add	w23, w23, #0x1
    9870:      	add	x8, x26, x27
    9874:      	mvn	w9, w23
    9878:      	tst	w9, #0xffff
    987c:      	add	x26, x8, #0x3
    9880:      	b.ne	0x9840 <JNI_OnLoad+0x6e4>
    9884:      	mov	w20, #-0x1              // =-1
    9888:      	b	0x98d0 <JNI_OnLoad+0x774>
    988c:      	adrp	x0, 0x16000
    9890:      	add	x6, x21, #0x1
    9894:      	add	x0, x0, #0x60
    9898:      	mov	x3, sp
    989c:      	mov	w1, #0x4000             // =16384
    98a0:      	mov	w2, #0x20000            // =131072
    98a4:      	mov	w4, #0x2                // =2
    98a8:      	mov	x5, x20
    98ac:      	strh	w21, [sp]
    98b0:      	bl	0x9984 <JNI_OnLoad+0x828>
    98b4:      	cbnz	w0, 0x98bc <JNI_OnLoad+0x760>
    98b8:      	strh	w23, [x19]
    98bc:      	cmp	w0, #0x0
    98c0:      	csetm	w20, ne
    98c4:      	b	0x98d0 <JNI_OnLoad+0x774>
    98c8:      	mov	w20, wzr
    98cc:      	strh	w23, [x19]
    98d0:      	adrp	x0, 0x16000
    98d4:      	add	x0, x0, #0x78
    98d8:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    98dc:      	ldr	x8, [x22, #0x28]
    98e0:      	ldr	x9, [sp, #0x8]
    98e4:      	cmp	x8, x9
    98e8:      	b.ne	0x9910 <JNI_OnLoad+0x7b4>
    98ec:      	mov	w0, w20
    98f0:      	ldp	x20, x19, [sp, #0x60]
    98f4:      	ldp	x22, x21, [sp, #0x50]
    98f8:      	ldp	x24, x23, [sp, #0x40]
    98fc:      	ldp	x26, x25, [sp, #0x30]
    9900:      	ldr	x27, [sp, #0x20]
    9904:      	ldp	x29, x30, [sp, #0x10]
    9908:      	add	sp, sp, #0x70
    990c:      	ret
    9910:      	bl	0xd2e0 <__stack_chk_fail@plt>
    9914:      	sub	sp, sp, #0x40
    9918:      	stp	x29, x30, [sp, #0x20]
    991c:      	str	x19, [sp, #0x30]
    9920:      	add	x29, sp, #0x20
    9924:      	mrs	x19, TPIDR_EL0
    9928:      	ldr	x8, [x19, #0x28]
    992c:      	add	x0, sp, #0x8
    9930:      	mov	x1, xzr
    9934:      	stur	x8, [x29, #-0x8]
    9938:      	bl	0xd4f0 <gettimeofday@plt>
    993c:      	adrp	x8, 0x16000
    9940:      	ldrb	w9, [x8, #0x18]
    9944:      	tbnz	w9, #0x0, 0x9950 <JNI_OnLoad+0x7f4>
    9948:      	mov	w9, #0x1                // =1
    994c:      	strb	w9, [x8, #0x18]
    9950:      	ldp	x8, x9, [sp, #0x8]
    9954:      	ldr	x10, [x19, #0x28]
    9958:      	ldur	x11, [x29, #-0x8]
    995c:      	cmp	x10, x11
    9960:      	b.ne	0x9980 <JNI_OnLoad+0x824>
    9964:      	ldr	x19, [sp, #0x30]
    9968:      	ldp	x29, x30, [sp, #0x20]
    996c:      	mov	w10, #0x3e8             // =1000
    9970:      	udiv	x9, x9, x10
    9974:      	madd	x0, x8, x10, x9
    9978:      	add	sp, sp, #0x40
    997c:      	ret
    9980:      	bl	0xd2e0 <__stack_chk_fail@plt>
    9984:      	stp	x29, x30, [sp, #-0x50]!
    9988:      	str	x25, [sp, #0x10]
    998c:      	stp	x24, x23, [sp, #0x20]
    9990:      	stp	x22, x21, [sp, #0x30]
    9994:      	stp	x20, x19, [sp, #0x40]
    9998:      	mov	x29, sp
    999c:      	cmp	x5, #0x0
    99a0:      	csel	x8, xzr, x6, eq
    99a4:      	add	x25, x8, x4
    99a8:      	cmp	x25, x1
    99ac:      	b.ls	0x99b8 <JNI_OnLoad+0x85c>
    99b0:      	mov	w0, #-0x1               // =-1
    99b4:      	b	0x9a48 <JNI_OnLoad+0x8ec>
    99b8:      	ldp	x9, x8, [x0, #0x8]
    99bc:      	mov	x19, x6
    99c0:      	mov	x20, x5
    99c4:      	mov	x22, x4
    99c8:      	sub	x10, x9, x8
    99cc:      	mov	x23, x3
    99d0:      	mov	x21, x0
    99d4:      	cmp	x10, x25
    99d8:      	b.hs	0x9a04 <JNI_OnLoad+0x8a8>
    99dc:      	add	x24, x9, x1
    99e0:      	cmp	x24, x2
    99e4:      	b.hi	0x99b0 <JNI_OnLoad+0x854>
    99e8:      	ldr	x0, [x21]
    99ec:      	mov	x1, x24
    99f0:      	bl	0xd250 <realloc@plt>
    99f4:      	cbz	x0, 0x99b0 <JNI_OnLoad+0x854>
    99f8:      	ldr	x8, [x21, #0x10]
    99fc:      	stp	x0, x24, [x21]
    9a00:      	b	0x9a08 <JNI_OnLoad+0x8ac>
    9a04:      	ldr	x0, [x21]
    9a08:      	add	x0, x8, x0
    9a0c:      	mov	x1, x23
    9a10:      	mov	x2, x22
    9a14:      	bl	0xd510 <memcpy@plt>
    9a18:      	cbz	x20, 0x9a38 <JNI_OnLoad+0x8dc>
    9a1c:      	ldr	x8, [x21]
    9a20:      	ldr	x9, [x21, #0x10]
    9a24:      	mov	x1, x20
    9a28:      	mov	x2, x19
    9a2c:      	add	x8, x8, x22
    9a30:      	add	x0, x8, x9
    9a34:      	bl	0xd510 <memcpy@plt>
    9a38:      	ldr	x8, [x21, #0x10]
    9a3c:      	mov	w0, wzr
    9a40:      	add	x8, x8, x25
    9a44:      	str	x8, [x21, #0x10]
    9a48:      	ldp	x20, x19, [sp, #0x40]
    9a4c:      	ldp	x22, x21, [sp, #0x30]
    9a50:      	ldp	x24, x23, [sp, #0x20]
    9a54:      	ldr	x25, [sp, #0x10]
    9a58:      	ldp	x29, x30, [sp], #0x50
    9a5c:      	ret
    9a60:      	stp	x29, x30, [sp, #-0x40]!
    9a64:      	stp	x28, x23, [sp, #0x10]
    9a68:      	stp	x22, x21, [sp, #0x20]
    9a6c:      	stp	x20, x19, [sp, #0x30]
    9a70:      	mov	x29, sp
    9a74:      	sub	sp, sp, #0x220
    9a78:      	mrs	x21, TPIDR_EL0
    9a7c:      	ldr	x8, [x21, #0x28]
    9a80:      	stur	x8, [x29, #-0x8]
    9a84:      	adrp	x8, 0x16000
    9a88:      	ldrb	w8, [x8, #0x10]
    9a8c:      	cbz	w8, 0x9b34 <JNI_OnLoad+0x9d8>
    9a90:      	adrp	x22, 0x16000
    9a94:      	ldrb	w8, [x22, #0x11]
    9a98:      	tbnz	w8, #0x0, 0x9b2c <JNI_OnLoad+0x9d0>
    9a9c:      	mov	x19, x1
    9aa0:      	mov	w20, w0
    9aa4:      	add	x1, sp, #0x18
    9aa8:      	mov	x0, x2
    9aac:      	bl	0x9754 <JNI_OnLoad+0x5f8>
    9ab0:      	add	x0, sp, #0x18
    9ab4:      	mov	w1, #0x200              // =512
    9ab8:      	bl	0xd5c0 <__strlen_chk@plt>
    9abc:      	mov	x1, x0
    9ac0:      	add	x0, sp, #0x18
    9ac4:      	add	x2, sp, #0x14
    9ac8:      	bl	0x97e8 <JNI_OnLoad+0x68c>
    9acc:      	cbnz	w0, 0x9b24 <JNI_OnLoad+0x9c8>
    9ad0:      	mov	w23, #0x1               // =1
    9ad4:      	bfi	w23, w20, #8, #8
    9ad8:      	str	x23, [sp]
    9adc:      	bl	0x9914 <JNI_OnLoad+0x7b8>
    9ae0:      	bfi	x23, x0, #16, #48
    9ae4:      	ldrh	w8, [sp, #0x14]
    9ae8:      	stp	x23, x19, [sp]
    9aec:      	adrp	x19, 0x16000
    9af0:      	add	x19, x19, #0x20
    9af4:      	add	x20, x19, #0x18
    9af8:      	mov	x0, x20
    9afc:      	strh	w8, [sp, #0x10]
    9b00:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    9b04:      	mov	x3, sp
    9b08:      	mov	w1, #0x8000             // =32768
    9b0c:      	mov	w2, #0x60000            // =393216
    9b10:      	mov	w4, #0x12               // =18
    9b14:      	mov	x0, x19
    9b18:      	bl	0xa040 <JNI_OnLoad+0xee4>
    9b1c:      	bl	0xa0c4 <JNI_OnLoad+0xf68>
    9b20:      	cbz	w19, 0x9b34 <JNI_OnLoad+0x9d8>
    9b24:      	mov	w8, #0x1                // =1
    9b28:      	strb	w8, [x22, #0x11]
    9b2c:      	mov	w0, #-0x1               // =-1
    9b30:      	b	0x9b38 <JNI_OnLoad+0x9dc>
    9b34:      	mov	w0, wzr
    9b38:      	ldr	x8, [x21, #0x28]
    9b3c:      	ldur	x9, [x29, #-0x8]
    9b40:      	cmp	x8, x9
    9b44:      	b.ne	0x9b60 <JNI_OnLoad+0xa04>
    9b48:      	add	sp, sp, #0x220
    9b4c:      	ldp	x20, x19, [sp, #0x30]
    9b50:      	ldp	x22, x21, [sp, #0x20]
    9b54:      	ldp	x28, x23, [sp, #0x10]
    9b58:      	ldp	x29, x30, [sp], #0x40
    9b5c:      	ret
    9b60:      	bl	0xd2e0 <__stack_chk_fail@plt>
    9b64:      	sub	sp, sp, #0x30
    9b68:      	stp	x29, x30, [sp, #0x10]
    9b6c:      	str	x19, [sp, #0x20]
    9b70:      	add	x29, sp, #0x10
    9b74:      	mrs	x19, TPIDR_EL0
    9b78:      	ldr	x8, [x19, #0x28]
    9b7c:      	mov	w2, w0
    9b80:      	mov	x0, xzr
    9b84:      	tst	w2, #0xff
    9b88:      	str	x8, [sp, #0x8]
    9b8c:      	b.eq	0x9bb0 <JNI_OnLoad+0xa54>
    9b90:      	adrp	x8, 0x16000
    9b94:      	ldrb	w8, [x8, #0x10]
    9b98:      	cbz	w8, 0x9bb0 <JNI_OnLoad+0xa54>
    9b9c:      	mov	x0, sp
    9ba0:      	mov	w1, #-0x1               // =-1
    9ba4:      	str	xzr, [sp]
    9ba8:      	bl	0x9bd4 <JNI_OnLoad+0xa78>
    9bac:      	ldr	x0, [sp]
    9bb0:      	ldr	x8, [x19, #0x28]
    9bb4:      	ldr	x9, [sp, #0x8]
    9bb8:      	cmp	x8, x9
    9bbc:      	b.ne	0x9bd0 <JNI_OnLoad+0xa74>
    9bc0:      	ldr	x19, [sp, #0x20]
    9bc4:      	ldp	x29, x30, [sp, #0x10]
    9bc8:      	add	sp, sp, #0x30
    9bcc:      	ret
    9bd0:      	bl	0xd2e0 <__stack_chk_fail@plt>
    9bd4:      	stp	x29, x30, [sp, #-0x60]!
    9bd8:      	bl	0xa07c <JNI_OnLoad+0xf20>
    9bdc:      	sub	sp, sp, #0x9d0
    9be0:      	str	w1, [sp, #0x3c]
    9be4:      	mrs	x20, TPIDR_EL0
    9be8:      	ldr	x8, [x20, #0x28]
    9bec:      	stur	x8, [x29, #-0x10]
    9bf0:      	adrp	x8, 0x16000
    9bf4:      	add	x8, x8, #0x20
    9bf8:      	ldr	x9, [x8]
    9bfc:      	cbz	x9, 0x9f44 <JNI_OnLoad+0xde8>
    9c00:      	ldr	x8, [x8, #0x10]
    9c04:      	cbz	x8, 0x9f44 <JNI_OnLoad+0xde8>
    9c08:      	adrp	x22, 0x16000
    9c0c:      	add	x22, x22, #0x38
    9c10:      	mov	x19, x0
    9c14:      	movi	v0.2d, #0000000000000000
    9c18:      	mov	x0, x22
    9c1c:      	mov	w21, w2
    9c20:      	str	x20, [sp, #0x30]
    9c24:      	stp	q0, q0, [x29, #-0x30]
    9c28:      	stp	q0, q0, [x29, #-0x50]
    9c2c:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    9c30:      	add	x0, x22, #0x40
    9c34:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    9c38:      	adrp	x24, 0x2000
    9c3c:      	mov	x23, xzr
    9c40:      	add	x22, sp, #0x80
    9c44:      	mov	w20, #0x900             // =2304
    9c48:      	add	x24, x24, #0x87f
    9c4c:      	adrp	x8, 0x16000
    9c50:      	ldr	x8, [x8, #0x30]
    9c54:      	cmp	x23, x8
    9c58:      	b.hs	0x9e4c <JNI_OnLoad+0xcf0>
    9c5c:      	adrp	x8, 0x16000
    9c60:      	ldr	x8, [x8, #0x20]
    9c64:      	add	x25, x23, x8
    9c68:      	tbnz	w21, #0x0, 0x9c78 <JNI_OnLoad+0xb1c>
    9c6c:      	mov	x26, xzr
    9c70:      	tbnz	w21, #0x1, 0x9d14 <JNI_OnLoad+0xbb8>
    9c74:      	b	0x9d20 <JNI_OnLoad+0xbc4>
    9c78:      	adrp	x27, 0x16000
    9c7c:      	ldr	x8, [x25]
    9c80:      	ldrb	w9, [x27, #0x18]
    9c84:      	mov	w11, #0x3e80000         // =65536000
    9c88:      	mov	x28, #0x7fffffffffffffff // =9223372036854775807
    9c8c:      	lsr	x10, x8, #16
    9c90:      	udiv	x8, x8, x11
    9c94:      	cmp	w9, #0x0
    9c98:      	mov	w9, #0x3e8              // =1000
    9c9c:      	str	x8, [sp, #0x78]
    9ca0:      	udiv	x8, x10, x9
    9ca4:      	csel	x1, xzr, x28, ne
    9ca8:      	add	x0, sp, #0x78
    9cac:      	add	x2, sp, #0x40
    9cb0:      	msub	x26, x8, x9, x10
    9cb4:      	bl	0xbc10 <JNI_OnLoad+0x2ab4>
    9cb8:      	ldrb	w10, [x27, #0x18]
    9cbc:      	ldp	w9, w8, [sp, #0x50]
    9cc0:      	ldp	w6, w5, [sp, #0x48]
    9cc4:      	ldp	w11, w7, [sp, #0x40]
    9cc8:      	cmp	w10, #0x0
    9ccc:      	add	w3, w8, #0x76c
    9cd0:      	csel	x8, xzr, x28, ne
    9cd4:      	mov	w10, #0xe10             // =3600
    9cd8:      	add	w4, w9, #0x1
    9cdc:      	udiv	x9, x8, x10
    9ce0:      	adrp	x2, 0x2000
    9ce4:      	msub	x8, x9, x10, x8
    9ce8:      	mov	w10, #0x2b              // =43
    9cec:      	add	x0, sp, #0x80
    9cf0:      	mov	w1, #0x900              // =2304
    9cf4:      	add	x2, x2, #0x79d
    9cf8:      	str	w10, [sp, #0x10]
    9cfc:      	str	x26, [sp, #0x8]
    9d00:      	str	w11, [sp]
    9d04:      	stp	x9, x8, [sp, #0x18]
    9d08:      	bl	0xc344 <JNI_OnLoad+0x31e8>
    9d0c:      	mov	x26, x0
    9d10:      	tbz	w21, #0x1, 0x9d20 <JNI_OnLoad+0xbc4>
    9d14:      	ldrh	w0, [x25, #0x10]
    9d18:      	bl	0xa018 <JNI_OnLoad+0xebc>
    9d1c:      	add	x26, x0, x26
    9d20:      	tbnz	w21, #0x2, 0x9d2c <JNI_OnLoad+0xbd0>
    9d24:      	tbnz	w21, #0x3, 0x9d70 <JNI_OnLoad+0xc14>
    9d28:      	b	0x9d88 <JNI_OnLoad+0xc2c>
    9d2c:      	ldrb	w8, [x25]
    9d30:      	adrp	x9, 0x2000
    9d34:      	adrp	x10, 0x2000
    9d38:      	add	x9, x9, #0xb40
    9d3c:      	cmp	w8, #0x1
    9d40:      	add	x10, x10, #0xa35
    9d44:      	csel	x9, x10, x9, eq
    9d48:      	cmp	w8, #0x0
    9d4c:      	adrp	x8, 0x2000
    9d50:      	add	x8, x8, #0x78d
    9d54:      	add	x0, x22, x26
    9d58:      	sub	x1, x20, x26
    9d5c:      	csel	x3, x8, x9, eq
    9d60:      	mov	x2, x24
    9d64:      	bl	0xc344 <JNI_OnLoad+0x31e8>
    9d68:      	add	x26, x0, x26
    9d6c:      	tbz	w21, #0x3, 0x9d88 <JNI_OnLoad+0xc2c>
    9d70:      	ldrb	w8, [x25]
    9d74:      	cmp	x8, #0x1
    9d78:      	b.eq	0x9d88 <JNI_OnLoad+0xc2c>
    9d7c:      	ldrh	w0, [x25, #0x12]
    9d80:      	bl	0xa018 <JNI_OnLoad+0xebc>
    9d84:      	add	x26, x0, x26
    9d88:      	tbz	w21, #0x4, 0x9da4 <JNI_OnLoad+0xc48>
    9d8c:      	ldrb	w8, [x25]
    9d90:      	cmp	x8, #0x1
    9d94:      	b.eq	0x9da4 <JNI_OnLoad+0xc48>
    9d98:      	ldrh	w0, [x25, #0x14]
    9d9c:      	bl	0xa018 <JNI_OnLoad+0xebc>
    9da0:      	add	x26, x0, x26
    9da4:      	tbz	w21, #0x5, 0x9dc0 <JNI_OnLoad+0xc64>
    9da8:      	ldrb	w8, [x25]
    9dac:      	cmp	x8, #0x1
    9db0:      	b.eq	0x9dc0 <JNI_OnLoad+0xc64>
    9db4:      	ldur	x3, [x25, #0x16]
    9db8:      	bl	0xa068 <JNI_OnLoad+0xf0c>
    9dbc:      	add	x26, x0, x26
    9dc0:      	tbz	w21, #0x6, 0x9de0 <JNI_OnLoad+0xc84>
    9dc4:      	ldrb	w3, [x25, #0x1]
    9dc8:      	adrp	x2, 0x2000
    9dcc:      	add	x0, x22, x26
    9dd0:      	sub	x1, x20, x26
    9dd4:      	add	x2, x2, #0x545
    9dd8:      	bl	0xc344 <JNI_OnLoad+0x31e8>
    9ddc:      	add	x26, x0, x26
    9de0:      	tbz	w21, #0x7, 0x9df0 <JNI_OnLoad+0xc94>
    9de4:      	ldr	x3, [x25, #0x8]
    9de8:      	bl	0xa068 <JNI_OnLoad+0xf0c>
    9dec:      	add	x26, x0, x26
    9df0:      	add	x8, x26, x22
    9df4:      	mov	w9, #0xa                // =10
    9df8:      	sturb	w9, [x8, #-0x1]
    9dfc:      	cbz	x19, 0x9e14 <JNI_OnLoad+0xcb8>
    9e00:      	bl	0xa0b0 <JNI_OnLoad+0xf54>
    9e04:      	mov	x4, x26
    9e08:      	bl	0xa040 <JNI_OnLoad+0xee4>
    9e0c:      	cbz	w0, 0x9e28 <JNI_OnLoad+0xccc>
    9e10:      	b	0x9e44 <JNI_OnLoad+0xce8>
    9e14:      	ldr	w0, [sp, #0x3c]
    9e18:      	add	x1, sp, #0x80
    9e1c:      	mov	x2, x26
    9e20:      	bl	0xbb8c <JNI_OnLoad+0x2a30>
    9e24:      	cbnz	w0, 0x9e4c <JNI_OnLoad+0xcf0>
    9e28:      	ldrb	w8, [x25]
    9e2c:      	mov	w9, #0x12               // =18
    9e30:      	cmp	x8, #0x1
    9e34:      	mov	w8, #0x1e               // =30
    9e38:      	csel	x8, x9, x8, eq
    9e3c:      	add	x23, x8, x23
    9e40:      	b	0x9c4c <JNI_OnLoad+0xaf0>
    9e44:      	sub	x0, x29, #0x50
    9e48:      	bl	0x9fec <JNI_OnLoad+0xe90>
    9e4c:      	adrp	x20, 0x16000
    9e50:      	add	x20, x20, #0x11
    9e54:      	add	x0, x20, #0x67
    9e58:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    9e5c:      	add	x0, x20, #0x27
    9e60:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    9e64:      	ldrb	w8, [x20]
    9e68:      	cmp	w8, #0x1
    9e6c:      	b.ne	0x9e80 <JNI_OnLoad+0xd24>
    9e70:      	tbnz	w21, #0x0, 0x9e8c <JNI_OnLoad+0xd30>
    9e74:      	mov	x22, xzr
    9e78:      	tbnz	w21, #0x1, 0x9ea0 <JNI_OnLoad+0xd44>
    9e7c:      	b	0x9ea8 <JNI_OnLoad+0xd4c>
    9e80:      	ldr	x20, [sp, #0x30]
    9e84:      	cbnz	x19, 0x9ed8 <JNI_OnLoad+0xd7c>
    9e88:      	b	0x9f44 <JNI_OnLoad+0xde8>
    9e8c:      	adrp	x2, 0x2000
    9e90:      	add	x2, x2, #0x813
    9e94:      	bl	0xa0d0 <JNI_OnLoad+0xf74>
    9e98:      	mov	x22, x0
    9e9c:      	tbz	w21, #0x1, 0x9ea8 <JNI_OnLoad+0xd4c>
    9ea0:      	bl	0xa04c <JNI_OnLoad+0xef0>
    9ea4:      	add	x22, x0, x22
    9ea8:      	tbnz	w21, #0x2, 0x9f04 <JNI_OnLoad+0xda8>
    9eac:      	cbz	x22, 0x9f10 <JNI_OnLoad+0xdb4>
    9eb0:      	add	x8, sp, #0x80
    9eb4:      	add	x8, x22, x8
    9eb8:      	mov	w9, #0xa                // =10
    9ebc:      	sturb	w9, [x8, #-0x1]
    9ec0:      	cbz	x19, 0x9f24 <JNI_OnLoad+0xdc8>
    9ec4:      	bl	0xa0b0 <JNI_OnLoad+0xf54>
    9ec8:      	mov	x4, x22
    9ecc:      	bl	0xa040 <JNI_OnLoad+0xee4>
    9ed0:      	ldr	x20, [sp, #0x30]
    9ed4:      	cbnz	w0, 0x9ef8 <JNI_OnLoad+0xd9c>
    9ed8:      	adrp	x3, 0x2000
    9edc:      	add	x3, x3, #0xb30
    9ee0:      	sub	x0, x29, #0x50
    9ee4:      	mov	w1, #0x20000            // =131072
    9ee8:      	mov	w2, #0x100000           // =1048576
    9eec:      	mov	w4, #0x1                // =1
    9ef0:      	bl	0xa040 <JNI_OnLoad+0xee4>
    9ef4:      	cbz	w0, 0x9f3c <JNI_OnLoad+0xde0>
    9ef8:      	sub	x0, x29, #0x50
    9efc:      	bl	0x9fec <JNI_OnLoad+0xe90>
    9f00:      	b	0x9f44 <JNI_OnLoad+0xde8>
    9f04:      	bl	0xa04c <JNI_OnLoad+0xef0>
    9f08:      	add	x22, x0, x22
    9f0c:      	cbnz	x22, 0x9eb0 <JNI_OnLoad+0xd54>
    9f10:      	adrp	x2, 0x2000
    9f14:      	add	x2, x2, #0x4d2
    9f18:      	bl	0xa0d0 <JNI_OnLoad+0xf74>
    9f1c:      	mov	x22, x0
    9f20:      	b	0x9eb0 <JNI_OnLoad+0xd54>
    9f24:      	ldr	w0, [sp, #0x3c]
    9f28:      	add	x1, sp, #0x80
    9f2c:      	mov	x2, x22
    9f30:      	bl	0xbb8c <JNI_OnLoad+0x2a30>
    9f34:      	ldr	x20, [sp, #0x30]
    9f38:      	b	0x9f44 <JNI_OnLoad+0xde8>
    9f3c:      	ldur	x8, [x29, #-0x50]
    9f40:      	str	x8, [x19]
    9f44:      	ldr	x8, [x20, #0x28]
    9f48:      	ldur	x9, [x29, #-0x10]
    9f4c:      	cmp	x8, x9
    9f50:      	b.ne	0x9f64 <JNI_OnLoad+0xe08>
    9f54:      	add	sp, sp, #0x9d0
    9f58:      	bl	0xa098 <JNI_OnLoad+0xf3c>
    9f5c:      	ldp	x29, x30, [sp], #0x60
    9f60:      	ret
    9f64:      	bl	0xd2e0 <__stack_chk_fail@plt>
    9f68:      	adrp	x8, 0x16000
    9f6c:      	ldrb	w8, [x8, #0x10]
    9f70:      	cbz	w8, 0x9f90 <JNI_OnLoad+0xe34>
    9f74:      	mov	w2, w1
    9f78:      	mov	w1, w0
    9f7c:      	tbnz	w0, #0x1f, 0x9f90 <JNI_OnLoad+0xe34>
    9f80:      	and	w8, w2, #0xff
    9f84:      	cbz	w8, 0x9f90 <JNI_OnLoad+0xe34>
    9f88:      	mov	x0, xzr
    9f8c:      	b	0x9bd4 <JNI_OnLoad+0xa78>
    9f90:      	ret
    9f94:      	adrp	x9, 0x16000
    9f98:      	add	x9, x9, #0x60
    9f9c:      	ldr	x10, [x9, #0x10]
    9fa0:      	ldr	x9, [x9]
    9fa4:      	mov	x8, xzr
    9fa8:      	mov	w11, wzr
    9fac:      	and	w12, w11, #0xffff
    9fb0:      	cmp	w12, w0, uxth
    9fb4:      	ccmp	x8, x10, #0x2, lo
    9fb8:      	b.hs	0x9fd0 <JNI_OnLoad+0xe74>
    9fbc:      	ldrh	w12, [x8, x9]
    9fc0:      	add	w11, w11, #0x1
    9fc4:      	add	x8, x8, x12
    9fc8:      	add	x8, x8, #0x3
    9fcc:      	b	0x9fac <JNI_OnLoad+0xe50>
    9fd0:      	add	x8, x8, x9
    9fd4:      	adrp	x9, 0x2000
    9fd8:      	add	x9, x9, #0xb40
    9fdc:      	add	x8, x8, #0x2
    9fe0:      	cmp	w12, w0, uxth
    9fe4:      	csel	x0, x8, x9, eq
    9fe8:      	ret
    9fec:      	stp	x29, x30, [sp, #-0x20]!
    9ff0:      	str	x19, [sp, #0x10]
    9ff4:      	mov	x29, sp
    9ff8:      	mov	x19, x0
    9ffc:      	ldr	x0, [x0]
    a000:      	cbz	x0, 0xa00c <JNI_OnLoad+0xeb0>
    a004:      	bl	0xd260 <free@plt>
    a008:      	str	xzr, [x19]
    a00c:      	ldr	x19, [sp, #0x10]
    a010:      	ldp	x29, x30, [sp], #0x20
    a014:      	ret
    a018:      	str	x30, [sp, #-0x10]!
    a01c:      	add	x27, x22, x26
    a020:      	sub	x28, x20, x26
    a024:      	bl	0x9f94 <JNI_OnLoad+0xe38>
    a028:      	mov	x3, x0
    a02c:      	mov	x0, x27
    a030:      	mov	x1, x28
    a034:      	mov	x2, x24
    a038:      	ldr	x30, [sp], #0x10
    a03c:      	b	0xc344 <JNI_OnLoad+0x31e8>
    a040:      	mov	x5, xzr
    a044:      	mov	x6, xzr
    a048:      	b	0x9984 <JNI_OnLoad+0x828>
    a04c:      	add	x8, sp, #0x80
    a050:      	mov	w9, #0x900              // =2304
    a054:      	adrp	x2, 0x2000
    a058:      	add	x0, x8, x22
    a05c:      	sub	x1, x9, x22
    a060:      	add	x2, x2, #0x4d2
    a064:      	b	0xc344 <JNI_OnLoad+0x31e8>
    a068:      	adrp	x2, 0x2000
    a06c:      	add	x0, x22, x26
    a070:      	sub	x1, x20, x26
    a074:      	add	x2, x2, #0xc66
    a078:      	b	0xc344 <JNI_OnLoad+0x31e8>
    a07c:      	stp	x28, x27, [sp, #0x10]
    a080:      	stp	x26, x25, [sp, #0x20]
    a084:      	stp	x24, x23, [sp, #0x30]
    a088:      	stp	x22, x21, [sp, #0x40]
    a08c:      	stp	x20, x19, [sp, #0x50]
    a090:      	mov	x29, sp
    a094:      	ret
    a098:      	ldp	x20, x19, [sp, #0x50]
    a09c:      	ldp	x22, x21, [sp, #0x40]
    a0a0:      	ldp	x24, x23, [sp, #0x30]
    a0a4:      	ldp	x26, x25, [sp, #0x20]
    a0a8:      	ldp	x28, x27, [sp, #0x10]
    a0ac:      	ret
    a0b0:      	sub	x0, x29, #0x50
    a0b4:      	add	x3, sp, #0x80
    a0b8:      	mov	w1, #0x20000            // =131072
    a0bc:      	mov	w2, #0x100000           // =1048576
    a0c0:      	ret
    a0c4:      	mov	w19, w0
    a0c8:      	mov	x0, x20
    a0cc:      	b	0xd3e0 <pthread_mutex_unlock@plt>
    a0d0:      	add	x0, sp, #0x80
    a0d4:      	mov	w1, #0x900              // =2304
    a0d8:      	b	0xc344 <JNI_OnLoad+0x31e8>
    a0dc:      	stp	x29, x30, [sp, #-0x20]!
    a0e0:      	stp	x20, x19, [sp, #0x10]
    a0e4:      	mov	x29, sp
    a0e8:      	bl	0xba68 <JNI_OnLoad+0x290c>
    a0ec:      	adrp	x8, 0x16000
    a0f0:      	str	w0, [x8, #0xa0]
    a0f4:      	adrp	x0, 0x2000
    a0f8:      	add	x0, x0, #0x7cf
    a0fc:      	mov	w1, wzr
    a100:      	bl	0xd280 <dlopen@plt>
    a104:      	cbz	x0, 0xa16c <JNI_OnLoad+0x1010>
    a108:      	adrp	x1, 0x2000
    a10c:      	add	x1, x1, #0x369
    a110:      	mov	x19, x0
    a114:      	bl	0xd290 <dlsym@plt>
    a118:      	adrp	x8, 0x16000
    a11c:      	str	x0, [x8, #0xa8]
    a120:      	cbz	x0, 0xa180 <JNI_OnLoad+0x1024>
    a124:      	adrp	x1, 0x2000
    a128:      	add	x1, x1, #0x37d
    a12c:      	mov	x0, x19
    a130:      	bl	0xd290 <dlsym@plt>
    a134:      	adrp	x8, 0x16000
    a138:      	str	x0, [x8, #0xb0]
    a13c:      	cbz	x0, 0xa180 <JNI_OnLoad+0x1024>
    a140:      	adrp	x1, 0x2000
    a144:      	add	x1, x1, #0x9b1
    a148:      	mov	x0, x19
    a14c:      	bl	0xd290 <dlsym@plt>
    a150:      	cmp	x0, #0x0
    a154:      	adrp	x8, 0x16000
    a158:      	csetm	w20, eq
    a15c:      	str	x0, [x8, #0xb8]
    a160:      	mov	x0, x19
    a164:      	bl	0xd2a0 <dlclose@plt>
    a168:      	b	0xa170 <JNI_OnLoad+0x1014>
    a16c:      	mov	w20, #-0x1              // =-1
    a170:      	mov	w0, w20
    a174:      	ldp	x20, x19, [sp, #0x10]
    a178:      	ldp	x29, x30, [sp], #0x20
    a17c:      	ret
    a180:      	mov	w20, #-0x1              // =-1
    a184:      	b	0xa160 <JNI_OnLoad+0x1004>
    a188:      	adrp	x8, 0x16000
    a18c:      	ldr	x1, [x8, #0xa8]
    a190:      	br	x1
    a194:      	adrp	x8, 0x16000
    a198:      	ldr	w8, [x8, #0xa0]
    a19c:      	cmp	w8, #0x17
    a1a0:      	b.lt	0xa1b0 <JNI_OnLoad+0x1054>
    a1a4:      	adrp	x8, 0x16000
    a1a8:      	ldr	x2, [x8, #0xb0]
    a1ac:      	br	x2
    a1b0:      	mrs	x8, TPIDR_EL0
    a1b4:      	str	x1, [x8, w0, sxtw #3]
    a1b8:      	mov	w0, wzr
    a1bc:      	ret
    a1c0:      	adrp	x8, 0x16000
    a1c4:      	ldr	x0, [x8, #0xb8]
    a1c8:      	br	x0
    a1cc:      	stp	x29, x30, [sp, #-0x20]!
    a1d0:      	str	x19, [sp, #0x10]
    a1d4:      	mov	x29, sp
    a1d8:      	sxtw	x2, w2
    a1dc:      	sxtw	x3, w3
    a1e0:      	sxtw	x4, w4
    a1e4:      	mov	x8, #0xde               // =222
    a1e8:      	svc	#0
    a1ec:      	cmn	x0, #0xfff
    a1f0:      	b.lo	0xa200 <JNI_OnLoad+0x10a4>
    a1f4:      	bl	0xa278 <JNI_OnLoad+0x111c>
    a1f8:      	str	w19, [x0]
    a1fc:      	mov	x0, #-0x1               // =-1
    a200:      	ldr	x19, [sp, #0x10]
    a204:      	ldp	x29, x30, [sp], #0x20
    a208:      	ret
    a20c:      	stp	x29, x30, [sp, #-0x20]!
    a210:      	str	x19, [sp, #0x10]
    a214:      	mov	x29, sp
    a218:      	mov	x8, #0xd7               // =215
    a21c:      	svc	#0
    a220:      	cmn	x0, #0xfff
    a224:      	b.lo	0xa234 <JNI_OnLoad+0x10d8>
    a228:      	bl	0xa278 <JNI_OnLoad+0x111c>
    a22c:      	str	w19, [x0]
    a230:      	mov	x0, #-0x1               // =-1
    a234:      	ldr	x19, [sp, #0x10]
    a238:      	ldp	x29, x30, [sp], #0x20
    a23c:      	ret
    a240:      	stp	x29, x30, [sp, #-0x20]!
    a244:      	str	x19, [sp, #0x10]
    a248:      	mov	x29, sp
    a24c:      	sxtw	x0, w0
    a250:      	mov	x8, #0xa7               // =167
    a254:      	svc	#0
    a258:      	cmn	x0, #0xfff
    a25c:      	b.lo	0xa26c <JNI_OnLoad+0x1110>
    a260:      	bl	0xa278 <JNI_OnLoad+0x111c>
    a264:      	str	w19, [x0]
    a268:      	mov	x0, #-0x1               // =-1
    a26c:      	ldr	x19, [sp, #0x10]
    a270:      	ldp	x29, x30, [sp], #0x20
    a274:      	ret
    a278:      	neg	w19, w0
    a27c:      	b	0xd370 <__errno@plt>
    a280:      	add	x8, x1, x2
    a284:      	stp	x1, x8, [x0]
    a288:      	ret
    a28c:      	ldp	x11, x9, [x0]
    a290:      	mov	x8, xzr
    a294:      	mov	x10, xzr
    a298:      	cmp	x11, x9
    a29c:      	b.hs	0xa2ec <JNI_OnLoad+0x1190>
    a2a0:      	add	x13, x11, #0x1
    a2a4:      	str	x13, [x0]
    a2a8:      	ldrb	w12, [x11]
    a2ac:      	mov	x11, x13
    a2b0:      	and	x13, x12, #0x7f
    a2b4:      	lsl	x13, x13, x10
    a2b8:      	orr	x8, x13, x8
    a2bc:      	add	x10, x10, #0x7
    a2c0:      	tbnz	w12, #0x7, 0xa298 <JNI_OnLoad+0x113c>
    a2c4:      	tst	w12, #0x40
    a2c8:      	mov	w9, #0x3f               // =63
    a2cc:      	mov	x11, #-0x1              // =-1
    a2d0:      	ccmp	x10, x9, #0x2, ne
    a2d4:      	lsl	x9, x11, x10
    a2d8:      	csel	x9, xzr, x9, hi
    a2dc:      	mov	w0, wzr
    a2e0:      	orr	x8, x8, x9
    a2e4:      	str	x8, [x1]
    a2e8:      	ret
    a2ec:      	mov	w0, #-0x1               // =-1
    a2f0:      	ret
    a2f4:      	stp	x29, x30, [sp, #-0x20]!
    a2f8:      	str	x19, [sp, #0x10]
    a2fc:      	mov	x29, sp
    a300:      	mov	w0, #0x48               // =72
    a304:      	bl	0xd270 <malloc@plt>
    a308:      	mov	x19, x0
    a30c:      	cbz	x0, 0xa320 <JNI_OnLoad+0x11c4>
    a310:      	add	x0, x19, #0x10
    a314:      	mov	x1, xzr
    a318:      	stp	xzr, x19, [x19]
    a31c:      	bl	0xd600 <pthread_rwlock_init@plt>
    a320:      	mov	x0, x19
    a324:      	ldr	x19, [sp, #0x10]
    a328:      	ldp	x29, x30, [sp], #0x20
    a32c:      	ret
    a330:      	stp	x29, x30, [sp, #-0x30]!
    a334:      	str	x21, [sp, #0x10]
    a338:      	stp	x20, x19, [sp, #0x20]
    a33c:      	mov	x29, sp
    a340:      	add	x20, x0, #0x10
    a344:      	mov	x19, x0
    a348:      	mov	x0, x20
    a34c:      	bl	0xd470 <pthread_rwlock_wrlock@plt>
    a350:      	mov	x8, x19
    a354:      	ldr	x21, [x8]
    a358:      	cbz	x21, 0xa36c <JNI_OnLoad+0x1210>
    a35c:      	mov	x0, x21
    a360:      	bl	0xab40 <JNI_OnLoad+0x19e4>
    a364:      	add	x8, x21, #0x18
    a368:      	b	0xa354 <JNI_OnLoad+0x11f8>
    a36c:      	mov	x0, x20
    a370:      	bl	0xd3f0 <pthread_rwlock_unlock@plt>
    a374:      	mov	x0, x20
    a378:      	bl	0xd610 <pthread_rwlock_destroy@plt>
    a37c:      	mov	x0, x19
    a380:      	ldp	x20, x19, [sp, #0x20]
    a384:      	ldr	x21, [sp, #0x10]
    a388:      	ldp	x29, x30, [sp], #0x30
    a38c:      	b	0xd260 <free@plt>
    a390:      	stp	x29, x30, [sp, #-0x20]!
    a394:      	str	x19, [sp, #0x10]
    a398:      	mov	x29, sp
    a39c:      	mov	x19, x0
    a3a0:      	ldr	x0, [x0, #0x10]
    a3a4:      	cbz	x0, 0xa3b0 <JNI_OnLoad+0x1254>
    a3a8:      	and	w1, w1, #0x1
    a3ac:      	bl	0x8c40 <.text+0x3654>
    a3b0:      	mov	x0, x19
    a3b4:      	ldr	x19, [sp, #0x10]
    a3b8:      	ldp	x29, x30, [sp], #0x20
    a3bc:      	b	0xd260 <free@plt>
    a3c0:      	sub	sp, sp, #0x80
    a3c4:      	stp	x29, x30, [sp, #0x20]
    a3c8:      	stp	x28, x27, [sp, #0x30]
    a3cc:      	stp	x26, x25, [sp, #0x40]
    a3d0:      	stp	x24, x23, [sp, #0x50]
    a3d4:      	stp	x22, x21, [sp, #0x60]
    a3d8:      	stp	x20, x19, [sp, #0x70]
    a3dc:      	add	x29, sp, #0x20
    a3e0:      	mrs	x19, TPIDR_EL0
    a3e4:      	ldr	x8, [x19, #0x28]
    a3e8:      	mov	x21, x6
    a3ec:      	mov	x23, x5
    a3f0:      	mov	x24, x4
    a3f4:      	mov	x25, x3
    a3f8:      	mov	x20, x2
    a3fc:      	mov	x27, x1
    a400:      	mov	x28, x0
    a404:      	stur	x8, [x29, #-0x8]
    a408:      	bl	0xd3d0 <bytehook_get_mode@plt>
    a40c:      	cmp	w0, #0x1
    a410:      	b.ne	0xa444 <JNI_OnLoad+0x12e8>
    a414:      	ldr	x26, [x28, #0x68]
    a418:      	str	x23, [sp, #0x8]
    a41c:      	add	x23, x26, #0x10
    a420:      	mov	x0, x23
    a424:      	bl	0xd430 <pthread_rwlock_rdlock@plt>
    a428:      	bl	0xab54 <JNI_OnLoad+0x19f8>
    a42c:      	mov	x22, x0
    a430:      	str	x0, [sp, #0x10]
    a434:      	bl	0xab38 <JNI_OnLoad+0x19dc>
    a438:      	cbz	x22, 0xa470 <JNI_OnLoad+0x1314>
    a43c:      	mov	w22, #0x1d              // =29
    a440:      	b	0xa52c <JNI_OnLoad+0x13d0>
    a444:      	mov	x0, x28
    a448:      	mov	x1, x27
    a44c:      	mov	x2, x20
    a450:      	mov	x3, x25
    a454:      	mov	x4, x24
    a458:      	mov	x5, x23
    a45c:      	mov	x6, x21
    a460:      	bl	0xa5a4 <JNI_OnLoad+0x1448>
    a464:      	mov	w22, w0
    a468:      	cbz	w22, 0xa534 <JNI_OnLoad+0x13d8>
    a46c:      	b	0xa53c <JNI_OnLoad+0x13e0>
    a470:      	add	x0, sp, #0x10
    a474:      	mov	x1, x20
    a478:      	mov	x2, xzr
    a47c:      	bl	0xaa48 <JNI_OnLoad+0x18ec>
    a480:      	mov	w22, w0
    a484:      	cbnz	w0, 0xa52c <JNI_OnLoad+0x13d0>
    a488:      	mov	x0, x23
    a48c:      	bl	0xd470 <pthread_rwlock_wrlock@plt>
    a490:      	bl	0xab54 <JNI_OnLoad+0x19f8>
    a494:      	ldr	x10, [sp, #0x10]
    a498:      	cbz	x0, 0xa4a8 <JNI_OnLoad+0x134c>
    a49c:      	mov	x24, x10
    a4a0:      	mov	w22, #0x1d              // =29
    a4a4:      	b	0xa51c <JNI_OnLoad+0x13c0>
    a4a8:      	mov	x8, x10
    a4ac:      	str	xzr, [x8, #0x18]!
    a4b0:      	ldr	x9, [x26, #0x8]
    a4b4:      	ldr	x4, [sp, #0x8]
    a4b8:      	mov	x0, x28
    a4bc:      	mov	x1, x27
    a4c0:      	str	x9, [x10, #0x20]
    a4c4:      	str	x10, [x9]
    a4c8:      	str	x8, [x26, #0x8]
    a4cc:      	add	x8, x10, #0x8
    a4d0:      	mov	x2, x25
    a4d4:      	mov	x3, x24
    a4d8:      	mov	x5, x8
    a4dc:      	mov	x25, x8
    a4e0:      	mov	x24, x10
    a4e4:      	bl	0x8370 <.text+0x2d84>
    a4e8:      	mov	w22, w0
    a4ec:      	cbz	w0, 0xa504 <JNI_OnLoad+0x13a8>
    a4f0:      	ldp	x8, x9, [x24, #0x18]
    a4f4:      	cbz	x8, 0xa514 <JNI_OnLoad+0x13b8>
    a4f8:      	str	x9, [x8, #0x20]
    a4fc:      	ldr	x9, [x24, #0x20]
    a500:      	b	0xa518 <JNI_OnLoad+0x13bc>
    a504:      	ldr	x8, [x25]
    a508:      	mov	x24, xzr
    a50c:      	str	x8, [x21]
    a510:      	b	0xa51c <JNI_OnLoad+0x13c0>
    a514:      	str	x9, [x26, #0x8]
    a518:      	str	x8, [x9]
    a51c:      	bl	0xab38 <JNI_OnLoad+0x19dc>
    a520:      	cbz	x24, 0xa52c <JNI_OnLoad+0x13d0>
    a524:      	mov	x0, x24
    a528:      	bl	0xab40 <JNI_OnLoad+0x19e4>
    a52c:      	ldr	x23, [sp, #0x8]
    a530:      	cbnz	w22, 0xa53c <JNI_OnLoad+0x13e0>
    a534:      	bl	0xab14 <JNI_OnLoad+0x19b8>
    a538:      	b.ls	0xa570 <JNI_OnLoad+0x1414>
    a53c:      	ldr	x8, [x19, #0x28]
    a540:      	ldur	x9, [x29, #-0x8]
    a544:      	cmp	x8, x9
    a548:      	b.ne	0xa5a0 <JNI_OnLoad+0x1444>
    a54c:      	mov	w0, w22
    a550:      	ldp	x20, x19, [sp, #0x70]
    a554:      	ldp	x22, x21, [sp, #0x60]
    a558:      	ldp	x24, x23, [sp, #0x50]
    a55c:      	ldp	x26, x25, [sp, #0x40]
    a560:      	ldp	x28, x27, [sp, #0x30]
    a564:      	ldp	x29, x30, [sp, #0x20]
    a568:      	add	sp, sp, #0x80
    a56c:      	ret
    a570:      	bl	0xd3d0 <bytehook_get_mode@plt>
    a574:      	ldr	x6, [x21]
    a578:      	bl	0xaac0 <JNI_OnLoad+0x1964>
    a57c:      	adrp	x2, 0x2000
    a580:      	csel	x3, x9, x8, eq
    a584:      	add	x1, x1, #0x94c
    a588:      	add	x2, x2, #0x832
    a58c:      	mov	w0, #0x4                // =4
    a590:      	mov	x4, x20
    a594:      	mov	x5, x23
    a598:      	bl	0xd3a0 <__android_log_print@plt>
    a59c:      	b	0xa53c <JNI_OnLoad+0x13e0>
    a5a0:      	bl	0xd2e0 <__stack_chk_fail@plt>
    a5a4:      	sub	sp, sp, #0x90
    a5a8:      	stp	x29, x30, [sp, #0x30]
    a5ac:      	stp	x28, x27, [sp, #0x40]
    a5b0:      	stp	x26, x25, [sp, #0x50]
    a5b4:      	stp	x24, x23, [sp, #0x60]
    a5b8:      	stp	x22, x21, [sp, #0x70]
    a5bc:      	stp	x20, x19, [sp, #0x80]
    a5c0:      	add	x29, sp, #0x30
    a5c4:      	mrs	x8, TPIDR_EL0
    a5c8:      	str	x8, [sp, #0x10]
    a5cc:      	ldr	x8, [x8, #0x28]
    a5d0:      	mov	x23, x0
    a5d4:      	mov	x27, x6
    a5d8:      	mov	x25, x5
    a5dc:      	stur	x8, [x29, #-0x8]
    a5e0:      	ldr	x22, [x0, #0x68]
    a5e4:      	mov	x26, x4
    a5e8:      	mov	x20, x3
    a5ec:      	mov	x21, x2
    a5f0:      	add	x19, x22, #0x10
    a5f4:      	mov	x0, x19
    a5f8:      	mov	x28, x1
    a5fc:      	bl	0xd430 <pthread_rwlock_rdlock@plt>
    a600:      	bl	0xab48 <JNI_OnLoad+0x19ec>
    a604:      	stur	x0, [x29, #-0x10]
    a608:      	cbz	x0, 0xa62c <JNI_OnLoad+0x14d0>
    a60c:      	bl	0xaadc <JNI_OnLoad+0x1980>
    a610:      	ldr	x0, [x24, #0x10]
    a614:      	mov	x1, x25
    a618:      	bl	0x8dbc <.text+0x37d0>
    a61c:      	mov	w24, w0
    a620:      	mov	x0, x19
    a624:      	bl	0xd3f0 <pthread_rwlock_unlock@plt>
    a628:      	b	0xa740 <JNI_OnLoad+0x15e4>
    a62c:      	mov	x0, x19
    a630:      	stp	x20, x25, [sp]
    a634:      	bl	0xd3f0 <pthread_rwlock_unlock@plt>
    a638:      	sub	x0, x29, #0x10
    a63c:      	add	x2, sp, #0x18
    a640:      	mov	x1, x21
    a644:      	bl	0xaa48 <JNI_OnLoad+0x18ec>
    a648:      	mov	w24, w0
    a64c:      	cbnz	w0, 0xa740 <JNI_OnLoad+0x15e4>
    a650:      	mov	x0, x19
    a654:      	bl	0xd470 <pthread_rwlock_wrlock@plt>
    a658:      	bl	0xab48 <JNI_OnLoad+0x19ec>
    a65c:      	cbz	x0, 0xa67c <JNI_OnLoad+0x1520>
    a660:      	bl	0xaadc <JNI_OnLoad+0x1980>
    a664:      	ldr	x0, [x24, #0x10]
    a668:      	ldr	x1, [sp, #0x8]
    a66c:      	ldur	x21, [x29, #-0x10]
    a670:      	bl	0x8dbc <.text+0x37d0>
    a674:      	mov	w24, w0
    a678:      	b	0xa72c <JNI_OnLoad+0x15d0>
    a67c:      	ldur	x21, [x29, #-0x10]
    a680:      	mov	x8, x21
    a684:      	str	xzr, [x8, #0x18]!
    a688:      	ldr	x9, [x22, #0x8]
    a68c:      	str	x9, [x21, #0x20]
    a690:      	str	x21, [x9]
    a694:      	str	x8, [x22, #0x8]
    a698:      	ldr	x0, [x21, #0x10]
    a69c:      	ldr	x24, [sp, #0x18]
    a6a0:      	bl	0x8db4 <.text+0x37c8>
    a6a4:      	ldr	x2, [sp]
    a6a8:      	mov	x5, x0
    a6ac:      	mov	x0, x23
    a6b0:      	mov	x1, x28
    a6b4:      	mov	x3, x26
    a6b8:      	mov	x4, x24
    a6bc:      	bl	0x8370 <.text+0x2d84>
    a6c0:      	ldr	x20, [sp, #0x8]
    a6c4:      	cbz	w0, 0xa6d0 <JNI_OnLoad+0x1574>
    a6c8:      	mov	w24, w0
    a6cc:      	b	0xa710 <JNI_OnLoad+0x15b4>
    a6d0:      	ldr	x0, [x21, #0x10]
    a6d4:      	bl	0x8dac <.text+0x37c0>
    a6d8:      	str	x0, [x21, #0x8]
    a6dc:      	str	x0, [x27]
    a6e0:      	ldr	x0, [x21, #0x10]
    a6e4:      	mov	x1, x20
    a6e8:      	bl	0x8dbc <.text+0x37d0>
    a6ec:      	mov	w24, w0
    a6f0:      	cbz	w0, 0xa778 <JNI_OnLoad+0x161c>
    a6f4:      	ldr	x4, [x21, #0x8]
    a6f8:      	ldr	x2, [sp]
    a6fc:      	mov	x0, x23
    a700:      	mov	x1, xzr
    a704:      	mov	x3, x26
    a708:      	mov	x5, xzr
    a70c:      	bl	0x8370 <.text+0x2d84>
    a710:      	ldp	x8, x9, [x21, #0x18]
    a714:      	cbz	x8, 0xa724 <JNI_OnLoad+0x15c8>
    a718:      	str	x9, [x8, #0x20]
    a71c:      	ldr	x9, [x21, #0x20]
    a720:      	b	0xa728 <JNI_OnLoad+0x15cc>
    a724:      	str	x9, [x22, #0x8]
    a728:      	str	x8, [x9]
    a72c:      	mov	x0, x19
    a730:      	bl	0xd3f0 <pthread_rwlock_unlock@plt>
    a734:      	cbz	x21, 0xa740 <JNI_OnLoad+0x15e4>
    a738:      	mov	x0, x21
    a73c:      	bl	0xab40 <JNI_OnLoad+0x19e4>
    a740:      	ldr	x8, [sp, #0x10]
    a744:      	ldr	x8, [x8, #0x28]
    a748:      	ldur	x9, [x29, #-0x8]
    a74c:      	cmp	x8, x9
    a750:      	b.ne	0xa780 <JNI_OnLoad+0x1624>
    a754:      	mov	w0, w24
    a758:      	ldp	x20, x19, [sp, #0x80]
    a75c:      	ldp	x22, x21, [sp, #0x70]
    a760:      	ldp	x24, x23, [sp, #0x60]
    a764:      	ldp	x26, x25, [sp, #0x50]
    a768:      	ldp	x28, x27, [sp, #0x40]
    a76c:      	ldp	x29, x30, [sp, #0x30]
    a770:      	add	sp, sp, #0x90
    a774:      	ret
    a778:      	mov	x21, xzr
    a77c:      	b	0xa72c <JNI_OnLoad+0x15d0>
    a780:      	bl	0xd2e0 <__stack_chk_fail@plt>
    a784:      	stp	x29, x30, [sp, #-0x50]!
    a788:      	stp	x26, x25, [sp, #0x10]
    a78c:      	stp	x24, x23, [sp, #0x20]
    a790:      	stp	x22, x21, [sp, #0x30]
    a794:      	stp	x20, x19, [sp, #0x40]
    a798:      	mov	x29, sp
    a79c:      	mov	x21, x6
    a7a0:      	mov	x19, x5
    a7a4:      	mov	x22, x4
    a7a8:      	mov	x23, x3
    a7ac:      	mov	x20, x2
    a7b0:      	mov	x24, x1
    a7b4:      	mov	x25, x0
    a7b8:      	bl	0xd3d0 <bytehook_get_mode@plt>
    a7bc:      	cmp	w0, #0x1
    a7c0:      	b.ne	0xa804 <JNI_OnLoad+0x16a8>
    a7c4:      	ldr	x8, [x25, #0x68]
    a7c8:      	add	x26, x8, #0x10
    a7cc:      	mov	x0, x26
    a7d0:      	bl	0xd470 <pthread_rwlock_wrlock@plt>
    a7d4:      	mov	x0, x25
    a7d8:      	mov	x1, x24
    a7dc:      	mov	x2, x23
    a7e0:      	mov	x3, x22
    a7e4:      	mov	x4, x19
    a7e8:      	mov	x5, x21
    a7ec:      	bl	0x8370 <.text+0x2d84>
    a7f0:      	mov	w22, w0
    a7f4:      	mov	x0, x26
    a7f8:      	bl	0xd3f0 <pthread_rwlock_unlock@plt>
    a7fc:      	cbz	w22, 0xa82c <JNI_OnLoad+0x16d0>
    a800:      	b	0xa834 <JNI_OnLoad+0x16d8>
    a804:      	mov	x0, x25
    a808:      	mov	x1, x24
    a80c:      	mov	x2, x20
    a810:      	mov	x3, x23
    a814:      	mov	x4, x22
    a818:      	mov	x5, x19
    a81c:      	mov	x6, x21
    a820:      	bl	0xa5a4 <JNI_OnLoad+0x1448>
    a824:      	mov	w22, w0
    a828:      	cbnz	w22, 0xa834 <JNI_OnLoad+0x16d8>
    a82c:      	bl	0xab14 <JNI_OnLoad+0x19b8>
    a830:      	b.ls	0xa850 <JNI_OnLoad+0x16f4>
    a834:      	mov	w0, w22
    a838:      	ldp	x20, x19, [sp, #0x40]
    a83c:      	ldp	x22, x21, [sp, #0x30]
    a840:      	ldp	x24, x23, [sp, #0x20]
    a844:      	ldp	x26, x25, [sp, #0x10]
    a848:      	ldp	x29, x30, [sp], #0x50
    a84c:      	ret
    a850:      	bl	0xd3d0 <bytehook_get_mode@plt>
    a854:      	ldr	x6, [x21]
    a858:      	bl	0xaac0 <JNI_OnLoad+0x1964>
    a85c:      	adrp	x2, 0x2000
    a860:      	csel	x3, x9, x8, eq
    a864:      	add	x1, x1, #0x94c
    a868:      	add	x2, x2, #0xbbf
    a86c:      	mov	w0, #0x4                // =4
    a870:      	mov	x4, x20
    a874:      	mov	x5, x19
    a878:      	bl	0xd3a0 <__android_log_print@plt>
    a87c:      	b	0xa834 <JNI_OnLoad+0x16d8>
    a880:      	sub	sp, sp, #0x70
    a884:      	stp	x29, x30, [sp, #0x10]
    a888:      	stp	x28, x27, [sp, #0x20]
    a88c:      	stp	x26, x25, [sp, #0x30]
    a890:      	stp	x24, x23, [sp, #0x40]
    a894:      	stp	x22, x21, [sp, #0x50]
    a898:      	stp	x20, x19, [sp, #0x60]
    a89c:      	add	x29, sp, #0x10
    a8a0:      	mrs	x28, TPIDR_EL0
    a8a4:      	ldr	x8, [x28, #0x28]
    a8a8:      	mov	x19, x4
    a8ac:      	mov	x22, x3
    a8b0:      	mov	x25, x2
    a8b4:      	mov	x20, x1
    a8b8:      	mov	x26, x0
    a8bc:      	str	x8, [sp, #0x8]
    a8c0:      	bl	0xd3d0 <bytehook_get_mode@plt>
    a8c4:      	cmp	w0, #0x1
    a8c8:      	b.ne	0xa904 <JNI_OnLoad+0x17a8>
    a8cc:      	bl	0xab28 <JNI_OnLoad+0x19cc>
    a8d0:      	mov	x0, x27
    a8d4:      	mov	x1, x20
    a8d8:      	bl	0xaa28 <JNI_OnLoad+0x18cc>
    a8dc:      	mov	x24, x0
    a8e0:      	cbz	x0, 0xa93c <JNI_OnLoad+0x17e0>
    a8e4:      	bl	0xaaf8 <JNI_OnLoad+0x199c>
    a8e8:      	ldr	x21, [x24, #0x8]
    a8ec:      	ldp	x8, x9, [x24, #0x18]
    a8f0:      	mov	w22, w0
    a8f4:      	cbz	x8, 0xa94c <JNI_OnLoad+0x17f0>
    a8f8:      	str	x9, [x8, #0x20]
    a8fc:      	ldr	x9, [x24, #0x20]
    a900:      	b	0xa950 <JNI_OnLoad+0x17f4>
    a904:      	bl	0xab28 <JNI_OnLoad+0x19cc>
    a908:      	mov	x0, x27
    a90c:      	mov	x1, x20
    a910:      	bl	0xaa28 <JNI_OnLoad+0x18cc>
    a914:      	mov	x24, x0
    a918:      	cbz	x0, 0xa944 <JNI_OnLoad+0x17e8>
    a91c:      	ldp	x21, x0, [x24, #0x8]
    a920:      	add	x2, sp, #0x4
    a924:      	mov	x1, x19
    a928:      	bl	0x8ed4 <.text+0x38e8>
    a92c:      	cbz	w0, 0xa968 <JNI_OnLoad+0x180c>
    a930:      	mov	x24, xzr
    a934:      	mov	w22, #0x1e              // =30
    a938:      	b	0xa9a0 <JNI_OnLoad+0x1844>
    a93c:      	mov	w22, #0x1e              // =30
    a940:      	b	0xa954 <JNI_OnLoad+0x17f8>
    a944:      	mov	w22, #0x1e              // =30
    a948:      	b	0xa9a0 <JNI_OnLoad+0x1844>
    a94c:      	str	x9, [x27, #0x8]
    a950:      	str	x8, [x9]
    a954:      	bl	0xab38 <JNI_OnLoad+0x19dc>
    a958:      	cbz	x24, 0xa9b4 <JNI_OnLoad+0x1858>
    a95c:      	mov	x0, x24
    a960:      	mov	w1, wzr
    a964:      	b	0xa9b0 <JNI_OnLoad+0x1854>
    a968:      	ldrb	w8, [sp, #0x4]
    a96c:      	cbz	w8, 0xa97c <JNI_OnLoad+0x1820>
    a970:      	mov	x24, xzr
    a974:      	mov	w22, wzr
    a978:      	b	0xa9a0 <JNI_OnLoad+0x1844>
    a97c:      	bl	0xaaf8 <JNI_OnLoad+0x199c>
    a980:      	ldp	x8, x9, [x24, #0x18]
    a984:      	mov	w22, w0
    a988:      	cbz	x8, 0xa998 <JNI_OnLoad+0x183c>
    a98c:      	str	x9, [x8, #0x20]
    a990:      	ldr	x9, [x24, #0x20]
    a994:      	b	0xa99c <JNI_OnLoad+0x1840>
    a998:      	str	x9, [x27, #0x8]
    a99c:      	str	x8, [x9]
    a9a0:      	bl	0xab38 <JNI_OnLoad+0x19dc>
    a9a4:      	cbz	x24, 0xa9b4 <JNI_OnLoad+0x1858>
    a9a8:      	mov	w1, #0x1                // =1
    a9ac:      	mov	x0, x24
    a9b0:      	bl	0xa390 <JNI_OnLoad+0x1234>
    a9b4:      	cbnz	w22, 0xa9c0 <JNI_OnLoad+0x1864>
    a9b8:      	bl	0xab14 <JNI_OnLoad+0x19b8>
    a9bc:      	b.ls	0xa9f4 <JNI_OnLoad+0x1898>
    a9c0:      	ldr	x8, [x28, #0x28]
    a9c4:      	ldr	x9, [sp, #0x8]
    a9c8:      	cmp	x8, x9
    a9cc:      	b.ne	0xaa24 <JNI_OnLoad+0x18c8>
    a9d0:      	mov	w0, w22
    a9d4:      	ldp	x20, x19, [sp, #0x60]
    a9d8:      	ldp	x22, x21, [sp, #0x50]
    a9dc:      	ldp	x24, x23, [sp, #0x40]
    a9e0:      	ldp	x26, x25, [sp, #0x30]
    a9e4:      	ldp	x28, x27, [sp, #0x20]
    a9e8:      	ldp	x29, x30, [sp, #0x10]
    a9ec:      	add	sp, sp, #0x70
    a9f0:      	ret
    a9f4:      	bl	0xd3d0 <bytehook_get_mode@plt>
    a9f8:      	bl	0xaac0 <JNI_OnLoad+0x1964>
    a9fc:      	adrp	x2, 0x2000
    aa00:      	csel	x3, x9, x8, eq
    aa04:      	add	x1, x1, #0x94c
    aa08:      	add	x2, x2, #0xb46
    aa0c:      	mov	w0, #0x4                // =4
    aa10:      	mov	x4, x20
    aa14:      	mov	x5, x19
    aa18:      	mov	x6, x21
    aa1c:      	bl	0xd3a0 <__android_log_print@plt>
    aa20:      	b	0xa9c0 <JNI_OnLoad+0x1864>
    aa24:      	bl	0xd2e0 <__stack_chk_fail@plt>
    aa28:      	ldr	x0, [x0]
    aa2c:      	cbz	x0, 0xaa44 <JNI_OnLoad+0x18e8>
    aa30:      	ldr	x8, [x0]
    aa34:      	cmp	x8, x1
    aa38:      	b.eq	0xaa44 <JNI_OnLoad+0x18e8>
    aa3c:      	add	x0, x0, #0x18
    aa40:      	b	0xaa28 <JNI_OnLoad+0x18cc>
    aa44:      	ret
    aa48:      	stp	x29, x30, [sp, #-0x30]!
    aa4c:      	str	x21, [sp, #0x10]
    aa50:      	stp	x20, x19, [sp, #0x20]
    aa54:      	mov	x29, sp
    aa58:      	mov	x19, x0
    aa5c:      	mov	w0, #0x28               // =40
    aa60:      	mov	x20, x2
    aa64:      	mov	x21, x1
    aa68:      	bl	0xd270 <malloc@plt>
    aa6c:      	str	x0, [x19]
    aa70:      	cbz	x0, 0xaa9c <JNI_OnLoad+0x1940>
    aa74:      	stp	xzr, xzr, [x0, #0x8]
    aa78:      	str	x21, [x0]
    aa7c:      	cbz	x20, 0xaa94 <JNI_OnLoad+0x1938>
    aa80:      	mov	x0, x20
    aa84:      	bl	0x88d0 <.text+0x32e4>
    aa88:      	ldr	x8, [x19]
    aa8c:      	str	x0, [x8, #0x10]
    aa90:      	cbz	x0, 0xaaa4 <JNI_OnLoad+0x1948>
    aa94:      	mov	w0, wzr
    aa98:      	b	0xaab0 <JNI_OnLoad+0x1954>
    aa9c:      	mov	w0, #0x1c               // =28
    aaa0:      	b	0xaab0 <JNI_OnLoad+0x1954>
    aaa4:      	ldr	x0, [x19]
    aaa8:      	bl	0xd260 <free@plt>
    aaac:      	mov	w0, #0x11               // =17
    aab0:      	ldp	x20, x19, [sp, #0x20]
    aab4:      	ldr	x21, [sp, #0x10]
    aab8:      	ldp	x29, x30, [sp], #0x30
    aabc:      	ret
    aac0:      	adrp	x8, 0x2000
    aac4:      	adrp	x9, 0x2000
    aac8:      	add	x8, x8, #0x72c
    aacc:      	add	x9, x9, #0x677
    aad0:      	cmp	w0, #0x1
    aad4:      	adrp	x1, 0x2000
    aad8:      	ret
    aadc:      	ldr	x8, [x0, #0x8]
    aae0:      	mov	x24, x0
    aae4:      	str	x8, [x27]
    aae8:      	ldr	x1, [x23, #0xa0]
    aaec:      	ldr	x2, [x0, #0x8]
    aaf0:      	mov	x0, x28
    aaf4:      	b	0xb148 <JNI_OnLoad+0x1fec>
    aaf8:      	ldr	x4, [x24, #0x8]
    aafc:      	mov	x0, x26
    ab00:      	mov	x1, xzr
    ab04:      	mov	x2, x25
    ab08:      	mov	x3, x22
    ab0c:      	mov	x5, xzr
    ab10:      	b	0x8370 <.text+0x2d84>
    ab14:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    ab18:      	ldr	x8, [x8, #0xaa8]
    ab1c:      	ldr	w8, [x8]
    ab20:      	cmp	w8, #0x4
    ab24:      	ret
    ab28:      	ldr	x27, [x26, #0x68]
    ab2c:      	add	x23, x27, #0x10
    ab30:      	mov	x0, x23
    ab34:      	b	0xd470 <pthread_rwlock_wrlock@plt>
    ab38:      	mov	x0, x23
    ab3c:      	b	0xd3f0 <pthread_rwlock_unlock@plt>
    ab40:      	mov	w1, wzr
    ab44:      	b	0xa390 <JNI_OnLoad+0x1234>
    ab48:      	mov	x0, x22
    ab4c:      	mov	x1, x21
    ab50:      	b	0xaa28 <JNI_OnLoad+0x18cc>
    ab54:      	mov	x0, x26
    ab58:      	mov	x1, x20
    ab5c:      	b	0xaa28 <JNI_OnLoad+0x18cc>
    ab60:      	stp	x29, x30, [sp, #-0x20]!
    ab64:      	stp	x20, x19, [sp, #0x10]
    ab68:      	mov	x29, sp
    ab6c:      	mov	x8, x5
    ab70:      	mov	x19, x0
    ab74:      	and	w5, w6, #0x1
    ab78:      	mov	x0, x1
    ab7c:      	mov	x1, x2
    ab80:      	mov	x2, x3
    ab84:      	mov	x3, x4
    ab88:      	mov	x4, x8
    ab8c:      	bl	0xabb8 <JNI_OnLoad+0x1a5c>
    ab90:      	mov	x20, x0
    ab94:      	cbz	x0, 0xaba8 <JNI_OnLoad+0x1a4c>
    ab98:      	mov	x0, x19
    ab9c:      	str	xzr, [x20]
    aba0:      	bl	0xd480 <strdup@plt>
    aba4:      	str	x0, [x20, #0x10]
    aba8:      	mov	x0, x20
    abac:      	ldp	x20, x19, [sp, #0x10]
    abb0:      	ldp	x29, x30, [sp], #0x20
    abb4:      	ret
    abb8:      	stp	x29, x30, [sp, #-0x50]!
    abbc:      	str	x25, [sp, #0x10]
    abc0:      	stp	x24, x23, [sp, #0x20]
    abc4:      	stp	x22, x21, [sp, #0x30]
    abc8:      	stp	x20, x19, [sp, #0x40]
    abcc:      	mov	x29, sp
    abd0:      	mov	x24, x0
    abd4:      	mov	w0, #0x70               // =112
    abd8:      	mov	w25, w5
    abdc:      	mov	x19, x4
    abe0:      	mov	x20, x3
    abe4:      	mov	x22, x2
    abe8:      	mov	x23, x1
    abec:      	bl	0xd270 <malloc@plt>
    abf0:      	mov	x21, x0
    abf4:      	cbz	x0, 0xac30 <JNI_OnLoad+0x1ad4>
    abf8:      	and	w25, w25, #0x1
    abfc:      	cbz	x24, 0xac0c <JNI_OnLoad+0x1ab0>
    ac00:      	mov	x0, x24
    ac04:      	bl	0xd480 <strdup@plt>
    ac08:      	b	0xac10 <JNI_OnLoad+0x1ab4>
    ac0c:      	mov	x0, xzr
    ac10:      	stp	x0, xzr, [x21, #0x30]
    ac14:      	mov	x0, x23
    ac18:      	bl	0xd480 <strdup@plt>
    ac1c:      	mov	w8, #0xff               // =255
    ac20:      	stp	x0, x22, [x21, #0x40]
    ac24:      	stp	x20, x19, [x21, #0x50]
    ac28:      	str	w8, [x21, #0x8]
    ac2c:      	strb	w25, [x21, #0xc]
    ac30:      	mov	x0, x21
    ac34:      	ldp	x20, x19, [sp, #0x40]
    ac38:      	ldp	x22, x21, [sp, #0x30]
    ac3c:      	ldp	x24, x23, [sp, #0x20]
    ac40:      	ldr	x25, [sp, #0x10]
    ac44:      	ldp	x29, x30, [sp], #0x50
    ac48:      	ret
    ac4c:      	stp	x29, x30, [sp, #-0x20]!
    ac50:      	stp	x20, x19, [sp, #0x10]
    ac54:      	mov	x29, sp
    ac58:      	mov	x8, x5
    ac5c:      	mov	x19, x1
    ac60:      	mov	x20, x0
    ac64:      	and	w5, w7, #0x1
    ac68:      	mov	x0, x2
    ac6c:      	mov	x1, x3
    ac70:      	mov	x2, x4
    ac74:      	mov	x3, x8
    ac78:      	mov	x4, x6
    ac7c:      	bl	0xabb8 <JNI_OnLoad+0x1a5c>
    ac80:      	cbz	x0, 0xac94 <JNI_OnLoad+0x1b38>
    ac84:      	movi	v0.2s, #0x2
    ac88:      	str	xzr, [x0, #0x10]
    ac8c:      	str	d0, [x0]
    ac90:      	stp	x20, x19, [x0, #0x20]
    ac94:      	ldp	x20, x19, [sp, #0x10]
    ac98:      	ldp	x29, x30, [sp], #0x20
    ac9c:      	ret
    aca0:      	stp	x29, x30, [sp, #-0x10]!
    aca4:      	mov	x29, sp
    aca8:      	and	w5, w5, #0x1
    acac:      	bl	0xabb8 <JNI_OnLoad+0x1a5c>
    acb0:      	cbz	x0, 0xacc4 <JNI_OnLoad+0x1b68>
    acb4:      	adrp	x8, 0x2000
    acb8:      	ldr	d0, [x8, #0xd18]
    acbc:      	str	xzr, [x0, #0x10]
    acc0:      	str	d0, [x0]
    acc4:      	ldp	x29, x30, [sp], #0x10
    acc8:      	ret
    accc:      	stp	x29, x30, [sp, #-0x20]!
    acd0:      	str	x19, [sp, #0x10]
    acd4:      	mov	x29, sp
    acd8:      	cbz	x0, 0xad14 <JNI_OnLoad+0x1bb8>
    acdc:      	ldr	x8, [x0]
    ace0:      	mov	x19, x0
    ace4:      	cbz	x8, 0xad14 <JNI_OnLoad+0x1bb8>
    ace8:      	ldr	x0, [x8, #0x10]
    acec:      	bl	0xd260 <free@plt>
    acf0:      	ldr	x8, [x19]
    acf4:      	ldr	x0, [x8, #0x30]
    acf8:      	bl	0xd260 <free@plt>
    acfc:      	ldr	x8, [x19]
    ad00:      	ldr	x0, [x8, #0x40]
    ad04:      	bl	0xd260 <free@plt>
    ad08:      	ldr	x0, [x19]
    ad0c:      	bl	0xd260 <free@plt>
    ad10:      	str	xzr, [x19]
    ad14:      	ldr	x19, [sp, #0x10]
    ad18:      	ldp	x29, x30, [sp], #0x20
    ad1c:      	ret
    ad20:      	stp	x29, x30, [sp, #-0x20]!
    ad24:      	str	x19, [sp, #0x10]
    ad28:      	mov	x29, sp
    ad2c:      	mov	w2, #-0x1               // =-1
    ad30:      	mov	x1, xzr
    ad34:      	mov	x19, x0
    ad38:      	bl	0xad64 <JNI_OnLoad+0x1c08>
    ad3c:      	mov	x0, x19
    ad40:      	bl	0xaebc <JNI_OnLoad+0x1d60>
    ad44:      	cbz	w0, 0xad54 <JNI_OnLoad+0x1bf8>
    ad48:      	ldr	x19, [sp, #0x10]
    ad4c:      	ldp	x29, x30, [sp], #0x20
    ad50:      	ret
    ad54:      	mov	x0, x19
    ad58:      	ldr	x19, [sp, #0x10]
    ad5c:      	ldp	x29, x30, [sp], #0x20
    ad60:      	b	0xaf10 <JNI_OnLoad+0x1db4>
    ad64:      	sub	sp, sp, #0xa0
    ad68:      	stp	x29, x30, [sp, #0x90]
    ad6c:      	add	x29, sp, #0x90
    ad70:      	mrs	x8, TPIDR_EL0
    ad74:      	ldr	x9, [x8, #0x28]
    ad78:      	stur	x9, [x29, #-0x8]
    ad7c:      	adrp	x9, 0x11000 <siglongjmp@plt+0x3870>
    ad80:      	ldr	x9, [x9, #0xaa8]
    ad84:      	ldr	w10, [x9]
    ad88:      	cmp	w10, #0x4
    ad8c:      	b.ls	0xadac <JNI_OnLoad+0x1c50>
    ad90:      	ldr	x8, [x8, #0x28]
    ad94:      	ldur	x9, [x29, #-0x8]
    ad98:      	cmp	x8, x9
    ad9c:      	b.ne	0xaeb8 <JNI_OnLoad+0x1d5c>
    ada0:      	ldp	x29, x30, [sp, #0x90]
    ada4:      	add	sp, sp, #0xa0
    ada8:      	ret
    adac:      	ldp	w11, w12, [x0]
    adb0:      	ldr	x14, [x0, #0x30]
    adb4:      	adrp	x10, 0x2000
    adb8:      	adrp	x13, 0x2000
    adbc:      	add	x10, x10, #0x78d
    adc0:      	add	x13, x13, #0xa35
    adc4:      	cmp	w12, #0x3
    adc8:      	adrp	x12, 0x2000
    adcc:      	add	x12, x12, #0x6e2
    add0:      	csel	x3, x13, x10, eq
    add4:      	cmp	x14, #0x0
    add8:      	adrp	x10, 0x2000
    addc:      	csel	x6, x12, x14, eq
    ade0:      	adrp	x12, 0x2000
    ade4:      	add	x10, x10, #0x77d
    ade8:      	add	x12, x12, #0x9b7
    adec:      	cmp	w11, #0x2
    adf0:      	csel	x12, x12, x10, eq
    adf4:      	adrp	x10, 0x2000
    adf8:      	add	x10, x10, #0xc0b
    adfc:      	cmp	w11, #0x0
    ae00:      	csel	x4, x10, x12, eq
    ae04:      	tbnz	w2, #0x1f, 0xae24 <JNI_OnLoad+0x1cc8>
    ae08:      	mov	x5, x1
    ae0c:      	cbz	w2, 0xae34 <JNI_OnLoad+0x1cd8>
    ae10:      	cmp	w2, #0xd
    ae14:      	b.ne	0xae40 <JNI_OnLoad+0x1ce4>
    ae18:      	adrp	x10, 0x2000
    ae1c:      	add	x10, x10, #0x873
    ae20:      	b	0xae78 <JNI_OnLoad+0x1d1c>
    ae24:      	adrp	x10, 0x2000
    ae28:      	add	x10, x10, #0x9f2
    ae2c:      	mov	x5, x12
    ae30:      	b	0xae78 <JNI_OnLoad+0x1d1c>
    ae34:      	adrp	x10, 0x2000
    ae38:      	add	x10, x10, #0x922
    ae3c:      	b	0xae78 <JNI_OnLoad+0x1d1c>
    ae40:      	stp	x4, x0, [sp, #0x30]
    ae44:      	add	x0, sp, #0x48
    ae48:      	mov	w4, w2
    ae4c:      	stp	x3, x5, [sp, #0x20]
    ae50:      	str	x6, [sp, #0x18]
    ae54:      	str	x8, [sp, #0x40]
    ae58:      	bl	0xb1ac <JNI_OnLoad+0x2050>
    ae5c:      	adrp	x9, 0x11000 <siglongjmp@plt+0x3870>
    ae60:      	ldr	x9, [x9, #0xaa8]
    ae64:      	ldp	x0, x8, [sp, #0x38]
    ae68:      	ldp	x5, x4, [sp, #0x28]
    ae6c:      	ldp	x6, x3, [sp, #0x18]
    ae70:      	add	x10, sp, #0x48
    ae74:      	ldr	w11, [x0]
    ae78:      	cbnz	w11, 0xae80 <JNI_OnLoad+0x1d24>
    ae7c:      	ldr	x5, [x0, #0x10]
    ae80:      	ldr	w9, [x9]
    ae84:      	cmp	w9, #0x4
    ae88:      	b.hi	0xad90 <JNI_OnLoad+0x1c34>
    ae8c:      	ldp	x7, x9, [x0, #0x40]
    ae90:      	adrp	x1, 0x2000
    ae94:      	adrp	x2, 0x2000
    ae98:      	add	x1, x1, #0x94c
    ae9c:      	add	x2, x2, #0xca4
    aea0:      	mov	w0, #0x4                // =4
    aea4:      	stp	x9, x10, [sp]
    aea8:      	str	x8, [sp, #0x40]
    aeac:      	bl	0xd3a0 <__android_log_print@plt>
    aeb0:      	ldr	x8, [sp, #0x40]
    aeb4:      	b	0xad90 <JNI_OnLoad+0x1c34>
    aeb8:      	bl	0xd2e0 <__stack_chk_fail@plt>
    aebc:      	stp	x29, x30, [sp, #-0x20]!
    aec0:      	str	x19, [sp, #0x10]
    aec4:      	mov	x29, sp
    aec8:      	ldr	w8, [x0, #0x4]
    aecc:      	cmp	w8, #0x1
    aed0:      	b.ne	0xaedc <JNI_OnLoad+0x1d80>
    aed4:      	mov	w0, #-0x1               // =-1
    aed8:      	b	0xaf04 <JNI_OnLoad+0x1da8>
    aedc:      	mov	x19, x0
    aee0:      	ldr	x0, [x0, #0x30]
    aee4:      	cbz	x0, 0xaf00 <JNI_OnLoad+0x1da4>
    aee8:      	ldr	x8, [x19, #0x38]
    aeec:      	cbnz	x8, 0xaf00 <JNI_OnLoad+0x1da4>
    aef0:      	ldr	x1, [x19, #0x40]
    aef4:      	bl	0x7c00 <.text+0x2614>
    aef8:      	str	x0, [x19, #0x38]
    aefc:      	cbz	x0, 0xaed4 <JNI_OnLoad+0x1d78>
    af00:      	mov	w0, wzr
    af04:      	ldr	x19, [sp, #0x10]
    af08:      	ldp	x29, x30, [sp], #0x20
    af0c:      	ret
    af10:      	stp	x29, x30, [sp, #-0x20]!
    af14:      	stp	x20, x19, [sp, #0x10]
    af18:      	mov	x29, sp
    af1c:      	ldr	w8, [x0]
    af20:      	mov	x19, x0
    af24:      	sub	w9, w8, #0x1
    af28:      	cmp	w9, #0x2
    af2c:      	b.hs	0xaf48 <JNI_OnLoad+0x1dec>
    af30:      	mov	x1, x19
    af34:      	ldp	x20, x19, [sp, #0x10]
    af38:      	adrp	x0, 0xb000 <JNI_OnLoad+0x1ea4>
    af3c:      	add	x0, x0, #0x248
    af40:      	ldp	x29, x30, [sp], #0x20
    af44:      	b	0x7ae4 <.text+0x24f8>
    af48:      	cbnz	w8, 0xaf78 <JNI_OnLoad+0x1e1c>
    af4c:      	ldr	x0, [x19, #0x10]
    af50:      	bl	0x7b90 <.text+0x25a4>
    af54:      	cbz	x0, 0xaf78 <JNI_OnLoad+0x1e1c>
    af58:      	mov	x20, x0
    af5c:      	mov	x0, x19
    af60:      	mov	x1, x20
    af64:      	bl	0xafc0 <JNI_OnLoad+0x1e64>
    af68:      	mov	x0, x20
    af6c:      	ldp	x20, x19, [sp, #0x10]
    af70:      	ldp	x29, x30, [sp], #0x20
    af74:      	b	0x6cb8 <.text+0x16cc>
    af78:      	ldp	x20, x19, [sp, #0x10]
    af7c:      	ldp	x29, x30, [sp], #0x20
    af80:      	ret
    af84:      	stp	x29, x30, [sp, #-0x20]!
    af88:      	stp	x20, x19, [sp, #0x10]
    af8c:      	mov	x29, sp
    af90:      	mov	x19, x1
    af94:      	mov	x20, x0
    af98:      	bl	0xaebc <JNI_OnLoad+0x1d60>
    af9c:      	cbz	w0, 0xafac <JNI_OnLoad+0x1e50>
    afa0:      	ldp	x20, x19, [sp, #0x10]
    afa4:      	ldp	x29, x30, [sp], #0x20
    afa8:      	ret
    afac:      	mov	x0, x20
    afb0:      	mov	x1, x19
    afb4:      	ldp	x20, x19, [sp, #0x10]
    afb8:      	ldp	x29, x30, [sp], #0x20
    afbc:      	b	0xafc0 <JNI_OnLoad+0x1e64>
    afc0:      	stp	x29, x30, [sp, #-0x30]!
    afc4:      	str	x21, [sp, #0x10]
    afc8:      	stp	x20, x19, [sp, #0x20]
    afcc:      	mov	x29, sp
    afd0:      	ldp	w9, w8, [x0]
    afd4:      	adrp	x10, 0x11000 <siglongjmp@plt+0x3870>
    afd8:      	adrp	x11, 0x11000 <siglongjmp@plt+0x3870>
    afdc:      	ldr	x10, [x10, #0xad8]
    afe0:      	ldr	x11, [x11, #0xae0]
    afe4:      	cmp	w8, #0x3
    afe8:      	mov	x19, x0
    afec:      	mov	x20, x1
    aff0:      	csel	x21, x11, x10, eq
    aff4:      	cmp	w9, #0x2
    aff8:      	b.eq	0xb030 <JNI_OnLoad+0x1ed4>
    affc:      	cmp	w9, #0x1
    b000:      	b.eq	0xb040 <JNI_OnLoad+0x1ee4>
    b004:      	cbnz	w9, 0xb048 <JNI_OnLoad+0x1eec>
    b008:      	ldr	x1, [x19, #0x10]
    b00c:      	mov	x0, x20
    b010:      	bl	0x6d50 <.text+0x1764>
    b014:      	tbz	w0, #0x0, 0xb044 <JNI_OnLoad+0x1ee8>
    b018:      	bl	0xb264 <JNI_OnLoad+0x2108>
    b01c:      	ldr	w8, [x19, #0x4]
    b020:      	cmp	w8, #0x3
    b024:      	b.ne	0xb058 <JNI_OnLoad+0x1efc>
    b028:      	mov	w8, wzr
    b02c:      	b	0xb048 <JNI_OnLoad+0x1eec>
    b030:      	ldr	x0, [x20, #0xa0]
    b034:      	ldp	x8, x1, [x19, #0x20]
    b038:      	blr	x8
    b03c:      	tbz	w0, #0x0, 0xb044 <JNI_OnLoad+0x1ee8>
    b040:      	bl	0xb264 <JNI_OnLoad+0x2108>
    b044:      	mov	w8, #0x1                // =1
    b048:      	bl	0xb258 <JNI_OnLoad+0x20fc>
    b04c:      	and	w0, w8, #0x1
    b050:      	ldp	x29, x30, [sp], #0x30
    b054:      	ret
    b058:      	ldr	x9, [x20, #0xa8]
    b05c:      	mov	w10, #0x1               // =1
    b060:      	mov	w8, wzr
    b064:      	str	w10, [x19, #0x4]
    b068:      	str	x9, [x19, #0x18]
    b06c:      	b	0xb048 <JNI_OnLoad+0x1eec>
    b070:      	stp	x29, x30, [sp, #-0x20]!
    b074:      	str	x19, [sp, #0x10]
    b078:      	mov	x29, sp
    b07c:      	mov	w8, #0x3                // =3
    b080:      	mov	w2, #-0x1               // =-1
    b084:      	mov	x1, xzr
    b088:      	mov	x19, x0
    b08c:      	str	w8, [x0, #0x4]
    b090:      	bl	0xad64 <JNI_OnLoad+0x1c08>
    b094:      	mov	x0, x19
    b098:      	bl	0xaf10 <JNI_OnLoad+0x1db4>
    b09c:      	ldr	x19, [sp, #0x10]
    b0a0:      	mov	w0, wzr
    b0a4:      	ldp	x29, x30, [sp], #0x20
    b0a8:      	ret
    b0ac:      	stp	x29, x30, [sp, #-0x30]!
    b0b0:      	str	x21, [sp, #0x10]
    b0b4:      	stp	x20, x19, [sp, #0x20]
    b0b8:      	mov	x29, sp
    b0bc:      	ldr	w8, [x0]
    b0c0:      	mov	x5, x3
    b0c4:      	mov	x19, x2
    b0c8:      	mov	x21, x0
    b0cc:      	mov	w20, w1
    b0d0:      	cbz	w8, 0xb0ec <JNI_OnLoad+0x1f90>
    b0d4:      	cmp	w20, #0xd
    b0d8:      	ccmp	w20, #0x15, #0x4, ne
    b0dc:      	b.ne	0xb104 <JNI_OnLoad+0x1fa8>
    b0e0:      	bl	0xb258 <JNI_OnLoad+0x20fc>
    b0e4:      	ldp	x29, x30, [sp], #0x30
    b0e8:      	ret
    b0ec:      	cbnz	x19, 0xb0f4 <JNI_OnLoad+0x1f98>
    b0f0:      	ldr	x19, [x21, #0x10]
    b0f4:      	ldr	w8, [x21, #0x4]
    b0f8:      	cmp	w8, #0x3
    b0fc:      	b.eq	0xb104 <JNI_OnLoad+0x1fa8>
    b100:      	str	w20, [x21, #0x8]
    b104:      	ldr	x8, [x21, #0x50]
    b108:      	cbz	x8, 0xb130 <JNI_OnLoad+0x1fd4>
    b10c:      	ldr	w9, [x21, #0x4]
    b110:      	cmp	w9, #0x3
    b114:      	b.eq	0xb130 <JNI_OnLoad+0x1fd4>
    b118:      	ldp	x3, x4, [x21, #0x40]
    b11c:      	ldr	x6, [x21, #0x58]
    b120:      	mov	x0, x21
    b124:      	mov	w1, w20
    b128:      	mov	x2, x19
    b12c:      	blr	x8
    b130:      	mov	x0, x21
    b134:      	mov	x1, x19
    b138:      	mov	w2, w20
    b13c:      	bl	0xb258 <JNI_OnLoad+0x20fc>
    b140:      	ldp	x29, x30, [sp], #0x30
    b144:      	b	0xad64 <JNI_OnLoad+0x1c08>
    b148:      	stp	x29, x30, [sp, #-0x30]!
    b14c:      	str	x21, [sp, #0x10]
    b150:      	stp	x20, x19, [sp, #0x20]
    b154:      	mov	x29, sp
    b158:      	cbz	x0, 0xb1a0 <JNI_OnLoad+0x2044>
    b15c:      	ldr	x8, [x0, #0x50]
    b160:      	mov	x21, x0
    b164:      	cbz	x8, 0xb1a0 <JNI_OnLoad+0x2044>
    b168:      	mov	x19, x2
    b16c:      	mov	x20, x1
    b170:      	bl	0xd3d0 <bytehook_get_mode@plt>
    b174:      	cmp	w0, #0x1
    b178:      	b.ne	0xb1a0 <JNI_OnLoad+0x2044>
    b17c:      	ldp	x3, x4, [x21, #0x40]
    b180:      	ldp	x7, x6, [x21, #0x50]
    b184:      	mov	x0, x21
    b188:      	mov	x2, x20
    b18c:      	mov	x5, x19
    b190:      	bl	0xb258 <JNI_OnLoad+0x20fc>
    b194:      	mov	w1, #0x17               // =23
    b198:      	ldp	x29, x30, [sp], #0x30
    b19c:      	br	x7
    b1a0:      	bl	0xb258 <JNI_OnLoad+0x20fc>
    b1a4:      	ldp	x29, x30, [sp], #0x30
    b1a8:      	ret
    b1ac:      	sub	sp, sp, #0x110
    b1b0:      	stp	x29, x30, [sp, #0xf0]
    b1b4:      	stp	x28, x19, [sp, #0x100]
    b1b8:      	add	x29, sp, #0xf0
    b1bc:      	stp	x4, x5, [x29, #-0x70]
    b1c0:      	stp	x6, x7, [x29, #-0x60]
    b1c4:      	stp	q0, q1, [sp]
    b1c8:      	stp	q2, q3, [sp, #0x20]
    b1cc:      	stp	q4, q5, [sp, #0x40]
    b1d0:      	stp	q6, q7, [sp, #0x60]
    b1d4:      	mrs	x19, TPIDR_EL0
    b1d8:      	ldr	x9, [x19, #0x28]
    b1dc:      	mov	x10, #-0x20             // =-32
    b1e0:      	mov	x11, sp
    b1e4:      	sub	x12, x29, #0x70
    b1e8:      	movk	x10, #0xff80, lsl #32
    b1ec:      	stur	x9, [x29, #-0x8]
    b1f0:      	add	x9, x29, #0x20
    b1f4:      	add	x11, x11, #0x80
    b1f8:      	add	x12, x12, #0x20
    b1fc:      	sub	x8, x29, #0x28
    b200:      	stp	x11, x10, [x29, #-0x18]
    b204:      	stp	x9, x12, [x29, #-0x28]
    b208:      	ldp	q0, q1, [x8]
    b20c:      	adrp	x2, 0x2000
    b210:      	add	x2, x2, #0x9f6
    b214:      	sub	x3, x29, #0x50
    b218:      	mov	w1, #0x40               // =64
    b21c:      	stp	q0, q1, [x29, #-0x50]
    b220:      	bl	0xd620 <vsnprintf@plt>
    b224:      	ldr	x8, [x19, #0x28]
    b228:      	ldur	x9, [x29, #-0x8]
    b22c:      	cmp	x8, x9
    b230:      	b.ne	0xb244 <JNI_OnLoad+0x20e8>
    b234:      	ldp	x28, x19, [sp, #0x100]
    b238:      	ldp	x29, x30, [sp, #0xf0]
    b23c:      	add	sp, sp, #0x110
    b240:      	ret
    b244:      	bl	0xd2e0 <__stack_chk_fail@plt>
    b248:      	mov	x8, x0
    b24c:      	mov	x0, x1
    b250:      	mov	x1, x8
    b254:      	b	0xafc0 <JNI_OnLoad+0x1e64>
    b258:      	ldp	x20, x19, [sp, #0x20]
    b25c:      	ldr	x21, [sp, #0x10]
    b260:      	ret
    b264:      	mov	x0, x20
    b268:      	mov	x1, x19
    b26c:      	br	x21
    b270:      	stp	x29, x30, [sp, #-0x20]!
    b274:      	stp	x20, x19, [sp, #0x10]
    b278:      	mov	x29, sp
    b27c:      	adrp	x20, 0x16000
    b280:      	add	x20, x20, #0xc0
    b284:      	mov	x19, x0
    b288:      	mov	x0, x20
    b28c:      	bl	0xd470 <pthread_rwlock_wrlock@plt>
    b290:      	mov	x8, x19
    b294:      	adrp	x9, 0x15000
    b298:      	str	xzr, [x8, #0x60]!
    b29c:      	ldr	x10, [x9, #0xe18]
    b2a0:      	mov	x0, x20
    b2a4:      	str	x10, [x19, #0x68]
    b2a8:      	str	x19, [x10]
    b2ac:      	ldp	x20, x19, [sp, #0x10]
    b2b0:      	str	x8, [x9, #0xe18]
    b2b4:      	ldp	x29, x30, [sp], #0x20
    b2b8:      	b	0xd3f0 <pthread_rwlock_unlock@plt>
    b2bc:      	stp	x29, x30, [sp, #-0x20]!
    b2c0:      	str	x19, [sp, #0x10]
    b2c4:      	mov	x29, sp
    b2c8:      	mov	x19, x0
    b2cc:      	adrp	x0, 0x16000
    b2d0:      	add	x0, x0, #0xc0
    b2d4:      	bl	0xd470 <pthread_rwlock_wrlock@plt>
    b2d8:      	ldp	x8, x9, [x19, #0x60]
    b2dc:      	cbz	x8, 0xb2ec <JNI_OnLoad+0x2190>
    b2e0:      	str	x9, [x8, #0x68]
    b2e4:      	ldr	x9, [x19, #0x68]
    b2e8:      	b	0xb2f4 <JNI_OnLoad+0x2198>
    b2ec:      	adrp	x10, 0x15000
    b2f0:      	str	x9, [x10, #0xe18]
    b2f4:      	ldr	x19, [sp, #0x10]
    b2f8:      	adrp	x0, 0x16000
    b2fc:      	add	x0, x0, #0xc0
    b300:      	str	x8, [x9]
    b304:      	ldp	x29, x30, [sp], #0x20
    b308:      	b	0xd3f0 <pthread_rwlock_unlock@plt>
    b30c:      	stp	x29, x30, [sp, #-0x30]!
    b310:      	stp	x22, x21, [sp, #0x10]
    b314:      	stp	x20, x19, [sp, #0x20]
    b318:      	mov	x29, sp
    b31c:      	mov	x19, x0
    b320:      	bl	0x94dc <JNI_OnLoad+0x380>
    b324:      	tbz	w0, #0x0, 0xb3a8 <JNI_OnLoad+0x224c>
    b328:      	adrp	x21, 0x16000
    b32c:      	ldrb	w8, [x21, #0xf8]
    b330:      	adrp	x20, 0x16000
    b334:      	tbnz	w8, #0x0, 0xb3a0 <JNI_OnLoad+0x2244>
    b338:      	adrp	x22, 0x16000
    b33c:      	add	x22, x22, #0xf8
    b340:      	add	x0, x22, #0x4
    b344:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    b348:      	ldrb	w8, [x22]
    b34c:      	tbnz	w8, #0x0, 0xb394 <JNI_OnLoad+0x2238>
    b350:      	mov	w8, #0x1                // =1
    b354:      	strb	w8, [x21, #0xf8]
    b358:      	bl	0x7c40 <.text+0x2654>
    b35c:      	adrp	x0, 0xb000 <JNI_OnLoad+0x1ea4>
    b360:      	add	x0, x0, #0x3e0
    b364:      	mov	x1, xzr
    b368:      	mov	x2, xzr
    b36c:      	bl	0xd630 <shadowhook_register_dl_init_callback@plt>
    b370:      	cbnz	w0, 0xb394 <JNI_OnLoad+0x2238>
    b374:      	adrp	x1, 0xb000 <JNI_OnLoad+0x1ea4>
    b378:      	add	x1, x1, #0x4b0
    b37c:      	mov	x0, xzr
    b380:      	mov	x2, xzr
    b384:      	bl	0xd640 <shadowhook_register_dl_fini_callback@plt>
    b388:      	cbnz	w0, 0xb394 <JNI_OnLoad+0x2238>
    b38c:      	mov	w8, #0x1                // =1
    b390:      	strb	w8, [x20, #0xf9]
    b394:      	adrp	x0, 0x16000
    b398:      	add	x0, x0, #0xfc
    b39c:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    b3a0:      	ldrb	w8, [x20, #0xf9]
    b3a4:      	tbz	w8, #0x0, 0xb3bc <JNI_OnLoad+0x2260>
    b3a8:      	mov	x0, x19
    b3ac:      	ldp	x20, x19, [sp, #0x20]
    b3b0:      	ldp	x22, x21, [sp, #0x10]
    b3b4:      	ldp	x29, x30, [sp], #0x30
    b3b8:      	b	0xad20 <JNI_OnLoad+0x1bc4>
    b3bc:      	mov	x0, x19
    b3c0:      	ldp	x20, x19, [sp, #0x20]
    b3c4:      	ldp	x22, x21, [sp, #0x10]
    b3c8:      	mov	w1, #0xa                // =10
    b3cc:      	mov	x2, xzr
    b3d0:      	mov	x3, xzr
    b3d4:      	ldp	x29, x30, [sp], #0x30
    b3d8:      	b	0xb0ac <JNI_OnLoad+0x1f50>
    b3dc:      	b	0xb070 <JNI_OnLoad+0x1f14>
    b3e0:      	stp	x29, x30, [sp, #-0x20]!
    b3e4:      	stp	x20, x19, [sp, #0x10]
    b3e8:      	mov	x29, sp
    b3ec:      	adrp	x20, 0x11000 <siglongjmp@plt+0x3870>
    b3f0:      	ldr	x20, [x20, #0xaa8]
    b3f4:      	mov	x19, x0
    b3f8:      	ldr	w8, [x20]
    b3fc:      	cmp	w8, #0x4
    b400:      	b.ls	0xb470 <JNI_OnLoad+0x2314>
    b404:      	mov	x0, x19
    b408:      	bl	0x7c6c <.text+0x2680>
    b40c:      	cbz	x0, 0xb464 <JNI_OnLoad+0x2308>
    b410:      	ldr	w8, [x20]
    b414:      	mov	x19, x0
    b418:      	cmp	w8, #0x4
    b41c:      	b.ls	0xb490 <JNI_OnLoad+0x2334>
    b420:      	bl	0xb5b8 <JNI_OnLoad+0x245c>
    b424:      	adrp	x8, 0x15000
    b428:      	add	x8, x8, #0xe10
    b42c:      	ldr	x20, [x8]
    b430:      	cbz	x20, 0xb448 <JNI_OnLoad+0x22ec>
    b434:      	mov	x0, x20
    b438:      	mov	x1, x19
    b43c:      	bl	0xaf84 <JNI_OnLoad+0x1e28>
    b440:      	add	x8, x20, #0x60
    b444:      	b	0xb42c <JNI_OnLoad+0x22d0>
    b448:      	adrp	x0, 0x16000
    b44c:      	add	x0, x0, #0xc0
    b450:      	bl	0xd3f0 <pthread_rwlock_unlock@plt>
    b454:      	mov	x0, x19
    b458:      	ldp	x20, x19, [sp, #0x10]
    b45c:      	ldp	x29, x30, [sp], #0x20
    b460:      	b	0x6cb8 <.text+0x16cc>
    b464:      	ldp	x20, x19, [sp, #0x10]
    b468:      	ldp	x29, x30, [sp], #0x20
    b46c:      	ret
    b470:      	ldp	x3, x4, [x19]
    b474:      	adrp	x1, 0x2000
    b478:      	adrp	x2, 0x2000
    b47c:      	add	x1, x1, #0x94c
    b480:      	add	x2, x2, #0xcc7
    b484:      	mov	w0, #0x4                // =4
    b488:      	bl	0xd3a0 <__android_log_print@plt>
    b48c:      	b	0xb404 <JNI_OnLoad+0x22a8>
    b490:      	ldr	x3, [x19, #0xa0]
    b494:      	adrp	x1, 0x2000
    b498:      	adrp	x2, 0x2000
    b49c:      	add	x1, x1, #0x94c
    b4a0:      	add	x2, x2, #0x926
    b4a4:      	mov	w0, #0x4                // =4
    b4a8:      	bl	0xd3a0 <__android_log_print@plt>
    b4ac:      	b	0xb420 <JNI_OnLoad+0x22c4>
    b4b0:      	str	d8, [sp, #-0x40]!
    b4b4:      	stp	x29, x30, [sp, #0x8]
    b4b8:      	str	x23, [sp, #0x18]
    b4bc:      	stp	x22, x21, [sp, #0x20]
    b4c0:      	stp	x20, x19, [sp, #0x30]
    b4c4:      	add	x29, sp, #0x8
    b4c8:      	adrp	x22, 0x11000 <siglongjmp@plt+0x3870>
    b4cc:      	ldr	x22, [x22, #0xaa8]
    b4d0:      	mov	x19, x0
    b4d4:      	ldr	w8, [x22]
    b4d8:      	cmp	w8, #0x4
    b4dc:      	b.ls	0xb598 <JNI_OnLoad+0x243c>
    b4e0:      	mov	x0, x19
    b4e4:      	bl	0x7d70 <.text+0x2784>
    b4e8:      	bl	0xb5b8 <JNI_OnLoad+0x245c>
    b4ec:      	adrp	x8, 0x15000
    b4f0:      	adrp	x20, 0x2000
    b4f4:      	adrp	x21, 0x2000
    b4f8:      	add	x8, x8, #0xe10
    b4fc:      	movi	d8, #0x0000ff00000000
    b500:      	add	x20, x20, #0x94c
    b504:      	add	x21, x21, #0x549
    b508:      	ldr	x23, [x8]
    b50c:      	cbz	x23, 0xb578 <JNI_OnLoad+0x241c>
    b510:      	ldr	w8, [x23]
    b514:      	cbnz	w8, 0xb52c <JNI_OnLoad+0x23d0>
    b518:      	ldr	w8, [x23, #0x4]
    b51c:      	cmp	w8, #0x1
    b520:      	b.ne	0xb52c <JNI_OnLoad+0x23d0>
    b524:      	ldrb	w8, [x23, #0xc]
    b528:      	cbz	w8, 0xb534 <JNI_OnLoad+0x23d8>
    b52c:      	add	x8, x23, #0x60
    b530:      	b	0xb508 <JNI_OnLoad+0x23ac>
    b534:      	ldr	x8, [x23, #0x18]
    b538:      	cbz	x8, 0xb52c <JNI_OnLoad+0x23d0>
    b53c:      	ldr	x9, [x19]
    b540:      	cmp	x9, x8
    b544:      	b.ne	0xb52c <JNI_OnLoad+0x23d0>
    b548:      	str	xzr, [x23, #0x18]
    b54c:      	stur	d8, [x23, #0x4]
    b550:      	ldr	w8, [x22]
    b554:      	cmp	w8, #0x4
    b558:      	b.hi	0xb52c <JNI_OnLoad+0x23d0>
    b55c:      	ldr	x3, [x23, #0x10]
    b560:      	ldr	x4, [x23, #0x40]
    b564:      	mov	w0, #0x4                // =4
    b568:      	mov	x1, x20
    b56c:      	mov	x2, x21
    b570:      	bl	0xd3a0 <__android_log_print@plt>
    b574:      	b	0xb52c <JNI_OnLoad+0x23d0>
    b578:      	ldp	x20, x19, [sp, #0x30]
    b57c:      	ldp	x22, x21, [sp, #0x20]
    b580:      	ldr	x23, [sp, #0x18]
    b584:      	ldp	x29, x30, [sp, #0x8]
    b588:      	adrp	x0, 0x16000
    b58c:      	add	x0, x0, #0xc0
    b590:      	ldr	d8, [sp], #0x40
    b594:      	b	0xd3f0 <pthread_rwlock_unlock@plt>
    b598:      	ldp	x3, x4, [x19]
    b59c:      	adrp	x1, 0x2000
    b5a0:      	adrp	x2, 0x2000
    b5a4:      	add	x1, x1, #0x94c
    b5a8:      	add	x2, x2, #0x883
    b5ac:      	mov	w0, #0x4                // =4
    b5b0:      	bl	0xd3a0 <__android_log_print@plt>
    b5b4:      	b	0xb4e0 <JNI_OnLoad+0x2384>
    b5b8:      	adrp	x0, 0x16000
    b5bc:      	add	x0, x0, #0xc0
    b5c0:      	b	0xd430 <pthread_rwlock_rdlock@plt>
    b5c4:      	stp	x29, x30, [sp, #-0x30]!
    b5c8:      	stp	x22, x21, [sp, #0x10]
    b5cc:      	stp	x20, x19, [sp, #0x20]
    b5d0:      	mov	x29, sp
    b5d4:      	mov	x21, x1
    b5d8:      	mov	x22, x0
    b5dc:      	str	xzr, [x0], #0x8
    b5e0:      	mov	x1, xzr
    b5e4:      	mov	x19, x3
    b5e8:      	mov	x20, x2
    b5ec:      	bl	0xd490 <pthread_mutex_init@plt>
    b5f0:      	add	x8, x20, #0x3
    b5f4:      	and	x8, x8, #0xfffffffffffffffc
    b5f8:      	stp	x21, x8, [x22, #0x30]
    b5fc:      	str	x19, [x22, #0x40]
    b600:      	ldp	x20, x19, [sp, #0x20]
    b604:      	ldp	x22, x21, [sp, #0x10]
    b608:      	ldp	x29, x30, [sp], #0x30
    b60c:      	ret
    b610:      	sub	sp, sp, #0x70
    b614:      	stp	x29, x30, [sp, #0x20]
    b618:      	stp	x26, x25, [sp, #0x30]
    b61c:      	stp	x24, x23, [sp, #0x40]
    b620:      	stp	x22, x21, [sp, #0x50]
    b624:      	stp	x20, x19, [sp, #0x60]
    b628:      	add	x29, sp, #0x20
    b62c:      	mrs	x25, TPIDR_EL0
    b630:      	ldr	x8, [x25, #0x28]
    b634:      	mov	x20, x0
    b638:      	stur	x8, [x29, #-0x8]
    b63c:      	bl	0xb968 <JNI_OnLoad+0x280c>
    b640:      	ldp	x21, x8, [x20, #0x38]
    b644:      	mov	x19, x0
    b648:      	cmp	x8, #0x1
    b64c:      	b.lt	0xb65c <JNI_OnLoad+0x2500>
    b650:      	bl	0xb93c <JNI_OnLoad+0x27e0>
    b654:      	ldr	x22, [sp, #0x8]
    b658:      	b	0xb65c <JNI_OnLoad+0x2500>
    b65c:      	udiv	x26, x19, x21
    b660:      	add	x21, x20, #0x8
    b664:      	mov	x0, x21
    b668:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    b66c:      	mov	w8, #0x1                // =1
    b670:      	mov	x9, x20
    b674:      	ldr	x9, [x9]
    b678:      	cbz	x9, 0xb750 <JNI_OnLoad+0x25f4>
    b67c:      	mov	x10, xzr
    b680:      	cmp	x10, x26
    b684:      	b.eq	0xb6c8 <JNI_OnLoad+0x256c>
    b688:      	ldr	x11, [x9, #0x8]
    b68c:      	lsr	x12, x10, #5
    b690:      	lsl	w14, w8, w10
    b694:      	ldr	w13, [x11, x12, lsl #2]
    b698:      	tst	w13, w14
    b69c:      	b.ne	0xb6c0 <JNI_OnLoad+0x2564>
    b6a0:      	ldr	x15, [x20, #0x40]
    b6a4:      	cmp	x15, #0x1
    b6a8:      	b.lt	0xb6d0 <JNI_OnLoad+0x2574>
    b6ac:      	ldr	x16, [x9, #0x10]
    b6b0:      	ldr	x16, [x16, x10, lsl #3]
    b6b4:      	subs	x16, x22, x16
    b6b8:      	ccmp	x16, x15, #0x4, gt
    b6bc:      	b.gt	0xb6d0 <JNI_OnLoad+0x2574>
    b6c0:      	add	x10, x10, #0x1
    b6c4:      	b	0xb680 <JNI_OnLoad+0x2524>
    b6c8:      	add	x9, x9, #0x18
    b6cc:      	b	0xb674 <JNI_OnLoad+0x2518>
    b6d0:      	orr	w8, w13, w14
    b6d4:      	str	w8, [x11, x12, lsl #2]
    b6d8:      	ldr	x8, [x9]
    b6dc:      	ldr	x2, [x20, #0x38]
    b6e0:      	mov	w1, wzr
    b6e4:      	madd	x23, x2, x10, x8
    b6e8:      	mov	x0, x23
    b6ec:      	bl	0xd650 <memset@plt>
    b6f0:      	mov	x22, #-0x1              // =-1
    b6f4:      	mov	x0, x21
    b6f8:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    b6fc:      	cmn	x22, #0x1
    b700:      	b.eq	0xb720 <JNI_OnLoad+0x25c4>
    b704:      	ldr	x4, [x20, #0x30]
    b708:      	mov	w0, #0x4d41             // =19777
    b70c:      	movk	w0, #0x5356, lsl #16
    b710:      	mov	w1, wzr
    b714:      	mov	x2, x22
    b718:      	mov	x3, x19
    b71c:      	bl	0xd660 <prctl@plt>
    b720:      	ldr	x8, [x25, #0x28]
    b724:      	ldur	x9, [x29, #-0x8]
    b728:      	cmp	x8, x9
    b72c:      	b.ne	0xb85c <JNI_OnLoad+0x2700>
    b730:      	mov	x0, x23
    b734:      	ldp	x20, x19, [sp, #0x60]
    b738:      	ldp	x22, x21, [sp, #0x50]
    b73c:      	ldp	x24, x23, [sp, #0x40]
    b740:      	ldp	x26, x25, [sp, #0x30]
    b744:      	ldp	x29, x30, [sp, #0x20]
    b748:      	add	sp, sp, #0x70
    b74c:      	ret
    b750:      	mov	w2, #0x7                // =7
    b754:      	mov	w3, #0x22               // =34
    b758:      	mov	w4, #-0x1               // =-1
    b75c:      	mov	x0, xzr
    b760:      	mov	x1, x19
    b764:      	mov	x5, xzr
    b768:      	bl	0xd670 <mmap@plt>
    b76c:      	mov	x22, x0
    b770:      	cmn	x0, #0x1
    b774:      	b.eq	0xb800 <JNI_OnLoad+0x26a4>
    b778:      	mov	w0, #0x1                // =1
    b77c:      	mov	w1, #0x20               // =32
    b780:      	bl	0xd300 <calloc@plt>
    b784:      	mov	x23, x0
    b788:      	cbz	x0, 0xb80c <JNI_OnLoad+0x26b0>
    b78c:      	mov	x0, x22
    b790:      	mov	w1, wzr
    b794:      	mov	x2, x19
    b798:      	bl	0xd650 <memset@plt>
    b79c:      	add	x8, x26, #0x1f
    b7a0:      	lsr	x8, x8, #3
    b7a4:      	and	x1, x8, #0x1ffffffffffffffc
    b7a8:      	mov	w0, #0x1                // =1
    b7ac:      	str	x22, [x23]
    b7b0:      	bl	0xd300 <calloc@plt>
    b7b4:      	str	x0, [x23, #0x8]
    b7b8:      	cbz	x0, 0xb808 <JNI_OnLoad+0x26ac>
    b7bc:      	str	xzr, [x23, #0x10]
    b7c0:      	ldr	x8, [x20, #0x40]
    b7c4:      	mov	x24, x0
    b7c8:      	cmp	x8, #0x1
    b7cc:      	b.lt	0xb7e4 <JNI_OnLoad+0x2688>
    b7d0:      	lsl	x1, x26, #3
    b7d4:      	mov	w0, #0x1                // =1
    b7d8:      	bl	0xd300 <calloc@plt>
    b7dc:      	str	x0, [x23, #0x10]
    b7e0:      	cbz	x0, 0xb808 <JNI_OnLoad+0x26ac>
    b7e4:      	ldr	x8, [x20]
    b7e8:      	mov	w9, #0x1                // =1
    b7ec:      	str	x8, [x23, #0x18]
    b7f0:      	str	x23, [x20]
    b7f4:      	mov	x23, x22
    b7f8:      	str	w9, [x24]
    b7fc:      	b	0xb6f4 <JNI_OnLoad+0x2598>
    b800:      	mov	x23, xzr
    b804:      	b	0xb80c <JNI_OnLoad+0x26b0>
    b808:      	mov	x22, #-0x1              // =-1
    b80c:      	mov	x0, x21
    b810:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    b814:      	cbz	x23, 0xb840 <JNI_OnLoad+0x26e4>
    b818:      	ldr	x0, [x23]
    b81c:      	cbz	x0, 0xb828 <JNI_OnLoad+0x26cc>
    b820:      	mov	x1, x19
    b824:      	bl	0xd680 <munmap@plt>
    b828:      	ldr	x0, [x23, #0x8]
    b82c:      	bl	0xd260 <free@plt>
    b830:      	ldr	x0, [x23, #0x10]
    b834:      	bl	0xd260 <free@plt>
    b838:      	mov	x0, x23
    b83c:      	bl	0xd260 <free@plt>
    b840:      	cmn	x22, #0x1
    b844:      	b.eq	0xb854 <JNI_OnLoad+0x26f8>
    b848:      	mov	x0, x22
    b84c:      	mov	x1, x19
    b850:      	bl	0xd680 <munmap@plt>
    b854:      	mov	x23, xzr
    b858:      	b	0xb720 <JNI_OnLoad+0x25c4>
    b85c:      	bl	0xd2e0 <__stack_chk_fail@plt>
    b860:      	sub	sp, sp, #0x50
    b864:      	stp	x29, x30, [sp, #0x20]
    b868:      	stp	x22, x21, [sp, #0x30]
    b86c:      	stp	x20, x19, [sp, #0x40]
    b870:      	add	x29, sp, #0x20
    b874:      	mrs	x22, TPIDR_EL0
    b878:      	ldr	x8, [x22, #0x28]
    b87c:      	mov	x20, x0
    b880:      	mov	x21, x1
    b884:      	stur	x8, [x29, #-0x8]
    b888:      	ldr	x8, [x0, #0x40]
    b88c:      	cmp	x8, #0x1
    b890:      	b.lt	0xb898 <JNI_OnLoad+0x273c>
    b894:      	bl	0xb93c <JNI_OnLoad+0x27e0>
    b898:      	add	x19, x20, #0x8
    b89c:      	mov	x0, x19
    b8a0:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    b8a4:      	bl	0xb968 <JNI_OnLoad+0x280c>
    b8a8:      	mov	x8, x20
    b8ac:      	ldr	x8, [x8]
    b8b0:      	cbz	x8, 0xb90c <JNI_OnLoad+0x27b0>
    b8b4:      	ldr	x9, [x8]
    b8b8:      	add	x10, x9, x0
    b8bc:      	cmp	x9, x21
    b8c0:      	ccmp	x10, x21, #0x0, ls
    b8c4:      	b.hi	0xb8d0 <JNI_OnLoad+0x2774>
    b8c8:      	add	x8, x8, #0x18
    b8cc:      	b	0xb8ac <JNI_OnLoad+0x2750>
    b8d0:      	ldp	x10, x12, [x20, #0x38]
    b8d4:      	sub	x9, x21, x9
    b8d8:      	mov	w13, #0x1               // =1
    b8dc:      	udiv	x11, x9, x10
    b8e0:      	cmp	x12, #0x1
    b8e4:      	lsr	x9, x11, #5
    b8e8:      	lsl	w10, w13, w11
    b8ec:      	b.lt	0xb8fc <JNI_OnLoad+0x27a0>
    b8f0:      	ldr	x12, [sp, #0x8]
    b8f4:      	ldr	x13, [x8, #0x10]
    b8f8:      	str	x12, [x13, x11, lsl #3]
    b8fc:      	ldr	x8, [x8, #0x8]
    b900:      	ldr	w11, [x8, x9, lsl #2]
    b904:      	bic	w10, w11, w10
    b908:      	str	w10, [x8, x9, lsl #2]
    b90c:      	mov	x0, x19
    b910:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    b914:      	ldr	x8, [x22, #0x28]
    b918:      	ldur	x9, [x29, #-0x8]
    b91c:      	cmp	x8, x9
    b920:      	b.ne	0xb938 <JNI_OnLoad+0x27dc>
    b924:      	ldp	x20, x19, [sp, #0x40]
    b928:      	ldp	x22, x21, [sp, #0x30]
    b92c:      	ldp	x29, x30, [sp, #0x20]
    b930:      	add	sp, sp, #0x50
    b934:      	ret
    b938:      	bl	0xd2e0 <__stack_chk_fail@plt>
    b93c:      	add	x0, sp, #0x8
    b940:      	mov	x1, xzr
    b944:      	b	0xd4f0 <gettimeofday@plt>
    b948:      	stp	x29, x30, [sp, #-0x10]!
    b94c:      	mov	x29, sp
    b950:      	bl	0xd690 <getpagesize@plt>
    b954:      	sxtw	x8, w0
    b958:      	adrp	x9, 0x16000
    b95c:      	str	x8, [x9, #0x128]
    b960:      	ldp	x29, x30, [sp], #0x10
    b964:      	ret
    b968:      	adrp	x8, 0x16000
    b96c:      	ldr	x0, [x8, #0x128]
    b970:      	ret
    b974:      	stp	x29, x30, [sp, #-0x10]!
    b978:      	mov	x29, sp
    b97c:      	adrp	x8, 0x16000
    b980:      	ldr	x8, [x8, #0x128]
    b984:      	mov	w2, w1
    b988:      	neg	x9, x8
    b98c:      	add	x8, x0, x8
    b990:      	add	x8, x8, #0x7
    b994:      	bl	0xc67c <JNI_OnLoad+0x3520>
    b998:      	cmp	w0, #0x0
    b99c:      	csetm	w0, ne
    b9a0:      	ldp	x29, x30, [sp], #0x10
    b9a4:      	ret
    b9a8:      	stp	x29, x30, [sp, #-0x10]!
    b9ac:      	mov	x29, sp
    b9b0:      	adrp	x8, 0x16000
    b9b4:      	ldr	x8, [x8, #0x128]
    b9b8:      	neg	x9, x8
    b9bc:      	add	x8, x1, x8
    b9c0:      	sub	x8, x8, #0x1
    b9c4:      	bl	0xc67c <JNI_OnLoad+0x3520>
    b9c8:      	cmp	w0, #0x0
    b9cc:      	csetm	w0, ne
    b9d0:      	ldp	x29, x30, [sp], #0x10
    b9d4:      	ret
    b9d8:      	add	x1, x1, x0
    b9dc:      	b	0xd170 <bytehook_del_dlopen_callback+0x648>
    b9e0:      	ldrb	w9, [x0]
    b9e4:      	ldrb	w8, [x1]
    b9e8:      	cbz	w9, 0xba00 <JNI_OnLoad+0x28a4>
    b9ec:      	cmp	w9, w8
    b9f0:      	b.ne	0xba00 <JNI_OnLoad+0x28a4>
    b9f4:      	add	x0, x0, #0x1
    b9f8:      	add	x1, x1, #0x1
    b9fc:      	b	0xb9e0 <JNI_OnLoad+0x2884>
    ba00:      	cmp	w8, #0x0
    ba04:      	cset	w0, eq
    ba08:      	ret
    ba0c:      	stp	x29, x30, [sp, #-0x30]!
    ba10:      	str	x21, [sp, #0x10]
    ba14:      	stp	x20, x19, [sp, #0x20]
    ba18:      	mov	x29, sp
    ba1c:      	mov	x19, x1
    ba20:      	mov	x20, x0
    ba24:      	bl	0xd5b0 <strlen@plt>
    ba28:      	mov	x21, x0
    ba2c:      	mov	x0, x19
    ba30:      	bl	0xd5b0 <strlen@plt>
    ba34:      	subs	x8, x21, x0
    ba38:      	b.hs	0xba44 <JNI_OnLoad+0x28e8>
    ba3c:      	mov	w0, wzr
    ba40:      	b	0xba58 <JNI_OnLoad+0x28fc>
    ba44:      	add	x0, x20, x8
    ba48:      	mov	x1, x19
    ba4c:      	bl	0xd340 <strcmp@plt>
    ba50:      	cmp	w0, #0x0
    ba54:      	cset	w0, eq
    ba58:      	ldp	x20, x19, [sp, #0x20]
    ba5c:      	ldr	x21, [sp, #0x10]
    ba60:      	ldp	x29, x30, [sp], #0x30
    ba64:      	ret
    ba68:      	sub	sp, sp, #0xc0
    ba6c:      	stp	x29, x30, [sp, #0x90]
    ba70:      	stp	x22, x21, [sp, #0xa0]
    ba74:      	stp	x20, x19, [sp, #0xb0]
    ba78:      	add	x29, sp, #0x90
    ba7c:      	mrs	x21, TPIDR_EL0
    ba80:      	ldr	x8, [x21, #0x28]
    ba84:      	adrp	x22, 0x15000
    ba88:      	add	x22, x22, #0xe20
    ba8c:      	stur	x8, [x29, #-0x8]
    ba90:      	ldar	w0, [x22]
    ba94:      	cmp	w0, #0x0
    ba98:      	b.le	0xbac0 <JNI_OnLoad+0x2964>
    ba9c:      	ldr	x8, [x21, #0x28]
    baa0:      	ldur	x9, [x29, #-0x8]
    baa4:      	cmp	x8, x9
    baa8:      	b.ne	0xbb88 <JNI_OnLoad+0x2a2c>
    baac:      	ldp	x20, x19, [sp, #0xb0]
    bab0:      	ldp	x22, x21, [sp, #0xa0]
    bab4:      	ldp	x29, x30, [sp, #0x90]
    bab8:      	add	sp, sp, #0xc0
    babc:      	ret
    bac0:      	adrp	x0, 0x2000
    bac4:      	movi	v0.2d, #0000000000000000
    bac8:      	add	x0, x0, #0x7d7
    bacc:      	mov	x1, sp
    bad0:      	stur	q0, [sp, #0x4c]
    bad4:      	stp	q0, q0, [sp, #0x30]
    bad8:      	stp	q0, q0, [sp, #0x10]
    badc:      	str	q0, [sp]
    bae0:      	bl	0xd6a0 <__system_property_get@plt>
    bae4:      	cmp	w0, #0x1
    bae8:      	b.lt	0xbafc <JNI_OnLoad+0x29a0>
    baec:      	mov	x0, sp
    baf0:      	bl	0xd6b0 <atoi@plt>
    baf4:      	cmp	w0, #0x1
    baf8:      	b.ge	0xbb74 <JNI_OnLoad+0x2a18>
    bafc:      	adrp	x0, 0x2000
    bb00:      	adrp	x1, 0x2000
    bb04:      	add	x0, x0, #0x391
    bb08:      	add	x1, x1, #0x9bf
    bb0c:      	bl	0xd6c0 <fopen@plt>
    bb10:      	cbz	x0, 0xbb58 <JNI_OnLoad+0x29fc>
    bb14:      	adrp	x20, 0x2000
    bb18:      	mov	x19, x0
    bb1c:      	add	x20, x20, #0x4d9
    bb20:      	mov	x0, sp
    bb24:      	mov	w1, #0x80               // =128
    bb28:      	mov	x2, x19
    bb2c:      	bl	0xd6d0 <fgets@plt>
    bb30:      	cbz	x0, 0xbb60 <JNI_OnLoad+0x2a04>
    bb34:      	mov	x0, sp
    bb38:      	mov	x1, x20
    bb3c:      	bl	0xb9e0 <JNI_OnLoad+0x2884>
    bb40:      	tbz	w0, #0x0, 0xbb20 <JNI_OnLoad+0x29c4>
    bb44:      	mov	x8, sp
    bb48:      	add	x0, x8, #0x15
    bb4c:      	bl	0xd6b0 <atoi@plt>
    bb50:      	mov	w20, w0
    bb54:      	b	0xbb64 <JNI_OnLoad+0x2a08>
    bb58:      	mov	w0, #-0x1               // =-1
    bb5c:      	b	0xbb74 <JNI_OnLoad+0x2a18>
    bb60:      	mov	w20, #-0x1              // =-1
    bb64:      	mov	x0, x19
    bb68:      	bl	0xd6e0 <fclose@plt>
    bb6c:      	cmp	w20, #0x0
    bb70:      	csinv	w0, w20, wzr, gt
    bb74:      	cmp	w0, #0x10
    bb78:      	mov	w8, #0x10               // =16
    bb7c:      	csel	w0, w0, w8, gt
    bb80:      	stlr	w0, [x22]
    bb84:      	b	0xba9c <JNI_OnLoad+0x2940>
    bb88:      	bl	0xd2e0 <__stack_chk_fail@plt>
    bb8c:      	stp	x29, x30, [sp, #-0x30]!
    bb90:      	stp	x22, x21, [sp, #0x10]
    bb94:      	stp	x20, x19, [sp, #0x20]
    bb98:      	mov	x29, sp
    bb9c:      	tbnz	w0, #0x1f, 0xbbfc <JNI_OnLoad+0x2aa0>
    bba0:      	mov	x19, x2
    bba4:      	mov	x20, x1
    bba8:      	mov	w21, w0
    bbac:      	cbz	x19, 0xbbf4 <JNI_OnLoad+0x2a98>
    bbb0:      	bl	0xd370 <__errno@plt>
    bbb4:      	mov	x22, x0
    bbb8:      	str	wzr, [x0]
    bbbc:      	mov	w0, w21
    bbc0:      	mov	x1, x20
    bbc4:      	mov	x2, x19
    bbc8:      	bl	0xd6f0 <write@plt>
    bbcc:      	cmp	x0, #0x0
    bbd0:      	b.gt	0xbbe8 <JNI_OnLoad+0x2a8c>
    bbd4:      	tbz	x0, #0x3f, 0xbbfc <JNI_OnLoad+0x2aa0>
    bbd8:      	ldr	w8, [x22]
    bbdc:      	cmp	w8, #0x4
    bbe0:      	b.ne	0xbbfc <JNI_OnLoad+0x2aa0>
    bbe4:      	mov	x0, xzr
    bbe8:      	sub	x19, x19, x0
    bbec:      	add	x20, x20, x0
    bbf0:      	cbnz	x19, 0xbbb0 <JNI_OnLoad+0x2a54>
    bbf4:      	mov	w0, wzr
    bbf8:      	b	0xbc00 <JNI_OnLoad+0x2aa4>
    bbfc:      	mov	w0, #-0x1               // =-1
    bc00:      	ldp	x20, x19, [sp, #0x20]
    bc04:      	ldp	x22, x21, [sp, #0x10]
    bc08:      	ldp	x29, x30, [sp], #0x30
    bc0c:      	ret
    bc10:      	stp	x29, x30, [sp, #-0x30]!
    bc14:      	stp	x22, x21, [sp, #0x10]
    bc18:      	stp	x20, x19, [sp, #0x20]
    bc1c:      	mov	x29, sp
    bc20:      	cbz	x2, 0xbe68 <JNI_OnLoad+0x2d0c>
    bc24:      	str	x1, [x2, #0x28]
    bc28:      	ldr	x12, [x0]
    bc2c:      	mov	w8, #0x5180             // =20864
    bc30:      	movk	w8, #0x1, lsl #16
    bc34:      	sub	x13, x8, #0x1
    bc38:      	sdiv	x0, x12, x8
    bc3c:      	msub	x12, x0, x8, x12
    bc40:      	add	x12, x12, x1
    bc44:      	bic	x1, x12, x12, asr #63
    bc48:      	add	x1, x1, x13
    bc4c:      	sub	x1, x1, x12
    bc50:      	udiv	x1, x1, x8
    bc54:      	madd	x3, x1, x8, x12
    bc58:      	cmp	x3, x13
    bc5c:      	mov	x14, #-0x5180           // =-20864
    bc60:      	csel	x13, x3, x13, gt
    bc64:      	movk	x14, #0xfffe, lsl #16
    bc68:      	sub	x0, x0, x1
    bc6c:      	udiv	x8, x13, x8
    bc70:      	madd	x1, x8, x14, x3
    bc74:      	add	x8, x0, x8
    bc78:      	mov	w15, #0xe10             // =3600
    bc7c:      	mov	w17, #0x7               // =7
    bc80:      	add	x0, x8, #0x4
    bc84:      	sdiv	x4, x1, x15
    bc88:      	sdiv	x17, x0, x17
    bc8c:      	msub	w1, w4, w15, w1
    bc90:      	sub	w17, w17, w17, lsl #3
    bc94:      	mov	w16, #0x3c              // =60
    bc98:      	add	w17, w0, w17
    bc9c:      	sxth	w0, w1
    bca0:      	sdiv	w0, w0, w16
    bca4:      	msub	w1, w0, w16, w1
    bca8:      	add	w16, w17, #0x7
    bcac:      	cmp	w17, #0x0
    bcb0:      	csel	w3, w16, w17, lt
    bcb4:      	sxth	w17, w0
    bcb8:      	sxth	w0, w1
    bcbc:      	mov	w9, #0x7b2              // =1970
    bcc0:      	mov	w10, #0x16d             // =365
    bcc4:      	mov	x11, #-0x16d            // =-365
    bcc8:      	mov	x12, #-0x4              // =-4
    bccc:      	mov	w13, #0x64              // =100
    bcd0:      	mov	w14, #0x190             // =400
    bcd4:      	mov	w15, #0x4               // =4
    bcd8:      	mov	x16, #-0x8000000000000000 // =-9223372036854775808
    bcdc:      	stp	w17, w4, [x2, #0x4]
    bce0:      	str	w0, [x2]
    bce4:      	mov	x17, #-0x64             // =-100
    bce8:      	mov	x0, #-0x190             // =-400
    bcec:      	str	w3, [x2, #0x18]
    bcf0:      	tbnz	x8, #0x3f, 0xbd28 <JNI_OnLoad+0x2bcc>
    bcf4:      	ands	x1, x9, #0x3
    bcf8:      	b.eq	0xbd04 <JNI_OnLoad+0x2ba8>
    bcfc:      	mov	w3, #0x16d              // =365
    bd00:      	b	0xbd20 <JNI_OnLoad+0x2bc4>
    bd04:      	sdiv	x4, x9, x14
    bd08:      	sdiv	x3, x9, x13
    bd0c:      	msub	x4, x4, x14, x9
    bd10:      	msub	x3, x3, x13, x9
    bd14:      	cmp	x4, #0x0
    bd18:      	ccmp	x3, #0x0, #0x0, ne
    bd1c:      	cinc	x3, x10, ne
    bd20:      	cmp	x8, x3
    bd24:      	b.lt	0xbdc8 <JNI_OnLoad+0x2c6c>
    bd28:      	sub	x3, x9, #0x1
    bd2c:      	sdiv	x1, x8, x10
    bd30:      	sdiv	x20, x3, x14
    bd34:      	add	x4, x1, x9
    bd38:      	msub	x1, x1, x10, x8
    bd3c:      	sdiv	x7, x3, x17
    bd40:      	add	x8, x20, x8
    bd44:      	sdiv	x5, x3, x15
    bd48:      	sdiv	x19, x3, x13
    bd4c:      	add	x8, x8, x7
    bd50:      	and	x6, x3, #0x8000000000000003
    bd54:      	add	x1, x4, x1, asr #63
    bd58:      	msub	x4, x19, x13, x3
    bd5c:      	msub	x3, x20, x14, x3
    bd60:      	add	x8, x8, x5
    bd64:      	cmp	x6, x16
    bd68:      	add	x8, x8, x3, asr #63
    bd6c:      	sub	x6, x1, #0x1
    bd70:      	cset	w19, hi
    bd74:      	add	x8, x8, x4, lsr #63
    bd78:      	sub	x8, x8, x19
    bd7c:      	sdiv	x3, x6, x0
    bd80:      	sdiv	x21, x6, x13
    bd84:      	add	x8, x8, x3
    bd88:      	sdiv	x7, x6, x12
    bd8c:      	add	x8, x8, x21
    bd90:      	sub	x9, x1, x9
    bd94:      	sdiv	x22, x6, x14
    bd98:      	add	x8, x8, x7
    bd9c:      	msub	x22, x22, x14, x6
    bda0:      	madd	x8, x9, x11, x8
    bda4:      	and	x20, x6, #0x8000000000000003
    bda8:      	msub	x5, x21, x13, x6
    bdac:      	add	x8, x8, x22, lsr #63
    bdb0:      	cmp	x20, x16
    bdb4:      	add	x8, x8, x5, asr #63
    bdb8:      	cinc	x8, x8, hi
    bdbc:      	mov	x9, x1
    bdc0:      	tbz	x8, #0x3f, 0xbcf4 <JNI_OnLoad+0x2b98>
    bdc4:      	b	0xbd28 <JNI_OnLoad+0x2bcc>
    bdc8:      	mov	w11, #0xf894            // =63636
    bdcc:      	movk	w11, #0x7fff, lsl #16
    bdd0:      	add	x11, x9, x11
    bdd4:      	sub	w10, w9, #0x76c
    bdd8:      	lsr	x11, x11, #32
    bddc:      	str	w10, [x2, #0x14]
    bde0:      	cbnz	x11, 0xbdf4 <JNI_OnLoad+0x2c98>
    bde4:      	str	w8, [x2, #0x1c]
    bde8:      	cbz	x1, 0xbe08 <JNI_OnLoad+0x2cac>
    bdec:      	mov	x9, xzr
    bdf0:      	b	0xbe34 <JNI_OnLoad+0x2cd8>
    bdf4:      	bl	0xd370 <__errno@plt>
    bdf8:      	mov	w8, #0x4b               // =75
    bdfc:      	mov	x2, xzr
    be00:      	str	w8, [x0]
    be04:      	b	0xbe68 <JNI_OnLoad+0x2d0c>
    be08:      	mov	w10, #0x64              // =100
    be0c:      	sdiv	x11, x9, x10
    be10:      	msub	x10, x11, x10, x9
    be14:      	cbz	x10, 0xbe20 <JNI_OnLoad+0x2cc4>
    be18:      	mov	w9, #0x1                // =1
    be1c:      	b	0xbe34 <JNI_OnLoad+0x2cd8>
    be20:      	mov	w10, #0x190             // =400
    be24:      	sdiv	x11, x9, x10
    be28:      	msub	x9, x11, x10, x9
    be2c:      	cmp	x9, #0x0
    be30:      	cset	w9, eq
    be34:      	adrp	x11, 0x2000
    be38:      	mov	w10, #0x1a              // =26
    be3c:      	add	x11, x11, #0xd3c
    be40:      	madd	x10, x9, x10, x11
    be44:      	mov	w9, #0xb                // =11
    be48:      	ldrh	w11, [x10, x9, lsl #1]
    be4c:      	sub	x9, x9, #0x1
    be50:      	cmp	x8, x11
    be54:      	b.lt	0xbe48 <JNI_OnLoad+0x2cec>
    be58:      	sub	w8, w8, w11
    be5c:      	add	w9, w9, #0x1
    be60:      	add	w8, w8, #0x1
    be64:      	stp	w8, w9, [x2, #0xc]
    be68:      	ldp	x20, x19, [sp, #0x20]
    be6c:      	ldp	x22, x21, [sp, #0x10]
    be70:      	mov	x0, x2
    be74:      	ldp	x29, x30, [sp], #0x30
    be78:      	ret
    be7c:      	sub	sp, sp, #0xd0
    be80:      	stp	x29, x30, [sp, #0x70]
    be84:      	stp	x28, x27, [sp, #0x80]
    be88:      	stp	x26, x25, [sp, #0x90]
    be8c:      	stp	x24, x23, [sp, #0xa0]
    be90:      	stp	x22, x21, [sp, #0xb0]
    be94:      	stp	x20, x19, [sp, #0xc0]
    be98:      	add	x29, sp, #0x70
    be9c:      	mrs	x28, TPIDR_EL0
    bea0:      	ldr	x8, [x28, #0x28]
    bea4:      	mov	x19, x2
    bea8:      	stur	x8, [x29, #-0x8]
    beac:      	stp	xzr, x0, [sp, #0x28]
    beb0:      	str	x1, [sp, #0x38]
    beb4:      	cbz	x1, 0xbebc <JNI_OnLoad+0x2d60>
    beb8:      	strb	wzr, [x0]
    bebc:      	ldp	x8, x23, [x3]
    bec0:      	ldr	w22, [x3, #0x18]
    bec4:      	mov	w27, wzr
    bec8:      	mov	w21, #0x2d              // =45
    becc:      	str	x8, [sp, #0x20]
    bed0:      	sub	x8, x29, #0x28
    bed4:      	orr	x8, x8, #0x2
    bed8:      	str	x8, [sp, #0x10]
    bedc:      	mov	w9, w27
    bee0:      	mov	x2, xzr
    bee4:      	mov	w8, w27
    bee8:      	sxtw	x9, w9
    beec:      	add	x11, x19, w27, sxtw
    bef0:      	ldrb	w10, [x11, x2]
    bef4:      	cbz	w10, 0xbf08 <JNI_OnLoad+0x2dac>
    bef8:      	cmp	w10, #0x25
    befc:      	b.eq	0xbf08 <JNI_OnLoad+0x2dac>
    bf00:      	add	x2, x2, #0x1
    bf04:      	b	0xbef0 <JNI_OnLoad+0x2d94>
    bf08:      	add	x20, x8, x2
    bf0c:      	cmp	w9, w20
    bf10:      	sturb	w10, [x29, #-0x30]
    bf14:      	b.ge	0xbf2c <JNI_OnLoad+0x2dd0>
    bf18:      	add	x1, x19, x9
    bf1c:      	add	x0, sp, #0x28
    bf20:      	bl	0xc3d8 <JNI_OnLoad+0x327c>
    bf24:      	ldurb	w10, [x29, #-0x30]
    bf28:      	mov	w8, w20
    bf2c:      	cbz	w10, 0xc30c <JNI_OnLoad+0x31b0>
    bf30:      	mov	w24, wzr
    bf34:      	mov	w26, wzr
    bf38:      	mov	w20, wzr
    bf3c:      	add	w27, w8, #0x1
    bf40:      	sxtw	x9, w27
    bf44:      	mov	w10, w20
    bf48:      	ldrb	w3, [x19, x9]
    bf4c:      	add	x27, x9, #0x1
    bf50:      	mov	w20, w10
    bf54:      	mov	w10, #0x1               // =1
    bf58:      	subs	w8, w3, #0x30
    bf5c:      	mov	x9, x27
    bf60:      	b.eq	0xbf48 <JNI_OnLoad+0x2dec>
    bf64:      	cmp	w3, #0x2d
    bf68:      	b.eq	0xbf88 <JNI_OnLoad+0x2e2c>
    bf6c:      	cmp	w3, #0x20
    bf70:      	b.eq	0xbf7c <JNI_OnLoad+0x2e20>
    bf74:      	cmp	w3, #0x2b
    bf78:      	b.ne	0xbf94 <JNI_OnLoad+0x2e38>
    bf7c:      	sturb	w3, [x29, #-0x30]
    bf80:      	mov	w24, w3
    bf84:      	b	0xbf40 <JNI_OnLoad+0x2de4>
    bf88:      	sturb	w21, [x29, #-0x30]
    bf8c:      	mov	w26, #0x1               // =1
    bf90:      	b	0xbf40 <JNI_OnLoad+0x2de4>
    bf94:      	cbz	w3, 0xc2f4 <JNI_OnLoad+0x3198>
    bf98:      	cmp	w8, #0x9
    bf9c:      	stur	w27, [x29, #-0x2c]
    bfa0:      	sturb	w3, [x29, #-0x30]
    bfa4:      	b.hi	0xbfcc <JNI_OnLoad+0x2e70>
    bfa8:      	sub	w8, w27, #0x1
    bfac:      	sub	x1, x29, #0x2c
    bfb0:      	mov	x0, x19
    bfb4:      	stur	w8, [x29, #-0x2c]
    bfb8:      	bl	0xc464 <JNI_OnLoad+0x3308>
    bfbc:      	ldursw	x8, [x29, #-0x2c]
    bfc0:      	str	w0, [sp, #0x1c]
    bfc4:      	bl	0xc698 <JNI_OnLoad+0x353c>
    bfc8:      	b	0xbfd4 <JNI_OnLoad+0x2e78>
    bfcc:      	mov	w8, #-0x1               // =-1
    bfd0:      	str	w8, [sp, #0x1c]
    bfd4:      	cmp	w3, #0x2e
    bfd8:      	b.ne	0xbff4 <JNI_OnLoad+0x2e98>
    bfdc:      	sub	x1, x29, #0x2c
    bfe0:      	mov	x0, x19
    bfe4:      	bl	0xc464 <JNI_OnLoad+0x3308>
    bfe8:      	ldursw	x8, [x29, #-0x2c]
    bfec:      	bl	0xc698 <JNI_OnLoad+0x353c>
    bff0:      	b	0xbff8 <JNI_OnLoad+0x2e9c>
    bff4:      	mov	w0, #-0x1               // =-1
    bff8:      	sub	w8, w3, #0x68
    bffc:      	ror	w9, w8, #0x1
    c000:      	cmp	w9, #0x9
    c004:      	mov	w8, #0x4                // =4
    c008:      	b.hi	0xc098 <JNI_OnLoad+0x2f3c>
    c00c:      	adrp	x12, 0x2000
    c010:      	add	x12, x12, #0xd20
    c014:      	adr	x10, 0xc024 <JNI_OnLoad+0x2ec8>
    c018:      	ldrb	w11, [x12, x9]
    c01c:      	add	x10, x10, x11, lsl #2
    c020:      	br	x10
    c024:      	add	w8, w27, #0x1
    c028:      	stur	w8, [x29, #-0x2c]
    c02c:      	ldrb	w3, [x19, w27, sxtw]
    c030:      	mov	w27, w8
    c034:      	sturb	w3, [x29, #-0x30]
    c038:      	b	0xc080 <JNI_OnLoad+0x2f24>
    c03c:      	ldrb	w3, [x19, w27, sxtw]
    c040:      	cmp	w3, #0x68
    c044:      	b.ne	0xc088 <JNI_OnLoad+0x2f2c>
    c048:      	sxtw	x8, w27
    c04c:      	add	x27, x8, #0x1
    c050:      	ldrb	w3, [x19, x27]
    c054:      	mov	w8, #0x1                // =1
    c058:      	b	0xc08c <JNI_OnLoad+0x2f30>
    c05c:      	ldrb	w3, [x19, w27, sxtw]
    c060:      	cmp	w3, #0x6c
    c064:      	b.ne	0xc074 <JNI_OnLoad+0x2f18>
    c068:      	sxtw	x8, w27
    c06c:      	add	x27, x8, #0x1
    c070:      	ldrb	w3, [x19, x27]
    c074:      	add	w27, w27, #0x1
    c078:      	sturb	w3, [x29, #-0x30]
    c07c:      	stur	w27, [x29, #-0x2c]
    c080:      	mov	w8, #0x8                // =8
    c084:      	b	0xc098 <JNI_OnLoad+0x2f3c>
    c088:      	mov	w8, #0x2                // =2
    c08c:      	add	w27, w27, #0x1
    c090:      	stur	w27, [x29, #-0x2c]
    c094:      	sturb	w3, [x29, #-0x30]
    c098:      	sub	w11, w3, #0x6f
    c09c:      	mov	w9, #0x1                // =1
    c0a0:      	cmp	w11, #0x9
    c0a4:      	add	x10, x23, w22, sxtw
    c0a8:      	b.hi	0xc0e0 <JNI_OnLoad+0x2f84>
    c0ac:      	adrp	x14, 0x2000
    c0b0:      	add	x14, x14, #0xd2a
    c0b4:      	adr	x12, 0xc0c4 <JNI_OnLoad+0x2f68>
    c0b8:      	ldrb	w13, [x14, x11]
    c0bc:      	add	x12, x12, x13, lsl #2
    c0c0:      	br	x12
    c0c4:      	str	x28, [sp, #0x8]
    c0c8:      	tbz	w22, #0x1f, 0xc280 <JNI_OnLoad+0x3124>
    c0cc:      	bl	0xc648 <JNI_OnLoad+0x34ec>
    c0d0:      	b.gt	0xc280 <JNI_OnLoad+0x3124>
    c0d4:      	ldr	x28, [sp, #0x20]
    c0d8:      	bl	0xc68c <JNI_OnLoad+0x3530>
    c0dc:      	b	0xc28c <JNI_OnLoad+0x3130>
    c0e0:      	cmp	w3, #0x25
    c0e4:      	b.eq	0xc26c <JNI_OnLoad+0x3110>
    c0e8:      	cmp	w3, #0x58
    c0ec:      	b.eq	0xc10c <JNI_OnLoad+0x2fb0>
    c0f0:      	cmp	w3, #0x63
    c0f4:      	b.eq	0xc254 <JNI_OnLoad+0x30f8>
    c0f8:      	cmp	w3, #0x64
    c0fc:      	b.eq	0xc110 <JNI_OnLoad+0x2fb4>
    c100:      	cmp	w3, #0x69
    c104:      	b.eq	0xc110 <JNI_OnLoad+0x2fb4>
    c108:      	b	0xc30c <JNI_OnLoad+0x31b0>
    c10c:      	mov	w9, wzr
    c110:      	sub	x11, x8, #0x1
    c114:      	cmp	x11, #0x7
    c118:      	b.hi	0xc30c <JNI_OnLoad+0x31b0>
    c11c:      	adrp	x14, 0x2000
    c120:      	add	x14, x14, #0xd34
    c124:      	adr	x12, 0xc134 <JNI_OnLoad+0x2fd8>
    c128:      	ldrb	w13, [x14, x11]
    c12c:      	add	x12, x12, x13, lsl #2
    c130:      	br	x12
    c134:      	tbz	w22, #0x1f, 0xc19c <JNI_OnLoad+0x3040>
    c138:      	bl	0xc648 <JNI_OnLoad+0x34ec>
    c13c:      	b.gt	0xc19c <JNI_OnLoad+0x3040>
    c140:      	bl	0xc6c0 <JNI_OnLoad+0x3564>
    c144:      	b	0xc1a0 <JNI_OnLoad+0x3044>
    c148:      	tbz	w22, #0x1f, 0xc184 <JNI_OnLoad+0x3028>
    c14c:      	bl	0xc648 <JNI_OnLoad+0x34ec>
    c150:      	b.gt	0xc184 <JNI_OnLoad+0x3028>
    c154:      	bl	0xc6c0 <JNI_OnLoad+0x3564>
    c158:      	b	0xc188 <JNI_OnLoad+0x302c>
    c15c:      	tbz	w22, #0x1f, 0xc190 <JNI_OnLoad+0x3034>
    c160:      	bl	0xc648 <JNI_OnLoad+0x34ec>
    c164:      	b.gt	0xc190 <JNI_OnLoad+0x3034>
    c168:      	bl	0xc6c0 <JNI_OnLoad+0x3564>
    c16c:      	b	0xc194 <JNI_OnLoad+0x3038>
    c170:      	tbz	w22, #0x1f, 0xc1a8 <JNI_OnLoad+0x304c>
    c174:      	bl	0xc648 <JNI_OnLoad+0x34ec>
    c178:      	b.gt	0xc1a8 <JNI_OnLoad+0x304c>
    c17c:      	bl	0xc6c0 <JNI_OnLoad+0x3564>
    c180:      	b	0xc1ac <JNI_OnLoad+0x3050>
    c184:      	bl	0xc66c <JNI_OnLoad+0x3510>
    c188:      	ldrh	w2, [x10]
    c18c:      	b	0xc1b0 <JNI_OnLoad+0x3054>
    c190:      	bl	0xc66c <JNI_OnLoad+0x3510>
    c194:      	ldr	x2, [x10]
    c198:      	b	0xc1b0 <JNI_OnLoad+0x3054>
    c19c:      	bl	0xc66c <JNI_OnLoad+0x3510>
    c1a0:      	ldrb	w2, [x10]
    c1a4:      	b	0xc1b0 <JNI_OnLoad+0x3054>
    c1a8:      	bl	0xc66c <JNI_OnLoad+0x3510>
    c1ac:      	ldr	w2, [x10]
    c1b0:      	mov	x21, x23
    c1b4:      	str	x11, [sp, #0x20]
    c1b8:      	cbz	w9, 0xc1cc <JNI_OnLoad+0x3070>
    c1bc:      	lsl	w8, w8, #3
    c1c0:      	neg	w8, w8
    c1c4:      	lsl	x9, x2, x8
    c1c8:      	asr	x2, x9, x8
    c1cc:      	sub	x0, x29, #0x28
    c1d0:      	mov	w1, #0x20               // =32
    c1d4:      	sub	x23, x29, #0x28
    c1d8:      	bl	0xc49c <JNI_OnLoad+0x3340>
    c1dc:      	mov	x0, x23
    c1e0:      	bl	0xd5b0 <strlen@plt>
    c1e4:      	tst	w24, #0xff
    c1e8:      	b.ne	0xc30c <JNI_OnLoad+0x31b0>
    c1ec:      	cmn	w25, #0x1
    c1f0:      	b.ne	0xc30c <JNI_OnLoad+0x31b0>
    c1f4:      	mov	x24, x0
    c1f8:      	cbnz	w26, 0xc20c <JNI_OnLoad+0x30b0>
    c1fc:      	ldr	w8, [sp, #0x1c]
    c200:      	subs	w2, w8, w24
    c204:      	b.le	0xc20c <JNI_OnLoad+0x30b0>
    c208:      	bl	0xc654 <JNI_OnLoad+0x34f8>
    c20c:      	add	x0, sp, #0x28
    c210:      	mov	x1, x23
    c214:      	mov	w2, w24
    c218:      	bl	0xc3d8 <JNI_OnLoad+0x327c>
    c21c:      	cbz	w26, 0xc230 <JNI_OnLoad+0x30d4>
    c220:      	ldr	w8, [sp, #0x1c]
    c224:      	subs	w2, w8, w24
    c228:      	b.le	0xc230 <JNI_OnLoad+0x30d4>
    c22c:      	bl	0xc654 <JNI_OnLoad+0x34f8>
    c230:      	mov	x23, x21
    c234:      	mov	w21, #0x2d              // =45
    c238:      	b	0xbedc <JNI_OnLoad+0x2d80>
    c23c:      	tbz	w22, #0x1f, 0xc2b8 <JNI_OnLoad+0x315c>
    c240:      	bl	0xc648 <JNI_OnLoad+0x34ec>
    c244:      	b.gt	0xc2b8 <JNI_OnLoad+0x315c>
    c248:      	ldr	x8, [sp, #0x20]
    c24c:      	bl	0xc68c <JNI_OnLoad+0x3530>
    c250:      	b	0xc2bc <JNI_OnLoad+0x3160>
    c254:      	tbz	w22, #0x1f, 0xc2d8 <JNI_OnLoad+0x317c>
    c258:      	bl	0xc648 <JNI_OnLoad+0x34ec>
    c25c:      	b.gt	0xc2d8 <JNI_OnLoad+0x317c>
    c260:      	ldr	x8, [sp, #0x20]
    c264:      	bl	0xc68c <JNI_OnLoad+0x3530>
    c268:      	b	0xc2dc <JNI_OnLoad+0x3180>
    c26c:      	bl	0xc68c <JNI_OnLoad+0x3530>
    c270:      	sub	x23, x29, #0x28
    c274:      	mov	w8, #0x25               // =37
    c278:      	sturh	w8, [x29, #-0x28]
    c27c:      	b	0xc1dc <JNI_OnLoad+0x3080>
    c280:      	ldr	x10, [sp, #0x20]
    c284:      	bl	0xc68c <JNI_OnLoad+0x3530>
    c288:      	add	x28, x10, #0x8
    c28c:      	ldr	x2, [x10]
    c290:      	ldr	x0, [sp, #0x10]
    c294:      	mov	w8, #0x7830             // =30768
    c298:      	mov	w1, #0x1e               // =30
    c29c:      	mov	w3, #0x78               // =120
    c2a0:      	sub	x23, x29, #0x28
    c2a4:      	sturh	w8, [x29, #-0x28]
    c2a8:      	bl	0xc49c <JNI_OnLoad+0x3340>
    c2ac:      	str	x28, [sp, #0x20]
    c2b0:      	ldr	x28, [sp, #0x8]
    c2b4:      	b	0xc1dc <JNI_OnLoad+0x3080>
    c2b8:      	bl	0xc6ac <JNI_OnLoad+0x3550>
    c2bc:      	ldr	x9, [x10]
    c2c0:      	adrp	x10, 0x2000
    c2c4:      	add	x10, x10, #0xaca
    c2c8:      	str	x8, [sp, #0x20]
    c2cc:      	cmp	x9, #0x0
    c2d0:      	csel	x23, x10, x9, eq
    c2d4:      	b	0xc1dc <JNI_OnLoad+0x3080>
    c2d8:      	bl	0xc6ac <JNI_OnLoad+0x3550>
    c2dc:      	ldr	w9, [x10]
    c2e0:      	sub	x23, x29, #0x28
    c2e4:      	sturb	wzr, [x29, #-0x27]
    c2e8:      	str	x8, [sp, #0x20]
    c2ec:      	sturb	w9, [x29, #-0x28]
    c2f0:      	b	0xc1dc <JNI_OnLoad+0x3080>
    c2f4:      	mov	w8, #0x25               // =37
    c2f8:      	add	x0, sp, #0x28
    c2fc:      	sub	x1, x29, #0x30
    c300:      	mov	w2, #0x1                // =1
    c304:      	sturb	w8, [x29, #-0x30]
    c308:      	bl	0xc3d8 <JNI_OnLoad+0x327c>
    c30c:      	ldr	x0, [sp, #0x28]
    c310:      	ldr	x8, [x28, #0x28]
    c314:      	ldur	x9, [x29, #-0x8]
    c318:      	cmp	x8, x9
    c31c:      	b.ne	0xc340 <JNI_OnLoad+0x31e4>
    c320:      	ldp	x20, x19, [sp, #0xc0]
    c324:      	ldp	x22, x21, [sp, #0xb0]
    c328:      	ldp	x24, x23, [sp, #0xa0]
    c32c:      	ldp	x26, x25, [sp, #0x90]
    c330:      	ldp	x28, x27, [sp, #0x80]
    c334:      	ldp	x29, x30, [sp, #0x70]
    c338:      	add	sp, sp, #0xd0
    c33c:      	ret
    c340:      	bl	0xd2e0 <__stack_chk_fail@plt>
    c344:      	sub	sp, sp, #0x120
    c348:      	stp	x29, x30, [sp, #0x100]
    c34c:      	stp	x28, x19, [sp, #0x110]
    c350:      	add	x29, sp, #0x100
    c354:      	stp	x3, x4, [x29, #-0x78]
    c358:      	stp	x5, x6, [x29, #-0x68]
    c35c:      	stur	x7, [x29, #-0x58]
    c360:      	stp	q0, q1, [sp]
    c364:      	stp	q2, q3, [sp, #0x20]
    c368:      	stp	q4, q5, [sp, #0x40]
    c36c:      	stp	q6, q7, [sp, #0x60]
    c370:      	mrs	x19, TPIDR_EL0
    c374:      	ldr	x9, [x19, #0x28]
    c378:      	mov	x10, #-0x28             // =-40
    c37c:      	mov	x11, sp
    c380:      	sub	x12, x29, #0x78
    c384:      	movk	x10, #0xff80, lsl #32
    c388:      	stur	x9, [x29, #-0x8]
    c38c:      	add	x9, x29, #0x20
    c390:      	add	x11, x11, #0x80
    c394:      	add	x12, x12, #0x28
    c398:      	sub	x8, x29, #0x28
    c39c:      	stp	x11, x10, [x29, #-0x18]
    c3a0:      	stp	x9, x12, [x29, #-0x28]
    c3a4:      	ldp	q0, q1, [x8]
    c3a8:      	sub	x3, x29, #0x50
    c3ac:      	stp	q0, q1, [x29, #-0x50]
    c3b0:      	bl	0xbe7c <JNI_OnLoad+0x2d20>
    c3b4:      	ldr	x8, [x19, #0x28]
    c3b8:      	ldur	x9, [x29, #-0x8]
    c3bc:      	cmp	x8, x9
    c3c0:      	b.ne	0xc3d4 <JNI_OnLoad+0x3278>
    c3c4:      	ldp	x28, x19, [sp, #0x110]
    c3c8:      	ldp	x29, x30, [sp, #0x100]
    c3cc:      	add	sp, sp, #0x120
    c3d0:      	ret
    c3d4:      	bl	0xd2e0 <__stack_chk_fail@plt>
    c3d8:      	stp	x29, x30, [sp, #-0x30]!
    c3dc:      	str	x21, [sp, #0x10]
    c3e0:      	stp	x20, x19, [sp, #0x20]
    c3e4:      	mov	x29, sp
    c3e8:      	mov	x20, x1
    c3ec:      	mov	x19, x0
    c3f0:      	tbz	w2, #0x1f, 0xc400 <JNI_OnLoad+0x32a4>
    c3f4:      	mov	x0, x20
    c3f8:      	bl	0xd5b0 <strlen@plt>
    c3fc:      	mov	x2, x0
    c400:      	ldr	x9, [x19]
    c404:      	ldr	x8, [x19, #0x10]
    c408:      	add	x9, x9, w2, sxtw
    c40c:      	cmp	x8, #0x2
    c410:      	str	x9, [x19]
    c414:      	b.lo	0xc454 <JNI_OnLoad+0x32f8>
    c418:      	sxtw	x9, w2
    c41c:      	ldr	x0, [x19, #0x8]
    c420:      	sub	w10, w8, #0x1
    c424:      	cmp	x8, x9
    c428:      	csel	w21, w9, w10, hi
    c42c:      	sxtw	x2, w21
    c430:      	mov	x1, x20
    c434:      	bl	0xd510 <memcpy@plt>
    c438:      	ldr	x8, [x19, #0x8]
    c43c:      	add	x9, x8, w21, sxtw
    c440:      	str	x9, [x19, #0x8]
    c444:      	strb	wzr, [x8, w21, sxtw]
    c448:      	ldr	x8, [x19, #0x10]
    c44c:      	sub	x8, x8, w21, sxtw
    c450:      	str	x8, [x19, #0x10]
    c454:      	ldp	x20, x19, [sp, #0x20]
    c458:      	ldr	x21, [sp, #0x10]
    c45c:      	ldp	x29, x30, [sp], #0x30
    c460:      	ret
    c464:      	ldrsw	x10, [x1]
    c468:      	mov	w8, wzr
    c46c:      	mov	w11, #0xa               // =10
    c470:      	add	x9, x0, x10
    c474:      	sub	w10, w10, #0x1
    c478:      	ldrb	w12, [x9], #0x1
    c47c:      	mov	w0, w8
    c480:      	add	w10, w10, #0x1
    c484:      	sub	w12, w12, #0x30
    c488:      	madd	w8, w8, w11, w12
    c48c:      	cmp	w12, #0xa
    c490:      	b.lo	0xc478 <JNI_OnLoad+0x331c>
    c494:      	str	w10, [x1]
    c498:      	ret
    c49c:      	sub	w8, w3, #0x64
    c4a0:      	and	w11, w8, #0xff
    c4a4:      	mov	w9, #0x821              // =2081
    c4a8:      	cmp	w11, #0xc
    c4ac:      	and	w10, w3, #0xff
    c4b0:      	lsr	w8, w9, w8
    c4b4:      	cset	w9, lo
    c4b8:      	cmp	w10, #0x58
    c4bc:      	and	w9, w8, w9
    c4c0:      	mov	w8, #0x10               // =16
    c4c4:      	b.eq	0xc4e4 <JNI_OnLoad+0x3388>
    c4c8:      	cmp	w10, #0x78
    c4cc:      	b.eq	0xc4e4 <JNI_OnLoad+0x3388>
    c4d0:      	cmp	w10, #0x6f
    c4d4:      	b.ne	0xc4e0 <JNI_OnLoad+0x3384>
    c4d8:      	mov	w8, #0x8                // =8
    c4dc:      	b	0xc4e4 <JNI_OnLoad+0x3388>
    c4e0:      	mov	w8, #0xa                // =10
    c4e4:      	cmp	x2, #0x0
    c4e8:      	cset	w10, ge
    c4ec:      	eor	w9, w9, #0x1
    c4f0:      	orr	w9, w10, w9
    c4f4:      	tbnz	w9, #0x0, 0xc508 <JNI_OnLoad+0x33ac>
    c4f8:      	mov	w9, #0x2d               // =45
    c4fc:      	sub	x1, x1, #0x1
    c500:      	strb	w9, [x0], #0x1
    c504:      	neg	x2, x2
    c508:      	and	w9, w3, #0xff
    c50c:      	add	x10, x0, x1
    c510:      	mov	w11, #0x57              // =87
    c514:      	mov	w12, #0x37              // =55
    c518:      	cmp	w9, #0x58
    c51c:      	sub	x10, x10, #0x1
    c520:      	csel	w11, w12, w11, eq
    c524:      	mov	w12, #0x30              // =48
    c528:      	mov	x14, x0
    c52c:      	mov	x9, x14
    c530:      	cbz	x2, 0xc564 <JNI_OnLoad+0x3408>
    c534:      	mov	x13, x2
    c538:      	cmp	x9, x10
    c53c:      	udiv	x2, x2, x8
    c540:      	mov	x14, x10
    c544:      	b.eq	0xc52c <JNI_OnLoad+0x33d0>
    c548:      	msub	x13, x2, x8, x13
    c54c:      	cmp	w13, #0xa
    c550:      	csel	w14, w12, w11, lo
    c554:      	add	w13, w14, w13
    c558:      	strb	w13, [x9], #0x1
    c55c:      	mov	x14, x9
    c560:      	b	0xc52c <JNI_OnLoad+0x33d0>
    c564:      	cmp	x9, x0
    c568:      	ccmp	x9, x10, #0x4, eq
    c56c:      	b.eq	0xc57c <JNI_OnLoad+0x3420>
    c570:      	mov	w8, #0x30               // =48
    c574:      	mov	x9, x0
    c578:      	strb	w8, [x9], #0x1
    c57c:      	mvn	x10, x0
    c580:      	mov	x8, xzr
    c584:      	strb	wzr, [x9]
    c588:      	add	x9, x9, x10
    c58c:      	cmp	x8, x9
    c590:      	b.hs	0xc5b0 <JNI_OnLoad+0x3454>
    c594:      	ldrb	w10, [x0, x9]
    c598:      	ldrb	w11, [x0, x8]
    c59c:      	strb	w10, [x0, x8]
    c5a0:      	strb	w11, [x0, x9]
    c5a4:      	add	x8, x8, #0x1
    c5a8:      	sub	x9, x9, #0x1
    c5ac:      	b	0xc58c <JNI_OnLoad+0x3430>
    c5b0:      	ret
    c5b4:      	sub	sp, sp, #0x50
    c5b8:      	stp	x29, x30, [sp, #0x10]
    c5bc:      	str	x23, [sp, #0x20]
    c5c0:      	stp	x22, x21, [sp, #0x30]
    c5c4:      	stp	x20, x19, [sp, #0x40]
    c5c8:      	add	x29, sp, #0x10
    c5cc:      	mrs	x22, TPIDR_EL0
    c5d0:      	ldr	x8, [x22, #0x28]
    c5d4:      	and	x9, x1, #0xff
    c5d8:      	mov	x10, #0x101010101010101 // =72340172838076673
    c5dc:      	mov	w19, w2
    c5e0:      	mov	x20, x0
    c5e4:      	mul	x9, x9, x10
    c5e8:      	mov	w23, #0x8               // =8
    c5ec:      	str	x8, [sp, #0x8]
    c5f0:      	str	x9, [sp]
    c5f4:      	cmp	w19, #0x1
    c5f8:      	b.lt	0xc61c <JNI_OnLoad+0x34c0>
    c5fc:      	cmp	w19, #0x8
    c600:      	csel	w21, w19, w23, lt
    c604:      	mov	x1, sp
    c608:      	mov	x0, x20
    c60c:      	mov	w2, w21
    c610:      	bl	0xc3d8 <JNI_OnLoad+0x327c>
    c614:      	sub	w19, w19, w21
    c618:      	b	0xc5f4 <JNI_OnLoad+0x3498>
    c61c:      	ldr	x8, [x22, #0x28]
    c620:      	ldr	x9, [sp, #0x8]
    c624:      	cmp	x8, x9
    c628:      	b.ne	0xc644 <JNI_OnLoad+0x34e8>
    c62c:      	ldp	x20, x19, [sp, #0x40]
    c630:      	ldp	x22, x21, [sp, #0x30]
    c634:      	ldr	x23, [sp, #0x20]
    c638:      	ldp	x29, x30, [sp, #0x10]
    c63c:      	add	sp, sp, #0x50
    c640:      	ret
    c644:      	bl	0xd2e0 <__stack_chk_fail@plt>
    c648:      	cmn	w22, #0x8
    c64c:      	add	w22, w22, #0x8
    c650:      	ret
    c654:      	cmp	w20, #0x0
    c658:      	mov	w8, #0x30               // =48
    c65c:      	mov	w9, #0x20               // =32
    c660:      	csel	w1, w9, w8, eq
    c664:      	add	x0, sp, #0x28
    c668:      	b	0xc5b4 <JNI_OnLoad+0x3458>
    c66c:      	ldr	x10, [sp, #0x20]
    c670:      	mov	w25, w0
    c674:      	add	x11, x10, #0x8
    c678:      	ret
    c67c:      	and	x0, x9, x0
    c680:      	and	x8, x8, x9
    c684:      	sub	x1, x8, x0
    c688:      	b	0xd700 <mprotect@plt>
    c68c:      	mov	w25, w0
    c690:      	mov	x21, x23
    c694:      	ret
    c698:      	add	w27, w8, #0x1
    c69c:      	stur	w27, [x29, #-0x2c]
    c6a0:      	ldrb	w3, [x19, x8]
    c6a4:      	sturb	w3, [x29, #-0x30]
    c6a8:      	ret
    c6ac:      	ldr	x10, [sp, #0x20]
    c6b0:      	mov	w25, w0
    c6b4:      	mov	x21, x23
    c6b8:      	add	x8, x10, #0x8
    c6bc:      	ret
    c6c0:      	ldr	x11, [sp, #0x20]
    c6c4:      	mov	w25, w0
    c6c8:      	ret

000000000000c6cc <bytehook_get_version>:
    c6cc:      	adrp	x0, 0x2000
    c6d0:      	add	x0, x0, #0xaef
    c6d4:      	ret

000000000000c6d8 <bytehook_init>:
    c6d8:      	stp	x29, x30, [sp, #-0x30]!
    c6dc:      	stp	x22, x21, [sp, #0x10]
    c6e0:      	stp	x20, x19, [sp, #0x20]
    c6e4:      	mov	x29, sp
    c6e8:      	adrp	x22, 0x15000
    c6ec:      	ldr	w6, [x22, #0xe24]
    c6f0:      	mov	w19, w1
    c6f4:      	mov	w20, w0
    c6f8:      	cmp	w6, #0x1
    c6fc:      	b.ne	0xc800 <bytehook_init+0x128>
    c700:      	adrp	x0, 0x16000
    c704:      	add	x0, x0, #0x130
    c708:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    c70c:      	ldr	w8, [x22, #0xe24]
    c710:      	cmp	w8, #0x1
    c714:      	b.ne	0xc80c <bytehook_init+0x134>
    c718:      	and	w0, w19, #0x1
    c71c:      	bl	0x9574 <JNI_OnLoad+0x418>
    c720:      	cmp	w20, #0x1
    c724:      	b.hi	0xc818 <bytehook_init+0x140>
    c728:      	adrp	x21, 0x15000
    c72c:      	str	w20, [x21, #0xe28]
    c730:      	bl	0x93b8 <JNI_OnLoad+0x25c>
    c734:      	cbnz	w0, 0xc820 <bytehook_init+0x148>
    c738:      	mov	w0, #0xb                // =11
    c73c:      	bl	0xcc38 <bytehook_del_dlopen_callback+0x110>
    c740:      	cbnz	w0, 0xc7f8 <bytehook_init+0x120>
    c744:      	mov	w0, #0x7                // =7
    c748:      	bl	0xcc38 <bytehook_del_dlopen_callback+0x110>
    c74c:      	cbnz	w0, 0xc7f8 <bytehook_init+0x120>
    c750:      	bl	0x5778 <.text+0x18c>
    c754:      	cbnz	w0, 0xc828 <bytehook_init+0x150>
    c758:      	bl	0xa0dc <JNI_OnLoad+0xf80>
    c75c:      	cbnz	w0, 0xc830 <bytehook_init+0x158>
    c760:      	ldr	w8, [x21, #0xe28]
    c764:      	cbnz	w8, 0xc770 <bytehook_init+0x98>
    c768:      	bl	0x8754 <.text+0x3168>
    c76c:      	cbnz	w0, 0xc838 <bytehook_init+0x160>
    c770:      	mov	w8, wzr
    c774:      	adrp	x21, 0x2000
    c778:      	add	x21, x21, #0x541
    c77c:      	str	w8, [x22, #0xe24]
    c780:      	adrp	x0, 0x16000
    c784:      	add	x0, x0, #0x130
    c788:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    c78c:      	ldr	w6, [x22, #0xe24]
    c790:      	adrp	x8, 0x2000
    c794:      	adrp	x9, 0x2000
    c798:      	add	x8, x8, #0x677
    c79c:      	add	x9, x9, #0x72c
    c7a0:      	cmp	w20, #0x0
    c7a4:      	adrp	x10, 0x2000
    c7a8:      	adrp	x11, 0x2000
    c7ac:      	add	x10, x10, #0x67e
    c7b0:      	add	x11, x11, #0x87a
    c7b4:      	csel	x4, x9, x8, eq
    c7b8:      	tst	w19, #0x1
    c7bc:      	adrp	x1, 0x2000
    c7c0:      	adrp	x2, 0x2000
    c7c4:      	adrp	x3, 0x2000
    c7c8:      	csel	x5, x11, x10, ne
    c7cc:      	add	x1, x1, #0x94c
    c7d0:      	add	x2, x2, #0x736
    c7d4:      	add	x3, x3, #0xaef
    c7d8:      	mov	w0, #0x6                // =6
    c7dc:      	mov	x7, x21
    c7e0:      	bl	0xd3a0 <__android_log_print@plt>
    c7e4:      	ldr	w0, [x22, #0xe24]
    c7e8:      	ldp	x20, x19, [sp, #0x20]
    c7ec:      	ldp	x22, x21, [sp, #0x10]
    c7f0:      	ldp	x29, x30, [sp], #0x30
    c7f4:      	ret
    c7f8:      	mov	w8, #0x9                // =9
    c7fc:      	b	0xc774 <bytehook_init+0x9c>
    c800:      	adrp	x21, 0x2000
    c804:      	add	x21, x21, #0x792
    c808:      	b	0xc790 <bytehook_init+0xb8>
    c80c:      	adrp	x21, 0x2000
    c810:      	add	x21, x21, #0x792
    c814:      	b	0xc780 <bytehook_init+0xa8>
    c818:      	mov	w8, #0x2                // =2
    c81c:      	b	0xc774 <bytehook_init+0x9c>
    c820:      	mov	w8, #0x3                // =3
    c824:      	b	0xc774 <bytehook_init+0x9c>
    c828:      	mov	w8, #0x18               // =24
    c82c:      	b	0xc774 <bytehook_init+0x9c>
    c830:      	mov	w8, #0x1a               // =26
    c834:      	b	0xc774 <bytehook_init+0x9c>
    c838:      	mov	w8, #0x1b               // =27
    c83c:      	b	0xc774 <bytehook_init+0x9c>

000000000000c840 <bytehook_get_mode>:
    c840:      	adrp	x8, 0x15000
    c844:      	ldr	w0, [x8, #0xe28]
    c848:      	ret

000000000000c84c <bytehook_hook_single>:
    c84c:      	stp	x29, x30, [sp, #-0x40]!
    c850:      	str	x23, [sp, #0x10]
    c854:      	stp	x22, x21, [sp, #0x20]
    c858:      	stp	x20, x19, [sp, #0x30]
    c85c:      	mov	x29, sp
    c860:      	adrp	x8, 0x15000
    c864:      	xpaclri
    c868:      	ldr	w8, [x8, #0xe24]
    c86c:      	mov	x21, xzr
    c870:      	cbnz	w8, 0xc8c8 <bytehook_hook_single+0x7c>
    c874:      	mov	x23, x0
    c878:      	cbz	x0, 0xc8c8 <bytehook_hook_single+0x7c>
    c87c:      	mov	x20, x2
    c880:      	cbz	x2, 0xc8c8 <bytehook_hook_single+0x7c>
    c884:      	mov	x19, x3
    c888:      	cbz	x3, 0xc8c8 <bytehook_hook_single+0x7c>
    c88c:      	mov	x0, x23
    c890:      	mov	x2, x20
    c894:      	mov	x3, x19
    c898:      	mov	w6, wzr
    c89c:      	mov	x22, x30
    c8a0:      	bl	0xab60 <JNI_OnLoad+0x1a04>
    c8a4:      	mov	x21, x0
    c8a8:      	cbz	x0, 0xc8c8 <bytehook_hook_single+0x7c>
    c8ac:      	mov	x0, x21
    c8b0:      	bl	0xb270 <JNI_OnLoad+0x2114>
    c8b4:      	mov	x0, x21
    c8b8:      	bl	0xb30c <JNI_OnLoad+0x21b0>
    c8bc:      	ldr	w0, [x21, #0x8]
    c8c0:      	mov	x1, x23
    c8c4:      	bl	0xcb2c <bytehook_del_dlopen_callback+0x4>
    c8c8:      	mov	x0, x21
    c8cc:      	ldp	x20, x19, [sp, #0x30]
    c8d0:      	ldp	x22, x21, [sp, #0x20]
    c8d4:      	ldr	x23, [sp, #0x10]
    c8d8:      	ldp	x29, x30, [sp], #0x40
    c8dc:      	ret

000000000000c8e0 <bytehook_hook_partial>:
    c8e0:      	stp	x29, x30, [sp, #-0x30]!
    c8e4:      	stp	x22, x21, [sp, #0x10]
    c8e8:      	stp	x20, x19, [sp, #0x20]
    c8ec:      	mov	x29, sp
    c8f0:      	adrp	x8, 0x15000
    c8f4:      	xpaclri
    c8f8:      	ldr	w8, [x8, #0xe24]
    c8fc:      	mov	x22, xzr
    c900:      	cbnz	w8, 0xc964 <bytehook_hook_partial+0x84>
    c904:      	cbz	x0, 0xc964 <bytehook_hook_partial+0x84>
    c908:      	mov	x20, x3
    c90c:      	cbz	x3, 0xc964 <bytehook_hook_partial+0x84>
    c910:      	mov	x19, x4
    c914:      	cbz	x4, 0xc964 <bytehook_hook_partial+0x84>
    c918:      	mov	x3, x20
    c91c:      	mov	x4, x19
    c920:      	mov	w7, wzr
    c924:      	mov	x21, x30
    c928:      	bl	0xac4c <JNI_OnLoad+0x1af0>
    c92c:      	mov	x22, x0
    c930:      	cbz	x0, 0xc964 <bytehook_hook_partial+0x84>
    c934:      	mov	x0, x22
    c938:      	bl	0xb270 <JNI_OnLoad+0x2114>
    c93c:      	mov	x0, x22
    c940:      	bl	0xb30c <JNI_OnLoad+0x21b0>
    c944:      	adrp	x1, 0x2000
    c948:      	add	x1, x1, #0xc6b
    c94c:      	mov	w0, #0xff               // =255
    c950:      	mov	x2, x20
    c954:      	mov	x3, x19
    c958:      	mov	x4, x22
    c95c:      	mov	x5, x21
    c960:      	bl	0x95b0 <JNI_OnLoad+0x454>
    c964:      	mov	x0, x22
    c968:      	ldp	x20, x19, [sp, #0x20]
    c96c:      	ldp	x22, x21, [sp, #0x10]
    c970:      	ldp	x29, x30, [sp], #0x30
    c974:      	ret

000000000000c978 <bytehook_hook_all>:
    c978:      	stp	x29, x30, [sp, #-0x30]!
    c97c:      	stp	x22, x21, [sp, #0x10]
    c980:      	stp	x20, x19, [sp, #0x20]
    c984:      	mov	x29, sp
    c988:      	xpaclri
    c98c:      	mov	x21, xzr
    c990:      	cbz	x1, 0xc9e4 <bytehook_hook_all+0x6c>
    c994:      	mov	x19, x2
    c998:      	cbz	x2, 0xc9e4 <bytehook_hook_all+0x6c>
    c99c:      	adrp	x8, 0x15000
    c9a0:      	ldr	w8, [x8, #0xe24]
    c9a4:      	cbnz	w8, 0xc9e4 <bytehook_hook_all+0x6c>
    c9a8:      	mov	x2, x19
    c9ac:      	mov	w5, wzr
    c9b0:      	mov	x20, x1
    c9b4:      	mov	x22, x30
    c9b8:      	bl	0xaca0 <JNI_OnLoad+0x1b44>
    c9bc:      	mov	x21, x0
    c9c0:      	cbz	x0, 0xc9e4 <bytehook_hook_all+0x6c>
    c9c4:      	mov	x0, x21
    c9c8:      	bl	0xb270 <JNI_OnLoad+0x2114>
    c9cc:      	mov	x0, x21
    c9d0:      	bl	0xb30c <JNI_OnLoad+0x21b0>
    c9d4:      	adrp	x1, 0x2000
    c9d8:      	add	x1, x1, #0x591
    c9dc:      	mov	w0, #0xff               // =255
    c9e0:      	bl	0xcb2c <bytehook_del_dlopen_callback+0x4>
    c9e4:      	mov	x0, x21
    c9e8:      	ldp	x20, x19, [sp, #0x20]
    c9ec:      	ldp	x22, x21, [sp, #0x10]
    c9f0:      	ldp	x29, x30, [sp], #0x30
    c9f4:      	ret

000000000000c9f8 <bytehook_unhook>:
    c9f8:      	sub	sp, sp, #0x40
    c9fc:      	stp	x29, x30, [sp, #0x10]
    ca00:      	stp	x22, x21, [sp, #0x20]
    ca04:      	stp	x20, x19, [sp, #0x30]
    ca08:      	add	x29, sp, #0x10
    ca0c:      	mrs	x22, TPIDR_EL0
    ca10:      	ldr	x8, [x22, #0x28]
    ca14:      	str	x8, [sp, #0x8]
    ca18:      	xpaclri
    ca1c:      	cbz	x0, 0xca60 <bytehook_unhook+0x68>
    ca20:      	adrp	x8, 0x15000
    ca24:      	ldr	w19, [x8, #0xe24]
    ca28:      	cbnz	w19, 0xca64 <bytehook_unhook+0x6c>
    ca2c:      	mov	x20, x30
    ca30:      	mov	x21, x0
    ca34:      	str	x0, [sp]
    ca38:      	bl	0xb2bc <JNI_OnLoad+0x2160>
    ca3c:      	mov	x0, x21
    ca40:      	bl	0xb3dc <JNI_OnLoad+0x2280>
    ca44:      	mov	x1, x21
    ca48:      	mov	x2, x20
    ca4c:      	mov	w19, w0
    ca50:      	bl	0x9a60 <JNI_OnLoad+0x904>
    ca54:      	mov	x0, sp
    ca58:      	bl	0xaccc <JNI_OnLoad+0x1b70>
    ca5c:      	b	0xca64 <bytehook_unhook+0x6c>
    ca60:      	mov	w19, #0xb               // =11
    ca64:      	ldr	x8, [x22, #0x28]
    ca68:      	ldr	x9, [sp, #0x8]
    ca6c:      	cmp	x8, x9
    ca70:      	b.ne	0xca8c <bytehook_unhook+0x94>
    ca74:      	mov	w0, w19
    ca78:      	ldp	x20, x19, [sp, #0x30]
    ca7c:      	ldp	x22, x21, [sp, #0x20]
    ca80:      	ldp	x29, x30, [sp, #0x10]
    ca84:      	add	sp, sp, #0x40
    ca88:      	ret
    ca8c:      	bl	0xd2e0 <__stack_chk_fail@plt>

000000000000ca90 <bytehook_add_ignore>:
    ca90:      	stp	x29, x30, [sp, #-0x10]!
    ca94:      	mov	x29, sp
    ca98:      	bl	0x7a1c <.text+0x2430>
    ca9c:      	cmp	w0, #0x0
    caa0:      	mov	w8, #0x19               // =25
    caa4:      	csel	w0, wzr, w8, eq
    caa8:      	ldp	x29, x30, [sp], #0x10
    caac:      	ret

000000000000cab0 <bytehook_get_debug>:
    cab0:      	b	0x955c <JNI_OnLoad+0x400>

000000000000cab4 <bytehook_set_debug>:
    cab4:      	and	w0, w0, #0x1
    cab8:      	b	0x9574 <JNI_OnLoad+0x418>

000000000000cabc <bytehook_get_recordable>:
    cabc:      	b	0x9594 <JNI_OnLoad+0x438>

000000000000cac0 <bytehook_set_recordable>:
    cac0:      	and	w0, w0, #0x1
    cac4:      	b	0x95a0 <JNI_OnLoad+0x444>

000000000000cac8 <bytehook_get_records>:
    cac8:      	b	0x9b64 <JNI_OnLoad+0xa08>

000000000000cacc <bytehook_dump_records>:
    cacc:      	b	0x9f68 <JNI_OnLoad+0xe0c>

000000000000cad0 <bytehook_get_prev_func>:
    cad0:      	stp	x29, x30, [sp, #-0x10]!
    cad4:      	mov	x29, sp
    cad8:      	bl	0xcb40 <bytehook_del_dlopen_callback+0x18>
    cadc:      	b.eq	0xcae8 <bytehook_get_prev_func+0x18>
    cae0:      	ldp	x29, x30, [sp], #0x10
    cae4:      	b	0x8fd8 <.text+0x39ec>
    cae8:      	bl	0xd4d0 <abort@plt>

000000000000caec <bytehook_get_return_address>:
    caec:      	stp	x29, x30, [sp, #-0x10]!
    caf0:      	mov	x29, sp
    caf4:      	bl	0xcb40 <bytehook_del_dlopen_callback+0x18>
    caf8:      	b.eq	0xcb04 <bytehook_get_return_address+0x18>
    cafc:      	ldp	x29, x30, [sp], #0x10
    cb00:      	b	0x9060 <.text+0x3a74>
    cb04:      	bl	0xd4d0 <abort@plt>

000000000000cb08 <bytehook_pop_stack>:
    cb08:      	stp	x29, x30, [sp, #-0x10]!
    cb0c:      	mov	x29, sp
    cb10:      	bl	0xcb40 <bytehook_del_dlopen_callback+0x18>
    cb14:      	b.eq	0xcb20 <bytehook_pop_stack+0x18>
    cb18:      	ldp	x29, x30, [sp], #0x10
    cb1c:      	b	0x8890 <.text+0x32a4>
    cb20:      	bl	0xd4d0 <abort@plt>

000000000000cb24 <bytehook_add_dlopen_callback>:
    cb24:      	b	0x61f4 <.text+0xc08>

000000000000cb28 <bytehook_del_dlopen_callback>:
    cb28:      	b	0x62b8 <.text+0xccc>
    cb2c:      	mov	x2, x20
    cb30:      	mov	x3, x19
    cb34:      	mov	x4, x21
    cb38:      	mov	x5, x22
    cb3c:      	b	0x95b0 <JNI_OnLoad+0x454>
    cb40:      	adrp	x8, 0x15000
    cb44:      	ldr	w8, [x8, #0xe28]
    cb48:      	cmp	w8, #0x1
    cb4c:      	ret
    cb50:      	stp	x29, x30, [sp, #-0x30]!
    cb54:      	str	x21, [sp, #0x10]
    cb58:      	stp	x20, x19, [sp, #0x20]
    cb5c:      	mov	x29, sp
    cb60:      	adrp	x0, 0x2000
    cb64:      	add	x0, x0, #0x7cf
    cb68:      	mov	w1, wzr
    cb6c:      	bl	0xd280 <dlopen@plt>
    cb70:      	cbz	x0, 0xcc2c <bytehook_del_dlopen_callback+0x104>
    cb74:      	adrp	x8, 0x11000 <siglongjmp@plt+0x3870>
    cb78:      	adrp	x9, 0x11000 <siglongjmp@plt+0x3870>
    cb7c:      	adrp	x10, 0x11000 <siglongjmp@plt+0x3870>
    cb80:      	adrp	x11, 0x11000 <siglongjmp@plt+0x3870>
    cb84:      	ldr	x8, [x8, #0xae8]
    cb88:      	ldr	x9, [x9, #0xaf0]
    cb8c:      	ldr	x10, [x10, #0xaf8]
    cb90:      	ldr	x11, [x11, #0xb00]
    cb94:      	mov	x19, x0
    cb98:      	adrp	x21, 0x16000
    cb9c:      	adrp	x20, 0x16000
    cba0:      	cmp	x11, #0x0
    cba4:      	ccmp	x10, #0x0, #0x4, ne
    cba8:      	ccmp	x9, #0x0, #0x4, ne
    cbac:      	ccmp	x8, #0x0, #0x4, ne
    cbb0:      	b.eq	0xcbf8 <bytehook_del_dlopen_callback+0xd0>
    cbb4:      	adrp	x1, 0x2000
    cbb8:      	add	x1, x1, #0x781
    cbbc:      	bl	0xd168 <bytehook_del_dlopen_callback+0x640>
    cbc0:      	str	x0, [x21, #0x160]
    cbc4:      	cbz	x0, 0xcbf8 <bytehook_del_dlopen_callback+0xd0>
    cbc8:      	adrp	x1, 0x2000
    cbcc:      	add	x1, x1, #0x595
    cbd0:      	bl	0xd168 <bytehook_del_dlopen_callback+0x640>
    cbd4:      	str	x0, [x20, #0x168]
    cbd8:      	cbz	x0, 0xcbf8 <bytehook_del_dlopen_callback+0xd0>
    cbdc:      	adrp	x8, 0x16000
    cbe0:      	mov	w9, #0x2                // =2
    cbe4:      	str	w9, [x8, #0x158]
    cbe8:      	mov	x0, x19
    cbec:      	bl	0xd15c <bytehook_del_dlopen_callback+0x634>
    cbf0:      	ldp	x29, x30, [sp], #0x30
    cbf4:      	b	0xd2a0 <dlclose@plt>
    cbf8:      	adrp	x1, 0x2000
    cbfc:      	add	x1, x1, #0xcf0
    cc00:      	bl	0xd168 <bytehook_del_dlopen_callback+0x640>
    cc04:      	str	x0, [x21, #0x160]
    cc08:      	cbz	x0, 0xcbe8 <bytehook_del_dlopen_callback+0xc0>
    cc0c:      	adrp	x1, 0x2000
    cc10:      	add	x1, x1, #0xa09
    cc14:      	bl	0xd168 <bytehook_del_dlopen_callback+0x640>
    cc18:      	str	x0, [x20, #0x168]
    cc1c:      	cbz	x0, 0xcbe8 <bytehook_del_dlopen_callback+0xc0>
    cc20:      	adrp	x8, 0x16000
    cc24:      	mov	w9, #0x1                // =1
    cc28:      	b	0xcbe4 <bytehook_del_dlopen_callback+0xbc>
    cc2c:      	bl	0xd15c <bytehook_del_dlopen_callback+0x634>
    cc30:      	ldp	x29, x30, [sp], #0x30
    cc34:      	ret
    cc38:      	sub	sp, sp, #0x80
    cc3c:      	stp	x29, x30, [sp, #0x30]
    cc40:      	str	x25, [sp, #0x40]
    cc44:      	stp	x24, x23, [sp, #0x50]
    cc48:      	stp	x22, x21, [sp, #0x60]
    cc4c:      	stp	x20, x19, [sp, #0x70]
    cc50:      	add	x29, sp, #0x30
    cc54:      	mrs	x22, TPIDR_EL0
    cc58:      	ldr	x8, [x22, #0x28]
    cc5c:      	adrp	x25, 0x16000
    cc60:      	mov	w21, #-0x1              // =-1
    cc64:      	stur	x8, [x29, #-0x8]
    cc68:      	ldr	w8, [x25, #0x158]
    cc6c:      	cbz	w8, 0xcd44 <bytehook_del_dlopen_callback+0x21c>
    cc70:      	cmp	w0, #0x13
    cc74:      	sub	w8, w0, #0x1
    cc78:      	ccmp	w0, #0x9, #0x4, ne
    cc7c:      	mov	w19, w0
    cc80:      	ccmp	w8, #0x1e, #0x2, ne
    cc84:      	b.hi	0xcd44 <bytehook_del_dlopen_callback+0x21c>
    cc88:      	adrp	x23, 0x16000
    cc8c:      	add	x23, x23, #0x158
    cc90:      	add	x8, x23, w19, sxtw #3
    cc94:      	ldr	x8, [x8, #0x40]
    cc98:      	cbnz	x8, 0xcd74 <bytehook_del_dlopen_callback+0x24c>
    cc9c:      	add	x0, x23, #0x18
    cca0:      	sxtw	x24, w19
    cca4:      	bl	0xd3b0 <pthread_mutex_lock@plt>
    cca8:      	add	x8, x23, x24, lsl #3
    ccac:      	ldr	x8, [x8, #0x40]
    ccb0:      	cbnz	x8, 0xcd84 <bytehook_del_dlopen_callback+0x25c>
    ccb4:      	mov	w0, #0x1                // =1
    ccb8:      	mov	w1, #0xc20              // =3104
    ccbc:      	bl	0xd300 <calloc@plt>
    ccc0:      	cbz	x0, 0xcd84 <bytehook_del_dlopen_callback+0x25c>
    ccc4:      	ldr	w8, [x25, #0x158]
    ccc8:      	mov	w21, #0x804             // =2052
    cccc:      	mov	x20, x0
    ccd0:      	movk	w21, #0x1800, lsl #16
    ccd4:      	cmp	w8, #0x2
    ccd8:      	movi	v0.2d, #0000000000000000
    ccdc:      	mov	x8, sp
    cce0:      	b.ne	0xccf4 <bytehook_del_dlopen_callback+0x1cc>
    cce4:      	add	x0, x8, #0x10
    cce8:      	stp	q0, q0, [sp]
    ccec:      	bl	0xd710 <sigfillset64@plt>
    ccf0:      	b	0xcd00 <bytehook_del_dlopen_callback+0x1d8>
    ccf4:      	add	x0, x8, #0x10
    ccf8:      	stp	q0, q0, [sp]
    ccfc:      	bl	0xd720 <sigfillset@plt>
    cd00:      	adrp	x9, 0x16000
    cd04:      	ldr	x9, [x9, #0x160]
    cd08:      	adrp	x8, 0xc000 <JNI_OnLoad+0x2ea4>
    cd0c:      	add	x8, x8, #0xd90
    cd10:      	add	x2, x20, #0xc00
    cd14:      	mov	x1, sp
    cd18:      	mov	w0, w19
    cd1c:      	str	x8, [sp, #0x8]
    cd20:      	str	w21, [sp]
    cd24:      	blr	x9
    cd28:      	cbnz	w0, 0xcd7c <bytehook_del_dlopen_callback+0x254>
    cd2c:      	mov	w21, wzr
    cd30:      	add	x8, x23, x24, lsl #3
    cd34:      	str	x20, [x8, #0x40]
    cd38:      	adrp	x0, 0x16000
    cd3c:      	add	x0, x0, #0x170
    cd40:      	bl	0xd3e0 <pthread_mutex_unlock@plt>
    cd44:      	ldr	x8, [x22, #0x28]
    cd48:      	ldur	x9, [x29, #-0x8]
    cd4c:      	cmp	x8, x9
    cd50:      	b.ne	0xcd8c <bytehook_del_dlopen_callback+0x264>
    cd54:      	mov	w0, w21
    cd58:      	ldp	x20, x19, [sp, #0x70]
    cd5c:      	ldp	x22, x21, [sp, #0x60]
    cd60:      	ldp	x24, x23, [sp, #0x50]
    cd64:      	ldr	x25, [sp, #0x40]
    cd68:      	ldp	x29, x30, [sp, #0x30]
    cd6c:      	add	sp, sp, #0x80
    cd70:      	ret
    cd74:      	mov	w21, #-0x1              // =-1
    cd78:      	b	0xcd44 <bytehook_del_dlopen_callback+0x21c>
    cd7c:      	mov	x0, x20
    cd80:      	bl	0xd260 <free@plt>
    cd84:      	mov	w21, #-0x1              // =-1
    cd88:      	b	0xcd38 <bytehook_del_dlopen_callback+0x210>
    cd8c:      	bl	0xd2e0 <__stack_chk_fail@plt>
    cd90:      	stp	x29, x30, [sp, #-0x30]!
    cd94:      	str	x21, [sp, #0x10]
    cd98:      	stp	x20, x19, [sp, #0x20]
    cd9c:      	mov	x29, sp
    cda0:      	mov	x20, x2
    cda4:      	mov	x21, x1
    cda8:      	mov	w19, w0
    cdac:      	bl	0xcf38 <bytehook_del_dlopen_callback+0x410>
    cdb0:      	adrp	x9, 0x16000
    cdb4:      	add	x9, x9, #0x158
    cdb8:      	add	x8, x9, w19, sxtw #3
    cdbc:      	ldr	x8, [x8, #0x40]
    cdc0:      	ldr	w10, [x9]
    cdc4:      	ldr	w9, [x8, #0xc00]
    cdc8:      	cmp	w10, #0x2
    cdcc:      	tbz	w9, #0x2, 0xcdec <bytehook_del_dlopen_callback+0x2c4>
    cdd0:      	ldr	x3, [x8, #0xc08]
    cdd4:      	mov	w0, w19
    cdd8:      	mov	x1, x21
    cddc:      	mov	x2, x20
    cde0:      	bl	0xd15c <bytehook_del_dlopen_callback+0x634>
    cde4:      	ldp	x29, x30, [sp], #0x30
    cde8:      	br	x3
    cdec:      	ldr	x1, [x8, #0xc08]
    cdf0:      	cmp	x1, #0x2
    cdf4:      	b.hs	0xce04 <bytehook_del_dlopen_callback+0x2dc>
    cdf8:      	bl	0xd15c <bytehook_del_dlopen_callback+0x634>
    cdfc:      	ldp	x29, x30, [sp], #0x30
    ce00:      	ret
    ce04:      	mov	w0, w19
    ce08:      	bl	0xd15c <bytehook_del_dlopen_callback+0x634>
    ce0c:      	ldp	x29, x30, [sp], #0x30
    ce10:      	br	x1
    ce14:      	adrp	x9, 0x16000
    ce18:      	mov	x8, xzr
    ce1c:      	add	x9, x9, #0x158
    ce20:      	cmp	x8, x3
    ce24:      	b.eq	0xceb0 <bytehook_del_dlopen_callback+0x388>
    ce28:      	ldr	w10, [x2, x8, lsl #2]
    ce2c:      	sub	w11, w10, #0x1
    ce30:      	cmp	w11, #0x1e
    ce34:      	ccmp	w10, #0x9, #0x4, ls
    ce38:      	ccmp	w10, #0x13, #0x4, ne
    ce3c:      	b.ne	0xce48 <bytehook_del_dlopen_callback+0x320>
    ce40:      	add	x8, x8, #0x1
    ce44:      	b	0xce20 <bytehook_del_dlopen_callback+0x2f8>
    ce48:      	add	x10, x9, x10, lsl #3
    ce4c:      	ldr	x10, [x10, #0x40]
    ce50:      	cbz	x10, 0xce40 <bytehook_del_dlopen_callback+0x318>
    ce54:      	mov	x11, xzr
    ce58:      	cmp	x11, #0x400
    ce5c:      	b.eq	0xce74 <bytehook_del_dlopen_callback+0x34c>
    ce60:      	ldr	w12, [x10, x11]
    ce64:      	add	x11, x11, #0x4
    ce68:      	cmp	w12, w0
    ce6c:      	b.ne	0xce58 <bytehook_del_dlopen_callback+0x330>
    ce70:      	b	0xce40 <bytehook_del_dlopen_callback+0x318>
    ce74:      	mov	x11, xzr
    ce78:      	add	x12, x10, x11, lsl #2
    ce7c:      	ldxr	w13, [x12]
    ce80:      	cbnz	w13, 0xce90 <bytehook_del_dlopen_callback+0x368>
    ce84:      	stlxr	w13, w0, [x12]
    ce88:      	cbnz	w13, 0xce7c <bytehook_del_dlopen_callback+0x354>
    ce8c:      	b	0xcea4 <bytehook_del_dlopen_callback+0x37c>
    ce90:      	clrex
    ce94:      	add	x12, x11, #0x1
    ce98:      	cmp	x12, #0x100
    ce9c:      	csinc	x11, xzr, x11, eq
    cea0:      	b	0xce78 <bytehook_del_dlopen_callback+0x350>
    cea4:      	add	x10, x10, x11, lsl #3
    cea8:      	str	x1, [x10, #0x400]
    ceac:      	b	0xce40 <bytehook_del_dlopen_callback+0x318>
    ceb0:      	ret
    ceb4:      	adrp	x9, 0x16000
    ceb8:      	mov	x8, xzr
    cebc:      	add	x9, x9, #0x158
    cec0:      	cmp	x8, x2
    cec4:      	b.eq	0xcf34 <bytehook_del_dlopen_callback+0x40c>
    cec8:      	ldr	w10, [x1, x8, lsl #2]
    cecc:      	sub	w11, w10, #0x1
    ced0:      	cmp	w11, #0x1e
    ced4:      	ccmp	w10, #0x9, #0x4, ls
    ced8:      	ccmp	w10, #0x13, #0x4, ne
    cedc:      	b.ne	0xcee8 <bytehook_del_dlopen_callback+0x3c0>
    cee0:      	add	x8, x8, #0x1
    cee4:      	b	0xcec0 <bytehook_del_dlopen_callback+0x398>
    cee8:      	add	x10, x9, x10, lsl #3
    ceec:      	ldr	x10, [x10, #0x40]
    cef0:      	cbz	x10, 0xcee0 <bytehook_del_dlopen_callback+0x3b8>
    cef4:      	mov	x11, xzr
    cef8:      	cmp	x11, #0x100
    cefc:      	b.eq	0xcee0 <bytehook_del_dlopen_callback+0x3b8>
    cf00:      	add	x12, x10, x11, lsl #2
    cf04:      	ldxr	w13, [x12]
    cf08:      	cmp	w13, w0
    cf0c:      	b.ne	0xcf20 <bytehook_del_dlopen_callback+0x3f8>
    cf10:      	stlxr	w13, wzr, [x12]
    cf14:      	cbnz	w13, 0xcf04 <bytehook_del_dlopen_callback+0x3dc>
    cf18:      	mov	w12, #0x1               // =1
    cf1c:      	b	0xcf28 <bytehook_del_dlopen_callback+0x400>
    cf20:      	clrex
    cf24:      	mov	w12, wzr
    cf28:      	add	x11, x11, #0x1
    cf2c:      	cbz	w12, 0xcef8 <bytehook_del_dlopen_callback+0x3d0>
    cf30:      	b	0xcee0 <bytehook_del_dlopen_callback+0x3b8>
    cf34:      	ret
    cf38:      	sub	sp, sp, #0x60
    cf3c:      	stp	x29, x30, [sp, #0x10]
    cf40:      	str	x25, [sp, #0x20]
    cf44:      	stp	x24, x23, [sp, #0x30]
    cf48:      	stp	x22, x21, [sp, #0x40]
    cf4c:      	stp	x20, x19, [sp, #0x50]
    cf50:      	add	x29, sp, #0x10
    cf54:      	mrs	x23, TPIDR_EL0
    cf58:      	ldr	x8, [x23, #0x28]
    cf5c:      	adrp	x9, 0x16000
    cf60:      	add	x9, x9, #0x158
    cf64:      	mov	x20, x2
    cf68:      	str	x8, [sp, #0x8]
    cf6c:      	add	x8, x9, w0, sxtw #3
    cf70:      	ldr	x24, [x8, #0x40]
    cf74:      	mov	w19, w0
    cf78:      	mov	x21, x1
    cf7c:      	bl	0xd2b0 <gettid@plt>
    cf80:      	cbz	w0, 0xd14c <bytehook_del_dlopen_callback+0x624>
    cf84:      	mov	x8, xzr
    cf88:      	cmp	x8, #0x100
    cf8c:      	b.eq	0xcfa8 <bytehook_del_dlopen_callback+0x480>
    cf90:      	add	x9, x24, x8, lsl #2
    cf94:      	ldar	w9, [x9]
    cf98:      	cmp	w0, w9
    cf9c:      	b.eq	0xd114 <bytehook_del_dlopen_callback+0x5ec>
    cfa0:      	add	x8, x8, #0x1
    cfa4:      	b	0xcf88 <bytehook_del_dlopen_callback+0x460>
    cfa8:      	adrp	x8, 0x16000
    cfac:      	ldr	w8, [x8, #0x158]
    cfb0:      	add	x20, x20, #0x28
    cfb4:      	add	x21, x24, #0xc10
    cfb8:      	mov	x0, sp
    cfbc:      	cmp	w8, #0x2
    cfc0:      	b.ne	0xd04c <bytehook_del_dlopen_callback+0x524>
    cfc4:      	bl	0xd730 <sigemptyset64@plt>
    cfc8:      	mov	x25, #-0x3f             // =-63
    cfcc:      	cbz	x25, 0xd010 <bytehook_del_dlopen_callback+0x4e8>
    cfd0:      	add	x22, x25, #0x40
    cfd4:      	mov	x0, x20
    cfd8:      	mov	w1, w22
    cfdc:      	bl	0xd740 <sigismember64@plt>
    cfe0:      	cmp	w0, #0x1
    cfe4:      	b.eq	0xcffc <bytehook_del_dlopen_callback+0x4d4>
    cfe8:      	mov	x0, x21
    cfec:      	mov	w1, w22
    cff0:      	bl	0xd740 <sigismember64@plt>
    cff4:      	cmp	w0, #0x1
    cff8:      	b.ne	0xd008 <bytehook_del_dlopen_callback+0x4e0>
    cffc:      	mov	x0, sp
    d000:      	mov	w1, w22
    d004:      	bl	0xd750 <sigaddset64@plt>
    d008:      	add	x25, x25, #0x1
    d00c:      	cbnz	x25, 0xcfd0 <bytehook_del_dlopen_callback+0x4a8>
    d010:      	ldrb	w8, [x24, #0xc03]
    d014:      	tbnz	w8, #0x6, 0xd024 <bytehook_del_dlopen_callback+0x4fc>
    d018:      	mov	x0, sp
    d01c:      	mov	w1, w19
    d020:      	bl	0xd750 <sigaddset64@plt>
    d024:      	mov	x0, sp
    d028:      	mov	w1, #0xd                // =13
    d02c:      	bl	0xd750 <sigaddset64@plt>
    d030:      	mov	x0, sp
    d034:      	mov	w1, #0xa                // =10
    d038:      	bl	0xd750 <sigaddset64@plt>
    d03c:      	mov	x0, sp
    d040:      	mov	w1, #0x3                // =3
    d044:      	bl	0xd750 <sigaddset64@plt>
    d048:      	b	0xd0d0 <bytehook_del_dlopen_callback+0x5a8>
    d04c:      	bl	0xd760 <sigemptyset@plt>
    d050:      	mov	x25, #-0x3f             // =-63
    d054:      	cbz	x25, 0xd098 <bytehook_del_dlopen_callback+0x570>
    d058:      	add	x22, x25, #0x40
    d05c:      	mov	x0, x20
    d060:      	mov	w1, w22
    d064:      	bl	0xd770 <sigismember@plt>
    d068:      	cmp	w0, #0x1
    d06c:      	b.eq	0xd084 <bytehook_del_dlopen_callback+0x55c>
    d070:      	mov	x0, x21
    d074:      	mov	w1, w22
    d078:      	bl	0xd770 <sigismember@plt>
    d07c:      	cmp	w0, #0x1
    d080:      	b.ne	0xd090 <bytehook_del_dlopen_callback+0x568>
    d084:      	mov	x0, sp
    d088:      	mov	w1, w22
    d08c:      	bl	0xd780 <sigaddset@plt>
    d090:      	add	x25, x25, #0x1
    d094:      	cbnz	x25, 0xd058 <bytehook_del_dlopen_callback+0x530>
    d098:      	ldrb	w8, [x24, #0xc03]
    d09c:      	tbnz	w8, #0x6, 0xd0ac <bytehook_del_dlopen_callback+0x584>
    d0a0:      	mov	x0, sp
    d0a4:      	mov	w1, w19
    d0a8:      	bl	0xd780 <sigaddset@plt>
    d0ac:      	mov	x0, sp
    d0b0:      	mov	w1, #0xd                // =13
    d0b4:      	bl	0xd780 <sigaddset@plt>
    d0b8:      	mov	x0, sp
    d0bc:      	mov	w1, #0xa                // =10
    d0c0:      	bl	0xd780 <sigaddset@plt>
    d0c4:      	mov	x0, sp
    d0c8:      	mov	w1, #0x3                // =3
    d0cc:      	bl	0xd780 <sigaddset@plt>
    d0d0:      	adrp	x8, 0x16000
    d0d4:      	ldr	x8, [x8, #0x168]
    d0d8:      	mov	x1, sp
    d0dc:      	mov	w0, #0x2                // =2
    d0e0:      	mov	x2, xzr
    d0e4:      	blr	x8
    d0e8:      	ldr	x8, [x23, #0x28]
    d0ec:      	ldr	x9, [sp, #0x8]
    d0f0:      	cmp	x8, x9
    d0f4:      	b.ne	0xd158 <bytehook_del_dlopen_callback+0x630>
    d0f8:      	ldp	x20, x19, [sp, #0x50]
    d0fc:      	ldp	x22, x21, [sp, #0x40]
    d100:      	ldp	x24, x23, [sp, #0x30]
    d104:      	ldr	x25, [sp, #0x20]
    d108:      	ldp	x29, x30, [sp, #0x10]
    d10c:      	add	sp, sp, #0x60
    d110:      	ret
    d114:      	ldr	w9, [x21, #0x8]
    d118:      	cmp	w9, #0x1
    d11c:      	b.lt	0xd128 <bytehook_del_dlopen_callback+0x600>
    d120:      	ubfiz	w1, w9, #8, #8
    d124:      	b	0xd13c <bytehook_del_dlopen_callback+0x614>
    d128:      	tbz	w9, #0x1f, 0xd138 <bytehook_del_dlopen_callback+0x610>
    d12c:      	neg	w9, w9
    d130:      	and	w1, w9, #0xff
    d134:      	b	0xd13c <bytehook_del_dlopen_callback+0x614>
    d138:      	mov	w1, wzr
    d13c:      	add	x8, x24, x8, lsl #3
    d140:      	ldr	x0, [x8, #0x400]
    d144:      	bfi	w1, w19, #16, #8
    d148:      	bl	0xd790 <siglongjmp@plt>
    d14c:      	mov	w0, #0xb2               // =178
    d150:      	bl	0xd2c0 <syscall@plt>
    d154:      	b	0xcf84 <bytehook_del_dlopen_callback+0x45c>
    d158:      	bl	0xd2e0 <__stack_chk_fail@plt>
    d15c:      	ldp	x20, x19, [sp, #0x20]
    d160:      	ldr	x21, [sp, #0x10]
    d164:      	ret
    d168:      	mov	x0, x19
    d16c:      	b	0xd290 <dlsym@plt>
    d170:      	bti	c
    d174:      	adrp	x8, 0x16000
    d178:      	ldr	x9, [x8, #0x298]
    d17c:      	cbz	x9, 0xd188 <bytehook_del_dlopen_callback+0x660>
    d180:      	tbz	w9, #0x1c, 0xd194 <bytehook_del_dlopen_callback+0x66c>
    d184:      	b	0xd1c0 <bytehook_del_dlopen_callback+0x698>
    d188:      	mrs	x9, CTR_EL0
    d18c:      	str	x9, [x8, #0x298]
    d190:      	tbnz	w9, #0x1c, 0xd1c0 <bytehook_del_dlopen_callback+0x698>
    d194:      	ubfx	w9, w9, #16, #4
    d198:      	mov	w10, #0x4               // =4
    d19c:      	lsl	w9, w10, w9
    d1a0:      	neg	x10, x9
    d1a4:      	and	x10, x10, x0
    d1a8:      	cmp	x10, x1
    d1ac:      	b.hs	0xd1c0 <bytehook_del_dlopen_callback+0x698>
    d1b0:      	dc	cvau, x10
    d1b4:      	add	x10, x10, x9
    d1b8:      	cmp	x10, x1
    d1bc:      	b.lo	0xd1b0 <bytehook_del_dlopen_callback+0x688>
    d1c0:      	dsb	ish
    d1c4:      	ldr	x8, [x8, #0x298]
    d1c8:      	tbnz	w8, #0x1d, 0xd1f8 <bytehook_del_dlopen_callback+0x6d0>
    d1cc:      	and	w8, w8, #0xf
    d1d0:      	mov	w9, #0x4                // =4
    d1d4:      	lsl	w8, w9, w8
    d1d8:      	neg	x9, x8
    d1dc:      	and	x9, x9, x0
    d1e0:      	cmp	x9, x1
    d1e4:      	b.hs	0xd1f8 <bytehook_del_dlopen_callback+0x6d0>
    d1e8:      	ic	ivau, x9
    d1ec:      	add	x9, x9, x8
    d1f0:      	cmp	x9, x1
    d1f4:      	b.lo	0xd1e8 <bytehook_del_dlopen_callback+0x6c0>
    d1f8:      	dsb	ish
    d1fc:      	isb
    d200:      	ret

Disassembly of section .plt:

000000000000d210 <.plt>:
    d210:      	stp	x16, x30, [sp, #-0x10]!
    d214:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d218:      	ldr	x17, [x16, #0xb18]
    d21c:      	add	x16, x16, #0xb18
    d220:      	br	x17
    d224:      	nop
    d228:      	nop
    d22c:      	nop

000000000000d230 <__cxa_finalize@plt>:
    d230:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d234:      	ldr	x17, [x16, #0xb20]
    d238:      	add	x16, x16, #0xb20
    d23c:      	br	x17

000000000000d240 <__cxa_atexit@plt>:
    d240:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d244:      	ldr	x17, [x16, #0xb28]
    d248:      	add	x16, x16, #0xb28
    d24c:      	br	x17

000000000000d250 <realloc@plt>:
    d250:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d254:      	ldr	x17, [x16, #0xb30]
    d258:      	add	x16, x16, #0xb30
    d25c:      	br	x17

000000000000d260 <free@plt>:
    d260:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d264:      	ldr	x17, [x16, #0xb38]
    d268:      	add	x16, x16, #0xb38
    d26c:      	br	x17

000000000000d270 <malloc@plt>:
    d270:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d274:      	ldr	x17, [x16, #0xb40]
    d278:      	add	x16, x16, #0xb40
    d27c:      	br	x17

000000000000d280 <dlopen@plt>:
    d280:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d284:      	ldr	x17, [x16, #0xb48]
    d288:      	add	x16, x16, #0xb48
    d28c:      	br	x17

000000000000d290 <dlsym@plt>:
    d290:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d294:      	ldr	x17, [x16, #0xb50]
    d298:      	add	x16, x16, #0xb50
    d29c:      	br	x17

000000000000d2a0 <dlclose@plt>:
    d2a0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d2a4:      	ldr	x17, [x16, #0xb58]
    d2a8:      	add	x16, x16, #0xb58
    d2ac:      	br	x17

000000000000d2b0 <gettid@plt>:
    d2b0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d2b4:      	ldr	x17, [x16, #0xb60]
    d2b8:      	add	x16, x16, #0xb60
    d2bc:      	br	x17

000000000000d2c0 <syscall@plt>:
    d2c0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d2c4:      	ldr	x17, [x16, #0xb68]
    d2c8:      	add	x16, x16, #0xb68
    d2cc:      	br	x17

000000000000d2d0 <sigsetjmp@plt>:
    d2d0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d2d4:      	ldr	x17, [x16, #0xb70]
    d2d8:      	add	x16, x16, #0xb70
    d2dc:      	br	x17

000000000000d2e0 <__stack_chk_fail@plt>:
    d2e0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d2e4:      	ldr	x17, [x16, #0xb78]
    d2e8:      	add	x16, x16, #0xb78
    d2ec:      	br	x17

000000000000d2f0 <getauxval@plt>:
    d2f0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d2f4:      	ldr	x17, [x16, #0xb80]
    d2f8:      	add	x16, x16, #0xb80
    d2fc:      	br	x17

000000000000d300 <calloc@plt>:
    d300:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d304:      	ldr	x17, [x16, #0xb88]
    d308:      	add	x16, x16, #0xb88
    d30c:      	br	x17

000000000000d310 <__open_2@plt>:
    d310:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d314:      	ldr	x17, [x16, #0xb90]
    d318:      	add	x16, x16, #0xb90
    d31c:      	br	x17

000000000000d320 <fstat@plt>:
    d320:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d324:      	ldr	x17, [x16, #0xb98]
    d328:      	add	x16, x16, #0xb98
    d32c:      	br	x17

000000000000d330 <close@plt>:
    d330:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d334:      	ldr	x17, [x16, #0xba0]
    d338:      	add	x16, x16, #0xba0
    d33c:      	br	x17

000000000000d340 <strcmp@plt>:
    d340:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d344:      	ldr	x17, [x16, #0xba8]
    d348:      	add	x16, x16, #0xba8
    d34c:      	br	x17

000000000000d350 <strncmp@plt>:
    d350:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d354:      	ldr	x17, [x16, #0xbb0]
    d358:      	add	x16, x16, #0xbb0
    d35c:      	br	x17

000000000000d360 <lseek@plt>:
    d360:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d364:      	ldr	x17, [x16, #0xbb8]
    d368:      	add	x16, x16, #0xbb8
    d36c:      	br	x17

000000000000d370 <__errno@plt>:
    d370:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d374:      	ldr	x17, [x16, #0xbc0]
    d378:      	add	x16, x16, #0xbc0
    d37c:      	br	x17

000000000000d380 <__read_chk@plt>:
    d380:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d384:      	ldr	x17, [x16, #0xbc8]
    d388:      	add	x16, x16, #0xbc8
    d38c:      	br	x17

000000000000d390 <dl_iterate_phdr@plt>:
    d390:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d394:      	ldr	x17, [x16, #0xbd0]
    d398:      	add	x16, x16, #0xbd0
    d39c:      	br	x17

000000000000d3a0 <__android_log_print@plt>:
    d3a0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d3a4:      	ldr	x17, [x16, #0xbd8]
    d3a8:      	add	x16, x16, #0xbd8
    d3ac:      	br	x17

000000000000d3b0 <pthread_mutex_lock@plt>:
    d3b0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d3b4:      	ldr	x17, [x16, #0xbe0]
    d3b8:      	add	x16, x16, #0xbe0
    d3bc:      	br	x17

000000000000d3c0 <pthread_key_create@plt>:
    d3c0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d3c4:      	ldr	x17, [x16, #0xbe8]
    d3c8:      	add	x16, x16, #0xbe8
    d3cc:      	br	x17

000000000000d3d0 <bytehook_get_mode@plt>:
    d3d0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d3d4:      	ldr	x17, [x16, #0xbf0]
    d3d8:      	add	x16, x16, #0xbf0
    d3dc:      	br	x17

000000000000d3e0 <pthread_mutex_unlock@plt>:
    d3e0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d3e4:      	ldr	x17, [x16, #0xbf8]
    d3e8:      	add	x16, x16, #0xbf8
    d3ec:      	br	x17

000000000000d3f0 <pthread_rwlock_unlock@plt>:
    d3f0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d3f4:      	ldr	x17, [x16, #0xc00]
    d3f8:      	add	x16, x16, #0xc00
    d3fc:      	br	x17

000000000000d400 <bytehook_get_prev_func@plt>:
    d400:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d404:      	ldr	x17, [x16, #0xc08]
    d408:      	add	x16, x16, #0xc08
    d40c:      	br	x17

000000000000d410 <bytehook_get_return_address@plt>:
    d410:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d414:      	ldr	x17, [x16, #0xc10]
    d418:      	add	x16, x16, #0xc10
    d41c:      	br	x17

000000000000d420 <bytehook_pop_stack@plt>:
    d420:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d424:      	ldr	x17, [x16, #0xc18]
    d428:      	add	x16, x16, #0xc18
    d42c:      	br	x17

000000000000d430 <pthread_rwlock_rdlock@plt>:
    d430:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d434:      	ldr	x17, [x16, #0xc20]
    d438:      	add	x16, x16, #0xc20
    d43c:      	br	x17

000000000000d440 <pthread_getspecific@plt>:
    d440:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d444:      	ldr	x17, [x16, #0xc28]
    d448:      	add	x16, x16, #0xc28
    d44c:      	br	x17

000000000000d450 <pthread_setspecific@plt>:
    d450:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d454:      	ldr	x17, [x16, #0xc30]
    d458:      	add	x16, x16, #0xc30
    d45c:      	br	x17

000000000000d460 <__vsnprintf_chk@plt>:
    d460:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d464:      	ldr	x17, [x16, #0xc38]
    d468:      	add	x16, x16, #0xc38
    d46c:      	br	x17

000000000000d470 <pthread_rwlock_wrlock@plt>:
    d470:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d474:      	ldr	x17, [x16, #0xc40]
    d478:      	add	x16, x16, #0xc40
    d47c:      	br	x17

000000000000d480 <strdup@plt>:
    d480:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d484:      	ldr	x17, [x16, #0xc48]
    d488:      	add	x16, x16, #0xc48
    d48c:      	br	x17

000000000000d490 <pthread_mutex_init@plt>:
    d490:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d494:      	ldr	x17, [x16, #0xc50]
    d498:      	add	x16, x16, #0xc50
    d49c:      	br	x17

000000000000d4a0 <pthread_cond_init@plt>:
    d4a0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d4a4:      	ldr	x17, [x16, #0xc58]
    d4a8:      	add	x16, x16, #0xc58
    d4ac:      	br	x17

000000000000d4b0 <pthread_mutex_destroy@plt>:
    d4b0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d4b4:      	ldr	x17, [x16, #0xc60]
    d4b8:      	add	x16, x16, #0xc60
    d4bc:      	br	x17

000000000000d4c0 <pthread_cond_destroy@plt>:
    d4c0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d4c4:      	ldr	x17, [x16, #0xc68]
    d4c8:      	add	x16, x16, #0xc68
    d4cc:      	br	x17

000000000000d4d0 <abort@plt>:
    d4d0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d4d4:      	ldr	x17, [x16, #0xc70]
    d4d8:      	add	x16, x16, #0xc70
    d4dc:      	br	x17

000000000000d4e0 <pthread_cond_signal@plt>:
    d4e0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d4e4:      	ldr	x17, [x16, #0xc78]
    d4e8:      	add	x16, x16, #0xc78
    d4ec:      	br	x17

000000000000d4f0 <gettimeofday@plt>:
    d4f0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d4f4:      	ldr	x17, [x16, #0xc80]
    d4f8:      	add	x16, x16, #0xc80
    d4fc:      	br	x17

000000000000d500 <pthread_cond_wait@plt>:
    d500:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d504:      	ldr	x17, [x16, #0xc88]
    d508:      	add	x16, x16, #0xc88
    d50c:      	br	x17

000000000000d510 <memcpy@plt>:
    d510:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d514:      	ldr	x17, [x16, #0xc90]
    d518:      	add	x16, x16, #0xc90
    d51c:      	br	x17

000000000000d520 <bytehook_get_version@plt>:
    d520:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d524:      	ldr	x17, [x16, #0xc98]
    d528:      	add	x16, x16, #0xc98
    d52c:      	br	x17

000000000000d530 <bytehook_init@plt>:
    d530:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d534:      	ldr	x17, [x16, #0xca0]
    d538:      	add	x16, x16, #0xca0
    d53c:      	br	x17

000000000000d540 <bytehook_add_ignore@plt>:
    d540:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d544:      	ldr	x17, [x16, #0xca8]
    d548:      	add	x16, x16, #0xca8
    d54c:      	br	x17

000000000000d550 <bytehook_get_debug@plt>:
    d550:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d554:      	ldr	x17, [x16, #0xcb0]
    d558:      	add	x16, x16, #0xcb0
    d55c:      	br	x17

000000000000d560 <bytehook_set_debug@plt>:
    d560:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d564:      	ldr	x17, [x16, #0xcb8]
    d568:      	add	x16, x16, #0xcb8
    d56c:      	br	x17

000000000000d570 <bytehook_get_recordable@plt>:
    d570:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d574:      	ldr	x17, [x16, #0xcc0]
    d578:      	add	x16, x16, #0xcc0
    d57c:      	br	x17

000000000000d580 <bytehook_set_recordable@plt>:
    d580:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d584:      	ldr	x17, [x16, #0xcc8]
    d588:      	add	x16, x16, #0xcc8
    d58c:      	br	x17

000000000000d590 <bytehook_get_records@plt>:
    d590:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d594:      	ldr	x17, [x16, #0xcd0]
    d598:      	add	x16, x16, #0xcd0
    d59c:      	br	x17

000000000000d5a0 <strrchr@plt>:
    d5a0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d5a4:      	ldr	x17, [x16, #0xcd8]
    d5a8:      	add	x16, x16, #0xcd8
    d5ac:      	br	x17

000000000000d5b0 <strlen@plt>:
    d5b0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d5b4:      	ldr	x17, [x16, #0xce0]
    d5b8:      	add	x16, x16, #0xce0
    d5bc:      	br	x17

000000000000d5c0 <__strlen_chk@plt>:
    d5c0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d5c4:      	ldr	x17, [x16, #0xce8]
    d5c8:      	add	x16, x16, #0xce8
    d5cc:      	br	x17

000000000000d5d0 <dladdr@plt>:
    d5d0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d5d4:      	ldr	x17, [x16, #0xcf0]
    d5d8:      	add	x16, x16, #0xcf0
    d5dc:      	br	x17

000000000000d5e0 <strlcpy@plt>:
    d5e0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d5e4:      	ldr	x17, [x16, #0xcf8]
    d5e8:      	add	x16, x16, #0xcf8
    d5ec:      	br	x17

000000000000d5f0 <memcmp@plt>:
    d5f0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d5f4:      	ldr	x17, [x16, #0xd00]
    d5f8:      	add	x16, x16, #0xd00
    d5fc:      	br	x17

000000000000d600 <pthread_rwlock_init@plt>:
    d600:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d604:      	ldr	x17, [x16, #0xd08]
    d608:      	add	x16, x16, #0xd08
    d60c:      	br	x17

000000000000d610 <pthread_rwlock_destroy@plt>:
    d610:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d614:      	ldr	x17, [x16, #0xd10]
    d618:      	add	x16, x16, #0xd10
    d61c:      	br	x17

000000000000d620 <vsnprintf@plt>:
    d620:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d624:      	ldr	x17, [x16, #0xd18]
    d628:      	add	x16, x16, #0xd18
    d62c:      	br	x17

000000000000d630 <shadowhook_register_dl_init_callback@plt>:
    d630:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d634:      	ldr	x17, [x16, #0xd20]
    d638:      	add	x16, x16, #0xd20
    d63c:      	br	x17

000000000000d640 <shadowhook_register_dl_fini_callback@plt>:
    d640:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d644:      	ldr	x17, [x16, #0xd28]
    d648:      	add	x16, x16, #0xd28
    d64c:      	br	x17

000000000000d650 <memset@plt>:
    d650:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d654:      	ldr	x17, [x16, #0xd30]
    d658:      	add	x16, x16, #0xd30
    d65c:      	br	x17

000000000000d660 <prctl@plt>:
    d660:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d664:      	ldr	x17, [x16, #0xd38]
    d668:      	add	x16, x16, #0xd38
    d66c:      	br	x17

000000000000d670 <mmap@plt>:
    d670:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d674:      	ldr	x17, [x16, #0xd40]
    d678:      	add	x16, x16, #0xd40
    d67c:      	br	x17

000000000000d680 <munmap@plt>:
    d680:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d684:      	ldr	x17, [x16, #0xd48]
    d688:      	add	x16, x16, #0xd48
    d68c:      	br	x17

000000000000d690 <getpagesize@plt>:
    d690:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d694:      	ldr	x17, [x16, #0xd50]
    d698:      	add	x16, x16, #0xd50
    d69c:      	br	x17

000000000000d6a0 <__system_property_get@plt>:
    d6a0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d6a4:      	ldr	x17, [x16, #0xd58]
    d6a8:      	add	x16, x16, #0xd58
    d6ac:      	br	x17

000000000000d6b0 <atoi@plt>:
    d6b0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d6b4:      	ldr	x17, [x16, #0xd60]
    d6b8:      	add	x16, x16, #0xd60
    d6bc:      	br	x17

000000000000d6c0 <fopen@plt>:
    d6c0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d6c4:      	ldr	x17, [x16, #0xd68]
    d6c8:      	add	x16, x16, #0xd68
    d6cc:      	br	x17

000000000000d6d0 <fgets@plt>:
    d6d0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d6d4:      	ldr	x17, [x16, #0xd70]
    d6d8:      	add	x16, x16, #0xd70
    d6dc:      	br	x17

000000000000d6e0 <fclose@plt>:
    d6e0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d6e4:      	ldr	x17, [x16, #0xd78]
    d6e8:      	add	x16, x16, #0xd78
    d6ec:      	br	x17

000000000000d6f0 <write@plt>:
    d6f0:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d6f4:      	ldr	x17, [x16, #0xd80]
    d6f8:      	add	x16, x16, #0xd80
    d6fc:      	br	x17

000000000000d700 <mprotect@plt>:
    d700:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d704:      	ldr	x17, [x16, #0xd88]
    d708:      	add	x16, x16, #0xd88
    d70c:      	br	x17

000000000000d710 <sigfillset64@plt>:
    d710:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d714:      	ldr	x17, [x16, #0xd90]
    d718:      	add	x16, x16, #0xd90
    d71c:      	br	x17

000000000000d720 <sigfillset@plt>:
    d720:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d724:      	ldr	x17, [x16, #0xd98]
    d728:      	add	x16, x16, #0xd98
    d72c:      	br	x17

000000000000d730 <sigemptyset64@plt>:
    d730:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d734:      	ldr	x17, [x16, #0xda0]
    d738:      	add	x16, x16, #0xda0
    d73c:      	br	x17

000000000000d740 <sigismember64@plt>:
    d740:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d744:      	ldr	x17, [x16, #0xda8]
    d748:      	add	x16, x16, #0xda8
    d74c:      	br	x17

000000000000d750 <sigaddset64@plt>:
    d750:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d754:      	ldr	x17, [x16, #0xdb0]
    d758:      	add	x16, x16, #0xdb0
    d75c:      	br	x17

000000000000d760 <sigemptyset@plt>:
    d760:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d764:      	ldr	x17, [x16, #0xdb8]
    d768:      	add	x16, x16, #0xdb8
    d76c:      	br	x17

000000000000d770 <sigismember@plt>:
    d770:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d774:      	ldr	x17, [x16, #0xdc0]
    d778:      	add	x16, x16, #0xdc0
    d77c:      	br	x17

000000000000d780 <sigaddset@plt>:
    d780:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d784:      	ldr	x17, [x16, #0xdc8]
    d788:      	add	x16, x16, #0xdc8
    d78c:      	br	x17

000000000000d790 <siglongjmp@plt>:
    d790:      	adrp	x16, 0x11000 <siglongjmp@plt+0x3870>
    d794:      	ldr	x17, [x16, #0xdd0]
    d798:      	add	x16, x16, #0xdd0
    d79c:      	br	x17
