
F:\CONVERT\com.mt.mtxx.mtxx\SOURCE\extracted_native_libs\lib\arm64-v8a\libfile_lock_pgl.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000a0c <.text>:
     a0c:      	adrp	x0, 0x4000 <close@plt+0x3100>
     a10:      	add	x0, x0, #0xf10
     a14:      	b	0xe80 <__cxa_finalize@plt>
     a18:      	ret
     a1c:      	b	0xa18 <.text+0xc>
     a20:      	cbz	x0, 0xa28 <.text+0x1c>
     a24:      	br	x0
     a28:      	ret
     a2c:      	adrp	x8, 0x0
     a30:      	add	x8, x8, #0xa20
     a34:      	adrp	x2, 0x4000 <close@plt+0x3100>
     a38:      	add	x2, x2, #0xf10
     a3c:      	mov	x1, x0
     a40:      	mov	x0, x8
     a44:      	b	0xe90 <__cxa_atexit@plt>

0000000000000a48 <Java_com_bykv_vk_openvk_preload_geckox_utils_FileLock_nLockFile>:
     a48:      	sub	sp, sp, #0x60
     a4c:      	stp	x29, x30, [sp, #0x30]
     a50:      	str	x21, [sp, #0x40]
     a54:      	stp	x20, x19, [sp, #0x50]
     a58:      	add	x29, sp, #0x30
     a5c:      	mrs	x21, TPIDR_EL0
     a60:      	ldr	x9, [x21, #0x28]
     a64:      	mov	w8, w2
     a68:      	mov	x19, x0
     a6c:      	mov	w10, #0x1               // =1
     a70:      	mov	w11, #-0x1              // =-1
     a74:      	add	x2, sp, #0x8
     a78:      	mov	w1, #0x7                // =7
     a7c:      	mov	w0, w8
     a80:      	stur	x9, [x29, #-0x8]
     a84:      	stp	xzr, xzr, [sp, #0x10]
     a88:      	str	w10, [sp, #0x8]
     a8c:      	str	w11, [sp, #0x20]
     a90:      	bl	0xea0 <fcntl@plt>
     a94:      	tbz	w0, #0x1f, 0xaf4 <Java_com_bykv_vk_openvk_preload_geckox_utils_FileLock_nLockFile+0xac>
     a98:      	ldrsh	w3, [sp, #0x8]
     a9c:      	adrp	x1, 0x0
     aa0:      	adrp	x2, 0x0
     aa4:      	add	x1, x1, #0x888
     aa8:      	add	x2, x2, #0x891
     aac:      	mov	w0, #0x3                // =3
     ab0:      	bl	0xeb0 <__android_log_print@plt>
     ab4:      	ldr	x8, [x19]
     ab8:      	adrp	x1, 0x0
     abc:      	add	x1, x1, #0x8c2
     ac0:      	mov	x0, x19
     ac4:      	ldr	x8, [x8, #0x30]
     ac8:      	blr	x8
     acc:      	mov	x20, x0
     ad0:      	bl	0xec0 <__errno@plt>
     ad4:      	ldr	w0, [x0]
     ad8:      	bl	0xed0 <strerror@plt>
     adc:      	ldr	x8, [x19]
     ae0:      	mov	x2, x0
     ae4:      	mov	x0, x19
     ae8:      	mov	x1, x20
     aec:      	ldr	x8, [x8, #0x70]
     af0:      	blr	x8
     af4:      	ldr	x8, [x21, #0x28]
     af8:      	ldur	x9, [x29, #-0x8]
     afc:      	cmp	x8, x9
     b00:      	b.ne	0xb18 <Java_com_bykv_vk_openvk_preload_geckox_utils_FileLock_nLockFile+0xd0>
     b04:      	ldp	x20, x19, [sp, #0x50]
     b08:      	ldr	x21, [sp, #0x40]
     b0c:      	ldp	x29, x30, [sp, #0x30]
     b10:      	add	sp, sp, #0x60
     b14:      	ret
     b18:      	bl	0xee0 <__stack_chk_fail@plt>

0000000000000b1c <Java_com_bykv_vk_openvk_preload_geckox_utils_FileLock_nUnlockFile>:
     b1c:      	sub	sp, sp, #0x60
     b20:      	stp	x29, x30, [sp, #0x30]
     b24:      	str	x21, [sp, #0x40]
     b28:      	stp	x20, x19, [sp, #0x50]
     b2c:      	add	x29, sp, #0x30
     b30:      	mrs	x21, TPIDR_EL0
     b34:      	ldr	x9, [x21, #0x28]
     b38:      	mov	w8, w2
     b3c:      	mov	x19, x0
     b40:      	mov	w10, #0x2               // =2
     b44:      	mov	w11, #-0x1              // =-1
     b48:      	add	x2, sp, #0x8
     b4c:      	mov	w1, #0x6                // =6
     b50:      	mov	w0, w8
     b54:      	stur	x9, [x29, #-0x8]
     b58:      	stp	xzr, xzr, [sp, #0x10]
     b5c:      	str	w10, [sp, #0x8]
     b60:      	str	w11, [sp, #0x20]
     b64:      	bl	0xea0 <fcntl@plt>
     b68:      	tbz	w0, #0x1f, 0xbc8 <Java_com_bykv_vk_openvk_preload_geckox_utils_FileLock_nUnlockFile+0xac>
     b6c:      	ldrsh	w3, [sp, #0x8]
     b70:      	adrp	x1, 0x0
     b74:      	adrp	x2, 0x0
     b78:      	add	x1, x1, #0x888
     b7c:      	add	x2, x2, #0x8a8
     b80:      	mov	w0, #0x3                // =3
     b84:      	bl	0xeb0 <__android_log_print@plt>
     b88:      	ldr	x8, [x19]
     b8c:      	adrp	x1, 0x0
     b90:      	add	x1, x1, #0x8c2
     b94:      	mov	x0, x19
     b98:      	ldr	x8, [x8, #0x30]
     b9c:      	blr	x8
     ba0:      	mov	x20, x0
     ba4:      	bl	0xec0 <__errno@plt>
     ba8:      	ldr	w0, [x0]
     bac:      	bl	0xed0 <strerror@plt>
     bb0:      	ldr	x8, [x19]
     bb4:      	mov	x2, x0
     bb8:      	mov	x0, x19
     bbc:      	mov	x1, x20
     bc0:      	ldr	x8, [x8, #0x70]
     bc4:      	blr	x8
     bc8:      	ldr	x8, [x21, #0x28]
     bcc:      	ldur	x9, [x29, #-0x8]
     bd0:      	cmp	x8, x9
     bd4:      	b.ne	0xbec <Java_com_bykv_vk_openvk_preload_geckox_utils_FileLock_nUnlockFile+0xd0>
     bd8:      	ldp	x20, x19, [sp, #0x50]
     bdc:      	ldr	x21, [sp, #0x40]
     be0:      	ldp	x29, x30, [sp, #0x30]
     be4:      	add	sp, sp, #0x60
     be8:      	ret
     bec:      	bl	0xee0 <__stack_chk_fail@plt>

0000000000000bf0 <Java_com_bykv_vk_openvk_preload_geckox_utils_FileLock_nTryLock>:
     bf0:      	sub	sp, sp, #0x50
     bf4:      	stp	x29, x30, [sp, #0x30]
     bf8:      	str	x19, [sp, #0x40]
     bfc:      	add	x29, sp, #0x30
     c00:      	mrs	x19, TPIDR_EL0
     c04:      	ldr	x8, [x19, #0x28]
     c08:      	mov	w0, w2
     c0c:      	mov	w9, #0x1                // =1
     c10:      	mov	w10, #-0x1              // =-1
     c14:      	add	x2, sp, #0x8
     c18:      	mov	w1, #0x6                // =6
     c1c:      	stur	x8, [x29, #-0x8]
     c20:      	stp	xzr, xzr, [sp, #0x10]
     c24:      	str	w9, [sp, #0x8]
     c28:      	str	w10, [sp, #0x20]
     c2c:      	bl	0xea0 <fcntl@plt>
     c30:      	ldr	x8, [x19, #0x28]
     c34:      	ldur	x9, [x29, #-0x8]
     c38:      	cmp	x8, x9
     c3c:      	b.ne	0xc58 <Java_com_bykv_vk_openvk_preload_geckox_utils_FileLock_nTryLock+0x68>
     c40:      	ldr	x19, [sp, #0x40]
     c44:      	ldp	x29, x30, [sp, #0x30]
     c48:      	mvn	w8, w0
     c4c:      	lsr	w0, w8, #31
     c50:      	add	sp, sp, #0x50
     c54:      	ret
     c58:      	bl	0xee0 <__stack_chk_fail@plt>

0000000000000c5c <Java_com_bykv_vk_openvk_preload_geckox_utils_FileLock_nLockFileSegment>:
     c5c:      	sub	sp, sp, #0x60
     c60:      	stp	x29, x30, [sp, #0x30]
     c64:      	str	x21, [sp, #0x40]
     c68:      	stp	x20, x19, [sp, #0x50]
     c6c:      	add	x29, sp, #0x30
     c70:      	mrs	x21, TPIDR_EL0
     c74:      	ldr	x9, [x21, #0x28]
     c78:      	mov	w8, w2
     c7c:      	mov	x19, x0
     c80:      	sxtw	x10, w3
     c84:      	mov	w11, #0x1               // =1
     c88:      	mov	w12, #-0x1              // =-1
     c8c:      	add	x2, sp, #0x8
     c90:      	mov	w1, #0x7                // =7
     c94:      	mov	w0, w8
     c98:      	stur	x9, [x29, #-0x8]
     c9c:      	stp	x10, x11, [sp, #0x10]
     ca0:      	str	w11, [sp, #0x8]
     ca4:      	str	w12, [sp, #0x20]
     ca8:      	bl	0xea0 <fcntl@plt>
     cac:      	tbz	w0, #0x1f, 0xd0c <Java_com_bykv_vk_openvk_preload_geckox_utils_FileLock_nLockFileSegment+0xb0>
     cb0:      	ldrsh	w3, [sp, #0x8]
     cb4:      	adrp	x1, 0x0
     cb8:      	adrp	x2, 0x0
     cbc:      	add	x1, x1, #0x888
     cc0:      	add	x2, x2, #0x891
     cc4:      	mov	w0, #0x3                // =3
     cc8:      	bl	0xeb0 <__android_log_print@plt>
     ccc:      	ldr	x8, [x19]
     cd0:      	adrp	x1, 0x0
     cd4:      	add	x1, x1, #0x8c2
     cd8:      	mov	x0, x19
     cdc:      	ldr	x8, [x8, #0x30]
     ce0:      	blr	x8
     ce4:      	mov	x20, x0
     ce8:      	bl	0xec0 <__errno@plt>
     cec:      	ldr	w0, [x0]
     cf0:      	bl	0xed0 <strerror@plt>
     cf4:      	ldr	x8, [x19]
     cf8:      	mov	x2, x0
     cfc:      	mov	x0, x19
     d00:      	mov	x1, x20
     d04:      	ldr	x8, [x8, #0x70]
     d08:      	blr	x8
     d0c:      	ldr	x8, [x21, #0x28]
     d10:      	ldur	x9, [x29, #-0x8]
     d14:      	cmp	x8, x9
     d18:      	b.ne	0xd30 <Java_com_bykv_vk_openvk_preload_geckox_utils_FileLock_nLockFileSegment+0xd4>
     d1c:      	ldp	x20, x19, [sp, #0x50]
     d20:      	ldr	x21, [sp, #0x40]
     d24:      	ldp	x29, x30, [sp, #0x30]
     d28:      	add	sp, sp, #0x60
     d2c:      	ret
     d30:      	bl	0xee0 <__stack_chk_fail@plt>

0000000000000d34 <Java_com_bykv_vk_openvk_preload_geckox_utils_FileLock_nGetFD>:
     d34:      	stp	x29, x30, [sp, #-0x30]!
     d38:      	stp	x22, x21, [sp, #0x10]
     d3c:      	stp	x20, x19, [sp, #0x20]
     d40:      	mov	x29, sp
     d44:      	ldr	x8, [x0]
     d48:      	mov	x21, x2
     d4c:      	mov	x1, x2
     d50:      	mov	x2, xzr
     d54:      	ldr	x8, [x8, #0x548]
     d58:      	mov	x19, x0
     d5c:      	blr	x8
     d60:      	mov	w1, #0x42               // =66
     d64:      	movk	w1, #0x8, lsl #16
     d68:      	mov	w2, #0x1b6              // =438
     d6c:      	mov	x22, x0
     d70:      	bl	0xef0 <open@plt>
     d74:      	ldr	x8, [x19]
     d78:      	mov	w20, w0
     d7c:      	mov	x0, x19
     d80:      	mov	x1, x21
     d84:      	ldr	x8, [x8, #0x550]
     d88:      	mov	x2, x22
     d8c:      	blr	x8
     d90:      	tbz	w20, #0x1f, 0xdd8 <Java_com_bykv_vk_openvk_preload_geckox_utils_FileLock_nGetFD+0xa4>
     d94:      	ldr	x8, [x19]
     d98:      	adrp	x1, 0x0
     d9c:      	add	x1, x1, #0x8c2
     da0:      	mov	x0, x19
     da4:      	ldr	x8, [x8, #0x30]
     da8:      	blr	x8
     dac:      	mov	x20, x0
     db0:      	bl	0xec0 <__errno@plt>
     db4:      	ldr	w0, [x0]
     db8:      	bl	0xed0 <strerror@plt>
     dbc:      	ldr	x8, [x19]
     dc0:      	mov	x2, x0
     dc4:      	mov	x0, x19
     dc8:      	mov	x1, x20
     dcc:      	ldr	x8, [x8, #0x70]
     dd0:      	blr	x8
     dd4:      	mov	w20, #-0x1              // =-1
     dd8:      	mov	w0, w20
     ddc:      	ldp	x20, x19, [sp, #0x20]
     de0:      	ldp	x22, x21, [sp, #0x10]
     de4:      	ldp	x29, x30, [sp], #0x30
     de8:      	ret

0000000000000dec <Java_com_bykv_vk_openvk_preload_geckox_utils_FileLock_nRelease>:
     dec:      	stp	x29, x30, [sp, #-0x20]!
     df0:      	stp	x20, x19, [sp, #0x10]
     df4:      	mov	x29, sp
     df8:      	mov	x19, x0
     dfc:      	mov	w0, w2
     e00:      	bl	0xf00 <close@plt>
     e04:      	cmn	w0, #0x1
     e08:      	b.eq	0xe18 <Java_com_bykv_vk_openvk_preload_geckox_utils_FileLock_nRelease+0x2c>
     e0c:      	ldp	x20, x19, [sp, #0x10]
     e10:      	ldp	x29, x30, [sp], #0x20
     e14:      	ret
     e18:      	ldr	x8, [x19]
     e1c:      	adrp	x1, 0x0
     e20:      	add	x1, x1, #0x8c2
     e24:      	mov	x0, x19
     e28:      	ldr	x8, [x8, #0x30]
     e2c:      	blr	x8
     e30:      	mov	x20, x0
     e34:      	bl	0xec0 <__errno@plt>
     e38:      	ldr	w0, [x0]
     e3c:      	bl	0xed0 <strerror@plt>
     e40:      	ldr	x8, [x19]
     e44:      	mov	x2, x0
     e48:      	mov	x0, x19
     e4c:      	mov	x1, x20
     e50:      	ldr	x3, [x8, #0x70]
     e54:      	ldp	x20, x19, [sp, #0x10]
     e58:      	ldp	x29, x30, [sp], #0x20
     e5c:      	br	x3

Disassembly of section .plt:

0000000000000e60 <.plt>:
     e60:      	stp	x16, x30, [sp, #-0x10]!
     e64:      	adrp	x16, 0x5000
     e68:      	ldr	x17, [x16, #0xe8]
     e6c:      	add	x16, x16, #0xe8
     e70:      	br	x17
     e74:      	nop
     e78:      	nop
     e7c:      	nop

0000000000000e80 <__cxa_finalize@plt>:
     e80:      	adrp	x16, 0x5000
     e84:      	ldr	x17, [x16, #0xf0]
     e88:      	add	x16, x16, #0xf0
     e8c:      	br	x17

0000000000000e90 <__cxa_atexit@plt>:
     e90:      	adrp	x16, 0x5000
     e94:      	ldr	x17, [x16, #0xf8]
     e98:      	add	x16, x16, #0xf8
     e9c:      	br	x17

0000000000000ea0 <fcntl@plt>:
     ea0:      	adrp	x16, 0x5000
     ea4:      	ldr	x17, [x16, #0x100]
     ea8:      	add	x16, x16, #0x100
     eac:      	br	x17

0000000000000eb0 <__android_log_print@plt>:
     eb0:      	adrp	x16, 0x5000
     eb4:      	ldr	x17, [x16, #0x108]
     eb8:      	add	x16, x16, #0x108
     ebc:      	br	x17

0000000000000ec0 <__errno@plt>:
     ec0:      	adrp	x16, 0x5000
     ec4:      	ldr	x17, [x16, #0x110]
     ec8:      	add	x16, x16, #0x110
     ecc:      	br	x17

0000000000000ed0 <strerror@plt>:
     ed0:      	adrp	x16, 0x5000
     ed4:      	ldr	x17, [x16, #0x118]
     ed8:      	add	x16, x16, #0x118
     edc:      	br	x17

0000000000000ee0 <__stack_chk_fail@plt>:
     ee0:      	adrp	x16, 0x5000
     ee4:      	ldr	x17, [x16, #0x120]
     ee8:      	add	x16, x16, #0x120
     eec:      	br	x17

0000000000000ef0 <open@plt>:
     ef0:      	adrp	x16, 0x5000
     ef4:      	ldr	x17, [x16, #0x128]
     ef8:      	add	x16, x16, #0x128
     efc:      	br	x17

0000000000000f00 <close@plt>:
     f00:      	adrp	x16, 0x5000
     f04:      	ldr	x17, [x16, #0x130]
     f08:      	add	x16, x16, #0x130
     f0c:      	br	x17
