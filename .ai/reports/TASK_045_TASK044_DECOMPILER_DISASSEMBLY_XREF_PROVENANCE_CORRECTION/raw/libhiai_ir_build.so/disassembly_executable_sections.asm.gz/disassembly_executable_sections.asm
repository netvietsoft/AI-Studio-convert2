
F:\CONVERT\com.mt.mtxx.mtxx\SOURCE\extracted_native_libs\lib\arm64-v8a\libhiai_ir_build.so:	file format elf64-littleaarch64

Disassembly of section .text:

00000000000064d0 <.text>:
    64d0:      	bti	c
    64d4:      	nop
    64d8:      	adr	x0, 0xddb0
    64dc:      	b	0x9ad0 <__cxa_finalize@plt>
    64e0:      	bti	c
    64e4:      	ret
    64e8:      	bti	c
    64ec:      	b	0x64e0 <.text+0x10>
    64f0:      	bti	c
    64f4:      	cbz	x0, 0x6500 <.text+0x30>
    64f8:      	mov	x16, x0
    64fc:      	br	x16
    6500:      	ret
    6504:      	bti	c
    6508:      	mov	x1, x0
    650c:      	nop
    6510:      	adr	x0, 0x64f0 <.text+0x20>
    6514:      	nop
    6518:      	adr	x2, 0xddb0
    651c:      	b	0x9ae0 <__cxa_atexit@plt>
    6520:      	sub	sp, sp, #0x30
    6524:      	str	x30, [sp, #0x10]
    6528:      	stp	x20, x19, [sp, #0x20]
    652c:      	mrs	x20, TPIDR_EL0
    6530:      	mov	x19, x0
    6534:      	ldr	x8, [x20, #0x28]
    6538:      	str	x8, [sp, #0x8]
    653c:      	ldrb	w8, [x0, #0x68]
    6540:      	tbz	w8, #0x0, 0x654c <.text+0x7c>
    6544:      	ldr	x0, [x19, #0x78]
    6548:      	bl	0x9af0 <_ZdlPv@plt>
    654c:      	ldr	x0, [x19, #0x48]
    6550:      	cbz	x0, 0x655c <.text+0x8c>
    6554:      	str	x0, [x19, #0x50]
    6558:      	bl	0x9af0 <_ZdlPv@plt>
    655c:      	add	x8, x19, #0x28
    6560:      	mov	x0, sp
    6564:      	str	x8, [sp]
    6568:      	bl	0x7250 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0xdc>
    656c:      	ldr	x1, [x19, #0x18]
    6570:      	add	x0, x19, #0x10
    6574:      	bl	0x72c8 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x154>
    6578:      	ldr	x8, [x20, #0x28]
    657c:      	ldr	x9, [sp, #0x8]
    6580:      	cmp	x8, x9
    6584:      	b.ne	0x6598 <.text+0xc8>
    6588:      	ldp	x20, x19, [sp, #0x20]
    658c:      	ldr	x30, [sp, #0x10]
    6590:      	add	sp, sp, #0x30
    6594:      	ret
    6598:      	bl	0x9b00 <__stack_chk_fail@plt>
    659c:      	str	x30, [sp, #-0x30]!
    65a0:      	stp	x22, x21, [sp, #0x10]
    65a4:      	stp	x20, x19, [sp, #0x20]
    65a8:      	mov	x19, x0
    65ac:      	mov	x0, x1
    65b0:      	mov	x21, x1
    65b4:      	bl	0x9b10 <strlen@plt>
    65b8:      	cmn	x0, #0x10
    65bc:      	b.hs	0x661c <.text+0x14c>
    65c0:      	mov	x20, x0
    65c4:      	cmp	x0, #0x17
    65c8:      	b.hs	0x65dc <.text+0x10c>
    65cc:      	lsl	w8, w20, #1
    65d0:      	strb	w8, [x19], #0x1
    65d4:      	cbnz	x20, 0x65f8 <.text+0x128>
    65d8:      	b	0x6608 <.text+0x138>
    65dc:      	orr	x22, x20, #0xf
    65e0:      	add	x0, x22, #0x1
    65e4:      	bl	0x9b20 <_Znwm@plt>
    65e8:      	add	x8, x22, #0x2
    65ec:      	stp	x20, x0, [x19, #0x8]
    65f0:      	str	x8, [x19]
    65f4:      	mov	x19, x0
    65f8:      	mov	x0, x19
    65fc:      	mov	x1, x21
    6600:      	mov	x2, x20
    6604:      	bl	0x9b30 <memmove@plt>
    6608:      	strb	wzr, [x19, x20]
    660c:      	ldp	x20, x19, [sp, #0x20]
    6610:      	ldp	x22, x21, [sp, #0x10]
    6614:      	ldr	x30, [sp], #0x30
    6618:      	ret
    661c:      	mov	x0, x19
    6620:      	bl	0x74c4 <_ZN2ge5GraphD0Ev+0x28>

0000000000006624 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataE>:
    6624:      	mov	w3, #0xc800000          // =209715200
    6628:      	b	0x9b40 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj@plt>

000000000000662c <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj>:
    662c:      	sub	sp, sp, #0xa0
    6630:      	stp	x30, x25, [sp, #0x60]
    6634:      	stp	x24, x23, [sp, #0x70]
    6638:      	stp	x22, x21, [sp, #0x80]
    663c:      	stp	x20, x19, [sp, #0x90]
    6640:      	mrs	x25, TPIDR_EL0
    6644:      	mov	w9, #0x1                // =1
    6648:      	mov	w21, w3
    664c:      	ldr	x8, [x25, #0x28]
    6650:      	movk	w9, #0xc80, lsl #16
    6654:      	cmp	w3, w9
    6658:      	str	x8, [sp, #0x58]
    665c:      	b.lo	0x66a8 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x7c>
    6660:      	adrp	x0, 0x1000
    6664:      	add	x0, x0, #0xb55
    6668:      	mov	w1, #0x2f               // =47
    666c:      	mov	w2, #0x75               // =117
    6670:      	bl	0x9b50 <__strrchr_chk@plt>
    6674:      	adrp	x1, 0x1000
    6678:      	add	x1, x1, #0xfe7
    667c:      	adrp	x2, 0x1000
    6680:      	add	x2, x2, #0xd0d
    6684:      	adrp	x4, 0x2000
    6688:      	add	x4, x4, #0x1ae
    668c:      	add	x3, x0, #0x1
    6690:      	mov	w0, #0x3                // =3
    6694:      	mov	w5, #0xe4               // =228
    6698:      	mov	w6, w21
    669c:      	bl	0x9b60 <AI_Log_Print@plt>
    66a0:      	mov	w20, wzr
    66a4:      	b	0x691c <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x2f0>
    66a8:      	adrp	x8, 0x12000
    66ac:      	mov	x20, x2
    66b0:      	mov	x22, x1
    66b4:      	ldrb	w8, [x8, #0x278]
    66b8:      	tbnz	w8, #0x0, 0x66d8 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0xac>
    66bc:      	nop
    66c0:      	adr	x8, 0x12278
    66c4:      	ldr	q0, [x8]
    66c8:      	ldr	x8, [x8, #0x10]
    66cc:      	str	q0, [sp, #0x20]
    66d0:      	str	x8, [sp, #0x30]
    66d4:      	b	0x66ec <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0xc0>
    66d8:      	adrp	x8, 0x12000
    66dc:      	add	x8, x8, #0x280
    66e0:      	add	x0, sp, #0x20
    66e4:      	ldp	x2, x1, [x8]
    66e8:      	bl	0x74e4 <_ZN2ge5GraphD0Ev+0x48>
    66ec:      	ldrb	w8, [sp, #0x20]
    66f0:      	ldr	x9, [sp, #0x30]
    66f4:      	add	x10, sp, #0x20
    66f8:      	orr	x10, x10, #0x1
    66fc:      	mov	w1, #0x100              // =256
    6700:      	tst	w8, #0x1
    6704:      	csel	x0, x10, x9, eq
    6708:      	bl	0x9b70 <dlopen@plt>
    670c:      	cbz	x0, 0x68cc <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x2a0>
    6710:      	adrp	x1, 0x1000
    6714:      	add	x1, x1, #0xe87
    6718:      	mov	x19, x0
    671c:      	bl	0x9b80 <dlsym@plt>
    6720:      	mov	x24, x0
    6724:      	bl	0x9b90 <dlerror@plt>
    6728:      	mov	x23, x0
    672c:      	cbz	x24, 0x6880 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x254>
    6730:      	blr	x24
    6734:      	cbz	x0, 0x6880 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x254>
    6738:      	blr	x24
    673c:      	mov	x1, x0
    6740:      	add	x0, sp, #0x8
    6744:      	bl	0x659c <.text+0xcc>
    6748:      	ldrb	w8, [sp, #0x8]
    674c:      	ldr	x9, [sp, #0x10]
    6750:      	lsr	x10, x8, #1
    6754:      	tst	w8, #0x1
    6758:      	csel	x8, x10, x9, eq
    675c:      	cbz	x8, 0x6948 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x31c>
    6760:      	adrp	x1, 0x1000
    6764:      	add	x1, x1, #0xf5a
    6768:      	add	x0, sp, #0x38
    676c:      	add	x23, sp, #0x38
    6770:      	bl	0x659c <.text+0xcc>
    6774:      	ldrb	w8, [sp, #0x38]
    6778:      	ldr	x9, [sp, #0x40]
    677c:      	lsr	x10, x8, #1
    6780:      	ands	w8, w8, #0x1
    6784:      	csel	x9, x10, x9, eq
    6788:      	cbz	x9, 0x69fc <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x3d0>
    678c:      	ldr	x9, [sp, #0x48]
    6790:      	orr	x10, x23, #0x1
    6794:      	cmp	w8, #0x0
    6798:      	mov	x0, x19
    679c:      	csel	x1, x10, x9, eq
    67a0:      	bl	0x9b80 <dlsym@plt>
    67a4:      	ldrb	w8, [sp, #0x38]
    67a8:      	cmp	x0, #0x0
    67ac:      	cset	w23, ne
    67b0:      	and	w8, w8, #0x1
    67b4:      	cbz	w8, 0x67c0 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x194>
    67b8:      	ldr	x0, [sp, #0x48]
    67bc:      	bl	0x9af0 <_ZdlPv@plt>
    67c0:      	adrp	x0, 0x1000
    67c4:      	add	x0, x0, #0xb55
    67c8:      	mov	w1, #0x2f               // =47
    67cc:      	mov	w2, #0x75               // =117
    67d0:      	bl	0x9b50 <__strrchr_chk@plt>
    67d4:      	adrp	x1, 0x1000
    67d8:      	add	x1, x1, #0xfe7
    67dc:      	cbz	w23, 0x6988 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x35c>
    67e0:      	adrp	x2, 0x1000
    67e4:      	add	x2, x2, #0xcf1
    67e8:      	adrp	x4, 0x2000
    67ec:      	add	x4, x4, #0x1ae
    67f0:      	add	x3, x0, #0x1
    67f4:      	mov	w0, #0x1                // =1
    67f8:      	mov	w5, #0x102              // =258
    67fc:      	bl	0x9b60 <AI_Log_Print@plt>
    6800:      	adrp	x1, 0x1000
    6804:      	add	x1, x1, #0xf5a
    6808:      	mov	x0, x19
    680c:      	bl	0x9b80 <dlsym@plt>
    6810:      	mov	x23, x0
    6814:      	bl	0x9b90 <dlerror@plt>
    6818:      	cbz	x23, 0x6a08 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x3dc>
    681c:      	add	x0, sp, #0x38
    6820:      	bl	0x9ba0 <_ZN2ge6BufferC1Ev@plt>
    6824:      	add	x1, sp, #0x38
    6828:      	mov	x0, x22
    682c:      	bl	0x9bb0 <_ZNK2ge5Model4SaveERNS_6BufferE@plt>
    6830:      	mov	w0, #0x10               // =16
    6834:      	bl	0x9bc0 <malloc@plt>
    6838:      	str	x0, [sp, #0x50]
    683c:      	cbz	x0, 0x6a94 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x468>
    6840:      	mov	x22, x0
    6844:      	add	x0, sp, #0x38
    6848:      	bl	0x9bd0 <_ZNK2ge6Buffer7GetSizeEv@plt>
    684c:      	str	w0, [x22]
    6850:      	add	x1, sp, #0x50
    6854:      	mov	w0, #0x7                // =7
    6858:      	mov	w2, #0x1                // =1
    685c:      	mov	w3, w21
    6860:      	blr	x23
    6864:      	cbz	x0, 0x6b10 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x4e4>
    6868:      	mov	x21, x0
    686c:      	ldr	x0, [sp, #0x50]
    6870:      	bl	0x9be0 <free@plt>
    6874:      	add	x0, sp, #0x38
    6878:      	bl	0x9bf0 <_ZN2ge6BufferD1Ev@plt>
    687c:      	b	0x69dc <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x3b0>
    6880:      	adrp	x0, 0x1000
    6884:      	add	x0, x0, #0xb55
    6888:      	mov	w1, #0x2f               // =47
    688c:      	mov	w2, #0x75               // =117
    6890:      	bl	0x9b50 <__strrchr_chk@plt>
    6894:      	adrp	x1, 0x1000
    6898:      	add	x1, x1, #0xfe7
    689c:      	adrp	x2, 0x2000
    68a0:      	add	x2, x2, #0x136
    68a4:      	adrp	x4, 0x2000
    68a8:      	add	x4, x4, #0x1ae
    68ac:      	add	x3, x0, #0x1
    68b0:      	mov	w0, #0x3                // =3
    68b4:      	mov	w5, #0xf3               // =243
    68b8:      	mov	x6, x23
    68bc:      	bl	0x9b60 <AI_Log_Print@plt>
    68c0:      	mov	x0, x19
    68c4:      	bl	0x9c00 <dlclose@plt>
    68c8:      	b	0x6908 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x2dc>
    68cc:      	adrp	x0, 0x1000
    68d0:      	add	x0, x0, #0xb55
    68d4:      	mov	w1, #0x2f               // =47
    68d8:      	mov	w2, #0x75               // =117
    68dc:      	bl	0x9b50 <__strrchr_chk@plt>
    68e0:      	adrp	x1, 0x1000
    68e4:      	add	x1, x1, #0xfe7
    68e8:      	adrp	x2, 0x2000
    68ec:      	add	x2, x2, #0x1d3
    68f0:      	adrp	x4, 0x2000
    68f4:      	add	x4, x4, #0x1ae
    68f8:      	add	x3, x0, #0x1
    68fc:      	mov	w0, #0x3                // =3
    6900:      	mov	w5, #0xeb               // =235
    6904:      	bl	0x9b60 <AI_Log_Print@plt>
    6908:      	mov	w20, wzr
    690c:      	ldrb	w8, [sp, #0x20]
    6910:      	tbz	w8, #0x0, 0x691c <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x2f0>
    6914:      	ldr	x0, [sp, #0x30]
    6918:      	bl	0x9af0 <_ZdlPv@plt>
    691c:      	ldr	x8, [x25, #0x28]
    6920:      	ldr	x9, [sp, #0x58]
    6924:      	cmp	x8, x9
    6928:      	b.ne	0x6b7c <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x550>
    692c:      	mov	w0, w20
    6930:      	ldp	x20, x19, [sp, #0x90]
    6934:      	ldp	x22, x21, [sp, #0x80]
    6938:      	ldp	x24, x23, [sp, #0x70]
    693c:      	ldp	x30, x25, [sp, #0x60]
    6940:      	add	sp, sp, #0xa0
    6944:      	ret
    6948:      	adrp	x0, 0x1000
    694c:      	add	x0, x0, #0xb55
    6950:      	mov	w1, #0x2f               // =47
    6954:      	mov	w2, #0x75               // =117
    6958:      	bl	0x9b50 <__strrchr_chk@plt>
    695c:      	adrp	x1, 0x1000
    6960:      	add	x1, x1, #0xfe7
    6964:      	adrp	x2, 0x1000
    6968:      	add	x2, x2, #0xccb
    696c:      	adrp	x4, 0x2000
    6970:      	add	x4, x4, #0x1ae
    6974:      	add	x3, x0, #0x1
    6978:      	mov	w0, #0x3                // =3
    697c:      	mov	w5, #0xfa               // =250
    6980:      	bl	0x9b60 <AI_Log_Print@plt>
    6984:      	b	0x6b5c <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x530>
    6988:      	adrp	x2, 0x1000
    698c:      	add	x2, x2, #0xbca
    6990:      	adrp	x4, 0x2000
    6994:      	add	x4, x4, #0x1ae
    6998:      	add	x3, x0, #0x1
    699c:      	mov	w0, #0x1                // =1
    69a0:      	mov	w5, #0x105              // =261
    69a4:      	bl	0x9b60 <AI_Log_Print@plt>
    69a8:      	adrp	x1, 0x1000
    69ac:      	add	x1, x1, #0xd49
    69b0:      	mov	x0, x19
    69b4:      	bl	0x9b80 <dlsym@plt>
    69b8:      	mov	x22, x0
    69bc:      	bl	0x9b90 <dlerror@plt>
    69c0:      	cbz	x22, 0x6a4c <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x420>
    69c4:      	add	x1, sp, #0x38
    69c8:      	mov	w0, #0x7                // =7
    69cc:      	mov	w2, #0x1                // =1
    69d0:      	blr	x22
    69d4:      	cbz	x0, 0x6ad4 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x4a8>
    69d8:      	mov	x21, x0
    69dc:      	ldr	x8, [x21, #0x8]
    69e0:      	mov	x0, x21
    69e4:      	str	x8, [x20]
    69e8:      	ldr	w8, [x21]
    69ec:      	str	w8, [x20, #0x8]
    69f0:      	bl	0x9be0 <free@plt>
    69f4:      	mov	w20, #0x1               // =1
    69f8:      	b	0x6b60 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x534>
    69fc:      	mov	w23, wzr
    6a00:      	cbnz	w8, 0x67b8 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x18c>
    6a04:      	b	0x67c0 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x194>
    6a08:      	mov	x24, x0
    6a0c:      	adrp	x0, 0x1000
    6a10:      	add	x0, x0, #0xb55
    6a14:      	mov	w1, #0x2f               // =47
    6a18:      	mov	w2, #0x75               // =117
    6a1c:      	bl	0x9b50 <__strrchr_chk@plt>
    6a20:      	adrp	x1, 0x1000
    6a24:      	add	x1, x1, #0xfe7
    6a28:      	adrp	x2, 0x1000
    6a2c:      	add	x2, x2, #0xcb0
    6a30:      	adrp	x4, 0x1000
    6a34:      	add	x4, x4, #0xa46
    6a38:      	add	x3, x0, #0x1
    6a3c:      	mov	w0, #0x3                // =3
    6a40:      	mov	w5, #0x4e               // =78
    6a44:      	mov	x6, x24
    6a48:      	b	0x6a8c <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x460>
    6a4c:      	mov	x21, x0
    6a50:      	adrp	x0, 0x1000
    6a54:      	add	x0, x0, #0xb55
    6a58:      	mov	w1, #0x2f               // =47
    6a5c:      	mov	w2, #0x75               // =117
    6a60:      	bl	0x9b50 <__strrchr_chk@plt>
    6a64:      	adrp	x1, 0x1000
    6a68:      	add	x1, x1, #0xfe7
    6a6c:      	adrp	x2, 0x1000
    6a70:      	add	x2, x2, #0xcb0
    6a74:      	adrp	x4, 0x1000
    6a78:      	add	x4, x4, #0xb1b
    6a7c:      	add	x3, x0, #0x1
    6a80:      	mov	w0, #0x3                // =3
    6a84:      	mov	w5, #0x71               // =113
    6a88:      	mov	x6, x21
    6a8c:      	bl	0x9b60 <AI_Log_Print@plt>
    6a90:      	b	0x6b5c <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x530>
    6a94:      	adrp	x0, 0x1000
    6a98:      	add	x0, x0, #0xb55
    6a9c:      	mov	w1, #0x2f               // =47
    6aa0:      	mov	w2, #0x75               // =117
    6aa4:      	bl	0x9b50 <__strrchr_chk@plt>
    6aa8:      	adrp	x1, 0x1000
    6aac:      	add	x1, x1, #0xfe7
    6ab0:      	adrp	x2, 0x2000
    6ab4:      	add	x2, x2, #0x1f9
    6ab8:      	adrp	x4, 0x1000
    6abc:      	add	x4, x4, #0xa46
    6ac0:      	add	x3, x0, #0x1
    6ac4:      	mov	w0, #0x3                // =3
    6ac8:      	mov	w5, #0x57               // =87
    6acc:      	bl	0x9b60 <AI_Log_Print@plt>
    6ad0:      	b	0x6b54 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x528>
    6ad4:      	adrp	x0, 0x1000
    6ad8:      	add	x0, x0, #0xb55
    6adc:      	mov	w1, #0x2f               // =47
    6ae0:      	mov	w2, #0x75               // =117
    6ae4:      	bl	0x9b50 <__strrchr_chk@plt>
    6ae8:      	adrp	x1, 0x1000
    6aec:      	add	x1, x1, #0xfe7
    6af0:      	adrp	x2, 0x1000
    6af4:      	add	x2, x2, #0xe97
    6af8:      	adrp	x4, 0x1000
    6afc:      	add	x4, x4, #0xb1b
    6b00:      	add	x3, x0, #0x1
    6b04:      	mov	w0, #0x3                // =3
    6b08:      	mov	w5, #0x78               // =120
    6b0c:      	b	0x6980 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x354>
    6b10:      	adrp	x0, 0x1000
    6b14:      	add	x0, x0, #0xb55
    6b18:      	mov	w1, #0x2f               // =47
    6b1c:      	mov	w2, #0x75               // =117
    6b20:      	bl	0x9b50 <__strrchr_chk@plt>
    6b24:      	adrp	x1, 0x1000
    6b28:      	add	x1, x1, #0xfe7
    6b2c:      	adrp	x2, 0x1000
    6b30:      	add	x2, x2, #0xa4f
    6b34:      	adrp	x4, 0x1000
    6b38:      	add	x4, x4, #0xa46
    6b3c:      	add	x3, x0, #0x1
    6b40:      	mov	w0, #0x3                // =3
    6b44:      	mov	w5, #0x5e               // =94
    6b48:      	bl	0x9b60 <AI_Log_Print@plt>
    6b4c:      	ldr	x0, [sp, #0x50]
    6b50:      	bl	0x9be0 <free@plt>
    6b54:      	add	x0, sp, #0x38
    6b58:      	bl	0x9bf0 <_ZN2ge6BufferD1Ev@plt>
    6b5c:      	mov	w20, wzr
    6b60:      	mov	x0, x19
    6b64:      	bl	0x9c00 <dlclose@plt>
    6b68:      	ldrb	w8, [sp, #0x8]
    6b6c:      	tbz	w8, #0x0, 0x690c <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x2e0>
    6b70:      	ldr	x0, [sp, #0x18]
    6b74:      	bl	0x9af0 <_ZdlPv@plt>
    6b78:      	b	0x690c <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj+0x2e0>
    6b7c:      	bl	0x9b00 <__stack_chk_fail@plt>

0000000000006b80 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE>:
    6b80:      	ldr	x0, [x1]
    6b84:      	str	wzr, [x1, #0x8]
    6b88:      	cbz	x0, 0x6ba0 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x20>
    6b8c:      	stp	x30, x19, [sp, #-0x10]!
    6b90:      	mov	x19, x1
    6b94:      	bl	0x9be0 <free@plt>
    6b98:      	str	xzr, [x19]
    6b9c:      	ldp	x30, x19, [sp], #0x10
    6ba0:      	ret
    6ba4:      	sub	sp, sp, #0x160
    6ba8:      	str	x29, [sp, #0x130]
    6bac:      	stp	x30, x21, [sp, #0x140]
    6bb0:      	stp	x20, x19, [sp, #0x150]
    6bb4:      	mrs	x21, TPIDR_EL0
    6bb8:      	mov	x0, x3
    6bbc:      	mov	x19, x2
    6bc0:      	ldr	x8, [x21, #0x28]
    6bc4:      	mov	x20, x1
    6bc8:      	str	x8, [sp, #0x128]
    6bcc:      	add	x8, sp, #0x50
    6bd0:      	bl	0x84c8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xea8>
    6bd4:      	ldr	w8, [x19, #0x8]
    6bd8:      	adrp	x1, 0x1000
    6bdc:      	add	x1, x1, #0xeef
    6be0:      	add	x0, sp, #0x18
    6be4:      	str	x8, [sp, #0xc8]
    6be8:      	bl	0x659c <.text+0xcc>
    6bec:      	mov	x0, x20
    6bf0:      	bl	0x9c10 <_ZNK2ge5Model7GetNameEv@plt>
    6bf4:      	ldrb	w8, [x0]
    6bf8:      	ldp	x10, x9, [x0, #0x8]
    6bfc:      	lsr	x11, x8, #1
    6c00:      	tst	w8, #0x1
    6c04:      	csinc	x1, x9, x0, ne
    6c08:      	add	x0, sp, #0x18
    6c0c:      	csel	x2, x11, x10, eq
    6c10:      	bl	0x9c20 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm@plt>
    6c14:      	ldr	q0, [x0]
    6c18:      	ldr	x8, [x0, #0x10]
    6c1c:      	str	q0, [sp, #0x30]
    6c20:      	str	x8, [sp, #0x40]
    6c24:      	stp	xzr, xzr, [x0, #0x8]
    6c28:      	str	xzr, [x0]
    6c2c:      	ldrb	w8, [sp, #0x18]
    6c30:      	tbz	w8, #0x0, 0x6c3c <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0xbc>
    6c34:      	ldr	x0, [sp, #0x28]
    6c38:      	bl	0x9af0 <_ZdlPv@plt>
    6c3c:      	add	x8, sp, #0x18
    6c40:      	add	x0, sp, #0x50
    6c44:      	add	x1, sp, #0x30
    6c48:      	mov	x2, x20
    6c4c:      	bl	0x7f00 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x8e0>
    6c50:      	ldr	x8, [sp, #0x18]
    6c54:      	cbz	x8, 0x6cec <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x16c>
    6c58:      	ldr	x0, [x19]
    6c5c:      	ldr	w1, [x19, #0x8]
    6c60:      	add	x8, sp, #0x8
    6c64:      	mov	w2, wzr
    6c68:      	bl	0x9c30 <_ZN4hiai17CreateLocalBufferEPvmb@plt>
    6c6c:      	ldr	x0, [sp, #0x18]
    6c70:      	str	xzr, [sp]
    6c74:      	add	x1, sp, #0x8
    6c78:      	mov	x2, sp
    6c7c:      	ldr	x8, [x0]
    6c80:      	ldr	x8, [x8, #0x10]
    6c84:      	blr	x8
    6c88:      	cbnz	w0, 0x6d30 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x1b0>
    6c8c:      	ldr	x20, [sp]
    6c90:      	cbz	x20, 0x6d30 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x1b0>
    6c94:      	adrp	x0, 0x1000
    6c98:      	add	x0, x0, #0xb55
    6c9c:      	mov	w1, #0x2f               // =47
    6ca0:      	mov	w2, #0x75               // =117
    6ca4:      	str	w20, [x19, #0x8]
    6ca8:      	bl	0x9b50 <__strrchr_chk@plt>
    6cac:      	mov	w8, #0x1                // =1
    6cb0:      	movk	w8, #0xc80, lsl #16
    6cb4:      	cmp	w20, w8
    6cb8:      	b.lo	0x6d7c <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x1fc>
    6cbc:      	ldr	w6, [x19, #0x8]
    6cc0:      	adrp	x1, 0x1000
    6cc4:      	add	x1, x1, #0xfe7
    6cc8:      	adrp	x2, 0x1000
    6ccc:      	add	x2, x2, #0xdb8
    6cd0:      	adrp	x4, 0x1000
    6cd4:      	add	x4, x4, #0xf72
    6cd8:      	add	x3, x0, #0x1
    6cdc:      	mov	w0, #0x3                // =3
    6ce0:      	mov	w5, #0x131              // =305
    6ce4:      	bl	0x9b60 <AI_Log_Print@plt>
    6ce8:      	b	0x6d74 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x1f4>
    6cec:      	adrp	x0, 0x1000
    6cf0:      	add	x0, x0, #0xb55
    6cf4:      	mov	w1, #0x2f               // =47
    6cf8:      	mov	w2, #0x75               // =117
    6cfc:      	bl	0x9b50 <__strrchr_chk@plt>
    6d00:      	adrp	x1, 0x2000
    6d04:      	add	x1, x1, #0x22f
    6d08:      	adrp	x2, 0x1000
    6d0c:      	add	x2, x2, #0xb22
    6d10:      	adrp	x4, 0x1000
    6d14:      	add	x4, x4, #0xf72
    6d18:      	add	x3, x0, #0x1
    6d1c:      	mov	w0, #0x3                // =3
    6d20:      	mov	w5, #0x127              // =295
    6d24:      	bl	0x9b60 <AI_Log_Print@plt>
    6d28:      	mov	w19, wzr
    6d2c:      	b	0x6dd8 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x258>
    6d30:      	adrp	x0, 0x1000
    6d34:      	add	x0, x0, #0xb55
    6d38:      	mov	w1, #0x2f               // =47
    6d3c:      	mov	w2, #0x75               // =117
    6d40:      	bl	0x9b50 <__strrchr_chk@plt>
    6d44:      	adrp	x1, 0x2000
    6d48:      	add	x1, x1, #0x22f
    6d4c:      	adrp	x2, 0x1000
    6d50:      	add	x2, x2, #0xfa1
    6d54:      	adrp	x4, 0x1000
    6d58:      	add	x4, x4, #0xf72
    6d5c:      	adrp	x6, 0x1000
    6d60:      	add	x6, x6, #0xa40
    6d64:      	add	x3, x0, #0x1
    6d68:      	mov	w0, #0x3                // =3
    6d6c:      	mov	w5, #0x12c              // =300
    6d70:      	bl	0x9b60 <AI_Log_Print@plt>
    6d74:      	mov	w19, wzr
    6d78:      	b	0x6da8 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x228>
    6d7c:      	adrp	x1, 0x1000
    6d80:      	add	x1, x1, #0xfe7
    6d84:      	adrp	x2, 0x2000
    6d88:      	add	x2, x2, #0xc7
    6d8c:      	adrp	x4, 0x1000
    6d90:      	add	x4, x4, #0xf72
    6d94:      	add	x3, x0, #0x1
    6d98:      	mov	w0, #0x1                // =1
    6d9c:      	mov	w5, #0x135              // =309
    6da0:      	mov	w19, #0x1               // =1
    6da4:      	bl	0x9b60 <AI_Log_Print@plt>
    6da8:      	ldr	x20, [sp, #0x10]
    6dac:      	cbz	x20, 0x6dd8 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x258>
    6db0:      	add	x1, x20, #0x8
    6db4:      	mov	x0, #-0x1               // =-1
    6db8:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    6dbc:      	cbnz	x0, 0x6dd8 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x258>
    6dc0:      	ldr	x8, [x20]
    6dc4:      	mov	x0, x20
    6dc8:      	ldr	x8, [x8, #0x10]
    6dcc:      	blr	x8
    6dd0:      	mov	x0, x20
    6dd4:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    6dd8:      	ldr	x20, [sp, #0x20]
    6ddc:      	cbz	x20, 0x6e08 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x288>
    6de0:      	add	x1, x20, #0x8
    6de4:      	mov	x0, #-0x1               // =-1
    6de8:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    6dec:      	cbnz	x0, 0x6e08 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x288>
    6df0:      	ldr	x8, [x20]
    6df4:      	mov	x0, x20
    6df8:      	ldr	x8, [x8, #0x10]
    6dfc:      	blr	x8
    6e00:      	mov	x0, x20
    6e04:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    6e08:      	ldrb	w8, [sp, #0x30]
    6e0c:      	tbz	w8, #0x0, 0x6e18 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x298>
    6e10:      	ldr	x0, [sp, #0x40]
    6e14:      	bl	0x9af0 <_ZdlPv@plt>
    6e18:      	ldrb	w8, [sp, #0x110]
    6e1c:      	tbz	w8, #0x0, 0x6e28 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x2a8>
    6e20:      	ldr	x0, [sp, #0x120]
    6e24:      	bl	0x9af0 <_ZdlPv@plt>
    6e28:      	ldrb	w8, [sp, #0xf0]
    6e2c:      	tbz	w8, #0x0, 0x6e38 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x2b8>
    6e30:      	ldr	x0, [sp, #0x100]
    6e34:      	bl	0x9af0 <_ZdlPv@plt>
    6e38:      	ldrb	w8, [sp, #0xd0]
    6e3c:      	tbz	w8, #0x0, 0x6e48 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x2c8>
    6e40:      	ldr	x0, [sp, #0xe0]
    6e44:      	bl	0x9af0 <_ZdlPv@plt>
    6e48:      	ldr	x1, [sp, #0xa8]
    6e4c:      	add	x20, sp, #0x50
    6e50:      	add	x0, x20, #0x50
    6e54:      	bl	0x7340 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x1cc>
    6e58:      	ldr	x0, [sp, #0x88]
    6e5c:      	cbz	x0, 0x6e68 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x2e8>
    6e60:      	str	x0, [sp, #0x90]
    6e64:      	bl	0x9af0 <_ZdlPv@plt>
    6e68:      	add	x0, sp, #0x30
    6e6c:      	str	x20, [sp, #0x30]
    6e70:      	bl	0x73b8 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x244>
    6e74:      	ldr	x8, [x21, #0x28]
    6e78:      	ldr	x9, [sp, #0x128]
    6e7c:      	cmp	x8, x9
    6e80:      	b.ne	0x6e9c <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x31c>
    6e84:      	mov	w0, w19
    6e88:      	ldp	x20, x19, [sp, #0x150]
    6e8c:      	ldp	x30, x21, [sp, #0x140]
    6e90:      	ldr	x29, [sp, #0x130]
    6e94:      	add	sp, sp, #0x160
    6e98:      	ret
    6e9c:      	bl	0x9b00 <__stack_chk_fail@plt>

0000000000006ea0 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE>:
    6ea0:      	sub	sp, sp, #0x80
    6ea4:      	stp	x30, x25, [sp, #0x40]
    6ea8:      	stp	x24, x23, [sp, #0x50]
    6eac:      	stp	x22, x21, [sp, #0x60]
    6eb0:      	stp	x20, x19, [sp, #0x70]
    6eb4:      	mrs	x25, TPIDR_EL0
    6eb8:      	mov	x21, x1
    6ebc:      	add	x0, sp, #0x20
    6ec0:      	ldr	x8, [x25, #0x28]
    6ec4:      	mov	x19, x3
    6ec8:      	mov	x20, x2
    6ecc:      	str	x8, [sp, #0x38]
    6ed0:      	str	x1, [sp, #0x8]
    6ed4:      	adrp	x1, 0x1000
    6ed8:      	add	x1, x1, #0xca5
    6edc:      	bl	0x659c <.text+0xcc>
    6ee0:      	mov	w8, #0x1                // =1
    6ee4:      	add	x0, sp, #0x8
    6ee8:      	add	x1, sp, #0x20
    6eec:      	add	x2, sp, #0x18
    6ef0:      	str	x8, [sp, #0x18]
    6ef4:      	bl	0x9c60 <_ZN2ge9AttrUtils6SetIntEONS0_17AttrHolderAdapterERKNSt6__ndk112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEERKl@plt>
    6ef8:      	ldrb	w8, [sp, #0x20]
    6efc:      	tbz	w8, #0x0, 0x6f08 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x68>
    6f00:      	ldr	x0, [sp, #0x30]
    6f04:      	bl	0x9af0 <_ZdlPv@plt>
    6f08:      	add	x8, sp, #0x20
    6f0c:      	mov	x0, x21
    6f10:      	bl	0x9c70 <_ZNK2ge5Model8GetGraphEv@plt>
    6f14:      	add	x8, sp, #0x8
    6f18:      	add	x0, sp, #0x20
    6f1c:      	bl	0x9c80 <_ZN2ge10GraphUtils15GetComputeGraphERKNS_5GraphE@plt>
    6f20:      	adrp	x8, 0xe000
    6f24:      	ldr	x8, [x8, #0x58]
    6f28:      	ldr	x22, [sp, #0x30]
    6f2c:      	add	x8, x8, #0x10
    6f30:      	str	x8, [sp, #0x20]
    6f34:      	cbz	x22, 0x6f60 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0xc0>
    6f38:      	add	x1, x22, #0x8
    6f3c:      	mov	x0, #-0x1               // =-1
    6f40:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    6f44:      	cbnz	x0, 0x6f60 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0xc0>
    6f48:      	ldr	x8, [x22]
    6f4c:      	mov	x0, x22
    6f50:      	ldr	x8, [x8, #0x10]
    6f54:      	blr	x8
    6f58:      	mov	x0, x22
    6f5c:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    6f60:      	ldp	x23, x22, [sp, #0x8]
    6f64:      	cbz	x22, 0x6f8c <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0xec>
    6f68:      	add	x1, x22, #0x8
    6f6c:      	mov	w0, #0x1                // =1
    6f70:      	bl	0x9390 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1d70>
    6f74:      	cbz	x23, 0x6fc8 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x128>
    6f78:      	add	x1, x22, #0x8
    6f7c:      	mov	w0, #0x1                // =1
    6f80:      	stp	x23, x22, [sp, #0x20]
    6f84:      	bl	0x9390 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1d70>
    6f88:      	b	0x6f94 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0xf4>
    6f8c:      	cbz	x23, 0x6fc8 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x128>
    6f90:      	stp	x23, xzr, [sp, #0x20]
    6f94:      	add	x0, sp, #0x20
    6f98:      	bl	0x9c90 <_ZN4hiai13IRTransformer21VerifyIrReservedFieldENSt6__ndk110shared_ptrIN2ge12ComputeGraphEEE@plt>
    6f9c:      	ldr	x24, [sp, #0x28]
    6fa0:      	mov	w23, w0
    6fa4:      	cbz	x24, 0x6fb8 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x118>
    6fa8:      	add	x1, x24, #0x8
    6fac:      	mov	x0, #-0x1               // =-1
    6fb0:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    6fb4:      	cbz	x0, 0x7008 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x168>
    6fb8:      	tbz	w23, #0x0, 0x7024 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x184>
    6fbc:      	mov	w23, #0x1               // =1
    6fc0:      	cbnz	x22, 0x7070 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x1d0>
    6fc4:      	b	0x7080 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x1e0>
    6fc8:      	adrp	x0, 0x1000
    6fcc:      	add	x0, x0, #0xb55
    6fd0:      	mov	w1, #0x2f               // =47
    6fd4:      	mov	w2, #0x75               // =117
    6fd8:      	bl	0x9b50 <__strrchr_chk@plt>
    6fdc:      	adrp	x1, 0x2000
    6fe0:      	add	x1, x1, #0x22f
    6fe4:      	adrp	x2, 0x1000
    6fe8:      	add	x2, x2, #0xa78
    6fec:      	adrp	x4, 0x2000
    6ff0:      	add	x4, x4, #0x2d2
    6ff4:      	add	x3, x0, #0x1
    6ff8:      	mov	w0, #0x3                // =3
    6ffc:      	mov	w5, #0x13b              // =315
    7000:      	bl	0x9b60 <AI_Log_Print@plt>
    7004:      	b	0x7068 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x1c8>
    7008:      	ldr	x8, [x24]
    700c:      	mov	x0, x24
    7010:      	ldr	x8, [x8, #0x10]
    7014:      	blr	x8
    7018:      	mov	x0, x24
    701c:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    7020:      	tbnz	w23, #0x0, 0x6fbc <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x11c>
    7024:      	adrp	x0, 0x1000
    7028:      	add	x0, x0, #0xb55
    702c:      	mov	w1, #0x2f               // =47
    7030:      	mov	w2, #0x75               // =117
    7034:      	bl	0x9b50 <__strrchr_chk@plt>
    7038:      	adrp	x1, 0x2000
    703c:      	add	x1, x1, #0x22f
    7040:      	adrp	x2, 0x1000
    7044:      	add	x2, x2, #0xc23
    7048:      	adrp	x4, 0x2000
    704c:      	add	x4, x4, #0x2d2
    7050:      	adrp	x6, 0x1000
    7054:      	add	x6, x6, #0xa40
    7058:      	add	x3, x0, #0x1
    705c:      	mov	w0, #0x3                // =3
    7060:      	mov	w5, #0x13c              // =316
    7064:      	bl	0x9b60 <AI_Log_Print@plt>
    7068:      	mov	w23, wzr
    706c:      	cbz	x22, 0x7080 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x1e0>
    7070:      	add	x1, x22, #0x8
    7074:      	mov	x0, #-0x1               // =-1
    7078:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    707c:      	cbz	x0, 0x709c <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x1fc>
    7080:      	tbz	w23, #0x0, 0x70b8 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x218>
    7084:      	mov	x1, x21
    7088:      	mov	x2, x20
    708c:      	mov	x3, x19
    7090:      	bl	0x6ba4 <_ZN4hiai11HiaiIrBuild16ReleaseModelBuffERNS_15ModelBufferDataE+0x24>
    7094:      	mov	w19, w0
    7098:      	b	0x7100 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x260>
    709c:      	ldr	x8, [x22]
    70a0:      	mov	x0, x22
    70a4:      	ldr	x8, [x8, #0x10]
    70a8:      	blr	x8
    70ac:      	mov	x0, x22
    70b0:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    70b4:      	tbnz	w23, #0x0, 0x7084 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x1e4>
    70b8:      	adrp	x0, 0x1000
    70bc:      	add	x0, x0, #0xb55
    70c0:      	mov	w1, #0x2f               // =47
    70c4:      	mov	w2, #0x75               // =117
    70c8:      	bl	0x9b50 <__strrchr_chk@plt>
    70cc:      	adrp	x1, 0x2000
    70d0:      	add	x1, x1, #0x22f
    70d4:      	adrp	x2, 0x1000
    70d8:      	add	x2, x2, #0xef8
    70dc:      	adrp	x4, 0x2000
    70e0:      	add	x4, x4, #0x6c
    70e4:      	adrp	x6, 0x1000
    70e8:      	add	x6, x6, #0xa40
    70ec:      	add	x3, x0, #0x1
    70f0:      	mov	w0, #0x3                // =3
    70f4:      	mov	w5, #0x146              // =326
    70f8:      	bl	0x9b60 <AI_Log_Print@plt>
    70fc:      	mov	w19, wzr
    7100:      	ldr	x20, [sp, #0x10]
    7104:      	cbz	x20, 0x7130 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x290>
    7108:      	add	x1, x20, #0x8
    710c:      	mov	x0, #-0x1               // =-1
    7110:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    7114:      	cbnz	x0, 0x7130 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x290>
    7118:      	ldr	x8, [x20]
    711c:      	mov	x0, x20
    7120:      	ldr	x8, [x8, #0x10]
    7124:      	blr	x8
    7128:      	mov	x0, x20
    712c:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    7130:      	ldr	x8, [x25, #0x28]
    7134:      	ldr	x9, [sp, #0x38]
    7138:      	cmp	x8, x9
    713c:      	b.ne	0x715c <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE+0x2bc>
    7140:      	and	w0, w19, #0x1
    7144:      	ldp	x20, x19, [sp, #0x70]
    7148:      	ldp	x22, x21, [sp, #0x60]
    714c:      	ldp	x24, x23, [sp, #0x50]
    7150:      	ldp	x30, x25, [sp, #0x40]
    7154:      	add	sp, sp, #0x80
    7158:      	ret
    715c:      	bl	0x9b00 <__stack_chk_fail@plt>

0000000000007160 <_ZN2ge5GraphD2Ev>:
    7160:      	adrp	x8, 0xe000
    7164:      	ldr	x8, [x8, #0x58]
    7168:      	add	x8, x8, #0x10
    716c:      	str	x8, [x0], #0x8
    7170:      	b	0x745c <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x2e8>

0000000000007174 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE>:
    7174:      	sub	sp, sp, #0xc0
    7178:      	stp	x30, x23, [sp, #0x90]
    717c:      	stp	x22, x21, [sp, #0xa0]
    7180:      	stp	x20, x19, [sp, #0xb0]
    7184:      	mrs	x21, TPIDR_EL0
    7188:      	mov	x22, sp
    718c:      	mov	x20, x1
    7190:      	ldr	x8, [x21, #0x28]
    7194:      	adrp	x1, 0x1000
    7198:      	add	x1, x1, #0xd0c
    719c:      	add	x0, x22, #0x68
    71a0:      	mov	x19, x2
    71a4:      	add	x23, x22, #0x28
    71a8:      	str	x8, [sp, #0x88]
    71ac:      	add	x8, x22, #0x18
    71b0:      	strb	wzr, [sp]
    71b4:      	stp	wzr, wzr, [sp, #0x4]
    71b8:      	stp	xzr, xzr, [sp, #0x20]
    71bc:      	stp	x8, xzr, [sp, #0x10]
    71c0:      	stp	xzr, xzr, [sp, #0x30]
    71c4:      	str	wzr, [sp, #0x40]
    71c8:      	stp	xzr, xzr, [sp, #0x50]
    71cc:      	str	xzr, [sp, #0x48]
    71d0:      	str	wzr, [sp, #0x60]
    71d4:      	bl	0x659c <.text+0xcc>
    71d8:      	mov	x3, sp
    71dc:      	mov	x1, x20
    71e0:      	mov	x2, x19
    71e4:      	bl	0x9c50 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE@plt>
    71e8:      	ldrb	w8, [sp, #0x68]
    71ec:      	mov	w19, w0
    71f0:      	tbz	w8, #0x0, 0x71fc <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x88>
    71f4:      	ldr	x0, [sp, #0x78]
    71f8:      	bl	0x9af0 <_ZdlPv@plt>
    71fc:      	ldr	x0, [sp, #0x48]
    7200:      	cbz	x0, 0x720c <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x98>
    7204:      	str	x0, [sp, #0x50]
    7208:      	bl	0x9af0 <_ZdlPv@plt>
    720c:      	add	x0, sp, #0x80
    7210:      	str	x23, [sp, #0x80]
    7214:      	bl	0x7250 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0xdc>
    7218:      	ldr	x1, [sp, #0x18]
    721c:      	add	x0, x22, #0x10
    7220:      	bl	0x72c8 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x154>
    7224:      	ldr	x8, [x21, #0x28]
    7228:      	ldr	x9, [sp, #0x88]
    722c:      	cmp	x8, x9
    7230:      	b.ne	0x724c <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0xd8>
    7234:      	and	w0, w19, #0x1
    7238:      	ldp	x20, x19, [sp, #0xb0]
    723c:      	ldp	x22, x21, [sp, #0xa0]
    7240:      	ldp	x30, x23, [sp, #0x90]
    7244:      	add	sp, sp, #0xc0
    7248:      	ret
    724c:      	bl	0x9b00 <__stack_chk_fail@plt>
    7250:      	stp	x30, x19, [sp, #-0x10]!
    7254:      	mov	x19, x0
    7258:      	ldr	x0, [x0]
    725c:      	ldr	x8, [x0]
    7260:      	cbz	x8, 0x7278 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x104>
    7264:      	bl	0x7280 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x10c>
    7268:      	ldr	x8, [x19]
    726c:      	ldr	x0, [x8]
    7270:      	ldp	x30, x19, [sp], #0x10
    7274:      	b	0x9af0 <_ZdlPv@plt>
    7278:      	ldp	x30, x19, [sp], #0x10
    727c:      	ret
    7280:      	stp	x30, x21, [sp, #-0x20]!
    7284:      	stp	x20, x19, [sp, #0x10]
    7288:      	ldp	x20, x8, [x0]
    728c:      	mov	x19, x0
    7290:      	cmp	x8, x20
    7294:      	b.eq	0x72b8 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x144>
    7298:      	mov	x21, x8
    729c:      	ldr	x0, [x21, #-0x18]!
    72a0:      	cbz	x0, 0x72ac <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x138>
    72a4:      	stur	x0, [x8, #-0x10]
    72a8:      	bl	0x9af0 <_ZdlPv@plt>
    72ac:      	cmp	x21, x20
    72b0:      	mov	x8, x21
    72b4:      	b.ne	0x729c <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x128>
    72b8:      	str	x20, [x19, #0x8]
    72bc:      	ldp	x20, x19, [sp, #0x10]
    72c0:      	ldp	x30, x21, [sp], #0x20
    72c4:      	ret
    72c8:      	cbz	x1, 0x7308 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x194>
    72cc:      	str	x30, [sp, #-0x20]!
    72d0:      	stp	x20, x19, [sp, #0x10]
    72d4:      	mov	x19, x1
    72d8:      	ldr	x1, [x1]
    72dc:      	mov	x20, x0
    72e0:      	bl	0x72c8 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x154>
    72e4:      	ldr	x1, [x19, #0x8]
    72e8:      	mov	x0, x20
    72ec:      	bl	0x72c8 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x154>
    72f0:      	add	x0, x19, #0x20
    72f4:      	bl	0x730c <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x198>
    72f8:      	mov	x0, x19
    72fc:      	ldp	x20, x19, [sp, #0x10]
    7300:      	ldr	x30, [sp], #0x20
    7304:      	b	0x9af0 <_ZdlPv@plt>
    7308:      	ret
    730c:      	stp	x30, x19, [sp, #-0x10]!
    7310:      	mov	x19, x0
    7314:      	ldr	x0, [x0, #0x18]
    7318:      	cbz	x0, 0x7324 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x1b0>
    731c:      	str	x0, [x19, #0x20]
    7320:      	bl	0x9af0 <_ZdlPv@plt>
    7324:      	ldrb	w8, [x19]
    7328:      	tbnz	w8, #0x0, 0x7334 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x1c0>
    732c:      	ldp	x30, x19, [sp], #0x10
    7330:      	ret
    7334:      	ldr	x0, [x19, #0x10]
    7338:      	ldp	x30, x19, [sp], #0x10
    733c:      	b	0x9af0 <_ZdlPv@plt>
    7340:      	cbz	x1, 0x7380 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x20c>
    7344:      	str	x30, [sp, #-0x20]!
    7348:      	stp	x20, x19, [sp, #0x10]
    734c:      	mov	x19, x1
    7350:      	ldr	x1, [x1]
    7354:      	mov	x20, x0
    7358:      	bl	0x7340 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x1cc>
    735c:      	ldr	x1, [x19, #0x8]
    7360:      	mov	x0, x20
    7364:      	bl	0x7340 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x1cc>
    7368:      	add	x0, x19, #0x20
    736c:      	bl	0x7384 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x210>
    7370:      	mov	x0, x19
    7374:      	ldp	x20, x19, [sp, #0x10]
    7378:      	ldr	x30, [sp], #0x20
    737c:      	b	0x9af0 <_ZdlPv@plt>
    7380:      	ret
    7384:      	stp	x30, x19, [sp, #-0x10]!
    7388:      	mov	x19, x0
    738c:      	ldr	x0, [x0, #0x18]
    7390:      	cbz	x0, 0x739c <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x228>
    7394:      	str	x0, [x19, #0x20]
    7398:      	bl	0x9af0 <_ZdlPv@plt>
    739c:      	ldrb	w8, [x19]
    73a0:      	tbnz	w8, #0x0, 0x73ac <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x238>
    73a4:      	ldp	x30, x19, [sp], #0x10
    73a8:      	ret
    73ac:      	ldr	x0, [x19, #0x10]
    73b0:      	ldp	x30, x19, [sp], #0x10
    73b4:      	b	0x9af0 <_ZdlPv@plt>
    73b8:      	str	x30, [sp, #-0x30]!
    73bc:      	stp	x22, x21, [sp, #0x10]
    73c0:      	stp	x20, x19, [sp, #0x20]
    73c4:      	ldr	x21, [x0]
    73c8:      	ldr	x22, [x21]
    73cc:      	cbz	x22, 0x7418 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x2a4>
    73d0:      	ldr	x20, [x21, #0x8]
    73d4:      	mov	x19, x0
    73d8:      	mov	x0, x22
    73dc:      	cmp	x20, x22
    73e0:      	b.eq	0x7404 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x290>
    73e4:      	sub	x20, x20, #0x38
    73e8:      	add	x0, x21, #0x10
    73ec:      	mov	x1, x20
    73f0:      	bl	0x7428 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x2b4>
    73f4:      	cmp	x20, x22
    73f8:      	b.ne	0x73e4 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x270>
    73fc:      	ldr	x8, [x19]
    7400:      	ldr	x0, [x8]
    7404:      	str	x22, [x21, #0x8]
    7408:      	ldp	x20, x19, [sp, #0x20]
    740c:      	ldp	x22, x21, [sp, #0x10]
    7410:      	ldr	x30, [sp], #0x30
    7414:      	b	0x9af0 <_ZdlPv@plt>
    7418:      	ldp	x20, x19, [sp, #0x20]
    741c:      	ldp	x22, x21, [sp, #0x10]
    7420:      	ldr	x30, [sp], #0x30
    7424:      	ret
    7428:      	stp	x30, x19, [sp, #-0x10]!
    742c:      	ldrb	w8, [x1, #0x20]
    7430:      	mov	x19, x1
    7434:      	tbz	w8, #0x0, 0x7440 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x2cc>
    7438:      	ldr	x0, [x19, #0x30]
    743c:      	bl	0x9af0 <_ZdlPv@plt>
    7440:      	ldr	x0, [x19]
    7444:      	cbz	x0, 0x7454 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x2e0>
    7448:      	str	x0, [x19, #0x8]
    744c:      	ldp	x30, x19, [sp], #0x10
    7450:      	b	0x9af0 <_ZdlPv@plt>
    7454:      	ldp	x30, x19, [sp], #0x10
    7458:      	ret
    745c:      	stp	x30, x19, [sp, #-0x10]!
    7460:      	ldr	x19, [x0, #0x8]
    7464:      	cbz	x19, 0x7478 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x304>
    7468:      	add	x1, x19, #0x8
    746c:      	mov	x0, #-0x1               // =-1
    7470:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    7474:      	cbz	x0, 0x7480 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x30c>
    7478:      	ldp	x30, x19, [sp], #0x10
    747c:      	ret
    7480:      	ldr	x8, [x19]
    7484:      	mov	x0, x19
    7488:      	ldr	x8, [x8, #0x10]
    748c:      	blr	x8
    7490:      	mov	x0, x19
    7494:      	ldp	x30, x19, [sp], #0x10
    7498:      	b	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>

000000000000749c <_ZN2ge5GraphD0Ev>:
    749c:      	stp	x30, x19, [sp, #-0x10]!
    74a0:      	adrp	x8, 0xe000
    74a4:      	mov	x19, x0
    74a8:      	ldr	x8, [x8, #0x58]
    74ac:      	add	x8, x8, #0x10
    74b0:      	str	x8, [x0], #0x8
    74b4:      	bl	0x745c <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x2e8>
    74b8:      	mov	x0, x19
    74bc:      	ldp	x30, x19, [sp], #0x10
    74c0:      	b	0x9af0 <_ZdlPv@plt>
    74c4:      	adrp	x0, 0x2000
    74c8:      	add	x0, x0, #0x1be
    74cc:      	bl	0x74d0 <_ZN2ge5GraphD0Ev+0x34>
    74d0:      	str	x30, [sp, #-0x10]!
    74d4:      	mov	x1, x0
    74d8:      	adrp	x0, 0x1000
    74dc:      	add	x0, x0, #0xdf4
    74e0:      	bl	0x9ca0 <_ZNSt6__ndk122__libcpp_verbose_abortEPKcz@plt>
    74e4:      	str	x30, [sp, #-0x30]!
    74e8:      	stp	x22, x21, [sp, #0x10]
    74ec:      	stp	x20, x19, [sp, #0x20]
    74f0:      	mov	x20, x2
    74f4:      	mov	x19, x1
    74f8:      	cmp	x2, #0x16
    74fc:      	mov	x21, x0
    7500:      	b.hi	0x7510 <_ZN2ge5GraphD0Ev+0x74>
    7504:      	lsl	w8, w20, #1
    7508:      	strb	w8, [x21], #0x1
    750c:      	b	0x7534 <_ZN2ge5GraphD0Ev+0x98>
    7510:      	cmn	x20, #0x10
    7514:      	b.hs	0x7550 <_ZN2ge5GraphD0Ev+0xb4>
    7518:      	orr	x22, x20, #0xf
    751c:      	add	x0, x22, #0x1
    7520:      	bl	0x9b20 <_Znwm@plt>
    7524:      	add	x8, x22, #0x2
    7528:      	stp	x20, x0, [x21, #0x8]
    752c:      	str	x8, [x21]
    7530:      	mov	x21, x0
    7534:      	add	x2, x20, #0x1
    7538:      	mov	x0, x21
    753c:      	mov	x1, x19
    7540:      	ldp	x20, x19, [sp, #0x20]
    7544:      	ldp	x22, x21, [sp, #0x10]
    7548:      	ldr	x30, [sp], #0x30
    754c:      	b	0x9b30 <memmove@plt>
    7550:      	mov	x0, x21
    7554:      	bl	0x74c4 <_ZN2ge5GraphD0Ev+0x28>
    7558:      	stp	x30, x21, [sp, #-0x20]!
    755c:      	stp	x20, x19, [sp, #0x10]
    7560:      	nop
    7564:      	adr	x19, 0x121f8
    7568:      	adrp	x1, 0x1000
    756c:      	add	x1, x1, #0xd0c
    7570:      	mov	x8, x19
    7574:      	add	x0, x19, #0x68
    7578:      	strb	wzr, [x19]
    757c:      	stp	wzr, wzr, [x19, #0x4]
    7580:      	stp	xzr, xzr, [x19, #0x20]
    7584:      	str	xzr, [x8, #0x18]!
    7588:      	str	x8, [x19, #0x10]
    758c:      	stp	xzr, xzr, [x19, #0x30]
    7590:      	str	wzr, [x19, #0x40]
    7594:      	stp	xzr, xzr, [x19, #0x50]
    7598:      	str	xzr, [x19, #0x48]
    759c:      	str	wzr, [x19, #0x60]
    75a0:      	bl	0x659c <.text+0xcc>
    75a4:      	nop
    75a8:      	adr	x20, 0xddb0
    75ac:      	nop
    75b0:      	adr	x0, 0x6520 <.text+0x50>
    75b4:      	mov	x1, x19
    75b8:      	mov	x2, x20
    75bc:      	bl	0x9ae0 <__cxa_atexit@plt>
    75c0:      	nop
    75c4:      	adr	x19, 0x12278
    75c8:      	nop
    75cc:      	adr	x1, 0x1ed1
    75d0:      	mov	x0, x19
    75d4:      	bl	0x659c <.text+0xcc>
    75d8:      	adrp	x21, 0xe000
    75dc:      	mov	x1, x19
    75e0:      	mov	x2, x20
    75e4:      	ldr	x21, [x21, #0x60]
    75e8:      	mov	x0, x21
    75ec:      	bl	0x9ae0 <__cxa_atexit@plt>
    75f0:      	nop
    75f4:      	adr	x19, 0x12290
    75f8:      	adrp	x1, 0x1000
    75fc:      	add	x1, x1, #0xf83
    7600:      	mov	x0, x19
    7604:      	bl	0x659c <.text+0xcc>
    7608:      	mov	x1, x19
    760c:      	mov	x2, x20
    7610:      	mov	x0, x21
    7614:      	ldp	x20, x19, [sp, #0x10]
    7618:      	ldp	x30, x21, [sp], #0x20
    761c:      	b	0x9ae0 <__cxa_atexit@plt>

0000000000007620 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE>:
    7620:      	sub	sp, sp, #0xc0
    7624:      	stp	x30, x25, [sp, #0x80]
    7628:      	stp	x24, x23, [sp, #0x90]
    762c:      	stp	x22, x21, [sp, #0xa0]
    7630:      	stp	x20, x19, [sp, #0xb0]
    7634:      	mrs	x24, TPIDR_EL0
    7638:      	ldr	x8, [x24, #0x28]
    763c:      	str	x8, [sp, #0x78]
    7640:      	ldr	x8, [x3]
    7644:      	cbz	x8, 0x7804 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e4>
    7648:      	mov	x21, x1
    764c:      	adrp	x1, 0x1000
    7650:      	add	x1, x1, #0xca5
    7654:      	add	x0, sp, #0x30
    7658:      	mov	x19, x4
    765c:      	mov	x22, x3
    7660:      	mov	x20, x2
    7664:      	str	x8, [sp, #0x60]
    7668:      	bl	0x659c <.text+0xcc>
    766c:      	mov	w8, #0x1                // =1
    7670:      	add	x0, sp, #0x60
    7674:      	add	x1, sp, #0x30
    7678:      	add	x2, sp, #0x18
    767c:      	str	x8, [sp, #0x18]
    7680:      	bl	0x9c60 <_ZN2ge9AttrUtils6SetIntEONS0_17AttrHolderAdapterERKNSt6__ndk112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEERKl@plt>
    7684:      	ldrb	w8, [sp, #0x30]
    7688:      	tbz	w8, #0x0, 0x7694 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x74>
    768c:      	ldr	x0, [sp, #0x40]
    7690:      	bl	0x9af0 <_ZdlPv@plt>
    7694:      	adrp	x1, 0xe000
    7698:      	ldr	x22, [x22]
    769c:      	mov	w0, #0x20               // =32
    76a0:      	ldr	x1, [x1, #0x68]
    76a4:      	bl	0x9cb0 <_ZnwmRKSt9nothrow_t@plt>
    76a8:      	cbz	x0, 0x76b4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x94>
    76ac:      	stp	xzr, xzr, [x0, #0x10]
    76b0:      	stp	x22, xzr, [x0]
    76b4:      	str	x0, [sp, #0x28]
    76b8:      	add	x8, sp, #0x30
    76bc:      	mov	x0, x22
    76c0:      	bl	0x9c70 <_ZNK2ge5Model8GetGraphEv@plt>
    76c4:      	add	x8, sp, #0x18
    76c8:      	add	x0, sp, #0x30
    76cc:      	bl	0x9c80 <_ZN2ge10GraphUtils15GetComputeGraphERKNS_5GraphE@plt>
    76d0:      	adrp	x25, 0xe000
    76d4:      	ldr	x25, [x25, #0x58]
    76d8:      	ldr	x22, [sp, #0x40]
    76dc:      	add	x8, x25, #0x10
    76e0:      	str	x8, [sp, #0x30]
    76e4:      	cbz	x22, 0x7710 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xf0>
    76e8:      	add	x1, x22, #0x8
    76ec:      	mov	x0, #-0x1               // =-1
    76f0:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    76f4:      	cbnz	x0, 0x7710 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xf0>
    76f8:      	ldr	x8, [x22]
    76fc:      	mov	x0, x22
    7700:      	ldr	x8, [x8, #0x10]
    7704:      	blr	x8
    7708:      	mov	x0, x22
    770c:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    7710:      	ldr	x9, [sp, #0x18]
    7714:      	cbz	x9, 0x7848 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x228>
    7718:      	ldr	x8, [sp, #0x20]
    771c:      	stp	x9, x8, [sp, #0x8]
    7720:      	cbz	x8, 0x7730 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x110>
    7724:      	add	x1, x8, #0x8
    7728:      	mov	w0, #0x1                // =1
    772c:      	bl	0x9390 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1d70>
    7730:      	add	x0, sp, #0x8
    7734:      	bl	0x9c90 <_ZN4hiai13IRTransformer21VerifyIrReservedFieldENSt6__ndk110shared_ptrIN2ge12ComputeGraphEEE@plt>
    7738:      	ldr	x23, [sp, #0x10]
    773c:      	mov	w22, w0
    7740:      	cbz	x23, 0x7754 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x134>
    7744:      	add	x1, x23, #0x8
    7748:      	mov	x0, #-0x1               // =-1
    774c:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    7750:      	cbz	x0, 0x7888 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x268>
    7754:      	tbz	w22, #0x0, 0x78a4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x284>
    7758:      	ldr	x23, [sp, #0x28]
    775c:      	add	x8, sp, #0x30
    7760:      	ldr	x0, [x23]
    7764:      	bl	0x9c70 <_ZNK2ge5Model8GetGraphEv@plt>
    7768:      	add	x8, sp, #0x60
    776c:      	add	x0, sp, #0x30
    7770:      	bl	0x9c80 <_ZN2ge10GraphUtils15GetComputeGraphERKNS_5GraphE@plt>
    7774:      	ldr	x22, [sp, #0x40]
    7778:      	add	x8, x25, #0x10
    777c:      	str	x8, [sp, #0x30]
    7780:      	cbz	x22, 0x77ac <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x18c>
    7784:      	add	x1, x22, #0x8
    7788:      	mov	x0, #-0x1               // =-1
    778c:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    7790:      	cbnz	x0, 0x77ac <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x18c>
    7794:      	ldr	x8, [x22]
    7798:      	mov	x0, x22
    779c:      	ldr	x8, [x8, #0x10]
    77a0:      	blr	x8
    77a4:      	mov	x0, x22
    77a8:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    77ac:      	ldr	x8, [sp, #0x60]
    77b0:      	cbz	x8, 0x78ec <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2cc>
    77b4:      	adrp	x0, 0x1000
    77b8:      	add	x0, x0, #0xbe3
    77bc:      	mov	w1, #0x1                // =1
    77c0:      	bl	0x9b70 <dlopen@plt>
    77c4:      	cbz	x0, 0x792c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x30c>
    77c8:      	adrp	x1, 0x2000
    77cc:      	add	x1, x1, #0x260
    77d0:      	mov	x22, x0
    77d4:      	bl	0x9b80 <dlsym@plt>
    77d8:      	cbz	x0, 0x7970 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x350>
    77dc:      	mov	x8, x0
    77e0:      	ldr	x0, [sp, #0x60]
    77e4:      	add	x1, x23, #0x8
    77e8:      	blr	x8
    77ec:      	mov	w23, w0
    77f0:      	mov	x0, x22
    77f4:      	bl	0x9c00 <dlclose@plt>
    77f8:      	cmp	w23, #0x0
    77fc:      	cset	w23, eq
    7800:      	b	0x79b8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x398>
    7804:      	adrp	x0, 0x1000
    7808:      	add	x0, x0, #0xff4
    780c:      	mov	w1, #0x2f               // =47
    7810:      	mov	w2, #0x78               // =120
    7814:      	bl	0x9b50 <__strrchr_chk@plt>
    7818:      	adrp	x1, 0x2000
    781c:      	add	x1, x1, #0x22f
    7820:      	adrp	x2, 0x2000
    7824:      	add	x2, x2, #0x238
    7828:      	adrp	x4, 0x2000
    782c:      	add	x4, x4, #0x2be
    7830:      	add	x3, x0, #0x1
    7834:      	mov	w0, #0x3                // =3
    7838:      	mov	w5, #0x44               // =68
    783c:      	bl	0x9b60 <AI_Log_Print@plt>
    7840:      	str	xzr, [sp]
    7844:      	b	0x7aac <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x48c>
    7848:      	adrp	x0, 0x1000
    784c:      	add	x0, x0, #0xff4
    7850:      	mov	w1, #0x2f               // =47
    7854:      	mov	w2, #0x78               // =120
    7858:      	bl	0x9b50 <__strrchr_chk@plt>
    785c:      	adrp	x1, 0x2000
    7860:      	add	x1, x1, #0x22f
    7864:      	adrp	x2, 0x1000
    7868:      	add	x2, x2, #0xa78
    786c:      	adrp	x4, 0x2000
    7870:      	add	x4, x4, #0x2be
    7874:      	add	x3, x0, #0x1
    7878:      	mov	w0, #0x3                // =3
    787c:      	mov	w5, #0x4a               // =74
    7880:      	bl	0x9b60 <AI_Log_Print@plt>
    7884:      	b	0x79fc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x3dc>
    7888:      	ldr	x8, [x23]
    788c:      	mov	x0, x23
    7890:      	ldr	x8, [x8, #0x10]
    7894:      	blr	x8
    7898:      	mov	x0, x23
    789c:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    78a0:      	tbnz	w22, #0x0, 0x7758 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x138>
    78a4:      	adrp	x0, 0x1000
    78a8:      	add	x0, x0, #0xff4
    78ac:      	mov	w1, #0x2f               // =47
    78b0:      	mov	w2, #0x78               // =120
    78b4:      	bl	0x9b50 <__strrchr_chk@plt>
    78b8:      	adrp	x1, 0x2000
    78bc:      	add	x1, x1, #0x22f
    78c0:      	adrp	x2, 0x1000
    78c4:      	add	x2, x2, #0xc23
    78c8:      	adrp	x4, 0x2000
    78cc:      	add	x4, x4, #0x2be
    78d0:      	adrp	x6, 0x2000
    78d4:      	add	x6, x6, #0x1cb
    78d8:      	add	x3, x0, #0x1
    78dc:      	mov	w0, #0x3                // =3
    78e0:      	mov	w5, #0x4c               // =76
    78e4:      	bl	0x9b60 <AI_Log_Print@plt>
    78e8:      	b	0x79fc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x3dc>
    78ec:      	adrp	x0, 0x1000
    78f0:      	add	x0, x0, #0xff4
    78f4:      	mov	w1, #0x2f               // =47
    78f8:      	mov	w2, #0x78               // =120
    78fc:      	bl	0x9b50 <__strrchr_chk@plt>
    7900:      	adrp	x1, 0x2000
    7904:      	add	x1, x1, #0x22f
    7908:      	adrp	x2, 0x1000
    790c:      	add	x2, x2, #0xa78
    7910:      	adrp	x4, 0x2000
    7914:      	add	x4, x4, #0x165
    7918:      	add	x3, x0, #0x1
    791c:      	mov	w0, #0x3                // =3
    7920:      	mov	w5, #0x2e               // =46
    7924:      	bl	0x9b60 <AI_Log_Print@plt>
    7928:      	b	0x79b4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x394>
    792c:      	adrp	x0, 0x1000
    7930:      	add	x0, x0, #0xff4
    7934:      	mov	w1, #0x2f               // =47
    7938:      	mov	w2, #0x78               // =120
    793c:      	bl	0x9b50 <__strrchr_chk@plt>
    7940:      	adrp	x1, 0x1000
    7944:      	add	x1, x1, #0xfe7
    7948:      	adrp	x2, 0x2000
    794c:      	add	x2, x2, #0x178
    7950:      	adrp	x4, 0x2000
    7954:      	add	x4, x4, #0x165
    7958:      	add	x3, x0, #0x1
    795c:      	mov	w0, #0x2                // =2
    7960:      	mov	w5, #0x33               // =51
    7964:      	bl	0x9b60 <AI_Log_Print@plt>
    7968:      	mov	w23, #0x1               // =1
    796c:      	b	0x79b8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x398>
    7970:      	adrp	x0, 0x1000
    7974:      	add	x0, x0, #0xff4
    7978:      	mov	w1, #0x2f               // =47
    797c:      	mov	w2, #0x78               // =120
    7980:      	bl	0x9b50 <__strrchr_chk@plt>
    7984:      	adrp	x1, 0x1000
    7988:      	add	x1, x1, #0xfe7
    798c:      	adrp	x2, 0x2000
    7990:      	add	x2, x2, #0x282
    7994:      	adrp	x4, 0x2000
    7998:      	add	x4, x4, #0x165
    799c:      	add	x3, x0, #0x1
    79a0:      	mov	w0, #0x2                // =2
    79a4:      	mov	w5, #0x39               // =57
    79a8:      	bl	0x9b60 <AI_Log_Print@plt>
    79ac:      	mov	x0, x22
    79b0:      	bl	0x9c00 <dlclose@plt>
    79b4:      	mov	w23, wzr
    79b8:      	ldr	x22, [sp, #0x68]
    79bc:      	cbz	x22, 0x79d0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x3b0>
    79c0:      	add	x1, x22, #0x8
    79c4:      	mov	x0, #-0x1               // =-1
    79c8:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    79cc:      	cbz	x0, 0x79e0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x3c0>
    79d0:      	cbz	w23, 0x79fc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x3dc>
    79d4:      	ldr	x23, [sp, #0x28]
    79d8:      	str	xzr, [sp, #0x28]
    79dc:      	b	0x7a00 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x3e0>
    79e0:      	ldr	x8, [x22]
    79e4:      	mov	x0, x22
    79e8:      	ldr	x8, [x8, #0x10]
    79ec:      	blr	x8
    79f0:      	mov	x0, x22
    79f4:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    79f8:      	cbnz	w23, 0x79d4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x3b4>
    79fc:      	mov	x23, xzr
    7a00:      	ldr	x22, [sp, #0x20]
    7a04:      	str	x23, [sp]
    7a08:      	cbz	x22, 0x7a38 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x418>
    7a0c:      	add	x1, x22, #0x8
    7a10:      	mov	x0, #-0x1               // =-1
    7a14:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    7a18:      	cbnz	x0, 0x7a34 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x414>
    7a1c:      	ldr	x8, [x22]
    7a20:      	mov	x0, x22
    7a24:      	ldr	x8, [x8, #0x10]
    7a28:      	blr	x8
    7a2c:      	mov	x0, x22
    7a30:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    7a34:      	ldr	x23, [sp]
    7a38:      	add	x0, sp, #0x28
    7a3c:      	bl	0x7cfc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x6dc>
    7a40:      	cbz	x23, 0x7aac <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x48c>
    7a44:      	ldr	x2, [x23]
    7a48:      	add	x8, sp, #0x60
    7a4c:      	mov	x0, x21
    7a50:      	mov	x1, x20
    7a54:      	bl	0x7f00 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x8e0>
    7a58:      	ldr	x8, [sp, #0x60]
    7a5c:      	cbz	x8, 0x7af0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x4d0>
    7a60:      	mov	x20, x23
    7a64:      	ldrb	w8, [x20, #0x8]!
    7a68:      	ldr	x9, [x20, #0x8]
    7a6c:      	lsr	x10, x8, #1
    7a70:      	tst	w8, #0x1
    7a74:      	csel	x8, x10, x9, eq
    7a78:      	cbz	x8, 0x7ba4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x584>
    7a7c:      	adrp	x1, 0x1000
    7a80:      	add	x1, x1, #0xebc
    7a84:      	add	x0, sp, #0x30
    7a88:      	add	x21, sp, #0x30
    7a8c:      	bl	0x659c <.text+0xcc>
    7a90:      	ldrb	w8, [x20]
    7a94:      	tbnz	w8, #0x0, 0x7b64 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x544>
    7a98:      	ldr	x8, [x20, #0x10]
    7a9c:      	ldr	q0, [x20]
    7aa0:      	stur	x8, [x21, #0x28]
    7aa4:      	stur	q0, [x21, #0x18]
    7aa8:      	b	0x7b70 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x550>
    7aac:      	adrp	x0, 0x1000
    7ab0:      	add	x0, x0, #0xff4
    7ab4:      	mov	w1, #0x2f               // =47
    7ab8:      	mov	w2, #0x78               // =120
    7abc:      	bl	0x9b50 <__strrchr_chk@plt>
    7ac0:      	adrp	x1, 0x2000
    7ac4:      	add	x1, x1, #0x22f
    7ac8:      	nop
    7acc:      	adr	x2, 0x22de
    7ad0:      	adrp	x4, 0x1000
    7ad4:      	add	x4, x4, #0xb4f
    7ad8:      	add	x3, x0, #0x1
    7adc:      	mov	w0, #0x3                // =3
    7ae0:      	mov	w5, #0x68               // =104
    7ae4:      	bl	0x9b60 <AI_Log_Print@plt>
    7ae8:      	mov	w19, #0x1               // =1
    7aec:      	b	0x7c30 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x610>
    7af0:      	adrp	x0, 0x1000
    7af4:      	add	x0, x0, #0xff4
    7af8:      	mov	w1, #0x2f               // =47
    7afc:      	mov	w2, #0x78               // =120
    7b00:      	bl	0x9b50 <__strrchr_chk@plt>
    7b04:      	adrp	x1, 0x2000
    7b08:      	add	x1, x1, #0x22f
    7b0c:      	adrp	x2, 0x1000
    7b10:      	add	x2, x2, #0xb22
    7b14:      	adrp	x4, 0x2000
    7b18:      	add	x4, x4, #0xf1
    7b1c:      	add	x3, x0, #0x1
    7b20:      	mov	w0, #0x3                // =3
    7b24:      	mov	w5, #0x58               // =88
    7b28:      	bl	0x9b60 <AI_Log_Print@plt>
    7b2c:      	ldr	x20, [sp, #0x68]
    7b30:      	stp	xzr, xzr, [sp, #0x30]
    7b34:      	cbz	x20, 0x7be8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x5c8>
    7b38:      	add	x1, x20, #0x8
    7b3c:      	mov	x0, #-0x1               // =-1
    7b40:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    7b44:      	cbnz	x0, 0x7be8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x5c8>
    7b48:      	ldr	x8, [x20]
    7b4c:      	mov	x0, x20
    7b50:      	ldr	x8, [x8, #0x10]
    7b54:      	blr	x8
    7b58:      	mov	x0, x20
    7b5c:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    7b60:      	b	0x7be8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x5c8>
    7b64:      	ldp	x2, x1, [x23, #0x10]
    7b68:      	add	x0, x21, #0x18
    7b6c:      	bl	0x74e4 <_ZN2ge5GraphD0Ev+0x48>
    7b70:      	ldr	x0, [sp, #0x60]
    7b74:      	add	x1, sp, #0x30
    7b78:      	ldr	x8, [x0]
    7b7c:      	ldr	x8, [x8, #0x60]
    7b80:      	blr	x8
    7b84:      	ldrb	w8, [sp, #0x48]
    7b88:      	tbz	w8, #0x0, 0x7b94 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x574>
    7b8c:      	ldr	x0, [sp, #0x58]
    7b90:      	bl	0x9af0 <_ZdlPv@plt>
    7b94:      	ldrb	w8, [sp, #0x30]
    7b98:      	tbz	w8, #0x0, 0x7ba4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x584>
    7b9c:      	ldr	x0, [sp, #0x40]
    7ba0:      	bl	0x9af0 <_ZdlPv@plt>
    7ba4:      	adrp	x0, 0x1000
    7ba8:      	add	x0, x0, #0xff4
    7bac:      	mov	w1, #0x2f               // =47
    7bb0:      	mov	w2, #0x78               // =120
    7bb4:      	bl	0x9b50 <__strrchr_chk@plt>
    7bb8:      	adrp	x1, 0x1000
    7bbc:      	add	x1, x1, #0xfe7
    7bc0:      	adrp	x2, 0x2000
    7bc4:      	add	x2, x2, #0x111
    7bc8:      	adrp	x4, 0x2000
    7bcc:      	add	x4, x4, #0xf1
    7bd0:      	add	x3, x0, #0x1
    7bd4:      	mov	w0, #0x1                // =1
    7bd8:      	mov	w5, #0x5f               // =95
    7bdc:      	bl	0x9b60 <AI_Log_Print@plt>
    7be0:      	ldr	q0, [sp, #0x60]
    7be4:      	str	q0, [sp, #0x30]
    7be8:      	add	x1, sp, #0x30
    7bec:      	mov	x0, x19
    7bf0:      	bl	0x7ca4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x684>
    7bf4:      	ldr	x20, [sp, #0x38]
    7bf8:      	cbz	x20, 0x7c24 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x604>
    7bfc:      	add	x1, x20, #0x8
    7c00:      	mov	x0, #-0x1               // =-1
    7c04:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    7c08:      	cbnz	x0, 0x7c24 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x604>
    7c0c:      	ldr	x8, [x20]
    7c10:      	mov	x0, x20
    7c14:      	ldr	x8, [x8, #0x10]
    7c18:      	blr	x8
    7c1c:      	mov	x0, x20
    7c20:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    7c24:      	ldr	x8, [x19]
    7c28:      	cbz	x8, 0x7c64 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x644>
    7c2c:      	mov	w19, wzr
    7c30:      	mov	x0, sp
    7c34:      	bl	0x7cfc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x6dc>
    7c38:      	ldr	x8, [x24, #0x28]
    7c3c:      	ldr	x9, [sp, #0x78]
    7c40:      	cmp	x8, x9
    7c44:      	b.ne	0x7ca0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x680>
    7c48:      	mov	w0, w19
    7c4c:      	ldp	x20, x19, [sp, #0xb0]
    7c50:      	ldp	x22, x21, [sp, #0xa0]
    7c54:      	ldp	x24, x23, [sp, #0x90]
    7c58:      	ldp	x30, x25, [sp, #0x80]
    7c5c:      	add	sp, sp, #0xc0
    7c60:      	ret
    7c64:      	adrp	x0, 0x1000
    7c68:      	add	x0, x0, #0xff4
    7c6c:      	mov	w1, #0x2f               // =47
    7c70:      	mov	w2, #0x78               // =120
    7c74:      	bl	0x9b50 <__strrchr_chk@plt>
    7c78:      	adrp	x1, 0x2000
    7c7c:      	add	x1, x1, #0x22f
    7c80:      	adrp	x2, 0x1000
    7c84:      	add	x2, x2, #0xb22
    7c88:      	adrp	x4, 0x1000
    7c8c:      	add	x4, x4, #0xb4f
    7c90:      	add	x3, x0, #0x1
    7c94:      	mov	w0, #0x3                // =3
    7c98:      	mov	w5, #0x6b               // =107
    7c9c:      	b	0x7ae4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x4c4>
    7ca0:      	bl	0x9b00 <__stack_chk_fail@plt>
    7ca4:      	str	x30, [sp, #-0x20]!
    7ca8:      	stp	x20, x19, [sp, #0x10]
    7cac:      	ldr	q0, [x1]
    7cb0:      	stp	xzr, xzr, [x1]
    7cb4:      	mov	x19, x0
    7cb8:      	ldr	x20, [x0, #0x8]
    7cbc:      	str	q0, [x0]
    7cc0:      	cbz	x20, 0x7cec <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x6cc>
    7cc4:      	add	x1, x20, #0x8
    7cc8:      	mov	x0, #-0x1               // =-1
    7ccc:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    7cd0:      	cbnz	x0, 0x7cec <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x6cc>
    7cd4:      	ldr	x8, [x20]
    7cd8:      	mov	x0, x20
    7cdc:      	ldr	x8, [x8, #0x10]
    7ce0:      	blr	x8
    7ce4:      	mov	x0, x20
    7ce8:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    7cec:      	mov	x0, x19
    7cf0:      	ldp	x20, x19, [sp, #0x10]
    7cf4:      	ldr	x30, [sp], #0x20
    7cf8:      	ret
    7cfc:      	stp	x30, x19, [sp, #-0x10]!
    7d00:      	ldr	x19, [x0]
    7d04:      	str	xzr, [x0]
    7d08:      	cbz	x19, 0x7d28 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x708>
    7d0c:      	ldrb	w8, [x19, #0x8]
    7d10:      	tbz	w8, #0x0, 0x7d1c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x6fc>
    7d14:      	ldr	x0, [x19, #0x18]
    7d18:      	bl	0x9af0 <_ZdlPv@plt>
    7d1c:      	mov	x0, x19
    7d20:      	ldp	x30, x19, [sp], #0x10
    7d24:      	b	0x9af0 <_ZdlPv@plt>
    7d28:      	ldp	x30, x19, [sp], #0x10
    7d2c:      	ret
    7d30:      	stp	x30, x19, [sp, #-0x10]!
    7d34:      	nop
    7d38:      	adr	x19, 0x122a8
    7d3c:      	adrp	x1, 0x1000
    7d40:      	add	x1, x1, #0xd0c
    7d44:      	mov	x8, x19
    7d48:      	add	x0, x19, #0x68
    7d4c:      	strb	wzr, [x19]
    7d50:      	stp	wzr, wzr, [x19, #0x4]
    7d54:      	stp	xzr, xzr, [x19, #0x20]
    7d58:      	str	xzr, [x8, #0x18]!
    7d5c:      	str	x8, [x19, #0x10]
    7d60:      	stp	xzr, xzr, [x19, #0x30]
    7d64:      	str	wzr, [x19, #0x40]
    7d68:      	stp	xzr, xzr, [x19, #0x50]
    7d6c:      	str	xzr, [x19, #0x48]
    7d70:      	str	wzr, [x19, #0x60]
    7d74:      	bl	0x659c <.text+0xcc>
    7d78:      	nop
    7d7c:      	adr	x0, 0x6520 <.text+0x50>
    7d80:      	nop
    7d84:      	adr	x2, 0xddb0
    7d88:      	mov	x1, x19
    7d8c:      	ldp	x30, x19, [sp], #0x10
    7d90:      	b	0x9ae0 <__cxa_atexit@plt>
    7d94:      	sub	sp, sp, #0x90
    7d98:      	stp	x30, x21, [sp, #0x70]
    7d9c:      	stp	x20, x19, [sp, #0x80]
    7da0:      	mrs	x21, TPIDR_EL0
    7da4:      	ldr	x8, [x21, #0x28]
    7da8:      	str	x8, [sp, #0x68]
    7dac:      	add	x8, sp, #0x8
    7db0:      	bl	0x9c70 <_ZNK2ge5Model8GetGraphEv@plt>
    7db4:      	add	x8, sp, #0x20
    7db8:      	add	x0, sp, #0x8
    7dbc:      	bl	0x9c80 <_ZN2ge10GraphUtils15GetComputeGraphERKNS_5GraphE@plt>
    7dc0:      	adrp	x8, 0xe000
    7dc4:      	ldr	x8, [x8, #0x58]
    7dc8:      	ldr	x19, [sp, #0x18]
    7dcc:      	add	x8, x8, #0x10
    7dd0:      	str	x8, [sp, #0x8]
    7dd4:      	cbz	x19, 0x7e00 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x7e0>
    7dd8:      	add	x1, x19, #0x8
    7ddc:      	mov	x0, #-0x1               // =-1
    7de0:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    7de4:      	cbnz	x0, 0x7e00 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x7e0>
    7de8:      	ldr	x8, [x19]
    7dec:      	mov	x0, x19
    7df0:      	ldr	x8, [x8, #0x10]
    7df4:      	blr	x8
    7df8:      	mov	x0, x19
    7dfc:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    7e00:      	ldr	x0, [sp, #0x20]
    7e04:      	cbz	x0, 0x7e4c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x82c>
    7e08:      	ldr	x8, [x0]
    7e0c:      	ldr	x8, [x8, #0x48]
    7e10:      	blr	x8
    7e14:      	adrp	x8, 0xd000 <strncmp@plt+0x3260>
    7e18:      	add	x8, x8, #0xde8
    7e1c:      	add	x19, sp, #0x30
    7e20:      	add	x1, sp, #0x30
    7e24:      	str	x8, [sp, #0x30]
    7e28:      	str	x19, [sp, #0x50]
    7e2c:      	bl	0x9cc0 <_ZN2ge15GraphListWalker12WalkOutNodesENSt6__ndk18functionIFjRNS_4NodeEEEE@plt>
    7e30:      	ldr	x8, [sp, #0x50]
    7e34:      	cmp	x8, x19
    7e38:      	mov	w19, w0
    7e3c:      	b.eq	0x7e90 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x870>
    7e40:      	cbz	x8, 0x7ea8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x888>
    7e44:      	mov	w9, #0x5                // =5
    7e48:      	b	0x7e98 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x878>
    7e4c:      	adrp	x0, 0x1000
    7e50:      	add	x0, x0, #0xaa0
    7e54:      	mov	w1, #0x2f               // =47
    7e58:      	mov	w2, #0x7b               // =123
    7e5c:      	bl	0x9b50 <__strrchr_chk@plt>
    7e60:      	adrp	x1, 0x2000
    7e64:      	add	x1, x1, #0x22f
    7e68:      	nop
    7e6c:      	adr	x2, 0x1a78
    7e70:      	adrp	x4, 0x1000
    7e74:      	add	x4, x4, #0xc76
    7e78:      	add	x3, x0, #0x1
    7e7c:      	mov	w0, #0x3                // =3
    7e80:      	mov	w5, #0x1f               // =31
    7e84:      	bl	0x9b60 <AI_Log_Print@plt>
    7e88:      	mov	w19, #0x1               // =1
    7e8c:      	b	0x7ea8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x888>
    7e90:      	mov	w9, #0x4                // =4
    7e94:      	add	x8, sp, #0x30
    7e98:      	ldr	x10, [x8]
    7e9c:      	mov	x0, x8
    7ea0:      	ldr	x9, [x10, x9, lsl #3]
    7ea4:      	blr	x9
    7ea8:      	ldr	x20, [sp, #0x28]
    7eac:      	cbz	x20, 0x7ed8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x8b8>
    7eb0:      	add	x1, x20, #0x8
    7eb4:      	mov	x0, #-0x1               // =-1
    7eb8:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    7ebc:      	cbnz	x0, 0x7ed8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x8b8>
    7ec0:      	ldr	x8, [x20]
    7ec4:      	mov	x0, x20
    7ec8:      	ldr	x8, [x8, #0x10]
    7ecc:      	blr	x8
    7ed0:      	mov	x0, x20
    7ed4:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    7ed8:      	ldr	x8, [x21, #0x28]
    7edc:      	ldr	x9, [sp, #0x68]
    7ee0:      	cmp	x8, x9
    7ee4:      	b.ne	0x7efc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x8dc>
    7ee8:      	mov	w0, w19
    7eec:      	ldp	x20, x19, [sp, #0x80]
    7ef0:      	ldp	x30, x21, [sp, #0x70]
    7ef4:      	add	sp, sp, #0x90
    7ef8:      	ret
    7efc:      	bl	0x9b00 <__stack_chk_fail@plt>
    7f00:      	sub	sp, sp, #0x70
    7f04:      	stp	x30, x23, [sp, #0x40]
    7f08:      	stp	x22, x21, [sp, #0x50]
    7f0c:      	stp	x20, x19, [sp, #0x60]
    7f10:      	mrs	x23, TPIDR_EL0
    7f14:      	mov	x19, x8
    7f18:      	mov	x22, x2
    7f1c:      	ldr	x8, [x23, #0x28]
    7f20:      	mov	x20, x1
    7f24:      	mov	x21, x0
    7f28:      	str	x8, [sp, #0x38]
    7f2c:      	add	x8, sp, #0x18
    7f30:      	bl	0x9cd0 <_ZN4hiai18CreateModelBuilderEv@plt>
    7f34:      	ldr	x8, [sp, #0x18]
    7f38:      	cbz	x8, 0x7fac <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x98c>
    7f3c:      	mov	x0, x22
    7f40:      	bl	0x7d94 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x774>
    7f44:      	cbnz	w0, 0x7fe8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x9c8>
    7f48:      	add	x0, sp, #0x28
    7f4c:      	bl	0x9ba0 <_ZN2ge6BufferC1Ev@plt>
    7f50:      	add	x1, sp, #0x28
    7f54:      	mov	x0, x22
    7f58:      	bl	0x9bb0 <_ZNK2ge5Model4SaveERNS_6BufferE@plt>
    7f5c:      	cbz	w0, 0x8040 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xa20>
    7f60:      	adrp	x0, 0x1000
    7f64:      	add	x0, x0, #0xaa0
    7f68:      	mov	w1, #0x2f               // =47
    7f6c:      	mov	w2, #0x7b               // =123
    7f70:      	bl	0x9b50 <__strrchr_chk@plt>
    7f74:      	adrp	x1, 0x1000
    7f78:      	add	x1, x1, #0xfe7
    7f7c:      	adrp	x2, 0x1000
    7f80:      	add	x2, x2, #0xbfc
    7f84:      	adrp	x4, 0x2000
    7f88:      	add	x4, x4, #0xbc
    7f8c:      	add	x3, x0, #0x1
    7f90:      	mov	w0, #0x3                // =3
    7f94:      	mov	w5, #0x43               // =67
    7f98:      	bl	0x9b60 <AI_Log_Print@plt>
    7f9c:      	stp	xzr, xzr, [x19]
    7fa0:      	add	x0, sp, #0x28
    7fa4:      	bl	0x9bf0 <_ZN2ge6BufferD1Ev@plt>
    7fa8:      	b	0x7fec <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x9cc>
    7fac:      	adrp	x0, 0x1000
    7fb0:      	add	x0, x0, #0xaa0
    7fb4:      	mov	w1, #0x2f               // =47
    7fb8:      	mov	w2, #0x7b               // =123
    7fbc:      	bl	0x9b50 <__strrchr_chk@plt>
    7fc0:      	adrp	x1, 0x2000
    7fc4:      	add	x1, x1, #0x22f
    7fc8:      	adrp	x2, 0x1000
    7fcc:      	add	x2, x2, #0xe41
    7fd0:      	adrp	x4, 0x2000
    7fd4:      	add	x4, x4, #0xbc
    7fd8:      	add	x3, x0, #0x1
    7fdc:      	mov	w0, #0x3                // =3
    7fe0:      	mov	w5, #0x3f               // =63
    7fe4:      	bl	0x9b60 <AI_Log_Print@plt>
    7fe8:      	stp	xzr, xzr, [x19]
    7fec:      	ldr	x19, [sp, #0x20]
    7ff0:      	cbz	x19, 0x801c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x9fc>
    7ff4:      	add	x1, x19, #0x8
    7ff8:      	mov	x0, #-0x1               // =-1
    7ffc:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    8000:      	cbnz	x0, 0x801c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x9fc>
    8004:      	ldr	x8, [x19]
    8008:      	mov	x0, x19
    800c:      	ldr	x8, [x8, #0x10]
    8010:      	blr	x8
    8014:      	mov	x0, x19
    8018:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    801c:      	ldr	x8, [x23, #0x28]
    8020:      	ldr	x9, [sp, #0x38]
    8024:      	cmp	x8, x9
    8028:      	b.ne	0x8154 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xb34>
    802c:      	ldp	x20, x19, [sp, #0x60]
    8030:      	ldp	x22, x21, [sp, #0x50]
    8034:      	ldp	x30, x23, [sp, #0x40]
    8038:      	add	sp, sp, #0x70
    803c:      	ret
    8040:      	add	x0, sp, #0x28
    8044:      	bl	0x9ce0 <_ZNK2ge6Buffer7GetDataEv@plt>
    8048:      	mov	x22, x0
    804c:      	add	x0, sp, #0x28
    8050:      	bl	0x9bd0 <_ZNK2ge6Buffer7GetSizeEv@plt>
    8054:      	mov	x1, x0
    8058:      	add	x8, sp, #0x8
    805c:      	mov	x0, x22
    8060:      	mov	w2, wzr
    8064:      	bl	0x9c30 <_ZN4hiai17CreateLocalBufferEPvmb@plt>
    8068:      	ldr	x8, [sp, #0x8]
    806c:      	cbz	x8, 0x80e0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xac0>
    8070:      	ldr	x0, [sp, #0x18]
    8074:      	stp	xzr, xzr, [x19]
    8078:      	add	x3, sp, #0x8
    807c:      	mov	x1, x21
    8080:      	mov	x2, x20
    8084:      	mov	x4, x19
    8088:      	ldr	x8, [x0]
    808c:      	ldr	x8, [x8, #0x10]
    8090:      	blr	x8
    8094:      	cbnz	w0, 0x80a0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xa80>
    8098:      	ldr	x8, [x19]
    809c:      	cbnz	x8, 0x8120 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xb00>
    80a0:      	adrp	x0, 0x1000
    80a4:      	add	x0, x0, #0xaa0
    80a8:      	mov	w1, #0x2f               // =47
    80ac:      	mov	w2, #0x7b               // =123
    80b0:      	bl	0x9b50 <__strrchr_chk@plt>
    80b4:      	adrp	x1, 0x1000
    80b8:      	add	x1, x1, #0xfe7
    80bc:      	adrp	x2, 0x1000
    80c0:      	add	x2, x2, #0xc83
    80c4:      	adrp	x4, 0x2000
    80c8:      	add	x4, x4, #0xbc
    80cc:      	add	x3, x0, #0x1
    80d0:      	mov	w0, #0x3                // =3
    80d4:      	mov	w5, #0x4d               // =77
    80d8:      	bl	0x9b60 <AI_Log_Print@plt>
    80dc:      	b	0x8120 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xb00>
    80e0:      	adrp	x0, 0x1000
    80e4:      	add	x0, x0, #0xaa0
    80e8:      	mov	w1, #0x2f               // =47
    80ec:      	mov	w2, #0x7b               // =123
    80f0:      	bl	0x9b50 <__strrchr_chk@plt>
    80f4:      	adrp	x1, 0x2000
    80f8:      	add	x1, x1, #0x22f
    80fc:      	adrp	x2, 0x1000
    8100:      	add	x2, x2, #0xf2c
    8104:      	adrp	x4, 0x2000
    8108:      	add	x4, x4, #0xbc
    810c:      	add	x3, x0, #0x1
    8110:      	mov	w0, #0x3                // =3
    8114:      	mov	w5, #0x48               // =72
    8118:      	bl	0x9b60 <AI_Log_Print@plt>
    811c:      	stp	xzr, xzr, [x19]
    8120:      	ldr	x19, [sp, #0x10]
    8124:      	cbz	x19, 0x7fa0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x980>
    8128:      	add	x1, x19, #0x8
    812c:      	mov	x0, #-0x1               // =-1
    8130:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    8134:      	cbnz	x0, 0x7fa0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x980>
    8138:      	ldr	x8, [x19]
    813c:      	mov	x0, x19
    8140:      	ldr	x8, [x8, #0x10]
    8144:      	blr	x8
    8148:      	mov	x0, x19
    814c:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    8150:      	b	0x7fa0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x980>
    8154:      	bl	0x9b00 <__stack_chk_fail@plt>
    8158:      	ret
    815c:      	b	0x9af0 <_ZdlPv@plt>
    8160:      	str	x30, [sp, #-0x10]!
    8164:      	mov	w0, #0x10               // =16
    8168:      	bl	0x9b20 <_Znwm@plt>
    816c:      	adrp	x8, 0xd000 <strncmp@plt+0x3260>
    8170:      	add	x8, x8, #0xde8
    8174:      	str	x8, [x0]
    8178:      	ldr	x30, [sp], #0x10
    817c:      	ret
    8180:      	adrp	x8, 0xd000 <strncmp@plt+0x3260>
    8184:      	add	x8, x8, #0xde8
    8188:      	str	x8, [x1]
    818c:      	ret
    8190:      	ret
    8194:      	b	0x9af0 <_ZdlPv@plt>
    8198:      	sub	sp, sp, #0xb0
    819c:      	str	x30, [sp, #0x60]
    81a0:      	stp	x26, x25, [sp, #0x70]
    81a4:      	stp	x24, x23, [sp, #0x80]
    81a8:      	stp	x22, x21, [sp, #0x90]
    81ac:      	stp	x20, x19, [sp, #0xa0]
    81b0:      	mrs	x23, TPIDR_EL0
    81b4:      	mov	x0, x1
    81b8:      	ldr	x8, [x23, #0x28]
    81bc:      	str	x8, [sp, #0x58]
    81c0:      	ldr	x8, [x1]
    81c4:      	stp	xzr, xzr, [sp, #0x40]
    81c8:      	str	xzr, [sp, #0x50]
    81cc:      	ldr	x8, [x8, #0x18]
    81d0:      	blr	x8
    81d4:      	bl	0x9cf0 <_ZN2ge8NodeSpec6OpDescEv@plt>
    81d8:      	mov	x19, x0
    81dc:      	str	x0, [sp, #0x18]
    81e0:      	adrp	x1, 0x1000
    81e4:      	add	x1, x1, #0xd5f
    81e8:      	add	x0, sp, #0x28
    81ec:      	bl	0x659c <.text+0xcc>
    81f0:      	add	x0, sp, #0x18
    81f4:      	add	x1, sp, #0x28
    81f8:      	add	x2, sp, #0x40
    81fc:      	bl	0x9d00 <_ZN2ge9AttrUtils10GetListIntEONS0_22ConstAttrHolderAdapterERKNSt6__ndk112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEERNS3_6vectorIlNS7_IlEEEE@plt>
    8200:      	ldrb	w8, [sp, #0x28]
    8204:      	tbz	w8, #0x0, 0x8210 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xbf0>
    8208:      	ldr	x0, [sp, #0x38]
    820c:      	bl	0x9af0 <_ZdlPv@plt>
    8210:      	ldp	x24, x22, [sp, #0x40]
    8214:      	mov	x0, x19
    8218:      	bl	0x9d10 <_ZNK2ge6OpDesc17GetInputsDescSizeEv@plt>
    821c:      	tbnz	w0, #0x1f, 0x8394 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xd74>
    8220:      	mov	x0, x19
    8224:      	bl	0x9d10 <_ZNK2ge6OpDesc17GetInputsDescSizeEv@plt>
    8228:      	ldr	x8, [x19]
    822c:      	mov	w20, w0
    8230:      	mov	x0, x19
    8234:      	ldr	x8, [x8, #0x50]
    8238:      	blr	x8
    823c:      	cmp	x22, x24
    8240:      	b.eq	0x838c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xd6c>
    8244:      	mov	x21, x0
    8248:      	sub	x8, x22, x24
    824c:      	adrp	x1, 0x1000
    8250:      	add	x1, x1, #0xd5f
    8254:      	add	x0, sp, #0x28
    8258:      	asr	x22, x8, #3
    825c:      	bl	0x659c <.text+0xcc>
    8260:      	add	x1, sp, #0x28
    8264:      	mov	x0, x19
    8268:      	bl	0x9d20 <_ZN2ge10AttrHolder7DelAttrERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE@plt>
    826c:      	ldrb	w8, [sp, #0x28]
    8270:      	tbz	w8, #0x0, 0x827c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xc5c>
    8274:      	ldr	x0, [sp, #0x38]
    8278:      	bl	0x9af0 <_ZdlPv@plt>
    827c:      	cmp	x22, x21
    8280:      	b.ne	0x83d4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xdb4>
    8284:      	mov	w8, w20
    8288:      	cmp	x22, x8
    828c:      	b.ne	0x83d4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xdb4>
    8290:      	cmp	x21, x8
    8294:      	b.ne	0x83d4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xdb4>
    8298:      	cmp	x22, #0x1
    829c:      	mov	x20, xzr
    82a0:      	adrp	x21, 0x1000
    82a4:      	add	x21, x21, #0xe70
    82a8:      	csinc	x24, x22, xzr, hi
    82ac:      	mov	w25, #0x1               // =1
    82b0:      	ldr	x8, [x19]
    82b4:      	mov	x0, x19
    82b8:      	mov	w1, w20
    82bc:      	ldr	x9, [x8, #0x38]
    82c0:      	add	x8, sp, #0x18
    82c4:      	blr	x9
    82c8:      	ldp	x26, x22, [sp, #0x18]
    82cc:      	cbz	x22, 0x82dc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xcbc>
    82d0:      	add	x1, x22, #0x8
    82d4:      	mov	w0, #0x1                // =1
    82d8:      	bl	0x9390 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1d70>
    82dc:      	add	x0, sp, #0x28
    82e0:      	mov	x1, x21
    82e4:      	str	x26, [sp, #0x10]
    82e8:      	bl	0x659c <.text+0xcc>
    82ec:      	add	x0, sp, #0x10
    82f0:      	add	x1, sp, #0x28
    82f4:      	add	x2, sp, #0xc
    82f8:      	strb	w25, [sp, #0xc]
    82fc:      	bl	0x9d30 <_ZN2ge9AttrUtils7SetBoolEONS0_17AttrHolderAdapterERKNSt6__ndk112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEERKb@plt>
    8300:      	ldrb	w8, [sp, #0x28]
    8304:      	tbz	w8, #0x0, 0x8310 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xcf0>
    8308:      	ldr	x0, [sp, #0x38]
    830c:      	bl	0x9af0 <_ZdlPv@plt>
    8310:      	str	xzr, [sp, #0x10]
    8314:      	cbz	x22, 0x8340 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xd20>
    8318:      	add	x1, x22, #0x8
    831c:      	mov	x0, #-0x1               // =-1
    8320:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    8324:      	cbnz	x0, 0x8340 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xd20>
    8328:      	ldr	x8, [x22]
    832c:      	mov	x0, x22
    8330:      	ldr	x8, [x8, #0x10]
    8334:      	blr	x8
    8338:      	mov	x0, x22
    833c:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    8340:      	ldr	x8, [sp, #0x40]
    8344:      	ldr	x0, [sp, #0x18]
    8348:      	ldr	x1, [x8, x20, lsl #3]
    834c:      	bl	0x9d40 <_ZN2ge10TensorDesc11SetDataTypeENS_8DataTypeE@plt>
    8350:      	ldr	x22, [sp, #0x20]
    8354:      	cbz	x22, 0x8380 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xd60>
    8358:      	add	x1, x22, #0x8
    835c:      	mov	x0, #-0x1               // =-1
    8360:      	bl	0x9a80 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2460>
    8364:      	cbnz	x0, 0x8380 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xd60>
    8368:      	ldr	x8, [x22]
    836c:      	mov	x0, x22
    8370:      	ldr	x8, [x8, #0x10]
    8374:      	blr	x8
    8378:      	mov	x0, x22
    837c:      	bl	0x9c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    8380:      	add	x20, x20, #0x1
    8384:      	cmp	x24, x20
    8388:      	b.ne	0x82b0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xc90>
    838c:      	mov	w19, wzr
    8390:      	b	0x8420 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xe00>
    8394:      	adrp	x0, 0x1000
    8398:      	add	x0, x0, #0xaa0
    839c:      	mov	w1, #0x2f               // =47
    83a0:      	mov	w2, #0x7b               // =123
    83a4:      	bl	0x9b50 <__strrchr_chk@plt>
    83a8:      	adrp	x1, 0x2000
    83ac:      	add	x1, x1, #0x22f
    83b0:      	adrp	x2, 0x2000
    83b4:      	add	x2, x2, #0x79
    83b8:      	adrp	x4, 0x2000
    83bc:      	add	x4, x4, #0x106
    83c0:      	add	x3, x0, #0x1
    83c4:      	mov	w0, #0x3                // =3
    83c8:      	mov	w5, #0x26               // =38
    83cc:      	bl	0x9b60 <AI_Log_Print@plt>
    83d0:      	b	0x841c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xdfc>
    83d4:      	adrp	x0, 0x1000
    83d8:      	add	x0, x0, #0xaa0
    83dc:      	mov	w1, #0x2f               // =47
    83e0:      	mov	w2, #0x7b               // =123
    83e4:      	bl	0x9b50 <__strrchr_chk@plt>
    83e8:      	adrp	x1, 0x1000
    83ec:      	add	x1, x1, #0xfe7
    83f0:      	adrp	x2, 0x1000
    83f4:      	add	x2, x2, #0xd6b
    83f8:      	adrp	x4, 0x2000
    83fc:      	add	x4, x4, #0x106
    8400:      	add	x3, x0, #0x1
    8404:      	mov	w0, #0x3                // =3
    8408:      	mov	w5, #0x2d               // =45
    840c:      	mov	x6, x22
    8410:      	mov	w7, w20
    8414:      	str	x21, [sp]
    8418:      	bl	0x9b60 <AI_Log_Print@plt>
    841c:      	mov	w19, #0x1               // =1
    8420:      	ldr	x0, [sp, #0x40]
    8424:      	cbz	x0, 0x8430 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xe10>
    8428:      	str	x0, [sp, #0x48]
    842c:      	bl	0x9af0 <_ZdlPv@plt>
    8430:      	ldr	x8, [x23, #0x28]
    8434:      	ldr	x9, [sp, #0x58]
    8438:      	cmp	x8, x9
    843c:      	b.ne	0x8460 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xe40>
    8440:      	mov	w0, w19
    8444:      	ldp	x20, x19, [sp, #0xa0]
    8448:      	ldp	x22, x21, [sp, #0x90]
    844c:      	ldr	x30, [sp, #0x60]
    8450:      	ldp	x24, x23, [sp, #0x80]
    8454:      	ldp	x26, x25, [sp, #0x70]
    8458:      	add	sp, sp, #0xb0
    845c:      	ret
    8460:      	bl	0x9b00 <__stack_chk_fail@plt>
    8464:      	stp	x30, x19, [sp, #-0x10]!
    8468:      	nop
    846c:      	adr	x19, 0x12328
    8470:      	adrp	x1, 0x1000
    8474:      	add	x1, x1, #0xd0c
    8478:      	mov	x8, x19
    847c:      	add	x0, x19, #0x68
    8480:      	strb	wzr, [x19]
    8484:      	stp	wzr, wzr, [x19, #0x4]
    8488:      	stp	xzr, xzr, [x19, #0x20]
    848c:      	str	xzr, [x8, #0x18]!
    8490:      	str	x8, [x19, #0x10]
    8494:      	stp	xzr, xzr, [x19, #0x30]
    8498:      	str	wzr, [x19, #0x40]
    849c:      	stp	xzr, xzr, [x19, #0x50]
    84a0:      	str	xzr, [x19, #0x48]
    84a4:      	str	wzr, [x19, #0x60]
    84a8:      	bl	0x659c <.text+0xcc>
    84ac:      	nop
    84b0:      	adr	x0, 0x6520 <.text+0x50>
    84b4:      	nop
    84b8:      	adr	x2, 0xddb0
    84bc:      	mov	x1, x19
    84c0:      	ldp	x30, x19, [sp], #0x10
    84c4:      	b	0x9ae0 <__cxa_atexit@plt>
    84c8:      	sub	sp, sp, #0xb0
    84cc:      	str	d8, [sp, #0x40]
    84d0:      	stp	x29, x30, [sp, #0x50]
    84d4:      	stp	x28, x27, [sp, #0x60]
    84d8:      	stp	x26, x25, [sp, #0x70]
    84dc:      	stp	x24, x23, [sp, #0x80]
    84e0:      	stp	x22, x21, [sp, #0x90]
    84e4:      	stp	x20, x19, [sp, #0xa0]
    84e8:      	mov	x20, x8
    84ec:      	mrs	x8, TPIDR_EL0
    84f0:      	movi	v0.2d, #0000000000000000
    84f4:      	str	x8, [sp, #0x10]
    84f8:      	nop
    84fc:      	adr	x22, 0x1d0c
    8500:      	ldr	x8, [x8, #0x28]
    8504:      	mov	x19, x0
    8508:      	mov	x9, x20
    850c:      	mov	x10, x20
    8510:      	add	x0, x20, #0x80
    8514:      	mov	x1, x22
    8518:      	str	x8, [sp, #0x38]
    851c:      	mov	x8, x20
    8520:      	str	xzr, [x9, #0x58]!
    8524:      	stur	d0, [x20, #0x24]
    8528:      	str	q0, [x8, #0x30]!
    852c:      	str	x8, [sp, #0x8]
    8530:      	str	x9, [x10, #0x50]!
    8534:      	str	x10, [sp, #0x18]
    8538:      	str	xzr, [x20, #0x60]
    853c:      	str	q0, [x20, #0x40]
    8540:      	stp	q0, q0, [x20]
    8544:      	strb	wzr, [x20, #0x20]
    8548:      	str	wzr, [x20, #0x68]
    854c:      	str	wzr, [x20, #0x70]
    8550:      	str	xzr, [x20, #0x78]
    8554:      	bl	0x659c <.text+0xcc>
    8558:      	movi	v0.2d, #0000000000000000
    855c:      	add	x0, x20, #0xa0
    8560:      	mov	x1, x22
    8564:      	str	d0, [x20, #0x98]
    8568:      	bl	0x659c <.text+0xcc>
    856c:      	add	x0, x20, #0xc0
    8570:      	mov	x1, x22
    8574:      	str	wzr, [x20, #0xb8]
    8578:      	bl	0x659c <.text+0xcc>
    857c:      	ldp	x9, x8, [x19, #0x28]
    8580:      	mov	x10, #-0x5555555555555556 // =-6148914691236517206
    8584:      	movk	x10, #0xaaab
    8588:      	mov	x0, x20
    858c:      	str	x20, [sp, #0x20]
    8590:      	sub	x8, x8, x9
    8594:      	ldr	w9, [x19, #0x8]
    8598:      	asr	x8, x8, #3
    859c:      	cmp	w9, #0x0
    85a0:      	mul	x1, x8, x10
    85a4:      	ldrb	w8, [x19]
    85a8:      	cset	w9, ne
    85ac:      	stp	w8, w9, [x20, #0x18]
    85b0:      	bl	0x88e8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x12c8>
    85b4:      	ldp	x8, x9, [x19, #0x28]
    85b8:      	cmp	x9, x8
    85bc:      	b.eq	0x86f4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x10d4>
    85c0:      	adrp	x9, 0x2000
    85c4:      	mov	x26, xzr
    85c8:      	mov	w28, #0x38              // =56
    85cc:      	ldr	d8, [x9, #0x348]
    85d0:      	mov	x29, #0x7ffffffffffffffc // =9223372036854775804
    85d4:      	mov	x24, #0x3fffffffffffffff // =4611686018427387903
    85d8:      	mov	w9, #0x18               // =24
    85dc:      	madd	x20, x26, x9, x8
    85e0:      	ldr	x8, [sp, #0x20]
    85e4:      	ldr	x25, [x8]
    85e8:      	nop
    85ec:      	madd	x22, x26, x28, x25
    85f0:      	ldp	x9, x8, [x20]
    85f4:      	mov	x0, x22
    85f8:      	sub	x8, x8, x9
    85fc:      	asr	x1, x8, #3
    8600:      	bl	0x8978 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1358>
    8604:      	ldp	x23, x21, [x20]
    8608:      	cmp	x23, x21
    860c:      	b.eq	0x86c8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x10a8>
    8610:      	ldr	x9, [x22, #0x8]
    8614:      	ldur	x8, [x22, #0x10]
    8618:      	ldr	w27, [x23]
    861c:      	cmp	x9, x8
    8620:      	b.hs	0x8630 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1010>
    8624:      	str	w27, [x9], #0x4
    8628:      	mov	x20, x9
    862c:      	b	0x86b4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1094>
    8630:      	ldr	x0, [x22]
    8634:      	sub	x10, x9, x0
    8638:      	asr	x20, x10, #2
    863c:      	add	x10, x20, #0x1
    8640:      	lsr	x11, x10, #62
    8644:      	cbnz	x11, 0x88d4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x12b4>
    8648:      	sub	x8, x8, x0
    864c:      	asr	x11, x8, #1
    8650:      	cmp	x11, x10
    8654:      	csel	x10, x11, x10, hi
    8658:      	cmp	x8, x29
    865c:      	csel	x1, x10, x24, lo
    8660:      	cbz	x1, 0x8678 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1058>
    8664:      	add	x0, x22, #0x10
    8668:      	bl	0x8ac0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x14a0>
    866c:      	mov	x8, x0
    8670:      	ldp	x0, x9, [x22]
    8674:      	b	0x867c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x105c>
    8678:      	mov	x8, xzr
    867c:      	add	x10, x8, x20, lsl #2
    8680:      	cmp	x9, x0
    8684:      	mov	x20, x10
    8688:      	str	w27, [x20], #0x4
    868c:      	b.eq	0x86a0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1080>
    8690:      	ldr	w11, [x9, #-0x4]!
    8694:      	cmp	x9, x0
    8698:      	str	w11, [x10, #-0x4]!
    869c:      	b.ne	0x8690 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1070>
    86a0:      	add	x8, x8, x1, lsl #2
    86a4:      	stp	x10, x20, [x22]
    86a8:      	str	x8, [x22, #0x10]
    86ac:      	cbz	x0, 0x86b4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1094>
    86b0:      	bl	0x9af0 <_ZdlPv@plt>
    86b4:      	add	x23, x23, #0x8
    86b8:      	mov	x9, x20
    86bc:      	str	x20, [x22, #0x8]
    86c0:      	cmp	x23, x21
    86c4:      	b.ne	0x8614 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xff4>
    86c8:      	madd	x8, x26, x28, x25
    86cc:      	mov	x10, #-0x5555555555555556 // =-6148914691236517206
    86d0:      	add	x26, x26, #0x1
    86d4:      	movk	x10, #0xaaab
    86d8:      	str	d8, [x8, #0x18]
    86dc:      	ldp	x8, x9, [x19, #0x28]
    86e0:      	sub	x9, x9, x8
    86e4:      	asr	x9, x9, #3
    86e8:      	mul	x9, x9, x10
    86ec:      	cmp	x26, x9
    86f0:      	b.lo	0x85d8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0xfb8>
    86f4:      	ldr	w8, [x19, #0x4]
    86f8:      	ldr	x27, [x19, #0x10]
    86fc:      	add	x26, x19, #0x18
    8700:      	ldr	x9, [sp, #0x20]
    8704:      	cmp	w8, #0x1
    8708:      	cset	w8, eq
    870c:      	cmp	x27, x26
    8710:      	stp	wzr, w8, [x9, #0x30]
    8714:      	b.eq	0x8840 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1220>
    8718:      	mov	x28, #0x7ffffffffffffffc // =9223372036854775804
    871c:      	mov	x29, #0x3fffffffffffffff // =4611686018427387903
    8720:      	ldr	x0, [sp, #0x18]
    8724:      	add	x1, x27, #0x20
    8728:      	add	x3, sp, #0x30
    872c:      	add	x4, sp, #0x2f
    8730:      	nop
    8734:      	adr	x2, 0x2350
    8738:      	str	x1, [sp, #0x30]
    873c:      	bl	0x8ae8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x14c8>
    8740:      	ldp	x24, x25, [x27, #0x38]
    8744:      	cmp	x24, x25
    8748:      	b.eq	0x8808 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x11e8>
    874c:      	ldr	x9, [x0, #0x40]
    8750:      	mov	x23, x0
    8754:      	ldur	x8, [x23, #0x48]
    8758:      	ldr	w21, [x24]
    875c:      	cmp	x9, x8
    8760:      	b.hs	0x8770 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1150>
    8764:      	str	w21, [x9], #0x4
    8768:      	mov	x22, x9
    876c:      	b	0x87f4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x11d4>
    8770:      	ldur	x0, [x23, #0x38]
    8774:      	sub	x10, x9, x0
    8778:      	asr	x20, x10, #2
    877c:      	add	x10, x20, #0x1
    8780:      	lsr	x11, x10, #62
    8784:      	cbnz	x11, 0x88dc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x12bc>
    8788:      	sub	x8, x8, x0
    878c:      	asr	x11, x8, #1
    8790:      	cmp	x11, x10
    8794:      	csel	x10, x11, x10, hi
    8798:      	cmp	x8, x28
    879c:      	csel	x1, x10, x29, lo
    87a0:      	cbz	x1, 0x87b8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1198>
    87a4:      	add	x0, x23, #0x48
    87a8:      	bl	0x8f2c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x190c>
    87ac:      	mov	x8, x0
    87b0:      	ldp	x0, x9, [x23, #0x38]
    87b4:      	b	0x87bc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x119c>
    87b8:      	mov	x8, xzr
    87bc:      	add	x10, x8, x20, lsl #2
    87c0:      	cmp	x9, x0
    87c4:      	mov	x22, x10
    87c8:      	str	w21, [x22], #0x4
    87cc:      	b.eq	0x87e0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x11c0>
    87d0:      	ldr	w11, [x9, #-0x4]!
    87d4:      	cmp	x9, x0
    87d8:      	str	w11, [x10, #-0x4]!
    87dc:      	b.ne	0x87d0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x11b0>
    87e0:      	add	x8, x8, x1, lsl #2
    87e4:      	stp	x10, x22, [x23, #0x38]
    87e8:      	str	x8, [x23, #0x48]
    87ec:      	cbz	x0, 0x87f4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x11d4>
    87f0:      	bl	0x9af0 <_ZdlPv@plt>
    87f4:      	add	x24, x24, #0x4
    87f8:      	mov	x9, x22
    87fc:      	str	x22, [x23, #0x40]
    8800:      	cmp	x24, x25
    8804:      	b.ne	0x8754 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1134>
    8808:      	ldr	x9, [x27, #0x8]
    880c:      	cbz	x9, 0x8820 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1200>
    8810:      	mov	x8, x9
    8814:      	ldr	x9, [x9]
    8818:      	cbnz	x9, 0x8810 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x11f0>
    881c:      	b	0x8834 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1214>
    8820:      	ldr	x8, [x27, #0x10]
    8824:      	ldr	x9, [x8]
    8828:      	cmp	x9, x27
    882c:      	mov	x27, x8
    8830:      	b.ne	0x8820 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1200>
    8834:      	cmp	x8, x26
    8838:      	mov	x27, x8
    883c:      	b.ne	0x8720 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1100>
    8840:      	ldr	x8, [sp, #0x20]
    8844:      	ldr	x8, [x8, #0x60]
    8848:      	cbz	x8, 0x8858 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1238>
    884c:      	ldr	x9, [sp, #0x8]
    8850:      	mov	w8, #0x2                // =2
    8854:      	str	w8, [x9]
    8858:      	ldr	x10, [sp, #0x20]
    885c:      	ldr	w8, [x19, #0x40]
    8860:      	add	x9, x19, #0x48
    8864:      	add	x0, x10, #0x38
    8868:      	str	w8, [x10, #0x70]
    886c:      	cmp	x0, x9
    8870:      	b.eq	0x8884 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1264>
    8874:      	ldp	x1, x2, [x19, #0x48]
    8878:      	sub	x8, x2, x1
    887c:      	asr	x3, x8, #2
    8880:      	bl	0x925c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1c3c>
    8884:      	ldr	x9, [sp, #0x20]
    8888:      	ldr	w8, [x19, #0x60]
    888c:      	add	x1, x19, #0x68
    8890:      	add	x0, x9, #0x80
    8894:      	str	w8, [x9, #0x68]
    8898:      	bl	0x9d50 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_@plt>
    889c:      	ldr	x8, [sp, #0x10]
    88a0:      	ldr	x8, [x8, #0x28]
    88a4:      	ldr	x9, [sp, #0x38]
    88a8:      	cmp	x8, x9
    88ac:      	b.ne	0x88e4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x12c4>
    88b0:      	ldp	x20, x19, [sp, #0xa0]
    88b4:      	ldr	d8, [sp, #0x40]
    88b8:      	ldp	x22, x21, [sp, #0x90]
    88bc:      	ldp	x24, x23, [sp, #0x80]
    88c0:      	ldp	x26, x25, [sp, #0x70]
    88c4:      	ldp	x28, x27, [sp, #0x60]
    88c8:      	ldp	x29, x30, [sp, #0x50]
    88cc:      	add	sp, sp, #0xb0
    88d0:      	ret
    88d4:      	mov	x0, x22
    88d8:      	bl	0x8ab4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1494>
    88dc:      	add	x0, x23, #0x38
    88e0:      	bl	0x8f20 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1900>
    88e4:      	bl	0x9b00 <__stack_chk_fail@plt>
    88e8:      	stp	x30, x21, [sp, #-0x20]!
    88ec:      	stp	x20, x19, [sp, #0x10]
    88f0:      	ldp	x9, x20, [x0]
    88f4:      	mov	x10, #0x6db7            // =28087
    88f8:      	movk	x10, #0xb6db, lsl #16
    88fc:      	mov	x19, x0
    8900:      	movk	x10, #0xdb6d, lsl #32
    8904:      	sub	x8, x20, x9
    8908:      	movk	x10, #0x6db6, lsl #48
    890c:      	asr	x8, x8, #3
    8910:      	mul	x8, x8, x10
    8914:      	subs	x8, x1, x8
    8918:      	b.ls	0x8930 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1310>
    891c:      	mov	x0, x19
    8920:      	ldp	x20, x19, [sp, #0x10]
    8924:      	mov	x1, x8
    8928:      	ldp	x30, x21, [sp], #0x20
    892c:      	b	0x8f54 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1934>
    8930:      	b.hs	0x895c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x133c>
    8934:      	mov	w8, #0x38               // =56
    8938:      	madd	x21, x1, x8, x9
    893c:      	cmp	x20, x21
    8940:      	b.eq	0x8958 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1338>
    8944:      	sub	x20, x20, #0x38
    8948:      	add	x0, x19, #0x10
    894c:      	mov	x1, x20
    8950:      	bl	0x7428 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x2b4>
    8954:      	b	0x893c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x131c>
    8958:      	str	x21, [x19, #0x8]
    895c:      	ldp	x20, x19, [sp, #0x10]
    8960:      	ldp	x30, x21, [sp], #0x20
    8964:      	ret
    8968:      	str	x30, [sp, #-0x10]!
    896c:      	adrp	x0, 0x2000
    8970:      	add	x0, x0, #0x310
    8974:      	bl	0x9ca0 <_ZNSt6__ndk122__libcpp_verbose_abortEPKcz@plt>
    8978:      	ldp	x8, x9, [x0]
    897c:      	sub	x10, x9, x8
    8980:      	asr	x9, x10, #2
    8984:      	cmp	x1, x10, asr #2
    8988:      	b.ls	0x8994 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1374>
    898c:      	sub	x1, x1, x9
    8990:      	b	0x89a8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1388>
    8994:      	cmp	x1, x9
    8998:      	b.hs	0x89a4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1384>
    899c:      	add	x8, x8, x1, lsl #2
    89a0:      	str	x8, [x0, #0x8]
    89a4:      	ret
    89a8:      	str	x30, [sp, #-0x40]!
    89ac:      	stp	x24, x23, [sp, #0x10]
    89b0:      	stp	x22, x21, [sp, #0x20]
    89b4:      	stp	x20, x19, [sp, #0x30]
    89b8:      	mov	x19, x0
    89bc:      	ldr	x8, [x0, #0x10]!
    89c0:      	ldur	x20, [x0, #-0x8]
    89c4:      	mov	x21, x1
    89c8:      	sub	x9, x8, x20
    89cc:      	cmp	x1, x9, asr #2
    89d0:      	b.ls	0x8a1c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x13fc>
    89d4:      	ldr	x22, [x19]
    89d8:      	sub	x9, x20, x22
    89dc:      	add	x10, x21, x9, asr #2
    89e0:      	lsr	x11, x10, #62
    89e4:      	cbnz	x11, 0x8aac <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x148c>
    89e8:      	sub	x8, x8, x22
    89ec:      	mov	x12, #0x7ffffffffffffffc // =9223372036854775804
    89f0:      	asr	x23, x9, #2
    89f4:      	asr	x11, x8, #1
    89f8:      	cmp	x11, x10
    89fc:      	csel	x10, x11, x10, hi
    8a00:      	cmp	x8, x12
    8a04:      	mov	x8, #0x3fffffffffffffff // =4611686018427387903
    8a08:      	csel	x1, x10, x8, lo
    8a0c:      	cbz	x1, 0x8a3c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x141c>
    8a10:      	bl	0x8ac0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x14a0>
    8a14:      	ldp	x22, x20, [x19]
    8a18:      	b	0x8a40 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1420>
    8a1c:      	cbz	x21, 0x8a34 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1414>
    8a20:      	lsl	x2, x21, #2
    8a24:      	mov	x0, x20
    8a28:      	mov	w1, wzr
    8a2c:      	bl	0x9d60 <memset@plt>
    8a30:      	add	x20, x20, x21, lsl #2
    8a34:      	str	x20, [x19, #0x8]
    8a38:      	b	0x8a98 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1478>
    8a3c:      	mov	x0, xzr
    8a40:      	add	x23, x0, x23, lsl #2
    8a44:      	lsl	x2, x21, #2
    8a48:      	add	x24, x0, x1, lsl #2
    8a4c:      	mov	w1, wzr
    8a50:      	mov	x0, x23
    8a54:      	bl	0x9d60 <memset@plt>
    8a58:      	add	x8, x23, x21, lsl #2
    8a5c:      	cmp	x20, x22
    8a60:      	b.eq	0x8a74 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1454>
    8a64:      	ldr	w9, [x20, #-0x4]!
    8a68:      	cmp	x20, x22
    8a6c:      	str	w9, [x23, #-0x4]!
    8a70:      	b.ne	0x8a64 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1444>
    8a74:      	stp	x23, x8, [x19]
    8a78:      	str	x24, [x19, #0x10]
    8a7c:      	cbz	x22, 0x8a98 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1478>
    8a80:      	mov	x0, x22
    8a84:      	ldp	x20, x19, [sp, #0x30]
    8a88:      	ldp	x22, x21, [sp, #0x20]
    8a8c:      	ldp	x24, x23, [sp, #0x10]
    8a90:      	ldr	x30, [sp], #0x40
    8a94:      	b	0x9af0 <_ZdlPv@plt>
    8a98:      	ldp	x20, x19, [sp, #0x30]
    8a9c:      	ldp	x22, x21, [sp, #0x20]
    8aa0:      	ldp	x24, x23, [sp, #0x10]
    8aa4:      	ldr	x30, [sp], #0x40
    8aa8:      	ret
    8aac:      	mov	x0, x19
    8ab0:      	bl	0x8ab4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1494>
    8ab4:      	adrp	x0, 0x2000
    8ab8:      	add	x0, x0, #0x1a7
    8abc:      	bl	0x74d0 <_ZN2ge5GraphD0Ev+0x34>
    8ac0:      	stp	x30, x19, [sp, #-0x10]!
    8ac4:      	lsr	x8, x1, #62
    8ac8:      	cbnz	x8, 0x8ae4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x14c4>
    8acc:      	lsl	x0, x1, #2
    8ad0:      	mov	x19, x1
    8ad4:      	bl	0x9b20 <_Znwm@plt>
    8ad8:      	mov	x1, x19
    8adc:      	ldp	x30, x19, [sp], #0x10
    8ae0:      	ret
    8ae4:      	bl	0x8968 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1348>
    8ae8:      	sub	sp, sp, #0x70
    8aec:      	stp	x30, x25, [sp, #0x30]
    8af0:      	stp	x24, x23, [sp, #0x40]
    8af4:      	stp	x22, x21, [sp, #0x50]
    8af8:      	stp	x20, x19, [sp, #0x60]
    8afc:      	mrs	x25, TPIDR_EL0
    8b00:      	mov	x23, x2
    8b04:      	mov	x2, x1
    8b08:      	ldr	x8, [x25, #0x28]
    8b0c:      	add	x1, sp, #0x8
    8b10:      	mov	x21, x4
    8b14:      	mov	x22, x3
    8b18:      	mov	x20, x0
    8b1c:      	str	x8, [sp, #0x28]
    8b20:      	bl	0x8ba8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1588>
    8b24:      	ldr	x19, [x0]
    8b28:      	cbz	x19, 0x8b34 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1514>
    8b2c:      	mov	x1, xzr
    8b30:      	b	0x8b78 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1558>
    8b34:      	mov	x24, x0
    8b38:      	add	x8, sp, #0x10
    8b3c:      	mov	x0, x20
    8b40:      	mov	x1, x23
    8b44:      	mov	x2, x22
    8b48:      	mov	x3, x21
    8b4c:      	bl	0x8c34 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1614>
    8b50:      	ldp	x1, x3, [sp, #0x8]
    8b54:      	mov	x0, x20
    8b58:      	mov	x2, x24
    8b5c:      	bl	0x8ca8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1688>
    8b60:      	ldr	x19, [sp, #0x10]
    8b64:      	add	x0, sp, #0x10
    8b68:      	mov	x1, xzr
    8b6c:      	str	xzr, [sp, #0x10]
    8b70:      	bl	0x8eec <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x18cc>
    8b74:      	mov	w1, #0x1                // =1
    8b78:      	ldr	x8, [x25, #0x28]
    8b7c:      	ldr	x9, [sp, #0x28]
    8b80:      	cmp	x8, x9
    8b84:      	b.ne	0x8ba4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1584>
    8b88:      	mov	x0, x19
    8b8c:      	ldp	x20, x19, [sp, #0x60]
    8b90:      	ldp	x22, x21, [sp, #0x50]
    8b94:      	ldp	x24, x23, [sp, #0x40]
    8b98:      	ldp	x30, x25, [sp, #0x30]
    8b9c:      	add	sp, sp, #0x70
    8ba0:      	ret
    8ba4:      	bl	0x9b00 <__stack_chk_fail@plt>
    8ba8:      	stp	x30, x23, [sp, #-0x30]!
    8bac:      	stp	x22, x21, [sp, #0x10]
    8bb0:      	stp	x20, x19, [sp, #0x20]
    8bb4:      	mov	x20, x0
    8bb8:      	mov	x19, x1
    8bbc:      	ldr	x8, [x20, #0x8]!
    8bc0:      	cbz	x8, 0x8c18 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x15f8>
    8bc4:      	mov	x21, x2
    8bc8:      	mov	x22, x0
    8bcc:      	add	x0, x22, #0x10
    8bd0:      	add	x2, x8, #0x20
    8bd4:      	mov	x1, x21
    8bd8:      	mov	x23, x8
    8bdc:      	bl	0x8cf0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x16d0>
    8be0:      	tbz	w0, #0x0, 0x8bf4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x15d4>
    8be4:      	ldr	x8, [x23]
    8be8:      	mov	x20, x23
    8bec:      	cbnz	x8, 0x8bcc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x15ac>
    8bf0:      	b	0x8c1c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x15fc>
    8bf4:      	add	x0, x22, #0x10
    8bf8:      	add	x1, x23, #0x20
    8bfc:      	mov	x2, x21
    8c00:      	bl	0x8cf0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x16d0>
    8c04:      	tbz	w0, #0x0, 0x8c1c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x15fc>
    8c08:      	mov	x20, x23
    8c0c:      	ldr	x8, [x20, #0x8]!
    8c10:      	cbnz	x8, 0x8bcc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x15ac>
    8c14:      	b	0x8c1c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x15fc>
    8c18:      	mov	x23, x20
    8c1c:      	mov	x0, x20
    8c20:      	str	x23, [x19]
    8c24:      	ldp	x20, x19, [sp, #0x20]
    8c28:      	ldp	x22, x21, [sp, #0x10]
    8c2c:      	ldp	x30, x23, [sp], #0x30
    8c30:      	ret
    8c34:      	str	x30, [sp, #-0x30]!
    8c38:      	stp	x22, x21, [sp, #0x10]
    8c3c:      	stp	x20, x19, [sp, #0x20]
    8c40:      	add	x22, x0, #0x8
    8c44:      	mov	w0, #0x50               // =80
    8c48:      	mov	x21, x2
    8c4c:      	mov	x19, x8
    8c50:      	bl	0x9b20 <_Znwm@plt>
    8c54:      	ldr	x8, [x21]
    8c58:      	mov	x20, x0
    8c5c:      	stp	x0, x22, [x19]
    8c60:      	ldrb	w9, [x8]
    8c64:      	tbnz	w9, #0x0, 0x8c7c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x165c>
    8c68:      	ldr	x9, [x8, #0x10]
    8c6c:      	ldr	q0, [x8]
    8c70:      	stur	x9, [x20, #0x30]
    8c74:      	stur	q0, [x20, #0x20]
    8c78:      	b	0x8c88 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1668>
    8c7c:      	ldp	x2, x1, [x8, #0x8]
    8c80:      	add	x0, x20, #0x20
    8c84:      	bl	0x74e4 <_ZN2ge5GraphD0Ev+0x48>
    8c88:      	mov	w8, #0x1                // =1
    8c8c:      	stp	xzr, xzr, [x20, #0x38]
    8c90:      	str	xzr, [x20, #0x48]
    8c94:      	ldp	x22, x21, [sp, #0x10]
    8c98:      	strb	w8, [x19, #0x10]
    8c9c:      	ldp	x20, x19, [sp, #0x20]
    8ca0:      	ldr	x30, [sp], #0x30
    8ca4:      	ret
    8ca8:      	stp	x30, x19, [sp, #-0x10]!
    8cac:      	stp	xzr, xzr, [x3]
    8cb0:      	mov	x19, x0
    8cb4:      	str	x1, [x3, #0x10]
    8cb8:      	str	x3, [x2]
    8cbc:      	ldr	x8, [x0]
    8cc0:      	ldr	x8, [x8]
    8cc4:      	cbz	x8, 0x8cd0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x16b0>
    8cc8:      	str	x8, [x19]
    8ccc:      	ldr	x3, [x2]
    8cd0:      	ldr	x0, [x19, #0x8]
    8cd4:      	mov	x1, x3
    8cd8:      	bl	0x8d58 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1738>
    8cdc:      	ldr	x8, [x19, #0x10]
    8ce0:      	add	x8, x8, #0x1
    8ce4:      	str	x8, [x19, #0x10]
    8ce8:      	ldp	x30, x19, [sp], #0x10
    8cec:      	ret
    8cf0:      	str	x30, [sp, #-0x20]!
    8cf4:      	stp	x20, x19, [sp, #0x10]
    8cf8:      	ldrb	w8, [x2]
    8cfc:      	ldp	x11, x10, [x2, #0x8]
    8d00:      	ldrb	w9, [x1]
    8d04:      	lsr	x12, x8, #1
    8d08:      	tst	w8, #0x1
    8d0c:      	csinc	x8, x10, x2, ne
    8d10:      	lsr	x10, x9, #1
    8d14:      	csel	x19, x12, x11, eq
    8d18:      	tst	w9, #0x1
    8d1c:      	ldp	x13, x9, [x1, #0x8]
    8d20:      	csel	x20, x10, x13, eq
    8d24:      	csinc	x0, x9, x1, ne
    8d28:      	mov	x1, x8
    8d2c:      	cmp	x19, x20
    8d30:      	csel	x2, x19, x20, lo
    8d34:      	bl	0x9d70 <memcmp@plt>
    8d38:      	cmp	x20, x19
    8d3c:      	ldp	x20, x19, [sp, #0x10]
    8d40:      	cset	w8, lo
    8d44:      	cmp	w0, #0x0
    8d48:      	cset	w9, lt
    8d4c:      	csel	w0, w8, w9, eq
    8d50:      	ldr	x30, [sp], #0x20
    8d54:      	ret
    8d58:      	cmp	x1, x0
    8d5c:      	cset	w8, eq
    8d60:      	strb	w8, [x1, #0x18]
    8d64:      	b.eq	0x8dc4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x17a4>
    8d68:      	mov	w10, #0x1               // =1
    8d6c:      	ldr	x9, [x1, #0x10]
    8d70:      	ldrb	w8, [x9, #0x18]
    8d74:      	cbnz	w8, 0x8dc4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x17a4>
    8d78:      	ldr	x8, [x9, #0x10]
    8d7c:      	ldr	x11, [x8]
    8d80:      	cmp	x11, x9
    8d84:      	b.eq	0x8d98 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1778>
    8d88:      	cbz	x11, 0x8dc8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x17a8>
    8d8c:      	ldrb	w12, [x11, #0x18]!
    8d90:      	cbz	w12, 0x8da8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1788>
    8d94:      	b	0x8dc8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x17a8>
    8d98:      	ldr	x11, [x8, #0x8]
    8d9c:      	cbz	x11, 0x8ddc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x17bc>
    8da0:      	ldrb	w12, [x11, #0x18]!
    8da4:      	cbnz	w12, 0x8ddc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x17bc>
    8da8:      	cmp	x8, x0
    8dac:      	strb	w10, [x9, #0x18]
    8db0:      	mov	x1, x8
    8db4:      	cset	w9, eq
    8db8:      	strb	w9, [x8, #0x18]
    8dbc:      	strb	w10, [x11]
    8dc0:      	b.ne	0x8d6c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x174c>
    8dc4:      	ret
    8dc8:      	ldr	x10, [x9]
    8dcc:      	cmp	x10, x1
    8dd0:      	b.eq	0x8e30 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1810>
    8dd4:      	mov	x1, x9
    8dd8:      	b	0x8e68 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1848>
    8ddc:      	ldr	x10, [x9]
    8de0:      	cmp	x10, x1
    8de4:      	b.eq	0x8ea8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1888>
    8de8:      	ldr	x10, [x9, #0x8]
    8dec:      	mov	x11, x9
    8df0:      	ldr	x12, [x10]
    8df4:      	str	x12, [x9, #0x8]
    8df8:      	cbz	x12, 0x8e08 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x17e8>
    8dfc:      	str	x9, [x12, #0x10]
    8e00:      	ldr	x8, [x9, #0x10]
    8e04:      	ldr	x11, [x8]
    8e08:      	add	x12, x8, #0x8
    8e0c:      	cmp	x11, x9
    8e10:      	str	x8, [x10, #0x10]
    8e14:      	csel	x8, x8, x12, eq
    8e18:      	str	x10, [x8]
    8e1c:      	str	x10, [x9, #0x10]
    8e20:      	ldr	x8, [x10, #0x10]
    8e24:      	str	x9, [x10]
    8e28:      	ldr	x9, [x8]
    8e2c:      	b	0x8eac <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x188c>
    8e30:      	ldr	x10, [x1, #0x8]
    8e34:      	str	x10, [x9]
    8e38:      	cbz	x10, 0x8e44 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1824>
    8e3c:      	str	x9, [x10, #0x10]
    8e40:      	ldr	x8, [x9, #0x10]
    8e44:      	mov	x10, x8
    8e48:      	str	x8, [x1, #0x10]
    8e4c:      	ldr	x11, [x10], #0x8
    8e50:      	cmp	x11, x9
    8e54:      	csel	x8, x8, x10, eq
    8e58:      	str	x1, [x8]
    8e5c:      	str	x1, [x9, #0x10]
    8e60:      	ldr	x8, [x1, #0x10]
    8e64:      	str	x9, [x1, #0x8]
    8e68:      	ldr	x9, [x8, #0x8]
    8e6c:      	mov	w10, #0x1               // =1
    8e70:      	strb	w10, [x1, #0x18]
    8e74:      	ldr	x10, [x9]
    8e78:      	strb	wzr, [x8, #0x18]
    8e7c:      	str	x10, [x8, #0x8]
    8e80:      	cbz	x10, 0x8e88 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1868>
    8e84:      	str	x8, [x10, #0x10]
    8e88:      	ldr	x10, [x8, #0x10]
    8e8c:      	ldr	x11, [x10]
    8e90:      	str	x10, [x9, #0x10]
    8e94:      	cmp	x11, x8
    8e98:      	cset	w11, ne
    8e9c:      	str	x9, [x10, w11, uxtw #3]
    8ea0:      	str	x8, [x9]
    8ea4:      	b	0x8ee4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x18c4>
    8ea8:      	mov	x10, x9
    8eac:      	ldr	x11, [x9, #0x8]
    8eb0:      	mov	w12, #0x1               // =1
    8eb4:      	strb	w12, [x10, #0x18]
    8eb8:      	strb	wzr, [x8, #0x18]
    8ebc:      	str	x11, [x8]
    8ec0:      	cbz	x11, 0x8ec8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x18a8>
    8ec4:      	str	x8, [x11, #0x10]
    8ec8:      	ldr	x10, [x8, #0x10]
    8ecc:      	ldr	x11, [x10]
    8ed0:      	str	x10, [x9, #0x10]
    8ed4:      	cmp	x11, x8
    8ed8:      	cset	w11, ne
    8edc:      	str	x9, [x10, w11, uxtw #3]
    8ee0:      	str	x8, [x9, #0x8]
    8ee4:      	str	x9, [x8, #0x10]
    8ee8:      	ret
    8eec:      	stp	x30, x19, [sp, #-0x10]!
    8ef0:      	ldr	x19, [x0]
    8ef4:      	str	x1, [x0]
    8ef8:      	cbz	x19, 0x8f18 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x18f8>
    8efc:      	ldrb	w8, [x0, #0x10]
    8f00:      	cbz	w8, 0x8f0c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x18ec>
    8f04:      	add	x0, x19, #0x20
    8f08:      	bl	0x7384 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x210>
    8f0c:      	mov	x0, x19
    8f10:      	ldp	x30, x19, [sp], #0x10
    8f14:      	b	0x9af0 <_ZdlPv@plt>
    8f18:      	ldp	x30, x19, [sp], #0x10
    8f1c:      	ret
    8f20:      	adrp	x0, 0x2000
    8f24:      	add	x0, x0, #0x1a7
    8f28:      	bl	0x74d0 <_ZN2ge5GraphD0Ev+0x34>
    8f2c:      	stp	x30, x19, [sp, #-0x10]!
    8f30:      	lsr	x8, x1, #62
    8f34:      	cbnz	x8, 0x8f50 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1930>
    8f38:      	lsl	x0, x1, #2
    8f3c:      	mov	x19, x1
    8f40:      	bl	0x9b20 <_Znwm@plt>
    8f44:      	mov	x1, x19
    8f48:      	ldp	x30, x19, [sp], #0x10
    8f4c:      	ret
    8f50:      	bl	0x8968 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1348>
    8f54:      	sub	sp, sp, #0x70
    8f58:      	str	x30, [sp, #0x30]
    8f5c:      	stp	x24, x23, [sp, #0x40]
    8f60:      	stp	x22, x21, [sp, #0x50]
    8f64:      	stp	x20, x19, [sp, #0x60]
    8f68:      	mrs	x21, TPIDR_EL0
    8f6c:      	mov	x19, x0
    8f70:      	mov	x20, x1
    8f74:      	ldr	x8, [x21, #0x28]
    8f78:      	str	x8, [sp, #0x28]
    8f7c:      	ldr	x8, [x0, #0x10]!
    8f80:      	ldur	x22, [x0, #-0x8]
    8f84:      	sub	x9, x8, x22
    8f88:      	asr	x10, x9, #3
    8f8c:      	mov	x9, #0x6db7             // =28087
    8f90:      	movk	x9, #0xb6db, lsl #16
    8f94:      	movk	x9, #0xdb6d, lsl #32
    8f98:      	movk	x9, #0x6db6, lsl #48
    8f9c:      	mul	x10, x10, x9
    8fa0:      	cmp	x10, x1
    8fa4:      	b.hs	0x9014 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x19f4>
    8fa8:      	ldr	x12, [x19]
    8fac:      	sub	x10, x22, x12
    8fb0:      	asr	x10, x10, #3
    8fb4:      	mul	x22, x10, x9
    8fb8:      	mov	x10, #0x2492            // =9362
    8fbc:      	movk	x10, #0x9249, lsl #16
    8fc0:      	movk	x10, #0x4924, lsl #32
    8fc4:      	movk	x10, #0x492, lsl #48
    8fc8:      	add	x11, x22, x20
    8fcc:      	cmp	x11, x10
    8fd0:      	b.hi	0x90fc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1adc>
    8fd4:      	sub	x8, x8, x12
    8fd8:      	mov	x12, #0x9249            // =37449
    8fdc:      	str	x0, [sp, #0x20]
    8fe0:      	asr	x8, x8, #3
    8fe4:      	movk	x12, #0x4924, lsl #16
    8fe8:      	movk	x12, #0x2492, lsl #32
    8fec:      	mul	x8, x8, x9
    8ff0:      	movk	x12, #0x249, lsl #48
    8ff4:      	lsl	x9, x8, #1
    8ff8:      	cmp	x9, x11
    8ffc:      	csel	x9, x9, x11, hi
    9000:      	cmp	x8, x12
    9004:      	csel	x1, x9, x10, lo
    9008:      	cbz	x1, 0x9064 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1a44>
    900c:      	bl	0x91e0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1bc0>
    9010:      	b	0x9068 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1a48>
    9014:      	cbz	x20, 0x905c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1a3c>
    9018:      	mov	w8, #0x38               // =56
    901c:      	mov	w24, #0x1               // =1
    9020:      	madd	x23, x20, x8, x22
    9024:      	nop
    9028:      	adr	x20, 0x1d0c
    902c:      	movi	v0.2d, #0000000000000000
    9030:      	mov	x0, x22
    9034:      	mov	x1, x20
    9038:      	str	xzr, [x22, #0x30]
    903c:      	stp	q0, q0, [x22]
    9040:      	str	q0, [x0, #0x20]!
    9044:      	str	w24, [x22, #0x18]
    9048:      	bl	0x659c <.text+0xcc>
    904c:      	add	x22, x22, #0x38
    9050:      	cmp	x22, x23
    9054:      	b.ne	0x902c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1a0c>
    9058:      	mov	x22, x23
    905c:      	str	x22, [x19, #0x8]
    9060:      	b	0x90d0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ab0>
    9064:      	mov	x0, xzr
    9068:      	mov	w8, #0x38               // =56
    906c:      	mov	w24, #0x1               // =1
    9070:      	madd	x22, x22, x8, x0
    9074:      	madd	x9, x1, x8, x0
    9078:      	madd	x23, x20, x8, x22
    907c:      	nop
    9080:      	adr	x20, 0x1d0c
    9084:      	stp	x0, x22, [sp]
    9088:      	str	x9, [sp, #0x18]
    908c:      	movi	v0.2d, #0000000000000000
    9090:      	mov	x0, x22
    9094:      	mov	x1, x20
    9098:      	str	xzr, [x22, #0x30]
    909c:      	stp	q0, q0, [x22]
    90a0:      	str	q0, [x0, #0x20]!
    90a4:      	str	w24, [x22, #0x18]
    90a8:      	bl	0x659c <.text+0xcc>
    90ac:      	add	x22, x22, #0x38
    90b0:      	cmp	x22, x23
    90b4:      	b.ne	0x908c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1a6c>
    90b8:      	mov	x1, sp
    90bc:      	mov	x0, x19
    90c0:      	str	x23, [sp, #0x10]
    90c4:      	bl	0x9104 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ae4>
    90c8:      	mov	x0, sp
    90cc:      	bl	0x91b0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1b90>
    90d0:      	ldr	x8, [x21, #0x28]
    90d4:      	ldr	x9, [sp, #0x28]
    90d8:      	cmp	x8, x9
    90dc:      	b.ne	0x90f8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ad8>
    90e0:      	ldp	x20, x19, [sp, #0x60]
    90e4:      	ldr	x30, [sp, #0x30]
    90e8:      	ldp	x22, x21, [sp, #0x50]
    90ec:      	ldp	x24, x23, [sp, #0x40]
    90f0:      	add	sp, sp, #0x70
    90f4:      	ret
    90f8:      	bl	0x9b00 <__stack_chk_fail@plt>
    90fc:      	mov	x0, x19
    9100:      	bl	0x91d4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1bb4>
    9104:      	ldp	x10, x9, [x0]
    9108:      	ldr	x8, [x1, #0x8]
    910c:      	cmp	x9, x10
    9110:      	b.eq	0x9174 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1b54>
    9114:      	mov	x11, xzr
    9118:      	add	x12, x8, x11
    911c:      	add	x13, x9, x11
    9120:      	sub	x11, x11, #0x38
    9124:      	stp	xzr, xzr, [x12, #-0x38]
    9128:      	stur	xzr, [x12, #-0x28]
    912c:      	ldur	q0, [x13, #-0x38]
    9130:      	stur	q0, [x12, #-0x38]
    9134:      	ldur	x14, [x13, #-0x28]
    9138:      	stur	x14, [x12, #-0x28]
    913c:      	ldur	x14, [x13, #-0x20]
    9140:      	stp	xzr, xzr, [x13, #-0x38]
    9144:      	stur	xzr, [x13, #-0x28]
    9148:      	stur	x14, [x12, #-0x20]
    914c:      	ldur	x14, [x13, #-0x8]
    9150:      	ldur	q0, [x13, #-0x18]
    9154:      	stur	x14, [x12, #-0x8]
    9158:      	stur	q0, [x12, #-0x18]
    915c:      	add	x12, x9, x11
    9160:      	cmp	x12, x10
    9164:      	stp	xzr, xzr, [x13, #-0x10]
    9168:      	stur	xzr, [x13, #-0x18]
    916c:      	b.ne	0x9118 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1af8>
    9170:      	add	x8, x8, x11
    9174:      	str	x8, [x1, #0x8]
    9178:      	ldr	x9, [x0]
    917c:      	str	x8, [x0]
    9180:      	ldr	x8, [x1, #0x10]
    9184:      	str	x9, [x1, #0x8]
    9188:      	ldr	x9, [x0, #0x8]
    918c:      	str	x8, [x0, #0x8]
    9190:      	ldr	x8, [x1, #0x18]
    9194:      	str	x9, [x1, #0x10]
    9198:      	ldr	x9, [x0, #0x10]
    919c:      	str	x8, [x0, #0x10]
    91a0:      	ldr	x8, [x1, #0x8]
    91a4:      	str	x9, [x1, #0x18]
    91a8:      	str	x8, [x1]
    91ac:      	ret
    91b0:      	stp	x30, x19, [sp, #-0x10]!
    91b4:      	mov	x19, x0
    91b8:      	bl	0x921c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1bfc>
    91bc:      	ldr	x0, [x19]
    91c0:      	cbz	x0, 0x91cc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1bac>
    91c4:      	ldp	x30, x19, [sp], #0x10
    91c8:      	b	0x9af0 <_ZdlPv@plt>
    91cc:      	ldp	x30, x19, [sp], #0x10
    91d0:      	ret
    91d4:      	adrp	x0, 0x2000
    91d8:      	add	x0, x0, #0x1a7
    91dc:      	bl	0x74d0 <_ZN2ge5GraphD0Ev+0x34>
    91e0:      	stp	x30, x19, [sp, #-0x10]!
    91e4:      	mov	x8, #0x2493             // =9363
    91e8:      	movk	x8, #0x9249, lsl #16
    91ec:      	movk	x8, #0x4924, lsl #32
    91f0:      	movk	x8, #0x492, lsl #48
    91f4:      	cmp	x1, x8
    91f8:      	b.hs	0x9218 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1bf8>
    91fc:      	lsl	x8, x1, #6
    9200:      	mov	x19, x1
    9204:      	sub	x0, x8, x1, lsl #3
    9208:      	bl	0x9b20 <_Znwm@plt>
    920c:      	mov	x1, x19
    9210:      	ldp	x30, x19, [sp], #0x10
    9214:      	ret
    9218:      	bl	0x8968 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1348>
    921c:      	str	x30, [sp, #-0x20]!
    9220:      	stp	x20, x19, [sp, #0x10]
    9224:      	ldp	x20, x8, [x0, #0x8]
    9228:      	cmp	x8, x20
    922c:      	b.eq	0x9250 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1c30>
    9230:      	mov	x19, x0
    9234:      	ldr	x0, [x19, #0x20]
    9238:      	sub	x1, x8, #0x38
    923c:      	str	x1, [x19, #0x10]
    9240:      	bl	0x7428 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataE+0x2b4>
    9244:      	ldr	x8, [x19, #0x10]
    9248:      	cmp	x8, x20
    924c:      	b.ne	0x9234 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1c14>
    9250:      	ldp	x20, x19, [sp, #0x10]
    9254:      	ldr	x30, [sp], #0x20
    9258:      	ret
    925c:      	stp	x30, x23, [sp, #-0x30]!
    9260:      	stp	x22, x21, [sp, #0x10]
    9264:      	stp	x20, x19, [sp, #0x20]
    9268:      	ldr	x8, [x0, #0x10]
    926c:      	ldr	x22, [x0]
    9270:      	mov	x23, x3
    9274:      	mov	x20, x2
    9278:      	mov	x19, x0
    927c:      	mov	x21, x1
    9280:      	sub	x9, x8, x22
    9284:      	cmp	x3, x9, asr #2
    9288:      	b.ls	0x92dc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1cbc>
    928c:      	cbz	x22, 0x92a8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1c88>
    9290:      	mov	x0, x22
    9294:      	str	x22, [x19, #0x8]
    9298:      	bl	0x9af0 <_ZdlPv@plt>
    929c:      	mov	x8, xzr
    92a0:      	stp	xzr, xzr, [x19]
    92a4:      	str	xzr, [x19, #0x10]
    92a8:      	lsr	x9, x23, #62
    92ac:      	cbnz	x9, 0x934c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1d2c>
    92b0:      	asr	x9, x8, #1
    92b4:      	mov	x10, #0x7ffffffffffffffc // =9223372036854775804
    92b8:      	mov	x0, x19
    92bc:      	cmp	x9, x23
    92c0:      	csel	x9, x9, x23, hi
    92c4:      	cmp	x8, x10
    92c8:      	mov	x8, #0x3fffffffffffffff // =4611686018427387903
    92cc:      	csel	x1, x9, x8, lo
    92d0:      	bl	0x9354 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1d34>
    92d4:      	ldr	x22, [x19, #0x8]
    92d8:      	b	0x931c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1cfc>
    92dc:      	ldr	x8, [x19, #0x8]
    92e0:      	sub	x2, x8, x22
    92e4:      	cmp	x23, x2, asr #2
    92e8:      	b.ls	0x931c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1cfc>
    92ec:      	cmp	x8, x22
    92f0:      	add	x23, x21, x2
    92f4:      	b.eq	0x9308 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ce8>
    92f8:      	mov	x0, x22
    92fc:      	mov	x1, x21
    9300:      	bl	0x9b30 <memmove@plt>
    9304:      	ldr	x22, [x19, #0x8]
    9308:      	subs	x20, x20, x23
    930c:      	b.eq	0x9334 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1d14>
    9310:      	mov	x0, x22
    9314:      	mov	x1, x23
    9318:      	b	0x932c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1d0c>
    931c:      	subs	x20, x20, x21
    9320:      	b.eq	0x9334 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1d14>
    9324:      	mov	x0, x22
    9328:      	mov	x1, x21
    932c:      	mov	x2, x20
    9330:      	bl	0x9b30 <memmove@plt>
    9334:      	add	x8, x22, x20
    9338:      	ldp	x22, x21, [sp, #0x10]
    933c:      	str	x8, [x19, #0x8]
    9340:      	ldp	x20, x19, [sp, #0x20]
    9344:      	ldp	x30, x23, [sp], #0x30
    9348:      	ret
    934c:      	mov	x0, x19
    9350:      	bl	0x8f20 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1900>
    9354:      	stp	x30, x19, [sp, #-0x10]!
    9358:      	lsr	x8, x1, #62
    935c:      	mov	x19, x0
    9360:      	cbnz	x8, 0x9380 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1d60>
    9364:      	add	x0, x19, #0x10
    9368:      	bl	0x8f2c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x190c>
    936c:      	add	x8, x0, x1, lsl #2
    9370:      	stp	x0, x0, [x19]
    9374:      	str	x8, [x19, #0x10]
    9378:      	ldp	x30, x19, [sp], #0x10
    937c:      	ret
    9380:      	mov	x0, x19
    9384:      	bl	0x8f20 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1900>
		...
    9390:      	bti	c
    9394:      	adrp	x16, 0x12000
    9398:      	ldrb	w16, [x16, #0x3a8]
    939c:      	cbz	w16, 0x93a8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1d88>
    93a0:      	ldadd	x0, x0, [x1]
    93a4:      	ret
    93a8:      	mov	x16, x0
    93ac:      	ldxr	x0, [x1]
    93b0:      	add	x17, x0, x16
    93b4:      	stxr	w15, x17, [x1]
    93b8:      	cbnz	w15, 0x93ac <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1d8c>
    93bc:      	ret
    93c0:      	paciasp
    93c4:      	sub	sp, sp, #0x70
    93c8:      	str	x30, [sp, #0x60]
    93cc:      	mov	w0, #0x10               // =16
    93d0:      	bl	0x9d80 <getauxval@plt>
    93d4:      	tbnz	w0, #0x8, 0x93f0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1dd0>
    93d8:      	adrp	x9, 0x12000
    93dc:      	ldr	x30, [sp, #0x60]
    93e0:      	strb	wzr, [x9, #0x3a8]
    93e4:      	add	sp, sp, #0x70
    93e8:      	autiasp
    93ec:      	ret
    93f0:      	nop
    93f4:      	adr	x0, 0x1ce9
    93f8:      	add	x1, sp, #0x4
    93fc:      	bl	0x9d90 <__system_property_get@plt>
    9400:      	cmp	w0, #0x0
    9404:      	b.le	0x943c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e1c>
    9408:      	adrp	x1, 0x1000
    940c:      	add	x1, x1, #0xe36
    9410:      	add	x0, sp, #0x4
    9414:      	mov	w2, #0xa                // =10
    9418:      	bl	0x9da0 <strncmp@plt>
    941c:      	cmp	w0, #0x0
    9420:      	cset	w8, ne
    9424:      	adrp	x9, 0x12000
    9428:      	ldr	x30, [sp, #0x60]
    942c:      	strb	w8, [x9, #0x3a8]
    9430:      	add	sp, sp, #0x70
    9434:      	autiasp
    9438:      	ret
    943c:      	mov	w8, #0x1                // =1
    9440:      	adrp	x9, 0x12000
    9444:      	ldr	x30, [sp, #0x60]
    9448:      	strb	w8, [x9, #0x3a8]
    944c:      	add	sp, sp, #0x70
    9450:      	autiasp
    9454:      	ret
    9458:      	bti	c
    945c:      	tbnz	x0, #0x3e, 0x9470 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e50>
    9460:      	mov	x9, xzr
    9464:      	adrp	x8, 0x12000
    9468:      	tbnz	w0, #0x7, 0x947c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e5c>
    946c:      	b	0x9488 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e68>
    9470:      	ldr	x9, [x1, #0x10]
    9474:      	adrp	x8, 0x12000
    9478:      	tbz	w0, #0x7, 0x9488 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e68>
    947c:      	ldr	x10, [x8, #0x3b0]
    9480:      	orr	x10, x10, #0x400
    9484:      	str	x10, [x8, #0x3b0]
    9488:      	tbnz	w0, #0x4, 0x95cc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1fac>
    948c:      	tbnz	w0, #0x1b, 0x95dc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1fbc>
    9490:      	tbnz	w9, #0x7, 0x95ec <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1fcc>
    9494:      	mvn	w10, w0
    9498:      	tst	x10, #0xc0000
    949c:      	b.eq	0x9604 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1fe4>
    94a0:      	tbnz	w0, #0x14, 0x9614 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ff4>
    94a4:      	tbnz	w0, #0x17, 0x9624 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2004>
    94a8:      	tbnz	w0, #0x9, 0x9634 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2014>
    94ac:      	tbnz	w0, #0x18, 0x964c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x202c>
    94b0:      	tbnz	w0, #0xc, 0x965c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x203c>
    94b4:      	tbnz	w0, #0x1a, 0x966c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x204c>
    94b8:      	tbnz	w0, #0x3, 0x967c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x205c>
    94bc:      	tbnz	w0, #0x5, 0x968c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x206c>
    94c0:      	tbnz	w0, #0x6, 0x969c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x207c>
    94c4:      	tbnz	w0, #0xd, 0x96ac <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x208c>
    94c8:      	tbnz	w0, #0xe, 0x96bc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x209c>
    94cc:      	tbnz	w0, #0x1d, 0x96cc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x20ac>
    94d0:      	tbnz	w0, #0x1c, 0x96dc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x20bc>
    94d4:      	tbnz	w9, #0x12, 0x96ec <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x20cc>
    94d8:      	tbnz	w9, #0x16, 0x96fc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x20dc>
    94dc:      	tbnz	w9, #0x2, 0x970c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x20ec>
    94e0:      	tbnz	w9, #0x3, 0x971c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x20fc>
    94e4:      	tbnz	w9, #0x4, 0x972c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x210c>
    94e8:      	tbnz	w9, #0x5, 0x973c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x211c>
    94ec:      	tbnz	w9, #0x6, 0x974c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x212c>
    94f0:      	tbnz	w9, #0x0, 0x975c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x213c>
    94f4:      	tbnz	w0, #0x8, 0x976c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x214c>
    94f8:      	tbnz	w9, #0x10, 0x977c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x215c>
    94fc:      	tbnz	w9, #0xd, 0x978c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x216c>
    9500:      	tbnz	x9, #0x20, 0x979c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x217c>
    9504:      	tbnz	x9, #0x21, 0x97ac <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x218c>
    9508:      	tbnz	w9, #0xf, 0x97bc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x219c>
    950c:      	tbnz	w9, #0x8, 0x97cc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x21ac>
    9510:      	tbnz	w9, #0x9, 0x97dc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x21bc>
    9514:      	tbnz	w9, #0xa, 0x97ec <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x21cc>
    9518:      	tbnz	w9, #0xb, 0x97fc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x21dc>
    951c:      	tbnz	w9, #0x11, 0x980c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x21ec>
    9520:      	tbnz	w9, #0x15, 0x981c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x21fc>
    9524:      	tbnz	w9, #0x1f, 0x982c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x220c>
    9528:      	tbnz	w9, #0x17, 0x983c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x221c>
    952c:      	tbnz	w9, #0x18, 0x984c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x222c>
    9530:      	tbnz	w9, #0x19, 0x985c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x223c>
    9534:      	tbnz	x9, #0x2b, 0x986c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x224c>
    9538:      	tbnz	w0, #0xb, 0x987c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x225c>
    953c:      	ldr	x10, [x8, #0x3b0]
    9540:      	mov	w12, #0x201             // =513
    9544:      	and	x11, x9, #0x1
    9548:      	tst	x0, x12
    954c:      	and	x12, x0, #0x10000
    9550:      	orr	x13, x10, #0x300
    9554:      	orr	x11, x11, x12
    9558:      	csel	x10, x10, x13, eq
    955c:      	cmp	x11, #0x0
    9560:      	mov	w11, #0x8000            // =32768
    9564:      	orr	x12, x10, #0x40000
    9568:      	movk	w11, #0x400, lsl #16
    956c:      	csel	x10, x10, x12, eq
    9570:      	tst	x0, x11
    9574:      	b.eq	0x9580 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1f60>
    9578:      	orr	x10, x10, #0x400000
    957c:      	str	x10, [x8, #0x3b0]
    9580:      	mov	x11, #0x4000            // =16384
    9584:      	lsl	w12, w9, #19
    9588:      	orr	x13, x10, #0x8000000
    958c:      	movk	x11, #0x1, lsl #32
    9590:      	tst	x9, x11
    9594:      	and	x11, x12, #0x80000000
    9598:      	csel	x10, x10, x13, eq
    959c:      	tst	x9, #0x2
    95a0:      	and	x9, x0, #0x400000
    95a4:      	orr	x10, x10, x11
    95a8:      	lsr	x11, x0, #4
    95ac:      	ccmp	x9, #0x0, #0x4, ne
    95b0:      	orr	x9, x10, #0x1000000000
    95b4:      	csel	x9, x10, x9, eq
    95b8:      	and	x10, x11, #0x2000
    95bc:      	orr	x10, x9, x10
    95c0:      	orr	x9, x10, #0x8000000000000000
    95c4:      	str	x9, [x8, #0x3b0]
    95c8:      	ret
    95cc:      	ldr	x10, [x8, #0x3b0]
    95d0:      	orr	x10, x10, #0x8000
    95d4:      	str	x10, [x8, #0x3b0]
    95d8:      	tbz	w0, #0x1b, 0x9490 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e70>
    95dc:      	ldr	x10, [x8, #0x3b0]
    95e0:      	orr	x10, x10, #0x2
    95e4:      	str	x10, [x8, #0x3b0]
    95e8:      	tbz	w9, #0x7, 0x9494 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e74>
    95ec:      	ldr	x10, [x8, #0x3b0]
    95f0:      	orr	x10, x10, #0x6
    95f4:      	str	x10, [x8, #0x3b0]
    95f8:      	mvn	w10, w0
    95fc:      	tst	x10, #0xc0000
    9600:      	b.ne	0x94a0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e80>
    9604:      	ldr	x10, [x8, #0x3b0]
    9608:      	orr	x10, x10, #0x20
    960c:      	str	x10, [x8, #0x3b0]
    9610:      	tbz	w0, #0x14, 0x94a4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e84>
    9614:      	ldr	x10, [x8, #0x3b0]
    9618:      	orr	x10, x10, #0x10
    961c:      	str	x10, [x8, #0x3b0]
    9620:      	tbz	w0, #0x17, 0x94a8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e88>
    9624:      	ldr	x10, [x8, #0x3b0]
    9628:      	orr	x10, x10, #0x8
    962c:      	str	x10, [x8, #0x3b0]
    9630:      	tbz	w0, #0x9, 0x94ac <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e8c>
    9634:      	ldr	x10, [x8, #0x3b0]
    9638:      	mov	w11, #0x100             // =256
    963c:      	movk	w11, #0x1, lsl #16
    9640:      	orr	x10, x10, x11
    9644:      	str	x10, [x8, #0x3b0]
    9648:      	tbz	w0, #0x18, 0x94b0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e90>
    964c:      	ldr	x10, [x8, #0x3b0]
    9650:      	orr	x10, x10, #0x20000
    9654:      	str	x10, [x8, #0x3b0]
    9658:      	tbz	w0, #0xc, 0x94b4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e94>
    965c:      	ldr	x10, [x8, #0x3b0]
    9660:      	orr	x10, x10, #0x40
    9664:      	str	x10, [x8, #0x3b0]
    9668:      	tbz	w0, #0x1a, 0x94b8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e98>
    966c:      	ldr	x10, [x8, #0x3b0]
    9670:      	orr	x10, x10, #0x800000
    9674:      	str	x10, [x8, #0x3b0]
    9678:      	tbz	w0, #0x3, 0x94bc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e9c>
    967c:      	ldr	x10, [x8, #0x3b0]
    9680:      	orr	x10, x10, #0x4000
    9684:      	str	x10, [x8, #0x3b0]
    9688:      	tbz	w0, #0x5, 0x94c0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ea0>
    968c:      	ldr	x10, [x8, #0x3b0]
    9690:      	orr	x10, x10, #0x800
    9694:      	str	x10, [x8, #0x3b0]
    9698:      	tbz	w0, #0x6, 0x94c4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ea4>
    969c:      	ldr	x10, [x8, #0x3b0]
    96a0:      	orr	x10, x10, #0x1000
    96a4:      	str	x10, [x8, #0x3b0]
    96a8:      	tbz	w0, #0xd, 0x94c8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ea8>
    96ac:      	ldr	x10, [x8, #0x3b0]
    96b0:      	orr	x10, x10, #0x100000
    96b4:      	str	x10, [x8, #0x3b0]
    96b8:      	tbz	w0, #0xe, 0x94cc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1eac>
    96bc:      	ldr	x10, [x8, #0x3b0]
    96c0:      	orr	x10, x10, #0x200000
    96c4:      	str	x10, [x8, #0x3b0]
    96c8:      	tbz	w0, #0x1d, 0x94d0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1eb0>
    96cc:      	ldr	x10, [x8, #0x3b0]
    96d0:      	orr	x10, x10, #0x400000000000
    96d4:      	str	x10, [x8, #0x3b0]
    96d8:      	tbz	w0, #0x1c, 0x94d4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1eb4>
    96dc:      	ldr	x10, [x8, #0x3b0]
    96e0:      	orr	x10, x10, #0x2000000000000
    96e4:      	str	x10, [x8, #0x3b0]
    96e8:      	tbz	w9, #0x12, 0x94d8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1eb8>
    96ec:      	ldr	x10, [x8, #0x3b0]
    96f0:      	orr	x10, x10, #0x180000000000
    96f4:      	str	x10, [x8, #0x3b0]
    96f8:      	tbz	w9, #0x16, 0x94dc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ebc>
    96fc:      	ldr	x10, [x8, #0x3b0]
    9700:      	orr	x10, x10, #0x380000000000
    9704:      	str	x10, [x8, #0x3b0]
    9708:      	tbz	w9, #0x2, 0x94e0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ec0>
    970c:      	ldr	x10, [x8, #0x3b0]
    9710:      	orr	x10, x10, #0x2000000000
    9714:      	str	x10, [x8, #0x3b0]
    9718:      	tbz	w9, #0x3, 0x94e4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ec4>
    971c:      	ldr	x10, [x8, #0x3b0]
    9720:      	orr	x10, x10, #0x6000000000
    9724:      	str	x10, [x8, #0x3b0]
    9728:      	tbz	w9, #0x4, 0x94e8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ec8>
    972c:      	ldr	x10, [x8, #0x3b0]
    9730:      	orr	x10, x10, #0x8000000000
    9734:      	str	x10, [x8, #0x3b0]
    9738:      	tbz	w9, #0x5, 0x94ec <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ecc>
    973c:      	ldr	x10, [x8, #0x3b0]
    9740:      	orr	x10, x10, #0x10000000000
    9744:      	str	x10, [x8, #0x3b0]
    9748:      	tbz	w9, #0x6, 0x94f0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ed0>
    974c:      	ldr	x10, [x8, #0x3b0]
    9750:      	orr	x10, x10, #0x20000000000
    9754:      	str	x10, [x8, #0x3b0]
    9758:      	tbz	w9, #0x0, 0x94f4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ed4>
    975c:      	ldr	x10, [x8, #0x3b0]
    9760:      	orr	x10, x10, #0x80000
    9764:      	str	x10, [x8, #0x3b0]
    9768:      	tbz	w0, #0x8, 0x94f8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ed8>
    976c:      	ldr	x10, [x8, #0x3b0]
    9770:      	orr	x10, x10, #0x80
    9774:      	str	x10, [x8, #0x3b0]
    9778:      	tbz	w9, #0x10, 0x94fc <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1edc>
    977c:      	ldr	x10, [x8, #0x3b0]
    9780:      	orr	x10, x10, #0x1
    9784:      	str	x10, [x8, #0x3b0]
    9788:      	tbz	w9, #0xd, 0x9500 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ee0>
    978c:      	ldr	x10, [x8, #0x3b0]
    9790:      	orr	x10, x10, #0x4000000
    9794:      	str	x10, [x8, #0x3b0]
    9798:      	tbz	x9, #0x20, 0x9504 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ee4>
    979c:      	ldr	x10, [x8, #0x3b0]
    97a0:      	orr	x10, x10, #0x10000000
    97a4:      	str	x10, [x8, #0x3b0]
    97a8:      	tbz	x9, #0x21, 0x9508 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ee8>
    97ac:      	ldr	x10, [x8, #0x3b0]
    97b0:      	orr	x10, x10, #0x100000000
    97b4:      	str	x10, [x8, #0x3b0]
    97b8:      	tbz	w9, #0xf, 0x950c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1eec>
    97bc:      	ldr	x10, [x8, #0x3b0]
    97c0:      	orr	x10, x10, #0x2000000
    97c4:      	str	x10, [x8, #0x3b0]
    97c8:      	tbz	w9, #0x8, 0x9510 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ef0>
    97cc:      	ldr	x10, [x8, #0x3b0]
    97d0:      	orr	x10, x10, #0x1000000
    97d4:      	str	x10, [x8, #0x3b0]
    97d8:      	tbz	w9, #0x9, 0x9514 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ef4>
    97dc:      	ldr	x10, [x8, #0x3b0]
    97e0:      	orr	x10, x10, #0x200000000
    97e4:      	str	x10, [x8, #0x3b0]
    97e8:      	tbz	w9, #0xa, 0x9518 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1ef8>
    97ec:      	ldr	x10, [x8, #0x3b0]
    97f0:      	orr	x10, x10, #0x400000000
    97f4:      	str	x10, [x8, #0x3b0]
    97f8:      	tbz	w9, #0xb, 0x951c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1efc>
    97fc:      	ldr	x10, [x8, #0x3b0]
    9800:      	orr	x10, x10, #0x800000000
    9804:      	str	x10, [x8, #0x3b0]
    9808:      	tbz	w9, #0x11, 0x9520 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1f00>
    980c:      	ldr	x10, [x8, #0x3b0]
    9810:      	orr	x10, x10, #0x4000000000000
    9814:      	str	x10, [x8, #0x3b0]
    9818:      	tbz	w9, #0x15, 0x9524 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1f04>
    981c:      	ldr	x10, [x8, #0x3b0]
    9820:      	orr	x10, x10, #0x20000000
    9824:      	str	x10, [x8, #0x3b0]
    9828:      	tbz	w9, #0x1f, 0x9528 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1f08>
    982c:      	ldr	x10, [x8, #0x3b0]
    9830:      	orr	x10, x10, #0x40000000000000
    9834:      	str	x10, [x8, #0x3b0]
    9838:      	tbz	w9, #0x17, 0x952c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1f0c>
    983c:      	ldr	x10, [x8, #0x3b0]
    9840:      	orr	x10, x10, #0x40000000000
    9844:      	str	x10, [x8, #0x3b0]
    9848:      	tbz	w9, #0x18, 0x9530 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1f10>
    984c:      	ldr	x10, [x8, #0x3b0]
    9850:      	orr	x10, x10, #0x100000000000000
    9854:      	str	x10, [x8, #0x3b0]
    9858:      	tbz	w9, #0x19, 0x9534 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1f14>
    985c:      	ldr	x10, [x8, #0x3b0]
    9860:      	orr	x10, x10, #0x80000000000000
    9864:      	str	x10, [x8, #0x3b0]
    9868:      	tbz	x9, #0x2b, 0x9538 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1f18>
    986c:      	ldr	x10, [x8, #0x3b0]
    9870:      	orr	x10, x10, #0x800000000000000
    9874:      	str	x10, [x8, #0x3b0]
    9878:      	tbz	w0, #0xb, 0x953c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1f1c>
    987c:      	mrs	x9, ID_AA64PFR1_EL1
    9880:      	tst	x9, #0xf00
    9884:      	b.eq	0x9894 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2274>
    9888:      	ldr	x10, [x8, #0x3b0]
    988c:      	orr	x10, x10, #0x80000000000
    9890:      	str	x10, [x8, #0x3b0]
    9894:      	and	x10, x9, #0xf0
    9898:      	cmp	x10, #0x10
    989c:      	b.eq	0x98e8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x22c8>
    98a0:      	and	x9, x9, #0xf000000
    98a4:      	mov	w10, #0x2000000         // =33554432
    98a8:      	cmp	x9, x10
    98ac:      	b.eq	0x9904 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x22e4>
    98b0:      	mrs	x9, ID_AA64PFR0_EL1
    98b4:      	mvn	w10, w9
    98b8:      	tst	x10, #0xf0000
    98bc:      	b.ne	0x9920 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2300>
    98c0:      	tst	x9, #0xf00000000
    98c4:      	b.eq	0x9934 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2314>
    98c8:      	mrs	x9, ID_AA64ZFR0_EL1
    98cc:      	and	x11, x9, #0xf
    98d0:      	ldr	x10, [x8, #0x3b0]
    98d4:      	cmp	x11, #0x1
    98d8:      	b.eq	0x993c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x231c>
    98dc:      	cbnz	x11, 0x9940 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2320>
    98e0:      	orr	x10, x10, #0x40000000
    98e4:      	b	0x9940 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2320>
    98e8:      	ldr	x10, [x8, #0x3b0]
    98ec:      	orr	x10, x10, #0x1000000000000
    98f0:      	str	x10, [x8, #0x3b0]
    98f4:      	and	x9, x9, #0xf000000
    98f8:      	mov	w10, #0x2000000         // =33554432
    98fc:      	cmp	x9, x10
    9900:      	b.ne	0x98b0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2290>
    9904:      	ldr	x9, [x8, #0x3b0]
    9908:      	orr	x9, x9, #0x200000000000000
    990c:      	str	x9, [x8, #0x3b0]
    9910:      	mrs	x9, ID_AA64PFR0_EL1
    9914:      	mvn	w10, w9
    9918:      	tst	x10, #0xf0000
    991c:      	b.eq	0x98c0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x22a0>
    9920:      	ldr	x10, [x8, #0x3b0]
    9924:      	orr	x10, x10, #0x300
    9928:      	str	x10, [x8, #0x3b0]
    992c:      	tst	x9, #0xf00000000
    9930:      	b.ne	0x98c8 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x22a8>
    9934:      	ldr	x10, [x8, #0x3b0]
    9938:      	b	0x994c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x232c>
    993c:      	orr	x10, x10, #0x1000000000
    9940:      	orr	x11, x10, #0x80000000
    9944:      	tst	x9, #0xf00000
    9948:      	csel	x10, x10, x11, eq
    994c:      	mrs	x9, ID_AA64ISAR0_EL1
    9950:      	orr	x11, x10, #0x2000
    9954:      	tst	x9, #0xf00000000
    9958:      	csel	x10, x10, x11, eq
    995c:      	mrs	x9, ID_AA64ISAR1_EL1
    9960:      	ubfx	x11, x9, #20, #4
    9964:      	orr	x12, x10, #0x40000
    9968:      	tst	x9, #0xf
    996c:      	csel	x10, x10, x12, eq
    9970:      	cbz	x11, 0x9994 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2374>
    9974:      	cmp	x11, #0x3
    9978:      	b.ne	0x9990 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2370>
    997c:      	mov	x11, #0x400000          // =4194304
    9980:      	movk	x11, #0x400, lsl #48
    9984:      	orr	x10, x10, x11
    9988:      	str	x10, [x8, #0x3b0]
    998c:      	b	0x9994 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2374>
    9990:      	orr	x10, x10, #0x400000
    9994:      	and	x11, x9, #0xf0000000000
    9998:      	mov	x12, #0x20000000000     // =2199023255552
    999c:      	orr	x13, x10, #0x800000000000
    99a0:      	cmp	x11, x12
    99a4:      	lsr	x11, x9, #60
    99a8:      	csel	x10, x13, x10, eq
    99ac:      	tst	x9, #0xf00000000000
    99b0:      	orr	x12, x10, #0x8000000
    99b4:      	csel	x10, x10, x12, eq
    99b8:      	cbz	x11, 0x95c0 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1fa0>
    99bc:      	lsr	x9, x9, #61
    99c0:      	cbz	x9, 0x99e4 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x23c4>
    99c4:      	cmp	x11, #0x2
    99c8:      	mov	x9, #0x18000000000000   // =6755399441055744
    99cc:      	mov	x11, #0x38000000000000  // =15762598695796736
    99d0:      	csel	x9, x11, x9, hi
    99d4:      	orr	x10, x10, x9
    99d8:      	orr	x9, x10, #0x8000000000000000
    99dc:      	str	x9, [x8, #0x3b0]
    99e0:      	ret
    99e4:      	orr	x10, x10, #0x8000000000000
    99e8:      	orr	x9, x10, #0x8000000000000000
    99ec:      	str	x9, [x8, #0x3b0]
    99f0:      	ret
    99f4:      	bti	c
    99f8:      	adrp	x8, 0x12000
    99fc:      	ldr	x8, [x8, #0x3b0]
    9a00:      	cbz	x8, 0x9a08 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x23e8>
    9a04:      	ret
    9a08:      	paciasp
    9a0c:      	sub	sp, sp, #0x70
    9a10:      	stp	x30, x19, [sp, #0x60]
    9a14:      	nop
    9a18:      	adr	x0, 0x1ce9
    9a1c:      	mov	x1, sp
    9a20:      	bl	0x9d90 <__system_property_get@plt>
    9a24:      	cmp	w0, #0x0
    9a28:      	b.le	0x9a44 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2424>
    9a2c:      	adrp	x1, 0x1000
    9a30:      	add	x1, x1, #0xe36
    9a34:      	mov	x0, sp
    9a38:      	mov	w2, #0xa                // =10
    9a3c:      	bl	0x9da0 <strncmp@plt>
    9a40:      	cbz	w0, 0x9a70 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2450>
    9a44:      	mov	w0, #0x10               // =16
    9a48:      	bl	0x9d80 <getauxval@plt>
    9a4c:      	mov	x19, x0
    9a50:      	mov	w0, #0x1a               // =26
    9a54:      	bl	0x9d80 <getauxval@plt>
    9a58:      	mov	w8, #0x18               // =24
    9a5c:      	str	x0, [sp, #0x10]
    9a60:      	orr	x0, x19, #0x4000000000000000
    9a64:      	mov	x1, sp
    9a68:      	stp	x8, x19, [sp]
    9a6c:      	bl	0x9458 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x1e38>
    9a70:      	ldp	x30, x19, [sp, #0x60]
    9a74:      	add	sp, sp, #0x70
    9a78:      	autiasp
    9a7c:      	ret
    9a80:      	bti	c
    9a84:      	adrp	x16, 0x12000
    9a88:      	ldrb	w16, [x16, #0x3a8]
    9a8c:      	cbz	w16, 0x9a98 <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x2478>
    9a90:      	ldaddal	x0, x0, [x1]
    9a94:      	ret
    9a98:      	mov	x16, x0
    9a9c:      	ldaxr	x0, [x1]
    9aa0:      	add	x17, x0, x16
    9aa4:      	stlxr	w15, x17, [x1]
    9aa8:      	cbnz	w15, 0x9a9c <_ZN4hiai13HiaiIrBuildV25BuildERKNS_17ModelBuildOptionsERKNSt6__ndk112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_10shared_ptrIN2ge5ModelEEERNSD_INS_11IBuiltModelEEE+0x247c>
    9aac:      	ret

Disassembly of section .plt:

0000000000009ab0 <.plt>:
    9ab0:      	stp	x16, x30, [sp, #-0x10]!
    9ab4:      	adrp	x16, 0xe000
    9ab8:      	ldr	x17, [x16, #0x80]
    9abc:      	add	x16, x16, #0x80
    9ac0:      	br	x17
    9ac4:      	nop
    9ac8:      	nop
    9acc:      	nop

0000000000009ad0 <__cxa_finalize@plt>:
    9ad0:      	adrp	x16, 0xe000
    9ad4:      	ldr	x17, [x16, #0x88]
    9ad8:      	add	x16, x16, #0x88
    9adc:      	br	x17

0000000000009ae0 <__cxa_atexit@plt>:
    9ae0:      	adrp	x16, 0xe000
    9ae4:      	ldr	x17, [x16, #0x90]
    9ae8:      	add	x16, x16, #0x90
    9aec:      	br	x17

0000000000009af0 <_ZdlPv@plt>:
    9af0:      	adrp	x16, 0xe000
    9af4:      	ldr	x17, [x16, #0x98]
    9af8:      	add	x16, x16, #0x98
    9afc:      	br	x17

0000000000009b00 <__stack_chk_fail@plt>:
    9b00:      	adrp	x16, 0xe000
    9b04:      	ldr	x17, [x16, #0xa0]
    9b08:      	add	x16, x16, #0xa0
    9b0c:      	br	x17

0000000000009b10 <strlen@plt>:
    9b10:      	adrp	x16, 0xe000
    9b14:      	ldr	x17, [x16, #0xa8]
    9b18:      	add	x16, x16, #0xa8
    9b1c:      	br	x17

0000000000009b20 <_Znwm@plt>:
    9b20:      	adrp	x16, 0xe000
    9b24:      	ldr	x17, [x16, #0xb0]
    9b28:      	add	x16, x16, #0xb0
    9b2c:      	br	x17

0000000000009b30 <memmove@plt>:
    9b30:      	adrp	x16, 0xe000
    9b34:      	ldr	x17, [x16, #0xb8]
    9b38:      	add	x16, x16, #0xb8
    9b3c:      	br	x17

0000000000009b40 <_ZN4hiai11HiaiIrBuild15CreateModelBuffERN2ge5ModelERNS_15ModelBufferDataEj@plt>:
    9b40:      	adrp	x16, 0xe000
    9b44:      	ldr	x17, [x16, #0xc0]
    9b48:      	add	x16, x16, #0xc0
    9b4c:      	br	x17

0000000000009b50 <__strrchr_chk@plt>:
    9b50:      	adrp	x16, 0xe000
    9b54:      	ldr	x17, [x16, #0xc8]
    9b58:      	add	x16, x16, #0xc8
    9b5c:      	br	x17

0000000000009b60 <AI_Log_Print@plt>:
    9b60:      	adrp	x16, 0xe000
    9b64:      	ldr	x17, [x16, #0xd0]
    9b68:      	add	x16, x16, #0xd0
    9b6c:      	br	x17

0000000000009b70 <dlopen@plt>:
    9b70:      	adrp	x16, 0xe000
    9b74:      	ldr	x17, [x16, #0xd8]
    9b78:      	add	x16, x16, #0xd8
    9b7c:      	br	x17

0000000000009b80 <dlsym@plt>:
    9b80:      	adrp	x16, 0xe000
    9b84:      	ldr	x17, [x16, #0xe0]
    9b88:      	add	x16, x16, #0xe0
    9b8c:      	br	x17

0000000000009b90 <dlerror@plt>:
    9b90:      	adrp	x16, 0xe000
    9b94:      	ldr	x17, [x16, #0xe8]
    9b98:      	add	x16, x16, #0xe8
    9b9c:      	br	x17

0000000000009ba0 <_ZN2ge6BufferC1Ev@plt>:
    9ba0:      	adrp	x16, 0xe000
    9ba4:      	ldr	x17, [x16, #0xf0]
    9ba8:      	add	x16, x16, #0xf0
    9bac:      	br	x17

0000000000009bb0 <_ZNK2ge5Model4SaveERNS_6BufferE@plt>:
    9bb0:      	adrp	x16, 0xe000
    9bb4:      	ldr	x17, [x16, #0xf8]
    9bb8:      	add	x16, x16, #0xf8
    9bbc:      	br	x17

0000000000009bc0 <malloc@plt>:
    9bc0:      	adrp	x16, 0xe000
    9bc4:      	ldr	x17, [x16, #0x100]
    9bc8:      	add	x16, x16, #0x100
    9bcc:      	br	x17

0000000000009bd0 <_ZNK2ge6Buffer7GetSizeEv@plt>:
    9bd0:      	adrp	x16, 0xe000
    9bd4:      	ldr	x17, [x16, #0x108]
    9bd8:      	add	x16, x16, #0x108
    9bdc:      	br	x17

0000000000009be0 <free@plt>:
    9be0:      	adrp	x16, 0xe000
    9be4:      	ldr	x17, [x16, #0x110]
    9be8:      	add	x16, x16, #0x110
    9bec:      	br	x17

0000000000009bf0 <_ZN2ge6BufferD1Ev@plt>:
    9bf0:      	adrp	x16, 0xe000
    9bf4:      	ldr	x17, [x16, #0x118]
    9bf8:      	add	x16, x16, #0x118
    9bfc:      	br	x17

0000000000009c00 <dlclose@plt>:
    9c00:      	adrp	x16, 0xe000
    9c04:      	ldr	x17, [x16, #0x120]
    9c08:      	add	x16, x16, #0x120
    9c0c:      	br	x17

0000000000009c10 <_ZNK2ge5Model7GetNameEv@plt>:
    9c10:      	adrp	x16, 0xe000
    9c14:      	ldr	x17, [x16, #0x128]
    9c18:      	add	x16, x16, #0x128
    9c1c:      	br	x17

0000000000009c20 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm@plt>:
    9c20:      	adrp	x16, 0xe000
    9c24:      	ldr	x17, [x16, #0x130]
    9c28:      	add	x16, x16, #0x130
    9c2c:      	br	x17

0000000000009c30 <_ZN4hiai17CreateLocalBufferEPvmb@plt>:
    9c30:      	adrp	x16, 0xe000
    9c34:      	ldr	x17, [x16, #0x138]
    9c38:      	add	x16, x16, #0x138
    9c3c:      	br	x17

0000000000009c40 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>:
    9c40:      	adrp	x16, 0xe000
    9c44:      	ldr	x17, [x16, #0x140]
    9c48:      	add	x16, x16, #0x140
    9c4c:      	br	x17

0000000000009c50 <_ZN4hiai11HiaiIrBuild12BuildIRModelERN2ge5ModelERNS_15ModelBufferDataERKNS_12BuildOptionsE@plt>:
    9c50:      	adrp	x16, 0xe000
    9c54:      	ldr	x17, [x16, #0x148]
    9c58:      	add	x16, x16, #0x148
    9c5c:      	br	x17

0000000000009c60 <_ZN2ge9AttrUtils6SetIntEONS0_17AttrHolderAdapterERKNSt6__ndk112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEERKl@plt>:
    9c60:      	adrp	x16, 0xe000
    9c64:      	ldr	x17, [x16, #0x150]
    9c68:      	add	x16, x16, #0x150
    9c6c:      	br	x17

0000000000009c70 <_ZNK2ge5Model8GetGraphEv@plt>:
    9c70:      	adrp	x16, 0xe000
    9c74:      	ldr	x17, [x16, #0x158]
    9c78:      	add	x16, x16, #0x158
    9c7c:      	br	x17

0000000000009c80 <_ZN2ge10GraphUtils15GetComputeGraphERKNS_5GraphE@plt>:
    9c80:      	adrp	x16, 0xe000
    9c84:      	ldr	x17, [x16, #0x160]
    9c88:      	add	x16, x16, #0x160
    9c8c:      	br	x17

0000000000009c90 <_ZN4hiai13IRTransformer21VerifyIrReservedFieldENSt6__ndk110shared_ptrIN2ge12ComputeGraphEEE@plt>:
    9c90:      	adrp	x16, 0xe000
    9c94:      	ldr	x17, [x16, #0x168]
    9c98:      	add	x16, x16, #0x168
    9c9c:      	br	x17

0000000000009ca0 <_ZNSt6__ndk122__libcpp_verbose_abortEPKcz@plt>:
    9ca0:      	adrp	x16, 0xe000
    9ca4:      	ldr	x17, [x16, #0x170]
    9ca8:      	add	x16, x16, #0x170
    9cac:      	br	x17

0000000000009cb0 <_ZnwmRKSt9nothrow_t@plt>:
    9cb0:      	adrp	x16, 0xe000
    9cb4:      	ldr	x17, [x16, #0x178]
    9cb8:      	add	x16, x16, #0x178
    9cbc:      	br	x17

0000000000009cc0 <_ZN2ge15GraphListWalker12WalkOutNodesENSt6__ndk18functionIFjRNS_4NodeEEEE@plt>:
    9cc0:      	adrp	x16, 0xe000
    9cc4:      	ldr	x17, [x16, #0x180]
    9cc8:      	add	x16, x16, #0x180
    9ccc:      	br	x17

0000000000009cd0 <_ZN4hiai18CreateModelBuilderEv@plt>:
    9cd0:      	adrp	x16, 0xe000
    9cd4:      	ldr	x17, [x16, #0x188]
    9cd8:      	add	x16, x16, #0x188
    9cdc:      	br	x17

0000000000009ce0 <_ZNK2ge6Buffer7GetDataEv@plt>:
    9ce0:      	adrp	x16, 0xe000
    9ce4:      	ldr	x17, [x16, #0x190]
    9ce8:      	add	x16, x16, #0x190
    9cec:      	br	x17

0000000000009cf0 <_ZN2ge8NodeSpec6OpDescEv@plt>:
    9cf0:      	adrp	x16, 0xe000
    9cf4:      	ldr	x17, [x16, #0x198]
    9cf8:      	add	x16, x16, #0x198
    9cfc:      	br	x17

0000000000009d00 <_ZN2ge9AttrUtils10GetListIntEONS0_22ConstAttrHolderAdapterERKNSt6__ndk112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEERNS3_6vectorIlNS7_IlEEEE@plt>:
    9d00:      	adrp	x16, 0xe000
    9d04:      	ldr	x17, [x16, #0x1a0]
    9d08:      	add	x16, x16, #0x1a0
    9d0c:      	br	x17

0000000000009d10 <_ZNK2ge6OpDesc17GetInputsDescSizeEv@plt>:
    9d10:      	adrp	x16, 0xe000
    9d14:      	ldr	x17, [x16, #0x1a8]
    9d18:      	add	x16, x16, #0x1a8
    9d1c:      	br	x17

0000000000009d20 <_ZN2ge10AttrHolder7DelAttrERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE@plt>:
    9d20:      	adrp	x16, 0xe000
    9d24:      	ldr	x17, [x16, #0x1b0]
    9d28:      	add	x16, x16, #0x1b0
    9d2c:      	br	x17

0000000000009d30 <_ZN2ge9AttrUtils7SetBoolEONS0_17AttrHolderAdapterERKNSt6__ndk112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEERKb@plt>:
    9d30:      	adrp	x16, 0xe000
    9d34:      	ldr	x17, [x16, #0x1b8]
    9d38:      	add	x16, x16, #0x1b8
    9d3c:      	br	x17

0000000000009d40 <_ZN2ge10TensorDesc11SetDataTypeENS_8DataTypeE@plt>:
    9d40:      	adrp	x16, 0xe000
    9d44:      	ldr	x17, [x16, #0x1c0]
    9d48:      	add	x16, x16, #0x1c0
    9d4c:      	br	x17

0000000000009d50 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_@plt>:
    9d50:      	adrp	x16, 0xe000
    9d54:      	ldr	x17, [x16, #0x1c8]
    9d58:      	add	x16, x16, #0x1c8
    9d5c:      	br	x17

0000000000009d60 <memset@plt>:
    9d60:      	adrp	x16, 0xe000
    9d64:      	ldr	x17, [x16, #0x1d0]
    9d68:      	add	x16, x16, #0x1d0
    9d6c:      	br	x17

0000000000009d70 <memcmp@plt>:
    9d70:      	adrp	x16, 0xe000
    9d74:      	ldr	x17, [x16, #0x1d8]
    9d78:      	add	x16, x16, #0x1d8
    9d7c:      	br	x17

0000000000009d80 <getauxval@plt>:
    9d80:      	adrp	x16, 0xe000
    9d84:      	ldr	x17, [x16, #0x1e0]
    9d88:      	add	x16, x16, #0x1e0
    9d8c:      	br	x17

0000000000009d90 <__system_property_get@plt>:
    9d90:      	adrp	x16, 0xe000
    9d94:      	ldr	x17, [x16, #0x1e8]
    9d98:      	add	x16, x16, #0x1e8
    9d9c:      	br	x17

0000000000009da0 <strncmp@plt>:
    9da0:      	adrp	x16, 0xe000
    9da4:      	ldr	x17, [x16, #0x1f0]
    9da8:      	add	x16, x16, #0x1f0
    9dac:      	br	x17
