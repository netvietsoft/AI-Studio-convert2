
F:\CONVERT\com.mt.mtxx.mtxx\SOURCE\extracted_native_libs\lib\arm64-v8a\libMTARMPM.so:	file format elf64-littleaarch64

Disassembly of section .text:

000000000000a240 <.text>:
    a240:      	bti	c
    a244:      	nop
    a248:      	adr	x0, 0x1b310
    a24c:      	b	0x16b00 <__cxa_finalize@plt>
    a250:      	bti	c
    a254:      	ret
    a258:      	bti	c
    a25c:      	b	0xa250 <.text+0x10>
    a260:      	bti	c
    a264:      	cbz	x0, 0xa270 <.text+0x30>
    a268:      	mov	x16, x0
    a26c:      	br	x16
    a270:      	ret
    a274:      	bti	c
    a278:      	mov	x1, x0
    a27c:      	nop
    a280:      	adr	x0, 0xa260 <.text+0x20>
    a284:      	nop
    a288:      	adr	x2, 0x1b310
    a28c:      	b	0x16b10 <__cxa_atexit@plt>
    a290:      	bti	c
    a294:      	nop
    a298:      	adr	x3, 0x1b310
    a29c:      	b	0x16b20 <__register_atfork@plt>

000000000000a2a0 <_Z21MTARMPMImplementationv>:
    a2a0:      	mov	w0, #0x1                // =1
    a2a4:      	ret

000000000000a2a8 <_Z18MTARMPMSetLogLeveli>:
    a2a8:      	ret

000000000000a2ac <_Z16MTARMPMSetJavaVMPv>:
    a2ac:      	stp	x29, x30, [sp, #-0x10]!
    a2b0:      	mov	x29, sp
    a2b4:      	bl	0x11ce8 <_Z20MTARMPMMusicGetSpeedPv+0x6fec>
    a2b8:      	bl	0x11c78 <_Z20MTARMPMMusicGetSpeedPv+0x6f7c>
    a2bc:      	ldp	x29, x30, [sp], #0x10
    a2c0:      	b	0x10294 <_Z20MTARMPMMusicGetSpeedPv+0x5598>

000000000000a2c4 <_Z19MTARMPMServiceStartv>:
    a2c4:      	sub	sp, sp, #0x50
    a2c8:      	stp	x29, x30, [sp, #0x20]
    a2cc:      	str	x21, [sp, #0x30]
    a2d0:      	stp	x20, x19, [sp, #0x40]
    a2d4:      	add	x29, sp, #0x20
    a2d8:      	mrs	x21, TPIDR_EL0
    a2dc:      	ldr	x8, [x21, #0x28]
    a2e0:      	stur	x8, [x29, #-0x8]
    a2e4:      	add	x8, sp, #0x8
    a2e8:      	bl	0xe970 <_Z20MTARMPMMusicGetSpeedPv+0x3c74>
    a2ec:      	ldr	x0, [sp, #0x8]
    a2f0:      	bl	0xeb5c <_Z20MTARMPMMusicGetSpeedPv+0x3e60>
    a2f4:      	ldr	x20, [sp, #0x10]
    a2f8:      	mov	w19, w0
    a2fc:      	cbz	x20, 0xa328 <_Z19MTARMPMServiceStartv+0x64>
    a300:      	add	x1, x20, #0x8
    a304:      	mov	x0, #-0x1               // =-1
    a308:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    a30c:      	cbnz	x0, 0xa328 <_Z19MTARMPMServiceStartv+0x64>
    a310:      	ldr	x8, [x20]
    a314:      	mov	x0, x20
    a318:      	ldr	x8, [x8, #0x10]
    a31c:      	blr	x8
    a320:      	mov	x0, x20
    a324:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    a328:      	ldr	x8, [x21, #0x28]
    a32c:      	ldur	x9, [x29, #-0x8]
    a330:      	cmp	x8, x9
    a334:      	b.ne	0xa374 <_Z19MTARMPMServiceStartv+0xb0>
    a338:      	and	w0, w19, #0x1
    a33c:      	ldp	x20, x19, [sp, #0x40]
    a340:      	ldr	x21, [sp, #0x30]
    a344:      	ldp	x29, x30, [sp, #0x20]
    a348:      	add	sp, sp, #0x50
    a34c:      	ret
    a350:      	mov	x19, x0
    a354:      	add	x0, sp, #0x8
    a358:      	bl	0xa378 <_Z19MTARMPMServiceStartv+0xb4>
    a35c:      	ldr	x8, [x21, #0x28]
    a360:      	ldur	x9, [x29, #-0x8]
    a364:      	cmp	x8, x9
    a368:      	b.ne	0xa374 <_Z19MTARMPMServiceStartv+0xb0>
    a36c:      	mov	x0, x19
    a370:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    a374:      	bl	0x16b40 <__stack_chk_fail@plt>
    a378:      	stp	x29, x30, [sp, #-0x20]!
    a37c:      	str	x19, [sp, #0x10]
    a380:      	mov	x29, sp
    a384:      	ldr	x19, [x0, #0x8]
    a388:      	cbz	x19, 0xa39c <_Z19MTARMPMServiceStartv+0xd8>
    a38c:      	add	x1, x19, #0x8
    a390:      	mov	x0, #-0x1               // =-1
    a394:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    a398:      	cbz	x0, 0xa3a8 <_Z19MTARMPMServiceStartv+0xe4>
    a39c:      	ldr	x19, [sp, #0x10]
    a3a0:      	ldp	x29, x30, [sp], #0x20
    a3a4:      	ret
    a3a8:      	ldr	x8, [x19]
    a3ac:      	mov	x0, x19
    a3b0:      	ldr	x8, [x8, #0x10]
    a3b4:      	blr	x8
    a3b8:      	mov	x0, x19
    a3bc:      	ldr	x19, [sp, #0x10]
    a3c0:      	ldp	x29, x30, [sp], #0x20
    a3c4:      	b	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>

000000000000a3c8 <_Z19MTARMPMServicePausei>:
    a3c8:      	sub	sp, sp, #0x40
    a3cc:      	stp	x29, x30, [sp, #0x20]
    a3d0:      	stp	x20, x19, [sp, #0x30]
    a3d4:      	add	x29, sp, #0x20
    a3d8:      	mrs	x20, TPIDR_EL0
    a3dc:      	mov	w19, w0
    a3e0:      	ldr	x8, [x20, #0x28]
    a3e4:      	stur	x8, [x29, #-0x8]
    a3e8:      	add	x8, sp, #0x8
    a3ec:      	bl	0xe970 <_Z20MTARMPMMusicGetSpeedPv+0x3c74>
    a3f0:      	ldr	x0, [sp, #0x8]
    a3f4:      	cmp	w19, #0x1
    a3f8:      	cset	w1, eq
    a3fc:      	bl	0xecb8 <_Z20MTARMPMMusicGetSpeedPv+0x3fbc>
    a400:      	ldr	x19, [sp, #0x10]
    a404:      	cbz	x19, 0xa430 <_Z19MTARMPMServicePausei+0x68>
    a408:      	add	x1, x19, #0x8
    a40c:      	mov	x0, #-0x1               // =-1
    a410:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    a414:      	cbnz	x0, 0xa430 <_Z19MTARMPMServicePausei+0x68>
    a418:      	ldr	x8, [x19]
    a41c:      	mov	x0, x19
    a420:      	ldr	x8, [x8, #0x10]
    a424:      	blr	x8
    a428:      	mov	x0, x19
    a42c:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    a430:      	ldr	x8, [x20, #0x28]
    a434:      	ldur	x9, [x29, #-0x8]
    a438:      	cmp	x8, x9
    a43c:      	b.ne	0xa474 <_Z19MTARMPMServicePausei+0xac>
    a440:      	ldp	x20, x19, [sp, #0x30]
    a444:      	ldp	x29, x30, [sp, #0x20]
    a448:      	add	sp, sp, #0x40
    a44c:      	ret
    a450:      	mov	x19, x0
    a454:      	add	x0, sp, #0x8
    a458:      	bl	0xa378 <_Z19MTARMPMServiceStartv+0xb4>
    a45c:      	ldr	x8, [x20, #0x28]
    a460:      	ldur	x9, [x29, #-0x8]
    a464:      	cmp	x8, x9
    a468:      	b.ne	0xa474 <_Z19MTARMPMServicePausei+0xac>
    a46c:      	mov	x0, x19
    a470:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    a474:      	bl	0x16b40 <__stack_chk_fail@plt>

000000000000a478 <_Z18MTARMPMServiceStopv>:
    a478:      	sub	sp, sp, #0x40
    a47c:      	stp	x29, x30, [sp, #0x20]
    a480:      	stp	x20, x19, [sp, #0x30]
    a484:      	add	x29, sp, #0x20
    a488:      	mrs	x20, TPIDR_EL0
    a48c:      	ldr	x8, [x20, #0x28]
    a490:      	stur	x8, [x29, #-0x8]
    a494:      	add	x8, sp, #0x8
    a498:      	bl	0xe970 <_Z20MTARMPMMusicGetSpeedPv+0x3c74>
    a49c:      	ldr	x0, [sp, #0x8]
    a4a0:      	bl	0xed24 <_Z20MTARMPMMusicGetSpeedPv+0x4028>
    a4a4:      	ldr	x19, [sp, #0x10]
    a4a8:      	cbz	x19, 0xa4d4 <_Z18MTARMPMServiceStopv+0x5c>
    a4ac:      	add	x1, x19, #0x8
    a4b0:      	mov	x0, #-0x1               // =-1
    a4b4:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    a4b8:      	cbnz	x0, 0xa4d4 <_Z18MTARMPMServiceStopv+0x5c>
    a4bc:      	ldr	x8, [x19]
    a4c0:      	mov	x0, x19
    a4c4:      	ldr	x8, [x8, #0x10]
    a4c8:      	blr	x8
    a4cc:      	mov	x0, x19
    a4d0:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    a4d4:      	ldr	x8, [x20, #0x28]
    a4d8:      	ldur	x9, [x29, #-0x8]
    a4dc:      	cmp	x8, x9
    a4e0:      	b.ne	0xa518 <_Z18MTARMPMServiceStopv+0xa0>
    a4e4:      	ldp	x20, x19, [sp, #0x30]
    a4e8:      	ldp	x29, x30, [sp, #0x20]
    a4ec:      	add	sp, sp, #0x40
    a4f0:      	ret
    a4f4:      	mov	x19, x0
    a4f8:      	add	x0, sp, #0x8
    a4fc:      	bl	0xa378 <_Z19MTARMPMServiceStartv+0xb4>
    a500:      	ldr	x8, [x20, #0x28]
    a504:      	ldur	x9, [x29, #-0x8]
    a508:      	cmp	x8, x9
    a50c:      	b.ne	0xa518 <_Z18MTARMPMServiceStopv+0xa0>
    a510:      	mov	x0, x19
    a514:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    a518:      	bl	0x16b40 <__stack_chk_fail@plt>

000000000000a51c <_Z23MTARMPMServiceIsStoppedv>:
    a51c:      	sub	sp, sp, #0x50
    a520:      	stp	x29, x30, [sp, #0x20]
    a524:      	str	x21, [sp, #0x30]
    a528:      	stp	x20, x19, [sp, #0x40]
    a52c:      	add	x29, sp, #0x20
    a530:      	mrs	x21, TPIDR_EL0
    a534:      	ldr	x8, [x21, #0x28]
    a538:      	stur	x8, [x29, #-0x8]
    a53c:      	add	x8, sp, #0x8
    a540:      	bl	0xe970 <_Z20MTARMPMMusicGetSpeedPv+0x3c74>
    a544:      	ldr	x0, [sp, #0x8]
    a548:      	bl	0xee50 <_Z20MTARMPMMusicGetSpeedPv+0x4154>
    a54c:      	ldr	x20, [sp, #0x10]
    a550:      	mov	w19, w0
    a554:      	cbz	x20, 0xa580 <_Z23MTARMPMServiceIsStoppedv+0x64>
    a558:      	add	x1, x20, #0x8
    a55c:      	mov	x0, #-0x1               // =-1
    a560:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    a564:      	cbnz	x0, 0xa580 <_Z23MTARMPMServiceIsStoppedv+0x64>
    a568:      	ldr	x8, [x20]
    a56c:      	mov	x0, x20
    a570:      	ldr	x8, [x8, #0x10]
    a574:      	blr	x8
    a578:      	mov	x0, x20
    a57c:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    a580:      	ldr	x8, [x21, #0x28]
    a584:      	ldur	x9, [x29, #-0x8]
    a588:      	cmp	x8, x9
    a58c:      	b.ne	0xa5cc <_Z23MTARMPMServiceIsStoppedv+0xb0>
    a590:      	and	w0, w19, #0x1
    a594:      	ldp	x20, x19, [sp, #0x40]
    a598:      	ldr	x21, [sp, #0x30]
    a59c:      	ldp	x29, x30, [sp, #0x20]
    a5a0:      	add	sp, sp, #0x50
    a5a4:      	ret
    a5a8:      	mov	x19, x0
    a5ac:      	add	x0, sp, #0x8
    a5b0:      	bl	0xa378 <_Z19MTARMPMServiceStartv+0xb4>
    a5b4:      	ldr	x8, [x21, #0x28]
    a5b8:      	ldur	x9, [x29, #-0x8]
    a5bc:      	cmp	x8, x9
    a5c0:      	b.ne	0xa5cc <_Z23MTARMPMServiceIsStoppedv+0xb0>
    a5c4:      	mov	x0, x19
    a5c8:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    a5cc:      	bl	0x16b40 <__stack_chk_fail@plt>

000000000000a5d0 <_Z24MTARMPMCreateMusicHandlev>:
    a5d0:      	stp	x29, x30, [sp, #-0x20]!
    a5d4:      	str	x19, [sp, #0x10]
    a5d8:      	mov	x29, sp
    a5dc:      	mov	w0, #0x40               // =64
    a5e0:      	bl	0x16b50 <_Znwm@plt>
    a5e4:      	mov	x19, x0
    a5e8:      	stp	xzr, xzr, [x0]
    a5ec:      	str	xzr, [x0, #0x30]
    a5f0:      	bl	0xa8b8 <_Z16MTARMPMMusicLoadPvPKc+0x150>
    a5f4:      	mov	x0, x19
    a5f8:      	ldr	x19, [sp, #0x10]
    a5fc:      	ldp	x29, x30, [sp], #0x20
    a600:      	ret

000000000000a604 <_Z25MTARMPMDestroyMusicHandleRPv>:
    a604:      	stp	x29, x30, [sp, #-0x20]!
    a608:      	stp	x20, x19, [sp, #0x10]
    a60c:      	mov	x29, sp
    a610:      	ldr	x20, [x0]
    a614:      	cbz	x20, 0xa630 <_Z25MTARMPMDestroyMusicHandleRPv+0x2c>
    a618:      	mov	x19, x0
    a61c:      	mov	x0, x20
    a620:      	bl	0xa63c <_Z25MTARMPMDestroyMusicHandleRPv+0x38>
    a624:      	mov	x0, x20
    a628:      	bl	0x16b60 <_ZdlPv@plt>
    a62c:      	str	xzr, [x19]
    a630:      	ldp	x20, x19, [sp, #0x10]
    a634:      	ldp	x29, x30, [sp], #0x20
    a638:      	ret
    a63c:      	stp	x29, x30, [sp, #-0x20]!
    a640:      	stp	x20, x19, [sp, #0x10]
    a644:      	mov	x29, sp
    a648:      	mov	x19, x0
    a64c:      	bl	0xa8b8 <_Z16MTARMPMMusicLoadPvPKc+0x150>
    a650:      	ldr	x0, [x19, #0x30]
    a654:      	add	x20, x19, #0x10
    a658:      	str	xzr, [x19, #0x30]
    a65c:      	cmp	x0, x20
    a660:      	b.eq	0xa670 <_Z25MTARMPMDestroyMusicHandleRPv+0x6c>
    a664:      	cbz	x0, 0xa6b4 <_Z25MTARMPMDestroyMusicHandleRPv+0xb0>
    a668:      	mov	w8, #0x5                // =5
    a66c:      	b	0xa678 <_Z25MTARMPMDestroyMusicHandleRPv+0x74>
    a670:      	mov	w8, #0x4                // =4
    a674:      	mov	x0, x20
    a678:      	ldr	x9, [x0]
    a67c:      	ldr	x8, [x9, x8, lsl #3]
    a680:      	blr	x8
    a684:      	ldr	x9, [x19, #0x30]
    a688:      	cmp	x9, x20
    a68c:      	b.eq	0xa6a0 <_Z25MTARMPMDestroyMusicHandleRPv+0x9c>
    a690:      	cbz	x9, 0xa6b4 <_Z25MTARMPMDestroyMusicHandleRPv+0xb0>
    a694:      	mov	w8, #0x5                // =5
    a698:      	mov	x20, x9
    a69c:      	b	0xa6a4 <_Z25MTARMPMDestroyMusicHandleRPv+0xa0>
    a6a0:      	mov	w8, #0x4                // =4
    a6a4:      	ldr	x9, [x20]
    a6a8:      	mov	x0, x20
    a6ac:      	ldr	x8, [x9, x8, lsl #3]
    a6b0:      	blr	x8
    a6b4:      	mov	x0, x19
    a6b8:      	ldp	x20, x19, [sp, #0x10]
    a6bc:      	ldp	x29, x30, [sp], #0x20
    a6c0:      	b	0xa9f4 <_Z16MTARMPMMusicLoadPvPKc+0x28c>

000000000000a6c4 <_Z25MTARMPMMusicSetFuncStructPvS_>:
    a6c4:      	cbz	x0, 0xa6d0 <_Z25MTARMPMMusicSetFuncStructPvS_+0xc>
    a6c8:      	add	x0, x0, #0x10
    a6cc:      	b	0xa6d4 <_Z25MTARMPMMusicSetFuncStructPvS_+0x10>
    a6d0:      	ret
    a6d4:      	sub	sp, sp, #0x70
    a6d8:      	stp	x29, x30, [sp, #0x40]
    a6dc:      	str	x21, [sp, #0x50]
    a6e0:      	stp	x20, x19, [sp, #0x60]
    a6e4:      	add	x29, sp, #0x40
    a6e8:      	mrs	x20, TPIDR_EL0
    a6ec:      	mov	x19, x0
    a6f0:      	mov	x0, sp
    a6f4:      	ldr	x8, [x20, #0x28]
    a6f8:      	mov	x21, sp
    a6fc:      	stur	x8, [x29, #-0x8]
    a700:      	bl	0xaea8 <_Z20MTARMPMMusicGetSpeedPv+0x1ac>
    a704:      	mov	x0, sp
    a708:      	mov	x1, x19
    a70c:      	bl	0xaf10 <_Z20MTARMPMMusicGetSpeedPv+0x214>
    a710:      	ldr	x0, [sp, #0x20]
    a714:      	cmp	x0, x21
    a718:      	b.eq	0xa728 <_Z25MTARMPMMusicSetFuncStructPvS_+0x64>
    a71c:      	cbz	x0, 0xa73c <_Z25MTARMPMMusicSetFuncStructPvS_+0x78>
    a720:      	mov	w8, #0x5                // =5
    a724:      	b	0xa730 <_Z25MTARMPMMusicSetFuncStructPvS_+0x6c>
    a728:      	mov	w8, #0x4                // =4
    a72c:      	mov	x0, sp
    a730:      	ldr	x9, [x0]
    a734:      	ldr	x8, [x9, x8, lsl #3]
    a738:      	blr	x8
    a73c:      	ldr	x8, [x20, #0x28]
    a740:      	ldur	x9, [x29, #-0x8]
    a744:      	cmp	x8, x9
    a748:      	b.ne	0xa764 <_Z25MTARMPMMusicSetFuncStructPvS_+0xa0>
    a74c:      	mov	x0, x19
    a750:      	ldp	x20, x19, [sp, #0x60]
    a754:      	ldr	x21, [sp, #0x50]
    a758:      	ldp	x29, x30, [sp, #0x40]
    a75c:      	add	sp, sp, #0x70
    a760:      	ret
    a764:      	bl	0x16b40 <__stack_chk_fail@plt>

000000000000a768 <_Z16MTARMPMMusicLoadPvPKc>:
    a768:      	sub	sp, sp, #0x70
    a76c:      	stp	x29, x30, [sp, #0x40]
    a770:      	stp	x22, x21, [sp, #0x50]
    a774:      	stp	x20, x19, [sp, #0x60]
    a778:      	add	x29, sp, #0x40
    a77c:      	mrs	x22, TPIDR_EL0
    a780:      	ldr	x8, [x22, #0x28]
    a784:      	stur	x8, [x29, #-0x8]
    a788:      	cbz	x0, 0xa854 <_Z16MTARMPMMusicLoadPvPKc+0xec>
    a78c:      	mov	x19, x0
    a790:      	ldr	x0, [x0]
    a794:      	mov	x20, x1
    a798:      	cbz	x0, 0xa7a8 <_Z16MTARMPMMusicLoadPvPKc+0x40>
    a79c:      	bl	0xd284 <_Z20MTARMPMMusicGetSpeedPv+0x2588>
    a7a0:      	mov	x0, x19
    a7a4:      	bl	0xa8b8 <_Z16MTARMPMMusicLoadPvPKc+0x150>
    a7a8:      	add	x8, sp, #0x18
    a7ac:      	bl	0xe970 <_Z20MTARMPMMusicGetSpeedPv+0x3c74>
    a7b0:      	ldr	x21, [sp, #0x18]
    a7b4:      	mov	x0, sp
    a7b8:      	mov	x1, x20
    a7bc:      	bl	0xa90c <_Z16MTARMPMMusicLoadPvPKc+0x1a4>
    a7c0:      	sub	x8, x29, #0x18
    a7c4:      	mov	x1, sp
    a7c8:      	mov	x0, x21
    a7cc:      	bl	0xedb4 <_Z20MTARMPMMusicGetSpeedPv+0x40b8>
    a7d0:      	sub	x1, x29, #0x18
    a7d4:      	mov	x0, x19
    a7d8:      	bl	0xa998 <_Z16MTARMPMMusicLoadPvPKc+0x230>
    a7dc:      	ldur	x20, [x29, #-0x10]
    a7e0:      	cbz	x20, 0xa80c <_Z16MTARMPMMusicLoadPvPKc+0xa4>
    a7e4:      	add	x1, x20, #0x8
    a7e8:      	mov	x0, #-0x1               // =-1
    a7ec:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    a7f0:      	cbnz	x0, 0xa80c <_Z16MTARMPMMusicLoadPvPKc+0xa4>
    a7f4:      	ldr	x8, [x20]
    a7f8:      	mov	x0, x20
    a7fc:      	ldr	x8, [x8, #0x10]
    a800:      	blr	x8
    a804:      	mov	x0, x20
    a808:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    a80c:      	ldrb	w8, [sp]
    a810:      	tbz	w8, #0x0, 0xa81c <_Z16MTARMPMMusicLoadPvPKc+0xb4>
    a814:      	ldr	x0, [sp, #0x10]
    a818:      	bl	0x16b60 <_ZdlPv@plt>
    a81c:      	ldr	x20, [sp, #0x20]
    a820:      	cbz	x20, 0xa84c <_Z16MTARMPMMusicLoadPvPKc+0xe4>
    a824:      	add	x1, x20, #0x8
    a828:      	mov	x0, #-0x1               // =-1
    a82c:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    a830:      	cbnz	x0, 0xa84c <_Z16MTARMPMMusicLoadPvPKc+0xe4>
    a834:      	ldr	x8, [x20]
    a838:      	mov	x0, x20
    a83c:      	ldr	x8, [x8, #0x10]
    a840:      	blr	x8
    a844:      	mov	x0, x20
    a848:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    a84c:      	mov	x0, x19
    a850:      	bl	0xaa44 <_Z16MTARMPMMusicLoadPvPKc+0x2dc>
    a854:      	ldr	x8, [x22, #0x28]
    a858:      	ldur	x9, [x29, #-0x8]
    a85c:      	cmp	x8, x9
    a860:      	b.ne	0xa8b4 <_Z16MTARMPMMusicLoadPvPKc+0x14c>
    a864:      	ldp	x20, x19, [sp, #0x60]
    a868:      	ldp	x22, x21, [sp, #0x50]
    a86c:      	ldp	x29, x30, [sp, #0x40]
    a870:      	add	sp, sp, #0x70
    a874:      	ret
    a878:      	ldrb	w8, [sp]
    a87c:      	mov	x19, x0
    a880:      	tbz	w8, #0x0, 0xa894 <_Z16MTARMPMMusicLoadPvPKc+0x12c>
    a884:      	ldr	x0, [sp, #0x10]
    a888:      	bl	0x16b60 <_ZdlPv@plt>
    a88c:      	b	0xa894 <_Z16MTARMPMMusicLoadPvPKc+0x12c>
    a890:      	mov	x19, x0
    a894:      	add	x0, sp, #0x18
    a898:      	bl	0xa378 <_Z19MTARMPMServiceStartv+0xb4>
    a89c:      	ldr	x8, [x22, #0x28]
    a8a0:      	ldur	x9, [x29, #-0x8]
    a8a4:      	cmp	x8, x9
    a8a8:      	b.ne	0xa8b4 <_Z16MTARMPMMusicLoadPvPKc+0x14c>
    a8ac:      	mov	x0, x19
    a8b0:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    a8b4:      	bl	0x16b40 <__stack_chk_fail@plt>
    a8b8:      	stp	x29, x30, [sp, #-0x20]!
    a8bc:      	str	x19, [sp, #0x10]
    a8c0:      	mov	x29, sp
    a8c4:      	ldr	x19, [x0, #0x8]
    a8c8:      	stp	xzr, xzr, [x0]
    a8cc:      	cbz	x19, 0xa8e0 <_Z16MTARMPMMusicLoadPvPKc+0x178>
    a8d0:      	add	x1, x19, #0x8
    a8d4:      	mov	x0, #-0x1               // =-1
    a8d8:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    a8dc:      	cbz	x0, 0xa8ec <_Z16MTARMPMMusicLoadPvPKc+0x184>
    a8e0:      	ldr	x19, [sp, #0x10]
    a8e4:      	ldp	x29, x30, [sp], #0x20
    a8e8:      	ret
    a8ec:      	ldr	x8, [x19]
    a8f0:      	mov	x0, x19
    a8f4:      	ldr	x8, [x8, #0x10]
    a8f8:      	blr	x8
    a8fc:      	mov	x0, x19
    a900:      	ldr	x19, [sp, #0x10]
    a904:      	ldp	x29, x30, [sp], #0x20
    a908:      	b	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    a90c:      	stp	x29, x30, [sp, #-0x30]!
    a910:      	stp	x22, x21, [sp, #0x10]
    a914:      	stp	x20, x19, [sp, #0x20]
    a918:      	mov	x29, sp
    a91c:      	mov	x19, x0
    a920:      	mov	x0, x1
    a924:      	mov	x21, x1
    a928:      	bl	0x16b70 <strlen@plt>
    a92c:      	cmn	x0, #0x10
    a930:      	b.hs	0xa990 <_Z16MTARMPMMusicLoadPvPKc+0x228>
    a934:      	mov	x20, x0
    a938:      	cmp	x0, #0x17
    a93c:      	b.hs	0xa950 <_Z16MTARMPMMusicLoadPvPKc+0x1e8>
    a940:      	lsl	w8, w20, #1
    a944:      	strb	w8, [x19], #0x1
    a948:      	cbnz	x20, 0xa96c <_Z16MTARMPMMusicLoadPvPKc+0x204>
    a94c:      	b	0xa97c <_Z16MTARMPMMusicLoadPvPKc+0x214>
    a950:      	orr	x22, x20, #0xf
    a954:      	add	x0, x22, #0x1
    a958:      	bl	0x16b50 <_Znwm@plt>
    a95c:      	add	x8, x22, #0x2
    a960:      	stp	x20, x0, [x19, #0x8]
    a964:      	str	x8, [x19]
    a968:      	mov	x19, x0
    a96c:      	mov	x0, x19
    a970:      	mov	x1, x21
    a974:      	mov	x2, x20
    a978:      	bl	0x16b80 <memmove@plt>
    a97c:      	strb	wzr, [x19, x20]
    a980:      	ldp	x20, x19, [sp, #0x20]
    a984:      	ldp	x22, x21, [sp, #0x10]
    a988:      	ldp	x29, x30, [sp], #0x30
    a98c:      	ret
    a990:      	mov	x0, x19
    a994:      	bl	0xae14 <_Z20MTARMPMMusicGetSpeedPv+0x118>
    a998:      	stp	x29, x30, [sp, #-0x20]!
    a99c:      	stp	x20, x19, [sp, #0x10]
    a9a0:      	mov	x29, sp
    a9a4:      	ldr	q0, [x1]
    a9a8:      	stp	xzr, xzr, [x1]
    a9ac:      	mov	x19, x0
    a9b0:      	ldr	x20, [x0, #0x8]
    a9b4:      	str	q0, [x0]
    a9b8:      	cbz	x20, 0xa9e4 <_Z16MTARMPMMusicLoadPvPKc+0x27c>
    a9bc:      	add	x1, x20, #0x8
    a9c0:      	mov	x0, #-0x1               // =-1
    a9c4:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    a9c8:      	cbnz	x0, 0xa9e4 <_Z16MTARMPMMusicLoadPvPKc+0x27c>
    a9cc:      	ldr	x8, [x20]
    a9d0:      	mov	x0, x20
    a9d4:      	ldr	x8, [x8, #0x10]
    a9d8:      	blr	x8
    a9dc:      	mov	x0, x20
    a9e0:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    a9e4:      	mov	x0, x19
    a9e8:      	ldp	x20, x19, [sp, #0x10]
    a9ec:      	ldp	x29, x30, [sp], #0x20
    a9f0:      	ret
    a9f4:      	stp	x29, x30, [sp, #-0x20]!
    a9f8:      	str	x19, [sp, #0x10]
    a9fc:      	mov	x29, sp
    aa00:      	ldr	x19, [x0, #0x8]
    aa04:      	cbz	x19, 0xaa18 <_Z16MTARMPMMusicLoadPvPKc+0x2b0>
    aa08:      	add	x1, x19, #0x8
    aa0c:      	mov	x0, #-0x1               // =-1
    aa10:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    aa14:      	cbz	x0, 0xaa24 <_Z16MTARMPMMusicLoadPvPKc+0x2bc>
    aa18:      	ldr	x19, [sp, #0x10]
    aa1c:      	ldp	x29, x30, [sp], #0x20
    aa20:      	ret
    aa24:      	ldr	x8, [x19]
    aa28:      	mov	x0, x19
    aa2c:      	ldr	x8, [x8, #0x10]
    aa30:      	blr	x8
    aa34:      	mov	x0, x19
    aa38:      	ldr	x19, [sp, #0x10]
    aa3c:      	ldp	x29, x30, [sp], #0x20
    aa40:      	b	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    aa44:      	sub	sp, sp, #0x90
    aa48:      	stp	x29, x30, [sp, #0x60]
    aa4c:      	str	x21, [sp, #0x70]
    aa50:      	stp	x20, x19, [sp, #0x80]
    aa54:      	add	x29, sp, #0x60
    aa58:      	mrs	x21, TPIDR_EL0
    aa5c:      	ldr	x8, [x21, #0x28]
    aa60:      	stur	x8, [x29, #-0x8]
    aa64:      	ldr	x19, [x0]
    aa68:      	cbz	x19, 0xaaec <_Z16MTARMPMMusicLoadPvPKc+0x384>
    aa6c:      	mov	x20, x0
    aa70:      	nop
    aa74:      	adr	x1, 0x47ea
    aa78:      	add	x0, sp, #0x8
    aa7c:      	bl	0xa90c <_Z16MTARMPMMusicLoadPvPKc+0x1a4>
    aa80:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    aa84:      	add	x8, x8, #0x338
    aa88:      	nop
    aa8c:      	adr	x9, 0xad24 <_Z20MTARMPMMusicGetSpeedPv+0x28>
    aa90:      	stp	xzr, x20, [sp, #0x30]
    aa94:      	add	x20, sp, #0x20
    aa98:      	stp	x8, x9, [sp, #0x20]
    aa9c:      	str	x20, [sp, #0x40]
    aaa0:      	add	x1, sp, #0x8
    aaa4:      	add	x2, sp, #0x20
    aaa8:      	mov	x0, x19
    aaac:      	bl	0xd9a0 <_Z20MTARMPMMusicGetSpeedPv+0x2ca4>
    aab0:      	ldr	x0, [sp, #0x40]
    aab4:      	cmp	x0, x20
    aab8:      	b.eq	0xaac8 <_Z16MTARMPMMusicLoadPvPKc+0x360>
    aabc:      	cbz	x0, 0xaadc <_Z16MTARMPMMusicLoadPvPKc+0x374>
    aac0:      	mov	w8, #0x5                // =5
    aac4:      	b	0xaad0 <_Z16MTARMPMMusicLoadPvPKc+0x368>
    aac8:      	mov	w8, #0x4                // =4
    aacc:      	add	x0, sp, #0x20
    aad0:      	ldr	x9, [x0]
    aad4:      	ldr	x8, [x9, x8, lsl #3]
    aad8:      	blr	x8
    aadc:      	ldrb	w8, [sp, #0x8]
    aae0:      	tbz	w8, #0x0, 0xaaec <_Z16MTARMPMMusicLoadPvPKc+0x384>
    aae4:      	ldr	x0, [sp, #0x18]
    aae8:      	bl	0x16b60 <_ZdlPv@plt>
    aaec:      	ldr	x8, [x21, #0x28]
    aaf0:      	ldur	x9, [x29, #-0x8]
    aaf4:      	cmp	x8, x9
    aaf8:      	b.ne	0xab6c <_Z16MTARMPMMusicLoadPvPKc+0x404>
    aafc:      	ldp	x20, x19, [sp, #0x80]
    ab00:      	ldr	x21, [sp, #0x70]
    ab04:      	ldp	x29, x30, [sp, #0x60]
    ab08:      	add	sp, sp, #0x90
    ab0c:      	ret
    ab10:      	ldr	x8, [sp, #0x40]
    ab14:      	mov	x19, x0
    ab18:      	cmp	x8, x20
    ab1c:      	b.ne	0xab2c <_Z16MTARMPMMusicLoadPvPKc+0x3c4>
    ab20:      	mov	w9, #0x4                // =4
    ab24:      	add	x8, sp, #0x20
    ab28:      	b	0xab34 <_Z16MTARMPMMusicLoadPvPKc+0x3cc>
    ab2c:      	cbz	x8, 0xab44 <_Z16MTARMPMMusicLoadPvPKc+0x3dc>
    ab30:      	mov	w9, #0x5                // =5
    ab34:      	ldr	x10, [x8]
    ab38:      	mov	x0, x8
    ab3c:      	ldr	x9, [x10, x9, lsl #3]
    ab40:      	blr	x9
    ab44:      	ldrb	w8, [sp, #0x8]
    ab48:      	tbz	w8, #0x0, 0xab54 <_Z16MTARMPMMusicLoadPvPKc+0x3ec>
    ab4c:      	ldr	x0, [sp, #0x18]
    ab50:      	bl	0x16b60 <_ZdlPv@plt>
    ab54:      	ldr	x8, [x21, #0x28]
    ab58:      	ldur	x9, [x29, #-0x8]
    ab5c:      	cmp	x8, x9
    ab60:      	b.ne	0xab6c <_Z16MTARMPMMusicLoadPvPKc+0x404>
    ab64:      	mov	x0, x19
    ab68:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    ab6c:      	bl	0x16b40 <__stack_chk_fail@plt>

000000000000ab70 <_Z22MTARMPMMusicFromMemoryPvPcj>:
    ab70:      	stp	x29, x30, [sp, #-0x20]!
    ab74:      	str	x19, [sp, #0x10]
    ab78:      	mov	x29, sp
    ab7c:      	cbz	x0, 0xaba0 <_Z22MTARMPMMusicFromMemoryPvPcj+0x30>
    ab80:      	mov	x19, x0
    ab84:      	ldr	x0, [x0]
    ab88:      	cbz	x0, 0xaba0 <_Z22MTARMPMMusicFromMemoryPvPcj+0x30>
    ab8c:      	bl	0xd284 <_Z20MTARMPMMusicGetSpeedPv+0x2588>
    ab90:      	mov	x0, x19
    ab94:      	ldr	x19, [sp, #0x10]
    ab98:      	ldp	x29, x30, [sp], #0x20
    ab9c:      	b	0xa8b8 <_Z16MTARMPMMusicLoadPvPKc+0x150>
    aba0:      	ldr	x19, [sp, #0x10]
    aba4:      	ldp	x29, x30, [sp], #0x20
    aba8:      	ret

000000000000abac <_Z16MTARMPMMusicPlayPv>:
    abac:      	cbz	x0, 0xabbc <_Z16MTARMPMMusicPlayPv+0x10>
    abb0:      	ldr	x0, [x0]
    abb4:      	cbz	x0, 0xabbc <_Z16MTARMPMMusicPlayPv+0x10>
    abb8:      	b	0xd4ec <_Z20MTARMPMMusicGetSpeedPv+0x27f0>
    abbc:      	ret

000000000000abc0 <_Z17MTARMPMMusicPausePv>:
    abc0:      	cbz	x0, 0xabd0 <_Z17MTARMPMMusicPausePv+0x10>
    abc4:      	ldr	x0, [x0]
    abc8:      	cbz	x0, 0xabd0 <_Z17MTARMPMMusicPausePv+0x10>
    abcc:      	b	0xd49c <_Z20MTARMPMMusicGetSpeedPv+0x27a0>
    abd0:      	ret

000000000000abd4 <_Z16MTARMPMMusicStopPv>:
    abd4:      	cbz	x0, 0xabe4 <_Z16MTARMPMMusicStopPv+0x10>
    abd8:      	ldr	x0, [x0]
    abdc:      	cbz	x0, 0xabe4 <_Z16MTARMPMMusicStopPv+0x10>
    abe0:      	b	0xd65c <_Z20MTARMPMMusicGetSpeedPv+0x2960>
    abe4:      	ret

000000000000abe8 <_Z19MTARMPMMusicDisposePv>:
    abe8:      	cbz	x0, 0xabf8 <_Z19MTARMPMMusicDisposePv+0x10>
    abec:      	ldr	x0, [x0]
    abf0:      	cbz	x0, 0xabf8 <_Z19MTARMPMMusicDisposePv+0x10>
    abf4:      	b	0xd284 <_Z20MTARMPMMusicGetSpeedPv+0x2588>
    abf8:      	ret

000000000000abfc <_Z21MTARMPMMusicIsPlayingPv>:
    abfc:      	cbz	x0, 0xac1c <_Z21MTARMPMMusicIsPlayingPv+0x20>
    ac00:      	ldr	x0, [x0]
    ac04:      	cbz	x0, 0xac1c <_Z21MTARMPMMusicIsPlayingPv+0x20>
    ac08:      	stp	x29, x30, [sp, #-0x10]!
    ac0c:      	mov	x29, sp
    ac10:      	bl	0xd474 <_Z20MTARMPMMusicGetSpeedPv+0x2778>
    ac14:      	and	w0, w0, #0x1
    ac18:      	ldp	x29, x30, [sp], #0x10
    ac1c:      	ret

000000000000ac20 <_Z24MTARMPMMusicGetLoopCountPv>:
    ac20:      	cbz	x0, 0xac30 <_Z24MTARMPMMusicGetLoopCountPv+0x10>
    ac24:      	ldr	x0, [x0]
    ac28:      	cbz	x0, 0xac30 <_Z24MTARMPMMusicGetLoopCountPv+0x10>
    ac2c:      	b	0xd454 <_Z20MTARMPMMusicGetSpeedPv+0x2758>
    ac30:      	mov	w0, wzr
    ac34:      	ret

000000000000ac38 <_Z23MTARMPMMusicGetDurationPv>:
    ac38:      	cbz	x0, 0xac48 <_Z23MTARMPMMusicGetDurationPv+0x10>
    ac3c:      	ldr	x0, [x0]
    ac40:      	cbz	x0, 0xac48 <_Z23MTARMPMMusicGetDurationPv+0x10>
    ac44:      	b	0xd8f4 <_Z20MTARMPMMusicGetSpeedPv+0x2bf8>
    ac48:      	movi	d0, #0000000000000000
    ac4c:      	ret

000000000000ac50 <_Z22MTARMPMMusicSetLoopingPvi>:
    ac50:      	cbz	x0, 0xac68 <_Z22MTARMPMMusicSetLoopingPvi+0x18>
    ac54:      	ldr	x0, [x0]
    ac58:      	cbz	x0, 0xac68 <_Z22MTARMPMMusicSetLoopingPvi+0x18>
    ac5c:      	cmp	w1, #0x0
    ac60:      	cset	w1, ne
    ac64:      	b	0xd59c <_Z20MTARMPMMusicGetSpeedPv+0x28a0>
    ac68:      	ret

000000000000ac6c <_Z22MTARMPMMusicGetLoopingPv>:
    ac6c:      	cbz	x0, 0xac8c <_Z22MTARMPMMusicGetLoopingPv+0x20>
    ac70:      	ldr	x0, [x0]
    ac74:      	cbz	x0, 0xac8c <_Z22MTARMPMMusicGetLoopingPv+0x20>
    ac78:      	stp	x29, x30, [sp, #-0x10]!
    ac7c:      	mov	x29, sp
    ac80:      	bl	0xd42c <_Z20MTARMPMMusicGetSpeedPv+0x2730>
    ac84:      	and	w0, w0, #0x1
    ac88:      	ldp	x29, x30, [sp], #0x10
    ac8c:      	ret

000000000000ac90 <_Z21MTARMPMMusicSetVolumePvf>:
    ac90:      	cbz	x0, 0xaca0 <_Z21MTARMPMMusicSetVolumePvf+0x10>
    ac94:      	ldr	x0, [x0]
    ac98:      	cbz	x0, 0xaca0 <_Z21MTARMPMMusicSetVolumePvf+0x10>
    ac9c:      	b	0xd5f8 <_Z20MTARMPMMusicGetSpeedPv+0x28fc>
    aca0:      	ret

000000000000aca4 <_Z21MTARMPMMusicGetVolumePv>:
    aca4:      	cbz	x0, 0xacb4 <_Z21MTARMPMMusicGetVolumePv+0x10>
    aca8:      	ldr	x0, [x0]
    acac:      	cbz	x0, 0xacb4 <_Z21MTARMPMMusicGetVolumePv+0x10>
    acb0:      	b	0xd654 <_Z20MTARMPMMusicGetSpeedPv+0x2958>
    acb4:      	fmov	s0, #1.00000000
    acb8:      	ret

000000000000acbc <_Z23MTARMPMMusicSetPositionPvf>:
    acbc:      	cbz	x0, 0xaccc <_Z23MTARMPMMusicSetPositionPvf+0x10>
    acc0:      	ldr	x0, [x0]
    acc4:      	cbz	x0, 0xaccc <_Z23MTARMPMMusicSetPositionPvf+0x10>
    acc8:      	b	0xd6b4 <_Z20MTARMPMMusicGetSpeedPv+0x29b8>
    accc:      	ret

000000000000acd0 <_Z23MTARMPMMusicGetPositionPv>:
    acd0:      	cbz	x0, 0xace0 <_Z23MTARMPMMusicGetPositionPv+0x10>
    acd4:      	ldr	x0, [x0]
    acd8:      	cbz	x0, 0xace0 <_Z23MTARMPMMusicGetPositionPv+0x10>
    acdc:      	b	0xd788 <_Z20MTARMPMMusicGetSpeedPv+0x2a8c>
    ace0:      	movi	d0, #0000000000000000
    ace4:      	ret

000000000000ace8 <_Z20MTARMPMMusicSetSpeedPvf>:
    ace8:      	cbz	x0, 0xacf8 <_Z20MTARMPMMusicSetSpeedPvf+0x10>
    acec:      	ldr	x0, [x0]
    acf0:      	cbz	x0, 0xacf8 <_Z20MTARMPMMusicSetSpeedPvf+0x10>
    acf4:      	b	0xd7bc <_Z20MTARMPMMusicGetSpeedPv+0x2ac0>
    acf8:      	ret

000000000000acfc <_Z20MTARMPMMusicGetSpeedPv>:
    acfc:      	cbz	x0, 0xad0c <_Z20MTARMPMMusicGetSpeedPv+0x10>
    ad00:      	ldr	x0, [x0]
    ad04:      	cbz	x0, 0xad0c <_Z20MTARMPMMusicGetSpeedPv+0x10>
    ad08:      	b	0xd8d8 <_Z20MTARMPMMusicGetSpeedPv+0x2bdc>
    ad0c:      	fmov	s0, #1.00000000
    ad10:      	ret
    ad14:      	stp	x29, x30, [sp, #-0x10]!
    ad18:      	mov	x29, sp
    ad1c:      	bl	0x16b90 <__cxa_begin_catch@plt>
    ad20:      	bl	0x16ba0 <_ZSt9terminatev@plt>
    ad24:      	sub	sp, sp, #0x30
    ad28:      	stp	x29, x30, [sp, #0x10]
    ad2c:      	str	x19, [sp, #0x20]
    ad30:      	add	x29, sp, #0x10
    ad34:      	mrs	x19, TPIDR_EL0
    ad38:      	ldr	x8, [x19, #0x28]
    ad3c:      	str	x8, [sp, #0x8]
    ad40:      	ldr	x0, [x0, #0x30]
    ad44:      	cbz	x0, 0xad60 <_Z20MTARMPMMusicGetSpeedPv+0x64>
    ad48:      	ldr	x8, [x0]
    ad4c:      	mov	w9, #0x1                // =1
    ad50:      	add	x1, sp, #0x4
    ad54:      	str	w9, [sp, #0x4]
    ad58:      	ldr	x8, [x8, #0x30]
    ad5c:      	blr	x8
    ad60:      	ldr	x8, [x19, #0x28]
    ad64:      	ldr	x9, [sp, #0x8]
    ad68:      	cmp	x8, x9
    ad6c:      	b.ne	0xad80 <_Z20MTARMPMMusicGetSpeedPv+0x84>
    ad70:      	ldp	x29, x30, [sp, #0x10]
    ad74:      	ldr	x19, [sp, #0x20]
    ad78:      	add	sp, sp, #0x30
    ad7c:      	ret
    ad80:      	bl	0x16b40 <__stack_chk_fail@plt>
    ad84:      	ret
    ad88:      	b	0x16b60 <_ZdlPv@plt>
    ad8c:      	stp	x29, x30, [sp, #-0x20]!
    ad90:      	str	x19, [sp, #0x10]
    ad94:      	mov	x29, sp
    ad98:      	mov	x19, x0
    ad9c:      	mov	w0, #0x20               // =32
    ada0:      	bl	0x16b50 <_Znwm@plt>
    ada4:      	ldur	q0, [x19, #0x8]
    ada8:      	ldr	x9, [x19, #0x18]
    adac:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    adb0:      	add	x8, x8, #0x338
    adb4:      	str	x8, [x0]
    adb8:      	stur	q0, [x0, #0x8]
    adbc:      	str	x9, [x0, #0x18]
    adc0:      	ldr	x19, [sp, #0x10]
    adc4:      	ldp	x29, x30, [sp], #0x20
    adc8:      	ret
    adcc:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    add0:      	add	x8, x8, #0x338
    add4:      	str	x8, [x1]
    add8:      	ldr	x8, [x0, #0x18]
    addc:      	ldur	q0, [x0, #0x8]
    ade0:      	str	x8, [x1, #0x18]
    ade4:      	stur	q0, [x1, #0x8]
    ade8:      	ret
    adec:      	ret
    adf0:      	b	0x16b60 <_ZdlPv@plt>
    adf4:      	ldp	x9, x8, [x0, #0x10]
    adf8:      	ldr	x2, [x0, #0x8]
    adfc:      	add	x0, x8, x9, asr #1
    ae00:      	tbz	w9, #0x0, 0xae0c <_Z20MTARMPMMusicGetSpeedPv+0x110>
    ae04:      	ldr	x8, [x0]
    ae08:      	ldr	x2, [x8, x2]
    ae0c:      	ldr	x1, [x1]
    ae10:      	br	x2
    ae14:      	stp	x29, x30, [sp, #-0x10]!
    ae18:      	mov	x29, sp
    ae1c:      	adrp	x0, 0x5000
    ae20:      	add	x0, x0, #0xa03
    ae24:      	bl	0xae28 <_Z20MTARMPMMusicGetSpeedPv+0x12c>
    ae28:      	stp	x29, x30, [sp, #-0x20]!
    ae2c:      	stp	x20, x19, [sp, #0x10]
    ae30:      	mov	x29, sp
    ae34:      	mov	x20, x0
    ae38:      	mov	w0, #0x10               // =16
    ae3c:      	bl	0x16bb0 <__cxa_allocate_exception@plt>
    ae40:      	mov	x19, x0
    ae44:      	mov	x1, x20
    ae48:      	bl	0xae78 <_Z20MTARMPMMusicGetSpeedPv+0x17c>
    ae4c:      	adrp	x1, 0x1b000 <syscall@plt+0x3d00>
    ae50:      	adrp	x2, 0x1b000 <syscall@plt+0x3d00>
    ae54:      	mov	x0, x19
    ae58:      	ldr	x1, [x1, #0x920]
    ae5c:      	ldr	x2, [x2, #0x928]
    ae60:      	bl	0x16bc0 <__cxa_throw@plt>
    ae64:      	mov	x20, x0
    ae68:      	mov	x0, x19
    ae6c:      	bl	0x16bd0 <__cxa_free_exception@plt>
    ae70:      	mov	x0, x20
    ae74:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    ae78:      	stp	x29, x30, [sp, #-0x20]!
    ae7c:      	str	x19, [sp, #0x10]
    ae80:      	mov	x29, sp
    ae84:      	mov	x19, x0
    ae88:      	bl	0x16be0 <_ZNSt11logic_errorC2EPKc@plt>
    ae8c:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    ae90:      	ldr	x8, [x8, #0x930]
    ae94:      	add	x8, x8, #0x10
    ae98:      	str	x8, [x19]
    ae9c:      	ldr	x19, [sp, #0x10]
    aea0:      	ldp	x29, x30, [sp], #0x20
    aea4:      	ret
    aea8:      	stp	x29, x30, [sp, #-0x20]!
    aeac:      	str	x19, [sp, #0x10]
    aeb0:      	mov	x29, sp
    aeb4:      	ldr	x8, [x1, #0x20]
    aeb8:      	mov	x19, x0
    aebc:      	cbz	x8, 0xaee0 <_Z20MTARMPMMusicGetSpeedPv+0x1e4>
    aec0:      	cmp	x8, x1
    aec4:      	b.eq	0xaef0 <_Z20MTARMPMMusicGetSpeedPv+0x1f4>
    aec8:      	ldr	x9, [x8]
    aecc:      	mov	x0, x8
    aed0:      	ldr	x9, [x9, #0x10]
    aed4:      	blr	x9
    aed8:      	str	x0, [x19, #0x20]
    aedc:      	b	0xaee4 <_Z20MTARMPMMusicGetSpeedPv+0x1e8>
    aee0:      	str	xzr, [x19, #0x20]
    aee4:      	ldr	x19, [sp, #0x10]
    aee8:      	ldp	x29, x30, [sp], #0x20
    aeec:      	ret
    aef0:      	str	x19, [x19, #0x20]
    aef4:      	ldr	x0, [x1, #0x20]
    aef8:      	ldr	x8, [x0]
    aefc:      	ldr	x2, [x8, #0x18]
    af00:      	mov	x1, x19
    af04:      	ldr	x19, [sp, #0x10]
    af08:      	ldp	x29, x30, [sp], #0x20
    af0c:      	br	x2
    af10:      	sub	sp, sp, #0x60
    af14:      	stp	x29, x30, [sp, #0x30]
    af18:      	str	x21, [sp, #0x40]
    af1c:      	stp	x20, x19, [sp, #0x50]
    af20:      	add	x29, sp, #0x30
    af24:      	mrs	x21, TPIDR_EL0
    af28:      	ldr	x8, [x21, #0x28]
    af2c:      	cmp	x1, x0
    af30:      	stur	x8, [x29, #-0x8]
    af34:      	b.eq	0xb04c <_Z20MTARMPMMusicGetSpeedPv+0x350>
    af38:      	ldr	x8, [x0, #0x20]
    af3c:      	ldr	x9, [x1, #0x20]
    af40:      	mov	x19, x1
    af44:      	mov	x20, x0
    af48:      	cmp	x8, x0
    af4c:      	b.eq	0xaf64 <_Z20MTARMPMMusicGetSpeedPv+0x268>
    af50:      	cmp	x9, x19
    af54:      	b.eq	0xaf9c <_Z20MTARMPMMusicGetSpeedPv+0x2a0>
    af58:      	str	x9, [x20, #0x20]
    af5c:      	str	x8, [x19, #0x20]
    af60:      	b	0xb04c <_Z20MTARMPMMusicGetSpeedPv+0x350>
    af64:      	cmp	x9, x19
    af68:      	b.eq	0xafd0 <_Z20MTARMPMMusicGetSpeedPv+0x2d4>
    af6c:      	ldr	x8, [x20]
    af70:      	ldr	x8, [x8, #0x18]
    af74:      	mov	x0, x20
    af78:      	mov	x1, x19
    af7c:      	blr	x8
    af80:      	ldr	x0, [x20, #0x20]
    af84:      	ldr	x8, [x0]
    af88:      	ldr	x8, [x8, #0x20]
    af8c:      	blr	x8
    af90:      	ldr	x8, [x19, #0x20]
    af94:      	str	x8, [x20, #0x20]
    af98:      	b	0xb048 <_Z20MTARMPMMusicGetSpeedPv+0x34c>
    af9c:      	ldr	x8, [x19]
    afa0:      	ldr	x8, [x8, #0x18]
    afa4:      	mov	x0, x19
    afa8:      	mov	x1, x20
    afac:      	blr	x8
    afb0:      	ldr	x0, [x19, #0x20]
    afb4:      	ldr	x8, [x0]
    afb8:      	ldr	x8, [x8, #0x20]
    afbc:      	blr	x8
    afc0:      	ldr	x8, [x20, #0x20]
    afc4:      	str	x8, [x19, #0x20]
    afc8:      	str	x20, [x20, #0x20]
    afcc:      	b	0xb04c <_Z20MTARMPMMusicGetSpeedPv+0x350>
    afd0:      	ldr	x8, [x20]
    afd4:      	ldr	x8, [x8, #0x18]
    afd8:      	mov	x1, sp
    afdc:      	mov	x0, x20
    afe0:      	blr	x8
    afe4:      	ldr	x0, [x20, #0x20]
    afe8:      	ldr	x8, [x0]
    afec:      	ldr	x8, [x8, #0x20]
    aff0:      	blr	x8
    aff4:      	str	xzr, [x20, #0x20]
    aff8:      	ldr	x0, [x19, #0x20]
    affc:      	ldr	x8, [x0]
    b000:      	ldr	x8, [x8, #0x18]
    b004:      	mov	x1, x20
    b008:      	blr	x8
    b00c:      	ldr	x0, [x19, #0x20]
    b010:      	ldr	x8, [x0]
    b014:      	ldr	x8, [x8, #0x20]
    b018:      	blr	x8
    b01c:      	ldr	x8, [sp]
    b020:      	str	xzr, [x19, #0x20]
    b024:      	str	x20, [x20, #0x20]
    b028:      	ldr	x8, [x8, #0x18]
    b02c:      	mov	x0, sp
    b030:      	mov	x1, x19
    b034:      	blr	x8
    b038:      	ldr	x8, [sp]
    b03c:      	mov	x0, sp
    b040:      	ldr	x8, [x8, #0x20]
    b044:      	blr	x8
    b048:      	str	x19, [x19, #0x20]
    b04c:      	ldr	x8, [x21, #0x28]
    b050:      	ldur	x9, [x29, #-0x8]
    b054:      	cmp	x8, x9
    b058:      	b.ne	0xb070 <_Z20MTARMPMMusicGetSpeedPv+0x374>
    b05c:      	ldp	x20, x19, [sp, #0x50]
    b060:      	ldr	x21, [sp, #0x40]
    b064:      	ldp	x29, x30, [sp, #0x30]
    b068:      	add	sp, sp, #0x60
    b06c:      	ret
    b070:      	bl	0x16b40 <__stack_chk_fail@plt>
    b074:      	bl	0xad14 <_Z20MTARMPMMusicGetSpeedPv+0x18>
    b078:      	stp	x29, x30, [sp, #-0x20]!
    b07c:      	str	x19, [sp, #0x10]
    b080:      	mov	x29, sp
    b084:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    b088:      	add	x8, x8, #0x3b0
    b08c:      	mov	x19, x0
    b090:      	str	x8, [x0], #0x8
    b094:      	ldrb	w8, [x1]
    b098:      	tbnz	w8, #0x0, 0xb0b0 <_Z20MTARMPMMusicGetSpeedPv+0x3b4>
    b09c:      	ldr	x8, [x1, #0x10]
    b0a0:      	ldr	q0, [x1]
    b0a4:      	str	x8, [x0, #0x10]
    b0a8:      	str	q0, [x0]
    b0ac:      	b	0xb0bc <_Z20MTARMPMMusicGetSpeedPv+0x3c0>
    b0b0:      	ldp	x2, x8, [x1, #0x8]
    b0b4:      	mov	x1, x8
    b0b8:      	bl	0xca60 <_Z20MTARMPMMusicGetSpeedPv+0x1d64>
    b0bc:      	movi	v0.2d, #0000000000000000
    b0c0:      	mov	w8, #-0x1               // =-1
    b0c4:      	add	x9, x19, #0x138
    b0c8:      	str	w8, [x19, #0x28]
    b0cc:      	str	w8, [x19, #0x38]
    b0d0:      	str	w8, [x19, #0xe8]
    b0d4:      	add	x8, x19, #0x108
    b0d8:      	stp	q0, q0, [x8]
    b0dc:      	mov	w8, #0x3f800000         // =1065353216
    b0e0:      	stp	x8, xzr, [x19, #0x128]
    b0e4:      	mov	w8, #0x1                // =1
    b0e8:      	strh	w8, [x19, #0x174]
    b0ec:      	mov	x8, #-0x8000000000000000 // =-9223372036854775808
    b0f0:      	str	x8, [x19, #0x178]
    b0f4:      	add	x8, x19, #0x180
    b0f8:      	str	q0, [x19, #0x1c0]
    b0fc:      	stur	q0, [x8, #0x4c]
    b100:      	mov	x8, #0x3ff0000000000000 // =4607182418800017408
    b104:      	str	xzr, [x19, #0xd0]
    b108:      	strb	wzr, [x19, #0xd8]
    b10c:      	str	xzr, [x19, #0xe0]
    b110:      	stp	q0, q0, [x19, #0x40]
    b114:      	stp	q0, q0, [x19, #0x60]
    b118:      	stp	q0, q0, [x19, #0x80]
    b11c:      	str	q0, [x19, #0xa0]
    b120:      	stp	xzr, xzr, [x19, #0xf0]
    b124:      	str	wzr, [x19, #0x100]
    b128:      	str	wzr, [x19, #0x160]
    b12c:      	str	xzr, [x19, #0x168]
    b130:      	str	wzr, [x19, #0x170]
    b134:      	str	xzr, [x19, #0x210]
    b138:      	strb	wzr, [x19, #0x220]
    b13c:      	stp	q0, q0, [x19, #0x180]
    b140:      	stp	q0, q0, [x19, #0x1a0]
    b144:      	stp	q0, q0, [x9]
    b148:      	str	xzr, [x19, #0x158]
    b14c:      	strb	wzr, [x19, #0x20]
    b150:      	str	x8, [x19, #0x1e0]
    b154:      	ldr	x19, [sp, #0x10]
    b158:      	ldp	x29, x30, [sp], #0x20
    b15c:      	ret
    b160:      	stp	x29, x30, [sp, #-0x20]!
    b164:      	str	x19, [sp, #0x10]
    b168:      	mov	x29, sp
    b16c:      	ldr	x19, [x0, #0x8]
    b170:      	cbz	x19, 0xb184 <_Z20MTARMPMMusicGetSpeedPv+0x488>
    b174:      	add	x1, x19, #0x8
    b178:      	mov	x0, #-0x1               // =-1
    b17c:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    b180:      	cbz	x0, 0xb190 <_Z20MTARMPMMusicGetSpeedPv+0x494>
    b184:      	ldr	x19, [sp, #0x10]
    b188:      	ldp	x29, x30, [sp], #0x20
    b18c:      	ret
    b190:      	ldr	x8, [x19]
    b194:      	mov	x0, x19
    b198:      	ldr	x8, [x8, #0x10]
    b19c:      	blr	x8
    b1a0:      	mov	x0, x19
    b1a4:      	ldr	x19, [sp, #0x10]
    b1a8:      	ldp	x29, x30, [sp], #0x20
    b1ac:      	b	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    b1b0:      	stp	x29, x30, [sp, #-0x20]!
    b1b4:      	str	x19, [sp, #0x10]
    b1b8:      	mov	x29, sp
    b1bc:      	mov	x19, x0
    b1c0:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    b1c4:      	add	x8, x8, #0x3b0
    b1c8:      	str	x8, [x0]
    b1cc:      	bl	0xb258 <_Z20MTARMPMMusicGetSpeedPv+0x55c>
    b1d0:      	mov	x0, x19
    b1d4:      	bl	0xb2b4 <_Z20MTARMPMMusicGetSpeedPv+0x5b8>
    b1d8:      	ldr	x0, [x19, #0x210]
    b1dc:      	add	x9, x19, #0x1f0
    b1e0:      	cmp	x0, x9
    b1e4:      	b.eq	0xb1f4 <_Z20MTARMPMMusicGetSpeedPv+0x4f8>
    b1e8:      	cbz	x0, 0xb208 <_Z20MTARMPMMusicGetSpeedPv+0x50c>
    b1ec:      	mov	w8, #0x5                // =5
    b1f0:      	b	0xb1fc <_Z20MTARMPMMusicGetSpeedPv+0x500>
    b1f4:      	mov	w8, #0x4                // =4
    b1f8:      	mov	x0, x9
    b1fc:      	ldr	x9, [x0]
    b200:      	ldr	x8, [x9, x8, lsl #3]
    b204:      	blr	x8
    b208:      	add	x0, x19, #0x1a8
    b20c:      	bl	0x16bf0 <_ZNSt6__ndk118condition_variableD1Ev@plt>
    b210:      	add	x0, x19, #0x180
    b214:      	bl	0x16c00 <_ZNSt6__ndk15mutexD1Ev@plt>
    b218:      	add	x0, x19, #0xa0
    b21c:      	bl	0xb160 <_Z20MTARMPMMusicGetSpeedPv+0x464>
    b220:      	add	x0, x19, #0x70
    b224:      	bl	0x16bf0 <_ZNSt6__ndk118condition_variableD1Ev@plt>
    b228:      	add	x0, x19, #0x48
    b22c:      	bl	0x16c00 <_ZNSt6__ndk15mutexD1Ev@plt>
    b230:      	ldrb	w8, [x19, #0x8]
    b234:      	tbnz	w8, #0x0, 0xb244 <_Z20MTARMPMMusicGetSpeedPv+0x548>
    b238:      	ldr	x19, [sp, #0x10]
    b23c:      	ldp	x29, x30, [sp], #0x20
    b240:      	ret
    b244:      	ldr	x0, [x19, #0x18]
    b248:      	ldr	x19, [sp, #0x10]
    b24c:      	ldp	x29, x30, [sp], #0x20
    b250:      	b	0x16b60 <_ZdlPv@plt>
    b254:      	bl	0xad14 <_Z20MTARMPMMusicGetSpeedPv+0x18>
    b258:      	stp	x29, x30, [sp, #-0x20]!
    b25c:      	stp	x20, x19, [sp, #0x10]
    b260:      	mov	x29, sp
    b264:      	mov	x20, x0
    b268:      	ldr	x8, [x20, #0xa0]!
    b26c:      	cbz	x8, 0xb2a8 <_Z20MTARMPMMusicGetSpeedPv+0x5ac>
    b270:      	mov	x19, x0
    b274:      	add	x0, x0, #0x48
    b278:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    b27c:      	mov	w8, #0x1                // =1
    b280:      	add	x0, x19, #0x70
    b284:      	strb	w8, [x19, #0xd8]
    b288:      	bl	0x16c20 <_ZNSt6__ndk118condition_variable10notify_allEv@plt>
    b28c:      	add	x0, x19, #0x48
    b290:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    b294:      	ldr	x0, [x19, #0xa0]
    b298:      	bl	0x16c40 <_ZNSt6__ndk16thread4joinEv@plt>
    b29c:      	mov	x0, x20
    b2a0:      	bl	0xbacc <_Z20MTARMPMMusicGetSpeedPv+0xdd0>
    b2a4:      	strb	wzr, [x19, #0xd8]
    b2a8:      	ldp	x20, x19, [sp, #0x10]
    b2ac:      	ldp	x29, x30, [sp], #0x20
    b2b0:      	ret
    b2b4:      	stp	x29, x30, [sp, #-0x20]!
    b2b8:      	stp	x20, x19, [sp, #0x10]
    b2bc:      	mov	x29, sp
    b2c0:      	ldr	x8, [x0, #0x130]
    b2c4:      	mov	x19, x0
    b2c8:      	cbz	x8, 0xb2d8 <_Z20MTARMPMMusicGetSpeedPv+0x5dc>
    b2cc:      	add	x0, x19, #0x130
    b2d0:      	bl	0x16c50 <swr_free@plt>
    b2d4:      	str	xzr, [x19, #0x130]
    b2d8:      	ldr	x8, [x19, #0x168]
    b2dc:      	cbz	x8, 0xb300 <_Z20MTARMPMMusicGetSpeedPv+0x604>
    b2e0:      	add	x20, x19, #0x48
    b2e4:      	mov	x0, x20
    b2e8:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    b2ec:      	ldr	x0, [x19, #0x168]
    b2f0:      	bl	0x16c60 <avcodec_close@plt>
    b2f4:      	mov	x0, x20
    b2f8:      	str	xzr, [x19, #0x168]
    b2fc:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    b300:      	mov	x20, x19
    b304:      	ldr	x8, [x20, #0xe0]!
    b308:      	cbz	x8, 0xb318 <_Z20MTARMPMMusicGetSpeedPv+0x61c>
    b30c:      	mov	x0, x20
    b310:      	bl	0x16c70 <avformat_close_input@plt>
    b314:      	str	xzr, [x20]
    b318:      	add	x20, x19, #0x48
    b31c:      	mov	x0, x20
    b320:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    b324:      	ldr	x0, [x19, #0x40]
    b328:      	cbz	x0, 0xb334 <_Z20MTARMPMMusicGetSpeedPv+0x638>
    b32c:      	bl	0x1258c <_Z20MTARMPMMusicGetSpeedPv+0x7890>
    b330:      	str	xzr, [x19, #0x40]
    b334:      	mov	x0, x20
    b338:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    b33c:      	ldr	x8, [x19, #0x110]
    b340:      	cbz	x8, 0xb34c <_Z20MTARMPMMusicGetSpeedPv+0x650>
    b344:      	add	x0, x19, #0x110
    b348:      	bl	0x16c80 <av_freep@plt>
    b34c:      	str	wzr, [x19, #0x11c]
    b350:      	str	wzr, [x19, #0x1d8]
    b354:      	ldp	x20, x19, [sp, #0x10]
    b358:      	ldp	x29, x30, [sp], #0x20
    b35c:      	ret
    b360:      	b	0xb364 <_Z20MTARMPMMusicGetSpeedPv+0x668>
    b364:      	mov	x19, x0
    b368:      	mov	x0, x20
    b36c:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    b370:      	mov	x0, x19
    b374:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    b378:      	stp	x29, x30, [sp, #-0x20]!
    b37c:      	str	x19, [sp, #0x10]
    b380:      	mov	x29, sp
    b384:      	mov	x19, x0
    b388:      	bl	0xb1b0 <_Z20MTARMPMMusicGetSpeedPv+0x4b4>
    b38c:      	mov	x0, x19
    b390:      	ldr	x19, [sp, #0x10]
    b394:      	ldp	x29, x30, [sp], #0x20
    b398:      	b	0x16b60 <_ZdlPv@plt>
    b39c:      	sub	sp, sp, #0xd0
    b3a0:      	stp	x29, x30, [sp, #0x90]
    b3a4:      	str	x23, [sp, #0xa0]
    b3a8:      	stp	x22, x21, [sp, #0xb0]
    b3ac:      	stp	x20, x19, [sp, #0xc0]
    b3b0:      	add	x29, sp, #0x90
    b3b4:      	mrs	x23, TPIDR_EL0
    b3b8:      	mov	x19, x0
    b3bc:      	ldr	x8, [x23, #0x28]
    b3c0:      	stur	x8, [x29, #-0x8]
    b3c4:      	strb	w1, [x0, #0x20]
    b3c8:      	bl	0x16c90 <avformat_alloc_context@plt>
    b3cc:      	str	x0, [sp]
    b3d0:      	cbz	x0, 0xb468 <_Z20MTARMPMMusicGetSpeedPv+0x76c>
    b3d4:      	nop
    b3d8:      	adr	x8, 0xb69c <_Z20MTARMPMMusicGetSpeedPv+0x9a0>
    b3dc:      	add	x22, x19, #0x9
    b3e0:      	stp	x8, x19, [x0, #0xd8]
    b3e4:      	ldr	x2, [x19, #0xd0]
    b3e8:      	mov	x0, sp
    b3ec:      	ldrb	w8, [x19, #0x8]
    b3f0:      	ldr	x9, [x19, #0x18]
    b3f4:      	mov	x3, xzr
    b3f8:      	tst	w8, #0x1
    b3fc:      	csel	x1, x22, x9, eq
    b400:      	bl	0x16ca0 <avformat_open_input@plt>
    b404:      	tbnz	w0, #0x1f, 0xb480 <_Z20MTARMPMMusicGetSpeedPv+0x784>
    b408:      	movi	v0.2d, #0xffffffffffffffff
    b40c:      	ldr	x0, [sp]
    b410:      	mov	x8, #-0x1               // =-1
    b414:      	str	x8, [x19, #0x158]
    b418:      	add	x8, x19, #0x138
    b41c:      	str	x0, [x19, #0xe0]
    b420:      	stp	q0, q0, [x8]
    b424:      	bl	0x16cb0 <av_format_inject_global_side_data@plt>
    b428:      	ldr	x0, [x19, #0xe0]
    b42c:      	mov	x1, xzr
    b430:      	bl	0x16cc0 <avformat_find_stream_info@plt>
    b434:      	tbnz	w0, #0x1f, 0xb4d4 <_Z20MTARMPMMusicGetSpeedPv+0x7d8>
    b438:      	ldr	x20, [x19, #0xe0]
    b43c:      	ldr	x8, [x20, #0x20]
    b440:      	cbz	x8, 0xb448 <_Z20MTARMPMMusicGetSpeedPv+0x74c>
    b444:      	str	wzr, [x8, #0x50]
    b448:      	adrp	x21, 0x1f000
    b44c:      	ldr	w8, [x21, #0xdc8]
    b450:      	tbz	w8, #0x1f, 0xb51c <_Z20MTARMPMMusicGetSpeedPv+0x820>
    b454:      	ldr	x8, [x20, #0x8]
    b458:      	ldrb	w9, [x8, #0x11]
    b45c:      	tbnz	w9, #0x1, 0xb500 <_Z20MTARMPMMusicGetSpeedPv+0x804>
    b460:      	mov	w8, wzr
    b464:      	b	0xb518 <_Z20MTARMPMMusicGetSpeedPv+0x81c>
    b468:      	nop
    b46c:      	adr	x2, 0x560f
    b470:      	mov	w1, #0x8                // =8
    b474:      	bl	0x16cd0 <av_log@plt>
    b478:      	mov	w20, #-0xc              // =-12
    b47c:      	b	0xb654 <_Z20MTARMPMMusicGetSpeedPv+0x958>
    b480:      	ldrb	w8, [x19, #0x8]
    b484:      	ldr	x9, [x19, #0x18]
    b488:      	add	x1, sp, #0x8
    b48c:      	mov	w2, #0x80               // =128
    b490:      	mov	w21, w0
    b494:      	tst	w8, #0x1
    b498:      	csel	x20, x22, x9, eq
    b49c:      	add	x22, sp, #0x8
    b4a0:      	bl	0x16ce0 <av_strerror@plt>
    b4a4:      	tbz	w0, #0x1f, 0xb4b4 <_Z20MTARMPMMusicGetSpeedPv+0x7b8>
    b4a8:      	neg	w0, w21
    b4ac:      	bl	0x16cf0 <strerror@plt>
    b4b0:      	mov	x22, x0
    b4b4:      	adrp	x2, 0x4000
    b4b8:      	add	x2, x2, #0xe44
    b4bc:      	mov	x0, xzr
    b4c0:      	mov	w1, #0x10               // =16
    b4c4:      	mov	x3, x20
    b4c8:      	mov	x4, x22
    b4cc:      	bl	0x16cd0 <av_log@plt>
    b4d0:      	b	0xb4f8 <_Z20MTARMPMMusicGetSpeedPv+0x7fc>
    b4d4:      	ldrb	w8, [x19, #0x8]
    b4d8:      	ldr	x9, [x19, #0x18]
    b4dc:      	adrp	x2, 0x4000
    b4e0:      	add	x2, x2, #0x598
    b4e4:      	mov	x0, xzr
    b4e8:      	mov	w1, #0x18               // =24
    b4ec:      	tst	w8, #0x1
    b4f0:      	csel	x3, x22, x9, eq
    b4f4:      	bl	0x16cd0 <av_log@plt>
    b4f8:      	mov	w20, #-0x1              // =-1
    b4fc:      	b	0xb654 <_Z20MTARMPMMusicGetSpeedPv+0x958>
    b500:      	ldr	x1, [x8]
    b504:      	adrp	x0, 0x5000
    b508:      	add	x0, x0, #0xa10
    b50c:      	bl	0x16d00 <strcmp@plt>
    b510:      	cmp	w0, #0x0
    b514:      	cset	w8, ne
    b518:      	str	w8, [x21, #0xdc8]
    b51c:      	ldr	x8, [x19, #0x178]
    b520:      	mov	x9, #-0x8000000000000000 // =-9223372036854775808
    b524:      	cmp	x8, x9
    b528:      	b.eq	0xb594 <_Z20MTARMPMMusicGetSpeedPv+0x898>
    b52c:      	ldr	x10, [x20, #0x60]
    b530:      	mov	w11, #0x3e8             // =1000
    b534:      	mov	x0, x20
    b538:      	mov	w1, #-0x1               // =-1
    b53c:      	mov	x2, #-0x8000000000000000 // =-9223372036854775808
    b540:      	mov	x4, #0x7fffffffffffffff // =9223372036854775807
    b544:      	cmp	x10, x9
    b548:      	mov	w5, wzr
    b54c:      	csel	x9, xzr, x10, eq
    b550:      	madd	x21, x8, x11, x9
    b554:      	mov	x3, x21
    b558:      	bl	0x16d10 <avformat_seek_file@plt>
    b55c:      	tbz	w0, #0x1f, 0xb594 <_Z20MTARMPMMusicGetSpeedPv+0x898>
    b560:      	scvtf	d0, x21
    b564:      	adrp	x8, 0x5000
    b568:      	ldr	x9, [x19, #0x18]
    b56c:      	ldr	d1, [x8, #0xee8]
    b570:      	ldrb	w8, [x19, #0x8]
    b574:      	adrp	x2, 0x4000
    b578:      	add	x2, x2, #0x7f2
    b57c:      	mov	x0, xzr
    b580:      	mov	w1, #0x18               // =24
    b584:      	tst	w8, #0x1
    b588:      	fdiv	d0, d0, d1
    b58c:      	csel	x3, x22, x9, eq
    b590:      	bl	0x16cd0 <av_log@plt>
    b594:      	ldrb	w8, [x19, #0x8]
    b598:      	ldr	x9, [x19, #0x18]
    b59c:      	mov	w1, wzr
    b5a0:      	ldr	x0, [x19, #0xe0]
    b5a4:      	mov	w3, wzr
    b5a8:      	tst	w8, #0x1
    b5ac:      	csel	x2, x22, x9, eq
    b5b0:      	bl	0x16d20 <av_dump_format@plt>
    b5b4:      	ldr	x0, [x19, #0xe0]
    b5b8:      	ldr	w8, [x0, #0x2c]
    b5bc:      	cbz	w8, 0xb600 <_Z20MTARMPMMusicGetSpeedPv+0x904>
    b5c0:      	ldr	x10, [x0, #0x30]
    b5c4:      	mov	x9, xzr
    b5c8:      	mov	w11, #0x30              // =48
    b5cc:      	ldr	x12, [x10, x9, lsl #3]
    b5d0:      	ldr	x13, [x12, #0x10]
    b5d4:      	str	w11, [x12, #0x44]
    b5d8:      	ldr	w12, [x19, #0x13c]
    b5dc:      	ldr	w13, [x13]
    b5e0:      	cmp	w13, #0x1
    b5e4:      	ccmn	w12, #0x1, #0x0, eq
    b5e8:      	b.ne	0xb5f4 <_Z20MTARMPMMusicGetSpeedPv+0x8f8>
    b5ec:      	str	w9, [x19, #0x13c]
    b5f0:      	ldr	w8, [x0, #0x2c]
    b5f4:      	add	x9, x9, #0x1
    b5f8:      	cmp	x9, x8
    b5fc:      	b.lo	0xb5cc <_Z20MTARMPMMusicGetSpeedPv+0x8d0>
    b600:      	mov	w8, #0x138              // =312
    b604:      	mov	w9, #0x7fffffff         // =2147483647
    b608:      	ldr	w10, [x19, x8]
    b60c:      	cmn	w10, #0x1
    b610:      	b.ne	0xb618 <_Z20MTARMPMMusicGetSpeedPv+0x91c>
    b614:      	str	w9, [x19, x8]
    b618:      	add	x8, x8, #0x4
    b61c:      	cmp	x8, #0x14c
    b620:      	b.ne	0xb608 <_Z20MTARMPMMusicGetSpeedPv+0x90c>
    b624:      	ldr	w2, [x19, #0x13c]
    b628:      	ldr	w3, [x19, #0x138]
    b62c:      	mov	w1, #0x1                // =1
    b630:      	mov	x4, xzr
    b634:      	mov	w5, wzr
    b638:      	bl	0x16d30 <av_find_best_stream@plt>
    b63c:      	str	w0, [x19, #0x13c]
    b640:      	tbnz	w0, #0x1f, 0xb650 <_Z20MTARMPMMusicGetSpeedPv+0x954>
    b644:      	mov	w1, w0
    b648:      	mov	x0, x19
    b64c:      	bl	0xb6a4 <_Z20MTARMPMMusicGetSpeedPv+0x9a8>
    b650:      	mov	w20, wzr
    b654:      	ldr	x8, [sp]
    b658:      	cbz	x8, 0xb66c <_Z20MTARMPMMusicGetSpeedPv+0x970>
    b65c:      	ldr	x8, [x19, #0xe0]
    b660:      	cbnz	x8, 0xb66c <_Z20MTARMPMMusicGetSpeedPv+0x970>
    b664:      	mov	x0, sp
    b668:      	bl	0x16c70 <avformat_close_input@plt>
    b66c:      	ldr	x8, [x23, #0x28]
    b670:      	ldur	x9, [x29, #-0x8]
    b674:      	cmp	x8, x9
    b678:      	b.ne	0xb698 <_Z20MTARMPMMusicGetSpeedPv+0x99c>
    b67c:      	mov	w0, w20
    b680:      	ldp	x20, x19, [sp, #0xc0]
    b684:      	ldr	x23, [sp, #0xa0]
    b688:      	ldp	x22, x21, [sp, #0xb0]
    b68c:      	ldp	x29, x30, [sp, #0x90]
    b690:      	add	sp, sp, #0xd0
    b694:      	ret
    b698:      	bl	0x16b40 <__stack_chk_fail@plt>
    b69c:      	ldrb	w0, [x0, #0xd8]
    b6a0:      	ret
    b6a4:      	sub	sp, sp, #0x90
    b6a8:      	stp	x29, x30, [sp, #0x40]
    b6ac:      	stp	x26, x25, [sp, #0x50]
    b6b0:      	stp	x24, x23, [sp, #0x60]
    b6b4:      	stp	x22, x21, [sp, #0x70]
    b6b8:      	stp	x20, x19, [sp, #0x80]
    b6bc:      	add	x29, sp, #0x40
    b6c0:      	mrs	x24, TPIDR_EL0
    b6c4:      	ldr	x8, [x24, #0x28]
    b6c8:      	stur	x8, [x29, #-0x8]
    b6cc:      	ldr	x25, [x0, #0xe0]
    b6d0:      	stur	xzr, [x29, #-0x10]
    b6d4:      	tbnz	w1, #0x1f, 0xb9ac <_Z20MTARMPMMusicGetSpeedPv+0xcb0>
    b6d8:      	ldr	w8, [x25, #0x2c]
    b6dc:      	mov	w21, w1
    b6e0:      	cmp	w8, w1
    b6e4:      	b.ls	0xb9ac <_Z20MTARMPMMusicGetSpeedPv+0xcb0>
    b6e8:      	ldr	x8, [x25, #0x30]
    b6ec:      	mov	x19, x0
    b6f0:      	mov	x0, xzr
    b6f4:      	ldr	x8, [x8, w21, uxtw #3]
    b6f8:      	ldr	x20, [x8, #0x10]
    b6fc:      	bl	0x16d40 <avcodec_alloc_context3@plt>
    b700:      	mov	x1, x20
    b704:      	mov	x22, x0
    b708:      	stur	x0, [x29, #-0x18]
    b70c:      	bl	0x16d50 <avcodec_parameters_to_context@plt>
    b710:      	tbnz	w0, #0x1f, 0xb974 <_Z20MTARMPMMusicGetSpeedPv+0xc78>
    b714:      	ldr	w0, [x22, #0x18]
    b718:      	bl	0x16d60 <avcodec_find_decoder@plt>
    b71c:      	cbz	x0, 0xb98c <_Z20MTARMPMMusicGetSpeedPv+0xc90>
    b720:      	ldr	w8, [x0, #0x14]
    b724:      	mov	x20, x0
    b728:      	adrp	x1, 0x4000
    b72c:      	add	x1, x1, #0x89e
    b730:      	mov	x0, x22
    b734:      	mov	x2, xzr
    b738:      	mov	w3, #0x1                // =1
    b73c:      	str	w8, [x22, #0x18]
    b740:      	bl	0x16d70 <av_opt_set_int@plt>
    b744:      	adrp	x1, 0x4000
    b748:      	add	x1, x1, #0xc59
    b74c:      	mov	x0, xzr
    b750:      	mov	x2, xzr
    b754:      	mov	w3, wzr
    b758:      	bl	0x16d80 <av_dict_get@plt>
    b75c:      	cbnz	x0, 0xb77c <_Z20MTARMPMMusicGetSpeedPv+0xa80>
    b760:      	adrp	x1, 0x4000
    b764:      	add	x1, x1, #0xc59
    b768:      	adrp	x2, 0x4000
    b76c:      	add	x2, x2, #0x817
    b770:      	sub	x0, x29, #0x10
    b774:      	mov	w3, wzr
    b778:      	bl	0x16d90 <av_dict_set@plt>
    b77c:      	ldr	w8, [x22, #0xc]
    b780:      	cmp	w8, #0x1
    b784:      	b.hi	0xb7a4 <_Z20MTARMPMMusicGetSpeedPv+0xaa8>
    b788:      	adrp	x1, 0x5000
    b78c:      	add	x1, x1, #0x431
    b790:      	adrp	x2, 0x5000
    b794:      	add	x2, x2, #0x3cb
    b798:      	sub	x0, x29, #0x10
    b79c:      	mov	w3, wzr
    b7a0:      	bl	0x16d90 <av_dict_set@plt>
    b7a4:      	sub	x2, x29, #0x10
    b7a8:      	mov	x0, x22
    b7ac:      	mov	x1, x20
    b7b0:      	bl	0x16da0 <avcodec_open2@plt>
    b7b4:      	mov	w20, w0
    b7b8:      	tbnz	w0, #0x1f, 0xb960 <_Z20MTARMPMMusicGetSpeedPv+0xc64>
    b7bc:      	str	wzr, [x19, #0x160]
    b7c0:      	ldr	x8, [x25, #0x30]
    b7c4:      	ldr	x8, [x8, w21, uxtw #3]
    b7c8:      	str	wzr, [x8, #0x44]
    b7cc:      	ldr	w8, [x22, #0xc]
    b7d0:      	cmp	w8, #0x1
    b7d4:      	b.ne	0xb968 <_Z20MTARMPMMusicGetSpeedPv+0xc6c>
    b7d8:      	ldr	w8, [x22, #0x160]
    b7dc:      	ldr	w26, [x22, #0x158]
    b7e0:      	ldr	w23, [x22, #0x164]
    b7e4:      	cmp	w8, #0x1
    b7e8:      	b.eq	0xb7f8 <_Z20MTARMPMMusicGetSpeedPv+0xafc>
    b7ec:      	add	x0, sp, #0x10
    b7f0:      	mov	w1, w23
    b7f4:      	bl	0x16db0 <av_channel_layout_default@plt>
    b7f8:      	ldr	w1, [x19, #0x3c]
    b7fc:      	add	x0, sp, #0x10
    b800:      	stp	w23, w26, [x19, #0x28]
    b804:      	str	w20, [x19, #0x100]
    b808:      	str	w1, [x19, #0xb4]
    b80c:      	bl	0x16db0 <av_channel_layout_default@plt>
    b810:      	ldr	x8, [sp, #0x18]
    b814:      	ldr	w23, [x19, #0x38]
    b818:      	mov	w9, #0x1                // =1
    b81c:      	str	w9, [x19, #0xc0]
    b820:      	mov	x2, #0x1                // =1
    b824:      	str	x8, [x19, #0xb8]
    b828:      	movk	x2, #0x4240, lsl #32
    b82c:      	str	w23, [x19, #0xb0]
    b830:      	movk	x2, #0xf, lsl #48
    b834:      	str	wzr, [x19, #0x118]
    b838:      	str	wzr, [x19, #0x120]
    b83c:      	str	w21, [x19, #0xe8]
    b840:      	ldr	x8, [x25, #0x30]
    b844:      	ldr	x8, [x8, w21, uxtw #3]
    b848:      	str	x8, [x19, #0xf0]
    b84c:      	ldr	x0, [x8, #0x30]
    b850:      	ldr	x1, [x8, #0x20]
    b854:      	bl	0x16dc0 <av_rescale_q@plt>
    b858:      	mov	x8, #0xf7cf             // =63439
    b85c:      	str	x22, [x19, #0x168]
    b860:      	movk	x8, #0xe353, lsl #16
    b864:      	movk	x8, #0x9ba5, lsl #32
    b868:      	movk	x8, #0x20c4, lsl #48
    b86c:      	smulh	x8, x0, x8
    b870:      	ldr	x0, [x19, #0x40]
    b874:      	asr	x9, x8, #7
    b878:      	add	x8, x9, x8, lsr #63
    b87c:      	str	x8, [x19, #0xf8]
    b880:      	cbz	x0, 0xb890 <_Z20MTARMPMMusicGetSpeedPv+0xb94>
    b884:      	bl	0x1258c <_Z20MTARMPMMusicGetSpeedPv+0x7890>
    b888:      	ldr	w23, [x19, #0x38]
    b88c:      	str	xzr, [x19, #0x40]
    b890:      	ldr	w1, [x19, #0x3c]
    b894:      	mov	x0, xzr
    b898:      	mov	w2, w23
    b89c:      	mov	w3, #0x1                // =1
    b8a0:      	mov	w4, wzr
    b8a4:      	bl	0x16dd0 <av_samples_get_buffer_size@plt>
    b8a8:      	bl	0x12298 <_Z20MTARMPMMusicGetSpeedPv+0x759c>
    b8ac:      	str	x0, [x19, #0x40]
    b8b0:      	mov	w0, #0x20               // =32
    b8b4:      	bl	0x16b50 <_Znwm@plt>
    b8b8:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    b8bc:      	mov	x21, x0
    b8c0:      	ldr	x8, [x8, #0x940]
    b8c4:      	stp	xzr, xzr, [x0, #0x8]
    b8c8:      	add	x8, x8, #0x10
    b8cc:      	str	x8, [x0]
    b8d0:      	mov	w0, #0x8                // =8
    b8d4:      	bl	0x16b50 <_Znwm@plt>
    b8d8:      	mov	x22, x0
    b8dc:      	bl	0x16de0 <_ZNSt6__ndk115__thread_structC1Ev@plt>
    b8e0:      	mov	w0, #0x10               // =16
    b8e4:      	bl	0x16b50 <_Znwm@plt>
    b8e8:      	stp	x22, x19, [x0]
    b8ec:      	add	x22, x21, #0x18
    b8f0:      	mov	x3, x0
    b8f4:      	str	x0, [sp]
    b8f8:      	nop
    b8fc:      	adr	x2, 0xccdc <_Z20MTARMPMMusicGetSpeedPv+0x1fe0>
    b900:      	mov	x0, x22
    b904:      	mov	x1, xzr
    b908:      	bl	0x16df0 <pthread_create@plt>
    b90c:      	cbnz	w0, 0xb9e0 <_Z20MTARMPMMusicGetSpeedPv+0xce4>
    b910:      	mov	x0, sp
    b914:      	str	xzr, [sp]
    b918:      	bl	0xcd70 <_Z20MTARMPMMusicGetSpeedPv+0x2074>
    b91c:      	add	x0, x19, #0xa0
    b920:      	mov	x1, sp
    b924:      	stp	x22, x21, [sp]
    b928:      	bl	0xc79c <_Z20MTARMPMMusicGetSpeedPv+0x1aa0>
    b92c:      	ldr	x19, [sp, #0x8]
    b930:      	cbz	x19, 0xb968 <_Z20MTARMPMMusicGetSpeedPv+0xc6c>
    b934:      	add	x1, x19, #0x8
    b938:      	mov	x0, #-0x1               // =-1
    b93c:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    b940:      	cbnz	x0, 0xb968 <_Z20MTARMPMMusicGetSpeedPv+0xc6c>
    b944:      	ldr	x8, [x19]
    b948:      	mov	x0, x19
    b94c:      	ldr	x8, [x8, #0x10]
    b950:      	blr	x8
    b954:      	mov	x0, x19
    b958:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    b95c:      	b	0xb968 <_Z20MTARMPMMusicGetSpeedPv+0xc6c>
    b960:      	sub	x0, x29, #0x18
    b964:      	bl	0x16e00 <avcodec_free_context@plt>
    b968:      	sub	x0, x29, #0x10
    b96c:      	bl	0x16e10 <av_dict_free@plt>
    b970:      	b	0xb9b0 <_Z20MTARMPMMusicGetSpeedPv+0xcb4>
    b974:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    b978:      	adrp	x0, 0x5000
    b97c:      	add	x0, x0, #0xb9a
    b980:      	ldr	x8, [x8, #0x948]
    b984:      	mov	w1, #0x33               // =51
    b988:      	b	0xb9a0 <_Z20MTARMPMMusicGetSpeedPv+0xca4>
    b98c:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    b990:      	adrp	x0, 0x5000
    b994:      	add	x0, x0, #0x4f9
    b998:      	ldr	x8, [x8, #0x948]
    b99c:      	mov	w1, #0x10               // =16
    b9a0:      	ldr	x3, [x8]
    b9a4:      	mov	w2, #0x1                // =1
    b9a8:      	bl	0x16e20 <fwrite@plt>
    b9ac:      	mov	w20, #-0x1              // =-1
    b9b0:      	ldr	x8, [x24, #0x28]
    b9b4:      	ldur	x9, [x29, #-0x8]
    b9b8:      	cmp	x8, x9
    b9bc:      	b.ne	0xba58 <_Z20MTARMPMMusicGetSpeedPv+0xd5c>
    b9c0:      	mov	w0, w20
    b9c4:      	ldp	x20, x19, [sp, #0x80]
    b9c8:      	ldp	x22, x21, [sp, #0x70]
    b9cc:      	ldp	x24, x23, [sp, #0x60]
    b9d0:      	ldp	x26, x25, [sp, #0x50]
    b9d4:      	ldp	x29, x30, [sp, #0x40]
    b9d8:      	add	sp, sp, #0x90
    b9dc:      	ret
    b9e0:      	ldr	x8, [x24, #0x28]
    b9e4:      	ldur	x9, [x29, #-0x8]
    b9e8:      	cmp	x8, x9
    b9ec:      	b.ne	0xba58 <_Z20MTARMPMMusicGetSpeedPv+0xd5c>
    b9f0:      	adrp	x1, 0x4000
    b9f4:      	add	x1, x1, #0xadf
    b9f8:      	bl	0x16e30 <_ZNSt6__ndk120__throw_system_errorEiPKc@plt>
    b9fc:      	mov	x19, x0
    ba00:      	mov	x0, x22
    ba04:      	bl	0x16e40 <_ZNSt6__ndk115__thread_structD1Ev@plt>
    ba08:      	b	0xba10 <_Z20MTARMPMMusicGetSpeedPv+0xd14>
    ba0c:      	mov	x19, x0
    ba10:      	mov	x0, x22
    ba14:      	bl	0x16b60 <_ZdlPv@plt>
    ba18:      	b	0xba30 <_Z20MTARMPMMusicGetSpeedPv+0xd34>
    ba1c:      	mov	x19, x0
    ba20:      	b	0xba30 <_Z20MTARMPMMusicGetSpeedPv+0xd34>
    ba24:      	mov	x19, x0
    ba28:      	mov	x0, sp
    ba2c:      	bl	0xcd70 <_Z20MTARMPMMusicGetSpeedPv+0x2074>
    ba30:      	mov	x0, x21
    ba34:      	bl	0x16e50 <_ZNSt6__ndk119__shared_weak_countD2Ev@plt>
    ba38:      	mov	x0, x21
    ba3c:      	bl	0x16b60 <_ZdlPv@plt>
    ba40:      	ldr	x8, [x24, #0x28]
    ba44:      	ldur	x9, [x29, #-0x8]
    ba48:      	cmp	x8, x9
    ba4c:      	b.ne	0xba58 <_Z20MTARMPMMusicGetSpeedPv+0xd5c>
    ba50:      	mov	x0, x19
    ba54:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    ba58:      	bl	0x16b40 <__stack_chk_fail@plt>
    ba5c:      	stp	x29, x30, [sp, #-0x20]!
    ba60:      	str	x19, [sp, #0x10]
    ba64:      	mov	x29, sp
    ba68:      	mov	x19, x0
    ba6c:      	add	x0, x0, #0x48
    ba70:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    ba74:      	mov	w8, #0x1                // =1
    ba78:      	add	x0, x19, #0x70
    ba7c:      	strb	w8, [x19, #0x174]
    ba80:      	bl	0x16c20 <_ZNSt6__ndk118condition_variable10notify_allEv@plt>
    ba84:      	add	x0, x19, #0x48
    ba88:      	ldr	x19, [sp, #0x10]
    ba8c:      	ldp	x29, x30, [sp], #0x20
    ba90:      	b	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    ba94:      	stp	x29, x30, [sp, #-0x20]!
    ba98:      	stp	x20, x19, [sp, #0x10]
    ba9c:      	mov	x29, sp
    baa0:      	mov	x20, x0
    baa4:      	add	x0, x0, #0x48
    baa8:      	mov	w19, w1
    baac:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    bab0:      	add	x0, x20, #0x70
    bab4:      	strb	w19, [x20, #0x20]
    bab8:      	bl	0x16c20 <_ZNSt6__ndk118condition_variable10notify_allEv@plt>
    babc:      	add	x0, x20, #0x48
    bac0:      	ldp	x20, x19, [sp, #0x10]
    bac4:      	ldp	x29, x30, [sp], #0x20
    bac8:      	b	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    bacc:      	stp	x29, x30, [sp, #-0x20]!
    bad0:      	str	x19, [sp, #0x10]
    bad4:      	mov	x29, sp
    bad8:      	ldr	x19, [x0, #0x8]
    badc:      	stp	xzr, xzr, [x0]
    bae0:      	cbz	x19, 0xbaf4 <_Z20MTARMPMMusicGetSpeedPv+0xdf8>
    bae4:      	add	x1, x19, #0x8
    bae8:      	mov	x0, #-0x1               // =-1
    baec:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    baf0:      	cbz	x0, 0xbb00 <_Z20MTARMPMMusicGetSpeedPv+0xe04>
    baf4:      	ldr	x19, [sp, #0x10]
    baf8:      	ldp	x29, x30, [sp], #0x20
    bafc:      	ret
    bb00:      	ldr	x8, [x19]
    bb04:      	mov	x0, x19
    bb08:      	ldr	x8, [x8, #0x10]
    bb0c:      	blr	x8
    bb10:      	mov	x0, x19
    bb14:      	ldr	x19, [sp, #0x10]
    bb18:      	ldp	x29, x30, [sp], #0x20
    bb1c:      	b	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    bb20:      	sub	sp, sp, #0x80
    bb24:      	stp	x29, x30, [sp, #0x30]
    bb28:      	str	x25, [sp, #0x40]
    bb2c:      	stp	x24, x23, [sp, #0x50]
    bb30:      	stp	x22, x21, [sp, #0x60]
    bb34:      	stp	x20, x19, [sp, #0x70]
    bb38:      	add	x29, sp, #0x30
    bb3c:      	mrs	x25, TPIDR_EL0
    bb40:      	mov	x20, x0
    bb44:      	add	x0, x0, #0x48
    bb48:      	ldr	x8, [x25, #0x28]
    bb4c:      	mov	x21, x2
    bb50:      	mov	w19, w1
    bb54:      	stur	x8, [x29, #-0x8]
    bb58:      	mov	w8, #0x1                // =1
    bb5c:      	str	x0, [sp, #0x18]
    bb60:      	strb	w8, [sp, #0x20]
    bb64:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    bb68:      	ldr	x0, [x20, #0x40]
    bb6c:      	cbz	x0, 0xbb80 <_Z20MTARMPMMusicGetSpeedPv+0xe84>
    bb70:      	ldrb	w8, [x20, #0x174]
    bb74:      	cbz	w8, 0xbb88 <_Z20MTARMPMMusicGetSpeedPv+0xe8c>
    bb78:      	mov	w19, wzr
    bb7c:      	b	0xbd44 <_Z20MTARMPMMusicGetSpeedPv+0x1048>
    bb80:      	mov	w19, wzr
    bb84:      	b	0xbd4c <_Z20MTARMPMMusicGetSpeedPv+0x1050>
    bb88:      	ldr	w8, [x20, #0x160]
    bb8c:      	cbz	w8, 0xbba0 <_Z20MTARMPMMusicGetSpeedPv+0xea4>
    bb90:      	bl	0x12564 <_Z20MTARMPMMusicGetSpeedPv+0x7868>
    bb94:      	cmp	w0, w19
    bb98:      	b.le	0xbc60 <_Z20MTARMPMMusicGetSpeedPv+0xf64>
    bb9c:      	ldrb	w8, [x20, #0x174]
    bba0:      	ldrb	w9, [x20, #0xd8]
    bba4:      	mov	w22, w19
    bba8:      	cbnz	w9, 0xbca4 <_Z20MTARMPMMusicGetSpeedPv+0xfa8>
    bbac:      	mov	w22, w19
    bbb0:      	cbnz	w8, 0xbca4 <_Z20MTARMPMMusicGetSpeedPv+0xfa8>
    bbb4:      	mov	x23, x21
    bbb8:      	mov	w22, w19
    bbbc:      	ldr	x0, [x20, #0x40]
    bbc0:      	mov	x1, x23
    bbc4:      	mov	w2, w22
    bbc8:      	bl	0x12304 <_Z20MTARMPMMusicGetSpeedPv+0x7608>
    bbcc:      	mov	w24, w0
    bbd0:      	add	x0, x20, #0x70
    bbd4:      	bl	0x16e60 <_ZNSt6__ndk118condition_variable10notify_oneEv@plt>
    bbd8:      	subs	w22, w22, w24
    bbdc:      	b.le	0xbc98 <_Z20MTARMPMMusicGetSpeedPv+0xf9c>
    bbe0:      	ldrb	w8, [x20, #0xd8]
    bbe4:      	cbnz	w8, 0xbc30 <_Z20MTARMPMMusicGetSpeedPv+0xf34>
    bbe8:      	ldr	x0, [x20, #0x40]
    bbec:      	cbz	x0, 0xbc0c <_Z20MTARMPMMusicGetSpeedPv+0xf10>
    bbf0:      	bl	0x12564 <_Z20MTARMPMMusicGetSpeedPv+0x7868>
    bbf4:      	cmp	w0, #0x0
    bbf8:      	b.gt	0xbc30 <_Z20MTARMPMMusicGetSpeedPv+0xf34>
    bbfc:      	ldr	w8, [x20, #0x160]
    bc00:      	cmp	w8, #0x1
    bc04:      	b.ne	0xbc18 <_Z20MTARMPMMusicGetSpeedPv+0xf1c>
    bc08:      	b	0xbc30 <_Z20MTARMPMMusicGetSpeedPv+0xf34>
    bc0c:      	ldr	w8, [x20, #0x160]
    bc10:      	cmp	w8, #0x1
    bc14:      	b.eq	0xbca4 <_Z20MTARMPMMusicGetSpeedPv+0xfa8>
    bc18:      	ldrb	w8, [x20, #0x174]
    bc1c:      	cbnz	w8, 0xbc30 <_Z20MTARMPMMusicGetSpeedPv+0xf34>
    bc20:      	add	x0, x20, #0x70
    bc24:      	add	x1, sp, #0x18
    bc28:      	bl	0x16e70 <_ZNSt6__ndk118condition_variable4waitERNS_11unique_lockINS_5mutexEEE@plt>
    bc2c:      	b	0xbbe0 <_Z20MTARMPMMusicGetSpeedPv+0xee4>
    bc30:      	ldr	x0, [x20, #0x40]
    bc34:      	cbz	x0, 0xbca4 <_Z20MTARMPMMusicGetSpeedPv+0xfa8>
    bc38:      	ldr	w8, [x20, #0x160]
    bc3c:      	cbz	w8, 0xbc48 <_Z20MTARMPMMusicGetSpeedPv+0xf4c>
    bc40:      	bl	0x12564 <_Z20MTARMPMMusicGetSpeedPv+0x7868>
    bc44:      	cbz	w0, 0xbca4 <_Z20MTARMPMMusicGetSpeedPv+0xfa8>
    bc48:      	ldrb	w8, [x20, #0xd8]
    bc4c:      	ldrb	w9, [x20, #0x174]
    bc50:      	add	x23, x23, w24, sxtw
    bc54:      	orr	w8, w8, w9
    bc58:      	cbz	w8, 0xbbbc <_Z20MTARMPMMusicGetSpeedPv+0xec0>
    bc5c:      	b	0xbca4 <_Z20MTARMPMMusicGetSpeedPv+0xfa8>
    bc60:      	sxtw	x2, w19
    bc64:      	mov	x0, x21
    bc68:      	mov	w1, wzr
    bc6c:      	bl	0x16e80 <memset@plt>
    bc70:      	ldr	x0, [x20, #0x40]
    bc74:      	mov	x1, x21
    bc78:      	mov	w2, w19
    bc7c:      	bl	0x12304 <_Z20MTARMPMMusicGetSpeedPv+0x7608>
    bc80:      	mov	w19, w0
    bc84:      	ldr	s0, [x20, #0x128]
    bc88:      	mov	x0, x21
    bc8c:      	mov	w1, w19
    bc90:      	bl	0x11c24 <_Z20MTARMPMMusicGetSpeedPv+0x6f28>
    bc94:      	b	0xbd44 <_Z20MTARMPMMusicGetSpeedPv+0x1048>
    bc98:      	ldr	w8, [x20, #0x170]
    bc9c:      	add	w8, w8, w19
    bca0:      	str	w8, [x20, #0x170]
    bca4:      	ldr	s0, [x20, #0x128]
    bca8:      	mov	x0, x21
    bcac:      	mov	w1, w19
    bcb0:      	bl	0x11c24 <_Z20MTARMPMMusicGetSpeedPv+0x6f28>
    bcb4:      	ldrb	w8, [x20, #0x220]
    bcb8:      	cbnz	w8, 0xbcfc <_Z20MTARMPMMusicGetSpeedPv+0x1000>
    bcbc:      	mov	w8, #0x1                // =1
    bcc0:      	strb	w8, [x20, #0x220]
    bcc4:      	adrp	x1, 0x4000
    bcc8:      	add	x1, x1, #0x7ea
    bccc:      	mov	x0, sp
    bcd0:      	bl	0xa90c <_Z16MTARMPMMusicLoadPvPKc+0x1a4>
    bcd4:      	ldr	x0, [x20, #0x210]
    bcd8:      	cbz	x0, 0xbd84 <_Z20MTARMPMMusicGetSpeedPv+0x1088>
    bcdc:      	ldr	x8, [x0]
    bce0:      	ldr	x8, [x8, #0x30]
    bce4:      	mov	x1, sp
    bce8:      	blr	x8
    bcec:      	ldrb	w8, [sp]
    bcf0:      	tbz	w8, #0x0, 0xbcfc <_Z20MTARMPMMusicGetSpeedPv+0x1000>
    bcf4:      	ldr	x0, [sp, #0x10]
    bcf8:      	bl	0x16b60 <_ZdlPv@plt>
    bcfc:      	ldrb	w8, [x20, #0x174]
    bd00:      	cbnz	w8, 0xbd44 <_Z20MTARMPMMusicGetSpeedPv+0x1048>
    bd04:      	ldrb	w8, [x20, #0xd8]
    bd08:      	sub	w21, w19, w22
    bd0c:      	cmp	w8, #0x0
    bd10:      	csinv	w19, w21, wzr, eq
    bd14:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    bd18:      	cmp	w0, #0x3
    bd1c:      	b.gt	0xbd44 <_Z20MTARMPMMusicGetSpeedPv+0x1048>
    bd20:      	ldrb	w4, [x20, #0xd8]
    bd24:      	ldr	w5, [x20, #0x170]
    bd28:      	adrp	x1, 0x5000
    bd2c:      	add	x1, x1, #0x2f1
    bd30:      	adrp	x2, 0x4000
    bd34:      	add	x2, x2, #0xf63
    bd38:      	mov	w0, #0x4                // =4
    bd3c:      	mov	w3, w21
    bd40:      	bl	0x16e90 <__android_log_print@plt>
    bd44:      	ldrb	w8, [sp, #0x20]
    bd48:      	cbz	w8, 0xbd54 <_Z20MTARMPMMusicGetSpeedPv+0x1058>
    bd4c:      	ldr	x0, [sp, #0x18]
    bd50:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    bd54:      	ldr	x8, [x25, #0x28]
    bd58:      	ldur	x9, [x29, #-0x8]
    bd5c:      	cmp	x8, x9
    bd60:      	b.ne	0xbdf0 <_Z20MTARMPMMusicGetSpeedPv+0x10f4>
    bd64:      	mov	w0, w19
    bd68:      	ldp	x20, x19, [sp, #0x70]
    bd6c:      	ldr	x25, [sp, #0x40]
    bd70:      	ldp	x22, x21, [sp, #0x60]
    bd74:      	ldp	x24, x23, [sp, #0x50]
    bd78:      	ldp	x29, x30, [sp, #0x30]
    bd7c:      	add	sp, sp, #0x80
    bd80:      	ret
    bd84:      	ldr	x8, [x25, #0x28]
    bd88:      	ldur	x9, [x29, #-0x8]
    bd8c:      	cmp	x8, x9
    bd90:      	b.ne	0xbdf0 <_Z20MTARMPMMusicGetSpeedPv+0x10f4>
    bd94:      	bl	0xcad8 <_Z20MTARMPMMusicGetSpeedPv+0x1ddc>
    bd98:      	b	0xbdc4 <_Z20MTARMPMMusicGetSpeedPv+0x10c8>
    bd9c:      	b	0xbdc4 <_Z20MTARMPMMusicGetSpeedPv+0x10c8>
    bda0:      	ldrb	w8, [sp]
    bda4:      	mov	x19, x0
    bda8:      	tbz	w8, #0x0, 0xbdc8 <_Z20MTARMPMMusicGetSpeedPv+0x10cc>
    bdac:      	ldr	x0, [sp, #0x10]
    bdb0:      	bl	0x16b60 <_ZdlPv@plt>
    bdb4:      	b	0xbdc8 <_Z20MTARMPMMusicGetSpeedPv+0x10cc>
    bdb8:      	b	0xbdc4 <_Z20MTARMPMMusicGetSpeedPv+0x10c8>
    bdbc:      	b	0xbdc4 <_Z20MTARMPMMusicGetSpeedPv+0x10c8>
    bdc0:      	b	0xbdc4 <_Z20MTARMPMMusicGetSpeedPv+0x10c8>
    bdc4:      	mov	x19, x0
    bdc8:      	ldrb	w8, [sp, #0x20]
    bdcc:      	cbz	w8, 0xbdd8 <_Z20MTARMPMMusicGetSpeedPv+0x10dc>
    bdd0:      	ldr	x0, [sp, #0x18]
    bdd4:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    bdd8:      	ldr	x8, [x25, #0x28]
    bddc:      	ldur	x9, [x29, #-0x8]
    bde0:      	cmp	x8, x9
    bde4:      	b.ne	0xbdf0 <_Z20MTARMPMMusicGetSpeedPv+0x10f4>
    bde8:      	mov	x0, x19
    bdec:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    bdf0:      	bl	0x16b40 <__stack_chk_fail@plt>
    bdf4:      	sub	sp, sp, #0xc0
    bdf8:      	stp	x29, x30, [sp, #0x70]
    bdfc:      	stp	x26, x25, [sp, #0x80]
    be00:      	stp	x24, x23, [sp, #0x90]
    be04:      	stp	x22, x21, [sp, #0xa0]
    be08:      	stp	x20, x19, [sp, #0xb0]
    be0c:      	add	x29, sp, #0x70
    be10:      	mrs	x26, TPIDR_EL0
    be14:      	mov	w20, w6
    be18:      	mov	w25, w5
    be1c:      	ldr	x8, [x26, #0x28]
    be20:      	mov	x24, x4
    be24:      	mov	x19, x0
    be28:      	mov	w21, w3
    be2c:      	mov	w23, w2
    be30:      	mov	x22, x1
    be34:      	stur	x8, [x29, #-0x8]
    be38:      	ldr	x8, [x0, #0x130]
    be3c:      	cbz	x8, 0xbe48 <_Z20MTARMPMMusicGetSpeedPv+0x114c>
    be40:      	add	x0, x19, #0x130
    be44:      	bl	0x16c50 <swr_free@plt>
    be48:      	sub	x0, x29, #0x20
    be4c:      	mov	x1, x22
    be50:      	bl	0x16ea0 <av_channel_layout_from_mask@plt>
    be54:      	add	x0, sp, #0x38
    be58:      	mov	x1, x24
    be5c:      	bl	0x16ea0 <av_channel_layout_from_mask@plt>
    be60:      	add	x0, x19, #0x130
    be64:      	sub	x1, x29, #0x20
    be68:      	add	x4, sp, #0x38
    be6c:      	mov	w2, w23
    be70:      	mov	w3, w21
    be74:      	mov	w5, w25
    be78:      	mov	w6, w20
    be7c:      	mov	w7, wzr
    be80:      	str	xzr, [sp]
    be84:      	bl	0x16eb0 <swr_alloc_set_opts2@plt>
    be88:      	tbnz	w0, #0x1f, 0xbe9c <_Z20MTARMPMMusicGetSpeedPv+0x11a0>
    be8c:      	ldr	x0, [x19, #0x130]
    be90:      	cbz	x0, 0xbe9c <_Z20MTARMPMMusicGetSpeedPv+0x11a0>
    be94:      	bl	0x16ec0 <swr_init@plt>
    be98:      	tbz	w0, #0x1f, 0xbf50 <_Z20MTARMPMMusicGetSpeedPv+0x1254>
    be9c:      	mov	w0, w25
    bea0:      	bl	0x16ed0 <av_get_sample_fmt_name@plt>
    bea4:      	mov	x25, x0
    bea8:      	add	x8, sp, #0x20
    beac:      	mov	x0, x24
    beb0:      	add	x24, sp, #0x20
    beb4:      	bl	0xbfcc <_Z20MTARMPMMusicGetSpeedPv+0x12d0>
    beb8:      	ldrb	w8, [sp, #0x20]
    bebc:      	ldr	x9, [sp, #0x30]
    bec0:      	orr	x10, x24, #0x1
    bec4:      	tst	w8, #0x1
    bec8:      	csel	x24, x10, x9, eq
    becc:      	mov	w0, w23
    bed0:      	bl	0x16ed0 <av_get_sample_fmt_name@plt>
    bed4:      	mov	x23, x0
    bed8:      	add	x8, sp, #0x8
    bedc:      	mov	x0, x22
    bee0:      	add	x22, sp, #0x8
    bee4:      	bl	0xbfcc <_Z20MTARMPMMusicGetSpeedPv+0x12d0>
    bee8:      	ldrb	w8, [sp, #0x8]
    beec:      	ldr	x9, [sp, #0x18]
    bef0:      	orr	x10, x22, #0x1
    bef4:      	tst	w8, #0x1
    bef8:      	csel	x8, x10, x9, eq
    befc:      	adrp	x2, 0x5000
    bf00:      	add	x2, x2, #0x8b5
    bf04:      	mov	x0, xzr
    bf08:      	mov	w1, #0x10               // =16
    bf0c:      	mov	w3, w20
    bf10:      	mov	x4, x25
    bf14:      	mov	x5, x24
    bf18:      	mov	w6, w21
    bf1c:      	mov	x7, x23
    bf20:      	str	x8, [sp]
    bf24:      	bl	0x16cd0 <av_log@plt>
    bf28:      	ldrb	w8, [sp, #0x8]
    bf2c:      	tbz	w8, #0x0, 0xbf38 <_Z20MTARMPMMusicGetSpeedPv+0x123c>
    bf30:      	ldr	x0, [sp, #0x18]
    bf34:      	bl	0x16b60 <_ZdlPv@plt>
    bf38:      	ldrb	w8, [sp, #0x20]
    bf3c:      	tbz	w8, #0x0, 0xbf48 <_Z20MTARMPMMusicGetSpeedPv+0x124c>
    bf40:      	ldr	x0, [sp, #0x30]
    bf44:      	bl	0x16b60 <_ZdlPv@plt>
    bf48:      	add	x0, x19, #0x130
    bf4c:      	bl	0x16c50 <swr_free@plt>
    bf50:      	ldr	x8, [x26, #0x28]
    bf54:      	ldur	x9, [x29, #-0x8]
    bf58:      	cmp	x8, x9
    bf5c:      	b.ne	0xbfc8 <_Z20MTARMPMMusicGetSpeedPv+0x12cc>
    bf60:      	mov	w0, wzr
    bf64:      	ldp	x20, x19, [sp, #0xb0]
    bf68:      	ldp	x22, x21, [sp, #0xa0]
    bf6c:      	ldp	x24, x23, [sp, #0x90]
    bf70:      	ldp	x26, x25, [sp, #0x80]
    bf74:      	ldp	x29, x30, [sp, #0x70]
    bf78:      	add	sp, sp, #0xc0
    bf7c:      	ret
    bf80:      	ldrb	w8, [sp, #0x8]
    bf84:      	mov	x19, x0
    bf88:      	tbz	w8, #0x0, 0xbfa0 <_Z20MTARMPMMusicGetSpeedPv+0x12a4>
    bf8c:      	ldr	x0, [sp, #0x18]
    bf90:      	bl	0x16b60 <_ZdlPv@plt>
    bf94:      	b	0xbfa0 <_Z20MTARMPMMusicGetSpeedPv+0x12a4>
    bf98:      	b	0xbf9c <_Z20MTARMPMMusicGetSpeedPv+0x12a0>
    bf9c:      	mov	x19, x0
    bfa0:      	ldrb	w8, [sp, #0x20]
    bfa4:      	tbz	w8, #0x0, 0xbfb0 <_Z20MTARMPMMusicGetSpeedPv+0x12b4>
    bfa8:      	ldr	x0, [sp, #0x30]
    bfac:      	bl	0x16b60 <_ZdlPv@plt>
    bfb0:      	ldr	x8, [x26, #0x28]
    bfb4:      	ldur	x9, [x29, #-0x8]
    bfb8:      	cmp	x8, x9
    bfbc:      	b.ne	0xbfc8 <_Z20MTARMPMMusicGetSpeedPv+0x12cc>
    bfc0:      	mov	x0, x19
    bfc4:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    bfc8:      	bl	0x16b40 <__stack_chk_fail@plt>
    bfcc:      	sub	sp, sp, #0x150
    bfd0:      	stp	x29, x30, [sp, #0x110]
    bfd4:      	str	x28, [sp, #0x120]
    bfd8:      	stp	x22, x21, [sp, #0x130]
    bfdc:      	stp	x20, x19, [sp, #0x140]
    bfe0:      	add	x29, sp, #0x110
    bfe4:      	mrs	x21, TPIDR_EL0
    bfe8:      	mov	x19, x8
    bfec:      	mov	x20, x0
    bff0:      	ldr	x8, [x21, #0x28]
    bff4:      	mov	x0, sp
    bff8:      	mov	x22, sp
    bffc:      	stur	x8, [x29, #-0x8]
    c000:      	bl	0xcb30 <_Z20MTARMPMMusicGetSpeedPv+0x1e34>
    c004:      	mov	x0, sp
    c008:      	mov	x1, x20
    c00c:      	bl	0x16ee0 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEElsEl@plt>
    c010:      	add	x0, x22, #0x8
    c014:      	mov	x8, x19
    c018:      	bl	0x16ef0 <_ZNKSt6__ndk115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strEv@plt>
    c01c:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
    c020:      	mov	x20, sp
    c024:      	ldr	x19, [x19, #0x958]
    c028:      	ldr	x8, [x19]
    c02c:      	ldr	x9, [x19, #0x18]
    c030:      	str	x8, [sp]
    c034:      	ldur	x8, [x8, #-0x18]
    c038:      	str	x9, [x20, x8]
    c03c:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    c040:      	ldr	x8, [x8, #0x960]
    c044:      	ldrb	w9, [sp, #0x48]
    c048:      	add	x8, x8, #0x10
    c04c:      	str	x8, [sp, #0x8]
    c050:      	tbz	w9, #0x0, 0xc05c <_Z20MTARMPMMusicGetSpeedPv+0x1360>
    c054:      	ldr	x0, [sp, #0x58]
    c058:      	bl	0x16b60 <_ZdlPv@plt>
    c05c:      	add	x0, x22, #0x8
    c060:      	bl	0x16f00 <_ZNSt6__ndk115basic_streambufIcNS_11char_traitsIcEEED2Ev@plt>
    c064:      	mov	x0, sp
    c068:      	add	x1, x19, #0x8
    c06c:      	bl	0x16f10 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEED2Ev@plt>
    c070:      	add	x0, x20, #0x70
    c074:      	bl	0x16f20 <_ZNSt6__ndk19basic_iosIcNS_11char_traitsIcEEED2Ev@plt>
    c078:      	ldr	x8, [x21, #0x28]
    c07c:      	ldur	x9, [x29, #-0x8]
    c080:      	cmp	x8, x9
    c084:      	b.ne	0xc0c4 <_Z20MTARMPMMusicGetSpeedPv+0x13c8>
    c088:      	ldp	x20, x19, [sp, #0x140]
    c08c:      	ldr	x28, [sp, #0x120]
    c090:      	ldp	x22, x21, [sp, #0x130]
    c094:      	ldp	x29, x30, [sp, #0x110]
    c098:      	add	sp, sp, #0x150
    c09c:      	ret
    c0a0:      	mov	x19, x0
    c0a4:      	mov	x0, sp
    c0a8:      	bl	0xcc0c <_Z20MTARMPMMusicGetSpeedPv+0x1f10>
    c0ac:      	ldr	x8, [x21, #0x28]
    c0b0:      	ldur	x9, [x29, #-0x8]
    c0b4:      	cmp	x8, x9
    c0b8:      	b.ne	0xc0c4 <_Z20MTARMPMMusicGetSpeedPv+0x13c8>
    c0bc:      	mov	x0, x19
    c0c0:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    c0c4:      	bl	0x16b40 <__stack_chk_fail@plt>
    c0c8:      	stp	x29, x30, [sp, #-0x40]!
    c0cc:      	str	x23, [sp, #0x10]
    c0d0:      	stp	x22, x21, [sp, #0x20]
    c0d4:      	stp	x20, x19, [sp, #0x30]
    c0d8:      	mov	x29, sp
    c0dc:      	mov	w21, w2
    c0e0:      	mov	x22, x1
    c0e4:      	mov	x23, x0
    c0e8:      	sxtw	x2, w21
    c0ec:      	add	x1, x0, #0x11c
    c0f0:      	mov	x0, x22
    c0f4:      	mov	w19, w4
    c0f8:      	mov	x20, x3
    c0fc:      	bl	0x16f30 <av_fast_malloc@plt>
    c100:      	ldr	x8, [x22]
    c104:      	cbz	x8, 0xc140 <_Z20MTARMPMMusicGetSpeedPv+0x1444>
    c108:      	ldr	x0, [x23, #0x130]
    c10c:      	mov	x1, x22
    c110:      	mov	w2, w21
    c114:      	mov	x3, x20
    c118:      	mov	w4, w19
    c11c:      	bl	0x16f40 <swr_convert@plt>
    c120:      	mov	w19, w0
    c124:      	tbz	w0, #0x1f, 0xc144 <_Z20MTARMPMMusicGetSpeedPv+0x1448>
    c128:      	adrp	x2, 0x5000
    c12c:      	add	x2, x2, #0xc97
    c130:      	mov	x0, xzr
    c134:      	mov	w1, #0x10               // =16
    c138:      	bl	0x16cd0 <av_log@plt>
    c13c:      	b	0xc144 <_Z20MTARMPMMusicGetSpeedPv+0x1448>
    c140:      	mov	w19, #-0xc              // =-12
    c144:      	mov	w0, w19
    c148:      	ldp	x20, x19, [sp, #0x30]
    c14c:      	ldr	x23, [sp, #0x10]
    c150:      	ldp	x22, x21, [sp, #0x20]
    c154:      	ldp	x29, x30, [sp], #0x40
    c158:      	ret
    c15c:      	sub	sp, sp, #0x120
    c160:      	str	d8, [sp, #0xb0]
    c164:      	stp	x29, x30, [sp, #0xc0]
    c168:      	stp	x28, x27, [sp, #0xd0]
    c16c:      	stp	x26, x25, [sp, #0xe0]
    c170:      	stp	x24, x23, [sp, #0xf0]
    c174:      	stp	x22, x21, [sp, #0x100]
    c178:      	stp	x20, x19, [sp, #0x110]
    c17c:      	add	x29, sp, #0xc0
    c180:      	movi	v0.2d, #0000000000000000
    c184:      	mrs	x22, TPIDR_EL0
    c188:      	mov	x19, x0
    c18c:      	ldr	x8, [x22, #0x28]
    c190:      	add	x0, sp, #0x10
    c194:      	stur	x8, [x29, #-0x20]
    c198:      	str	xzr, [sp, #0x70]
    c19c:      	stp	q0, q0, [sp, #0x10]
    c1a0:      	stp	q0, q0, [sp, #0x30]
    c1a4:      	stp	q0, q0, [sp, #0x50]
    c1a8:      	bl	0x16f60 <av_init_packet@plt>
    c1ac:      	bl	0x16f70 <av_frame_alloc@plt>
    c1b0:      	stur	x0, [x29, #-0x40]
    c1b4:      	cbz	x0, 0xc6d0 <_Z20MTARMPMMusicGetSpeedPv+0x19d4>
    c1b8:      	ldrb	w8, [x19, #0xd8]
    c1bc:      	cbz	w8, 0xc20c <_Z20MTARMPMMusicGetSpeedPv+0x1510>
    c1c0:      	add	x0, x19, #0x48
    c1c4:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    c1c8:      	mov	w8, #0x1                // =1
    c1cc:      	add	x0, x19, #0x70
    c1d0:      	str	w8, [x19, #0x160]
    c1d4:      	bl	0x16e60 <_ZNSt6__ndk118condition_variable10notify_oneEv@plt>
    c1d8:      	add	x0, x19, #0x48
    c1dc:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    c1e0:      	add	x0, x19, #0x180
    c1e4:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    c1e8:      	ldrb	w8, [x19, #0x175]
    c1ec:      	cbz	w8, 0xc1f8 <_Z20MTARMPMMusicGetSpeedPv+0x14fc>
    c1f0:      	strb	wzr, [x19, #0x175]
    c1f4:      	str	xzr, [x19, #0x178]
    c1f8:      	add	x0, x19, #0x1a8
    c1fc:      	bl	0x16c20 <_ZNSt6__ndk118condition_variable10notify_allEv@plt>
    c200:      	add	x0, x19, #0x180
    c204:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    c208:      	b	0xc6d0 <_Z20MTARMPMMusicGetSpeedPv+0x19d4>
    c20c:      	add	x8, x19, #0x9
    c210:      	mov	x20, x0
    c214:      	add	x21, x19, #0x48
    c218:      	str	x8, [sp]
    c21c:      	adrp	x8, 0x5000
    c220:      	mov	w23, #0x1               // =1
    c224:      	ldr	d8, [x8, #0xee8]
    c228:      	mov	x24, #-0x8000000000000000 // =-9223372036854775808
    c22c:      	str	x22, [sp, #0x8]
    c230:      	ldrb	w8, [x19, #0x175]
    c234:      	cbz	w8, 0xc2f4 <_Z20MTARMPMMusicGetSpeedPv+0x15f8>
    c238:      	ldr	x8, [x19, #0x178]
    c23c:      	cmp	x8, x24
    c240:      	b.eq	0xc2d8 <_Z20MTARMPMMusicGetSpeedPv+0x15dc>
    c244:      	mov	w9, #0x3e8              // =1000
    c248:      	mov	x1, #0x1                // =1
    c24c:      	mul	x0, x8, x9
    c250:      	ldr	x8, [x19, #0xf0]
    c254:      	movk	x1, #0x4240, lsl #32
    c258:      	movk	x1, #0xf, lsl #48
    c25c:      	ldr	x2, [x8, #0x20]
    c260:      	bl	0x16dc0 <av_rescale_q@plt>
    c264:      	mov	x25, x0
    c268:      	mov	x0, x21
    c26c:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    c270:      	ldr	x0, [x19, #0x40]
    c274:      	bl	0x12574 <_Z20MTARMPMMusicGetSpeedPv+0x7878>
    c278:      	ldr	x0, [x19, #0xe0]
    c27c:      	ldr	w1, [x19, #0xe8]
    c280:      	str	wzr, [x19, #0x160]
    c284:      	str	wzr, [x19, #0x170]
    c288:      	mov	x2, x25
    c28c:      	mov	w3, #0x4                // =4
    c290:      	bl	0x16f80 <av_seek_frame@plt>
    c294:      	tbz	w0, #0x1f, 0xc2c8 <_Z20MTARMPMMusicGetSpeedPv+0x15cc>
    c298:      	scvtf	d0, x25
    c29c:      	ldrb	w8, [x19, #0x8]
    c2a0:      	ldr	x9, [x19, #0x18]
    c2a4:      	tst	w8, #0x1
    c2a8:      	ldr	x8, [sp]
    c2ac:      	fdiv	d0, d0, d8
    c2b0:      	csel	x3, x8, x9, eq
    c2b4:      	mov	x0, xzr
    c2b8:      	mov	w1, #0x18               // =24
    c2bc:      	adrp	x2, 0x4000
    c2c0:      	add	x2, x2, #0x7f2
    c2c4:      	bl	0x16cd0 <av_log@plt>
    c2c8:      	ldr	x0, [x19, #0x168]
    c2cc:      	bl	0x16f90 <avcodec_flush_buffers@plt>
    c2d0:      	mov	x0, x21
    c2d4:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    c2d8:      	add	x0, x19, #0x180
    c2dc:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    c2e0:      	add	x0, x19, #0x1a8
    c2e4:      	strb	wzr, [x19, #0x175]
    c2e8:      	bl	0x16e60 <_ZNSt6__ndk118condition_variable10notify_oneEv@plt>
    c2ec:      	add	x0, x19, #0x180
    c2f0:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    c2f4:      	ldr	x0, [x19, #0xe0]
    c2f8:      	add	x1, sp, #0x10
    c2fc:      	bl	0x16f50 <av_read_frame@plt>
    c300:      	tbz	w0, #0x1f, 0xc35c <_Z20MTARMPMMusicGetSpeedPv+0x1660>
    c304:      	mov	w8, #0xa7bb             // =42939
    c308:      	movk	w8, #0xabb6, lsl #16
    c30c:      	cmp	w0, w8
    c310:      	b.eq	0xc1c0 <_Z20MTARMPMMusicGetSpeedPv+0x14c4>
    c314:      	ldrb	w8, [x19, #0xd8]
    c318:      	cbnz	w8, 0xc1c0 <_Z20MTARMPMMusicGetSpeedPv+0x14c4>
    c31c:      	ldrb	w8, [x19, #0x20]
    c320:      	cbz	w8, 0xc644 <_Z20MTARMPMMusicGetSpeedPv+0x1948>
    c324:      	ldr	x0, [x19, #0xe0]
    c328:      	mov	w1, #-0x1               // =-1
    c32c:      	mov	x2, #-0x8000000000000000 // =-9223372036854775808
    c330:      	mov	x3, xzr
    c334:      	mov	x4, #0x7fffffffffffffff // =9223372036854775807
    c338:      	mov	w5, wzr
    c33c:      	bl	0x16d10 <avformat_seek_file@plt>
    c340:      	ldr	w8, [x19, #0x1d8]
    c344:      	ldr	x0, [x19, #0xe0]
    c348:      	add	x1, sp, #0x10
    c34c:      	add	w8, w8, #0x1
    c350:      	str	w8, [x19, #0x1d8]
    c354:      	bl	0x16f50 <av_read_frame@plt>
    c358:      	tbnz	w0, #0x1f, 0xc1c0 <_Z20MTARMPMMusicGetSpeedPv+0x14c4>
    c35c:      	ldr	w8, [sp, #0x34]
    c360:      	ldr	w9, [x19, #0xe8]
    c364:      	cmp	w8, w9
    c368:      	b.ne	0xc630 <_Z20MTARMPMMusicGetSpeedPv+0x1934>
    c36c:      	ldr	x0, [x19, #0x168]
    c370:      	ldr	x22, [sp, #0x28]
    c374:      	add	x1, sp, #0x10
    c378:      	ldr	w24, [sp, #0x30]
    c37c:      	bl	0x16fa0 <avcodec_send_packet@plt>
    c380:      	tbnz	w0, #0x1f, 0xc73c <_Z20MTARMPMMusicGetSpeedPv+0x1a40>
    c384:      	ldr	x0, [x19, #0x168]
    c388:      	mov	x1, x20
    c38c:      	bl	0x16fb0 <avcodec_receive_frame@plt>
    c390:      	mov	w8, #0xb0bb             // =45243
    c394:      	movk	w8, #0xdfb9, lsl #16
    c398:      	cmp	w0, w8
    c39c:      	b.eq	0xc620 <_Z20MTARMPMMusicGetSpeedPv+0x1924>
    c3a0:      	mov	w26, w0
    c3a4:      	cmn	w0, #0xb
    c3a8:      	b.eq	0xc620 <_Z20MTARMPMMusicGetSpeedPv+0x1924>
    c3ac:      	tbnz	w26, #0x1f, 0xc710 <_Z20MTARMPMMusicGetSpeedPv+0x1a14>
    c3b0:      	ldr	w1, [x20, #0x70]
    c3b4:      	adrp	x0, 0x4000
    c3b8:      	add	x0, x0, #0xbc0
    c3bc:      	bl	0x16fc0 <printf@plt>
    c3c0:      	ldp	w2, w3, [x20, #0x70]
    c3c4:      	ldr	w1, [x20, #0x19c]
    c3c8:      	mov	x0, xzr
    c3cc:      	mov	w4, #0x1                // =1
    c3d0:      	bl	0x16dd0 <av_samples_get_buffer_size@plt>
    c3d4:      	ldr	w8, [x20, #0x198]
    c3d8:      	mov	w27, w0
    c3dc:      	cmp	w8, #0x1
    c3e0:      	b.ne	0xc3ec <_Z20MTARMPMMusicGetSpeedPv+0x16f0>
    c3e4:      	ldr	x25, [x20, #0x1a0]
    c3e8:      	b	0xc3fc <_Z20MTARMPMMusicGetSpeedPv+0x1700>
    c3ec:      	ldr	w1, [x20, #0x19c]
    c3f0:      	sub	x0, x29, #0x38
    c3f4:      	bl	0x16db0 <av_channel_layout_default@plt>
    c3f8:      	ldur	x25, [x29, #-0x30]
    c3fc:      	ldp	w28, w8, [x20, #0x70]
    c400:      	ldr	w9, [x19, #0xc0]
    c404:      	cmp	w8, w9
    c408:      	b.ne	0xc428 <_Z20MTARMPMMusicGetSpeedPv+0x172c>
    c40c:      	ldr	x8, [x19, #0xb8]
    c410:      	cmp	x25, x8
    c414:      	b.ne	0xc428 <_Z20MTARMPMMusicGetSpeedPv+0x172c>
    c418:      	ldr	w8, [x20, #0xc0]
    c41c:      	ldr	w9, [x19, #0xb0]
    c420:      	cmp	w8, w9
    c424:      	b.eq	0xc474 <_Z20MTARMPMMusicGetSpeedPv+0x1778>
    c428:      	ldr	w1, [x19, #0x3c]
    c42c:      	sub	x0, x29, #0x38
    c430:      	bl	0x16db0 <av_channel_layout_default@plt>
    c434:      	ldur	x1, [x29, #-0x30]
    c438:      	ldr	w3, [x19, #0x38]
    c43c:      	mov	x0, x19
    c440:      	ldr	w5, [x20, #0x74]
    c444:      	ldr	w6, [x20, #0xc0]
    c448:      	mov	w2, #0x1                // =1
    c44c:      	mov	x4, x25
    c450:      	bl	0xbdf4 <_Z20MTARMPMMusicGetSpeedPv+0x10f8>
    c454:      	str	x25, [x19, #0xb8]
    c458:      	mov	w26, wzr
    c45c:      	ldr	w8, [x20, #0x19c]
    c460:      	str	w8, [x19, #0xb4]
    c464:      	ldr	w8, [x20, #0xc0]
    c468:      	str	w8, [x19, #0xb0]
    c46c:      	ldr	w9, [x20, #0x74]
    c470:      	str	w9, [x19, #0xc0]
    c474:      	ldr	x9, [x19, #0x130]
    c478:      	cbz	x9, 0xc55c <_Z20MTARMPMMusicGetSpeedPv+0x1860>
    c47c:      	ldp	w10, w1, [x19, #0x38]
    c480:      	sxtw	x9, w28
    c484:      	sxtw	x8, w8
    c488:      	ldr	x26, [x20, #0x60]
    c48c:      	sxtw	x10, w10
    c490:      	mov	x0, xzr
    c494:      	mov	w3, #0x1                // =1
    c498:      	mov	w4, wzr
    c49c:      	smull	x9, w10, w9
    c4a0:      	sdiv	x8, x9, x8
    c4a4:      	add	w27, w8, #0x100
    c4a8:      	mov	w2, w27
    c4ac:      	bl	0x16dd0 <av_samples_get_buffer_size@plt>
    c4b0:      	tbnz	w0, #0x1f, 0xc6a0 <_Z20MTARMPMMusicGetSpeedPv+0x19a4>
    c4b4:      	ldr	w8, [x20, #0x70]
    c4b8:      	mov	w25, w0
    c4bc:      	subs	w8, w28, w8
    c4c0:      	b.eq	0xc4ec <_Z20MTARMPMMusicGetSpeedPv+0x17f0>
    c4c4:      	ldr	w9, [x19, #0x38]
    c4c8:      	ldr	w10, [x20, #0xc0]
    c4cc:      	ldr	x0, [x19, #0x130]
    c4d0:      	mul	w8, w9, w8
    c4d4:      	sdiv	w1, w8, w10
    c4d8:      	mul	w8, w9, w28
    c4dc:      	sdiv	w2, w8, w10
    c4e0:      	bl	0x16fd0 <swr_set_compensation@plt>
    c4e4:      	tbnz	w0, #0x1f, 0xc6b8 <_Z20MTARMPMMusicGetSpeedPv+0x19bc>
    c4e8:      	ldr	w28, [x20, #0x70]
    c4ec:      	add	x1, x19, #0x110
    c4f0:      	mov	x0, x19
    c4f4:      	mov	w2, w25
    c4f8:      	mov	x3, x26
    c4fc:      	mov	w4, w28
    c500:      	bl	0xc0c8 <_Z20MTARMPMMusicGetSpeedPv+0x13cc>
    c504:      	tbnz	w0, #0x1f, 0xc6ac <_Z20MTARMPMMusicGetSpeedPv+0x19b0>
    c508:      	mov	w26, w0
    c50c:      	cmp	w0, w27
    c510:      	b.ne	0xc53c <_Z20MTARMPMMusicGetSpeedPv+0x1840>
    c514:      	mov	x0, xzr
    c518:      	mov	w1, #0x18               // =24
    c51c:      	adrp	x2, 0x5000
    c520:      	add	x2, x2, #0x2b5
    c524:      	bl	0x16cd0 <av_log@plt>
    c528:      	ldr	x0, [x19, #0x130]
    c52c:      	bl	0x16ec0 <swr_init@plt>
    c530:      	tbz	w0, #0x1f, 0xc53c <_Z20MTARMPMMusicGetSpeedPv+0x1840>
    c534:      	add	x0, x19, #0x130
    c538:      	bl	0x16c50 <swr_free@plt>
    c53c:      	ldr	w8, [x19, #0x3c]
    c540:      	ldr	x9, [x19, #0x110]
    c544:      	mov	w0, #0x1                // =1
    c548:      	mul	w25, w8, w26
    c54c:      	str	x9, [x19, #0x108]
    c550:      	bl	0x16fe0 <av_get_bytes_per_sample@plt>
    c554:      	mul	w27, w25, w0
    c558:      	b	0xc564 <_Z20MTARMPMMusicGetSpeedPv+0x1868>
    c55c:      	ldr	x8, [x20]
    c560:      	str	x8, [x19, #0x108]
    c564:      	cmp	w27, #0x1
    c568:      	b.lt	0xc614 <_Z20MTARMPMMusicGetSpeedPv+0x1918>
    c56c:      	ldrb	w8, [x19, #0xd8]
    c570:      	cbnz	w8, 0xc614 <_Z20MTARMPMMusicGetSpeedPv+0x1918>
    c574:      	ldrb	w8, [x19, #0x175]
    c578:      	cbnz	w8, 0xc614 <_Z20MTARMPMMusicGetSpeedPv+0x1918>
    c57c:      	mov	x0, x21
    c580:      	stur	x21, [x29, #-0x38]
    c584:      	sturb	w23, [x29, #-0x30]
    c588:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    c58c:      	ldr	x0, [x19, #0x40]
    c590:      	bl	0x1256c <_Z20MTARMPMMusicGetSpeedPv+0x7870>
    c594:      	cmp	w0, #0x0
    c598:      	b.gt	0xc5c8 <_Z20MTARMPMMusicGetSpeedPv+0x18cc>
    c59c:      	ldrb	w8, [x19, #0xd8]
    c5a0:      	ldrb	w9, [x19, #0x175]
    c5a4:      	orr	w8, w8, w9
    c5a8:      	cbnz	w8, 0xc5c8 <_Z20MTARMPMMusicGetSpeedPv+0x18cc>
    c5ac:      	add	x0, x19, #0x70
    c5b0:      	sub	x1, x29, #0x38
    c5b4:      	bl	0x16e70 <_ZNSt6__ndk118condition_variable4waitERNS_11unique_lockINS_5mutexEEE@plt>
    c5b8:      	ldr	x0, [x19, #0x40]
    c5bc:      	bl	0x1256c <_Z20MTARMPMMusicGetSpeedPv+0x7870>
    c5c0:      	cmp	w0, #0x1
    c5c4:      	b.lt	0xc59c <_Z20MTARMPMMusicGetSpeedPv+0x18a0>
    c5c8:      	ldr	x0, [x19, #0x40]
    c5cc:      	ldr	x1, [x19, #0x108]
    c5d0:      	mov	w2, w27
    c5d4:      	bl	0x123dc <_Z20MTARMPMMusicGetSpeedPv+0x76e0>
    c5d8:      	ldr	x8, [x19, #0x108]
    c5dc:      	ldr	w9, [x19, #0x118]
    c5e0:      	mov	w25, w0
    c5e4:      	add	x8, x8, w0, sxtw
    c5e8:      	sub	w9, w9, w0
    c5ec:      	add	x0, x19, #0x70
    c5f0:      	str	w9, [x19, #0x118]
    c5f4:      	str	x8, [x19, #0x108]
    c5f8:      	bl	0x16e60 <_ZNSt6__ndk118condition_variable10notify_oneEv@plt>
    c5fc:      	ldurb	w8, [x29, #-0x30]
    c600:      	cbz	w8, 0xc60c <_Z20MTARMPMMusicGetSpeedPv+0x1910>
    c604:      	ldur	x0, [x29, #-0x38]
    c608:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    c60c:      	sub	w27, w27, w25
    c610:      	b	0xc564 <_Z20MTARMPMMusicGetSpeedPv+0x1868>
    c614:      	mov	x0, x20
    c618:      	bl	0x16ff0 <av_frame_unref@plt>
    c61c:      	tbz	w26, #0x1f, 0xc384 <_Z20MTARMPMMusicGetSpeedPv+0x1688>
    c620:      	str	x22, [sp, #0x28]
    c624:      	ldr	x22, [sp, #0x8]
    c628:      	str	w24, [sp, #0x30]
    c62c:      	mov	x24, #-0x8000000000000000 // =-9223372036854775808
    c630:      	add	x0, sp, #0x10
    c634:      	bl	0x17000 <av_packet_unref@plt>
    c638:      	ldrb	w8, [x19, #0xd8]
    c63c:      	cbz	w8, 0xc230 <_Z20MTARMPMMusicGetSpeedPv+0x1534>
    c640:      	b	0xc1c0 <_Z20MTARMPMMusicGetSpeedPv+0x14c4>
    c644:      	mov	x0, x21
    c648:      	stur	x21, [x29, #-0x38]
    c64c:      	sturb	w23, [x29, #-0x30]
    c650:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    c654:      	add	x0, x19, #0x70
    c658:      	str	w23, [x19, #0x160]
    c65c:      	bl	0x16e60 <_ZNSt6__ndk118condition_variable10notify_oneEv@plt>
    c660:      	ldrb	w8, [x19, #0xd8]
    c664:      	cbnz	w8, 0xc68c <_Z20MTARMPMMusicGetSpeedPv+0x1990>
    c668:      	ldrb	w9, [x19, #0x175]
    c66c:      	cbnz	w9, 0xc68c <_Z20MTARMPMMusicGetSpeedPv+0x1990>
    c670:      	add	x0, x19, #0x70
    c674:      	sub	x1, x29, #0x38
    c678:      	bl	0x16e70 <_ZNSt6__ndk118condition_variable4waitERNS_11unique_lockINS_5mutexEEE@plt>
    c67c:      	ldrb	w9, [x19, #0x175]
    c680:      	ldrb	w8, [x19, #0xd8]
    c684:      	cbnz	w9, 0xc68c <_Z20MTARMPMMusicGetSpeedPv+0x1990>
    c688:      	cbz	w8, 0xc670 <_Z20MTARMPMMusicGetSpeedPv+0x1974>
    c68c:      	ldurb	w9, [x29, #-0x30]
    c690:      	cbz	w9, 0xc63c <_Z20MTARMPMMusicGetSpeedPv+0x1940>
    c694:      	ldur	x0, [x29, #-0x38]
    c698:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    c69c:      	b	0xc638 <_Z20MTARMPMMusicGetSpeedPv+0x193c>
    c6a0:      	adrp	x2, 0x4000
    c6a4:      	add	x2, x2, #0x645
    c6a8:      	b	0xc6c0 <_Z20MTARMPMMusicGetSpeedPv+0x19c4>
    c6ac:      	adrp	x2, 0x5000
    c6b0:      	add	x2, x2, #0xac2
    c6b4:      	b	0xc6c0 <_Z20MTARMPMMusicGetSpeedPv+0x19c4>
    c6b8:      	adrp	x2, 0x5000
    c6bc:      	add	x2, x2, #0x1c9
    c6c0:      	mov	x0, xzr
    c6c4:      	mov	w1, #0x10               // =16
    c6c8:      	bl	0x16cd0 <av_log@plt>
    c6cc:      	ldr	x22, [sp, #0x8]
    c6d0:      	sub	x0, x29, #0x40
    c6d4:      	bl	0x17010 <av_frame_free@plt>
    c6d8:      	mov	w0, wzr
    c6dc:      	ldr	x8, [x22, #0x28]
    c6e0:      	ldur	x9, [x29, #-0x20]
    c6e4:      	cmp	x8, x9
    c6e8:      	b.ne	0xc798 <_Z20MTARMPMMusicGetSpeedPv+0x1a9c>
    c6ec:      	ldp	x20, x19, [sp, #0x110]
    c6f0:      	ldr	d8, [sp, #0xb0]
    c6f4:      	ldp	x22, x21, [sp, #0x100]
    c6f8:      	ldp	x24, x23, [sp, #0xf0]
    c6fc:      	ldp	x26, x25, [sp, #0xe0]
    c700:      	ldp	x28, x27, [sp, #0xd0]
    c704:      	ldp	x29, x30, [sp, #0xc0]
    c708:      	add	sp, sp, #0x120
    c70c:      	ret
    c710:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    c714:      	adrp	x0, 0x4000
    c718:      	add	x0, x0, #0x978
    c71c:      	ldr	x8, [x8, #0x948]
    c720:      	mov	w1, #0x23               // =35
    c724:      	ldr	x3, [x8]
    c728:      	mov	w2, #0x1                // =1
    c72c:      	bl	0x16e20 <fwrite@plt>
    c730:      	ldr	x22, [sp, #0x8]
    c734:      	mov	w0, #-0x1               // =-1
    c738:      	b	0xc6dc <_Z20MTARMPMMusicGetSpeedPv+0x19e0>
    c73c:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    c740:      	adrp	x0, 0x4000
    c744:      	add	x0, x0, #0x87d
    c748:      	ldr	x8, [x8, #0x948]
    c74c:      	mov	w1, #0x20               // =32
    c750:      	b	0xc724 <_Z20MTARMPMMusicGetSpeedPv+0x1a28>
    c754:      	mov	x19, x0
    c758:      	mov	x0, x21
    c75c:      	b	0xc77c <_Z20MTARMPMMusicGetSpeedPv+0x1a80>
    c760:      	b	0xc768 <_Z20MTARMPMMusicGetSpeedPv+0x1a6c>
    c764:      	b	0xc768 <_Z20MTARMPMMusicGetSpeedPv+0x1a6c>
    c768:      	ldurb	w8, [x29, #-0x30]
    c76c:      	ldr	x22, [sp, #0x8]
    c770:      	mov	x19, x0
    c774:      	cbz	w8, 0xc780 <_Z20MTARMPMMusicGetSpeedPv+0x1a84>
    c778:      	ldur	x0, [x29, #-0x38]
    c77c:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    c780:      	ldr	x8, [x22, #0x28]
    c784:      	ldur	x9, [x29, #-0x20]
    c788:      	cmp	x8, x9
    c78c:      	b.ne	0xc798 <_Z20MTARMPMMusicGetSpeedPv+0x1a9c>
    c790:      	mov	x0, x19
    c794:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    c798:      	bl	0x16b40 <__stack_chk_fail@plt>
    c79c:      	stp	x29, x30, [sp, #-0x20]!
    c7a0:      	stp	x20, x19, [sp, #0x10]
    c7a4:      	mov	x29, sp
    c7a8:      	ldr	q0, [x1]
    c7ac:      	stp	xzr, xzr, [x1]
    c7b0:      	mov	x19, x0
    c7b4:      	ldr	x20, [x0, #0x8]
    c7b8:      	str	q0, [x0]
    c7bc:      	cbz	x20, 0xc7e8 <_Z20MTARMPMMusicGetSpeedPv+0x1aec>
    c7c0:      	add	x1, x20, #0x8
    c7c4:      	mov	x0, #-0x1               // =-1
    c7c8:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    c7cc:      	cbnz	x0, 0xc7e8 <_Z20MTARMPMMusicGetSpeedPv+0x1aec>
    c7d0:      	ldr	x8, [x20]
    c7d4:      	mov	x0, x20
    c7d8:      	ldr	x8, [x8, #0x10]
    c7dc:      	blr	x8
    c7e0:      	mov	x0, x20
    c7e4:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    c7e8:      	mov	x0, x19
    c7ec:      	ldp	x20, x19, [sp, #0x10]
    c7f0:      	ldp	x29, x30, [sp], #0x20
    c7f4:      	ret
    c7f8:      	stp	x29, x30, [sp, #-0x20]!
    c7fc:      	stp	x20, x19, [sp, #0x10]
    c800:      	mov	x29, sp
    c804:      	mov	x19, x0
    c808:      	add	x0, x0, #0x48
    c80c:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    c810:      	ldr	x8, [x19, #0xf8]
    c814:      	cbz	x8, 0xc860 <_Z20MTARMPMMusicGetSpeedPv+0x1b64>
    c818:      	ldr	w9, [x19, #0x38]
    c81c:      	ldr	w10, [x19, #0x170]
    c820:      	lsl	w9, w9, #1
    c824:      	scvtf	d0, w10
    c828:      	ldr	w10, [x19, #0x178]
    c82c:      	scvtf	d1, w9
    c830:      	adrp	x9, 0x5000
    c834:      	fdiv	d0, d0, d1
    c838:      	ldr	d1, [x9, #0xef8]
    c83c:      	fmul	d0, d0, d1
    c840:      	ldr	d1, [x19, #0x1e0]
    c844:      	fmul	d0, d1, d0
    c848:      	fcvtzs	x9, d0
    c84c:      	add	w9, w10, w9
    c850:      	sxtw	x10, w9
    c854:      	sdiv	x10, x10, x8
    c858:      	msub	w20, w10, w8, w9
    c85c:      	b	0xc888 <_Z20MTARMPMMusicGetSpeedPv+0x1b8c>
    c860:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    c864:      	cmp	w0, #0x4
    c868:      	b.gt	0xc884 <_Z20MTARMPMMusicGetSpeedPv+0x1b88>
    c86c:      	adrp	x1, 0x5000
    c870:      	add	x1, x1, #0x2f1
    c874:      	adrp	x2, 0x4000
    c878:      	add	x2, x2, #0x8a5
    c87c:      	mov	w0, #0x5                // =5
    c880:      	bl	0x16e90 <__android_log_print@plt>
    c884:      	mov	w20, wzr
    c888:      	add	x0, x19, #0x48
    c88c:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    c890:      	mov	w0, w20
    c894:      	ldp	x20, x19, [sp, #0x10]
    c898:      	ldp	x29, x30, [sp], #0x20
    c89c:      	ret
    c8a0:      	mov	x20, x0
    c8a4:      	add	x0, x19, #0x48
    c8a8:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    c8ac:      	mov	x0, x20
    c8b0:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    c8b4:      	stp	x29, x30, [sp, #-0x20]!
    c8b8:      	str	x19, [sp, #0x10]
    c8bc:      	mov	x29, sp
    c8c0:      	mov	x19, x0
    c8c4:      	bl	0xb258 <_Z20MTARMPMMusicGetSpeedPv+0x55c>
    c8c8:      	mov	x0, x19
    c8cc:      	bl	0xb2b4 <_Z20MTARMPMMusicGetSpeedPv+0x5b8>
    c8d0:      	mov	w8, #0x1                // =1
    c8d4:      	strb	w8, [x19, #0x174]
    c8d8:      	str	wzr, [x19, #0x170]
    c8dc:      	ldr	x19, [sp, #0x10]
    c8e0:      	ldp	x29, x30, [sp], #0x20
    c8e4:      	ret
    c8e8:      	sub	sp, sp, #0x60
    c8ec:      	stp	x29, x30, [sp, #0x20]
    c8f0:      	str	x23, [sp, #0x30]
    c8f4:      	stp	x22, x21, [sp, #0x40]
    c8f8:      	stp	x20, x19, [sp, #0x50]
    c8fc:      	add	x29, sp, #0x20
    c900:      	mrs	x22, TPIDR_EL0
    c904:      	mov	x19, x0
    c908:      	mov	w20, w1
    c90c:      	ldr	x8, [x22, #0x28]
    c910:      	stur	x8, [x29, #-0x8]
    c914:      	ldr	x8, [x0, #0xe0]
    c918:      	cbz	x8, 0xc9a0 <_Z20MTARMPMMusicGetSpeedPv+0x1ca4>
    c91c:      	ldrb	w8, [x19, #0xd8]
    c920:      	cbnz	w8, 0xc9a0 <_Z20MTARMPMMusicGetSpeedPv+0x1ca4>
    c924:      	add	x21, x19, #0x180
    c928:      	mov	w23, #0x1               // =1
    c92c:      	mov	x0, x21
    c930:      	str	x21, [sp, #0x8]
    c934:      	strb	w23, [sp, #0x10]
    c938:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    c93c:      	add	x0, x19, #0x48
    c940:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    c944:      	sxtw	x8, w20
    c948:      	add	x0, x19, #0x70
    c94c:      	strb	w23, [x19, #0x175]
    c950:      	str	x8, [x19, #0x178]
    c954:      	bl	0x16c20 <_ZNSt6__ndk118condition_variable10notify_allEv@plt>
    c958:      	add	x0, x19, #0x48
    c95c:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    c960:      	ldrb	w8, [x19, #0x175]
    c964:      	cbz	w8, 0xc994 <_Z20MTARMPMMusicGetSpeedPv+0x1c98>
    c968:      	ldrb	w8, [x19, #0xd8]
    c96c:      	cbnz	w8, 0xc994 <_Z20MTARMPMMusicGetSpeedPv+0x1c98>
    c970:      	add	x0, x19, #0x1a8
    c974:      	add	x1, sp, #0x8
    c978:      	bl	0x16e70 <_ZNSt6__ndk118condition_variable4waitERNS_11unique_lockINS_5mutexEEE@plt>
    c97c:      	ldrb	w8, [x19, #0x175]
    c980:      	cbz	w8, 0xc98c <_Z20MTARMPMMusicGetSpeedPv+0x1c90>
    c984:      	ldrb	w8, [x19, #0xd8]
    c988:      	cbz	w8, 0xc970 <_Z20MTARMPMMusicGetSpeedPv+0x1c74>
    c98c:      	ldrb	w8, [sp, #0x10]
    c990:      	cbz	w8, 0xc9cc <_Z20MTARMPMMusicGetSpeedPv+0x1cd0>
    c994:      	ldr	x0, [sp, #0x8]
    c998:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    c99c:      	b	0xc9cc <_Z20MTARMPMMusicGetSpeedPv+0x1cd0>
    c9a0:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    c9a4:      	cmp	w0, #0x5
    c9a8:      	b.gt	0xc9cc <_Z20MTARMPMMusicGetSpeedPv+0x1cd0>
    c9ac:      	ldrb	w4, [x19, #0xd8]
    c9b0:      	adrp	x1, 0x5000
    c9b4:      	add	x1, x1, #0x2f1
    c9b8:      	adrp	x2, 0x4000
    c9bc:      	add	x2, x2, #0xfd2
    c9c0:      	mov	w0, #0x6                // =6
    c9c4:      	mov	w3, w20
    c9c8:      	bl	0x16e90 <__android_log_print@plt>
    c9cc:      	ldr	x8, [x22, #0x28]
    c9d0:      	ldur	x9, [x29, #-0x8]
    c9d4:      	cmp	x8, x9
    c9d8:      	b.ne	0xca1c <_Z20MTARMPMMusicGetSpeedPv+0x1d20>
    c9dc:      	mov	w0, wzr
    c9e0:      	ldp	x20, x19, [sp, #0x50]
    c9e4:      	ldr	x23, [sp, #0x30]
    c9e8:      	ldp	x22, x21, [sp, #0x40]
    c9ec:      	ldp	x29, x30, [sp, #0x20]
    c9f0:      	add	sp, sp, #0x60
    c9f4:      	ret
    c9f8:      	mov	x19, x0
    c9fc:      	mov	x0, x21
    ca00:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    ca04:      	ldr	x8, [x22, #0x28]
    ca08:      	ldur	x9, [x29, #-0x8]
    ca0c:      	cmp	x8, x9
    ca10:      	b.ne	0xca1c <_Z20MTARMPMMusicGetSpeedPv+0x1d20>
    ca14:      	mov	x0, x19
    ca18:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    ca1c:      	bl	0x16b40 <__stack_chk_fail@plt>
    ca20:      	ret
    ca24:      	ret
    ca28:      	ldr	x8, [x0, #0xf0]
    ca2c:      	ldr	x9, [x0, #0xe0]
    ca30:      	cmp	x8, #0x0
    ca34:      	ldr	w8, [x0, #0xf8]
    ca38:      	ccmp	x9, #0x0, #0x4, ne
    ca3c:      	csinv	w0, w8, wzr, ne
    ca40:      	ret
    ca44:      	stp	x29, x30, [sp, #-0x10]!
    ca48:      	mov	x29, sp
    ca4c:      	add	x0, x0, #0x1f0
    ca50:      	bl	0xcdec <_Z20MTARMPMMusicGetSpeedPv+0x20f0>
    ca54:      	ldp	x29, x30, [sp], #0x10
    ca58:      	ret
    ca5c:      	bl	0xad14 <_Z20MTARMPMMusicGetSpeedPv+0x18>
    ca60:      	stp	x29, x30, [sp, #-0x30]!
    ca64:      	stp	x22, x21, [sp, #0x10]
    ca68:      	stp	x20, x19, [sp, #0x20]
    ca6c:      	mov	x29, sp
    ca70:      	mov	x20, x2
    ca74:      	mov	x19, x1
    ca78:      	cmp	x2, #0x16
    ca7c:      	mov	x21, x0
    ca80:      	b.hi	0xca90 <_Z20MTARMPMMusicGetSpeedPv+0x1d94>
    ca84:      	lsl	w8, w20, #1
    ca88:      	strb	w8, [x21], #0x1
    ca8c:      	b	0xcab4 <_Z20MTARMPMMusicGetSpeedPv+0x1db8>
    ca90:      	cmn	x20, #0x10
    ca94:      	b.hs	0xcad0 <_Z20MTARMPMMusicGetSpeedPv+0x1dd4>
    ca98:      	orr	x22, x20, #0xf
    ca9c:      	add	x0, x22, #0x1
    caa0:      	bl	0x16b50 <_Znwm@plt>
    caa4:      	add	x8, x22, #0x2
    caa8:      	stp	x20, x0, [x21, #0x8]
    caac:      	str	x8, [x21]
    cab0:      	mov	x21, x0
    cab4:      	add	x2, x20, #0x1
    cab8:      	mov	x0, x21
    cabc:      	mov	x1, x19
    cac0:      	ldp	x20, x19, [sp, #0x20]
    cac4:      	ldp	x22, x21, [sp, #0x10]
    cac8:      	ldp	x29, x30, [sp], #0x30
    cacc:      	b	0x16b80 <memmove@plt>
    cad0:      	mov	x0, x21
    cad4:      	bl	0xae14 <_Z20MTARMPMMusicGetSpeedPv+0x118>
    cad8:      	stp	x29, x30, [sp, #-0x10]!
    cadc:      	mov	x29, sp
    cae0:      	mov	w0, #0x8                // =8
    cae4:      	bl	0x16bb0 <__cxa_allocate_exception@plt>
    cae8:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    caec:      	adrp	x1, 0x1b000 <syscall@plt+0x3d00>
    caf0:      	adrp	x2, 0x1b000 <syscall@plt+0x3d00>
    caf4:      	ldr	x8, [x8, #0x968]
    caf8:      	add	x8, x8, #0x10
    cafc:      	str	x8, [x0]
    cb00:      	ldr	x1, [x1, #0x970]
    cb04:      	ldr	x2, [x2, #0x978]
    cb08:      	bl	0x16bc0 <__cxa_throw@plt>
    cb0c:      	stp	x29, x30, [sp, #-0x20]!
    cb10:      	str	x19, [sp, #0x10]
    cb14:      	mov	x29, sp
    cb18:      	mov	x19, x0
    cb1c:      	bl	0x17020 <_ZNSt9exceptionD2Ev@plt>
    cb20:      	mov	x0, x19
    cb24:      	ldr	x19, [sp, #0x10]
    cb28:      	ldp	x29, x30, [sp], #0x20
    cb2c:      	b	0x16b60 <_ZdlPv@plt>
    cb30:      	stp	x29, x30, [sp, #-0x40]!
    cb34:      	stp	x24, x23, [sp, #0x10]
    cb38:      	stp	x22, x21, [sp, #0x20]
    cb3c:      	stp	x20, x19, [sp, #0x30]
    cb40:      	mov	x29, sp
    cb44:      	adrp	x23, 0x1b000 <syscall@plt+0x3d00>
    cb48:      	adrp	x22, 0x1b000 <syscall@plt+0x3d00>
    cb4c:      	mov	x20, x0
    cb50:      	ldr	x23, [x23, #0x980]
    cb54:      	ldr	x22, [x22, #0x958]
    cb58:      	mov	x19, x0
    cb5c:      	ldp	x8, x9, [x22, #0x8]
    cb60:      	add	x24, x23, #0x40
    cb64:      	str	x24, [x20, #0x70]!
    cb68:      	str	x8, [x0]
    cb6c:      	ldur	x8, [x8, #-0x18]
    cb70:      	str	x9, [x0, x8]
    cb74:      	ldr	x8, [x0]
    cb78:      	ldur	x8, [x8, #-0x18]
    cb7c:      	add	x21, x0, x8
    cb80:      	add	x1, x0, #0x8
    cb84:      	mov	x0, x21
    cb88:      	bl	0x17030 <_ZNSt6__ndk18ios_base4initEPv@plt>
    cb8c:      	mov	w8, #-0x1               // =-1
    cb90:      	add	x9, x23, #0x18
    cb94:      	str	xzr, [x21, #0x88]
    cb98:      	str	w8, [x21, #0x90]
    cb9c:      	str	x9, [x19]
    cba0:      	str	x24, [x19, #0x70]
    cba4:      	add	x0, x19, #0x8
    cba8:      	bl	0x17040 <_ZNSt6__ndk115basic_streambufIcNS_11char_traitsIcEEEC2Ev@plt>
    cbac:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    cbb0:      	movi	v0.2d, #0000000000000000
    cbb4:      	ldr	x8, [x8, #0x960]
    cbb8:      	add	x8, x8, #0x10
    cbbc:      	str	x8, [x19, #0x8]
    cbc0:      	mov	w8, #0x10               // =16
    cbc4:      	stur	q0, [x19, #0x48]
    cbc8:      	stur	q0, [x19, #0x58]
    cbcc:      	str	w8, [x19, #0x68]
    cbd0:      	ldp	x20, x19, [sp, #0x30]
    cbd4:      	ldp	x22, x21, [sp, #0x20]
    cbd8:      	ldp	x24, x23, [sp, #0x10]
    cbdc:      	ldp	x29, x30, [sp], #0x40
    cbe0:      	ret
    cbe4:      	mov	x21, x0
    cbe8:      	add	x1, x22, #0x8
    cbec:      	mov	x0, x19
    cbf0:      	bl	0x16f10 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEED2Ev@plt>
    cbf4:      	b	0xcbfc <_Z20MTARMPMMusicGetSpeedPv+0x1f00>
    cbf8:      	mov	x21, x0
    cbfc:      	mov	x0, x20
    cc00:      	bl	0x16f20 <_ZNSt6__ndk19basic_iosIcNS_11char_traitsIcEEED2Ev@plt>
    cc04:      	mov	x0, x21
    cc08:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    cc0c:      	stp	x29, x30, [sp, #-0x30]!
    cc10:      	str	x21, [sp, #0x10]
    cc14:      	stp	x20, x19, [sp, #0x20]
    cc18:      	mov	x29, sp
    cc1c:      	adrp	x21, 0x1b000 <syscall@plt+0x3d00>
    cc20:      	adrp	x9, 0x1b000 <syscall@plt+0x3d00>
    cc24:      	mov	x20, x0
    cc28:      	ldr	x21, [x21, #0x958]
    cc2c:      	mov	x19, x0
    cc30:      	ldr	x8, [x21]
    cc34:      	ldr	x10, [x21, #0x18]
    cc38:      	str	x8, [x0]
    cc3c:      	ldur	x8, [x8, #-0x18]
    cc40:      	ldr	x9, [x9, #0x960]
    cc44:      	str	x10, [x0, x8]
    cc48:      	add	x8, x9, #0x10
    cc4c:      	str	x8, [x20, #0x8]!
    cc50:      	ldrb	w8, [x20, #0x40]
    cc54:      	tbz	w8, #0x0, 0xcc60 <_Z20MTARMPMMusicGetSpeedPv+0x1f64>
    cc58:      	ldr	x0, [x19, #0x58]
    cc5c:      	bl	0x16b60 <_ZdlPv@plt>
    cc60:      	mov	x0, x20
    cc64:      	bl	0x16f00 <_ZNSt6__ndk115basic_streambufIcNS_11char_traitsIcEEED2Ev@plt>
    cc68:      	add	x1, x21, #0x8
    cc6c:      	mov	x0, x19
    cc70:      	bl	0x16f10 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEED2Ev@plt>
    cc74:      	add	x0, x19, #0x70
    cc78:      	ldp	x20, x19, [sp, #0x20]
    cc7c:      	ldr	x21, [sp, #0x10]
    cc80:      	ldp	x29, x30, [sp], #0x30
    cc84:      	b	0x16f20 <_ZNSt6__ndk19basic_iosIcNS_11char_traitsIcEEED2Ev@plt>
    cc88:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    cc8c:      	ldr	x8, [x8, #0x940]
    cc90:      	add	x8, x8, #0x10
    cc94:      	str	x8, [x0]
    cc98:      	b	0x16e50 <_ZNSt6__ndk119__shared_weak_countD2Ev@plt>
    cc9c:      	stp	x29, x30, [sp, #-0x20]!
    cca0:      	str	x19, [sp, #0x10]
    cca4:      	mov	x29, sp
    cca8:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    ccac:      	mov	x19, x0
    ccb0:      	ldr	x8, [x8, #0x940]
    ccb4:      	add	x8, x8, #0x10
    ccb8:      	str	x8, [x0]
    ccbc:      	bl	0x16e50 <_ZNSt6__ndk119__shared_weak_countD2Ev@plt>
    ccc0:      	mov	x0, x19
    ccc4:      	ldr	x19, [sp, #0x10]
    ccc8:      	ldp	x29, x30, [sp], #0x20
    cccc:      	b	0x16b60 <_ZdlPv@plt>
    ccd0:      	add	x0, x0, #0x18
    ccd4:      	b	0x17050 <_ZNSt6__ndk16threadD1Ev@plt>
    ccd8:      	b	0x16b60 <_ZdlPv@plt>
    ccdc:      	sub	sp, sp, #0x30
    cce0:      	stp	x29, x30, [sp, #0x10]
    cce4:      	stp	x20, x19, [sp, #0x20]
    cce8:      	add	x29, sp, #0x10
    ccec:      	mrs	x20, TPIDR_EL0
    ccf0:      	mov	x19, x0
    ccf4:      	ldr	x8, [x20, #0x28]
    ccf8:      	str	x8, [sp, #0x8]
    ccfc:      	str	x0, [sp]
    cd00:      	bl	0x17060 <_ZNSt6__ndk119__thread_local_dataEv@plt>
    cd04:      	ldr	x1, [x19]
    cd08:      	ldr	w0, [x0]
    cd0c:      	str	xzr, [x19]
    cd10:      	bl	0x17070 <pthread_setspecific@plt>
    cd14:      	ldr	x0, [x19, #0x8]
    cd18:      	bl	0xc15c <_Z20MTARMPMMusicGetSpeedPv+0x1460>
    cd1c:      	mov	x0, sp
    cd20:      	bl	0xcd70 <_Z20MTARMPMMusicGetSpeedPv+0x2074>
    cd24:      	ldr	x8, [x20, #0x28]
    cd28:      	ldr	x9, [sp, #0x8]
    cd2c:      	cmp	x8, x9
    cd30:      	b.ne	0xcd6c <_Z20MTARMPMMusicGetSpeedPv+0x2070>
    cd34:      	mov	x0, xzr
    cd38:      	ldp	x20, x19, [sp, #0x20]
    cd3c:      	ldp	x29, x30, [sp, #0x10]
    cd40:      	add	sp, sp, #0x30
    cd44:      	ret
    cd48:      	mov	x19, x0
    cd4c:      	mov	x0, sp
    cd50:      	bl	0xcd70 <_Z20MTARMPMMusicGetSpeedPv+0x2074>
    cd54:      	ldr	x8, [x20, #0x28]
    cd58:      	ldr	x9, [sp, #0x8]
    cd5c:      	cmp	x8, x9
    cd60:      	b.ne	0xcd6c <_Z20MTARMPMMusicGetSpeedPv+0x2070>
    cd64:      	mov	x0, x19
    cd68:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    cd6c:      	bl	0x16b40 <__stack_chk_fail@plt>
    cd70:      	stp	x29, x30, [sp, #-0x20]!
    cd74:      	str	x19, [sp, #0x10]
    cd78:      	mov	x29, sp
    cd7c:      	ldr	x19, [x0]
    cd80:      	str	xzr, [x0]
    cd84:      	cbz	x19, 0xcda4 <_Z20MTARMPMMusicGetSpeedPv+0x20a8>
    cd88:      	mov	x0, x19
    cd8c:      	mov	x1, xzr
    cd90:      	bl	0xcdb0 <_Z20MTARMPMMusicGetSpeedPv+0x20b4>
    cd94:      	mov	x0, x19
    cd98:      	ldr	x19, [sp, #0x10]
    cd9c:      	ldp	x29, x30, [sp], #0x20
    cda0:      	b	0x16b60 <_ZdlPv@plt>
    cda4:      	ldr	x19, [sp, #0x10]
    cda8:      	ldp	x29, x30, [sp], #0x20
    cdac:      	ret
    cdb0:      	stp	x29, x30, [sp, #-0x20]!
    cdb4:      	str	x19, [sp, #0x10]
    cdb8:      	mov	x29, sp
    cdbc:      	ldr	x19, [x0]
    cdc0:      	str	x1, [x0]
    cdc4:      	cbz	x19, 0xcde0 <_Z20MTARMPMMusicGetSpeedPv+0x20e4>
    cdc8:      	mov	x0, x19
    cdcc:      	bl	0x16e40 <_ZNSt6__ndk115__thread_structD1Ev@plt>
    cdd0:      	mov	x0, x19
    cdd4:      	ldr	x19, [sp, #0x10]
    cdd8:      	ldp	x29, x30, [sp], #0x20
    cddc:      	b	0x16b60 <_ZdlPv@plt>
    cde0:      	ldr	x19, [sp, #0x10]
    cde4:      	ldp	x29, x30, [sp], #0x20
    cde8:      	ret
    cdec:      	stp	x29, x30, [sp, #-0x20]!
    cdf0:      	stp	x20, x19, [sp, #0x10]
    cdf4:      	mov	x29, sp
    cdf8:      	mov	x19, x0
    cdfc:      	ldr	x0, [x0, #0x20]
    ce00:      	mov	x20, x1
    ce04:      	str	xzr, [x19, #0x20]
    ce08:      	cmp	x0, x19
    ce0c:      	b.eq	0xce1c <_Z20MTARMPMMusicGetSpeedPv+0x2120>
    ce10:      	cbz	x0, 0xce30 <_Z20MTARMPMMusicGetSpeedPv+0x2134>
    ce14:      	mov	w8, #0x5                // =5
    ce18:      	b	0xce24 <_Z20MTARMPMMusicGetSpeedPv+0x2128>
    ce1c:      	mov	w8, #0x4                // =4
    ce20:      	mov	x0, x19
    ce24:      	ldr	x9, [x0]
    ce28:      	ldr	x8, [x9, x8, lsl #3]
    ce2c:      	blr	x8
    ce30:      	ldr	x8, [x20, #0x20]
    ce34:      	cbz	x8, 0xce4c <_Z20MTARMPMMusicGetSpeedPv+0x2150>
    ce38:      	cmp	x8, x20
    ce3c:      	b.eq	0xce54 <_Z20MTARMPMMusicGetSpeedPv+0x2158>
    ce40:      	str	x8, [x19, #0x20]
    ce44:      	str	xzr, [x20, #0x20]
    ce48:      	b	0xce6c <_Z20MTARMPMMusicGetSpeedPv+0x2170>
    ce4c:      	str	xzr, [x19, #0x20]
    ce50:      	b	0xce6c <_Z20MTARMPMMusicGetSpeedPv+0x2170>
    ce54:      	str	x19, [x19, #0x20]
    ce58:      	mov	x1, x19
    ce5c:      	ldr	x0, [x20, #0x20]
    ce60:      	ldr	x8, [x0]
    ce64:      	ldr	x8, [x8, #0x18]
    ce68:      	blr	x8
    ce6c:      	mov	x0, x19
    ce70:      	ldp	x20, x19, [sp, #0x10]
    ce74:      	ldp	x29, x30, [sp], #0x20
    ce78:      	ret
    ce7c:      	adrp	x8, 0x1f000
    ce80:      	ldr	w0, [x8, #0xdcc]
    ce84:      	ret
    ce88:      	sub	sp, sp, #0x100
    ce8c:      	stp	x29, x30, [sp, #0xa0]
    ce90:      	stp	x28, x27, [sp, #0xb0]
    ce94:      	stp	x26, x25, [sp, #0xc0]
    ce98:      	stp	x24, x23, [sp, #0xd0]
    ce9c:      	stp	x22, x21, [sp, #0xe0]
    cea0:      	stp	x20, x19, [sp, #0xf0]
    cea4:      	add	x29, sp, #0xa0
    cea8:      	mrs	x25, TPIDR_EL0
    ceac:      	mov	x19, x0
    ceb0:      	mov	x24, x2
    ceb4:      	ldr	x8, [x25, #0x28]
    ceb8:      	mov	x22, x1
    cebc:      	mov	x23, x0
    cec0:      	stur	x8, [x29, #-0x8]
    cec4:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    cec8:      	add	x8, x8, #0x448
    cecc:      	str	x8, [x0]
    ced0:      	ldr	x8, [x1]
    ced4:      	str	x8, [x19, #0x10]!
    ced8:      	ldr	x8, [x1, #0x8]
    cedc:      	str	x8, [x0, #0x18]
    cee0:      	cbz	x8, 0xcef0 <_Z20MTARMPMMusicGetSpeedPv+0x21f4>
    cee4:      	add	x1, x8, #0x8
    cee8:      	mov	w0, #0x1                // =1
    ceec:      	bl	0x125c0 <_Z20MTARMPMMusicGetSpeedPv+0x78c4>
    cef0:      	mov	x20, x23
    cef4:      	mov	w8, #0x3f800000         // =1065353216
    cef8:      	stp	xzr, xzr, [x20, #0x20]!
    cefc:      	mov	x26, x20
    cf00:      	mov	x21, x20
    cf04:      	strb	wzr, [x20, #0x10]
    cf08:      	str	w8, [x20, #0x14]
    cf0c:      	str	xzr, [x26, #0x20]!
    cf10:      	str	x26, [x21, #0x18]!
    cf14:      	str	xzr, [x20, #0x28]
    cf18:      	add	x8, sp, #0x30
    cf1c:      	add	x0, sp, #0x2f
    cf20:      	mov	x1, x24
    cf24:      	bl	0xdb10 <_Z20MTARMPMMusicGetSpeedPv+0x2e14>
    cf28:      	add	x1, sp, #0x30
    cf2c:      	mov	x0, x20
    cf30:      	bl	0xd140 <_Z20MTARMPMMusicGetSpeedPv+0x2444>
    cf34:      	ldr	x24, [sp, #0x38]
    cf38:      	cbz	x24, 0xcf64 <_Z20MTARMPMMusicGetSpeedPv+0x2268>
    cf3c:      	add	x1, x24, #0x8
    cf40:      	mov	x0, #-0x1               // =-1
    cf44:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    cf48:      	cbnz	x0, 0xcf64 <_Z20MTARMPMMusicGetSpeedPv+0x2268>
    cf4c:      	ldr	x8, [x24]
    cf50:      	mov	x0, x24
    cf54:      	ldr	x8, [x8, #0x10]
    cf58:      	blr	x8
    cf5c:      	mov	x0, x24
    cf60:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    cf64:      	ldr	x8, [x22]
    cf68:      	ldr	x0, [x23, #0x20]
    cf6c:      	sub	x24, x29, #0x40
    cf70:      	stur	x24, [x29, #-0x20]
    cf74:      	ldr	d0, [x8, #0x30]
    cf78:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    cf7c:      	add	x8, x8, #0x4a0
    cf80:      	stp	x8, x23, [x29, #-0x40]
    cf84:      	rev64	v0.2s, v0.2s
    cf88:      	str	d0, [x0, #0x38]
    cf8c:      	sub	x1, x29, #0x40
    cf90:      	bl	0xca44 <_Z20MTARMPMMusicGetSpeedPv+0x1d48>
    cf94:      	ldur	x0, [x29, #-0x20]
    cf98:      	cmp	x0, x24
    cf9c:      	b.eq	0xcfac <_Z20MTARMPMMusicGetSpeedPv+0x22b0>
    cfa0:      	cbz	x0, 0xcfc0 <_Z20MTARMPMMusicGetSpeedPv+0x22c4>
    cfa4:      	mov	w8, #0x5                // =5
    cfa8:      	b	0xcfb4 <_Z20MTARMPMMusicGetSpeedPv+0x22b8>
    cfac:      	mov	w8, #0x4                // =4
    cfb0:      	sub	x0, x29, #0x40
    cfb4:      	ldr	x9, [x0]
    cfb8:      	ldr	x8, [x9, x8, lsl #3]
    cfbc:      	blr	x8
    cfc0:      	nop
    cfc4:      	adr	x27, 0xbb20 <_Z20MTARMPMMusicGetSpeedPv+0xe24>
    cfc8:      	ldp	x24, x28, [x23, #0x20]
    cfcc:      	ldr	x22, [x22]
    cfd0:      	stp	x27, xzr, [sp, #0x8]
    cfd4:      	stp	x24, x28, [sp, #0x18]
    cfd8:      	cbz	x28, 0xcfe8 <_Z20MTARMPMMusicGetSpeedPv+0x22ec>
    cfdc:      	add	x1, x28, #0x8
    cfe0:      	mov	w0, #0x1                // =1
    cfe4:      	bl	0x125c0 <_Z20MTARMPMMusicGetSpeedPv+0x78c4>
    cfe8:      	add	x23, sp, #0x8
    cfec:      	str	xzr, [sp, #0x50]
    cff0:      	mov	w0, #0x28               // =40
    cff4:      	bl	0x16b50 <_Znwm@plt>
    cff8:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    cffc:      	add	x8, x8, #0x4e8
    d000:      	stp	xzr, x24, [x0, #0x10]
    d004:      	stp	x8, x27, [x0]
    d008:      	str	x28, [x0, #0x20]
    d00c:      	stp	xzr, xzr, [x23, #0x10]
    d010:      	str	x0, [sp, #0x50]
    d014:      	add	x2, sp, #0x30
    d018:      	mov	x0, x22
    d01c:      	mov	x1, x24
    d020:      	add	x22, sp, #0x30
    d024:      	bl	0xfb74 <_Z20MTARMPMMusicGetSpeedPv+0x4e78>
    d028:      	ldr	x0, [sp, #0x50]
    d02c:      	cmp	x0, x22
    d030:      	b.eq	0xd040 <_Z20MTARMPMMusicGetSpeedPv+0x2344>
    d034:      	cbz	x0, 0xd054 <_Z20MTARMPMMusicGetSpeedPv+0x2358>
    d038:      	mov	w8, #0x5                // =5
    d03c:      	b	0xd048 <_Z20MTARMPMMusicGetSpeedPv+0x234c>
    d040:      	mov	w8, #0x4                // =4
    d044:      	add	x0, sp, #0x30
    d048:      	ldr	x9, [x0]
    d04c:      	ldr	x8, [x9, x8, lsl #3]
    d050:      	blr	x8
    d054:      	ldr	x8, [x25, #0x28]
    d058:      	ldur	x9, [x29, #-0x8]
    d05c:      	cmp	x8, x9
    d060:      	b.ne	0xd13c <_Z20MTARMPMMusicGetSpeedPv+0x2440>
    d064:      	ldp	x20, x19, [sp, #0xf0]
    d068:      	ldp	x22, x21, [sp, #0xe0]
    d06c:      	ldp	x24, x23, [sp, #0xd0]
    d070:      	ldp	x26, x25, [sp, #0xc0]
    d074:      	ldp	x28, x27, [sp, #0xb0]
    d078:      	ldp	x29, x30, [sp, #0xa0]
    d07c:      	add	sp, sp, #0x100
    d080:      	ret
    d084:      	ldr	x8, [sp, #0x50]
    d088:      	cmp	x8, x22
    d08c:      	mov	x22, x0
    d090:      	b.ne	0xd0a0 <_Z20MTARMPMMusicGetSpeedPv+0x23a4>
    d094:      	mov	w9, #0x4                // =4
    d098:      	add	x8, sp, #0x30
    d09c:      	b	0xd0a8 <_Z20MTARMPMMusicGetSpeedPv+0x23ac>
    d0a0:      	cbz	x8, 0xd0c0 <_Z20MTARMPMMusicGetSpeedPv+0x23c4>
    d0a4:      	mov	w9, #0x5                // =5
    d0a8:      	ldr	x10, [x8]
    d0ac:      	mov	x0, x8
    d0b0:      	ldr	x9, [x10, x9, lsl #3]
    d0b4:      	blr	x9
    d0b8:      	b	0xd0c0 <_Z20MTARMPMMusicGetSpeedPv+0x23c4>
    d0bc:      	mov	x22, x0
    d0c0:      	add	x0, x23, #0x10
    d0c4:      	bl	0xd19c <_Z20MTARMPMMusicGetSpeedPv+0x24a0>
    d0c8:      	b	0xd108 <_Z20MTARMPMMusicGetSpeedPv+0x240c>
    d0cc:      	ldur	x8, [x29, #-0x20]
    d0d0:      	mov	x22, x0
    d0d4:      	cmp	x8, x24
    d0d8:      	b.ne	0xd0e8 <_Z20MTARMPMMusicGetSpeedPv+0x23ec>
    d0dc:      	mov	w9, #0x4                // =4
    d0e0:      	sub	x8, x29, #0x40
    d0e4:      	b	0xd0f0 <_Z20MTARMPMMusicGetSpeedPv+0x23f4>
    d0e8:      	cbz	x8, 0xd108 <_Z20MTARMPMMusicGetSpeedPv+0x240c>
    d0ec:      	mov	w9, #0x5                // =5
    d0f0:      	ldr	x10, [x8]
    d0f4:      	mov	x0, x8
    d0f8:      	ldr	x9, [x10, x9, lsl #3]
    d0fc:      	blr	x9
    d100:      	b	0xd108 <_Z20MTARMPMMusicGetSpeedPv+0x240c>
    d104:      	mov	x22, x0
    d108:      	ldr	x1, [x26]
    d10c:      	mov	x0, x21
    d110:      	bl	0xda64 <_Z20MTARMPMMusicGetSpeedPv+0x2d68>
    d114:      	mov	x0, x20
    d118:      	bl	0xd19c <_Z20MTARMPMMusicGetSpeedPv+0x24a0>
    d11c:      	mov	x0, x19
    d120:      	bl	0xd1ec <_Z20MTARMPMMusicGetSpeedPv+0x24f0>
    d124:      	ldr	x8, [x25, #0x28]
    d128:      	ldur	x9, [x29, #-0x8]
    d12c:      	cmp	x8, x9
    d130:      	b.ne	0xd13c <_Z20MTARMPMMusicGetSpeedPv+0x2440>
    d134:      	mov	x0, x22
    d138:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    d13c:      	bl	0x16b40 <__stack_chk_fail@plt>
    d140:      	stp	x29, x30, [sp, #-0x20]!
    d144:      	stp	x20, x19, [sp, #0x10]
    d148:      	mov	x29, sp
    d14c:      	ldr	q0, [x1]
    d150:      	stp	xzr, xzr, [x1]
    d154:      	mov	x19, x0
    d158:      	ldr	x20, [x0, #0x8]
    d15c:      	str	q0, [x0]
    d160:      	cbz	x20, 0xd18c <_Z20MTARMPMMusicGetSpeedPv+0x2490>
    d164:      	add	x1, x20, #0x8
    d168:      	mov	x0, #-0x1               // =-1
    d16c:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    d170:      	cbnz	x0, 0xd18c <_Z20MTARMPMMusicGetSpeedPv+0x2490>
    d174:      	ldr	x8, [x20]
    d178:      	mov	x0, x20
    d17c:      	ldr	x8, [x8, #0x10]
    d180:      	blr	x8
    d184:      	mov	x0, x20
    d188:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    d18c:      	mov	x0, x19
    d190:      	ldp	x20, x19, [sp, #0x10]
    d194:      	ldp	x29, x30, [sp], #0x20
    d198:      	ret
    d19c:      	stp	x29, x30, [sp, #-0x20]!
    d1a0:      	str	x19, [sp, #0x10]
    d1a4:      	mov	x29, sp
    d1a8:      	ldr	x19, [x0, #0x8]
    d1ac:      	cbz	x19, 0xd1c0 <_Z20MTARMPMMusicGetSpeedPv+0x24c4>
    d1b0:      	add	x1, x19, #0x8
    d1b4:      	mov	x0, #-0x1               // =-1
    d1b8:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    d1bc:      	cbz	x0, 0xd1cc <_Z20MTARMPMMusicGetSpeedPv+0x24d0>
    d1c0:      	ldr	x19, [sp, #0x10]
    d1c4:      	ldp	x29, x30, [sp], #0x20
    d1c8:      	ret
    d1cc:      	ldr	x8, [x19]
    d1d0:      	mov	x0, x19
    d1d4:      	ldr	x8, [x8, #0x10]
    d1d8:      	blr	x8
    d1dc:      	mov	x0, x19
    d1e0:      	ldr	x19, [sp, #0x10]
    d1e4:      	ldp	x29, x30, [sp], #0x20
    d1e8:      	b	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    d1ec:      	stp	x29, x30, [sp, #-0x20]!
    d1f0:      	str	x19, [sp, #0x10]
    d1f4:      	mov	x29, sp
    d1f8:      	ldr	x19, [x0, #0x8]
    d1fc:      	cbz	x19, 0xd210 <_Z20MTARMPMMusicGetSpeedPv+0x2514>
    d200:      	add	x1, x19, #0x8
    d204:      	mov	x0, #-0x1               // =-1
    d208:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    d20c:      	cbz	x0, 0xd21c <_Z20MTARMPMMusicGetSpeedPv+0x2520>
    d210:      	ldr	x19, [sp, #0x10]
    d214:      	ldp	x29, x30, [sp], #0x20
    d218:      	ret
    d21c:      	ldr	x8, [x19]
    d220:      	mov	x0, x19
    d224:      	ldr	x8, [x8, #0x10]
    d228:      	blr	x8
    d22c:      	mov	x0, x19
    d230:      	ldr	x19, [sp, #0x10]
    d234:      	ldp	x29, x30, [sp], #0x20
    d238:      	b	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    d23c:      	stp	x29, x30, [sp, #-0x20]!
    d240:      	str	x19, [sp, #0x10]
    d244:      	mov	x29, sp
    d248:      	mov	x19, x0
    d24c:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    d250:      	add	x8, x8, #0x448
    d254:      	str	x8, [x0]
    d258:      	bl	0xd284 <_Z20MTARMPMMusicGetSpeedPv+0x2588>
    d25c:      	ldr	x1, [x19, #0x40]
    d260:      	add	x0, x19, #0x38
    d264:      	bl	0xda64 <_Z20MTARMPMMusicGetSpeedPv+0x2d68>
    d268:      	add	x0, x19, #0x20
    d26c:      	bl	0xd19c <_Z20MTARMPMMusicGetSpeedPv+0x24a0>
    d270:      	add	x0, x19, #0x10
    d274:      	ldr	x19, [sp, #0x10]
    d278:      	ldp	x29, x30, [sp], #0x20
    d27c:      	b	0xd1ec <_Z20MTARMPMMusicGetSpeedPv+0x24f0>
    d280:      	bl	0xad14 <_Z20MTARMPMMusicGetSpeedPv+0x18>
    d284:      	sub	sp, sp, #0x50
    d288:      	stp	x29, x30, [sp, #0x20]
    d28c:      	stp	x22, x21, [sp, #0x30]
    d290:      	stp	x20, x19, [sp, #0x40]
    d294:      	add	x29, sp, #0x20
    d298:      	mrs	x22, TPIDR_EL0
    d29c:      	mov	x21, x0
    d2a0:      	mov	x19, x0
    d2a4:      	ldr	x8, [x22, #0x28]
    d2a8:      	stur	x8, [x29, #-0x8]
    d2ac:      	ldr	x0, [x21, #0x10]!
    d2b0:      	cbz	x0, 0xd384 <_Z20MTARMPMMusicGetSpeedPv+0x2688>
    d2b4:      	mov	x20, x19
    d2b8:      	ldr	x1, [x20, #0x20]!
    d2bc:      	cbz	x1, 0xd384 <_Z20MTARMPMMusicGetSpeedPv+0x2688>
    d2c0:      	bl	0xfb8c <_Z20MTARMPMMusicGetSpeedPv+0x4e90>
    d2c4:      	ldr	x0, [x20]
    d2c8:      	bl	0xc8b4 <_Z20MTARMPMMusicGetSpeedPv+0x1bb8>
    d2cc:      	add	x1, sp, #0x8
    d2d0:      	mov	x0, x21
    d2d4:      	stp	xzr, xzr, [sp, #0x8]
    d2d8:      	bl	0xd3d0 <_Z20MTARMPMMusicGetSpeedPv+0x26d4>
    d2dc:      	ldr	x21, [sp, #0x10]
    d2e0:      	cbz	x21, 0xd30c <_Z20MTARMPMMusicGetSpeedPv+0x2610>
    d2e4:      	add	x1, x21, #0x8
    d2e8:      	mov	x0, #-0x1               // =-1
    d2ec:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    d2f0:      	cbnz	x0, 0xd30c <_Z20MTARMPMMusicGetSpeedPv+0x2610>
    d2f4:      	ldr	x8, [x21]
    d2f8:      	mov	x0, x21
    d2fc:      	ldr	x8, [x8, #0x10]
    d300:      	blr	x8
    d304:      	mov	x0, x21
    d308:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    d30c:      	add	x1, sp, #0x8
    d310:      	mov	x0, x20
    d314:      	stp	xzr, xzr, [sp, #0x8]
    d318:      	bl	0xd140 <_Z20MTARMPMMusicGetSpeedPv+0x2444>
    d31c:      	ldr	x20, [sp, #0x10]
    d320:      	cbz	x20, 0xd34c <_Z20MTARMPMMusicGetSpeedPv+0x2650>
    d324:      	add	x1, x20, #0x8
    d328:      	mov	x0, #-0x1               // =-1
    d32c:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    d330:      	cbnz	x0, 0xd34c <_Z20MTARMPMMusicGetSpeedPv+0x2650>
    d334:      	ldr	x8, [x20]
    d338:      	mov	x0, x20
    d33c:      	ldr	x8, [x8, #0x10]
    d340:      	blr	x8
    d344:      	mov	x0, x20
    d348:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    d34c:      	ldr	x1, [x19, #0x40]!
    d350:      	sub	x0, x19, #0x8
    d354:      	bl	0xda64 <_Z20MTARMPMMusicGetSpeedPv+0x2d68>
    d358:      	stp	x19, xzr, [x19, #-0x8]
    d35c:      	str	xzr, [x19, #0x8]
    d360:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    d364:      	cmp	w0, #0x2
    d368:      	b.gt	0xd384 <_Z20MTARMPMMusicGetSpeedPv+0x2688>
    d36c:      	nop
    d370:      	adr	x1, 0x52f1
    d374:      	adrp	x2, 0x4000
    d378:      	add	x2, x2, #0xaf9
    d37c:      	mov	w0, #0x3                // =3
    d380:      	bl	0x16e90 <__android_log_print@plt>
    d384:      	ldr	x8, [x22, #0x28]
    d388:      	ldur	x9, [x29, #-0x8]
    d38c:      	cmp	x8, x9
    d390:      	b.ne	0xd3a8 <_Z20MTARMPMMusicGetSpeedPv+0x26ac>
    d394:      	ldp	x20, x19, [sp, #0x40]
    d398:      	ldp	x22, x21, [sp, #0x30]
    d39c:      	ldp	x29, x30, [sp, #0x20]
    d3a0:      	add	sp, sp, #0x50
    d3a4:      	ret
    d3a8:      	bl	0x16b40 <__stack_chk_fail@plt>
    d3ac:      	stp	x29, x30, [sp, #-0x20]!
    d3b0:      	str	x19, [sp, #0x10]
    d3b4:      	mov	x29, sp
    d3b8:      	mov	x19, x0
    d3bc:      	bl	0xd23c <_Z20MTARMPMMusicGetSpeedPv+0x2540>
    d3c0:      	mov	x0, x19
    d3c4:      	ldr	x19, [sp, #0x10]
    d3c8:      	ldp	x29, x30, [sp], #0x20
    d3cc:      	b	0x16b60 <_ZdlPv@plt>
    d3d0:      	stp	x29, x30, [sp, #-0x20]!
    d3d4:      	stp	x20, x19, [sp, #0x10]
    d3d8:      	mov	x29, sp
    d3dc:      	ldr	q0, [x1]
    d3e0:      	stp	xzr, xzr, [x1]
    d3e4:      	mov	x19, x0
    d3e8:      	ldr	x20, [x0, #0x8]
    d3ec:      	str	q0, [x0]
    d3f0:      	cbz	x20, 0xd41c <_Z20MTARMPMMusicGetSpeedPv+0x2720>
    d3f4:      	add	x1, x20, #0x8
    d3f8:      	mov	x0, #-0x1               // =-1
    d3fc:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    d400:      	cbnz	x0, 0xd41c <_Z20MTARMPMMusicGetSpeedPv+0x2720>
    d404:      	ldr	x8, [x20]
    d408:      	mov	x0, x20
    d40c:      	ldr	x8, [x8, #0x10]
    d410:      	blr	x8
    d414:      	mov	x0, x20
    d418:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    d41c:      	mov	x0, x19
    d420:      	ldp	x20, x19, [sp, #0x10]
    d424:      	ldp	x29, x30, [sp], #0x20
    d428:      	ret
    d42c:      	ldr	x8, [x0, #0x10]
    d430:      	cbz	x8, 0xd44c <_Z20MTARMPMMusicGetSpeedPv+0x2750>
    d434:      	ldr	x8, [x0, #0x20]
    d438:      	cbz	x8, 0xd44c <_Z20MTARMPMMusicGetSpeedPv+0x2750>
    d43c:      	ldrb	w8, [x8, #0x20]
    d440:      	cmp	w8, #0x0
    d444:      	cset	w0, ne
    d448:      	ret
    d44c:      	mov	w0, wzr
    d450:      	ret
    d454:      	ldr	x8, [x0, #0x10]
    d458:      	cbz	x8, 0xd46c <_Z20MTARMPMMusicGetSpeedPv+0x2770>
    d45c:      	ldr	x8, [x0, #0x20]
    d460:      	cbz	x8, 0xd46c <_Z20MTARMPMMusicGetSpeedPv+0x2770>
    d464:      	ldr	w0, [x8, #0x1d8]
    d468:      	ret
    d46c:      	mov	w0, wzr
    d470:      	ret
    d474:      	ldr	x8, [x0, #0x10]
    d478:      	cbz	x8, 0xd494 <_Z20MTARMPMMusicGetSpeedPv+0x2798>
    d47c:      	ldr	x8, [x0, #0x20]
    d480:      	cbz	x8, 0xd494 <_Z20MTARMPMMusicGetSpeedPv+0x2798>
    d484:      	ldrb	w8, [x8, #0x174]
    d488:      	cmp	w8, #0x0
    d48c:      	cset	w0, eq
    d490:      	ret
    d494:      	mov	w0, wzr
    d498:      	ret
    d49c:      	ldr	x8, [x0, #0x10]
    d4a0:      	cbz	x8, 0xd4e8 <_Z20MTARMPMMusicGetSpeedPv+0x27ec>
    d4a4:      	ldr	x0, [x0, #0x20]
    d4a8:      	cbz	x0, 0xd4e8 <_Z20MTARMPMMusicGetSpeedPv+0x27ec>
    d4ac:      	stp	x29, x30, [sp, #-0x10]!
    d4b0:      	mov	x29, sp
    d4b4:      	ldrb	w8, [x0, #0x174]
    d4b8:      	cbnz	w8, 0xd4c0 <_Z20MTARMPMMusicGetSpeedPv+0x27c4>
    d4bc:      	bl	0xba5c <_Z20MTARMPMMusicGetSpeedPv+0xd60>
    d4c0:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    d4c4:      	cmp	w0, #0x2
    d4c8:      	ldp	x29, x30, [sp], #0x10
    d4cc:      	b.gt	0xd4e8 <_Z20MTARMPMMusicGetSpeedPv+0x27ec>
    d4d0:      	nop
    d4d4:      	adr	x1, 0x52f1
    d4d8:      	adrp	x2, 0x5000
    d4dc:      	add	x2, x2, #0x2fb
    d4e0:      	mov	w0, #0x3                // =3
    d4e4:      	b	0x16e90 <__android_log_print@plt>
    d4e8:      	ret
    d4ec:      	stp	x29, x30, [sp, #-0x20]!
    d4f0:      	str	x19, [sp, #0x10]
    d4f4:      	mov	x29, sp
    d4f8:      	ldr	x8, [x0, #0x10]
    d4fc:      	cbz	x8, 0xd560 <_Z20MTARMPMMusicGetSpeedPv+0x2864>
    d500:      	mov	x19, x0
    d504:      	ldr	x0, [x0, #0x20]
    d508:      	cbz	x0, 0xd560 <_Z20MTARMPMMusicGetSpeedPv+0x2864>
    d50c:      	ldrb	w8, [x0, #0x174]
    d510:      	cbz	w8, 0xd560 <_Z20MTARMPMMusicGetSpeedPv+0x2864>
    d514:      	ldrb	w8, [x19, #0x30]
    d518:      	cbz	w8, 0xd554 <_Z20MTARMPMMusicGetSpeedPv+0x2858>
    d51c:      	ldr	x8, [x19, #0x20]
    d520:      	strb	wzr, [x8, #0x174]
    d524:      	strb	wzr, [x8, #0x220]
    d528:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    d52c:      	cmp	w0, #0x2
    d530:      	b.gt	0xd560 <_Z20MTARMPMMusicGetSpeedPv+0x2864>
    d534:      	nop
    d538:      	adr	x1, 0x52f1
    d53c:      	adrp	x2, 0x5000
    d540:      	add	x2, x2, #0xe43
    d544:      	mov	w0, #0x3                // =3
    d548:      	ldr	x19, [sp, #0x10]
    d54c:      	ldp	x29, x30, [sp], #0x20
    d550:      	b	0x16e90 <__android_log_print@plt>
    d554:      	ldrb	w1, [x0, #0x20]
    d558:      	bl	0xb39c <_Z20MTARMPMMusicGetSpeedPv+0x6a0>
    d55c:      	cbz	w0, 0xd56c <_Z20MTARMPMMusicGetSpeedPv+0x2870>
    d560:      	ldr	x19, [sp, #0x10]
    d564:      	ldp	x29, x30, [sp], #0x20
    d568:      	ret
    d56c:      	mov	w8, #0x1                // =1
    d570:      	strb	w8, [x19, #0x30]
    d574:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    d578:      	cmp	w0, #0x2
    d57c:      	b.gt	0xd51c <_Z20MTARMPMMusicGetSpeedPv+0x2820>
    d580:      	nop
    d584:      	adr	x1, 0x52f1
    d588:      	adrp	x2, 0x5000
    d58c:      	add	x2, x2, #0xd6e
    d590:      	mov	w0, #0x3                // =3
    d594:      	bl	0x16e90 <__android_log_print@plt>
    d598:      	b	0xd51c <_Z20MTARMPMMusicGetSpeedPv+0x2820>
    d59c:      	stp	x29, x30, [sp, #-0x20]!
    d5a0:      	str	x19, [sp, #0x10]
    d5a4:      	mov	x29, sp
    d5a8:      	ldr	x0, [x0, #0x20]
    d5ac:      	cbz	x0, 0xd5ec <_Z20MTARMPMMusicGetSpeedPv+0x28f0>
    d5b0:      	mov	w19, w1
    d5b4:      	and	w1, w1, #0x1
    d5b8:      	bl	0xba94 <_Z20MTARMPMMusicGetSpeedPv+0xd98>
    d5bc:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    d5c0:      	cmp	w0, #0x2
    d5c4:      	b.gt	0xd5ec <_Z20MTARMPMMusicGetSpeedPv+0x28f0>
    d5c8:      	nop
    d5cc:      	adr	x1, 0x52f1
    d5d0:      	adrp	x2, 0x4000
    d5d4:      	add	x2, x2, #0x8cb
    d5d8:      	and	w3, w19, #0x1
    d5dc:      	mov	w0, #0x3                // =3
    d5e0:      	ldr	x19, [sp, #0x10]
    d5e4:      	ldp	x29, x30, [sp], #0x20
    d5e8:      	b	0x16e90 <__android_log_print@plt>
    d5ec:      	ldr	x19, [sp, #0x10]
    d5f0:      	ldp	x29, x30, [sp], #0x20
    d5f4:      	ret
    d5f8:      	str	d8, [sp, #-0x20]!
    d5fc:      	stp	x29, x30, [sp, #0x10]
    d600:      	add	x29, sp, #0x10
    d604:      	ldr	x8, [x0, #0x20]
    d608:      	cbz	x8, 0xd648 <_Z20MTARMPMMusicGetSpeedPv+0x294c>
    d60c:      	fmov	s8, s0
    d610:      	str	s0, [x8, #0x128]
    d614:      	str	s0, [x0, #0x34]
    d618:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    d61c:      	cmp	w0, #0x2
    d620:      	b.gt	0xd648 <_Z20MTARMPMMusicGetSpeedPv+0x294c>
    d624:      	fcvt	d0, s8
    d628:      	nop
    d62c:      	adr	x1, 0x52f1
    d630:      	adrp	x2, 0x5000
    d634:      	add	x2, x2, #0x30a
    d638:      	mov	w0, #0x3                // =3
    d63c:      	ldp	x29, x30, [sp, #0x10]
    d640:      	ldr	d8, [sp], #0x20
    d644:      	b	0x16e90 <__android_log_print@plt>
    d648:      	ldp	x29, x30, [sp, #0x10]
    d64c:      	ldr	d8, [sp], #0x20
    d650:      	ret
    d654:      	ldr	s0, [x0, #0x34]
    d658:      	ret
    d65c:      	stp	x29, x30, [sp, #-0x20]!
    d660:      	str	x19, [sp, #0x10]
    d664:      	mov	x29, sp
    d668:      	mov	x19, x0
    d66c:      	ldr	x0, [x0, #0x20]
    d670:      	cbz	x0, 0xd6a8 <_Z20MTARMPMMusicGetSpeedPv+0x29ac>
    d674:      	bl	0xc8b4 <_Z20MTARMPMMusicGetSpeedPv+0x1bb8>
    d678:      	strb	wzr, [x19, #0x30]
    d67c:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    d680:      	cmp	w0, #0x2
    d684:      	b.gt	0xd6a8 <_Z20MTARMPMMusicGetSpeedPv+0x29ac>
    d688:      	nop
    d68c:      	adr	x1, 0x52f1
    d690:      	adrp	x2, 0x4000
    d694:      	add	x2, x2, #0xd89
    d698:      	mov	w0, #0x3                // =3
    d69c:      	ldr	x19, [sp, #0x10]
    d6a0:      	ldp	x29, x30, [sp], #0x20
    d6a4:      	b	0x16e90 <__android_log_print@plt>
    d6a8:      	ldr	x19, [sp, #0x10]
    d6ac:      	ldp	x29, x30, [sp], #0x20
    d6b0:      	ret
    d6b4:      	str	d8, [sp, #-0x20]!
    d6b8:      	stp	x29, x30, [sp, #0x8]
    d6bc:      	str	x19, [sp, #0x18]
    d6c0:      	add	x29, sp, #0x8
    d6c4:      	ldr	x8, [x0, #0x20]
    d6c8:      	cbz	x8, 0xd778 <_Z20MTARMPMMusicGetSpeedPv+0x2a7c>
    d6cc:      	mov	x19, x0
    d6d0:      	fmov	s8, s0
    d6d4:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    d6d8:      	cmp	w0, #0x2
    d6dc:      	b.gt	0xd6f8 <_Z20MTARMPMMusicGetSpeedPv+0x29fc>
    d6e0:      	nop
    d6e4:      	adr	x1, 0x52f1
    d6e8:      	adrp	x2, 0x5000
    d6ec:      	add	x2, x2, #0x1e7
    d6f0:      	mov	w0, #0x3                // =3
    d6f4:      	bl	0x16e90 <__android_log_print@plt>
    d6f8:      	ldrb	w8, [x19, #0x30]
    d6fc:      	cbnz	w8, 0xd72c <_Z20MTARMPMMusicGetSpeedPv+0x2a30>
    d700:      	ldr	x8, [x19, #0x10]
    d704:      	ldr	x0, [x19, #0x20]
    d708:      	mov	w1, wzr
    d70c:      	cbz	x8, 0xd720 <_Z20MTARMPMMusicGetSpeedPv+0x2a24>
    d710:      	cbz	x0, 0xd720 <_Z20MTARMPMMusicGetSpeedPv+0x2a24>
    d714:      	ldrb	w8, [x0, #0x20]
    d718:      	cmp	w8, #0x0
    d71c:      	cset	w1, ne
    d720:      	bl	0xb39c <_Z20MTARMPMMusicGetSpeedPv+0x6a0>
    d724:      	mov	w8, #0x1                // =1
    d728:      	strb	w8, [x19, #0x30]
    d72c:      	mov	w8, #0x447a0000         // =1148846080
    d730:      	ldr	x0, [x19, #0x20]
    d734:      	fmov	s0, w8
    d738:      	fmul	s0, s8, s0
    d73c:      	fcvtzs	w1, s0
    d740:      	bl	0xc8e8 <_Z20MTARMPMMusicGetSpeedPv+0x1bec>
    d744:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    d748:      	cmp	w0, #0x2
    d74c:      	b.gt	0xd778 <_Z20MTARMPMMusicGetSpeedPv+0x2a7c>
    d750:      	fcvt	d0, s8
    d754:      	nop
    d758:      	adr	x1, 0x52f1
    d75c:      	adrp	x2, 0x5000
    d760:      	add	x2, x2, #0xad7
    d764:      	mov	w0, #0x3                // =3
    d768:      	ldp	x29, x30, [sp, #0x8]
    d76c:      	ldr	x19, [sp, #0x18]
    d770:      	ldr	d8, [sp], #0x20
    d774:      	b	0x16e90 <__android_log_print@plt>
    d778:      	ldp	x29, x30, [sp, #0x8]
    d77c:      	ldr	x19, [sp, #0x18]
    d780:      	ldr	d8, [sp], #0x20
    d784:      	ret
    d788:      	ldr	x0, [x0, #0x20]
    d78c:      	cbz	x0, 0xd7b4 <_Z20MTARMPMMusicGetSpeedPv+0x2ab8>
    d790:      	stp	x29, x30, [sp, #-0x10]!
    d794:      	mov	x29, sp
    d798:      	bl	0xc7f8 <_Z20MTARMPMMusicGetSpeedPv+0x1afc>
    d79c:      	scvtf	s0, w0
    d7a0:      	mov	w8, #0x447a0000         // =1148846080
    d7a4:      	fmov	s1, w8
    d7a8:      	fdiv	s0, s0, s1
    d7ac:      	ldp	x29, x30, [sp], #0x10
    d7b0:      	ret
    d7b4:      	fmov	s0, #-1.00000000
    d7b8:      	ret
    d7bc:      	str	d8, [sp, #-0x20]!
    d7c0:      	stp	x29, x30, [sp, #0x8]
    d7c4:      	str	x19, [sp, #0x18]
    d7c8:      	add	x29, sp, #0x8
    d7cc:      	ldr	x8, [x0, #0x20]
    d7d0:      	cbz	x8, 0xd8c8 <_Z20MTARMPMMusicGetSpeedPv+0x2bcc>
    d7d4:      	mov	x19, x0
    d7d8:      	fmov	s8, s0
    d7dc:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    d7e0:      	fmov	s0, #0.25000000
    d7e4:      	fcmp	s8, s0
    d7e8:      	b.mi	0xd858 <_Z20MTARMPMMusicGetSpeedPv+0x2b5c>
    d7ec:      	fmov	s0, #4.00000000
    d7f0:      	fcmp	s8, s0
    d7f4:      	b.gt	0xd858 <_Z20MTARMPMMusicGetSpeedPv+0x2b5c>
    d7f8:      	cmp	w0, #0x2
    d7fc:      	b.gt	0xd818 <_Z20MTARMPMMusicGetSpeedPv+0x2b1c>
    d800:      	nop
    d804:      	adr	x1, 0x52f1
    d808:      	adrp	x2, 0x5000
    d80c:      	add	x2, x2, #0xa14
    d810:      	mov	w0, #0x3                // =3
    d814:      	bl	0x16e90 <__android_log_print@plt>
    d818:      	fcvt	d8, s8
    d81c:      	ldrb	w8, [x19, #0x30]
    d820:      	cbz	w8, 0xd838 <_Z20MTARMPMMusicGetSpeedPv+0x2b3c>
    d824:      	ldr	x0, [x19, #0x20]
    d828:      	bl	0xba5c <_Z20MTARMPMMusicGetSpeedPv+0xd60>
    d82c:      	ldr	x0, [x19, #0x20]
    d830:      	bl	0xc8b4 <_Z20MTARMPMMusicGetSpeedPv+0x1bb8>
    d834:      	strb	wzr, [x19, #0x30]
    d838:      	ldr	x0, [x19, #0x20]
    d83c:      	ldr	x8, [x19, #0x10]
    d840:      	str	d8, [x0, #0x1e0]
    d844:      	cbz	x8, 0xd884 <_Z20MTARMPMMusicGetSpeedPv+0x2b88>
    d848:      	ldrb	w8, [x0, #0x20]
    d84c:      	cmp	w8, #0x0
    d850:      	cset	w1, ne
    d854:      	b	0xd888 <_Z20MTARMPMMusicGetSpeedPv+0x2b8c>
    d858:      	cmp	w0, #0x4
    d85c:      	b.gt	0xd8c8 <_Z20MTARMPMMusicGetSpeedPv+0x2bcc>
    d860:      	nop
    d864:      	adr	x1, 0x52f1
    d868:      	adrp	x2, 0x4000
    d86c:      	add	x2, x2, #0x5bd
    d870:      	mov	w0, #0x5                // =5
    d874:      	ldp	x29, x30, [sp, #0x8]
    d878:      	ldr	x19, [sp, #0x18]
    d87c:      	ldr	d8, [sp], #0x20
    d880:      	b	0x16e90 <__android_log_print@plt>
    d884:      	mov	w1, wzr
    d888:      	bl	0xb39c <_Z20MTARMPMMusicGetSpeedPv+0x6a0>
    d88c:      	mov	w8, #0x1                // =1
    d890:      	strb	w8, [x19, #0x30]
    d894:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    d898:      	cmp	w0, #0x2
    d89c:      	b.gt	0xd8c8 <_Z20MTARMPMMusicGetSpeedPv+0x2bcc>
    d8a0:      	nop
    d8a4:      	adr	x1, 0x52f1
    d8a8:      	adrp	x2, 0x5000
    d8ac:      	add	x2, x2, #0xcf2
    d8b0:      	mov	w0, #0x3                // =3
    d8b4:      	fmov	d0, d8
    d8b8:      	ldp	x29, x30, [sp, #0x8]
    d8bc:      	ldr	x19, [sp, #0x18]
    d8c0:      	ldr	d8, [sp], #0x20
    d8c4:      	b	0x16e90 <__android_log_print@plt>
    d8c8:      	ldp	x29, x30, [sp, #0x8]
    d8cc:      	ldr	x19, [sp, #0x18]
    d8d0:      	ldr	d8, [sp], #0x20
    d8d4:      	ret
    d8d8:      	ldr	x8, [x0, #0x20]
    d8dc:      	cbz	x8, 0xd8ec <_Z20MTARMPMMusicGetSpeedPv+0x2bf0>
    d8e0:      	ldr	d0, [x8, #0x1e0]
    d8e4:      	fcvt	s0, d0
    d8e8:      	ret
    d8ec:      	fmov	s0, #1.00000000
    d8f0:      	ret
    d8f4:      	str	d8, [sp, #-0x20]!
    d8f8:      	stp	x29, x30, [sp, #0x8]
    d8fc:      	str	x19, [sp, #0x18]
    d900:      	add	x29, sp, #0x8
    d904:      	fmov	s8, #-1.00000000
    d908:      	mov	x19, x0
    d90c:      	ldr	x0, [x0, #0x20]
    d910:      	cbz	x0, 0xd95c <_Z20MTARMPMMusicGetSpeedPv+0x2c60>
    d914:      	ldrb	w8, [x19, #0x30]
    d918:      	cbz	w8, 0xd938 <_Z20MTARMPMMusicGetSpeedPv+0x2c3c>
    d91c:      	ldr	x0, [x19, #0x20]
    d920:      	bl	0xca28 <_Z20MTARMPMMusicGetSpeedPv+0x1d2c>
    d924:      	scvtf	s0, w0
    d928:      	mov	w8, #0x447a0000         // =1148846080
    d92c:      	fmov	s1, w8
    d930:      	fdiv	s8, s0, s1
    d934:      	b	0xd95c <_Z20MTARMPMMusicGetSpeedPv+0x2c60>
    d938:      	ldr	x8, [x19, #0x10]
    d93c:      	cbz	x8, 0xd950 <_Z20MTARMPMMusicGetSpeedPv+0x2c54>
    d940:      	ldrb	w8, [x0, #0x20]
    d944:      	cmp	w8, #0x0
    d948:      	cset	w1, ne
    d94c:      	b	0xd954 <_Z20MTARMPMMusicGetSpeedPv+0x2c58>
    d950:      	mov	w1, wzr
    d954:      	bl	0xb39c <_Z20MTARMPMMusicGetSpeedPv+0x6a0>
    d958:      	cbz	w0, 0xd970 <_Z20MTARMPMMusicGetSpeedPv+0x2c74>
    d95c:      	fmov	s0, s8
    d960:      	ldp	x29, x30, [sp, #0x8]
    d964:      	ldr	x19, [sp, #0x18]
    d968:      	ldr	d8, [sp], #0x20
    d96c:      	ret
    d970:      	mov	w8, #0x1                // =1
    d974:      	strb	w8, [x19, #0x30]
    d978:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    d97c:      	cmp	w0, #0x2
    d980:      	b.gt	0xd91c <_Z20MTARMPMMusicGetSpeedPv+0x2c20>
    d984:      	nop
    d988:      	adr	x1, 0x52f1
    d98c:      	adrp	x2, 0x5000
    d990:      	add	x2, x2, #0xd6e
    d994:      	mov	w0, #0x3                // =3
    d998:      	bl	0x16e90 <__android_log_print@plt>
    d99c:      	b	0xd91c <_Z20MTARMPMMusicGetSpeedPv+0x2c20>
    d9a0:      	b	0xd9a4 <_Z20MTARMPMMusicGetSpeedPv+0x2ca8>
    d9a4:      	sub	sp, sp, #0x60
    d9a8:      	stp	x29, x30, [sp, #0x20]
    d9ac:      	str	x23, [sp, #0x30]
    d9b0:      	stp	x22, x21, [sp, #0x40]
    d9b4:      	stp	x20, x19, [sp, #0x50]
    d9b8:      	add	x29, sp, #0x20
    d9bc:      	mrs	x23, TPIDR_EL0
    d9c0:      	mov	x21, x0
    d9c4:      	add	x0, x0, #0x38
    d9c8:      	ldr	x8, [x23, #0x28]
    d9cc:      	mov	x19, x2
    d9d0:      	mov	x20, x1
    d9d4:      	stur	x8, [x29, #-0x8]
    d9d8:      	bl	0xdc00 <_Z20MTARMPMMusicGetSpeedPv+0x2f04>
    d9dc:      	add	x8, x21, #0x40
    d9e0:      	cmp	x8, x0
    d9e4:      	b.eq	0xda08 <_Z20MTARMPMMusicGetSpeedPv+0x2d0c>
    d9e8:      	mov	x22, x0
    d9ec:      	add	x0, x21, #0x38
    d9f0:      	mov	x1, x22
    d9f4:      	bl	0xdfac <_Z20MTARMPMMusicGetSpeedPv+0x32b0>
    d9f8:      	add	x0, x22, #0x20
    d9fc:      	bl	0xdaac <_Z20MTARMPMMusicGetSpeedPv+0x2db0>
    da00:      	mov	x0, x22
    da04:      	bl	0x16b60 <_ZdlPv@plt>
    da08:      	nop
    da0c:      	adr	x2, 0x5f27 <_ZTSNSt6__ndk117bad_function_callE+0x1f>
    da10:      	add	x0, x21, #0x38
    da14:      	add	x3, sp, #0x10
    da18:      	add	x4, sp, #0xf
    da1c:      	mov	x1, x20
    da20:      	str	x20, [sp, #0x10]
    da24:      	bl	0xe388 <_Z20MTARMPMMusicGetSpeedPv+0x368c>
    da28:      	add	x0, x0, #0x40
    da2c:      	mov	x1, x19
    da30:      	bl	0xe7a8 <_Z20MTARMPMMusicGetSpeedPv+0x3aac>
    da34:      	ldr	x8, [x23, #0x28]
    da38:      	ldur	x9, [x29, #-0x8]
    da3c:      	cmp	x8, x9
    da40:      	b.ne	0xda5c <_Z20MTARMPMMusicGetSpeedPv+0x2d60>
    da44:      	ldp	x20, x19, [sp, #0x50]
    da48:      	ldr	x23, [sp, #0x30]
    da4c:      	ldp	x22, x21, [sp, #0x40]
    da50:      	ldp	x29, x30, [sp, #0x20]
    da54:      	add	sp, sp, #0x60
    da58:      	ret
    da5c:      	bl	0x16b40 <__stack_chk_fail@plt>
    da60:      	bl	0xad14 <_Z20MTARMPMMusicGetSpeedPv+0x18>
    da64:      	cbz	x1, 0xdaa8 <_Z20MTARMPMMusicGetSpeedPv+0x2dac>
    da68:      	stp	x29, x30, [sp, #-0x20]!
    da6c:      	stp	x20, x19, [sp, #0x10]
    da70:      	mov	x29, sp
    da74:      	mov	x19, x1
    da78:      	ldr	x1, [x1]
    da7c:      	mov	x20, x0
    da80:      	bl	0xda64 <_Z20MTARMPMMusicGetSpeedPv+0x2d68>
    da84:      	ldr	x1, [x19, #0x8]
    da88:      	mov	x0, x20
    da8c:      	bl	0xda64 <_Z20MTARMPMMusicGetSpeedPv+0x2d68>
    da90:      	add	x0, x19, #0x20
    da94:      	bl	0xdaac <_Z20MTARMPMMusicGetSpeedPv+0x2db0>
    da98:      	mov	x0, x19
    da9c:      	ldp	x20, x19, [sp, #0x10]
    daa0:      	ldp	x29, x30, [sp], #0x20
    daa4:      	b	0x16b60 <_ZdlPv@plt>
    daa8:      	ret
    daac:      	stp	x29, x30, [sp, #-0x20]!
    dab0:      	str	x19, [sp, #0x10]
    dab4:      	mov	x29, sp
    dab8:      	mov	x19, x0
    dabc:      	ldr	x0, [x0, #0x40]
    dac0:      	add	x9, x19, #0x20
    dac4:      	cmp	x0, x9
    dac8:      	b.eq	0xdad8 <_Z20MTARMPMMusicGetSpeedPv+0x2ddc>
    dacc:      	cbz	x0, 0xdaec <_Z20MTARMPMMusicGetSpeedPv+0x2df0>
    dad0:      	mov	w8, #0x5                // =5
    dad4:      	b	0xdae0 <_Z20MTARMPMMusicGetSpeedPv+0x2de4>
    dad8:      	mov	w8, #0x4                // =4
    dadc:      	mov	x0, x9
    dae0:      	ldr	x9, [x0]
    dae4:      	ldr	x8, [x9, x8, lsl #3]
    dae8:      	blr	x8
    daec:      	ldrb	w8, [x19]
    daf0:      	tbnz	w8, #0x0, 0xdb00 <_Z20MTARMPMMusicGetSpeedPv+0x2e04>
    daf4:      	ldr	x19, [sp, #0x10]
    daf8:      	ldp	x29, x30, [sp], #0x20
    dafc:      	ret
    db00:      	ldr	x0, [x19, #0x10]
    db04:      	ldr	x19, [sp, #0x10]
    db08:      	ldp	x29, x30, [sp], #0x20
    db0c:      	b	0x16b60 <_ZdlPv@plt>
    db10:      	stp	x29, x30, [sp, #-0x30]!
    db14:      	str	x21, [sp, #0x10]
    db18:      	stp	x20, x19, [sp, #0x20]
    db1c:      	mov	x29, sp
    db20:      	mov	w0, #0x250              // =592
    db24:      	mov	x21, x1
    db28:      	mov	x19, x8
    db2c:      	bl	0x16b50 <_Znwm@plt>
    db30:      	mov	x20, x0
    db34:      	mov	x2, x21
    db38:      	bl	0xdb68 <_Z20MTARMPMMusicGetSpeedPv+0x2e6c>
    db3c:      	add	x8, x20, #0x20
    db40:      	stp	x8, x20, [x19]
    db44:      	ldp	x20, x19, [sp, #0x20]
    db48:      	ldr	x21, [sp, #0x10]
    db4c:      	ldp	x29, x30, [sp], #0x30
    db50:      	ret
    db54:      	mov	x19, x0
    db58:      	mov	x0, x20
    db5c:      	bl	0x16b60 <_ZdlPv@plt>
    db60:      	mov	x0, x19
    db64:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    db68:      	stp	x29, x30, [sp, #-0x20]!
    db6c:      	stp	x20, x19, [sp, #0x10]
    db70:      	mov	x29, sp
    db74:      	mov	x1, x2
    db78:      	mov	x19, x0
    db7c:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    db80:      	add	x8, x8, #0x468
    db84:      	stp	xzr, xzr, [x0, #0x8]
    db88:      	str	x8, [x0], #0x20
    db8c:      	bl	0xb078 <_Z20MTARMPMMusicGetSpeedPv+0x37c>
    db90:      	ldp	x20, x19, [sp, #0x10]
    db94:      	ldp	x29, x30, [sp], #0x20
    db98:      	ret
    db9c:      	mov	x20, x0
    dba0:      	mov	x0, x19
    dba4:      	bl	0x16e50 <_ZNSt6__ndk119__shared_weak_countD2Ev@plt>
    dba8:      	mov	x0, x20
    dbac:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    dbb0:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    dbb4:      	add	x8, x8, #0x468
    dbb8:      	str	x8, [x0]
    dbbc:      	b	0x16e50 <_ZNSt6__ndk119__shared_weak_countD2Ev@plt>
    dbc0:      	stp	x29, x30, [sp, #-0x20]!
    dbc4:      	str	x19, [sp, #0x10]
    dbc8:      	mov	x29, sp
    dbcc:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    dbd0:      	add	x8, x8, #0x468
    dbd4:      	mov	x19, x0
    dbd8:      	str	x8, [x0]
    dbdc:      	bl	0x16e50 <_ZNSt6__ndk119__shared_weak_countD2Ev@plt>
    dbe0:      	mov	x0, x19
    dbe4:      	ldr	x19, [sp, #0x10]
    dbe8:      	ldp	x29, x30, [sp], #0x20
    dbec:      	b	0x16b60 <_ZdlPv@plt>
    dbf0:      	ldr	x8, [x0, #0x20]!
    dbf4:      	ldr	x1, [x8]
    dbf8:      	br	x1
    dbfc:      	b	0x16b60 <_ZdlPv@plt>
    dc00:      	stp	x29, x30, [sp, #-0x40]!
    dc04:      	str	x23, [sp, #0x10]
    dc08:      	stp	x22, x21, [sp, #0x20]
    dc0c:      	stp	x20, x19, [sp, #0x30]
    dc10:      	mov	x29, sp
    dc14:      	mov	x19, x0
    dc18:      	ldr	x23, [x19, #0x8]!
    dc1c:      	cbz	x23, 0xdc74 <_Z20MTARMPMMusicGetSpeedPv+0x2f78>
    dc20:      	mov	x20, x0
    dc24:      	mov	x21, x1
    dc28:      	mov	x22, x19
    dc2c:      	add	x0, x20, #0x10
    dc30:      	add	x1, x23, #0x20
    dc34:      	mov	x2, x21
    dc38:      	bl	0xdc8c <_Z20MTARMPMMusicGetSpeedPv+0x2f90>
    dc3c:      	add	x8, x23, #0x8
    dc40:      	tst	w0, #0x1
    dc44:      	csel	x8, x8, x23, ne
    dc48:      	csel	x22, x22, x23, ne
    dc4c:      	ldr	x23, [x8]
    dc50:      	cbnz	x23, 0xdc2c <_Z20MTARMPMMusicGetSpeedPv+0x2f30>
    dc54:      	cmp	x22, x19
    dc58:      	b.eq	0xdc74 <_Z20MTARMPMMusicGetSpeedPv+0x2f78>
    dc5c:      	add	x0, x20, #0x10
    dc60:      	add	x2, x22, #0x20
    dc64:      	mov	x1, x21
    dc68:      	bl	0xdc8c <_Z20MTARMPMMusicGetSpeedPv+0x2f90>
    dc6c:      	tst	w0, #0x1
    dc70:      	csel	x19, x19, x22, ne
    dc74:      	mov	x0, x19
    dc78:      	ldp	x20, x19, [sp, #0x30]
    dc7c:      	ldr	x23, [sp, #0x10]
    dc80:      	ldp	x22, x21, [sp, #0x20]
    dc84:      	ldp	x29, x30, [sp], #0x40
    dc88:      	ret
    dc8c:      	stp	x29, x30, [sp, #-0x20]!
    dc90:      	stp	x20, x19, [sp, #0x10]
    dc94:      	mov	x29, sp
    dc98:      	ldrb	w8, [x2]
    dc9c:      	ldp	x11, x10, [x2, #0x8]
    dca0:      	ldrb	w9, [x1]
    dca4:      	lsr	x12, x8, #1
    dca8:      	tst	w8, #0x1
    dcac:      	csinc	x8, x10, x2, ne
    dcb0:      	lsr	x10, x9, #1
    dcb4:      	csel	x19, x12, x11, eq
    dcb8:      	tst	w9, #0x1
    dcbc:      	ldp	x13, x9, [x1, #0x8]
    dcc0:      	csel	x20, x10, x13, eq
    dcc4:      	csinc	x0, x9, x1, ne
    dcc8:      	mov	x1, x8
    dccc:      	cmp	x19, x20
    dcd0:      	csel	x2, x19, x20, lo
    dcd4:      	bl	0x17080 <memcmp@plt>
    dcd8:      	cmp	x20, x19
    dcdc:      	cset	w8, lo
    dce0:      	cmp	w0, #0x0
    dce4:      	cset	w9, lt
    dce8:      	csel	w0, w8, w9, eq
    dcec:      	ldp	x20, x19, [sp, #0x10]
    dcf0:      	ldp	x29, x30, [sp], #0x20
    dcf4:      	ret
    dcf8:      	ret
    dcfc:      	b	0x16b60 <_ZdlPv@plt>
    dd00:      	stp	x29, x30, [sp, #-0x20]!
    dd04:      	str	x19, [sp, #0x10]
    dd08:      	mov	x29, sp
    dd0c:      	mov	x19, x0
    dd10:      	mov	w0, #0x10               // =16
    dd14:      	bl	0x16b50 <_Znwm@plt>
    dd18:      	ldr	x9, [x19, #0x8]
    dd1c:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    dd20:      	add	x8, x8, #0x4a0
    dd24:      	stp	x8, x9, [x0]
    dd28:      	ldr	x19, [sp, #0x10]
    dd2c:      	ldp	x29, x30, [sp], #0x20
    dd30:      	ret
    dd34:      	ldr	x8, [x0, #0x8]
    dd38:      	adrp	x9, 0x1b000 <syscall@plt+0x3d00>
    dd3c:      	add	x9, x9, #0x4a0
    dd40:      	stp	x9, x8, [x1]
    dd44:      	ret
    dd48:      	ret
    dd4c:      	b	0x16b60 <_ZdlPv@plt>
    dd50:      	sub	sp, sp, #0x50
    dd54:      	stp	x29, x30, [sp, #0x20]
    dd58:      	str	x21, [sp, #0x30]
    dd5c:      	stp	x20, x19, [sp, #0x40]
    dd60:      	add	x29, sp, #0x20
    dd64:      	mrs	x20, TPIDR_EL0
    dd68:      	ldr	x8, [x20, #0x28]
    dd6c:      	stur	x8, [x29, #-0x8]
    dd70:      	ldrb	w8, [x1]
    dd74:      	ldr	x9, [x1, #0x8]
    dd78:      	lsr	x10, x8, #1
    dd7c:      	tst	w8, #0x1
    dd80:      	csel	x9, x10, x9, eq
    dd84:      	cmp	x9, #0x7
    dd88:      	b.ne	0xde18 <_Z20MTARMPMMusicGetSpeedPv+0x311c>
    dd8c:      	ldr	x9, [x1, #0x10]
    dd90:      	tst	w8, #0x1
    dd94:      	mov	w10, #0x7473            // =29811
    dd98:      	movk	w10, #0x7261, lsl #16
    dd9c:      	csinc	x8, x9, x1, ne
    dda0:      	ldr	w9, [x8]
    dda4:      	ldur	w8, [x8, #0x3]
    dda8:      	cmp	w9, w10
    ddac:      	mov	w9, #0x7472             // =29810
    ddb0:      	movk	w9, #0x6465, lsl #16
    ddb4:      	ccmp	w8, w9, #0x0, eq
    ddb8:      	b.ne	0xde18 <_Z20MTARMPMMusicGetSpeedPv+0x311c>
    ddbc:      	ldr	x21, [x0, #0x8]
    ddc0:      	adrp	x1, 0x4000
    ddc4:      	add	x1, x1, #0x7ea
    ddc8:      	mov	x0, sp
    ddcc:      	bl	0xa90c <_Z16MTARMPMMusicLoadPvPKc+0x1a4>
    ddd0:      	add	x0, x21, #0x38
    ddd4:      	mov	x1, sp
    ddd8:      	bl	0xdc00 <_Z20MTARMPMMusicGetSpeedPv+0x2f04>
    dddc:      	ldrb	w8, [sp]
    dde0:      	mov	x19, x0
    dde4:      	tbz	w8, #0x0, 0xddf0 <_Z20MTARMPMMusicGetSpeedPv+0x30f4>
    dde8:      	ldr	x0, [sp, #0x10]
    ddec:      	bl	0x16b60 <_ZdlPv@plt>
    ddf0:      	add	x8, x21, #0x40
    ddf4:      	cmp	x8, x19
    ddf8:      	b.eq	0xde18 <_Z20MTARMPMMusicGetSpeedPv+0x311c>
    ddfc:      	ldr	x0, [x19, #0x60]
    de00:      	str	x21, [sp]
    de04:      	cbz	x0, 0xde3c <_Z20MTARMPMMusicGetSpeedPv+0x3140>
    de08:      	ldr	x8, [x0]
    de0c:      	mov	x1, sp
    de10:      	ldr	x8, [x8, #0x30]
    de14:      	blr	x8
    de18:      	ldr	x8, [x20, #0x28]
    de1c:      	ldur	x9, [x29, #-0x8]
    de20:      	cmp	x8, x9
    de24:      	b.ne	0xde7c <_Z20MTARMPMMusicGetSpeedPv+0x3180>
    de28:      	ldp	x20, x19, [sp, #0x40]
    de2c:      	ldr	x21, [sp, #0x30]
    de30:      	ldp	x29, x30, [sp, #0x20]
    de34:      	add	sp, sp, #0x50
    de38:      	ret
    de3c:      	ldr	x8, [x20, #0x28]
    de40:      	ldur	x9, [x29, #-0x8]
    de44:      	cmp	x8, x9
    de48:      	b.ne	0xde7c <_Z20MTARMPMMusicGetSpeedPv+0x3180>
    de4c:      	bl	0xcad8 <_Z20MTARMPMMusicGetSpeedPv+0x1ddc>
    de50:      	ldrb	w8, [sp]
    de54:      	mov	x19, x0
    de58:      	tbz	w8, #0x0, 0xde64 <_Z20MTARMPMMusicGetSpeedPv+0x3168>
    de5c:      	ldr	x0, [sp, #0x10]
    de60:      	bl	0x16b60 <_ZdlPv@plt>
    de64:      	ldr	x8, [x20, #0x28]
    de68:      	ldur	x9, [x29, #-0x8]
    de6c:      	cmp	x8, x9
    de70:      	b.ne	0xde7c <_Z20MTARMPMMusicGetSpeedPv+0x3180>
    de74:      	mov	x0, x19
    de78:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    de7c:      	bl	0x16b40 <__stack_chk_fail@plt>
    de80:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    de84:      	add	x8, x8, #0x4e8
    de88:      	str	x8, [x0], #0x18
    de8c:      	b	0xd19c <_Z20MTARMPMMusicGetSpeedPv+0x24a0>
    de90:      	stp	x29, x30, [sp, #-0x20]!
    de94:      	str	x19, [sp, #0x10]
    de98:      	mov	x29, sp
    de9c:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    dea0:      	add	x8, x8, #0x4e8
    dea4:      	mov	x19, x0
    dea8:      	str	x8, [x0], #0x18
    deac:      	bl	0xd19c <_Z20MTARMPMMusicGetSpeedPv+0x24a0>
    deb0:      	mov	x0, x19
    deb4:      	ldr	x19, [sp, #0x10]
    deb8:      	ldp	x29, x30, [sp], #0x20
    debc:      	b	0x16b60 <_ZdlPv@plt>
    dec0:      	stp	x29, x30, [sp, #-0x20]!
    dec4:      	stp	x20, x19, [sp, #0x10]
    dec8:      	mov	x29, sp
    decc:      	mov	x20, x0
    ded0:      	mov	w0, #0x28               // =40
    ded4:      	bl	0x16b50 <_Znwm@plt>
    ded8:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    dedc:      	add	x8, x8, #0x4e8
    dee0:      	ldur	q0, [x20, #0x8]
    dee4:      	str	x8, [x0]
    dee8:      	ldp	x9, x8, [x20, #0x18]
    deec:      	mov	x19, x0
    def0:      	stur	q0, [x0, #0x8]
    def4:      	stp	x9, x8, [x0, #0x18]
    def8:      	cbz	x8, 0xdf08 <_Z20MTARMPMMusicGetSpeedPv+0x320c>
    defc:      	add	x1, x8, #0x8
    df00:      	mov	w0, #0x1                // =1
    df04:      	bl	0x125c0 <_Z20MTARMPMMusicGetSpeedPv+0x78c4>
    df08:      	mov	x0, x19
    df0c:      	ldp	x20, x19, [sp, #0x10]
    df10:      	ldp	x29, x30, [sp], #0x20
    df14:      	ret
    df18:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    df1c:      	add	x8, x8, #0x4e8
    df20:      	ldur	q0, [x0, #0x8]
    df24:      	str	x8, [x1]
    df28:      	ldp	x9, x8, [x0, #0x18]
    df2c:      	stur	q0, [x1, #0x8]
    df30:      	stp	x9, x8, [x1, #0x18]
    df34:      	cbz	x8, 0xdf50 <_Z20MTARMPMMusicGetSpeedPv+0x3254>
    df38:      	stp	x29, x30, [sp, #-0x10]!
    df3c:      	mov	x29, sp
    df40:      	add	x1, x8, #0x8
    df44:      	mov	w0, #0x1                // =1
    df48:      	bl	0x125c0 <_Z20MTARMPMMusicGetSpeedPv+0x78c4>
    df4c:      	ldp	x29, x30, [sp], #0x10
    df50:      	ret
    df54:      	add	x0, x0, #0x18
    df58:      	b	0xd19c <_Z20MTARMPMMusicGetSpeedPv+0x24a0>
    df5c:      	stp	x29, x30, [sp, #-0x20]!
    df60:      	str	x19, [sp, #0x10]
    df64:      	mov	x29, sp
    df68:      	mov	x19, x0
    df6c:      	add	x0, x0, #0x18
    df70:      	bl	0xd19c <_Z20MTARMPMMusicGetSpeedPv+0x24a0>
    df74:      	mov	x0, x19
    df78:      	ldr	x19, [sp, #0x10]
    df7c:      	ldp	x29, x30, [sp], #0x20
    df80:      	b	0x16b60 <_ZdlPv@plt>
    df84:      	ldp	x9, x8, [x0, #0x10]
    df88:      	ldr	x3, [x0, #0x8]
    df8c:      	add	x0, x8, x9, asr #1
    df90:      	tbz	w9, #0x0, 0xdf9c <_Z20MTARMPMMusicGetSpeedPv+0x32a0>
    df94:      	ldr	x8, [x0]
    df98:      	ldr	x3, [x8, x3]
    df9c:      	ldr	w8, [x2]
    dfa0:      	ldr	x2, [x1]
    dfa4:      	mov	w1, w8
    dfa8:      	br	x3
    dfac:      	stp	x29, x30, [sp, #-0x20]!
    dfb0:      	str	x19, [sp, #0x10]
    dfb4:      	mov	x29, sp
    dfb8:      	ldr	x8, [x1, #0x8]
    dfbc:      	cbz	x8, 0xdfd0 <_Z20MTARMPMMusicGetSpeedPv+0x32d4>
    dfc0:      	mov	x19, x8
    dfc4:      	ldr	x8, [x8]
    dfc8:      	cbnz	x8, 0xdfc0 <_Z20MTARMPMMusicGetSpeedPv+0x32c4>
    dfcc:      	b	0xdfe8 <_Z20MTARMPMMusicGetSpeedPv+0x32ec>
    dfd0:      	mov	x8, x1
    dfd4:      	ldr	x19, [x8, #0x10]
    dfd8:      	ldr	x9, [x19]
    dfdc:      	cmp	x9, x8
    dfe0:      	mov	x8, x19
    dfe4:      	b.ne	0xdfd4 <_Z20MTARMPMMusicGetSpeedPv+0x32d8>
    dfe8:      	ldr	x8, [x0]
    dfec:      	cmp	x8, x1
    dff0:      	b.ne	0xdff8 <_Z20MTARMPMMusicGetSpeedPv+0x32fc>
    dff4:      	str	x19, [x0]
    dff8:      	ldp	x8, x9, [x0, #0x8]
    dffc:      	sub	x9, x9, #0x1
    e000:      	str	x9, [x0, #0x10]
    e004:      	mov	x0, x8
    e008:      	bl	0xe01c <_Z20MTARMPMMusicGetSpeedPv+0x3320>
    e00c:      	mov	x0, x19
    e010:      	ldr	x19, [sp, #0x10]
    e014:      	ldp	x29, x30, [sp], #0x20
    e018:      	ret
    e01c:      	ldr	x9, [x1]
    e020:      	mov	x10, x1
    e024:      	cbz	x9, 0xe03c <_Z20MTARMPMMusicGetSpeedPv+0x3340>
    e028:      	ldr	x8, [x1, #0x8]
    e02c:      	cbz	x8, 0xe050 <_Z20MTARMPMMusicGetSpeedPv+0x3354>
    e030:      	mov	x10, x8
    e034:      	ldr	x8, [x8]
    e038:      	cbnz	x8, 0xe030 <_Z20MTARMPMMusicGetSpeedPv+0x3334>
    e03c:      	ldr	x9, [x10, #0x8]
    e040:      	cbnz	x9, 0xe054 <_Z20MTARMPMMusicGetSpeedPv+0x3358>
    e044:      	ldr	x12, [x10, #0x10]
    e048:      	mov	w11, #0x1               // =1
    e04c:      	b	0xe060 <_Z20MTARMPMMusicGetSpeedPv+0x3364>
    e050:      	mov	x10, x1
    e054:      	ldr	x12, [x10, #0x10]
    e058:      	mov	w11, wzr
    e05c:      	str	x12, [x9, #0x10]
    e060:      	ldr	x8, [x12]
    e064:      	cmp	x8, x10
    e068:      	b.eq	0xe074 <_Z20MTARMPMMusicGetSpeedPv+0x3378>
    e06c:      	str	x9, [x12, #0x8]
    e070:      	b	0xe090 <_Z20MTARMPMMusicGetSpeedPv+0x3394>
    e074:      	cmp	x10, x0
    e078:      	str	x9, [x12]
    e07c:      	b.eq	0xe088 <_Z20MTARMPMMusicGetSpeedPv+0x338c>
    e080:      	ldr	x8, [x12, #0x8]
    e084:      	b	0xe090 <_Z20MTARMPMMusicGetSpeedPv+0x3394>
    e088:      	mov	x8, xzr
    e08c:      	mov	x0, x9
    e090:      	ldrb	w12, [x10, #0x18]
    e094:      	cmp	x10, x1
    e098:      	b.eq	0xe0d8 <_Z20MTARMPMMusicGetSpeedPv+0x33dc>
    e09c:      	ldr	x13, [x1, #0x10]
    e0a0:      	ldr	x14, [x13]
    e0a4:      	str	x13, [x10, #0x10]
    e0a8:      	cmp	x14, x1
    e0ac:      	cset	w14, ne
    e0b0:      	str	x10, [x13, w14, uxtw #3]
    e0b4:      	ldp	x14, x13, [x1]
    e0b8:      	str	x10, [x14, #0x10]
    e0bc:      	stp	x14, x13, [x10]
    e0c0:      	cbz	x13, 0xe0c8 <_Z20MTARMPMMusicGetSpeedPv+0x33cc>
    e0c4:      	str	x10, [x13, #0x10]
    e0c8:      	ldrb	w13, [x1, #0x18]
    e0cc:      	cmp	x0, x1
    e0d0:      	csel	x0, x10, x0, eq
    e0d4:      	strb	w13, [x10, #0x18]
    e0d8:      	cbz	w12, 0xe228 <_Z20MTARMPMMusicGetSpeedPv+0x352c>
    e0dc:      	cbz	x0, 0xe228 <_Z20MTARMPMMusicGetSpeedPv+0x352c>
    e0e0:      	cbz	w11, 0xe220 <_Z20MTARMPMMusicGetSpeedPv+0x3524>
    e0e4:      	mov	w9, #0x1                // =1
    e0e8:      	ldr	x10, [x8, #0x10]
    e0ec:      	ldrb	w11, [x8, #0x18]
    e0f0:      	ldr	x12, [x10]
    e0f4:      	cmp	x12, x8
    e0f8:      	b.eq	0xe188 <_Z20MTARMPMMusicGetSpeedPv+0x348c>
    e0fc:      	cbnz	w11, 0xe14c <_Z20MTARMPMMusicGetSpeedPv+0x3450>
    e100:      	ldr	x11, [x10, #0x8]
    e104:      	strb	w9, [x8, #0x18]
    e108:      	strb	wzr, [x10, #0x18]
    e10c:      	ldr	x12, [x11]
    e110:      	str	x12, [x10, #0x8]
    e114:      	cbz	x12, 0xe11c <_Z20MTARMPMMusicGetSpeedPv+0x3420>
    e118:      	str	x10, [x12, #0x10]
    e11c:      	ldr	x12, [x10, #0x10]
    e120:      	ldr	x13, [x12]
    e124:      	str	x12, [x11, #0x10]
    e128:      	cmp	x13, x10
    e12c:      	cset	w13, ne
    e130:      	str	x11, [x12, w13, uxtw #3]
    e134:      	str	x10, [x11]
    e138:      	ldr	x12, [x8]
    e13c:      	str	x11, [x10, #0x10]
    e140:      	cmp	x0, x12
    e144:      	csel	x0, x8, x0, eq
    e148:      	ldr	x8, [x12, #0x8]
    e14c:      	ldr	x10, [x8]
    e150:      	cbz	x10, 0xe15c <_Z20MTARMPMMusicGetSpeedPv+0x3460>
    e154:      	ldrb	w11, [x10, #0x18]
    e158:      	cbz	w11, 0xe23c <_Z20MTARMPMMusicGetSpeedPv+0x3540>
    e15c:      	ldr	x11, [x8, #0x8]
    e160:      	cbz	x11, 0xe16c <_Z20MTARMPMMusicGetSpeedPv+0x3470>
    e164:      	ldrb	w12, [x11, #0x18]
    e168:      	cbz	w12, 0xe244 <_Z20MTARMPMMusicGetSpeedPv+0x3548>
    e16c:      	ldr	x10, [x8, #0x10]
    e170:      	strb	wzr, [x8, #0x18]
    e174:      	cmp	x10, x0
    e178:      	b.eq	0xe22c <_Z20MTARMPMMusicGetSpeedPv+0x3530>
    e17c:      	ldrb	w8, [x10, #0x18]
    e180:      	cbnz	w8, 0xe208 <_Z20MTARMPMMusicGetSpeedPv+0x350c>
    e184:      	b	0xe230 <_Z20MTARMPMMusicGetSpeedPv+0x3534>
    e188:      	cbnz	w11, 0xe1d0 <_Z20MTARMPMMusicGetSpeedPv+0x34d4>
    e18c:      	ldr	x11, [x8, #0x8]
    e190:      	strb	w9, [x8, #0x18]
    e194:      	strb	wzr, [x10, #0x18]
    e198:      	str	x11, [x10]
    e19c:      	cbz	x11, 0xe1a4 <_Z20MTARMPMMusicGetSpeedPv+0x34a8>
    e1a0:      	str	x10, [x11, #0x10]
    e1a4:      	ldr	x11, [x10, #0x10]
    e1a8:      	ldr	x12, [x11]
    e1ac:      	str	x11, [x8, #0x10]
    e1b0:      	cmp	x12, x10
    e1b4:      	cset	w12, ne
    e1b8:      	cmp	x0, x10
    e1bc:      	str	x8, [x11, w12, uxtw #3]
    e1c0:      	csel	x0, x8, x0, eq
    e1c4:      	str	x10, [x8, #0x8]
    e1c8:      	str	x8, [x10, #0x10]
    e1cc:      	ldr	x8, [x10]
    e1d0:      	ldr	x11, [x8]
    e1d4:      	cbz	x11, 0xe1e0 <_Z20MTARMPMMusicGetSpeedPv+0x34e4>
    e1d8:      	ldrb	w10, [x11, #0x18]
    e1dc:      	cbz	w10, 0xe334 <_Z20MTARMPMMusicGetSpeedPv+0x3638>
    e1e0:      	ldr	x10, [x8, #0x8]
    e1e4:      	cbz	x10, 0xe1f0 <_Z20MTARMPMMusicGetSpeedPv+0x34f4>
    e1e8:      	ldrb	w12, [x10, #0x18]
    e1ec:      	cbz	w12, 0xe2e0 <_Z20MTARMPMMusicGetSpeedPv+0x35e4>
    e1f0:      	ldr	x10, [x8, #0x10]
    e1f4:      	strb	wzr, [x8, #0x18]
    e1f8:      	ldrb	w8, [x10, #0x18]
    e1fc:      	cbz	w8, 0xe230 <_Z20MTARMPMMusicGetSpeedPv+0x3534>
    e200:      	cmp	x10, x0
    e204:      	b.eq	0xe230 <_Z20MTARMPMMusicGetSpeedPv+0x3534>
    e208:      	ldr	x8, [x10, #0x10]
    e20c:      	ldr	x11, [x8]
    e210:      	cmp	x11, x10
    e214:      	cset	w10, eq
    e218:      	ldr	x8, [x8, w10, uxtw #3]
    e21c:      	b	0xe0e8 <_Z20MTARMPMMusicGetSpeedPv+0x33ec>
    e220:      	mov	w8, #0x1                // =1
    e224:      	strb	w8, [x9, #0x18]
    e228:      	ret
    e22c:      	mov	x10, x0
    e230:      	mov	w8, #0x1                // =1
    e234:      	strb	w8, [x10, #0x18]
    e238:      	ret
    e23c:      	ldr	x11, [x8, #0x8]
    e240:      	cbz	x11, 0xe24c <_Z20MTARMPMMusicGetSpeedPv+0x3550>
    e244:      	ldrb	w9, [x11, #0x18]
    e248:      	cbz	w9, 0xe290 <_Z20MTARMPMMusicGetSpeedPv+0x3594>
    e24c:      	ldr	x9, [x10, #0x8]
    e250:      	mov	w11, #0x1               // =1
    e254:      	strb	w11, [x10, #0x18]
    e258:      	strb	wzr, [x8, #0x18]
    e25c:      	str	x9, [x8]
    e260:      	cbz	x9, 0xe268 <_Z20MTARMPMMusicGetSpeedPv+0x356c>
    e264:      	str	x8, [x9, #0x10]
    e268:      	ldr	x9, [x8, #0x10]
    e26c:      	ldr	x11, [x9]
    e270:      	str	x9, [x10, #0x10]
    e274:      	cmp	x11, x8
    e278:      	cset	w11, ne
    e27c:      	str	x10, [x9, w11, uxtw #3]
    e280:      	mov	x11, x8
    e284:      	str	x8, [x10, #0x8]
    e288:      	str	x10, [x8, #0x10]
    e28c:      	b	0xe294 <_Z20MTARMPMMusicGetSpeedPv+0x3598>
    e290:      	mov	x10, x8
    e294:      	ldr	x8, [x10, #0x10]
    e298:      	mov	w13, #0x1               // =1
    e29c:      	ldrb	w12, [x8, #0x18]
    e2a0:      	ldr	x9, [x8, #0x8]
    e2a4:      	strb	w12, [x10, #0x18]
    e2a8:      	ldr	x10, [x9]
    e2ac:      	strb	w13, [x8, #0x18]
    e2b0:      	strb	w13, [x11, #0x18]
    e2b4:      	str	x10, [x8, #0x8]
    e2b8:      	cbz	x10, 0xe2c0 <_Z20MTARMPMMusicGetSpeedPv+0x35c4>
    e2bc:      	str	x8, [x10, #0x10]
    e2c0:      	ldr	x10, [x8, #0x10]
    e2c4:      	ldr	x11, [x10]
    e2c8:      	str	x10, [x9, #0x10]
    e2cc:      	cmp	x11, x8
    e2d0:      	cset	w11, ne
    e2d4:      	str	x9, [x10, w11, uxtw #3]
    e2d8:      	str	x8, [x9]
    e2dc:      	b	0xe380 <_Z20MTARMPMMusicGetSpeedPv+0x3684>
    e2e0:      	cbz	x11, 0xe2f0 <_Z20MTARMPMMusicGetSpeedPv+0x35f4>
    e2e4:      	ldrb	w9, [x11, #0x18]
    e2e8:      	cbz	w9, 0xe334 <_Z20MTARMPMMusicGetSpeedPv+0x3638>
    e2ec:      	ldr	x10, [x8, #0x8]
    e2f0:      	ldr	x9, [x10]
    e2f4:      	mov	w11, #0x1               // =1
    e2f8:      	strb	w11, [x10, #0x18]
    e2fc:      	strb	wzr, [x8, #0x18]
    e300:      	str	x9, [x8, #0x8]
    e304:      	cbz	x9, 0xe30c <_Z20MTARMPMMusicGetSpeedPv+0x3610>
    e308:      	str	x8, [x9, #0x10]
    e30c:      	ldr	x9, [x8, #0x10]
    e310:      	ldr	x11, [x9]
    e314:      	str	x9, [x10, #0x10]
    e318:      	cmp	x11, x8
    e31c:      	cset	w11, ne
    e320:      	str	x10, [x9, w11, uxtw #3]
    e324:      	mov	x11, x8
    e328:      	str	x8, [x10]
    e32c:      	str	x10, [x8, #0x10]
    e330:      	b	0xe338 <_Z20MTARMPMMusicGetSpeedPv+0x363c>
    e334:      	mov	x10, x8
    e338:      	ldr	x8, [x10, #0x10]
    e33c:      	mov	w13, #0x1               // =1
    e340:      	ldrb	w12, [x8, #0x18]
    e344:      	ldr	x9, [x8]
    e348:      	strb	w12, [x10, #0x18]
    e34c:      	ldr	x10, [x9, #0x8]
    e350:      	strb	w13, [x8, #0x18]
    e354:      	strb	w13, [x11, #0x18]
    e358:      	str	x10, [x8]
    e35c:      	cbz	x10, 0xe364 <_Z20MTARMPMMusicGetSpeedPv+0x3668>
    e360:      	str	x8, [x10, #0x10]
    e364:      	ldr	x10, [x8, #0x10]
    e368:      	ldr	x11, [x10]
    e36c:      	str	x10, [x9, #0x10]
    e370:      	cmp	x11, x8
    e374:      	cset	w11, ne
    e378:      	str	x9, [x10, w11, uxtw #3]
    e37c:      	str	x8, [x9, #0x8]
    e380:      	str	x9, [x8, #0x10]
    e384:      	ret
    e388:      	sub	sp, sp, #0x80
    e38c:      	stp	x29, x30, [sp, #0x30]
    e390:      	str	x25, [sp, #0x40]
    e394:      	stp	x24, x23, [sp, #0x50]
    e398:      	stp	x22, x21, [sp, #0x60]
    e39c:      	stp	x20, x19, [sp, #0x70]
    e3a0:      	add	x29, sp, #0x30
    e3a4:      	mrs	x25, TPIDR_EL0
    e3a8:      	mov	x23, x2
    e3ac:      	mov	x2, x1
    e3b0:      	ldr	x8, [x25, #0x28]
    e3b4:      	add	x1, sp, #0x8
    e3b8:      	mov	x21, x4
    e3bc:      	mov	x22, x3
    e3c0:      	mov	x20, x0
    e3c4:      	stur	x8, [x29, #-0x8]
    e3c8:      	bl	0xe454 <_Z20MTARMPMMusicGetSpeedPv+0x3758>
    e3cc:      	ldr	x19, [x0]
    e3d0:      	cbz	x19, 0xe3dc <_Z20MTARMPMMusicGetSpeedPv+0x36e0>
    e3d4:      	mov	x1, xzr
    e3d8:      	b	0xe420 <_Z20MTARMPMMusicGetSpeedPv+0x3724>
    e3dc:      	mov	x24, x0
    e3e0:      	add	x8, sp, #0x10
    e3e4:      	mov	x0, x20
    e3e8:      	mov	x1, x23
    e3ec:      	mov	x2, x22
    e3f0:      	mov	x3, x21
    e3f4:      	bl	0xe4ec <_Z20MTARMPMMusicGetSpeedPv+0x37f0>
    e3f8:      	ldp	x1, x3, [sp, #0x8]
    e3fc:      	mov	x0, x20
    e400:      	mov	x2, x24
    e404:      	bl	0xe57c <_Z20MTARMPMMusicGetSpeedPv+0x3880>
    e408:      	ldr	x19, [sp, #0x10]
    e40c:      	add	x0, sp, #0x10
    e410:      	mov	x1, xzr
    e414:      	str	xzr, [sp, #0x10]
    e418:      	bl	0xe764 <_Z20MTARMPMMusicGetSpeedPv+0x3a68>
    e41c:      	mov	w1, #0x1                // =1
    e420:      	ldr	x8, [x25, #0x28]
    e424:      	ldur	x9, [x29, #-0x8]
    e428:      	cmp	x8, x9
    e42c:      	b.ne	0xe450 <_Z20MTARMPMMusicGetSpeedPv+0x3754>
    e430:      	mov	x0, x19
    e434:      	ldp	x20, x19, [sp, #0x70]
    e438:      	ldr	x25, [sp, #0x40]
    e43c:      	ldp	x22, x21, [sp, #0x60]
    e440:      	ldp	x24, x23, [sp, #0x50]
    e444:      	ldp	x29, x30, [sp, #0x30]
    e448:      	add	sp, sp, #0x80
    e44c:      	ret
    e450:      	bl	0x16b40 <__stack_chk_fail@plt>
    e454:      	stp	x29, x30, [sp, #-0x40]!
    e458:      	str	x23, [sp, #0x10]
    e45c:      	stp	x22, x21, [sp, #0x20]
    e460:      	stp	x20, x19, [sp, #0x30]
    e464:      	mov	x29, sp
    e468:      	mov	x20, x0
    e46c:      	mov	x19, x1
    e470:      	ldr	x8, [x20, #0x8]!
    e474:      	cbz	x8, 0xe4cc <_Z20MTARMPMMusicGetSpeedPv+0x37d0>
    e478:      	mov	x21, x2
    e47c:      	mov	x22, x0
    e480:      	add	x0, x22, #0x10
    e484:      	add	x2, x8, #0x20
    e488:      	mov	x1, x21
    e48c:      	mov	x23, x8
    e490:      	bl	0xdc8c <_Z20MTARMPMMusicGetSpeedPv+0x2f90>
    e494:      	tbz	w0, #0x0, 0xe4a8 <_Z20MTARMPMMusicGetSpeedPv+0x37ac>
    e498:      	ldr	x8, [x23]
    e49c:      	mov	x20, x23
    e4a0:      	cbnz	x8, 0xe480 <_Z20MTARMPMMusicGetSpeedPv+0x3784>
    e4a4:      	b	0xe4d0 <_Z20MTARMPMMusicGetSpeedPv+0x37d4>
    e4a8:      	add	x0, x22, #0x10
    e4ac:      	add	x1, x23, #0x20
    e4b0:      	mov	x2, x21
    e4b4:      	bl	0xdc8c <_Z20MTARMPMMusicGetSpeedPv+0x2f90>
    e4b8:      	tbz	w0, #0x0, 0xe4d0 <_Z20MTARMPMMusicGetSpeedPv+0x37d4>
    e4bc:      	mov	x20, x23
    e4c0:      	ldr	x8, [x20, #0x8]!
    e4c4:      	cbnz	x8, 0xe480 <_Z20MTARMPMMusicGetSpeedPv+0x3784>
    e4c8:      	b	0xe4d0 <_Z20MTARMPMMusicGetSpeedPv+0x37d4>
    e4cc:      	mov	x23, x20
    e4d0:      	mov	x0, x20
    e4d4:      	str	x23, [x19]
    e4d8:      	ldp	x20, x19, [sp, #0x30]
    e4dc:      	ldr	x23, [sp, #0x10]
    e4e0:      	ldp	x22, x21, [sp, #0x20]
    e4e4:      	ldp	x29, x30, [sp], #0x40
    e4e8:      	ret
    e4ec:      	stp	x29, x30, [sp, #-0x30]!
    e4f0:      	stp	x22, x21, [sp, #0x10]
    e4f4:      	stp	x20, x19, [sp, #0x20]
    e4f8:      	mov	x29, sp
    e4fc:      	add	x22, x0, #0x8
    e500:      	mov	w0, #0x70               // =112
    e504:      	mov	x21, x2
    e508:      	mov	x19, x8
    e50c:      	bl	0x16b50 <_Znwm@plt>
    e510:      	ldr	x8, [x21]
    e514:      	stp	x0, x22, [x19]
    e518:      	mov	x20, x0
    e51c:      	strb	wzr, [x19, #0x10]
    e520:      	ldrb	w9, [x8]
    e524:      	tbnz	w9, #0x0, 0xe53c <_Z20MTARMPMMusicGetSpeedPv+0x3840>
    e528:      	ldr	x9, [x8, #0x10]
    e52c:      	ldr	q0, [x8]
    e530:      	stur	x9, [x20, #0x30]
    e534:      	stur	q0, [x20, #0x20]
    e538:      	b	0xe548 <_Z20MTARMPMMusicGetSpeedPv+0x384c>
    e53c:      	ldp	x2, x1, [x8, #0x8]
    e540:      	add	x0, x20, #0x20
    e544:      	bl	0xca60 <_Z20MTARMPMMusicGetSpeedPv+0x1d64>
    e548:      	mov	w8, #0x1                // =1
    e54c:      	str	xzr, [x20, #0x60]
    e550:      	strb	w8, [x19, #0x10]
    e554:      	ldp	x20, x19, [sp, #0x20]
    e558:      	ldp	x22, x21, [sp, #0x10]
    e55c:      	ldp	x29, x30, [sp], #0x30
    e560:      	ret
    e564:      	mov	x20, x0
    e568:      	mov	x0, x19
    e56c:      	mov	x1, xzr
    e570:      	bl	0xe764 <_Z20MTARMPMMusicGetSpeedPv+0x3a68>
    e574:      	mov	x0, x20
    e578:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    e57c:      	stp	x29, x30, [sp, #-0x20]!
    e580:      	str	x19, [sp, #0x10]
    e584:      	mov	x29, sp
    e588:      	stp	xzr, xzr, [x3]
    e58c:      	mov	x19, x0
    e590:      	str	x1, [x3, #0x10]
    e594:      	str	x3, [x2]
    e598:      	ldr	x8, [x0]
    e59c:      	ldr	x8, [x8]
    e5a0:      	cbz	x8, 0xe5ac <_Z20MTARMPMMusicGetSpeedPv+0x38b0>
    e5a4:      	str	x8, [x19]
    e5a8:      	ldr	x3, [x2]
    e5ac:      	ldr	x0, [x19, #0x8]
    e5b0:      	mov	x1, x3
    e5b4:      	bl	0xe5d0 <_Z20MTARMPMMusicGetSpeedPv+0x38d4>
    e5b8:      	ldr	x8, [x19, #0x10]
    e5bc:      	add	x8, x8, #0x1
    e5c0:      	str	x8, [x19, #0x10]
    e5c4:      	ldr	x19, [sp, #0x10]
    e5c8:      	ldp	x29, x30, [sp], #0x20
    e5cc:      	ret
    e5d0:      	cmp	x1, x0
    e5d4:      	cset	w8, eq
    e5d8:      	strb	w8, [x1, #0x18]
    e5dc:      	b.eq	0xe63c <_Z20MTARMPMMusicGetSpeedPv+0x3940>
    e5e0:      	mov	w10, #0x1               // =1
    e5e4:      	ldr	x9, [x1, #0x10]
    e5e8:      	ldrb	w8, [x9, #0x18]
    e5ec:      	cbnz	w8, 0xe63c <_Z20MTARMPMMusicGetSpeedPv+0x3940>
    e5f0:      	ldr	x8, [x9, #0x10]
    e5f4:      	ldr	x11, [x8]
    e5f8:      	cmp	x11, x9
    e5fc:      	b.eq	0xe610 <_Z20MTARMPMMusicGetSpeedPv+0x3914>
    e600:      	cbz	x11, 0xe640 <_Z20MTARMPMMusicGetSpeedPv+0x3944>
    e604:      	ldrb	w12, [x11, #0x18]!
    e608:      	cbz	w12, 0xe620 <_Z20MTARMPMMusicGetSpeedPv+0x3924>
    e60c:      	b	0xe640 <_Z20MTARMPMMusicGetSpeedPv+0x3944>
    e610:      	ldr	x11, [x8, #0x8]
    e614:      	cbz	x11, 0xe654 <_Z20MTARMPMMusicGetSpeedPv+0x3958>
    e618:      	ldrb	w12, [x11, #0x18]!
    e61c:      	cbnz	w12, 0xe654 <_Z20MTARMPMMusicGetSpeedPv+0x3958>
    e620:      	cmp	x8, x0
    e624:      	strb	w10, [x9, #0x18]
    e628:      	mov	x1, x8
    e62c:      	cset	w9, eq
    e630:      	strb	w9, [x8, #0x18]
    e634:      	strb	w10, [x11]
    e638:      	b.ne	0xe5e4 <_Z20MTARMPMMusicGetSpeedPv+0x38e8>
    e63c:      	ret
    e640:      	ldr	x10, [x9]
    e644:      	cmp	x10, x1
    e648:      	b.eq	0xe6a8 <_Z20MTARMPMMusicGetSpeedPv+0x39ac>
    e64c:      	mov	x1, x9
    e650:      	b	0xe6e0 <_Z20MTARMPMMusicGetSpeedPv+0x39e4>
    e654:      	ldr	x10, [x9]
    e658:      	cmp	x10, x1
    e65c:      	b.eq	0xe720 <_Z20MTARMPMMusicGetSpeedPv+0x3a24>
    e660:      	ldr	x10, [x9, #0x8]
    e664:      	mov	x11, x9
    e668:      	ldr	x12, [x10]
    e66c:      	str	x12, [x9, #0x8]
    e670:      	cbz	x12, 0xe680 <_Z20MTARMPMMusicGetSpeedPv+0x3984>
    e674:      	str	x9, [x12, #0x10]
    e678:      	ldr	x8, [x9, #0x10]
    e67c:      	ldr	x11, [x8]
    e680:      	add	x12, x8, #0x8
    e684:      	cmp	x11, x9
    e688:      	str	x8, [x10, #0x10]
    e68c:      	csel	x8, x8, x12, eq
    e690:      	str	x10, [x8]
    e694:      	str	x10, [x9, #0x10]
    e698:      	ldr	x8, [x10, #0x10]
    e69c:      	str	x9, [x10]
    e6a0:      	ldr	x9, [x8]
    e6a4:      	b	0xe724 <_Z20MTARMPMMusicGetSpeedPv+0x3a28>
    e6a8:      	ldr	x10, [x1, #0x8]
    e6ac:      	str	x10, [x9]
    e6b0:      	cbz	x10, 0xe6bc <_Z20MTARMPMMusicGetSpeedPv+0x39c0>
    e6b4:      	str	x9, [x10, #0x10]
    e6b8:      	ldr	x8, [x9, #0x10]
    e6bc:      	mov	x10, x8
    e6c0:      	str	x8, [x1, #0x10]
    e6c4:      	ldr	x11, [x10], #0x8
    e6c8:      	cmp	x11, x9
    e6cc:      	csel	x8, x8, x10, eq
    e6d0:      	str	x1, [x8]
    e6d4:      	str	x1, [x9, #0x10]
    e6d8:      	ldr	x8, [x1, #0x10]
    e6dc:      	str	x9, [x1, #0x8]
    e6e0:      	ldr	x9, [x8, #0x8]
    e6e4:      	mov	w10, #0x1               // =1
    e6e8:      	strb	w10, [x1, #0x18]
    e6ec:      	ldr	x10, [x9]
    e6f0:      	strb	wzr, [x8, #0x18]
    e6f4:      	str	x10, [x8, #0x8]
    e6f8:      	cbz	x10, 0xe700 <_Z20MTARMPMMusicGetSpeedPv+0x3a04>
    e6fc:      	str	x8, [x10, #0x10]
    e700:      	ldr	x10, [x8, #0x10]
    e704:      	ldr	x11, [x10]
    e708:      	str	x10, [x9, #0x10]
    e70c:      	cmp	x11, x8
    e710:      	cset	w11, ne
    e714:      	str	x9, [x10, w11, uxtw #3]
    e718:      	str	x8, [x9]
    e71c:      	b	0xe75c <_Z20MTARMPMMusicGetSpeedPv+0x3a60>
    e720:      	mov	x10, x9
    e724:      	ldr	x11, [x9, #0x8]
    e728:      	mov	w12, #0x1               // =1
    e72c:      	strb	w12, [x10, #0x18]
    e730:      	strb	wzr, [x8, #0x18]
    e734:      	str	x11, [x8]
    e738:      	cbz	x11, 0xe740 <_Z20MTARMPMMusicGetSpeedPv+0x3a44>
    e73c:      	str	x8, [x11, #0x10]
    e740:      	ldr	x10, [x8, #0x10]
    e744:      	ldr	x11, [x10]
    e748:      	str	x10, [x9, #0x10]
    e74c:      	cmp	x11, x8
    e750:      	cset	w11, ne
    e754:      	str	x9, [x10, w11, uxtw #3]
    e758:      	str	x8, [x9, #0x8]
    e75c:      	str	x9, [x8, #0x10]
    e760:      	ret
    e764:      	stp	x29, x30, [sp, #-0x20]!
    e768:      	str	x19, [sp, #0x10]
    e76c:      	mov	x29, sp
    e770:      	ldr	x19, [x0]
    e774:      	str	x1, [x0]
    e778:      	cbz	x19, 0xe79c <_Z20MTARMPMMusicGetSpeedPv+0x3aa0>
    e77c:      	ldrb	w8, [x0, #0x10]
    e780:      	cbz	w8, 0xe78c <_Z20MTARMPMMusicGetSpeedPv+0x3a90>
    e784:      	add	x0, x19, #0x20
    e788:      	bl	0xdaac <_Z20MTARMPMMusicGetSpeedPv+0x2db0>
    e78c:      	mov	x0, x19
    e790:      	ldr	x19, [sp, #0x10]
    e794:      	ldp	x29, x30, [sp], #0x20
    e798:      	b	0x16b60 <_ZdlPv@plt>
    e79c:      	ldr	x19, [sp, #0x10]
    e7a0:      	ldp	x29, x30, [sp], #0x20
    e7a4:      	ret
    e7a8:      	stp	x29, x30, [sp, #-0x20]!
    e7ac:      	stp	x20, x19, [sp, #0x10]
    e7b0:      	mov	x29, sp
    e7b4:      	mov	x19, x0
    e7b8:      	ldr	x0, [x0, #0x20]
    e7bc:      	mov	x20, x1
    e7c0:      	str	xzr, [x19, #0x20]
    e7c4:      	cmp	x0, x19
    e7c8:      	b.eq	0xe7d8 <_Z20MTARMPMMusicGetSpeedPv+0x3adc>
    e7cc:      	cbz	x0, 0xe7ec <_Z20MTARMPMMusicGetSpeedPv+0x3af0>
    e7d0:      	mov	w8, #0x5                // =5
    e7d4:      	b	0xe7e0 <_Z20MTARMPMMusicGetSpeedPv+0x3ae4>
    e7d8:      	mov	w8, #0x4                // =4
    e7dc:      	mov	x0, x19
    e7e0:      	ldr	x9, [x0]
    e7e4:      	ldr	x8, [x9, x8, lsl #3]
    e7e8:      	blr	x8
    e7ec:      	ldr	x8, [x20, #0x20]
    e7f0:      	cbz	x8, 0xe808 <_Z20MTARMPMMusicGetSpeedPv+0x3b0c>
    e7f4:      	cmp	x8, x20
    e7f8:      	b.eq	0xe810 <_Z20MTARMPMMusicGetSpeedPv+0x3b14>
    e7fc:      	str	x8, [x19, #0x20]
    e800:      	str	xzr, [x20, #0x20]
    e804:      	b	0xe828 <_Z20MTARMPMMusicGetSpeedPv+0x3b2c>
    e808:      	str	xzr, [x19, #0x20]
    e80c:      	b	0xe828 <_Z20MTARMPMMusicGetSpeedPv+0x3b2c>
    e810:      	str	x19, [x19, #0x20]
    e814:      	mov	x1, x19
    e818:      	ldr	x0, [x20, #0x20]
    e81c:      	ldr	x8, [x0]
    e820:      	ldr	x8, [x8, #0x18]
    e824:      	blr	x8
    e828:      	mov	x0, x19
    e82c:      	ldp	x20, x19, [sp, #0x10]
    e830:      	ldp	x29, x30, [sp], #0x20
    e834:      	ret
    e838:      	stp	x29, x30, [sp, #-0x20]!
    e83c:      	str	x19, [sp, #0x10]
    e840:      	mov	x29, sp
    e844:      	mov	w0, #0x8                // =8
    e848:      	bl	0x16bb0 <__cxa_allocate_exception@plt>
    e84c:      	mov	x19, x0
    e850:      	bl	0x17090 <_ZNSt20bad_array_new_lengthC1Ev@plt>
    e854:      	adrp	x1, 0x1b000 <syscall@plt+0x3d00>
    e858:      	adrp	x2, 0x1b000 <syscall@plt+0x3d00>
    e85c:      	mov	x0, x19
    e860:      	ldr	x1, [x1, #0x988]
    e864:      	ldr	x2, [x2, #0x990]
    e868:      	bl	0x16bc0 <__cxa_throw@plt>
    e86c:      	stp	x29, x30, [sp, #-0x20]!
    e870:      	stp	x20, x19, [sp, #0x10]
    e874:      	mov	x29, sp
    e878:      	mov	x19, x0
    e87c:      	mov	w8, #0x3f800000         // =1065353216
    e880:      	stp	xzr, xzr, [x0]
    e884:      	str	w8, [x0, #0x10]
    e888:      	bl	0xca20 <_Z20MTARMPMMusicGetSpeedPv+0x1d24>
    e88c:      	ldp	x20, x19, [sp, #0x10]
    e890:      	ldp	x29, x30, [sp], #0x20
    e894:      	ret
    e898:      	mov	x20, x0
    e89c:      	mov	x0, x19
    e8a0:      	bl	0xd1ec <_Z20MTARMPMMusicGetSpeedPv+0x24f0>
    e8a4:      	mov	x0, x20
    e8a8:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    e8ac:      	stp	x29, x30, [sp, #-0x20]!
    e8b0:      	str	x19, [sp, #0x10]
    e8b4:      	mov	x29, sp
    e8b8:      	ldr	x8, [x0]
    e8bc:      	mov	x19, x0
    e8c0:      	cbz	x8, 0xe904 <_Z20MTARMPMMusicGetSpeedPv+0x3c08>
    e8c4:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    e8c8:      	cmp	w0, #0x3
    e8cc:      	b.gt	0xe8e8 <_Z20MTARMPMMusicGetSpeedPv+0x3bec>
    e8d0:      	nop
    e8d4:      	adr	x1, 0x52f1
    e8d8:      	adrp	x2, 0x5000
    e8dc:      	add	x2, x2, #0x322
    e8e0:      	mov	w0, #0x4                // =4
    e8e4:      	bl	0x16e90 <__android_log_print@plt>
    e8e8:      	ldr	x0, [x19]
    e8ec:      	mov	w1, #0x1                // =1
    e8f0:      	bl	0xf5b8 <_Z20MTARMPMMusicGetSpeedPv+0x48bc>
    e8f4:      	ldr	x0, [x19]
    e8f8:      	bl	0xf6b4 <_Z20MTARMPMMusicGetSpeedPv+0x49b8>
    e8fc:      	mov	x0, x19
    e900:      	bl	0xe91c <_Z20MTARMPMMusicGetSpeedPv+0x3c20>
    e904:      	bl	0xca24 <_Z20MTARMPMMusicGetSpeedPv+0x1d28>
    e908:      	mov	x0, x19
    e90c:      	ldr	x19, [sp, #0x10]
    e910:      	ldp	x29, x30, [sp], #0x20
    e914:      	b	0xd1ec <_Z20MTARMPMMusicGetSpeedPv+0x24f0>
    e918:      	bl	0xad14 <_Z20MTARMPMMusicGetSpeedPv+0x18>
    e91c:      	stp	x29, x30, [sp, #-0x20]!
    e920:      	str	x19, [sp, #0x10]
    e924:      	mov	x29, sp
    e928:      	ldr	x19, [x0, #0x8]
    e92c:      	stp	xzr, xzr, [x0]
    e930:      	cbz	x19, 0xe944 <_Z20MTARMPMMusicGetSpeedPv+0x3c48>
    e934:      	add	x1, x19, #0x8
    e938:      	mov	x0, #-0x1               // =-1
    e93c:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    e940:      	cbz	x0, 0xe950 <_Z20MTARMPMMusicGetSpeedPv+0x3c54>
    e944:      	ldr	x19, [sp, #0x10]
    e948:      	ldp	x29, x30, [sp], #0x20
    e94c:      	ret
    e950:      	ldr	x8, [x19]
    e954:      	mov	x0, x19
    e958:      	ldr	x8, [x8, #0x10]
    e95c:      	blr	x8
    e960:      	mov	x0, x19
    e964:      	ldr	x19, [sp, #0x10]
    e968:      	ldp	x29, x30, [sp], #0x20
    e96c:      	b	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    e970:      	sub	sp, sp, #0x50
    e974:      	stp	x29, x30, [sp, #0x20]
    e978:      	stp	x22, x21, [sp, #0x30]
    e97c:      	stp	x20, x19, [sp, #0x40]
    e980:      	add	x29, sp, #0x20
    e984:      	mrs	x21, TPIDR_EL0
    e988:      	adrp	x22, 0x1f000
    e98c:      	mov	x19, x8
    e990:      	ldr	x9, [x21, #0x28]
    e994:      	stur	x9, [x29, #-0x8]
    e998:      	ldr	x9, [x22, #0xde8]
    e99c:      	cbnz	x9, 0xe9c4 <_Z20MTARMPMMusicGetSpeedPv+0x3cc8>
    e9a0:      	nop
    e9a4:      	adr	x0, 0x1fdf8 <__bss_start+0x10>
    e9a8:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    e9ac:      	ldr	x8, [x22, #0xde8]
    e9b0:      	cbz	x8, 0xea04 <_Z20MTARMPMMusicGetSpeedPv+0x3d08>
    e9b4:      	nop
    e9b8:      	adr	x0, 0x1fdf8 <__bss_start+0x10>
    e9bc:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    e9c0:      	ldr	x9, [x22, #0xde8]
    e9c4:      	adrp	x8, 0x1f000
    e9c8:      	ldr	x8, [x8, #0xdf0]
    e9cc:      	stp	x9, x8, [x19]
    e9d0:      	cbz	x8, 0xe9e0 <_Z20MTARMPMMusicGetSpeedPv+0x3ce4>
    e9d4:      	add	x1, x8, #0x8
    e9d8:      	mov	w0, #0x1                // =1
    e9dc:      	bl	0x125c0 <_Z20MTARMPMMusicGetSpeedPv+0x78c4>
    e9e0:      	ldr	x8, [x21, #0x28]
    e9e4:      	ldur	x9, [x29, #-0x8]
    e9e8:      	cmp	x8, x9
    e9ec:      	b.ne	0xea9c <_Z20MTARMPMMusicGetSpeedPv+0x3da0>
    e9f0:      	ldp	x20, x19, [sp, #0x40]
    e9f4:      	ldp	x22, x21, [sp, #0x30]
    e9f8:      	ldp	x29, x30, [sp, #0x20]
    e9fc:      	add	sp, sp, #0x50
    ea00:      	ret
    ea04:      	mov	w0, #0x18               // =24
    ea08:      	bl	0x16b50 <_Znwm@plt>
    ea0c:      	mov	x20, x0
    ea10:      	bl	0xe86c <_Z20MTARMPMMusicGetSpeedPv+0x3b70>
    ea14:      	add	x0, sp, #0x8
    ea18:      	mov	x1, x20
    ea1c:      	bl	0xeaa0 <_Z20MTARMPMMusicGetSpeedPv+0x3da4>
    ea20:      	nop
    ea24:      	adr	x0, 0x1fde8 <__bss_start>
    ea28:      	add	x1, sp, #0x8
    ea2c:      	bl	0xeb00 <_Z20MTARMPMMusicGetSpeedPv+0x3e04>
    ea30:      	ldr	x20, [sp, #0x10]
    ea34:      	cbz	x20, 0xe9b4 <_Z20MTARMPMMusicGetSpeedPv+0x3cb8>
    ea38:      	add	x1, x20, #0x8
    ea3c:      	mov	x0, #-0x1               // =-1
    ea40:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    ea44:      	cbnz	x0, 0xe9b4 <_Z20MTARMPMMusicGetSpeedPv+0x3cb8>
    ea48:      	ldr	x8, [x20]
    ea4c:      	mov	x0, x20
    ea50:      	ldr	x8, [x8, #0x10]
    ea54:      	blr	x8
    ea58:      	mov	x0, x20
    ea5c:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    ea60:      	b	0xe9b4 <_Z20MTARMPMMusicGetSpeedPv+0x3cb8>
    ea64:      	mov	x19, x0
    ea68:      	mov	x0, x20
    ea6c:      	bl	0x16b60 <_ZdlPv@plt>
    ea70:      	b	0xea78 <_Z20MTARMPMMusicGetSpeedPv+0x3d7c>
    ea74:      	mov	x19, x0
    ea78:      	nop
    ea7c:      	adr	x0, 0x1fdf8 <__bss_start+0x10>
    ea80:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    ea84:      	ldr	x8, [x21, #0x28]
    ea88:      	ldur	x9, [x29, #-0x8]
    ea8c:      	cmp	x8, x9
    ea90:      	b.ne	0xea9c <_Z20MTARMPMMusicGetSpeedPv+0x3da0>
    ea94:      	mov	x0, x19
    ea98:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    ea9c:      	bl	0x16b40 <__stack_chk_fail@plt>
    eaa0:      	stp	x29, x30, [sp, #-0x20]!
    eaa4:      	stp	x20, x19, [sp, #0x10]
    eaa8:      	mov	x29, sp
    eaac:      	mov	x19, x1
    eab0:      	mov	x20, x0
    eab4:      	str	x1, [x0]
    eab8:      	mov	w0, #0x20               // =32
    eabc:      	bl	0x16b50 <_Znwm@plt>
    eac0:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    eac4:      	add	x8, x8, #0x560
    eac8:      	stp	xzr, x19, [x0, #0x10]
    eacc:      	stp	x8, xzr, [x0]
    ead0:      	str	x0, [x20, #0x8]
    ead4:      	ldp	x20, x19, [sp, #0x10]
    ead8:      	ldp	x29, x30, [sp], #0x20
    eadc:      	ret
    eae0:      	mov	x20, x0
    eae4:      	cbz	x19, 0xeaf8 <_Z20MTARMPMMusicGetSpeedPv+0x3dfc>
    eae8:      	mov	x0, x19
    eaec:      	bl	0xe8ac <_Z20MTARMPMMusicGetSpeedPv+0x3bb0>
    eaf0:      	mov	x0, x19
    eaf4:      	bl	0x16b60 <_ZdlPv@plt>
    eaf8:      	mov	x0, x20
    eafc:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    eb00:      	stp	x29, x30, [sp, #-0x20]!
    eb04:      	stp	x20, x19, [sp, #0x10]
    eb08:      	mov	x29, sp
    eb0c:      	ldr	q0, [x1]
    eb10:      	stp	xzr, xzr, [x1]
    eb14:      	mov	x19, x0
    eb18:      	ldr	x20, [x0, #0x8]
    eb1c:      	str	q0, [x0]
    eb20:      	cbz	x20, 0xeb4c <_Z20MTARMPMMusicGetSpeedPv+0x3e50>
    eb24:      	add	x1, x20, #0x8
    eb28:      	mov	x0, #-0x1               // =-1
    eb2c:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    eb30:      	cbnz	x0, 0xeb4c <_Z20MTARMPMMusicGetSpeedPv+0x3e50>
    eb34:      	ldr	x8, [x20]
    eb38:      	mov	x0, x20
    eb3c:      	ldr	x8, [x8, #0x10]
    eb40:      	blr	x8
    eb44:      	mov	x0, x20
    eb48:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    eb4c:      	mov	x0, x19
    eb50:      	ldp	x20, x19, [sp, #0x10]
    eb54:      	ldp	x29, x30, [sp], #0x20
    eb58:      	ret
    eb5c:      	sub	sp, sp, #0x50
    eb60:      	stp	x29, x30, [sp, #0x20]
    eb64:      	str	x21, [sp, #0x30]
    eb68:      	stp	x20, x19, [sp, #0x40]
    eb6c:      	add	x29, sp, #0x20
    eb70:      	mrs	x21, TPIDR_EL0
    eb74:      	mov	x19, x0
    eb78:      	nop
    eb7c:      	adr	x0, 0x1fdf8 <__bss_start+0x10>
    eb80:      	ldr	x8, [x21, #0x28]
    eb84:      	stur	x8, [x29, #-0x8]
    eb88:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    eb8c:      	ldr	x0, [x19]
    eb90:      	cbz	x0, 0xeba4 <_Z20MTARMPMMusicGetSpeedPv+0x3ea8>
    eb94:      	mov	w1, wzr
    eb98:      	bl	0xf5b8 <_Z20MTARMPMMusicGetSpeedPv+0x48bc>
    eb9c:      	mov	w19, #0x1               // =1
    eba0:      	b	0xec10 <_Z20MTARMPMMusicGetSpeedPv+0x3f14>
    eba4:      	mov	x8, sp
    eba8:      	sub	x0, x29, #0x9
    ebac:      	bl	0xeedc <_Z20MTARMPMMusicGetSpeedPv+0x41e0>
    ebb0:      	mov	x1, sp
    ebb4:      	mov	x0, x19
    ebb8:      	bl	0xd3d0 <_Z20MTARMPMMusicGetSpeedPv+0x26d4>
    ebbc:      	ldr	x20, [sp, #0x8]
    ebc0:      	cbz	x20, 0xebec <_Z20MTARMPMMusicGetSpeedPv+0x3ef0>
    ebc4:      	add	x1, x20, #0x8
    ebc8:      	mov	x0, #-0x1               // =-1
    ebcc:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    ebd0:      	cbnz	x0, 0xebec <_Z20MTARMPMMusicGetSpeedPv+0x3ef0>
    ebd4:      	ldr	x8, [x20]
    ebd8:      	mov	x0, x20
    ebdc:      	ldr	x8, [x8, #0x10]
    ebe0:      	blr	x8
    ebe4:      	mov	x0, x20
    ebe8:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    ebec:      	adrp	x8, 0x5000
    ebf0:      	ldr	x0, [x19]
    ebf4:      	ldr	d0, [x8, #0xef0]
    ebf8:      	str	d0, [x0, #0x30]
    ebfc:      	bl	0xf2c8 <_Z20MTARMPMMusicGetSpeedPv+0x45cc>
    ec00:      	cbz	w0, 0xec44 <_Z20MTARMPMMusicGetSpeedPv+0x3f48>
    ec04:      	mov	x0, x19
    ec08:      	bl	0xe91c <_Z20MTARMPMMusicGetSpeedPv+0x3c20>
    ec0c:      	mov	w19, wzr
    ec10:      	nop
    ec14:      	adr	x0, 0x1fdf8 <__bss_start+0x10>
    ec18:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    ec1c:      	ldr	x8, [x21, #0x28]
    ec20:      	ldur	x9, [x29, #-0x8]
    ec24:      	cmp	x8, x9
    ec28:      	b.ne	0xecb4 <_Z20MTARMPMMusicGetSpeedPv+0x3fb8>
    ec2c:      	mov	w0, w19
    ec30:      	ldp	x20, x19, [sp, #0x40]
    ec34:      	ldr	x21, [sp, #0x30]
    ec38:      	ldp	x29, x30, [sp, #0x20]
    ec3c:      	add	sp, sp, #0x50
    ec40:      	ret
    ec44:      	ldr	x0, [x19]
    ec48:      	ldr	s0, [x19, #0x10]
    ec4c:      	bl	0xf688 <_Z20MTARMPMMusicGetSpeedPv+0x498c>
    ec50:      	ldr	x0, [x19]
    ec54:      	mov	w1, wzr
    ec58:      	bl	0xf5b8 <_Z20MTARMPMMusicGetSpeedPv+0x48bc>
    ec5c:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    ec60:      	cmp	w0, #0x3
    ec64:      	b.gt	0xeb9c <_Z20MTARMPMMusicGetSpeedPv+0x3ea0>
    ec68:      	nop
    ec6c:      	adr	x1, 0x52f1
    ec70:      	adrp	x2, 0x5000
    ec74:      	add	x2, x2, #0xaf4
    ec78:      	mov	w0, #0x4                // =4
    ec7c:      	bl	0x16e90 <__android_log_print@plt>
    ec80:      	b	0xeb9c <_Z20MTARMPMMusicGetSpeedPv+0x3ea0>
    ec84:      	b	0xec8c <_Z20MTARMPMMusicGetSpeedPv+0x3f90>
    ec88:      	b	0xec8c <_Z20MTARMPMMusicGetSpeedPv+0x3f90>
    ec8c:      	mov	x19, x0
    ec90:      	nop
    ec94:      	adr	x0, 0x1fdf8 <__bss_start+0x10>
    ec98:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    ec9c:      	ldr	x8, [x21, #0x28]
    eca0:      	ldur	x9, [x29, #-0x8]
    eca4:      	cmp	x8, x9
    eca8:      	b.ne	0xecb4 <_Z20MTARMPMMusicGetSpeedPv+0x3fb8>
    ecac:      	mov	x0, x19
    ecb0:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    ecb4:      	bl	0x16b40 <__stack_chk_fail@plt>
    ecb8:      	stp	x29, x30, [sp, #-0x20]!
    ecbc:      	stp	x20, x19, [sp, #0x10]
    ecc0:      	mov	x29, sp
    ecc4:      	mov	x19, x0
    ecc8:      	nop
    eccc:      	adr	x0, 0x1fdf8 <__bss_start+0x10>
    ecd0:      	mov	w20, w1
    ecd4:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    ecd8:      	ldr	x0, [x19]
    ecdc:      	cbz	x0, 0xecf8 <_Z20MTARMPMMusicGetSpeedPv+0x3ffc>
    ece0:      	and	w1, w20, #0x1
    ece4:      	bl	0xf5b8 <_Z20MTARMPMMusicGetSpeedPv+0x48bc>
    ece8:      	tbz	w20, #0x0, 0xecf8 <_Z20MTARMPMMusicGetSpeedPv+0x3ffc>
    ecec:      	ldr	x0, [x19]
    ecf0:      	cbz	x0, 0xecf8 <_Z20MTARMPMMusicGetSpeedPv+0x3ffc>
    ecf4:      	bl	0xf6b0 <_Z20MTARMPMMusicGetSpeedPv+0x49b4>
    ecf8:      	nop
    ecfc:      	adr	x0, 0x1fdf8 <__bss_start+0x10>
    ed00:      	ldp	x20, x19, [sp, #0x10]
    ed04:      	ldp	x29, x30, [sp], #0x20
    ed08:      	b	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    ed0c:      	mov	x19, x0
    ed10:      	nop
    ed14:      	adr	x0, 0x1fdf8 <__bss_start+0x10>
    ed18:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    ed1c:      	mov	x0, x19
    ed20:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    ed24:      	stp	x29, x30, [sp, #-0x20]!
    ed28:      	str	x19, [sp, #0x10]
    ed2c:      	mov	x29, sp
    ed30:      	mov	x19, x0
    ed34:      	nop
    ed38:      	adr	x0, 0x1fdf8 <__bss_start+0x10>
    ed3c:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    ed40:      	ldr	x8, [x19]
    ed44:      	cbz	x8, 0xed88 <_Z20MTARMPMMusicGetSpeedPv+0x408c>
    ed48:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    ed4c:      	cmp	w0, #0x3
    ed50:      	b.gt	0xed6c <_Z20MTARMPMMusicGetSpeedPv+0x4070>
    ed54:      	nop
    ed58:      	adr	x1, 0x52f1
    ed5c:      	adrp	x2, 0x5000
    ed60:      	add	x2, x2, #0x322
    ed64:      	mov	w0, #0x4                // =4
    ed68:      	bl	0x16e90 <__android_log_print@plt>
    ed6c:      	ldr	x0, [x19]
    ed70:      	mov	w1, #0x1                // =1
    ed74:      	bl	0xf5b8 <_Z20MTARMPMMusicGetSpeedPv+0x48bc>
    ed78:      	ldr	x0, [x19]
    ed7c:      	bl	0xf6b4 <_Z20MTARMPMMusicGetSpeedPv+0x49b8>
    ed80:      	mov	x0, x19
    ed84:      	bl	0xe91c <_Z20MTARMPMMusicGetSpeedPv+0x3c20>
    ed88:      	nop
    ed8c:      	adr	x0, 0x1fdf8 <__bss_start+0x10>
    ed90:      	ldr	x19, [sp, #0x10]
    ed94:      	ldp	x29, x30, [sp], #0x20
    ed98:      	b	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    ed9c:      	mov	x19, x0
    eda0:      	nop
    eda4:      	adr	x0, 0x1fdf8 <__bss_start+0x10>
    eda8:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    edac:      	mov	x0, x19
    edb0:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    edb4:      	sub	sp, sp, #0x30
    edb8:      	stp	x29, x30, [sp, #0x10]
    edbc:      	stp	x20, x19, [sp, #0x20]
    edc0:      	add	x29, sp, #0x10
    edc4:      	mrs	x20, TPIDR_EL0
    edc8:      	mov	x19, x8
    edcc:      	ldr	x9, [x20, #0x28]
    edd0:      	str	x9, [sp, #0x8]
    edd4:      	ldr	x9, [x0]
    edd8:      	cbz	x9, 0xee04 <_Z20MTARMPMMusicGetSpeedPv+0x4108>
    eddc:      	mov	x2, x1
    ede0:      	mov	x1, x0
    ede4:      	add	x0, sp, #0x7
    ede8:      	mov	x8, x19
    edec:      	bl	0xefb4 <_Z20MTARMPMMusicGetSpeedPv+0x42b8>
    edf0:      	ldr	x8, [x20, #0x28]
    edf4:      	ldr	x9, [sp, #0x8]
    edf8:      	cmp	x8, x9
    edfc:      	b.ne	0xee4c <_Z20MTARMPMMusicGetSpeedPv+0x4150>
    ee00:      	b	0xee3c <_Z20MTARMPMMusicGetSpeedPv+0x4140>
    ee04:      	bl	0xce7c <_Z20MTARMPMMusicGetSpeedPv+0x2180>
    ee08:      	cmp	w0, #0x5
    ee0c:      	b.gt	0xee28 <_Z20MTARMPMMusicGetSpeedPv+0x412c>
    ee10:      	nop
    ee14:      	adr	x1, 0x52f1
    ee18:      	adrp	x2, 0x4000
    ee1c:      	add	x2, x2, #0x8e5
    ee20:      	mov	w0, #0x6                // =6
    ee24:      	bl	0x16e90 <__android_log_print@plt>
    ee28:      	ldr	x8, [x20, #0x28]
    ee2c:      	ldr	x9, [sp, #0x8]
    ee30:      	cmp	x8, x9
    ee34:      	b.ne	0xee4c <_Z20MTARMPMMusicGetSpeedPv+0x4150>
    ee38:      	stp	xzr, xzr, [x19]
    ee3c:      	ldp	x20, x19, [sp, #0x20]
    ee40:      	ldp	x29, x30, [sp, #0x10]
    ee44:      	add	sp, sp, #0x30
    ee48:      	ret
    ee4c:      	bl	0x16b40 <__stack_chk_fail@plt>
    ee50:      	ldr	x0, [x0]
    ee54:      	cbz	x0, 0xee70 <_Z20MTARMPMMusicGetSpeedPv+0x4174>
    ee58:      	stp	x29, x30, [sp, #-0x10]!
    ee5c:      	mov	x29, sp
    ee60:      	bl	0xfa1c <_Z20MTARMPMMusicGetSpeedPv+0x4d20>
    ee64:      	eor	w8, w0, #0x1
    ee68:      	ldp	x29, x30, [sp], #0x10
    ee6c:      	b	0xee74 <_Z20MTARMPMMusicGetSpeedPv+0x4178>
    ee70:      	mov	w8, #0x1                // =1
    ee74:      	and	w0, w8, #0x1
    ee78:      	ret
    ee7c:      	stp	x29, x30, [sp, #-0x20]!
    ee80:      	str	x19, [sp, #0x10]
    ee84:      	mov	x29, sp
    ee88:      	mov	x19, x0
    ee8c:      	bl	0x16e50 <_ZNSt6__ndk119__shared_weak_countD2Ev@plt>
    ee90:      	mov	x0, x19
    ee94:      	ldr	x19, [sp, #0x10]
    ee98:      	ldp	x29, x30, [sp], #0x20
    ee9c:      	b	0x16b60 <_ZdlPv@plt>
    eea0:      	stp	x29, x30, [sp, #-0x20]!
    eea4:      	str	x19, [sp, #0x10]
    eea8:      	mov	x29, sp
    eeac:      	ldr	x19, [x0, #0x18]
    eeb0:      	cbz	x19, 0xeecc <_Z20MTARMPMMusicGetSpeedPv+0x41d0>
    eeb4:      	mov	x0, x19
    eeb8:      	bl	0xe8ac <_Z20MTARMPMMusicGetSpeedPv+0x3bb0>
    eebc:      	mov	x0, x19
    eec0:      	ldr	x19, [sp, #0x10]
    eec4:      	ldp	x29, x30, [sp], #0x20
    eec8:      	b	0x16b60 <_ZdlPv@plt>
    eecc:      	ldr	x19, [sp, #0x10]
    eed0:      	ldp	x29, x30, [sp], #0x20
    eed4:      	ret
    eed8:      	b	0x16b60 <_ZdlPv@plt>
    eedc:      	stp	x29, x30, [sp, #-0x20]!
    eee0:      	stp	x20, x19, [sp, #0x10]
    eee4:      	mov	x29, sp
    eee8:      	mov	w0, #0x118              // =280
    eeec:      	mov	x19, x8
    eef0:      	bl	0x16b50 <_Znwm@plt>
    eef4:      	mov	x20, x0
    eef8:      	bl	0xef24 <_Z20MTARMPMMusicGetSpeedPv+0x4228>
    eefc:      	add	x8, x20, #0x18
    ef00:      	stp	x8, x20, [x19]
    ef04:      	ldp	x20, x19, [sp, #0x10]
    ef08:      	ldp	x29, x30, [sp], #0x20
    ef0c:      	ret
    ef10:      	mov	x19, x0
    ef14:      	mov	x0, x20
    ef18:      	bl	0x16b60 <_ZdlPv@plt>
    ef1c:      	mov	x0, x19
    ef20:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    ef24:      	stp	x29, x30, [sp, #-0x20]!
    ef28:      	stp	x20, x19, [sp, #0x10]
    ef2c:      	mov	x29, sp
    ef30:      	mov	x19, x0
    ef34:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    ef38:      	add	x8, x8, #0x598
    ef3c:      	stp	xzr, xzr, [x0, #0x8]
    ef40:      	str	x8, [x0], #0x18
    ef44:      	bl	0xf100 <_Z20MTARMPMMusicGetSpeedPv+0x4404>
    ef48:      	ldp	x20, x19, [sp, #0x10]
    ef4c:      	ldp	x29, x30, [sp], #0x20
    ef50:      	ret
    ef54:      	mov	x20, x0
    ef58:      	mov	x0, x19
    ef5c:      	bl	0x16e50 <_ZNSt6__ndk119__shared_weak_countD2Ev@plt>
    ef60:      	mov	x0, x20
    ef64:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    ef68:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    ef6c:      	add	x8, x8, #0x598
    ef70:      	str	x8, [x0]
    ef74:      	b	0x16e50 <_ZNSt6__ndk119__shared_weak_countD2Ev@plt>
    ef78:      	stp	x29, x30, [sp, #-0x20]!
    ef7c:      	str	x19, [sp, #0x10]
    ef80:      	mov	x29, sp
    ef84:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    ef88:      	add	x8, x8, #0x598
    ef8c:      	mov	x19, x0
    ef90:      	str	x8, [x0]
    ef94:      	bl	0x16e50 <_ZNSt6__ndk119__shared_weak_countD2Ev@plt>
    ef98:      	mov	x0, x19
    ef9c:      	ldr	x19, [sp, #0x10]
    efa0:      	ldp	x29, x30, [sp], #0x20
    efa4:      	b	0x16b60 <_ZdlPv@plt>
    efa8:      	add	x0, x0, #0x18
    efac:      	b	0xf238 <_Z20MTARMPMMusicGetSpeedPv+0x453c>
    efb0:      	b	0x16b60 <_ZdlPv@plt>
    efb4:      	stp	x29, x30, [sp, #-0x30]!
    efb8:      	stp	x22, x21, [sp, #0x10]
    efbc:      	stp	x20, x19, [sp, #0x20]
    efc0:      	mov	x29, sp
    efc4:      	mov	w0, #0x68               // =104
    efc8:      	mov	x21, x2
    efcc:      	mov	x22, x1
    efd0:      	mov	x19, x8
    efd4:      	bl	0x16b50 <_Znwm@plt>
    efd8:      	mov	x20, x0
    efdc:      	mov	x2, x22
    efe0:      	mov	x3, x21
    efe4:      	bl	0xf014 <_Z20MTARMPMMusicGetSpeedPv+0x4318>
    efe8:      	add	x8, x20, #0x18
    efec:      	stp	x8, x20, [x19]
    eff0:      	ldp	x20, x19, [sp, #0x20]
    eff4:      	ldp	x22, x21, [sp, #0x10]
    eff8:      	ldp	x29, x30, [sp], #0x30
    effc:      	ret
    f000:      	mov	x19, x0
    f004:      	mov	x0, x20
    f008:      	bl	0x16b60 <_ZdlPv@plt>
    f00c:      	mov	x0, x19
    f010:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    f014:      	stp	x29, x30, [sp, #-0x20]!
    f018:      	stp	x20, x19, [sp, #0x10]
    f01c:      	mov	x29, sp
    f020:      	mov	x1, x2
    f024:      	mov	x19, x0
    f028:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    f02c:      	add	x8, x8, #0x5d0
    f030:      	stp	xzr, xzr, [x0, #0x8]
    f034:      	str	x8, [x0], #0x18
    f038:      	mov	x2, x3
    f03c:      	bl	0xce88 <_Z20MTARMPMMusicGetSpeedPv+0x218c>
    f040:      	ldp	x20, x19, [sp, #0x10]
    f044:      	ldp	x29, x30, [sp], #0x20
    f048:      	ret
    f04c:      	mov	x20, x0
    f050:      	mov	x0, x19
    f054:      	bl	0x16e50 <_ZNSt6__ndk119__shared_weak_countD2Ev@plt>
    f058:      	mov	x0, x20
    f05c:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    f060:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    f064:      	add	x8, x8, #0x5d0
    f068:      	str	x8, [x0]
    f06c:      	b	0x16e50 <_ZNSt6__ndk119__shared_weak_countD2Ev@plt>
    f070:      	stp	x29, x30, [sp, #-0x20]!
    f074:      	str	x19, [sp, #0x10]
    f078:      	mov	x29, sp
    f07c:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    f080:      	add	x8, x8, #0x5d0
    f084:      	mov	x19, x0
    f088:      	str	x8, [x0]
    f08c:      	bl	0x16e50 <_ZNSt6__ndk119__shared_weak_countD2Ev@plt>
    f090:      	mov	x0, x19
    f094:      	ldr	x19, [sp, #0x10]
    f098:      	ldp	x29, x30, [sp], #0x20
    f09c:      	b	0x16b60 <_ZdlPv@plt>
    f0a0:      	ldr	x8, [x0, #0x18]!
    f0a4:      	ldr	x1, [x8]
    f0a8:      	br	x1
    f0ac:      	b	0x16b60 <_ZdlPv@plt>
    f0b0:      	stp	x29, x30, [sp, #-0x20]!
    f0b4:      	str	x19, [sp, #0x10]
    f0b8:      	mov	x29, sp
    f0bc:      	nop
    f0c0:      	adr	x19, 0x1b310
    f0c4:      	nop
    f0c8:      	adr	x1, 0x1fde8 <__bss_start>
    f0cc:      	nop
    f0d0:      	adr	x0, 0xa378 <_Z19MTARMPMServiceStartv+0xb4>
    f0d4:      	mov	x2, x19
    f0d8:      	stp	xzr, xzr, [x1]
    f0dc:      	bl	0x16b10 <__cxa_atexit@plt>
    f0e0:      	adrp	x0, 0x1b000 <syscall@plt+0x3d00>
    f0e4:      	nop
    f0e8:      	adr	x1, 0x1fdf8 <__bss_start+0x10>
    f0ec:      	ldr	x0, [x0, #0x938]
    f0f0:      	mov	x2, x19
    f0f4:      	ldr	x19, [sp, #0x10]
    f0f8:      	ldp	x29, x30, [sp], #0x20
    f0fc:      	b	0x16b10 <__cxa_atexit@plt>
    f100:      	sub	sp, sp, #0x40
    f104:      	stp	x29, x30, [sp, #0x10]
    f108:      	stp	x22, x21, [sp, #0x20]
    f10c:      	stp	x20, x19, [sp, #0x30]
    f110:      	add	x29, sp, #0x10
    f114:      	mrs	x21, TPIDR_EL0
    f118:      	movi	v0.2d, #0000000000000000
    f11c:      	mov	x20, x0
    f120:      	ldr	x8, [x21, #0x28]
    f124:      	mov	x19, x0
    f128:      	str	x8, [sp, #0x8]
    f12c:      	adrp	x8, 0x5000
    f130:      	str	q0, [x20, #0x80]!
    f134:      	stp	q0, q0, [x0, #0x90]
    f138:      	stp	q0, q0, [x0, #0xb0]
    f13c:      	stp	q0, q0, [x0, #0xd0]
    f140:      	str	q0, [x0, #0xf0]
    f144:      	ldr	d0, [x8, #0xef0]
    f148:      	mov	w8, #0x3f800000         // =1065353216
    f14c:      	str	xzr, [x0]
    f150:      	str	d0, [x0, #0x30]
    f154:      	str	wzr, [x0, #0x48]
    f158:      	stp	xzr, xzr, [x0, #0x58]
    f15c:      	str	xzr, [x0, #0x50]
    f160:      	strh	wzr, [x0, #0x68]
    f164:      	str	w8, [x0, #0x78]
    f168:      	strb	wzr, [x0, #0x6a]
    f16c:      	bl	0x11e34 <_Z20MTARMPMMusicGetSpeedPv+0x7138>
    f170:      	str	x0, [x19, #0x58]
    f174:      	bl	0x11f04 <_Z20MTARMPMMusicGetSpeedPv+0x7208>
    f178:      	str	x0, [x19, #0x60]
    f17c:      	ldr	x8, [x21, #0x28]
    f180:      	ldr	x9, [sp, #0x8]
    f184:      	cmp	x8, x9
    f188:      	b.ne	0xf1e4 <_Z20MTARMPMMusicGetSpeedPv+0x44e8>
    f18c:      	ldp	x20, x19, [sp, #0x30]
    f190:      	ldp	x22, x21, [sp, #0x20]
    f194:      	ldp	x29, x30, [sp, #0x10]
    f198:      	add	sp, sp, #0x40
    f19c:      	ret
    f1a0:      	mov	x22, x20
    f1a4:      	mov	x20, x0
    f1a8:      	add	x0, x19, #0xf0
    f1ac:      	bl	0xf1e8 <_Z20MTARMPMMusicGetSpeedPv+0x44ec>
    f1b0:      	add	x0, x19, #0xc0
    f1b4:      	bl	0x16bf0 <_ZNSt6__ndk118condition_variableD1Ev@plt>
    f1b8:      	add	x0, x19, #0x98
    f1bc:      	bl	0x16c00 <_ZNSt6__ndk15mutexD1Ev@plt>
    f1c0:      	mov	x0, sp
    f1c4:      	str	x22, [sp]
    f1c8:      	bl	0xfc70 <_Z20MTARMPMMusicGetSpeedPv+0x4f74>
    f1cc:      	ldr	x8, [x21, #0x28]
    f1d0:      	ldr	x9, [sp, #0x8]
    f1d4:      	cmp	x8, x9
    f1d8:      	b.ne	0xf1e4 <_Z20MTARMPMMusicGetSpeedPv+0x44e8>
    f1dc:      	mov	x0, x20
    f1e0:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    f1e4:      	bl	0x16b40 <__stack_chk_fail@plt>
    f1e8:      	stp	x29, x30, [sp, #-0x20]!
    f1ec:      	str	x19, [sp, #0x10]
    f1f0:      	mov	x29, sp
    f1f4:      	ldr	x19, [x0, #0x8]
    f1f8:      	cbz	x19, 0xf20c <_Z20MTARMPMMusicGetSpeedPv+0x4510>
    f1fc:      	add	x1, x19, #0x8
    f200:      	mov	x0, #-0x1               // =-1
    f204:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    f208:      	cbz	x0, 0xf218 <_Z20MTARMPMMusicGetSpeedPv+0x451c>
    f20c:      	ldr	x19, [sp, #0x10]
    f210:      	ldp	x29, x30, [sp], #0x20
    f214:      	ret
    f218:      	ldr	x8, [x19]
    f21c:      	mov	x0, x19
    f220:      	ldr	x8, [x8, #0x10]
    f224:      	blr	x8
    f228:      	mov	x0, x19
    f22c:      	ldr	x19, [sp, #0x10]
    f230:      	ldp	x29, x30, [sp], #0x20
    f234:      	b	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    f238:      	sub	sp, sp, #0x30
    f23c:      	stp	x29, x30, [sp, #0x10]
    f240:      	stp	x20, x19, [sp, #0x20]
    f244:      	add	x29, sp, #0x10
    f248:      	mrs	x20, TPIDR_EL0
    f24c:      	mov	x19, x0
    f250:      	ldr	x8, [x20, #0x28]
    f254:      	str	x8, [sp, #0x8]
    f258:      	ldr	x0, [x0, #0x60]
    f25c:      	cbz	x0, 0xf268 <_Z20MTARMPMMusicGetSpeedPv+0x456c>
    f260:      	bl	0x11f4c <_Z20MTARMPMMusicGetSpeedPv+0x7250>
    f264:      	str	xzr, [x19, #0x60]
    f268:      	ldr	x0, [x19, #0x58]
    f26c:      	cbz	x0, 0xf278 <_Z20MTARMPMMusicGetSpeedPv+0x457c>
    f270:      	bl	0x11eb8 <_Z20MTARMPMMusicGetSpeedPv+0x71bc>
    f274:      	str	xzr, [x19, #0x58]
    f278:      	add	x0, x19, #0xf0
    f27c:      	bl	0xf1e8 <_Z20MTARMPMMusicGetSpeedPv+0x44ec>
    f280:      	add	x0, x19, #0xc0
    f284:      	bl	0x16bf0 <_ZNSt6__ndk118condition_variableD1Ev@plt>
    f288:      	add	x0, x19, #0x98
    f28c:      	bl	0x16c00 <_ZNSt6__ndk15mutexD1Ev@plt>
    f290:      	add	x8, x19, #0x80
    f294:      	mov	x0, sp
    f298:      	str	x8, [sp]
    f29c:      	bl	0xfc70 <_Z20MTARMPMMusicGetSpeedPv+0x4f74>
    f2a0:      	ldr	x8, [x20, #0x28]
    f2a4:      	ldr	x9, [sp, #0x8]
    f2a8:      	cmp	x8, x9
    f2ac:      	b.ne	0xf2c0 <_Z20MTARMPMMusicGetSpeedPv+0x45c4>
    f2b0:      	ldp	x20, x19, [sp, #0x20]
    f2b4:      	ldp	x29, x30, [sp, #0x10]
    f2b8:      	add	sp, sp, #0x30
    f2bc:      	ret
    f2c0:      	bl	0x16b40 <__stack_chk_fail@plt>
    f2c4:      	bl	0xad14 <_Z20MTARMPMMusicGetSpeedPv+0x18>
    f2c8:      	stp	x29, x30, [sp, #-0x20]!
    f2cc:      	stp	x20, x19, [sp, #0x10]
    f2d0:      	mov	x29, sp
    f2d4:      	ldp	w2, w3, [x0, #0x30]
    f2d8:      	add	x4, x0, #0x8
    f2dc:      	mov	x1, xzr
    f2e0:      	mov	x19, x0
    f2e4:      	stp	xzr, xzr, [x0, #0x38]
    f2e8:      	bl	0xf37c <_Z20MTARMPMMusicGetSpeedPv+0x4680>
    f2ec:      	tbnz	w0, #0x1f, 0xf300 <_Z20MTARMPMMusicGetSpeedPv+0x4604>
    f2f0:      	ldr	x0, [x19, #0x50]
    f2f4:      	cbz	x0, 0xf328 <_Z20MTARMPMMusicGetSpeedPv+0x462c>
    f2f8:      	bl	0x12574 <_Z20MTARMPMMusicGetSpeedPv+0x7878>
    f2fc:      	b	0xf338 <_Z20MTARMPMMusicGetSpeedPv+0x463c>
    f300:      	mov	w20, w0
    f304:      	nop
    f308:      	adr	x1, 0x4e4c
    f30c:      	adrp	x2, 0x5000
    f310:      	add	x2, x2, #0x95b
    f314:      	mov	w0, #0x6                // =6
    f318:      	mov	w3, w20
    f31c:      	bl	0x16e90 <__android_log_print@plt>
    f320:      	mov	w8, wzr
    f324:      	b	0xf358 <_Z20MTARMPMMusicGetSpeedPv+0x465c>
    f328:      	ldr	w8, [x19, #0x48]
    f32c:      	lsl	w0, w8, #1
    f330:      	bl	0x12298 <_Z20MTARMPMMusicGetSpeedPv+0x759c>
    f334:      	str	x0, [x19, #0x50]
    f338:      	nop
    f33c:      	adr	x1, 0x4e4c
    f340:      	adrp	x2, 0x5000
    f344:      	add	x2, x2, #0xbce
    f348:      	mov	w0, #0x3                // =3
    f34c:      	bl	0x16e90 <__android_log_print@plt>
    f350:      	mov	w20, wzr
    f354:      	mov	w8, #0x1                // =1
    f358:      	mov	x0, x19
    f35c:      	mov	w1, #0x1                // =1
    f360:      	strb	w8, [x19, #0x6a]
    f364:      	strh	wzr, [x19, #0x68]
    f368:      	bl	0xf5b8 <_Z20MTARMPMMusicGetSpeedPv+0x48bc>
    f36c:      	mov	w0, w20
    f370:      	ldp	x20, x19, [sp, #0x10]
    f374:      	ldp	x29, x30, [sp], #0x20
    f378:      	ret
    f37c:      	sub	sp, sp, #0xc0
    f380:      	stp	x29, x30, [sp, #0x60]
    f384:      	stp	x28, x27, [sp, #0x70]
    f388:      	stp	x26, x25, [sp, #0x80]
    f38c:      	stp	x24, x23, [sp, #0x90]
    f390:      	stp	x22, x21, [sp, #0xa0]
    f394:      	stp	x20, x19, [sp, #0xb0]
    f398:      	add	x29, sp, #0x60
    f39c:      	mrs	x26, TPIDR_EL0
    f3a0:      	ldr	x8, [x26, #0x28]
    f3a4:      	cmp	w3, #0x1
    f3a8:      	stur	x8, [x29, #-0x8]
    f3ac:      	sturb	w2, [x29, #-0x22]
    f3b0:      	stur	w3, [x29, #-0x28]
    f3b4:      	b.lt	0xf524 <_Z20MTARMPMMusicGetSpeedPv+0x4828>
    f3b8:      	mov	w23, w2
    f3bc:      	and	w8, w2, #0xff
    f3c0:      	cbz	w8, 0xf524 <_Z20MTARMPMMusicGetSpeedPv+0x4828>
    f3c4:      	mov	w22, w3
    f3c8:      	mov	x19, x0
    f3cc:      	mov	w28, #0x7               // =7
    f3d0:      	adrp	x27, 0x5000
    f3d4:      	add	x27, x27, #0xf50
    f3d8:      	stp	x1, x4, [sp, #0x8]
    f3dc:      	ldr	w8, [x27, x28, lsl #2]
    f3e0:      	cmp	w8, w22
    f3e4:      	b.lt	0xf3f0 <_Z20MTARMPMMusicGetSpeedPv+0x46f4>
    f3e8:      	subs	x28, x28, #0x1
    f3ec:      	b.ne	0xf3dc <_Z20MTARMPMMusicGetSpeedPv+0x46e0>
    f3f0:      	scvtf	d0, w22
    f3f4:      	fmov	d1, #30.00000000
    f3f8:      	mov	w8, #0x8010             // =32784
    f3fc:      	sturh	w8, [x29, #-0x24]
    f400:      	sturb	wzr, [x29, #-0x21]
    f404:      	fdiv	d0, d0, d1
    f408:      	bl	0x170a0 <log@plt>
    f40c:      	adrp	x8, 0x5000
    f410:      	mov	w9, #0x2                // =2
    f414:      	sub	x1, x29, #0x28
    f418:      	ldr	d1, [x8, #0xf00]
    f41c:      	add	x2, sp, #0x18
    f420:      	mov	x0, x19
    f424:      	fdiv	d0, d0, d1
    f428:      	fcvtzs	w8, d0
    f42c:      	lsl	w8, w9, w8
    f430:      	mov	w9, #0x200              // =512
    f434:      	cmp	w8, #0x200
    f438:      	csel	w8, w8, w9, gt
    f43c:      	sturh	w8, [x29, #-0x20]
    f440:      	nop
    f444:      	adr	x8, 0xf724 <_Z20MTARMPMMusicGetSpeedPv+0x4a28>
    f448:      	stp	x8, x19, [x29, #-0x18]
    f44c:      	bl	0xf62c <_Z20MTARMPMMusicGetSpeedPv+0x4930>
    f450:      	tbz	w0, #0x1f, 0xf4cc <_Z20MTARMPMMusicGetSpeedPv+0x47d0>
    f454:      	nop
    f458:      	adr	x24, 0x4e4c
    f45c:      	adrp	x25, 0x5000
    f460:      	add	x25, x25, #0x816
    f464:      	mov	w21, #0x7               // =7
    f468:      	nop
    f46c:      	adr	x20, 0x5f70 <_ZTSSt9bad_alloc+0x2f>
    f470:      	ldurb	w3, [x29, #-0x22]
    f474:      	ldur	w4, [x29, #-0x28]
    f478:      	mov	w0, #0x5                // =5
    f47c:      	mov	x1, x24
    f480:      	mov	x2, x25
    f484:      	bl	0x16e90 <__android_log_print@plt>
    f488:      	ldurb	w8, [x29, #-0x22]
    f48c:      	cmp	w8, #0x7
    f490:      	csel	w8, w8, w21, lo
    f494:      	ldr	w8, [x20, w8, uxtw #2]
    f498:      	tst	w8, #0xff
    f49c:      	sturb	w8, [x29, #-0x22]
    f4a0:      	b.ne	0xf4b8 <_Z20MTARMPMMusicGetSpeedPv+0x47bc>
    f4a4:      	ldr	w8, [x27, w28, sxtw #2]
    f4a8:      	sturb	w23, [x29, #-0x22]
    f4ac:      	stur	w8, [x29, #-0x28]
    f4b0:      	cbz	w28, 0xf5a0 <_Z20MTARMPMMusicGetSpeedPv+0x48a4>
    f4b4:      	sub	w28, w28, #0x1
    f4b8:      	sub	x1, x29, #0x28
    f4bc:      	add	x2, sp, #0x18
    f4c0:      	mov	x0, x19
    f4c4:      	bl	0xf62c <_Z20MTARMPMMusicGetSpeedPv+0x4930>
    f4c8:      	tbnz	w0, #0x1f, 0xf470 <_Z20MTARMPMMusicGetSpeedPv+0x4774>
    f4cc:      	ldrh	w3, [sp, #0x1c]
    f4d0:      	mov	w8, #0x8010             // =32784
    f4d4:      	cmp	w3, w8
    f4d8:      	b.ne	0xf540 <_Z20MTARMPMMusicGetSpeedPv+0x4844>
    f4dc:      	ldrb	w3, [sp, #0x1e]
    f4e0:      	ldurb	w8, [x29, #-0x22]
    f4e4:      	cmp	w3, w8
    f4e8:      	b.ne	0xf554 <_Z20MTARMPMMusicGetSpeedPv+0x4858>
    f4ec:      	ldp	x11, x10, [sp, #0x8]
    f4f0:      	adrp	x9, 0x5000
    f4f4:      	ldr	w8, [sp, #0x18]
    f4f8:      	ldr	w0, [sp, #0x24]
    f4fc:      	ldr	d0, [x9, #0xee0]
    f500:      	lsl	w9, w22, #1
    f504:      	str	x11, [x10, #0x8]
    f508:      	stp	w8, w3, [x10]
    f50c:      	str	d0, [x10, #0x10]
    f510:      	str	w9, [x10, #0x18]
    f514:      	str	x11, [x19, #0x28]
    f518:      	stp	w3, w8, [x19, #0x30]
    f51c:      	str	w0, [x19, #0x48]
    f520:      	b	0xf570 <_Z20MTARMPMMusicGetSpeedPv+0x4874>
    f524:      	nop
    f528:      	adr	x1, 0x4e4c
    f52c:      	adrp	x2, 0x5000
    f530:      	add	x2, x2, #0x974
    f534:      	mov	w0, #0x6                // =6
    f538:      	bl	0x16e90 <__android_log_print@plt>
    f53c:      	b	0xf56c <_Z20MTARMPMMusicGetSpeedPv+0x4870>
    f540:      	nop
    f544:      	adr	x1, 0x4e4c
    f548:      	adrp	x2, 0x4000
    f54c:      	add	x2, x2, #0x99c
    f550:      	b	0xf564 <_Z20MTARMPMMusicGetSpeedPv+0x4868>
    f554:      	nop
    f558:      	adr	x1, 0x4e4c
    f55c:      	adrp	x2, 0x4000
    f560:      	add	x2, x2, #0xe55
    f564:      	mov	w0, #0x6                // =6
    f568:      	bl	0x16e90 <__android_log_print@plt>
    f56c:      	mov	w0, #-0x1               // =-1
    f570:      	ldr	x8, [x26, #0x28]
    f574:      	ldur	x9, [x29, #-0x8]
    f578:      	cmp	x8, x9
    f57c:      	b.ne	0xf5b4 <_Z20MTARMPMMusicGetSpeedPv+0x48b8>
    f580:      	ldp	x20, x19, [sp, #0xb0]
    f584:      	ldp	x22, x21, [sp, #0xa0]
    f588:      	ldp	x24, x23, [sp, #0x90]
    f58c:      	ldp	x26, x25, [sp, #0x80]
    f590:      	ldp	x28, x27, [sp, #0x70]
    f594:      	ldp	x29, x30, [sp, #0x60]
    f598:      	add	sp, sp, #0xc0
    f59c:      	ret
    f5a0:      	nop
    f5a4:      	adr	x1, 0x4e4c
    f5a8:      	adrp	x2, 0x5000
    f5ac:      	add	x2, x2, #0x1fc
    f5b0:      	b	0xf534 <_Z20MTARMPMMusicGetSpeedPv+0x4838>
    f5b4:      	bl	0x16b40 <__stack_chk_fail@plt>
    f5b8:      	stp	x29, x30, [sp, #-0x30]!
    f5bc:      	str	x21, [sp, #0x10]
    f5c0:      	stp	x20, x19, [sp, #0x20]
    f5c4:      	mov	x29, sp
    f5c8:      	ldrb	w8, [x0, #0x6a]
    f5cc:      	cbz	w8, 0xf5e8 <_Z20MTARMPMMusicGetSpeedPv+0x48ec>
    f5d0:      	ldrb	w8, [x0, #0x69]
    f5d4:      	and	w21, w1, #0x1
    f5d8:      	mov	x19, x0
    f5dc:      	mov	w20, w1
    f5e0:      	cmp	w8, w21
    f5e4:      	b.ne	0xf5f8 <_Z20MTARMPMMusicGetSpeedPv+0x48fc>
    f5e8:      	ldp	x20, x19, [sp, #0x20]
    f5ec:      	ldr	x21, [sp, #0x10]
    f5f0:      	ldp	x29, x30, [sp], #0x30
    f5f4:      	ret
    f5f8:      	ldr	x0, [x19, #0x58]
    f5fc:      	bl	0x11ee4 <_Z20MTARMPMMusicGetSpeedPv+0x71e8>
    f600:      	ldr	x0, [x19, #0x60]
    f604:      	strb	w21, [x19, #0x69]
    f608:      	bl	0x11f78 <_Z20MTARMPMMusicGetSpeedPv+0x727c>
    f60c:      	ldr	x0, [x19, #0x58]
    f610:      	bl	0x11ef4 <_Z20MTARMPMMusicGetSpeedPv+0x71f8>
    f614:      	ldr	x0, [x19]
    f618:      	and	w1, w20, #0x1
    f61c:      	ldp	x20, x19, [sp, #0x20]
    f620:      	ldr	x21, [sp, #0x10]
    f624:      	ldp	x29, x30, [sp], #0x30
    f628:      	b	0x12244 <_Z20MTARMPMMusicGetSpeedPv+0x7548>
    f62c:      	stp	x29, x30, [sp, #-0x30]!
    f630:      	str	x21, [sp, #0x10]
    f634:      	stp	x20, x19, [sp, #0x20]
    f638:      	mov	x29, sp
    f63c:      	mov	x19, x2
    f640:      	mov	x20, x1
    f644:      	mov	x21, x0
    f648:      	bl	0x11b24 <_Z20MTARMPMMusicGetSpeedPv+0x6e28>
    f64c:      	str	x0, [x21]
    f650:      	cbnz	x0, 0xf670 <_Z20MTARMPMMusicGetSpeedPv+0x4974>
    f654:      	nop
    f658:      	adr	x1, 0x4e4c
    f65c:      	adrp	x2, 0x5000
    f660:      	add	x2, x2, #0x62c
    f664:      	mov	w0, #0x6                // =6
    f668:      	bl	0x16e90 <__android_log_print@plt>
    f66c:      	ldr	x0, [x21]
    f670:      	mov	x1, x20
    f674:      	mov	x2, x19
    f678:      	ldp	x20, x19, [sp, #0x20]
    f67c:      	ldr	x21, [sp, #0x10]
    f680:      	ldp	x29, x30, [sp], #0x30
    f684:      	b	0x12228 <_Z20MTARMPMMusicGetSpeedPv+0x752c>
    f688:      	fmov	s1, s0
    f68c:      	movi	d0, #0000000000000000
    f690:      	mov	x8, x0
    f694:      	fmov	s2, #1.00000000
    f698:      	ldr	x0, [x0]
    f69c:      	mov	w1, #0x1                // =1
    f6a0:      	fcmp	s1, #0.0
    f6a4:      	str	s1, [x8, #0x78]
    f6a8:      	fcsel	s0, s2, s0, gt
    f6ac:      	b	0x12258 <_Z20MTARMPMMusicGetSpeedPv+0x755c>
    f6b0:      	ret
    f6b4:      	stp	x29, x30, [sp, #-0x20]!
    f6b8:      	str	x19, [sp, #0x10]
    f6bc:      	mov	x29, sp
    f6c0:      	mov	x19, x0
    f6c4:      	ldr	x0, [x0, #0x58]
    f6c8:      	bl	0x11ee4 <_Z20MTARMPMMusicGetSpeedPv+0x71e8>
    f6cc:      	ldr	x0, [x19, #0x60]
    f6d0:      	mov	w8, #0x1                // =1
    f6d4:      	strb	wzr, [x19, #0x6a]
    f6d8:      	strb	w8, [x19, #0x68]
    f6dc:      	bl	0x11f78 <_Z20MTARMPMMusicGetSpeedPv+0x727c>
    f6e0:      	ldr	x0, [x19, #0x58]
    f6e4:      	bl	0x11ef4 <_Z20MTARMPMMusicGetSpeedPv+0x71f8>
    f6e8:      	add	x0, x19, #0xc0
    f6ec:      	bl	0x16c20 <_ZNSt6__ndk118condition_variable10notify_allEv@plt>
    f6f0:      	ldr	x0, [x19]
    f6f4:      	bl	0x1226c <_Z20MTARMPMMusicGetSpeedPv+0x7570>
    f6f8:      	ldr	x0, [x19]
    f6fc:      	cbz	x0, 0xf708 <_Z20MTARMPMMusicGetSpeedPv+0x4a0c>
    f700:      	bl	0x12280 <_Z20MTARMPMMusicGetSpeedPv+0x7584>
    f704:      	str	xzr, [x19]
    f708:      	ldr	x0, [x19, #0x50]
    f70c:      	cbz	x0, 0xf718 <_Z20MTARMPMMusicGetSpeedPv+0x4a1c>
    f710:      	bl	0x1258c <_Z20MTARMPMMusicGetSpeedPv+0x7890>
    f714:      	str	xzr, [x19, #0x50]
    f718:      	ldr	x19, [sp, #0x10]
    f71c:      	ldp	x29, x30, [sp], #0x20
    f720:      	ret
    f724:      	sub	sp, sp, #0x80
    f728:      	stp	x29, x30, [sp, #0x30]
    f72c:      	str	x25, [sp, #0x40]
    f730:      	stp	x24, x23, [sp, #0x50]
    f734:      	stp	x22, x21, [sp, #0x60]
    f738:      	stp	x20, x19, [sp, #0x70]
    f73c:      	add	x29, sp, #0x30
    f740:      	mrs	x25, TPIDR_EL0
    f744:      	mov	x21, x0
    f748:      	add	x0, x0, #0x98
    f74c:      	ldr	x8, [x25, #0x28]
    f750:      	mov	w19, w2
    f754:      	mov	x20, x1
    f758:      	stur	x8, [x29, #-0x8]
    f75c:      	mov	w8, #0x1                // =1
    f760:      	str	x0, [sp, #0x18]
    f764:      	strb	w8, [sp, #0x20]
    f768:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    f76c:      	sxtw	x22, w19
    f770:      	mov	x0, x20
    f774:      	mov	w1, wzr
    f778:      	mov	x2, x22
    f77c:      	bl	0x16e80 <memset@plt>
    f780:      	ldp	x9, x8, [x21, #0x80]
    f784:      	cmp	x8, x9
    f788:      	b.eq	0xf870 <_Z20MTARMPMMusicGetSpeedPv+0x4b74>
    f78c:      	cmp	x8, x9
    f790:      	b.eq	0xf878 <_Z20MTARMPMMusicGetSpeedPv+0x4b7c>
    f794:      	mov	x23, x21
    f798:      	ldr	x0, [x23, #0xf0]!
    f79c:      	cbnz	x0, 0xf810 <_Z20MTARMPMMusicGetSpeedPv+0x4b14>
    f7a0:      	cmp	w19, #0x0
    f7a4:      	csinv	x0, x22, xzr, ge
    f7a8:      	bl	0x170b0 <_Znam@plt>
    f7ac:      	mov	x24, x0
    f7b0:      	str	x0, [sp, #0x8]
    f7b4:      	mov	w0, #0x20               // =32
    f7b8:      	bl	0x16b50 <_Znwm@plt>
    f7bc:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
    f7c0:      	add	x8, x8, #0x608
    f7c4:      	stp	xzr, x24, [x0, #0x10]
    f7c8:      	stp	x8, xzr, [x0]
    f7cc:      	add	x1, sp, #0x8
    f7d0:      	str	x0, [sp, #0x10]
    f7d4:      	mov	x0, x23
    f7d8:      	bl	0xf948 <_Z20MTARMPMMusicGetSpeedPv+0x4c4c>
    f7dc:      	ldr	x24, [sp, #0x10]
    f7e0:      	cbz	x24, 0xf80c <_Z20MTARMPMMusicGetSpeedPv+0x4b10>
    f7e4:      	add	x1, x24, #0x8
    f7e8:      	mov	x0, #-0x1               // =-1
    f7ec:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    f7f0:      	cbnz	x0, 0xf80c <_Z20MTARMPMMusicGetSpeedPv+0x4b10>
    f7f4:      	ldr	x8, [x24]
    f7f8:      	mov	x0, x24
    f7fc:      	ldr	x8, [x8, #0x10]
    f800:      	blr	x8
    f804:      	mov	x0, x24
    f808:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    f80c:      	ldr	x0, [x23]
    f810:      	mov	w1, wzr
    f814:      	mov	x2, x22
    f818:      	bl	0x16e80 <memset@plt>
    f81c:      	ldp	x22, x24, [x21, #0x80]
    f820:      	cmp	x22, x24
    f824:      	b.eq	0xf85c <_Z20MTARMPMMusicGetSpeedPv+0x4b60>
    f828:      	ldr	x1, [x23]
    f82c:      	add	x0, x22, #0x10
    f830:      	mov	w2, w19
    f834:      	bl	0xf9a4 <_Z20MTARMPMMusicGetSpeedPv+0x4ca8>
    f838:      	mov	w2, w0
    f83c:      	cmp	w0, #0x1
    f840:      	b.lt	0xf854 <_Z20MTARMPMMusicGetSpeedPv+0x4b58>
    f844:      	ldr	x1, [x23]
    f848:      	fmov	s0, #1.00000000
    f84c:      	mov	x0, x20
    f850:      	bl	0x11b28 <_Z20MTARMPMMusicGetSpeedPv+0x6e2c>
    f854:      	add	x22, x22, #0x40
    f858:      	b	0xf820 <_Z20MTARMPMMusicGetSpeedPv+0x4b24>
    f85c:      	ldr	s0, [x21, #0x78]
    f860:      	mov	x0, x20
    f864:      	mov	w1, w19
    f868:      	bl	0x11c24 <_Z20MTARMPMMusicGetSpeedPv+0x6f28>
    f86c:      	b	0xf878 <_Z20MTARMPMMusicGetSpeedPv+0x4b7c>
    f870:      	ldrb	w8, [x21, #0x68]
    f874:      	cbz	w8, 0xf8c8 <_Z20MTARMPMMusicGetSpeedPv+0x4bcc>
    f878:      	ldrb	w8, [sp, #0x20]
    f87c:      	cbz	w8, 0xf888 <_Z20MTARMPMMusicGetSpeedPv+0x4b8c>
    f880:      	ldr	x0, [sp, #0x18]
    f884:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    f888:      	ldr	x8, [x25, #0x28]
    f88c:      	ldur	x9, [x29, #-0x8]
    f890:      	cmp	x8, x9
    f894:      	b.ne	0xf944 <_Z20MTARMPMMusicGetSpeedPv+0x4c48>
    f898:      	ldp	x20, x19, [sp, #0x70]
    f89c:      	ldr	x25, [sp, #0x40]
    f8a0:      	ldp	x22, x21, [sp, #0x60]
    f8a4:      	ldp	x24, x23, [sp, #0x50]
    f8a8:      	ldp	x29, x30, [sp, #0x30]
    f8ac:      	add	sp, sp, #0x80
    f8b0:      	ret
    f8b4:      	add	x0, x21, #0xc0
    f8b8:      	add	x1, sp, #0x18
    f8bc:      	bl	0x16e70 <_ZNSt6__ndk118condition_variable4waitERNS_11unique_lockINS_5mutexEEE@plt>
    f8c0:      	ldrb	w8, [x21, #0x68]
    f8c4:      	cbnz	w8, 0xf8d8 <_Z20MTARMPMMusicGetSpeedPv+0x4bdc>
    f8c8:      	ldp	x9, x8, [x21, #0x80]
    f8cc:      	cmp	x8, x9
    f8d0:      	b.eq	0xf8b4 <_Z20MTARMPMMusicGetSpeedPv+0x4bb8>
    f8d4:      	b	0xf78c <_Z20MTARMPMMusicGetSpeedPv+0x4a90>
    f8d8:      	ldp	x9, x8, [x21, #0x80]
    f8dc:      	b	0xf78c <_Z20MTARMPMMusicGetSpeedPv+0x4a90>
    f8e0:      	bl	0x16b90 <__cxa_begin_catch@plt>
    f8e4:      	mov	x0, x24
    f8e8:      	bl	0x170c0 <_ZdaPv@plt>
    f8ec:      	ldr	x8, [x25, #0x28]
    f8f0:      	ldur	x9, [x29, #-0x8]
    f8f4:      	cmp	x8, x9
    f8f8:      	b.ne	0xf944 <_Z20MTARMPMMusicGetSpeedPv+0x4c48>
    f8fc:      	bl	0x170d0 <__cxa_rethrow@plt>
    f900:      	mov	x19, x0
    f904:      	bl	0x170e0 <__cxa_end_catch@plt>
    f908:      	b	0xf91c <_Z20MTARMPMMusicGetSpeedPv+0x4c20>
    f90c:      	bl	0xad14 <_Z20MTARMPMMusicGetSpeedPv+0x18>
    f910:      	b	0xf918 <_Z20MTARMPMMusicGetSpeedPv+0x4c1c>
    f914:      	b	0xf918 <_Z20MTARMPMMusicGetSpeedPv+0x4c1c>
    f918:      	mov	x19, x0
    f91c:      	ldrb	w8, [sp, #0x20]
    f920:      	cbz	w8, 0xf92c <_Z20MTARMPMMusicGetSpeedPv+0x4c30>
    f924:      	ldr	x0, [sp, #0x18]
    f928:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    f92c:      	ldr	x8, [x25, #0x28]
    f930:      	ldur	x9, [x29, #-0x8]
    f934:      	cmp	x8, x9
    f938:      	b.ne	0xf944 <_Z20MTARMPMMusicGetSpeedPv+0x4c48>
    f93c:      	mov	x0, x19
    f940:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    f944:      	bl	0x16b40 <__stack_chk_fail@plt>
    f948:      	stp	x29, x30, [sp, #-0x20]!
    f94c:      	stp	x20, x19, [sp, #0x10]
    f950:      	mov	x29, sp
    f954:      	ldr	q0, [x1]
    f958:      	stp	xzr, xzr, [x1]
    f95c:      	mov	x19, x0
    f960:      	ldr	x20, [x0, #0x8]
    f964:      	str	q0, [x0]
    f968:      	cbz	x20, 0xf994 <_Z20MTARMPMMusicGetSpeedPv+0x4c98>
    f96c:      	add	x1, x20, #0x8
    f970:      	mov	x0, #-0x1               // =-1
    f974:      	bl	0x12cb0 <_Z20MTARMPMMusicGetSpeedPv+0x7fb4>
    f978:      	cbnz	x0, 0xf994 <_Z20MTARMPMMusicGetSpeedPv+0x4c98>
    f97c:      	ldr	x8, [x20]
    f980:      	mov	x0, x20
    f984:      	ldr	x8, [x8, #0x10]
    f988:      	blr	x8
    f98c:      	mov	x0, x20
    f990:      	bl	0x16b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>
    f994:      	mov	x0, x19
    f998:      	ldp	x20, x19, [sp, #0x10]
    f99c:      	ldp	x29, x30, [sp], #0x20
    f9a0:      	ret
    f9a4:      	sub	sp, sp, #0x40
    f9a8:      	stp	x29, x30, [sp, #0x20]
    f9ac:      	str	x19, [sp, #0x30]
    f9b0:      	add	x29, sp, #0x20
    f9b4:      	mrs	x19, TPIDR_EL0
    f9b8:      	ldr	x8, [x19, #0x28]
    f9bc:      	stur	x8, [x29, #-0x8]
    f9c0:      	ldr	x0, [x0, #0x20]
    f9c4:      	str	x1, [sp, #0x10]
    f9c8:      	str	w2, [sp, #0xc]
    f9cc:      	cbz	x0, 0xfa04 <_Z20MTARMPMMusicGetSpeedPv+0x4d08>
    f9d0:      	ldr	x8, [x0]
    f9d4:      	add	x1, sp, #0x10
    f9d8:      	add	x2, sp, #0xc
    f9dc:      	ldr	x8, [x8, #0x30]
    f9e0:      	blr	x8
    f9e4:      	ldr	x8, [x19, #0x28]
    f9e8:      	ldur	x9, [x29, #-0x8]
    f9ec:      	cmp	x8, x9
    f9f0:      	b.ne	0xfa18 <_Z20MTARMPMMusicGetSpeedPv+0x4d1c>
    f9f4:      	ldp	x29, x30, [sp, #0x20]
    f9f8:      	ldr	x19, [sp, #0x30]
    f9fc:      	add	sp, sp, #0x40
    fa00:      	ret
    fa04:      	ldr	x8, [x19, #0x28]
    fa08:      	ldur	x9, [x29, #-0x8]
    fa0c:      	cmp	x8, x9
    fa10:      	b.ne	0xfa18 <_Z20MTARMPMMusicGetSpeedPv+0x4d1c>
    fa14:      	bl	0xcad8 <_Z20MTARMPMMusicGetSpeedPv+0x1ddc>
    fa18:      	bl	0x16b40 <__stack_chk_fail@plt>
    fa1c:      	ldrb	w0, [x0, #0x6a]
    fa20:      	ret
    fa24:      	sub	sp, sp, #0x80
    fa28:      	stp	x29, x30, [sp, #0x50]
    fa2c:      	stp	x22, x21, [sp, #0x60]
    fa30:      	stp	x20, x19, [sp, #0x70]
    fa34:      	add	x29, sp, #0x50
    fa38:      	mrs	x22, TPIDR_EL0
    fa3c:      	mov	x19, x0
    fa40:      	add	x0, x0, #0x98
    fa44:      	ldr	x8, [x22, #0x28]
    fa48:      	mov	x21, x2
    fa4c:      	mov	x20, x1
    fa50:      	stur	x8, [x29, #-0x8]
    fa54:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    fa58:      	mov	x8, sp
    fa5c:      	str	x20, [sp]
    fa60:      	add	x20, x8, #0x10
    fa64:      	mov	x0, x20
    fa68:      	mov	x1, x21
    fa6c:      	bl	0xfd40 <_Z20MTARMPMMusicGetSpeedPv+0x5044>
    fa70:      	ldp	x8, x9, [x19, #0x88]
    fa74:      	cmp	x8, x9
    fa78:      	b.hs	0xfa98 <_Z20MTARMPMMusicGetSpeedPv+0x4d9c>
    fa7c:      	ldr	x9, [sp]
    fa80:      	mov	x21, x8
    fa84:      	add	x0, x8, #0x10
    fa88:      	mov	x1, x20
    fa8c:      	str	x9, [x21], #0x40
    fa90:      	bl	0xfed0 <_Z20MTARMPMMusicGetSpeedPv+0x51d4>
    fa94:      	b	0xfaa8 <_Z20MTARMPMMusicGetSpeedPv+0x4dac>
    fa98:      	add	x0, x19, #0x80
    fa9c:      	mov	x1, sp
    faa0:      	bl	0xfda8 <_Z20MTARMPMMusicGetSpeedPv+0x50ac>
    faa4:      	mov	x21, x0
    faa8:      	ldr	x9, [sp, #0x30]
    faac:      	str	x21, [x19, #0x88]
    fab0:      	cmp	x9, x20
    fab4:      	b.eq	0xfac8 <_Z20MTARMPMMusicGetSpeedPv+0x4dcc>
    fab8:      	cbz	x9, 0xfadc <_Z20MTARMPMMusicGetSpeedPv+0x4de0>
    fabc:      	mov	w8, #0x5                // =5
    fac0:      	mov	x20, x9
    fac4:      	b	0xfacc <_Z20MTARMPMMusicGetSpeedPv+0x4dd0>
    fac8:      	mov	w8, #0x4                // =4
    facc:      	ldr	x9, [x20]
    fad0:      	mov	x0, x20
    fad4:      	ldr	x8, [x9, x8, lsl #3]
    fad8:      	blr	x8
    fadc:      	add	x0, x19, #0xc0
    fae0:      	bl	0x16e60 <_ZNSt6__ndk118condition_variable10notify_oneEv@plt>
    fae4:      	add	x0, x19, #0x98
    fae8:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    faec:      	ldr	x8, [x22, #0x28]
    faf0:      	ldur	x9, [x29, #-0x8]
    faf4:      	cmp	x8, x9
    faf8:      	b.ne	0xfb70 <_Z20MTARMPMMusicGetSpeedPv+0x4e74>
    fafc:      	mov	w0, wzr
    fb00:      	ldp	x20, x19, [sp, #0x70]
    fb04:      	ldp	x22, x21, [sp, #0x60]
    fb08:      	ldp	x29, x30, [sp, #0x50]
    fb0c:      	add	sp, sp, #0x80
    fb10:      	ret
    fb14:      	ldr	x9, [sp, #0x30]
    fb18:      	mov	x21, x0
    fb1c:      	cmp	x9, x20
    fb20:      	b.ne	0xfb2c <_Z20MTARMPMMusicGetSpeedPv+0x4e30>
    fb24:      	mov	w8, #0x4                // =4
    fb28:      	b	0xfb38 <_Z20MTARMPMMusicGetSpeedPv+0x4e3c>
    fb2c:      	cbz	x9, 0xfb50 <_Z20MTARMPMMusicGetSpeedPv+0x4e54>
    fb30:      	mov	w8, #0x5                // =5
    fb34:      	mov	x20, x9
    fb38:      	ldr	x9, [x20]
    fb3c:      	mov	x0, x20
    fb40:      	ldr	x8, [x9, x8, lsl #3]
    fb44:      	blr	x8
    fb48:      	b	0xfb50 <_Z20MTARMPMMusicGetSpeedPv+0x4e54>
    fb4c:      	mov	x21, x0
    fb50:      	add	x0, x19, #0x98
    fb54:      	bl	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    fb58:      	ldr	x8, [x22, #0x28]
    fb5c:      	ldur	x9, [x29, #-0x8]
    fb60:      	cmp	x8, x9
    fb64:      	b.ne	0xfb70 <_Z20MTARMPMMusicGetSpeedPv+0x4e74>
    fb68:      	mov	x0, x21
    fb6c:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    fb70:      	bl	0x16b40 <__stack_chk_fail@plt>
    fb74:      	stp	x29, x30, [sp, #-0x10]!
    fb78:      	mov	x29, sp
    fb7c:      	bl	0xfa24 <_Z20MTARMPMMusicGetSpeedPv+0x4d28>
    fb80:      	mov	w0, wzr
    fb84:      	ldp	x29, x30, [sp], #0x10
    fb88:      	ret
    fb8c:      	stp	x29, x30, [sp, #-0x30]!
    fb90:      	stp	x22, x21, [sp, #0x10]
    fb94:      	stp	x20, x19, [sp, #0x20]
    fb98:      	mov	x29, sp
    fb9c:      	mov	x19, x0
    fba0:      	add	x0, x0, #0x98
    fba4:      	mov	x21, x1
    fba8:      	bl	0x16c10 <_ZNSt6__ndk15mutex4lockEv@plt>
    fbac:      	ldp	x20, x22, [x19, #0x80]
    fbb0:      	cmp	x20, x22
    fbb4:      	b.eq	0xfbd4 <_Z20MTARMPMMusicGetSpeedPv+0x4ed8>
    fbb8:      	ldr	x8, [x20]
    fbbc:      	cmp	x8, x21
    fbc0:      	b.eq	0xfbd4 <_Z20MTARMPMMusicGetSpeedPv+0x4ed8>
    fbc4:      	add	x20, x20, #0x40
    fbc8:      	cmp	x20, x22
    fbcc:      	b.ne	0xfbb8 <_Z20MTARMPMMusicGetSpeedPv+0x4ebc>
    fbd0:      	mov	x20, x22
    fbd4:      	cmp	x22, x20
    fbd8:      	b.eq	0xfc54 <_Z20MTARMPMMusicGetSpeedPv+0x4f58>
    fbdc:      	add	x8, x20, #0x40
    fbe0:      	cmp	x8, x22
    fbe4:      	b.eq	0xfc48 <_Z20MTARMPMMusicGetSpeedPv+0x4f4c>
    fbe8:      	add	x21, x20, #0x40
    fbec:      	mov	x0, x20
    fbf0:      	mov	x1, x21
    fbf4:      	bl	0x101d4 <_Z20MTARMPMMusicGetSpeedPv+0x54d8>
    fbf8:      	add	x8, x20, #0x80
    fbfc:      	mov	x20, x21
    fc00:      	cmp	x8, x22
    fc04:      	b.ne	0xfbe8 <_Z20MTARMPMMusicGetSpeedPv+0x4eec>
    fc08:      	ldr	x22, [x19, #0x88]
    fc0c:      	mov	x20, x21
    fc10:      	b	0xfc48 <_Z20MTARMPMMusicGetSpeedPv+0x4f4c>
    fc14:      	ldur	x0, [x22, #-0x10]
    fc18:      	sub	x8, x22, #0x30
    fc1c:      	cmp	x8, x0
    fc20:      	b.eq	0xfc30 <_Z20MTARMPMMusicGetSpeedPv+0x4f34>
    fc24:      	cbz	x0, 0xfc44 <_Z20MTARMPMMusicGetSpeedPv+0x4f48>
    fc28:      	mov	w8, #0x5                // =5
    fc2c:      	b	0xfc38 <_Z20MTARMPMMusicGetSpeedPv+0x4f3c>
    fc30:      	mov	x0, x8
    fc34:      	mov	w8, #0x4                // =4
    fc38:      	ldr	x9, [x0]
    fc3c:      	ldr	x8, [x9, x8, lsl #3]
    fc40:      	blr	x8
    fc44:      	sub	x22, x22, #0x40
    fc48:      	cmp	x22, x20
    fc4c:      	b.ne	0xfc14 <_Z20MTARMPMMusicGetSpeedPv+0x4f18>
    fc50:      	str	x20, [x19, #0x88]
    fc54:      	add	x0, x19, #0xc0
    fc58:      	bl	0x16e60 <_ZNSt6__ndk118condition_variable10notify_oneEv@plt>
    fc5c:      	add	x0, x19, #0x98
    fc60:      	ldp	x20, x19, [sp, #0x20]
    fc64:      	ldp	x22, x21, [sp, #0x10]
    fc68:      	ldp	x29, x30, [sp], #0x30
    fc6c:      	b	0x16c30 <_ZNSt6__ndk15mutex6unlockEv@plt>
    fc70:      	stp	x29, x30, [sp, #-0x30]!
    fc74:      	stp	x22, x21, [sp, #0x10]
    fc78:      	stp	x20, x19, [sp, #0x20]
    fc7c:      	mov	x29, sp
    fc80:      	ldr	x20, [x0]
    fc84:      	ldr	x21, [x20]
    fc88:      	cbz	x21, 0xfcf8 <_Z20MTARMPMMusicGetSpeedPv+0x4ffc>
    fc8c:      	ldr	x22, [x20, #0x8]
    fc90:      	mov	x19, x0
    fc94:      	mov	x0, x21
    fc98:      	cmp	x22, x21
    fc9c:      	b.eq	0xfce4 <_Z20MTARMPMMusicGetSpeedPv+0x4fe8>
    fca0:      	ldur	x0, [x22, #-0x10]
    fca4:      	sub	x8, x22, #0x30
    fca8:      	cmp	x8, x0
    fcac:      	b.eq	0xfcbc <_Z20MTARMPMMusicGetSpeedPv+0x4fc0>
    fcb0:      	cbz	x0, 0xfcd0 <_Z20MTARMPMMusicGetSpeedPv+0x4fd4>
    fcb4:      	mov	w8, #0x5                // =5
    fcb8:      	b	0xfcc4 <_Z20MTARMPMMusicGetSpeedPv+0x4fc8>
    fcbc:      	mov	x0, x8
    fcc0:      	mov	w8, #0x4                // =4
    fcc4:      	ldr	x9, [x0]
    fcc8:      	ldr	x8, [x9, x8, lsl #3]
    fccc:      	blr	x8
    fcd0:      	sub	x22, x22, #0x40
    fcd4:      	cmp	x22, x21
    fcd8:      	b.ne	0xfca0 <_Z20MTARMPMMusicGetSpeedPv+0x4fa4>
    fcdc:      	ldr	x8, [x19]
    fce0:      	ldr	x0, [x8]
    fce4:      	str	x21, [x20, #0x8]
    fce8:      	ldp	x20, x19, [sp, #0x20]
    fcec:      	ldp	x22, x21, [sp, #0x10]
    fcf0:      	ldp	x29, x30, [sp], #0x30
    fcf4:      	b	0x16b60 <_ZdlPv@plt>
    fcf8:      	ldp	x20, x19, [sp, #0x20]
    fcfc:      	ldp	x22, x21, [sp, #0x10]
    fd00:      	ldp	x29, x30, [sp], #0x30
    fd04:      	ret
    fd08:      	stp	x29, x30, [sp, #-0x20]!
    fd0c:      	str	x19, [sp, #0x10]
    fd10:      	mov	x29, sp
    fd14:      	mov	x19, x0
    fd18:      	bl	0x16e50 <_ZNSt6__ndk119__shared_weak_countD2Ev@plt>
    fd1c:      	mov	x0, x19
    fd20:      	ldr	x19, [sp, #0x10]
    fd24:      	ldp	x29, x30, [sp], #0x20
    fd28:      	b	0x16b60 <_ZdlPv@plt>
    fd2c:      	ldr	x0, [x0, #0x18]
    fd30:      	cbz	x0, 0xfd38 <_Z20MTARMPMMusicGetSpeedPv+0x503c>
    fd34:      	b	0x170c0 <_ZdaPv@plt>
    fd38:      	ret
    fd3c:      	b	0x16b60 <_ZdlPv@plt>
    fd40:      	stp	x29, x30, [sp, #-0x20]!
    fd44:      	str	x19, [sp, #0x10]
    fd48:      	mov	x29, sp
    fd4c:      	ldr	x8, [x1, #0x20]
    fd50:      	mov	x19, x0
    fd54:      	cbz	x8, 0xfd78 <_Z20MTARMPMMusicGetSpeedPv+0x507c>
    fd58:      	cmp	x8, x1
    fd5c:      	b.eq	0xfd88 <_Z20MTARMPMMusicGetSpeedPv+0x508c>
    fd60:      	ldr	x9, [x8]
    fd64:      	mov	x0, x8
    fd68:      	ldr	x9, [x9, #0x10]
    fd6c:      	blr	x9
    fd70:      	str	x0, [x19, #0x20]
    fd74:      	b	0xfd7c <_Z20MTARMPMMusicGetSpeedPv+0x5080>
    fd78:      	str	xzr, [x19, #0x20]
    fd7c:      	ldr	x19, [sp, #0x10]
    fd80:      	ldp	x29, x30, [sp], #0x20
    fd84:      	ret
    fd88:      	str	x19, [x19, #0x20]
    fd8c:      	ldr	x0, [x1, #0x20]
    fd90:      	ldr	x8, [x0]
    fd94:      	ldr	x2, [x8, #0x18]
    fd98:      	mov	x1, x19
    fd9c:      	ldr	x19, [sp, #0x10]
    fda0:      	ldp	x29, x30, [sp], #0x20
    fda4:      	br	x2
    fda8:      	sub	sp, sp, #0x60
    fdac:      	stp	x29, x30, [sp, #0x30]
    fdb0:      	stp	x22, x21, [sp, #0x40]
    fdb4:      	stp	x20, x19, [sp, #0x50]
    fdb8:      	add	x29, sp, #0x30
    fdbc:      	mrs	x21, TPIDR_EL0
    fdc0:      	mov	x19, x0
    fdc4:      	ldr	x8, [x21, #0x28]
    fdc8:      	stur	x8, [x29, #-0x8]
    fdcc:      	ldp	x9, x8, [x0]
    fdd0:      	sub	x8, x8, x9
    fdd4:      	asr	x22, x8, #6
    fdd8:      	add	x8, x22, #0x1
    fddc:      	lsr	x10, x8, #58
    fde0:      	cbnz	x10, 0xfe90 <_Z20MTARMPMMusicGetSpeedPv+0x5194>
    fde4:      	add	x0, x19, #0x10
    fde8:      	mov	x11, #0x7fffffffffffffc0 // =9223372036854775744
    fdec:      	mov	x20, x1
    fdf0:      	ldr	x10, [x0]
    fdf4:      	str	x0, [sp, #0x20]
    fdf8:      	sub	x9, x10, x9
    fdfc:      	asr	x10, x9, #5
    fe00:      	cmp	x10, x8
    fe04:      	csel	x8, x10, x8, hi
    fe08:      	cmp	x9, x11
    fe0c:      	mov	x9, #0x3ffffffffffffff  // =288230376151711743
    fe10:      	csel	x1, x8, x9, lo
    fe14:      	cbz	x1, 0xfe20 <_Z20MTARMPMMusicGetSpeedPv+0x5124>
    fe18:      	bl	0xffe0 <_Z20MTARMPMMusicGetSpeedPv+0x52e4>
    fe1c:      	b	0xfe24 <_Z20MTARMPMMusicGetSpeedPv+0x5128>
    fe20:      	mov	x0, xzr
    fe24:      	add	x8, x0, x22, lsl #6
    fe28:      	add	x9, x0, x1, lsl #6
    fe2c:      	ldr	x10, [x20], #0x10
    fe30:      	mov	x1, x20
    fe34:      	stp	x0, x8, [sp]
    fe38:      	mov	x22, x8
    fe3c:      	add	x0, x8, #0x10
    fe40:      	str	x9, [sp, #0x18]
    fe44:      	str	x10, [x22], #0x40
    fe48:      	bl	0xfed0 <_Z20MTARMPMMusicGetSpeedPv+0x51d4>
    fe4c:      	str	x22, [sp, #0x10]
    fe50:      	mov	x1, sp
    fe54:      	mov	x0, x19
    fe58:      	bl	0xff28 <_Z20MTARMPMMusicGetSpeedPv+0x522c>
    fe5c:      	ldr	x19, [x19, #0x8]
    fe60:      	mov	x0, sp
    fe64:      	bl	0xff98 <_Z20MTARMPMMusicGetSpeedPv+0x529c>
    fe68:      	ldr	x8, [x21, #0x28]
    fe6c:      	ldur	x9, [x29, #-0x8]
    fe70:      	cmp	x8, x9
    fe74:      	b.ne	0xfecc <_Z20MTARMPMMusicGetSpeedPv+0x51d0>
    fe78:      	mov	x0, x19
    fe7c:      	ldp	x20, x19, [sp, #0x50]
    fe80:      	ldp	x22, x21, [sp, #0x40]
    fe84:      	ldp	x29, x30, [sp, #0x30]
    fe88:      	add	sp, sp, #0x60
    fe8c:      	ret
    fe90:      	ldr	x8, [x21, #0x28]
    fe94:      	ldur	x9, [x29, #-0x8]
    fe98:      	cmp	x8, x9
    fe9c:      	b.ne	0xfecc <_Z20MTARMPMMusicGetSpeedPv+0x51d0>
    fea0:      	mov	x0, x19
    fea4:      	bl	0xffcc <_Z20MTARMPMMusicGetSpeedPv+0x52d0>
    fea8:      	mov	x19, x0
    feac:      	mov	x0, sp
    feb0:      	bl	0xff98 <_Z20MTARMPMMusicGetSpeedPv+0x529c>
    feb4:      	ldr	x8, [x21, #0x28]
    feb8:      	ldur	x9, [x29, #-0x8]
    febc:      	cmp	x8, x9
    fec0:      	b.ne	0xfecc <_Z20MTARMPMMusicGetSpeedPv+0x51d0>
    fec4:      	mov	x0, x19
    fec8:      	bl	0x12e14 <_Z20MTARMPMMusicGetSpeedPv+0x8118>
    fecc:      	bl	0x16b40 <__stack_chk_fail@plt>
    fed0:      	stp	x29, x30, [sp, #-0x10]!
    fed4:      	mov	x29, sp
    fed8:      	mov	x9, x1
    fedc:      	mov	x8, x0
    fee0:      	ldr	x10, [x9, #0x20]!
    fee4:      	cbz	x10, 0xfef8 <_Z20MTARMPMMusicGetSpeedPv+0x51fc>
    fee8:      	cmp	x10, x1
    feec:      	b.eq	0xff04 <_Z20MTARMPMMusicGetSpeedPv+0x5208>
    fef0:      	str	x10, [x8, #0x20]
    fef4:      	b	0xfefc <_Z20MTARMPMMusicGetSpeedPv+0x5200>
    fef8:      	add	x9, x8, #0x20
    fefc:      	str	xzr, [x9]
    ff00:      	b	0xff1c <_Z20MTARMPMMusicGetSpeedPv+0x5220>
    ff04:      	str	x8, [x8, #0x20]
    ff08:      	ldr	x0, [x9]
    ff0c:      	ldr	x9, [x0]
    ff10:      	ldr	x9, [x9, #0x18]
    ff14:      	mov	x1, x8
    ff18:      	blr	x9
    ff1c:      	ldp	x29, x30, [sp], #0x10
    ff20:      	ret
    ff24:      	bl	0xad14 <_Z20MTARMPMMusicGetSpeedPv+0x18>
    ff28:      	stp	x29, x30, [sp, #-0x20]!
    ff2c:      	stp	x20, x19, [sp, #0x10]
    ff30:      	mov	x29, sp
    ff34:      	mov	x19, x1
    ff38:      	mov	x20, x0
    ff3c:      	ldp	x3, x1, [x0], #0x10
    ff40:      	ldr	x5, [x19, #0x8]
    ff44:      	mov	x2, x1
    ff48:      	mov	x4, x3
    ff4c:      	mov	x6, x5
    ff50:      	bl	0x10014 <_Z20MTARMPMMusicGetSpeedPv+0x5318>
    ff54:      	str	x1, [x19, #0x8]
    ff58:      	ldr	x8, [x20]
    ff5c:      	str	x1, [x20]
    ff60:      	ldr	x9, [x19, #0x10]
    ff64:      	str	x8, [x19, #0x8]
    ff68:      	ldr	x8, [x20, #0x8]
    ff6c:      	str	x9, [x20, #0x8]
    ff70:      	ldr	x9, [x19, #0x18]
    ff74:      	str	x8, [x19, #0x10]
    ff78:      	ldr	x8, [x20, #0x10]
    ff7c:      	str	x9, [x20, #0x10]
    ff80:      	ldr	x9, [x19, #0x8]
    ff84:      	str	x8, [x19, #0x18]
    ff88:      	str	x9, [x19]
    ff8c:      	ldp	x20, x19, [sp, #0x10]
    ff90:      	ldp	x29, x30, [sp], #0x20
    ff94:      	ret
    ff98:      	stp	x29, x30, [sp, #-0x20]!
    ff9c:      	str	x19, [sp, #0x10]
    ffa0:      	mov	x29, sp
    ffa4:      	mov	x19, x0
    ffa8:      	bl	0x10168 <_Z20MTARMPMMusicGetSpeedPv+0x546c>
    ffac:      	ldr	x0, [x19]
    ffb0:      	cbz	x0, 0xffc0 <_Z20MTARMPMMusicGetSpeedPv+0x52c4>
    ffb4:      	ldr	x19, [sp, #0x10]
    ffb8:      	ldp	x29, x30, [sp], #0x20
    ffbc:      	b	0x16b60 <_ZdlPv@plt>
    ffc0:      	ldr	x19, [sp, #0x10]
    ffc4:      	ldp	x29, x30, [sp], #0x20
    ffc8:      	ret
    ffcc:      	stp	x29, x30, [sp, #-0x10]!
    ffd0:      	mov	x29, sp
    ffd4:      	adrp	x0, 0x5000
    ffd8:      	add	x0, x0, #0x919
    ffdc:      	bl	0xae28 <_Z20MTARMPMMusicGetSpeedPv+0x12c>
    ffe0:      	stp	x29, x30, [sp, #-0x20]!
    ffe4:      	str	x19, [sp, #0x10]
    ffe8:      	mov	x29, sp
    ffec:      	lsr	x8, x1, #58
    fff0:      	cbnz	x8, 0x10010 <_Z20MTARMPMMusicGetSpeedPv+0x5314>
    fff4:      	lsl	x0, x1, #6
    fff8:      	mov	x19, x1
    fffc:      	bl	0x16b50 <_Znwm@plt>
   10000:      	mov	x1, x19
   10004:      	ldr	x19, [sp, #0x10]
   10008:      	ldp	x29, x30, [sp], #0x20
   1000c:      	ret
   10010:      	bl	0xe838 <_Z20MTARMPMMusicGetSpeedPv+0x3b3c>
   10014:      	sub	sp, sp, #0x90
   10018:      	stp	x29, x30, [sp, #0x50]
   1001c:      	str	x23, [sp, #0x60]
   10020:      	stp	x22, x21, [sp, #0x70]
   10024:      	stp	x20, x19, [sp, #0x80]
   10028:      	add	x29, sp, #0x50
   1002c:      	mrs	x23, TPIDR_EL0
   10030:      	mov	x19, x6
   10034:      	add	x9, sp, #0x18
   10038:      	ldr	x8, [x23, #0x28]
   1003c:      	cmp	x2, x4
   10040:      	stur	x8, [x29, #-0x8]
   10044:      	mov	x8, sp
   10048:      	stp	x5, x6, [sp, #0x18]
   1004c:      	ldur	q0, [sp, #0x18]
   10050:      	stp	x0, x8, [sp, #0x28]
   10054:      	str	x9, [sp, #0x38]
   10058:      	str	q0, [sp]
   1005c:      	strb	wzr, [sp, #0x40]
   10060:      	b.eq	0x1009c <_Z20MTARMPMMusicGetSpeedPv+0x53a0>
   10064:      	mov	x20, x4
   10068:      	mov	x21, x2
   1006c:      	ldr	x8, [x21, #-0x40]!
   10070:      	sub	x0, x19, #0x30
   10074:      	add	x1, x21, #0x10
   10078:      	stur	x8, [x19, #-0x40]
   1007c:      	bl	0xfed0 <_Z20MTARMPMMusicGetSpeedPv+0x51d4>
   10080:      	ldr	x8, [sp, #0x20]
   10084:      	cmp	x21, x20
   10088:      	sub	x19, x8, #0x40
   1008c:      	str	x19, [sp, #0x20]
   10090:      	b.ne	0x1006c <_Z20MTARMPMMusicGetSpeedPv+0x5370>
   10094:      	ldr	x22, [sp, #0x18]
   10098:      	b	0x100a0 <_Z20MTARMPMMusicGetSpeedPv+0x53a4>
   1009c:      	mov	x22, x5
   100a0:      	mov	w8, #0x1                // =1
   100a4:      	add	x0, sp, #0x28
   100a8:      	strb	w8, [sp, #0x40]
   100ac:      	bl	0x100e4 <_Z20MTARMPMMusicGetSpeedPv+0x53e8>
   100b0:      	ldr	x8, [x23, #0x28]
   100b4:      	ldur	x9, [x29, #-0x8]
   100b8:      	cmp	x8, x9
   100bc:      	b.ne	0x100e0 <_Z20MTARMPMMusicGetSpeedPv+0x53e4>
   100c0:      	mov	x0, x22
   100c4:      	mov	x1, x19
   100c8:      	ldp	x20, x19, [sp, #0x80]
   100cc:      	ldr	x23, [sp, #0x60]
   100d0:      	ldp	x22, x21, [sp, #0x70]
   100d4:      	ldp	x29, x30, [sp, #0x50]
   100d8:      	add	sp, sp, #0x90
   100dc:      	ret
   100e0:      	bl	0x16b40 <__stack_chk_fail@plt>
   100e4:      	stp	x29, x30, [sp, #-0x10]!
   100e8:      	mov	x29, sp
   100ec:      	ldrb	w8, [x0, #0x18]
   100f0:      	cbnz	w8, 0x100f8 <_Z20MTARMPMMusicGetSpeedPv+0x53fc>
   100f4:      	bl	0x10104 <_Z20MTARMPMMusicGetSpeedPv+0x5408>
   100f8:      	ldp	x29, x30, [sp], #0x10
   100fc:      	ret
   10100:      	bl	0xad14 <_Z20MTARMPMMusicGetSpeedPv+0x18>
   10104:      	stp	x29, x30, [sp, #-0x20]!
   10108:      	stp	x20, x19, [sp, #0x10]
   1010c:      	mov	x29, sp
   10110:      	ldp	x9, x8, [x0, #0x8]
   10114:      	ldr	x19, [x8, #0x8]
   10118:      	ldr	x20, [x9, #0x8]
   1011c:      	cmp	x19, x20
   10120:      	b.eq	0x1015c <_Z20MTARMPMMusicGetSpeedPv+0x5460>
   10124:      	ldr	x0, [x19, #0x30]
   10128:      	add	x8, x19, #0x10
   1012c:      	cmp	x8, x0
   10130:      	b.eq	0x10140 <_Z20MTARMPMMusicGetSpeedPv+0x5444>
   10134:      	cbz	x0, 0x10154 <_Z20MTARMPMMusicGetSpeedPv+0x5458>
   10138:      	mov	w8, #0x5                // =5
   1013c:      	b	0x10148 <_Z20MTARMPMMusicGetSpeedPv+0x544c>
   10140:      	mov	x0, x8
   10144:      	mov	w8, #0x4                // =4
   10148:      	ldr	x9, [x0]
   1014c:      	ldr	x8, [x9, x8, lsl #3]
   10150:      	blr	x8
   10154:      	add	x19, x19, #0x40
   10158:      	b	0x1011c <_Z20MTARMPMMusicGetSpeedPv+0x5420>
   1015c:      	ldp	x20, x19, [sp, #0x10]
   10160:      	ldp	x29, x30, [sp], #0x20
   10164:      	ret
   10168:      	stp	x29, x30, [sp, #-0x20]!
   1016c:      	stp	x20, x19, [sp, #0x10]
   10170:      	mov	x29, sp
   10174:      	ldp	x20, x8, [x0, #0x8]
   10178:      	cmp	x8, x20
   1017c:      	b.eq	0x101c8 <_Z20MTARMPMMusicGetSpeedPv+0x54cc>
   10180:      	mov	x19, x0
   10184:      	ldur	x0, [x8, #-0x10]
   10188:      	sub	x9, x8, #0x30
   1018c:      	sub	x8, x8, #0x40
   10190:      	str	x8, [x19, #0x10]
   10194:      	cmp	x0, x9
   10198:      	b.eq	0x101a8 <_Z20MTARMPMMusicGetSpeedPv+0x54ac>
   1019c:      	cbz	x0, 0x101c0 <_Z20MTARMPMMusicGetSpeedPv+0x54c4>
   101a0:      	mov	w8, #0x5                // =5
   101a4:      	b	0x101b0 <_Z20MTARMPMMusicGetSpeedPv+0x54b4>
   101a8:      	mov	x0, x9
   101ac:      	mov	w8, #0x4                // =4
   101b0:      	ldr	x9, [x0]
   101b4:      	ldr	x8, [x9, x8, lsl #3]
   101b8:      	blr	x8
   101bc:      	ldr	x8, [x19, #0x10]
   101c0:      	cmp	x8, x20
   101c4:      	b.ne	0x10184 <_Z20MTARMPMMusicGetSpeedPv+0x5488>
   101c8:      	ldp	x20, x19, [sp, #0x10]
   101cc:      	ldp	x29, x30, [sp], #0x20
   101d0:      	ret
   101d4:      	stp	x29, x30, [sp, #-0x20]!
   101d8:      	str	x19, [sp, #0x10]
   101dc:      	mov	x29, sp
   101e0:      	ldr	x8, [x1], #0x10
   101e4:      	mov	x19, x0
   101e8:      	str	x8, [x0], #0x10
   101ec:      	bl	0x10204 <_Z20MTARMPMMusicGetSpeedPv+0x5508>
   101f0:      	mov	x0, x19
   101f4:      	ldr	x19, [sp, #0x10]
   101f8:      	ldp	x29, x30, [sp], #0x20
   101fc:      	ret
   10200:      	bl	0xad14 <_Z20MTARMPMMusicGetSpeedPv+0x18>
   10204:      	stp	x29, x30, [sp, #-0x20]!
   10208:      	stp	x20, x19, [sp, #0x10]
   1020c:      	mov	x29, sp
   10210:      	mov	x19, x0
   10214:      	ldr	x0, [x0, #0x20]
   10218:      	mov	x20, x1
   1021c:      	str	xzr, [x19, #0x20]
   10220:      	cmp	x0, x19
   10224:      	b.eq	0x10234 <_Z20MTARMPMMusicGetSpeedPv+0x5538>
   10228:      	cbz	x0, 0x10248 <_Z20MTARMPMMusicGetSpeedPv+0x554c>
   1022c:      	mov	w8, #0x5                // =5
   10230:      	b	0x1023c <_Z20MTARMPMMusicGetSpeedPv+0x5540>
   10234:      	mov	w8, #0x4                // =4
   10238:      	mov	x0, x19
   1023c:      	ldr	x9, [x0]
   10240:      	ldr	x8, [x9, x8, lsl #3]
   10244:      	blr	x8
   10248:      	ldr	x8, [x20, #0x20]
   1024c:      	cbz	x8, 0x10264 <_Z20MTARMPMMusicGetSpeedPv+0x5568>
   10250:      	cmp	x8, x20
   10254:      	b.eq	0x1026c <_Z20MTARMPMMusicGetSpeedPv+0x5570>
   10258:      	str	x8, [x19, #0x20]
   1025c:      	str	xzr, [x20, #0x20]
   10260:      	b	0x10284 <_Z20MTARMPMMusicGetSpeedPv+0x5588>
   10264:      	str	xzr, [x19, #0x20]
   10268:      	b	0x10284 <_Z20MTARMPMMusicGetSpeedPv+0x5588>
   1026c:      	str	x19, [x19, #0x20]
   10270:      	mov	x1, x19
   10274:      	ldr	x0, [x20, #0x20]
   10278:      	ldr	x8, [x0]
   1027c:      	ldr	x8, [x8, #0x18]
   10280:      	blr	x8
   10284:      	mov	x0, x19
   10288:      	ldp	x20, x19, [sp, #0x10]
   1028c:      	ldp	x29, x30, [sp], #0x20
   10290:      	ret
   10294:      	stp	x29, x30, [sp, #-0x30]!
   10298:      	str	x21, [sp, #0x10]
   1029c:      	stp	x20, x19, [sp, #0x20]
   102a0:      	mov	x29, sp
   102a4:      	ldr	x8, [x0]
   102a8:      	nop
   102ac:      	adr	x1, 0x4b0a
   102b0:      	mov	x19, x0
   102b4:      	ldr	x8, [x8, #0x30]
   102b8:      	blr	x8
   102bc:      	cbz	x0, 0x10540 <_Z20MTARMPMMusicGetSpeedPv+0x5844>
   102c0:      	ldr	x8, [x19]
   102c4:      	mov	x20, x0
   102c8:      	mov	x0, x19
   102cc:      	mov	x1, x20
   102d0:      	ldr	x8, [x8, #0xa8]
   102d4:      	blr	x8
   102d8:      	adrp	x21, 0x1f000
   102dc:      	str	x0, [x21, #0xe20]
   102e0:      	cbz	x0, 0x1054c <_Z20MTARMPMMusicGetSpeedPv+0x5850>
   102e4:      	ldr	x8, [x19]
   102e8:      	mov	x0, x19
   102ec:      	mov	x1, x20
   102f0:      	ldr	x8, [x8, #0xb8]
   102f4:      	blr	x8
   102f8:      	ldr	x8, [x19]
   102fc:      	ldr	x1, [x21, #0xe20]
   10300:      	adrp	x2, 0x5000
   10304:      	add	x2, x2, #0x6f9
   10308:      	adrp	x3, 0x4000
   1030c:      	add	x3, x3, #0xc61
   10310:      	ldr	x8, [x8, #0x108]
   10314:      	mov	x0, x19
   10318:      	blr	x8
   1031c:      	adrp	x8, 0x1f000
   10320:      	str	x0, [x8, #0xe28]
   10324:      	cbz	x0, 0x10558 <_Z20MTARMPMMusicGetSpeedPv+0x585c>
   10328:      	ldr	x8, [x19]
   1032c:      	ldr	x1, [x21, #0xe20]
   10330:      	adrp	x2, 0x4000
   10334:      	add	x2, x2, #0xd97
   10338:      	adrp	x3, 0x5000
   1033c:      	add	x3, x3, #0xd0b
   10340:      	ldr	x8, [x8, #0x388]
   10344:      	mov	x0, x19
   10348:      	blr	x8
   1034c:      	adrp	x8, 0x1f000
   10350:      	str	x0, [x8, #0xe30]
   10354:      	cbz	x0, 0x10564 <_Z20MTARMPMMusicGetSpeedPv+0x5868>
   10358:      	ldr	x8, [x19]
   1035c:      	ldr	x1, [x21, #0xe20]
   10360:      	adrp	x2, 0x5000
   10364:      	add	x2, x2, #0x64e
   10368:      	adrp	x3, 0x4000
   1036c:      	add	x3, x3, #0xe85
   10370:      	ldr	x8, [x8, #0x388]
   10374:      	mov	x0, x19
   10378:      	blr	x8
   1037c:      	adrp	x8, 0x1f000
   10380:      	str	x0, [x8, #0xe38]
   10384:      	cbz	x0, 0x10570 <_Z20MTARMPMMusicGetSpeedPv+0x5874>
   10388:      	ldr	x8, [x19]
   1038c:      	ldr	x1, [x21, #0xe20]
   10390:      	adrp	x2, 0x4000
   10394:      	add	x2, x2, #0xe89
   10398:      	adrp	x3, 0x4000
   1039c:      	add	x3, x3, #0xe85
   103a0:      	ldr	x8, [x8, #0x388]
   103a4:      	mov	x0, x19
   103a8:      	blr	x8
   103ac:      	adrp	x8, 0x1f000
   103b0:      	str	x0, [x8, #0xe40]
   103b4:      	cbz	x0, 0x1057c <_Z20MTARMPMMusicGetSpeedPv+0x5880>
   103b8:      	ldr	x8, [x19]
   103bc:      	ldr	x1, [x21, #0xe20]
   103c0:      	adrp	x2, 0x5000
   103c4:      	add	x2, x2, #0xcac
   103c8:      	adrp	x3, 0x5000
   103cc:      	add	x3, x3, #0x83c
   103d0:      	ldr	x8, [x8, #0x388]
   103d4:      	mov	x0, x19
   103d8:      	blr	x8
   103dc:      	adrp	x8, 0x1f000
   103e0:      	str	x0, [x8, #0xe48]
   103e4:      	cbz	x0, 0x10588 <_Z20MTARMPMMusicGetSpeedPv+0x588c>
   103e8:      	ldr	x8, [x19]
   103ec:      	ldr	x1, [x21, #0xe20]
   103f0:      	adrp	x2, 0x4000
   103f4:      	add	x2, x2, #0x90a
   103f8:      	adrp	x3, 0x4000
   103fc:      	add	x3, x3, #0x9ef
   10400:      	ldr	x8, [x8, #0x108]
   10404:      	mov	x0, x19
   10408:      	blr	x8
   1040c:      	adrp	x8, 0x1f000
   10410:      	str	x0, [x8, #0xe50]
   10414:      	cbz	x0, 0x10594 <_Z20MTARMPMMusicGetSpeedPv+0x5898>
   10418:      	ldr	x8, [x19]
   1041c:      	ldr	x1, [x21, #0xe20]
   10420:      	adrp	x2, 0x5000
   10424:      	add	x2, x2, #0xd12
   10428:      	adrp	x3, 0x4000
   1042c:      	add	x3, x3, #0x9ef
   10430:      	ldr	x8, [x8, #0x108]
   10434:      	mov	x0, x19
   10438:      	blr	x8
   1043c:      	adrp	x8, 0x1f000
   10440:      	str	x0, [x8, #0xe58]
   10444:      	cbz	x0, 0x105a0 <_Z20MTARMPMMusicGetSpeedPv+0x58a4>
   10448:      	ldr	x8, [x19]
   1044c:      	ldr	x1, [x21, #0xe20]
   10450:      	adrp	x2, 0x5000
   10454:      	add	x2, x2, #0xa36
   10458:      	adrp	x3, 0x4000
   1045c:      	add	x3, x3, #0x9ef
   10460:      	ldr	x8, [x8, #0x108]
   10464:      	mov	x0, x19
   10468:      	blr	x8
   1046c:      	adrp	x8, 0x1f000
   10470:      	str	x0, [x8, #0xe60]
   10474:      	cbz	x0, 0x105ac <_Z20MTARMPMMusicGetSpeedPv+0x58b0>
   10478:      	ldr	x8, [x19]
   1047c:      	ldr	x1, [x21, #0xe20]
   10480:      	adrp	x2, 0x5000
   10484:      	add	x2, x2, #0xb09
   10488:      	adrp	x3, 0x4000
   1048c:      	add	x3, x3, #0x9ef
   10490:      	ldr	x8, [x8, #0x108]
   10494:      	mov	x0, x19
   10498:      	blr	x8
   1049c:      	adrp	x8, 0x1f000
   104a0:      	str	x0, [x8, #0xe68]
   104a4:      	cbz	x0, 0x105b8 <_Z20MTARMPMMusicGetSpeedPv+0x58bc>
   104a8:      	ldr	x8, [x19]
   104ac:      	ldr	x1, [x21, #0xe20]
   104b0:      	adrp	x2, 0x5000
   104b4:      	add	x2, x2, #0x720
   104b8:      	adrp	x3, 0x4000
   104bc:      	add	x3, x3, #0x9ef
   104c0:      	ldr	x8, [x8, #0x108]
   104c4:      	mov	x0, x19
   104c8:      	blr	x8
   104cc:      	adrp	x8, 0x1f000
   104d0:      	str	x0, [x8, #0xe70]
   104d4:      	cbz	x0, 0x105c4 <_Z20MTARMPMMusicGetSpeedPv+0x58c8>
   104d8:      	ldr	x8, [x19]
   104dc:      	ldr	x1, [x21, #0xe20]
   104e0:      	adrp	x2, 0x4000
   104e4:      	add	x2, x2, #0xbdf
   104e8:      	adrp	x3, 0x4000
   104ec:      	add	x3, x3, #0xbe5
   104f0:      	ldr	x8, [x8, #0x108]
   104f4:      	mov	x0, x19
   104f8:      	blr	x8
   104fc:      	adrp	x8, 0x1f000
   10500:      	str	x0, [x8, #0xe78]
   10504:      	cbz	x0, 0x105d0 <_Z20MTARMPMMusicGetSpeedPv+0x58d4>
   10508:      	ldr	x8, [x19]
   1050c:      	ldr	x1, [x21, #0xe20]
   10510:      	adrp	x2, 0x5000
   10514:      	add	x2, x2, #0xe51
   10518:      	adrp	x3, 0x4000
   1051c:      	add	x3, x3, #0xbed
   10520:      	ldr	x8, [x8, #0x108]
   10524:      	mov	x0, x19
   10528:      	blr	x8
   1052c:      	adrp	x8, 0x1f000
   10530:      	str	x0, [x8, #0xe80]
   10534:      	cbz	x0, 0x105dc <_Z20MTARMPMMusicGetSpeedPv+0x58e0>
   10538:      	mov	w0, wzr
   1053c:      	b	0x105f8 <_Z20MTARMPMMusicGetSpeedPv+0x58fc>
   10540:      	adrp	x2, 0x5000
   10544:      	add	x2, x2, #0xa23
   10548:      	b	0x105e4 <_Z20MTARMPMMusicGetSpeedPv+0x58e8>
   1054c:      	adrp	x2, 0x5000
   10550:      	add	x2, x2, #0xbe5
   10554:      	b	0x105e4 <_Z20MTARMPMMusicGetSpeedPv+0x58e8>
   10558:      	adrp	x2, 0x5000
   1055c:      	add	x2, x2, #0x443
   10560:      	b	0x105e4 <_Z20MTARMPMMusicGetSpeedPv+0x58e8>
   10564:      	adrp	x2, 0x4000
   10568:      	add	x2, x2, #0x9cb
   1056c:      	b	0x105e4 <_Z20MTARMPMMusicGetSpeedPv+0x58e8>
   10570:      	adrp	x2, 0x5000
   10574:      	add	x2, x2, #0x700
   10578:      	b	0x105e4 <_Z20MTARMPMMusicGetSpeedPv+0x58e8>
   1057c:      	adrp	x2, 0x5000
   10580:      	add	x2, x2, #0x920
   10584:      	b	0x105e4 <_Z20MTARMPMMusicGetSpeedPv+0x58e8>
   10588:      	adrp	x2, 0x5000
   1058c:      	add	x2, x2, #0x26
   10590:      	b	0x105e4 <_Z20MTARMPMMusicGetSpeedPv+0x58e8>
   10594:      	adrp	x2, 0x4000
   10598:      	add	x2, x2, #0x9f3
   1059c:      	b	0x105e4 <_Z20MTARMPMMusicGetSpeedPv+0x58e8>
   105a0:      	adrp	x2, 0x4000
   105a4:      	add	x2, x2, #0xa0b
   105a8:      	b	0x105e4 <_Z20MTARMPMMusicGetSpeedPv+0x58e8>
   105ac:      	adrp	x2, 0x4000
   105b0:      	add	x2, x2, #0x5e8
   105b4:      	b	0x105e4 <_Z20MTARMPMMusicGetSpeedPv+0x58e8>
   105b8:      	adrp	x2, 0x5000
   105bc:      	add	x2, x2, #0xd8a
   105c0:      	b	0x105e4 <_Z20MTARMPMMusicGetSpeedPv+0x58e8>
   105c4:      	adrp	x2, 0x4000
   105c8:      	add	x2, x2, #0x81c
   105cc:      	b	0x105e4 <_Z20MTARMPMMusicGetSpeedPv+0x58e8>
   105d0:      	adrp	x2, 0x5000
   105d4:      	add	x2, x2, #0x2d8
   105d8:      	b	0x105e4 <_Z20MTARMPMMusicGetSpeedPv+0x58e8>
   105dc:      	adrp	x2, 0x5000
   105e0:      	add	x2, x2, #0x728
   105e4:      	adrp	x1, 0x4000
   105e8:      	add	x1, x1, #0xe4c
   105ec:      	mov	w0, #0x6                // =6
   105f0:      	bl	0x16e90 <__android_log_print@plt>
   105f4:      	mov	w0, #-0x1               // =-1
   105f8:      	ldp	x20, x19, [sp, #0x20]
   105fc:      	ldr	x21, [sp, #0x10]
   10600:      	ldp	x29, x30, [sp], #0x30
   10604:      	ret
   10608:      	b	0x1060c <_Z20MTARMPMMusicGetSpeedPv+0x5910>
   1060c:      	stp	x29, x30, [sp, #-0x20]!
   10610:      	str	x19, [sp, #0x10]
   10614:      	mov	x29, sp
   10618:      	fcvt	d0, s0
   1061c:      	fcvt	d1, s1
   10620:      	adrp	x8, 0x1f000
   10624:      	ldr	x1, [x1]
   10628:      	ldr	x2, [x8, #0xe80]
   1062c:      	mov	x19, x0
   10630:      	bl	0x1134c <_Z20MTARMPMMusicGetSpeedPv+0x6650>
   10634:      	ldr	x8, [x19]
   10638:      	mov	x0, x19
   1063c:      	ldr	x8, [x8, #0x720]
   10640:      	blr	x8
   10644:      	tst	w0, #0xff
   10648:      	b.eq	0x106a4 <_Z20MTARMPMMusicGetSpeedPv+0x59a8>
   1064c:      	adrp	x1, 0x4000
   10650:      	add	x1, x1, #0xe4c
   10654:      	adrp	x2, 0x5000
   10658:      	add	x2, x2, #0x471
   1065c:      	mov	w0, #0x6                // =6
   10660:      	bl	0x16e90 <__android_log_print@plt>
   10664:      	ldr	x8, [x19]
   10668:      	mov	x0, x19
   1066c:      	ldr	x8, [x8, #0x720]
   10670:      	blr	x8
   10674:      	tst	w0, #0xff
   10678:      	b.eq	0x106a4 <_Z20MTARMPMMusicGetSpeedPv+0x59a8>
   1067c:      	ldr	x8, [x19]
   10680:      	mov	x0, x19
   10684:      	ldr	x8, [x8, #0x80]
   10688:      	blr	x8
   1068c:      	ldr	x8, [x19]
   10690:      	ldr	x1, [x8, #0x88]
   10694:      	mov	x0, x19
   10698:      	ldr	x19, [sp, #0x10]
   1069c:      	ldp	x29, x30, [sp], #0x20
   106a0:      	br	x1
   106a4:      	ldr	x19, [sp, #0x10]
   106a8:      	ldp	x29, x30, [sp], #0x20
   106ac:      	ret
   106b0:      	sub	sp, sp, #0x70
   106b4:      	str	d10, [sp, #0x10]
   106b8:      	stp	d9, d8, [sp, #0x18]
   106bc:      	stp	x29, x30, [sp, #0x28]
   106c0:      	str	x25, [sp, #0x38]
   106c4:      	stp	x24, x23, [sp, #0x40]
   106c8:      	stp	x22, x21, [sp, #0x50]
   106cc:      	stp	x20, x19, [sp, #0x60]
   106d0:      	add	x29, sp, #0x28
   106d4:      	ldr	w3, [x1, #0x8]
   106d8:      	mov	x22, x1
   106dc:      	mov	x19, x0
   106e0:      	cmp	w3, #0x4
   106e4:      	b.eq	0x106fc <_Z20MTARMPMMusicGetSpeedPv+0x5a00>
   106e8:      	cmp	w3, #0xc
   106ec:      	b.ne	0x1073c <_Z20MTARMPMMusicGetSpeedPv+0x5a40>
   106f0:      	adrp	x3, 0x5000
   106f4:      	add	x3, x3, #0xcc6
   106f8:      	b	0x10704 <_Z20MTARMPMMusicGetSpeedPv+0x5a08>
   106fc:      	adrp	x3, 0x4000
   10700:      	add	x3, x3, #0x601
   10704:      	adrp	x1, 0x4000
   10708:      	add	x1, x1, #0xe4c
   1070c:      	adrp	x2, 0x5000
   10710:      	add	x2, x2, #0xd18
   10714:      	mov	w0, #0x4                // =4
   10718:      	bl	0x16e90 <__android_log_print@plt>
   1071c:      	ldr	w3, [x22, #0xc]
   10720:      	cmp	w3, #0x2
   10724:      	b.eq	0x10750 <_Z20MTARMPMMusicGetSpeedPv+0x5a54>
   10728:      	cmp	w3, #0x3
   1072c:      	b.ne	0x10820 <_Z20MTARMPMMusicGetSpeedPv+0x5b24>
   10730:      	adrp	x3, 0x4000
   10734:      	add	x3, x3, #0x90f
   10738:      	b	0x10758 <_Z20MTARMPMMusicGetSpeedPv+0x5a5c>
   1073c:      	adrp	x1, 0x4000
   10740:      	add	x1, x1, #0xe4c
   10744:      	adrp	x2, 0x5000
   10748:      	add	x2, x2, #0x53
   1074c:      	b	0x10830 <_Z20MTARMPMMusicGetSpeedPv+0x5b34>
   10750:      	adrp	x3, 0x5000
   10754:      	add	x3, x3, #0x3cd
   10758:      	adrp	x1, 0x4000
   1075c:      	add	x1, x1, #0xe4c
   10760:      	adrp	x2, 0x5000
   10764:      	add	x2, x2, #0xd18
   10768:      	mov	w0, #0x4                // =4
   1076c:      	bl	0x16e90 <__android_log_print@plt>
   10770:      	mov	w0, #0x1                // =1
   10774:      	mov	w1, #0x40               // =64
   10778:      	bl	0x170f0 <calloc@plt>
   1077c:      	mov	x20, x0
   10780:      	cbz	x0, 0x1083c <_Z20MTARMPMMusicGetSpeedPv+0x5b40>
   10784:      	ldr	q0, [x22]
   10788:      	mov	w8, #-0xbb81            // =-48001
   1078c:      	mov	w9, #-0xabe2            // =-44002
   10790:      	adrp	x25, 0x1f000
   10794:      	stur	q0, [x20, #0x8]
   10798:      	ldur	q0, [x22, #0xc]
   1079c:      	ldr	w21, [x20, #0xc]
   107a0:      	stur	q0, [x20, #0x14]
   107a4:      	add	w8, w21, w8
   107a8:      	cmp	w8, w9
   107ac:      	b.hi	0x10890 <_Z20MTARMPMMusicGetSpeedPv+0x5b94>
   107b0:      	adrp	x8, 0x1f000
   107b4:      	ldr	x1, [x25, #0xe20]
   107b8:      	mov	x0, x19
   107bc:      	ldr	x2, [x8, #0xe48]
   107c0:      	mov	w3, #0x3                // =3
   107c4:      	bl	0x113e8 <_Z20MTARMPMMusicGetSpeedPv+0x66ec>
   107c8:      	ldr	x8, [x19]
   107cc:      	mov	w22, w0
   107d0:      	mov	x0, x19
   107d4:      	ldr	x8, [x8, #0x720]
   107d8:      	blr	x8
   107dc:      	tst	w0, #0xff
   107e0:      	b.eq	0x10860 <_Z20MTARMPMMusicGetSpeedPv+0x5b64>
   107e4:      	adrp	x1, 0x4000
   107e8:      	add	x1, x1, #0xe4c
   107ec:      	adrp	x2, 0x4000
   107f0:      	add	x2, x2, #0x6f1
   107f4:      	mov	w0, #0x6                // =6
   107f8:      	bl	0x16e90 <__android_log_print@plt>
   107fc:      	ldr	x8, [x19]
   10800:      	mov	x0, x19
   10804:      	ldr	x8, [x8, #0x80]
   10808:      	blr	x8
   1080c:      	ldr	x8, [x19]
   10810:      	mov	x0, x19
   10814:      	ldr	x8, [x8, #0x88]
   10818:      	blr	x8
   1081c:      	b	0x10890 <_Z20MTARMPMMusicGetSpeedPv+0x5b94>
   10820:      	adrp	x1, 0x4000
   10824:      	add	x1, x1, #0xe4c
   10828:      	adrp	x2, 0x4000
   1082c:      	add	x2, x2, #0x669
   10830:      	mov	w0, #0x6                // =6
   10834:      	bl	0x16e90 <__android_log_print@plt>
   10838:      	b	0x10930 <_Z20MTARMPMMusicGetSpeedPv+0x5c34>
   1083c:      	adrp	x1, 0x4000
   10840:      	add	x1, x1, #0xe4c
   10844:      	adrp	x2, 0x5000
   10848:      	add	x2, x2, #0x45d
   1084c:      	adrp	x3, 0x5000
   10850:      	add	x3, x3, #0x33b
   10854:      	mov	w0, #0x6                // =6
   10858:      	bl	0x16e90 <__android_log_print@plt>
   1085c:      	b	0x10934 <_Z20MTARMPMMusicGetSpeedPv+0x5c38>
   10860:      	cmp	w22, #0x1
   10864:      	b.lt	0x10890 <_Z20MTARMPMMusicGetSpeedPv+0x5b94>
   10868:      	adrp	x1, 0x4000
   1086c:      	add	x1, x1, #0xe4c
   10870:      	adrp	x2, 0x5000
   10874:      	add	x2, x2, #0xd32
   10878:      	mov	w0, #0x6                // =6
   1087c:      	mov	w3, w21
   10880:      	mov	w4, w22
   10884:      	bl	0x16e90 <__android_log_print@plt>
   10888:      	mov	w21, w22
   1088c:      	str	w22, [x20, #0xc]
   10890:      	ldp	w23, w24, [x20, #0x10]
   10894:      	adrp	x8, 0x1f000
   10898:      	ldr	x1, [x25, #0xe20]
   1089c:      	mov	x0, x19
   108a0:      	ldr	x2, [x8, #0xe30]
   108a4:      	mov	w3, w21
   108a8:      	mov	w4, w23
   108ac:      	mov	w5, w24
   108b0:      	bl	0x113e8 <_Z20MTARMPMMusicGetSpeedPv+0x66ec>
   108b4:      	ldr	x8, [x19]
   108b8:      	mov	w22, w0
   108bc:      	mov	x0, x19
   108c0:      	ldr	x8, [x8, #0x720]
   108c4:      	blr	x8
   108c8:      	tst	w0, #0xff
   108cc:      	b.eq	0x1095c <_Z20MTARMPMMusicGetSpeedPv+0x5c60>
   108d0:      	adrp	x1, 0x4000
   108d4:      	add	x1, x1, #0xe4c
   108d8:      	adrp	x2, 0x4000
   108dc:      	add	x2, x2, #0x734
   108e0:      	mov	w0, #0x6                // =6
   108e4:      	bl	0x16e90 <__android_log_print@plt>
   108e8:      	ldr	x8, [x19]
   108ec:      	mov	x0, x19
   108f0:      	ldr	x8, [x8, #0x80]
   108f4:      	blr	x8
   108f8:      	ldr	x8, [x19]
   108fc:      	mov	x0, x19
   10900:      	ldr	x8, [x8, #0x88]
   10904:      	blr	x8
   10908:      	mov	w22, #-0x1              // =-1
   1090c:      	adrp	x1, 0x4000
   10910:      	add	x1, x1, #0xe4c
   10914:      	adrp	x2, 0x5000
   10918:      	add	x2, x2, #0x65b
   1091c:      	mov	w0, #0x6                // =6
   10920:      	mov	w3, w22
   10924:      	bl	0x16e90 <__android_log_print@plt>
   10928:      	mov	x0, x20
   1092c:      	bl	0x17100 <free@plt>
   10930:      	mov	x20, xzr
   10934:      	mov	x0, x20
   10938:      	ldp	x20, x19, [sp, #0x60]
   1093c:      	ldr	x25, [sp, #0x38]
   10940:      	ldp	x22, x21, [sp, #0x50]
   10944:      	ldr	d10, [sp, #0x10]
   10948:      	ldp	x24, x23, [sp, #0x40]
   1094c:      	ldp	x29, x30, [sp, #0x28]
   10950:      	ldp	d9, d8, [sp, #0x18]
   10954:      	add	sp, sp, #0x70
   10958:      	ret
   1095c:      	cmp	w22, #0x0
   10960:      	b.le	0x1090c <_Z20MTARMPMMusicGetSpeedPv+0x5c10>
   10964:      	adrp	x8, 0x1f000
   10968:      	ldr	x1, [x25, #0xe20]
   1096c:      	ldr	w3, [x20, #0x8]
   10970:      	ldr	x2, [x8, #0xe28]
   10974:      	ldr	w8, [x20, #0x1c]
   10978:      	mov	x0, x19
   1097c:      	mov	w4, w21
   10980:      	mov	w5, w23
   10984:      	mov	w6, w24
   10988:      	mov	w7, w22
   1098c:      	str	w8, [sp]
   10990:      	bl	0x10b6c <_Z20MTARMPMMusicGetSpeedPv+0x5e70>
   10994:      	cbz	x0, 0x109b4 <_Z20MTARMPMMusicGetSpeedPv+0x5cb8>
   10998:      	ldr	x8, [x19]
   1099c:      	mov	x21, x0
   109a0:      	mov	x0, x19
   109a4:      	ldr	x8, [x8, #0x720]
   109a8:      	blr	x8
   109ac:      	tst	w0, #0xff
   109b0:      	b.eq	0x10a08 <_Z20MTARMPMMusicGetSpeedPv+0x5d0c>
   109b4:      	adrp	x1, 0x4000
   109b8:      	add	x1, x1, #0xe4c
   109bc:      	adrp	x2, 0x4000
   109c0:      	add	x2, x2, #0x699
   109c4:      	mov	w0, #0x6                // =6
   109c8:      	bl	0x16e90 <__android_log_print@plt>
   109cc:      	ldr	x8, [x19]
   109d0:      	mov	x0, x19
   109d4:      	ldr	x8, [x8, #0x720]
   109d8:      	blr	x8
   109dc:      	tst	w0, #0xff
   109e0:      	b.eq	0x10928 <_Z20MTARMPMMusicGetSpeedPv+0x5c2c>
   109e4:      	ldr	x8, [x19]
   109e8:      	mov	x0, x19
   109ec:      	ldr	x8, [x8, #0x80]
   109f0:      	blr	x8
   109f4:      	ldr	x8, [x19]
   109f8:      	mov	x0, x19
   109fc:      	ldr	x8, [x8, #0x88]
   10a00:      	blr	x8
   10a04:      	b	0x10928 <_Z20MTARMPMMusicGetSpeedPv+0x5c2c>
   10a08:      	adrp	x8, 0x1f000
   10a0c:      	ldr	x1, [x25, #0xe20]
   10a10:      	mov	x0, x19
   10a14:      	ldr	x2, [x8, #0xe38]
   10a18:      	str	w22, [x20, #0x34]
   10a1c:      	str	w22, [x20, #0x18]
   10a20:      	bl	0x11484 <_Z20MTARMPMMusicGetSpeedPv+0x6788>
   10a24:      	ldr	x8, [x19]
   10a28:      	mov	x0, x19
   10a2c:      	fmov	s8, s0
   10a30:      	ldr	x8, [x8, #0x720]
   10a34:      	blr	x8
   10a38:      	tst	w0, #0xff
   10a3c:      	b.eq	0x10a7c <_Z20MTARMPMMusicGetSpeedPv+0x5d80>
   10a40:      	adrp	x1, 0x4000
   10a44:      	add	x1, x1, #0xe4c
   10a48:      	adrp	x2, 0x5000
   10a4c:      	add	x2, x2, #0x84
   10a50:      	mov	w0, #0x6                // =6
   10a54:      	bl	0x16e90 <__android_log_print@plt>
   10a58:      	ldr	x8, [x19]
   10a5c:      	mov	x0, x19
   10a60:      	ldr	x8, [x8, #0x80]
   10a64:      	blr	x8
   10a68:      	ldr	x8, [x19]
   10a6c:      	mov	x0, x19
   10a70:      	ldr	x8, [x8, #0x88]
   10a74:      	blr	x8
   10a78:      	fmov	s8, #-1.00000000
   10a7c:      	adrp	x8, 0x1f000
   10a80:      	ldr	x1, [x25, #0xe20]
   10a84:      	mov	x0, x19
   10a88:      	ldr	x2, [x8, #0xe40]
   10a8c:      	str	s8, [x20, #0x38]
   10a90:      	bl	0x11484 <_Z20MTARMPMMusicGetSpeedPv+0x6788>
   10a94:      	ldr	x8, [x19]
   10a98:      	mov	x0, x19
   10a9c:      	fmov	s9, s0
   10aa0:      	ldr	x8, [x8, #0x720]
   10aa4:      	blr	x8
   10aa8:      	tst	w0, #0xff
   10aac:      	b.eq	0x10aec <_Z20MTARMPMMusicGetSpeedPv+0x5df0>
   10ab0:      	adrp	x1, 0x4000
   10ab4:      	add	x1, x1, #0xe4c
   10ab8:      	adrp	x2, 0x4000
   10abc:      	add	x2, x2, #0xa24
   10ac0:      	mov	w0, #0x6                // =6
   10ac4:      	bl	0x16e90 <__android_log_print@plt>
   10ac8:      	ldr	x8, [x19]
   10acc:      	mov	x0, x19
   10ad0:      	ldr	x8, [x8, #0x80]
   10ad4:      	blr	x8
   10ad8:      	ldr	x8, [x19]
   10adc:      	mov	x0, x19
   10ae0:      	ldr	x8, [x8, #0x88]
   10ae4:      	blr	x8
   10ae8:      	fmov	s9, #-1.00000000
   10aec:      	ldr	x8, [x19]
   10af0:      	mov	x0, x19
   10af4:      	mov	x1, x21
   10af8:      	str	s9, [x20, #0x3c]
   10afc:      	ldr	x8, [x8, #0xa8]
   10b00:      	blr	x8
   10b04:      	ldr	x8, [x19]
   10b08:      	str	x0, [x20]
   10b0c:      	mov	x0, x19
   10b10:      	mov	x1, x21
   10b14:      	ldr	x8, [x8, #0xb8]
   10b18:      	blr	x8
   10b1c:      	fmov	s0, #1.00000000
   10b20:      	fcvt	d1, s9
   10b24:      	adrp	x1, 0x4000
   10b28:      	add	x1, x1, #0xe4c
   10b2c:      	fcvt	d2, s8
   10b30:      	adrp	x2, 0x4000
   10b34:      	add	x2, x2, #0x6c3
   10b38:      	mov	w0, #0x4                // =4
   10b3c:      	fcmp	s8, s0
   10b40:      	fcsel	s0, s0, s8, gt
   10b44:      	fcmp	s0, s9
   10b48:      	fcsel	s10, s0, s9, gt
   10b4c:      	fcvt	d0, s10
   10b50:      	bl	0x16e90 <__android_log_print@plt>
   10b54:      	fmov	s0, s10
   10b58:      	fmov	s1, s10
   10b5c:      	mov	x0, x19
   10b60:      	mov	x1, x20
   10b64:      	bl	0x1060c <_Z20MTARMPMMusicGetSpeedPv+0x5910>
   10b68:      	b	0x10934 <_Z20MTARMPMMusicGetSpeedPv+0x5c38>
   10b6c:      	sub	sp, sp, #0x120
   10b70:      	stp	x29, x30, [sp, #0x100]
   10b74:      	stp	x28, x19, [sp, #0x110]
   10b78:      	add	x29, sp, #0x100
   10b7c:      	stp	x3, x4, [x29, #-0x78]
   10b80:      	sub	x9, x29, #0x78
   10b84:      	mov	x10, sp
   10b88:      	stp	x5, x6, [x29, #-0x68]
   10b8c:      	add	x10, x10, #0x80
   10b90:      	sub	x3, x29, #0x50
   10b94:      	stur	x7, [x29, #-0x58]
   10b98:      	stp	q0, q1, [sp]
   10b9c:      	stp	q2, q3, [sp, #0x20]
   10ba0:      	stp	q4, q5, [sp, #0x40]
   10ba4:      	stp	q6, q7, [sp, #0x60]
   10ba8:      	mrs	x19, TPIDR_EL0
   10bac:      	ldr	x8, [x19, #0x28]
   10bb0:      	stur	x8, [x29, #-0x8]
   10bb4:      	add	x8, x9, #0x28
   10bb8:      	add	x9, x29, #0x20
   10bbc:      	stp	x9, x8, [x29, #-0x28]
   10bc0:      	mov	x8, #-0x28              // =-40
   10bc4:      	sub	x9, x29, #0x28
   10bc8:      	movk	x8, #0xff80, lsl #32
   10bcc:      	stp	x10, x8, [x29, #-0x18]
   10bd0:      	ldr	x8, [x0]
   10bd4:      	ldp	q0, q1, [x9]
   10bd8:      	ldr	x8, [x8, #0xe8]
   10bdc:      	stp	q0, q1, [x29, #-0x50]
   10be0:      	blr	x8
   10be4:      	ldr	x8, [x19, #0x28]
   10be8:      	ldur	x9, [x29, #-0x8]
   10bec:      	cmp	x8, x9
   10bf0:      	b.ne	0x10c04 <_Z20MTARMPMMusicGetSpeedPv+0x5f08>
   10bf4:      	ldp	x28, x19, [sp, #0x110]
   10bf8:      	ldp	x29, x30, [sp, #0x100]
   10bfc:      	add	sp, sp, #0x120
   10c00:      	ret
   10c04:      	bl	0x16b40 <__stack_chk_fail@plt>
   10c08:      	sub	sp, sp, #0x50
   10c0c:      	stp	x29, x30, [sp, #0x30]
   10c10:      	str	x19, [sp, #0x40]
   10c14:      	add	x29, sp, #0x30
   10c18:      	mrs	x19, TPIDR_EL0
   10c1c:      	mov	x8, xzr
   10c20:      	mov	w10, #0x1               // =1
   10c24:      	ldr	x9, [x19, #0x28]
   10c28:      	mov	w12, #0x18              // =24
   10c2c:      	stur	x9, [x29, #-0x8]
   10c30:      	mov	w9, #0x3                // =3
   10c34:      	ldr	w11, [x1]
   10c38:      	str	w10, [sp, #0x20]
   10c3c:      	stp	w9, w11, [sp, #0xc]
   10c40:      	ldrb	w9, [x1, #0x6]
   10c44:      	nop
   10c48:      	adr	x11, 0x1b630 <_ZTISt20bad_array_new_length+0xf8>
   10c4c:      	mul	x13, x8, x12
   10c50:      	ldrb	w13, [x11, x13]
   10c54:      	cmp	w13, w9
   10c58:      	b.eq	0x10c74 <_Z20MTARMPMMusicGetSpeedPv+0x5f78>
   10c5c:      	mov	w13, w10
   10c60:      	mov	w10, wzr
   10c64:      	mov	w8, #0x1                // =1
   10c68:      	tbnz	w13, #0x0, 0x10c4c <_Z20MTARMPMMusicGetSpeedPv+0x5f50>
   10c6c:      	mov	w9, wzr
   10c70:      	b	0x10c80 <_Z20MTARMPMMusicGetSpeedPv+0x5f84>
   10c74:      	mov	w9, #0x18               // =24
   10c78:      	madd	x8, x8, x9, x11
   10c7c:      	ldr	w9, [x8, #0x4]
   10c80:      	str	w9, [sp, #0x14]
   10c84:      	ldrh	w9, [x1, #0x4]
   10c88:      	mov	x8, xzr
   10c8c:      	mov	w12, #0x1               // =1
   10c90:      	mov	w11, #0x18              // =24
   10c94:      	nop
   10c98:      	adr	x10, 0x1b660 <_ZTISt20bad_array_new_length+0x128>
   10c9c:      	mul	x13, x8, x11
   10ca0:      	ldrh	w13, [x10, x13]
   10ca4:      	cmp	w13, w9
   10ca8:      	b.eq	0x10cc4 <_Z20MTARMPMMusicGetSpeedPv+0x5fc8>
   10cac:      	mov	w13, w12
   10cb0:      	mov	w12, wzr
   10cb4:      	mov	w8, #0x1                // =1
   10cb8:      	tbnz	w13, #0x0, 0x10c9c <_Z20MTARMPMMusicGetSpeedPv+0x5fa0>
   10cbc:      	mov	w8, wzr
   10cc0:      	b	0x10cd0 <_Z20MTARMPMMusicGetSpeedPv+0x5fd4>
   10cc4:      	mov	w9, #0x18               // =24
   10cc8:      	madd	x8, x8, x9, x10
   10ccc:      	ldr	w8, [x8, #0x4]
   10cd0:      	ldr	w9, [x1, #0xc]
   10cd4:      	add	x1, sp, #0xc
   10cd8:      	stp	w8, w9, [sp, #0x18]
   10cdc:      	bl	0x106b0 <_Z20MTARMPMMusicGetSpeedPv+0x59b4>
   10ce0:      	ldr	x8, [x19, #0x28]
   10ce4:      	ldur	x9, [x29, #-0x8]
   10ce8:      	cmp	x8, x9
   10cec:      	b.ne	0x10d00 <_Z20MTARMPMMusicGetSpeedPv+0x6004>
   10cf0:      	ldp	x29, x30, [sp, #0x30]
   10cf4:      	ldr	x19, [sp, #0x40]
   10cf8:      	add	sp, sp, #0x50
   10cfc:      	ret
   10d00:      	bl	0x16b40 <__stack_chk_fail@plt>
   10d04:      	stp	x29, x30, [sp, #-0x20]!
   10d08:      	stp	x20, x19, [sp, #0x10]
   10d0c:      	mov	x29, sp
   10d10:      	mov	x19, x1
   10d14:      	ldr	x1, [x1, #0x28]
   10d18:      	mov	x20, x0
   10d1c:      	cbz	x1, 0x10d34 <_Z20MTARMPMMusicGetSpeedPv+0x6038>
   10d20:      	ldr	x8, [x20]
   10d24:      	mov	x0, x20
   10d28:      	ldr	x8, [x8, #0xb0]
   10d2c:      	blr	x8
   10d30:      	str	xzr, [x19, #0x28]
   10d34:      	ldr	x8, [x19]
   10d38:      	str	wzr, [x19, #0x30]
   10d3c:      	cbz	x8, 0x10d60 <_Z20MTARMPMMusicGetSpeedPv+0x6064>
   10d40:      	mov	x0, x20
   10d44:      	mov	x1, x19
   10d48:      	bl	0x10d70 <_Z20MTARMPMMusicGetSpeedPv+0x6074>
   10d4c:      	ldr	x8, [x20]
   10d50:      	ldr	x1, [x19]
   10d54:      	mov	x0, x20
   10d58:      	ldr	x8, [x8, #0xb0]
   10d5c:      	blr	x8
   10d60:      	mov	x0, x19
   10d64:      	ldp	x20, x19, [sp, #0x10]
   10d68:      	ldp	x29, x30, [sp], #0x20
   10d6c:      	b	0x17100 <free@plt>
   10d70:      	stp	x29, x30, [sp, #-0x20]!
   10d74:      	str	x19, [sp, #0x10]
   10d78:      	mov	x29, sp
   10d7c:      	adrp	x8, 0x1f000
   10d80:      	ldr	x1, [x1]
   10d84:      	mov	x19, x0
   10d88:      	ldr	x2, [x8, #0xe70]
   10d8c:      	bl	0x10f38 <_Z20MTARMPMMusicGetSpeedPv+0x623c>
   10d90:      	ldr	x8, [x19]
   10d94:      	mov	x0, x19
   10d98:      	ldr	x8, [x8, #0x720]
   10d9c:      	blr	x8
   10da0:      	tst	w0, #0xff
   10da4:      	b.eq	0x10de8 <_Z20MTARMPMMusicGetSpeedPv+0x60ec>
   10da8:      	adrp	x1, 0x4000
   10dac:      	add	x1, x1, #0xe4c
   10db0:      	adrp	x2, 0x4000
   10db4:      	add	x2, x2, #0x837
   10db8:      	mov	w0, #0x6                // =6
   10dbc:      	bl	0x16e90 <__android_log_print@plt>
   10dc0:      	ldr	x8, [x19]
   10dc4:      	mov	x0, x19
   10dc8:      	ldr	x8, [x8, #0x80]
   10dcc:      	blr	x8
   10dd0:      	ldr	x8, [x19]
   10dd4:      	ldr	x1, [x8, #0x88]
   10dd8:      	mov	x0, x19
   10ddc:      	ldr	x19, [sp, #0x10]
   10de0:      	ldp	x29, x30, [sp], #0x20
   10de4:      	br	x1
   10de8:      	ldr	x19, [sp, #0x10]
   10dec:      	ldp	x29, x30, [sp], #0x20
   10df0:      	ret
   10df4:      	ldp	w10, w9, [x0, #0xc]
   10df8:      	mov	x8, xzr
   10dfc:      	mov	w12, #0x1               // =1
   10e00:      	mov	w11, #0x18              // =24
   10e04:      	str	w10, [x1]
   10e08:      	nop
   10e0c:      	adr	x10, 0x1b630 <_ZTISt20bad_array_new_length+0xf8>
   10e10:      	madd	x13, x8, x11, x10
   10e14:      	ldr	w13, [x13, #0x4]
   10e18:      	cmp	w13, w9
   10e1c:      	b.eq	0x10e38 <_Z20MTARMPMMusicGetSpeedPv+0x613c>
   10e20:      	mov	w13, w12
   10e24:      	mov	w12, wzr
   10e28:      	mov	w8, #0x1                // =1
   10e2c:      	tbnz	w13, #0x0, 0x10e10 <_Z20MTARMPMMusicGetSpeedPv+0x6114>
   10e30:      	mov	w9, wzr
   10e34:      	b	0x10e44 <_Z20MTARMPMMusicGetSpeedPv+0x6148>
   10e38:      	mov	w9, #0x18               // =24
   10e3c:      	mul	x8, x8, x9
   10e40:      	ldrb	w9, [x10, x8]
   10e44:      	strb	w9, [x1, #0x6]
   10e48:      	ldr	w9, [x0, #0x14]
   10e4c:      	mov	x8, xzr
   10e50:      	mov	w12, #0x1               // =1
   10e54:      	mov	w11, #0x18              // =24
   10e58:      	nop
   10e5c:      	adr	x10, 0x1b660 <_ZTISt20bad_array_new_length+0x128>
   10e60:      	madd	x13, x8, x11, x10
   10e64:      	ldr	w13, [x13, #0x4]
   10e68:      	cmp	w13, w9
   10e6c:      	b.eq	0x10e88 <_Z20MTARMPMMusicGetSpeedPv+0x618c>
   10e70:      	mov	w13, w12
   10e74:      	mov	w12, wzr
   10e78:      	mov	w8, #0x1                // =1
   10e7c:      	tbnz	w13, #0x0, 0x10e60 <_Z20MTARMPMMusicGetSpeedPv+0x6164>
   10e80:      	mov	w8, wzr
   10e84:      	b	0x10e94 <_Z20MTARMPMMusicGetSpeedPv+0x6198>
   10e88:      	mov	w9, #0x18               // =24
   10e8c:      	mul	x8, x8, x9
   10e90:      	ldrh	w8, [x10, x8]
   10e94:      	strh	w8, [x1, #0x4]
   10e98:      	ldr	w8, [x0, #0x18]
   10e9c:      	strb	wzr, [x1, #0x7]
   10ea0:      	str	w8, [x1, #0xc]
   10ea4:      	strh	wzr, [x1, #0xa]
   10ea8:      	ret
   10eac:      	ldr	w0, [x0, #0x34]
   10eb0:      	ret
   10eb4:      	stp	x29, x30, [sp, #-0x20]!
   10eb8:      	str	x19, [sp, #0x10]
   10ebc:      	mov	x29, sp
   10ec0:      	adrp	x8, 0x1f000
   10ec4:      	ldr	x1, [x1]
   10ec8:      	mov	x19, x0
   10ecc:      	ldr	x2, [x8, #0xe50]
   10ed0:      	bl	0x10f38 <_Z20MTARMPMMusicGetSpeedPv+0x623c>
   10ed4:      	ldr	x8, [x19]
   10ed8:      	mov	x0, x19
   10edc:      	ldr	x8, [x8, #0x720]
   10ee0:      	blr	x8
   10ee4:      	tst	w0, #0xff
   10ee8:      	b.eq	0x10f2c <_Z20MTARMPMMusicGetSpeedPv+0x6230>
   10eec:      	adrp	x1, 0x4000
   10ef0:      	add	x1, x1, #0xe4c
   10ef4:      	adrp	x2, 0x4000
   10ef8:      	add	x2, x2, #0xf96
   10efc:      	mov	w0, #0x6                // =6
   10f00:      	bl	0x16e90 <__android_log_print@plt>
   10f04:      	ldr	x8, [x19]
   10f08:      	mov	x0, x19
   10f0c:      	ldr	x8, [x8, #0x80]
   10f10:      	blr	x8
   10f14:      	ldr	x8, [x19]
   10f18:      	ldr	x1, [x8, #0x88]
   10f1c:      	mov	x0, x19
   10f20:      	ldr	x19, [sp, #0x10]
   10f24:      	ldp	x29, x30, [sp], #0x20
   10f28:      	br	x1
   10f2c:      	ldr	x19, [sp, #0x10]
   10f30:      	ldp	x29, x30, [sp], #0x20
   10f34:      	ret
   10f38:      	sub	sp, sp, #0x120
   10f3c:      	stp	x29, x30, [sp, #0x100]
   10f40:      	stp	x28, x19, [sp, #0x110]
   10f44:      	add	x29, sp, #0x100
   10f48:      	stp	x3, x4, [x29, #-0x78]
   10f4c:      	sub	x9, x29, #0x78
   10f50:      	mov	x10, sp
   10f54:      	stp	x5, x6, [x29, #-0x68]
   10f58:      	add	x10, x10, #0x80
   10f5c:      	sub	x3, x29, #0x50
   10f60:      	stur	x7, [x29, #-0x58]
   10f64:      	stp	q0, q1, [sp]
   10f68:      	stp	q2, q3, [sp, #0x20]
   10f6c:      	stp	q4, q5, [sp, #0x40]
   10f70:      	stp	q6, q7, [sp, #0x60]
   10f74:      	mrs	x19, TPIDR_EL0
   10f78:      	ldr	x8, [x19, #0x28]
   10f7c:      	stur	x8, [x29, #-0x8]
   10f80:      	add	x8, x9, #0x28
   10f84:      	add	x9, x29, #0x20
   10f88:      	stp	x9, x8, [x29, #-0x28]
   10f8c:      	mov	x8, #-0x28              // =-40
   10f90:      	sub	x9, x29, #0x28
   10f94:      	movk	x8, #0xff80, lsl #32
   10f98:      	stp	x10, x8, [x29, #-0x18]
   10f9c:      	ldr	x8, [x0]
   10fa0:      	ldp	q0, q1, [x9]
   10fa4:      	ldr	x8, [x8, #0x1f0]
   10fa8:      	stp	q0, q1, [x29, #-0x50]
   10fac:      	blr	x8
   10fb0:      	ldr	x8, [x19, #0x28]
   10fb4:      	ldur	x9, [x29, #-0x8]
   10fb8:      	cmp	x8, x9
   10fbc:      	b.ne	0x10fd0 <_Z20MTARMPMMusicGetSpeedPv+0x62d4>
   10fc0:      	ldp	x28, x19, [sp, #0x110]
   10fc4:      	ldp	x29, x30, [sp, #0x100]
   10fc8:      	add	sp, sp, #0x120
   10fcc:      	ret
   10fd0:      	bl	0x16b40 <__stack_chk_fail@plt>
   10fd4:      	stp	x29, x30, [sp, #-0x20]!
   10fd8:      	str	x19, [sp, #0x10]
   10fdc:      	mov	x29, sp
   10fe0:      	adrp	x8, 0x1f000
   10fe4:      	ldr	x1, [x1]
   10fe8:      	mov	x19, x0
   10fec:      	ldr	x2, [x8, #0xe58]
   10ff0:      	bl	0x10f38 <_Z20MTARMPMMusicGetSpeedPv+0x623c>
   10ff4:      	ldr	x8, [x19]
   10ff8:      	mov	x0, x19
   10ffc:      	ldr	x8, [x8, #0x720]
   11000:      	blr	x8
   11004:      	tst	w0, #0xff
   11008:      	b.eq	0x1104c <_Z20MTARMPMMusicGetSpeedPv+0x6350>
   1100c:      	adrp	x1, 0x4000
   11010:      	add	x1, x1, #0xe4c
   11014:      	adrp	x2, 0x4000
   11018:      	add	x2, x2, #0xe96
   1101c:      	mov	w0, #0x6                // =6
   11020:      	bl	0x16e90 <__android_log_print@plt>
   11024:      	ldr	x8, [x19]
   11028:      	mov	x0, x19
   1102c:      	ldr	x8, [x8, #0x80]
   11030:      	blr	x8
   11034:      	ldr	x8, [x19]
   11038:      	ldr	x1, [x8, #0x88]
   1103c:      	mov	x0, x19
   11040:      	ldr	x19, [sp, #0x10]
   11044:      	ldp	x29, x30, [sp], #0x20
   11048:      	br	x1
   1104c:      	ldr	x19, [sp, #0x10]
   11050:      	ldp	x29, x30, [sp], #0x20
   11054:      	ret
   11058:      	stp	x29, x30, [sp, #-0x20]!
   1105c:      	str	x19, [sp, #0x10]
   11060:      	mov	x29, sp
   11064:      	adrp	x8, 0x1f000
   11068:      	ldr	x1, [x1]
   1106c:      	mov	x19, x0
   11070:      	ldr	x2, [x8, #0xe60]
   11074:      	bl	0x10f38 <_Z20MTARMPMMusicGetSpeedPv+0x623c>
   11078:      	ldr	x8, [x19]
   1107c:      	mov	x0, x19
   11080:      	ldr	x8, [x8, #0x720]
   11084:      	blr	x8
   11088:      	tst	w0, #0xff
   1108c:      	b.eq	0x110d0 <_Z20MTARMPMMusicGetSpeedPv+0x63d4>
   11090:      	adrp	x1, 0x4000
   11094:      	add	x1, x1, #0xe4c
   11098:      	adrp	x2, 0x4000
   1109c:      	add	x2, x2, #0xebe
   110a0:      	mov	w0, #0x6                // =6
   110a4:      	bl	0x16e90 <__android_log_print@plt>
   110a8:      	ldr	x8, [x19]
   110ac:      	mov	x0, x19
   110b0:      	ldr	x8, [x8, #0x80]
   110b4:      	blr	x8
   110b8:      	ldr	x8, [x19]
   110bc:      	ldr	x1, [x8, #0x88]
   110c0:      	mov	x0, x19
   110c4:      	ldr	x19, [sp, #0x10]
   110c8:      	ldp	x29, x30, [sp], #0x20
   110cc:      	br	x1
   110d0:      	ldr	x19, [sp, #0x10]
   110d4:      	ldp	x29, x30, [sp], #0x20
   110d8:      	ret
   110dc:      	stp	x29, x30, [sp, #-0x30]!
   110e0:      	stp	x22, x21, [sp, #0x10]
   110e4:      	stp	x20, x19, [sp, #0x20]
   110e8:      	mov	x29, sp
   110ec:      	mov	x21, x1
   110f0:      	ldr	x1, [x1, #0x28]
   110f4:      	mov	w20, w2
   110f8:      	mov	x19, x0
   110fc:      	cbz	x1, 0x11124 <_Z20MTARMPMMusicGetSpeedPv+0x6428>
   11100:      	ldr	w8, [x21, #0x30]
   11104:      	cmp	w8, w20
   11108:      	b.ge	0x111ec <_Z20MTARMPMMusicGetSpeedPv+0x64f0>
   1110c:      	ldr	x8, [x19]
   11110:      	mov	x0, x19
   11114:      	ldr	x8, [x8, #0xb0]
   11118:      	blr	x8
   1111c:      	str	xzr, [x21, #0x28]
   11120:      	str	wzr, [x21, #0x30]
   11124:      	ldr	w8, [x21, #0x34]
   11128:      	ldr	x9, [x19]
   1112c:      	mov	x0, x19
   11130:      	cmp	w8, w20
   11134:      	ldr	x9, [x9, #0x580]
   11138:      	csel	w20, w8, w20, gt
   1113c:      	mov	w1, w20
   11140:      	blr	x9
   11144:      	cbz	x0, 0x11164 <_Z20MTARMPMMusicGetSpeedPv+0x6468>
   11148:      	ldr	x8, [x19]
   1114c:      	mov	x22, x0
   11150:      	mov	x0, x19
   11154:      	ldr	x8, [x8, #0x720]
   11158:      	blr	x8
   1115c:      	tst	w0, #0xff
   11160:      	b.eq	0x111bc <_Z20MTARMPMMusicGetSpeedPv+0x64c0>
   11164:      	adrp	x1, 0x4000
   11168:      	add	x1, x1, #0xe4c
   1116c:      	adrp	x2, 0x5000
   11170:      	add	x2, x2, #0x69e
   11174:      	mov	w0, #0x6                // =6
   11178:      	bl	0x16e90 <__android_log_print@plt>
   1117c:      	ldr	x8, [x19]
   11180:      	mov	x0, x19
   11184:      	ldr	x8, [x8, #0x720]
   11188:      	blr	x8
   1118c:      	tst	w0, #0xff
   11190:      	b.eq	0x111b4 <_Z20MTARMPMMusicGetSpeedPv+0x64b8>
   11194:      	ldr	x8, [x19]
   11198:      	mov	x0, x19
   1119c:      	ldr	x8, [x8, #0x80]
   111a0:      	blr	x8
   111a4:      	ldr	x8, [x19]
   111a8:      	mov	x0, x19
   111ac:      	ldr	x8, [x8, #0x88]
   111b0:      	blr	x8
   111b4:      	mov	w20, #-0x1              // =-1
   111b8:      	b	0x111ec <_Z20MTARMPMMusicGetSpeedPv+0x64f0>
   111bc:      	ldr	x8, [x19]
   111c0:      	mov	x0, x19
   111c4:      	mov	x1, x22
   111c8:      	str	w20, [x21, #0x30]
   111cc:      	ldr	x8, [x8, #0xa8]
   111d0:      	blr	x8
   111d4:      	ldr	x8, [x19]
   111d8:      	str	x0, [x21, #0x28]
   111dc:      	mov	x0, x19
   111e0:      	mov	x1, x22
   111e4:      	ldr	x8, [x8, #0xb8]
   111e8:      	blr	x8
   111ec:      	mov	w0, w20
   111f0:      	ldp	x20, x19, [sp, #0x20]
   111f4:      	ldp	x22, x21, [sp, #0x10]
   111f8:      	ldp	x29, x30, [sp], #0x30
   111fc:      	ret
   11200:      	stp	x29, x30, [sp, #-0x30]!
   11204:      	stp	x22, x21, [sp, #0x10]
   11208:      	stp	x20, x19, [sp, #0x20]
   1120c:      	mov	x29, sp
   11210:      	mov	w20, w3
   11214:      	cmp	w3, #0x1
   11218:      	b.lt	0x11338 <_Z20MTARMPMMusicGetSpeedPv+0x663c>
   1121c:      	mov	x22, x2
   11220:      	mov	w2, w20
   11224:      	mov	x21, x1
   11228:      	mov	x19, x0
   1122c:      	bl	0x110dc <_Z20MTARMPMMusicGetSpeedPv+0x63e0>
   11230:      	cmp	w0, w20
   11234:      	b.ge	0x1125c <_Z20MTARMPMMusicGetSpeedPv+0x6560>
   11238:      	mov	w3, w0
   1123c:      	adrp	x1, 0x4000
   11240:      	add	x1, x1, #0xe4c
   11244:      	adrp	x2, 0x4000
   11248:      	add	x2, x2, #0xee6
   1124c:      	mov	w0, #0x6                // =6
   11250:      	mov	w4, w20
   11254:      	bl	0x16e90 <__android_log_print@plt>
   11258:      	b	0x11334 <_Z20MTARMPMMusicGetSpeedPv+0x6638>
   1125c:      	ldr	x8, [x19]
   11260:      	ldr	x1, [x21, #0x28]
   11264:      	mov	x0, x19
   11268:      	mov	w2, wzr
   1126c:      	mov	w3, w20
   11270:      	mov	x4, x22
   11274:      	ldr	x8, [x8, #0x680]
   11278:      	blr	x8
   1127c:      	ldr	x8, [x19]
   11280:      	mov	x0, x19
   11284:      	ldr	x8, [x8, #0x720]
   11288:      	blr	x8
   1128c:      	tst	w0, #0xff
   11290:      	b.eq	0x112a8 <_Z20MTARMPMMusicGetSpeedPv+0x65ac>
   11294:      	adrp	x1, 0x4000
   11298:      	add	x1, x1, #0xe4c
   1129c:      	adrp	x2, 0x5000
   112a0:      	add	x2, x2, #0x50a
   112a4:      	b	0x112f4 <_Z20MTARMPMMusicGetSpeedPv+0x65f8>
   112a8:      	adrp	x8, 0x1f000
   112ac:      	ldr	x1, [x21]
   112b0:      	ldr	x3, [x21, #0x28]
   112b4:      	ldr	x2, [x8, #0xe78]
   112b8:      	mov	x0, x19
   112bc:      	mov	w4, wzr
   112c0:      	mov	w5, w20
   112c4:      	bl	0x1134c <_Z20MTARMPMMusicGetSpeedPv+0x6650>
   112c8:      	ldr	x8, [x19]
   112cc:      	mov	w20, w0
   112d0:      	mov	x0, x19
   112d4:      	ldr	x8, [x8, #0x720]
   112d8:      	blr	x8
   112dc:      	tst	w0, #0xff
   112e0:      	b.eq	0x11338 <_Z20MTARMPMMusicGetSpeedPv+0x663c>
   112e4:      	adrp	x1, 0x4000
   112e8:      	add	x1, x1, #0xe4c
   112ec:      	adrp	x2, 0x5000
   112f0:      	add	x2, x2, #0xa3c
   112f4:      	mov	w0, #0x6                // =6
   112f8:      	bl	0x16e90 <__android_log_print@plt>
   112fc:      	ldr	x8, [x19]
   11300:      	mov	x0, x19
   11304:      	ldr	x8, [x8, #0x720]
   11308:      	blr	x8
   1130c:      	tst	w0, #0xff
   11310:      	b.eq	0x11334 <_Z20MTARMPMMusicGetSpeedPv+0x6638>
   11314:      	ldr	x8, [x19]
   11318:      	mov	x0, x19
   1131c:      	ldr	x8, [x8, #0x80]
   11320:      	blr	x8
   11324:      	ldr	x8, [x19]
   11328:      	mov	x0, x19
   1132c:      	ldr	x8, [x8, #0x88]
   11330:      	blr	x8
   11334:      	mov	w20, #-0x1              // =-1
   11338:      	mov	w0, w20
   1133c:      	ldp	x20, x19, [sp, #0x20]
   11340:      	ldp	x22, x21, [sp, #0x10]
   11344:      	ldp	x29, x30, [sp], #0x30
   11348:      	ret
   1134c:      	sub	sp, sp, #0x120
   11350:      	stp	x29, x30, [sp, #0x100]
   11354:      	stp	x28, x19, [sp, #0x110]
   11358:      	add	x29, sp, #0x100
   1135c:      	stp	x3, x4, [x29, #-0x78]
   11360:      	sub	x9, x29, #0x78
   11364:      	mov	x10, sp
   11368:      	stp	x5, x6, [x29, #-0x68]
   1136c:      	add	x10, x10, #0x80
   11370:      	sub	x3, x29, #0x50
   11374:      	stur	x7, [x29, #-0x58]
   11378:      	stp	q0, q1, [sp]
   1137c:      	stp	q2, q3, [sp, #0x20]
   11380:      	stp	q4, q5, [sp, #0x40]
   11384:      	stp	q6, q7, [sp, #0x60]
   11388:      	mrs	x19, TPIDR_EL0
   1138c:      	ldr	x8, [x19, #0x28]
   11390:      	stur	x8, [x29, #-0x8]
   11394:      	add	x8, x9, #0x28
   11398:      	add	x9, x29, #0x20
   1139c:      	stp	x9, x8, [x29, #-0x28]
   113a0:      	mov	x8, #-0x28              // =-40
   113a4:      	sub	x9, x29, #0x28
   113a8:      	movk	x8, #0xff80, lsl #32
   113ac:      	stp	x10, x8, [x29, #-0x18]
   113b0:      	ldr	x8, [x0]
   113b4:      	ldp	q0, q1, [x9]
   113b8:      	ldr	x8, [x8, #0x190]
   113bc:      	stp	q0, q1, [x29, #-0x50]
   113c0:      	blr	x8
   113c4:      	ldr	x8, [x19, #0x28]
   113c8:      	ldur	x9, [x29, #-0x8]
   113cc:      	cmp	x8, x9
   113d0:      	b.ne	0x113e4 <_Z20MTARMPMMusicGetSpeedPv+0x66e8>
   113d4:      	ldp	x28, x19, [sp, #0x110]
   113d8:      	ldp	x29, x30, [sp, #0x100]
   113dc:      	add	sp, sp, #0x120
   113e0:      	ret
   113e4:      	bl	0x16b40 <__stack_chk_fail@plt>
   113e8:      	sub	sp, sp, #0x120
   113ec:      	stp	x29, x30, [sp, #0x100]
   113f0:      	stp	x28, x19, [sp, #0x110]
   113f4:      	add	x29, sp, #0x100
   113f8:      	stp	x3, x4, [x29, #-0x78]
   113fc:      	sub	x9, x29, #0x78
   11400:      	mov	x10, sp
   11404:      	stp	x5, x6, [x29, #-0x68]
   11408:      	add	x10, x10, #0x80
   1140c:      	sub	x3, x29, #0x50
   11410:      	stur	x7, [x29, #-0x58]
   11414:      	stp	q0, q1, [sp]
   11418:      	stp	q2, q3, [sp, #0x20]
   1141c:      	stp	q4, q5, [sp, #0x40]
   11420:      	stp	q6, q7, [sp, #0x60]
   11424:      	mrs	x19, TPIDR_EL0
   11428:      	ldr	x8, [x19, #0x28]
   1142c:      	stur	x8, [x29, #-0x8]
   11430:      	add	x8, x9, #0x28
   11434:      	add	x9, x29, #0x20
   11438:      	stp	x9, x8, [x29, #-0x28]
   1143c:      	mov	x8, #-0x28              // =-40
   11440:      	sub	x9, x29, #0x28
   11444:      	movk	x8, #0xff80, lsl #32
   11448:      	stp	x10, x8, [x29, #-0x18]
   1144c:      	ldr	x8, [x0]
   11450:      	ldp	q0, q1, [x9]
   11454:      	ldr	x8, [x8, #0x410]
   11458:      	stp	q0, q1, [x29, #-0x50]
   1145c:      	blr	x8
   11460:      	ldr	x8, [x19, #0x28]
   11464:      	ldur	x9, [x29, #-0x8]
   11468:      	cmp	x8, x9
   1146c:      	b.ne	0x11480 <_Z20MTARMPMMusicGetSpeedPv+0x6784>
   11470:      	ldp	x28, x19, [sp, #0x110]
   11474:      	ldp	x29, x30, [sp, #0x100]
   11478:      	add	sp, sp, #0x120
   1147c:      	ret
   11480:      	bl	0x16b40 <__stack_chk_fail@plt>
   11484:      	sub	sp, sp, #0x120
   11488:      	stp	x29, x30, [sp, #0x100]
   1148c:      	stp	x28, x19, [sp, #0x110]
   11490:      	add	x29, sp, #0x100
   11494:      	stp	x3, x4, [x29, #-0x78]
   11498:      	sub	x9, x29, #0x78
   1149c:      	mov	x10, sp
   114a0:      	stp	x5, x6, [x29, #-0x68]
   114a4:      	add	x10, x10, #0x80
   114a8:      	sub	x3, x29, #0x50
   114ac:      	stur	x7, [x29, #-0x58]
   114b0:      	stp	q0, q1, [sp]
   114b4:      	stp	q2, q3, [sp, #0x20]
   114b8:      	stp	q4, q5, [sp, #0x40]
   114bc:      	stp	q6, q7, [sp, #0x60]
   114c0:      	mrs	x19, TPIDR_EL0
   114c4:      	ldr	x8, [x19, #0x28]
   114c8:      	stur	x8, [x29, #-0x8]
   114cc:      	add	x8, x9, #0x28
   114d0:      	add	x9, x29, #0x20
   114d4:      	stp	x9, x8, [x29, #-0x28]
   114d8:      	mov	x8, #-0x28              // =-40
   114dc:      	sub	x9, x29, #0x28
   114e0:      	movk	x8, #0xff80, lsl #32
   114e4:      	stp	x10, x8, [x29, #-0x18]
   114e8:      	ldr	x8, [x0]
   114ec:      	ldp	q0, q1, [x9]
   114f0:      	ldr	x8, [x8, #0x440]
   114f4:      	stp	q0, q1, [x29, #-0x50]
   114f8:      	blr	x8
   114fc:      	ldr	x8, [x19, #0x28]
   11500:      	ldur	x9, [x29, #-0x8]
   11504:      	cmp	x8, x9
   11508:      	b.ne	0x1151c <_Z20MTARMPMMusicGetSpeedPv+0x6820>
   1150c:      	ldp	x28, x19, [sp, #0x110]
   11510:      	ldp	x29, x30, [sp, #0x100]
   11514:      	add	sp, sp, #0x120
   11518:      	ret
   1151c:      	bl	0x16b40 <__stack_chk_fail@plt>
   11520:      	stp	x29, x30, [sp, #-0x40]!
   11524:      	stp	x24, x23, [sp, #0x10]
   11528:      	stp	x22, x21, [sp, #0x20]
   1152c:      	stp	x20, x19, [sp, #0x30]
   11530:      	mov	x29, sp
   11534:      	ldr	x23, [x1, #0x8]
   11538:      	mov	x21, x0
   1153c:      	mov	w0, #0x2                // =2
   11540:      	ldp	x24, x20, [x23, #0x20]
   11544:      	ldp	x19, x22, [x23, #0x30]
   11548:      	bl	0x120fc <_Z20MTARMPMMusicGetSpeedPv+0x7400>
   1154c:      	ldrb	w8, [x23, #0x46]
   11550:      	cbnz	w8, 0x11568 <_Z20MTARMPMMusicGetSpeedPv+0x686c>
   11554:      	ldrb	w8, [x23, #0x45]
   11558:      	cbnz	w8, 0x11568 <_Z20MTARMPMMusicGetSpeedPv+0x686c>
   1155c:      	mov	x0, x21
   11560:      	mov	x1, x19
   11564:      	bl	0x10eb4 <_Z20MTARMPMMusicGetSpeedPv+0x61b8>
   11568:      	ldrb	w8, [x23, #0x46]
   1156c:      	cbnz	w8, 0x11670 <_Z20MTARMPMMusicGetSpeedPv+0x6974>
   11570:      	ldr	x0, [x23, #0x8]
   11574:      	bl	0x11ee4 <_Z20MTARMPMMusicGetSpeedPv+0x71e8>
   11578:      	ldrb	w8, [x23, #0x46]
   1157c:      	cbz	w8, 0x11604 <_Z20MTARMPMMusicGetSpeedPv+0x6908>
   11580:      	ldrb	w8, [x23, #0x44]
   11584:      	cbz	w8, 0x11598 <_Z20MTARMPMMusicGetSpeedPv+0x689c>
   11588:      	mov	x0, x21
   1158c:      	mov	x1, x19
   11590:      	strb	wzr, [x23, #0x44]
   11594:      	bl	0x11058 <_Z20MTARMPMMusicGetSpeedPv+0x635c>
   11598:      	ldrb	w8, [x23, #0x47]
   1159c:      	cbz	w8, 0x115b8 <_Z20MTARMPMMusicGetSpeedPv+0x68bc>
   115a0:      	strb	wzr, [x23, #0x47]
   115a4:      	mov	x0, x21
   115a8:      	mov	x1, x19
   115ac:      	ldr	s0, [x23, #0x48]
   115b0:      	ldr	s1, [x23, #0x4c]
   115b4:      	bl	0x10608 <_Z20MTARMPMMusicGetSpeedPv+0x590c>
   115b8:      	ldr	x0, [x23, #0x8]
   115bc:      	bl	0x11ef4 <_Z20MTARMPMMusicGetSpeedPv+0x71f8>
   115c0:      	mov	x0, x20
   115c4:      	mov	x1, x22
   115c8:      	mov	w2, #0x100              // =256
   115cc:      	blr	x24
   115d0:      	ldrb	w8, [x23, #0x44]
   115d4:      	cbz	w8, 0x115e8 <_Z20MTARMPMMusicGetSpeedPv+0x68ec>
   115d8:      	mov	x0, x21
   115dc:      	mov	x1, x19
   115e0:      	bl	0x11058 <_Z20MTARMPMMusicGetSpeedPv+0x635c>
   115e4:      	strb	wzr, [x23, #0x44]
   115e8:      	ldrb	w8, [x23, #0x44]
   115ec:      	cbz	w8, 0x11638 <_Z20MTARMPMMusicGetSpeedPv+0x693c>
   115f0:      	mov	x0, x21
   115f4:      	mov	x1, x19
   115f8:      	strb	wzr, [x23, #0x44]
   115fc:      	bl	0x11058 <_Z20MTARMPMMusicGetSpeedPv+0x635c>
   11600:      	b	0x11568 <_Z20MTARMPMMusicGetSpeedPv+0x686c>
   11604:      	ldrb	w8, [x23, #0x45]
   11608:      	cbz	w8, 0x11580 <_Z20MTARMPMMusicGetSpeedPv+0x6884>
   1160c:      	mov	x0, x21
   11610:      	mov	x1, x19
   11614:      	bl	0x10fd4 <_Z20MTARMPMMusicGetSpeedPv+0x62d8>
   11618:      	ldrb	w8, [x23, #0x46]
   1161c:      	cbnz	w8, 0x11650 <_Z20MTARMPMMusicGetSpeedPv+0x6954>
   11620:      	ldrb	w8, [x23, #0x45]
   11624:      	cbz	w8, 0x11650 <_Z20MTARMPMMusicGetSpeedPv+0x6954>
   11628:      	ldp	x0, x1, [x23]
   1162c:      	mov	w2, #0x3e8              // =1000
   11630:      	bl	0x11f88 <_Z20MTARMPMMusicGetSpeedPv+0x728c>
   11634:      	b	0x11618 <_Z20MTARMPMMusicGetSpeedPv+0x691c>
   11638:      	mov	x0, x21
   1163c:      	mov	x1, x19
   11640:      	mov	x2, x22
   11644:      	mov	w3, #0x100              // =256
   11648:      	bl	0x11200 <_Z20MTARMPMMusicGetSpeedPv+0x6504>
   1164c:      	b	0x11568 <_Z20MTARMPMMusicGetSpeedPv+0x686c>
   11650:      	ldrb	w8, [x23, #0x46]
   11654:      	cbnz	w8, 0x11580 <_Z20MTARMPMMusicGetSpeedPv+0x6884>
   11658:      	ldrb	w8, [x23, #0x45]
   1165c:      	cbnz	w8, 0x11580 <_Z20MTARMPMMusicGetSpeedPv+0x6884>
   11660:      	mov	x0, x21
   11664:      	mov	x1, x19
   11668:      	bl	0x10eb4 <_Z20MTARMPMMusicGetSpeedPv+0x61b8>
   1166c:      	b	0x11580 <_Z20MTARMPMMusicGetSpeedPv+0x6884>
   11670:      	mov	x0, x21
   11674:      	mov	x1, x19
   11678:      	bl	0x10d04 <_Z20MTARMPMMusicGetSpeedPv+0x6008>
   1167c:      	mov	w0, wzr
   11680:      	ldp	x20, x19, [sp, #0x30]
   11684:      	ldp	x22, x21, [sp, #0x20]
   11688:      	ldp	x24, x23, [sp, #0x10]
   1168c:      	ldp	x29, x30, [sp], #0x40
   11690:      	ret
   11694:      	stp	x29, x30, [sp, #-0x20]!
   11698:      	str	x19, [sp, #0x10]
   1169c:      	mov	x29, sp
   116a0:      	mov	x19, x0
   116a4:      	bl	0x11c78 <_Z20MTARMPMMusicGetSpeedPv+0x6f7c>
   116a8:      	cbz	x0, 0x116bc <_Z20MTARMPMMusicGetSpeedPv+0x69c0>
   116ac:      	mov	x1, x19
   116b0:      	bl	0x11520 <_Z20MTARMPMMusicGetSpeedPv+0x6824>
   116b4:      	mov	w0, wzr
   116b8:      	b	0x116d8 <_Z20MTARMPMMusicGetSpeedPv+0x69dc>
   116bc:      	nop
   116c0:      	adr	x1, 0x4e4c
   116c4:      	adrp	x2, 0x4000
   116c8:      	add	x2, x2, #0xcf6
   116cc:      	mov	w0, #0x6                // =6
   116d0:      	bl	0x16e90 <__android_log_print@plt>
   116d4:      	mov	w0, #-0x1               // =-1
   116d8:      	ldr	x19, [sp, #0x10]
   116dc:      	ldp	x29, x30, [sp], #0x20
   116e0:      	ret
   116e4:      	stp	x29, x30, [sp, #-0x30]!
   116e8:      	stp	x22, x21, [sp, #0x10]
   116ec:      	stp	x20, x19, [sp, #0x20]
   116f0:      	mov	x29, sp
   116f4:      	ldp	q1, q0, [x2]
   116f8:      	mov	x20, x1
   116fc:      	ldr	x22, [x1, #0x8]
   11700:      	mov	x1, x2
   11704:      	mov	x21, x3
   11708:      	mov	x19, x0
   1170c:      	stp	q1, q0, [x22, #0x10]
   11710:      	bl	0x10c08 <_Z20MTARMPMMusicGetSpeedPv+0x5f0c>
   11714:      	str	x0, [x22, #0x30]
   11718:      	cbz	x0, 0x117b8 <_Z20MTARMPMMusicGetSpeedPv+0x6abc>
   1171c:      	bl	0x10eac <_Z20MTARMPMMusicGetSpeedPv+0x61b0>
   11720:      	cmp	w0, #0x0
   11724:      	str	w0, [x22, #0x40]
   11728:      	b.le	0x117d4 <_Z20MTARMPMMusicGetSpeedPv+0x6ad8>
   1172c:      	mov	w0, w0
   11730:      	bl	0x17110 <malloc@plt>
   11734:      	str	x0, [x22, #0x38]
   11738:      	cbz	x0, 0x117e8 <_Z20MTARMPMMusicGetSpeedPv+0x6aec>
   1173c:      	cbz	x21, 0x1176c <_Z20MTARMPMMusicGetSpeedPv+0x6a70>
   11740:      	ldr	x0, [x22, #0x30]
   11744:      	mov	x1, x21
   11748:      	bl	0x10df4 <_Z20MTARMPMMusicGetSpeedPv+0x60f8>
   1174c:      	ldrh	w3, [x21, #0x4]
   11750:      	ldrb	w4, [x21, #0x6]
   11754:      	nop
   11758:      	adr	x1, 0x4e4c
   1175c:      	adrp	x2, 0x5000
   11760:      	add	x2, x2, #0x74b
   11764:      	mov	w0, #0x3                // =3
   11768:      	bl	0x16e90 <__android_log_print@plt>
   1176c:      	mov	w8, #0x1                // =1
   11770:      	nop
   11774:      	adr	x1, 0x11694 <_Z20MTARMPMMusicGetSpeedPv+0x6998>
   11778:      	adrp	x3, 0x4000
   1177c:      	add	x3, x3, #0x921
   11780:      	add	x0, x22, #0x58
   11784:      	mov	x2, x20
   11788:      	strb	w8, [x22, #0x45]
   1178c:      	strb	wzr, [x22, #0x46]
   11790:      	bl	0x12078 <_Z20MTARMPMMusicGetSpeedPv+0x737c>
   11794:      	mov	x8, x0
   11798:      	mov	w0, wzr
   1179c:      	str	x8, [x22, #0x50]
   117a0:      	cbnz	x8, 0x11814 <_Z20MTARMPMMusicGetSpeedPv+0x6b18>
   117a4:      	nop
   117a8:      	adr	x1, 0x4e4c
   117ac:      	adrp	x2, 0x5000
   117b0:      	add	x2, x2, #0x25c
   117b4:      	b	0x117f8 <_Z20MTARMPMMusicGetSpeedPv+0x6afc>
   117b8:      	nop
   117bc:      	adr	x1, 0x4e4c
   117c0:      	adrp	x2, 0x4000
   117c4:      	add	x2, x2, #0xbf3
   117c8:      	mov	w0, #0x6                // =6
   117cc:      	bl	0x16e90 <__android_log_print@plt>
   117d0:      	b	0x11810 <_Z20MTARMPMMusicGetSpeedPv+0x6b14>
   117d4:      	nop
   117d8:      	adr	x1, 0x4e4c
   117dc:      	adrp	x2, 0x5000
   117e0:      	add	x2, x2, #0x22c
   117e4:      	b	0x117f8 <_Z20MTARMPMMusicGetSpeedPv+0x6afc>
   117e8:      	nop
   117ec:      	adr	x1, 0x4e4c
   117f0:      	adrp	x2, 0x5000
   117f4:      	add	x2, x2, #0xc04
   117f8:      	mov	w0, #0x6                // =6
   117fc:      	bl	0x16e90 <__android_log_print@plt>
   11800:      	ldr	x1, [x22, #0x30]
   11804:      	mov	x0, x19
   11808:      	bl	0x10d04 <_Z20MTARMPMMusicGetSpeedPv+0x6008>
   1180c:      	str	xzr, [x22, #0x30]
   11810:      	mov	w0, #-0x1               // =-1
   11814:      	ldp	x20, x19, [sp, #0x20]
   11818:      	ldp	x22, x21, [sp, #0x10]
   1181c:      	ldp	x29, x30, [sp], #0x30
   11820:      	ret
   11824:      	stp	x29, x30, [sp, #-0x20]!
   11828:      	stp	x20, x19, [sp, #0x10]
   1182c:      	mov	x29, sp
   11830:      	ldr	x20, [x0, #0x8]
   11834:      	mov	w19, w1
   11838:      	ldr	x0, [x20, #0x8]
   1183c:      	bl	0x11ee4 <_Z20MTARMPMMusicGetSpeedPv+0x71e8>
   11840:      	nop
   11844:      	adr	x1, 0x4e4c
   11848:      	adrp	x2, 0x5000
   1184c:      	add	x2, x2, #0x841
   11850:      	mov	w0, #0x3                // =3
   11854:      	mov	w3, w19
   11858:      	bl	0x16e90 <__android_log_print@plt>
   1185c:      	cmp	w19, #0x0
   11860:      	cset	w8, ne
   11864:      	strb	w8, [x20, #0x45]
   11868:      	cbnz	w19, 0x11874 <_Z20MTARMPMMusicGetSpeedPv+0x6b78>
   1186c:      	ldr	x0, [x20]
   11870:      	bl	0x11f78 <_Z20MTARMPMMusicGetSpeedPv+0x727c>
   11874:      	ldr	x0, [x20, #0x8]
   11878:      	ldp	x20, x19, [sp, #0x10]
   1187c:      	ldp	x29, x30, [sp], #0x20
   11880:      	b	0x11ef4 <_Z20MTARMPMMusicGetSpeedPv+0x71f8>
   11884:      	stp	x29, x30, [sp, #-0x20]!
   11888:      	str	x19, [sp, #0x10]
   1188c:      	mov	x29, sp
   11890:      	ldr	x19, [x0, #0x8]
   11894:      	ldr	x0, [x19, #0x8]
   11898:      	bl	0x11ee4 <_Z20MTARMPMMusicGetSpeedPv+0x71e8>
   1189c:      	nop
   118a0:      	adr	x1, 0x4e4c
   118a4:      	adrp	x2, 0x5000
   118a8:      	add	x2, x2, #0x6d6
   118ac:      	mov	w0, #0x3                // =3
   118b0:      	bl	0x16e90 <__android_log_print@plt>
   118b4:      	mov	w8, #0x1                // =1
   118b8:      	strb	w8, [x19, #0x44]
   118bc:      	ldr	x0, [x19]
   118c0:      	bl	0x11f78 <_Z20MTARMPMMusicGetSpeedPv+0x727c>
   118c4:      	ldr	x0, [x19, #0x8]
   118c8:      	ldr	x19, [sp, #0x10]
   118cc:      	ldp	x29, x30, [sp], #0x20
   118d0:      	b	0x11ef4 <_Z20MTARMPMMusicGetSpeedPv+0x71f8>
   118d4:      	stp	d9, d8, [sp, #-0x30]!
   118d8:      	stp	x29, x30, [sp, #0x10]
   118dc:      	str	x19, [sp, #0x20]
   118e0:      	add	x29, sp, #0x10
   118e4:      	ldr	x19, [x0, #0x8]
   118e8:      	fmov	s8, s1
   118ec:      	fmov	s9, s0
   118f0:      	ldr	x0, [x19, #0x8]
   118f4:      	bl	0x11ee4 <_Z20MTARMPMMusicGetSpeedPv+0x71e8>
   118f8:      	nop
   118fc:      	adr	x1, 0x4e4c
   11900:      	adrp	x2, 0x5000
   11904:      	add	x2, x2, #0x6d6
   11908:      	mov	w0, #0x3                // =3
   1190c:      	bl	0x16e90 <__android_log_print@plt>
   11910:      	mov	w8, #0x1                // =1
   11914:      	str	s9, [x19, #0x48]
   11918:      	str	s8, [x19, #0x4c]
   1191c:      	strb	w8, [x19, #0x47]
   11920:      	ldr	x0, [x19]
   11924:      	bl	0x11f78 <_Z20MTARMPMMusicGetSpeedPv+0x727c>
   11928:      	ldr	x0, [x19, #0x8]
   1192c:      	ldp	x29, x30, [sp, #0x10]
   11930:      	ldr	x19, [sp, #0x20]
   11934:      	ldp	d9, d8, [sp], #0x30
   11938:      	b	0x11ef4 <_Z20MTARMPMMusicGetSpeedPv+0x71f8>
   1193c:      	stp	x29, x30, [sp, #-0x20]!
   11940:      	str	x19, [sp, #0x10]
   11944:      	mov	x29, sp
   11948:      	ldr	x19, [x0, #0x8]
   1194c:      	ldr	x0, [x19, #0x8]
   11950:      	bl	0x11ee4 <_Z20MTARMPMMusicGetSpeedPv+0x71e8>
   11954:      	mov	w8, #0x1                // =1
   11958:      	strb	w8, [x19, #0x46]
   1195c:      	ldr	x0, [x19]
   11960:      	bl	0x11f78 <_Z20MTARMPMMusicGetSpeedPv+0x727c>
   11964:      	ldr	x0, [x19, #0x8]
   11968:      	bl	0x11ef4 <_Z20MTARMPMMusicGetSpeedPv+0x71f8>
   1196c:      	ldr	x0, [x19, #0x50]
   11970:      	mov	x1, xzr
   11974:      	bl	0x121ec <_Z20MTARMPMMusicGetSpeedPv+0x74f0>
   11978:      	str	xzr, [x19, #0x50]
   1197c:      	ldr	x19, [sp, #0x10]
   11980:      	ldp	x29, x30, [sp], #0x20
   11984:      	ret
   11988:      	cbz	x0, 0x119fc <_Z20MTARMPMMusicGetSpeedPv+0x6d00>
   1198c:      	stp	x29, x30, [sp, #-0x20]!
   11990:      	stp	x20, x19, [sp, #0x10]
   11994:      	mov	x29, sp
   11998:      	mov	x19, x0
   1199c:      	bl	0x1193c <_Z20MTARMPMMusicGetSpeedPv+0x6c40>
   119a0:      	ldr	x20, [x19, #0x8]
   119a4:      	cbz	x20, 0x119c8 <_Z20MTARMPMMusicGetSpeedPv+0x6ccc>
   119a8:      	ldr	x0, [x20, #0x38]
   119ac:      	bl	0x17100 <free@plt>
   119b0:      	ldr	x0, [x20]
   119b4:      	str	xzr, [x20, #0x38]
   119b8:      	str	wzr, [x20, #0x40]
   119bc:      	bl	0x11f4c <_Z20MTARMPMMusicGetSpeedPv+0x7250>
   119c0:      	ldr	x0, [x20, #0x8]
   119c4:      	bl	0x11eb8 <_Z20MTARMPMMusicGetSpeedPv+0x71bc>
   119c8:      	ldr	x0, [x19]
   119cc:      	cbz	x0, 0x119d4 <_Z20MTARMPMMusicGetSpeedPv+0x6cd8>
   119d0:      	bl	0x11eb8 <_Z20MTARMPMMusicGetSpeedPv+0x71bc>
   119d4:      	ldr	x0, [x19, #0x8]
   119d8:      	bl	0x17100 <free@plt>
   119dc:      	movi	v0.2d, #0000000000000000
   119e0:      	str	xzr, [x19, #0x40]
   119e4:      	stp	q0, q0, [x19]
   119e8:      	stp	q0, q0, [x19, #0x20]
   119ec:      	mov	x0, x19
   119f0:      	ldp	x20, x19, [sp, #0x10]
   119f4:      	ldp	x29, x30, [sp], #0x20
   119f8:      	b	0x17100 <free@plt>
   119fc:      	ret
   11a00:      	stp	x29, x30, [sp, #-0x20]!
   11a04:      	stp	x20, x19, [sp, #0x10]
   11a08:      	mov	x29, sp
   11a0c:      	mov	w0, #0x1                // =1
   11a10:      	mov	w1, #0x48               // =72
   11a14:      	bl	0x170f0 <calloc@plt>
   11a18:      	mov	x19, x0
   11a1c:      	cbz	x0, 0x11aa8 <_Z20MTARMPMMusicGetSpeedPv+0x6dac>
   11a20:      	mov	w0, #0x1                // =1
   11a24:      	mov	w1, #0x98               // =152
   11a28:      	bl	0x170f0 <calloc@plt>
   11a2c:      	cbz	x0, 0x11a9c <_Z20MTARMPMMusicGetSpeedPv+0x6da0>
   11a30:      	mov	x20, x0
   11a34:      	str	x0, [x19, #0x8]
   11a38:      	bl	0x11e34 <_Z20MTARMPMMusicGetSpeedPv+0x7138>
   11a3c:      	str	x0, [x19]
   11a40:      	cbz	x0, 0x11a94 <_Z20MTARMPMMusicGetSpeedPv+0x6d98>
   11a44:      	bl	0x11f04 <_Z20MTARMPMMusicGetSpeedPv+0x7208>
   11a48:      	str	x0, [x20]
   11a4c:      	bl	0x11e34 <_Z20MTARMPMMusicGetSpeedPv+0x7138>
   11a50:      	nop
   11a54:      	adr	x8, 0x11988 <_Z20MTARMPMMusicGetSpeedPv+0x6c8c>
   11a58:      	nop
   11a5c:      	adr	x9, 0x11ab8 <_Z20MTARMPMMusicGetSpeedPv+0x6dbc>
   11a60:      	str	x0, [x20, #0x8]
   11a64:      	stp	x8, x9, [x19, #0x10]
   11a68:      	nop
   11a6c:      	adr	x8, 0x11824 <_Z20MTARMPMMusicGetSpeedPv+0x6b28>
   11a70:      	nop
   11a74:      	adr	x9, 0x11884 <_Z20MTARMPMMusicGetSpeedPv+0x6b88>
   11a78:      	stp	x8, x9, [x19, #0x20]
   11a7c:      	nop
   11a80:      	adr	x8, 0x118d4 <_Z20MTARMPMMusicGetSpeedPv+0x6bd8>
   11a84:      	nop
   11a88:      	adr	x9, 0x1193c <_Z20MTARMPMMusicGetSpeedPv+0x6c40>
   11a8c:      	stp	x8, x9, [x19, #0x30]
   11a90:      	b	0x11aa8 <_Z20MTARMPMMusicGetSpeedPv+0x6dac>
   11a94:      	mov	x0, x20
   11a98:      	bl	0x17100 <free@plt>
   11a9c:      	mov	x0, x19
   11aa0:      	bl	0x17100 <free@plt>
   11aa4:      	mov	x19, xzr
   11aa8:      	mov	x0, x19
   11aac:      	ldp	x20, x19, [sp, #0x10]
   11ab0:      	ldp	x29, x30, [sp], #0x20
   11ab4:      	ret
   11ab8:      	stp	x29, x30, [sp, #-0x30]!
   11abc:      	str	x21, [sp, #0x10]
   11ac0:      	stp	x20, x19, [sp, #0x20]
   11ac4:      	mov	x29, sp
   11ac8:      	mov	x19, x2
   11acc:      	mov	x20, x1
   11ad0:      	mov	x21, x0
   11ad4:      	bl	0x11c78 <_Z20MTARMPMMusicGetSpeedPv+0x6f7c>
   11ad8:      	cbz	x0, 0x11af8 <_Z20MTARMPMMusicGetSpeedPv+0x6dfc>
   11adc:      	mov	x1, x21
   11ae0:      	mov	x2, x20
   11ae4:      	mov	x3, x19
   11ae8:      	ldp	x20, x19, [sp, #0x20]
   11aec:      	ldr	x21, [sp, #0x10]
   11af0:      	ldp	x29, x30, [sp], #0x30
   11af4:      	b	0x116e4 <_Z20MTARMPMMusicGetSpeedPv+0x69e8>
   11af8:      	nop
   11afc:      	adr	x1, 0x4e4c
   11b00:      	adrp	x2, 0x4000
   11b04:      	add	x2, x2, #0x771
   11b08:      	mov	w0, #0x6                // =6
   11b0c:      	bl	0x16e90 <__android_log_print@plt>
   11b10:      	mov	w0, #-0x1               // =-1
   11b14:      	ldp	x20, x19, [sp, #0x20]
   11b18:      	ldr	x21, [sp, #0x10]
   11b1c:      	ldp	x29, x30, [sp], #0x30
   11b20:      	ret
   11b24:      	b	0x11a00 <_Z20MTARMPMMusicGetSpeedPv+0x6d04>
   11b28:      	cbz	x1, 0x11c20 <_Z20MTARMPMMusicGetSpeedPv+0x6f24>
   11b2c:      	cbz	x0, 0x11c20 <_Z20MTARMPMMusicGetSpeedPv+0x6f24>
   11b30:      	fcmp	s0, #0.0
   11b34:      	b.ls	0x11c20 <_Z20MTARMPMMusicGetSpeedPv+0x6f24>
   11b38:      	fmov	s1, #1.00000000
   11b3c:      	fcmp	s0, s1
   11b40:      	fcsel	s0, s1, s0, gt
   11b44:      	cmp	w2, #0x2
   11b48:      	b.lo	0x11c20 <_Z20MTARMPMMusicGetSpeedPv+0x6f24>
   11b4c:      	lsr	w8, w2, #1
   11b50:      	mov	w9, #0x3                // =3
   11b54:      	movk	w9, #0x8001, lsl #16
   11b58:      	ldrsh	w10, [x1], #0x2
   11b5c:      	ldrsh	w11, [x0]
   11b60:      	scvtf	s1, w10
   11b64:      	cmp	w11, #0x0
   11b68:      	cset	w12, ge
   11b6c:      	fmul	s1, s0, s1
   11b70:      	fcvtzs	w10, s1
   11b74:      	cmp	w10, #0x0
   11b78:      	cset	w13, lt
   11b7c:      	eor	w12, w12, w13
   11b80:      	cset	w13, eq
   11b84:      	csel	w12, wzr, w12, eq
   11b88:      	cmp	w11, #0x0
   11b8c:      	csel	w12, w13, w12, eq
   11b90:      	cmp	w12, #0x1
   11b94:      	b.ne	0x11bcc <_Z20MTARMPMMusicGetSpeedPv+0x6ed0>
   11b98:      	mul	w12, w10, w11
   11b9c:      	smull	x13, w12, w9
   11ba0:      	lsr	x13, x13, #32
   11ba4:      	add	w12, w13, w12
   11ba8:      	asr	w13, w12, #14
   11bac:      	add	w13, w13, w12, lsr #31
   11bb0:      	add	w12, w10, w11
   11bb4:      	sxtw	x12, w12
   11bb8:      	sxtw	x13, w13
   11bbc:      	tbz	w11, #0x1f, 0x11bf4 <_Z20MTARMPMMusicGetSpeedPv+0x6ef8>
   11bc0:      	tbz	w10, #0x1f, 0x11bf4 <_Z20MTARMPMMusicGetSpeedPv+0x6ef8>
   11bc4:      	add	x10, x13, x12
   11bc8:      	b	0x11bf8 <_Z20MTARMPMMusicGetSpeedPv+0x6efc>
   11bcc:      	sxtw	x11, w11
   11bd0:      	sxtw	x10, w10
   11bd4:      	add	x11, x11, #0x8, lsl #12 // =0x8000
   11bd8:      	add	x10, x10, #0x8, lsl #12 // =0x8000
   11bdc:      	mul	x12, x10, x11
   11be0:      	add	x10, x10, x11
   11be4:      	lsl	x10, x10, #1
   11be8:      	sub	x10, x10, x12, asr #15
   11bec:      	sub	x10, x10, #0x18, lsl #12 // =0x18000
   11bf0:      	b	0x11bf8 <_Z20MTARMPMMusicGetSpeedPv+0x6efc>
   11bf4:      	sub	x10, x12, x13
   11bf8:      	cmp	x10, #0x0
   11bfc:      	cneg	x11, x10, mi
   11c00:      	cmp	x11, #0x8, lsl #12      // =0x8000
   11c04:      	b.lo	0x11c14 <_Z20MTARMPMMusicGetSpeedPv+0x6f18>
   11c08:      	sdiv	x10, x11, x10
   11c0c:      	lsl	x11, x10, #15
   11c10:      	sub	x10, x11, x10
   11c14:      	subs	x8, x8, #0x1
   11c18:      	strh	w10, [x0], #0x2
   11c1c:      	b.ne	0x11b58 <_Z20MTARMPMMusicGetSpeedPv+0x6e5c>
   11c20:      	ret
   11c24:      	fcmp	s0, #0.0
   11c28:      	b.mi	0x11c74 <_Z20MTARMPMMusicGetSpeedPv+0x6f78>
   11c2c:      	fmov	s1, #1.00000000
   11c30:      	fcmp	s0, s1
   11c34:      	b.ge	0x11c74 <_Z20MTARMPMMusicGetSpeedPv+0x6f78>
   11c38:      	fcmp	s0, #0.0
   11c3c:      	b.ne	0x11c4c <_Z20MTARMPMMusicGetSpeedPv+0x6f50>
   11c40:      	mov	w2, w1
   11c44:      	mov	w1, wzr
   11c48:      	b	0x16e80 <memset@plt>
   11c4c:      	cmp	w1, #0x2
   11c50:      	b.lo	0x11c74 <_Z20MTARMPMMusicGetSpeedPv+0x6f78>
   11c54:      	lsr	w8, w1, #1
   11c58:      	ldrsh	w9, [x0]
   11c5c:      	subs	w8, w8, #0x1
   11c60:      	scvtf	s1, w9
   11c64:      	fmul	s1, s1, s0
   11c68:      	fcvtzs	w9, s1
   11c6c:      	strh	w9, [x0], #0x2
   11c70:      	b.ne	0x11c58 <_Z20MTARMPMMusicGetSpeedPv+0x6f5c>
   11c74:      	ret
   11c78:      	stp	x29, x30, [sp, #-0x10]!
   11c7c:      	mov	x29, sp
   11c80:      	adrp	x8, 0x1f000
   11c84:      	ldr	w0, [x8, #0xe90]
   11c88:      	bl	0x17120 <pthread_getspecific@plt>
   11c8c:      	cbz	x0, 0x11c98 <_Z20MTARMPMMusicGetSpeedPv+0x6f9c>
   11c90:      	ldp	x29, x30, [sp], #0x10
   11c94:      	ret
   11c98:      	adrp	x8, 0x1f000
   11c9c:      	ldr	x0, [x8, #0xe88]
   11ca0:      	ldp	x29, x30, [sp], #0x10
   11ca4:      	b	0x11d40 <_Z20MTARMPMMusicGetSpeedPv+0x7044>
   11ca8:      	stp	x29, x30, [sp, #-0x10]!
   11cac:      	mov	x29, sp
   11cb0:      	bl	0x17130 <pthread_self@plt>
   11cb4:      	mov	x3, x0
   11cb8:      	nop
   11cbc:      	adr	x1, 0x5139
   11cc0:      	adrp	x2, 0x5000
   11cc4:      	add	x2, x2, #0x358
   11cc8:      	mov	w0, #0x3                // =3
   11ccc:      	bl	0x16e90 <__android_log_print@plt>
   11cd0:      	adrp	x8, 0x1f000
   11cd4:      	ldr	x0, [x8, #0xe88]
   11cd8:      	ldr	x8, [x0]
   11cdc:      	ldr	x1, [x8, #0x28]
   11ce0:      	ldp	x29, x30, [sp], #0x10
   11ce4:      	br	x1
   11ce8:      	stp	x29, x30, [sp, #-0x20]!
   11cec:      	str	x19, [sp, #0x10]
   11cf0:      	mov	x29, sp
   11cf4:      	mov	x19, x0
   11cf8:      	bl	0x17130 <pthread_self@plt>
   11cfc:      	mov	x4, x0
   11d00:      	nop
   11d04:      	adr	x1, 0x5139
   11d08:      	adrp	x2, 0x4000
   11d0c:      	add	x2, x2, #0x612
   11d10:      	mov	w0, #0x3                // =3
   11d14:      	mov	x3, x19
   11d18:      	bl	0x16e90 <__android_log_print@plt>
   11d1c:      	adrp	x8, 0x1f000
   11d20:      	nop
   11d24:      	adr	x0, 0x1fe90 <__bss_start+0xa8>
   11d28:      	nop
   11d2c:      	adr	x1, 0x11ca8 <_Z20MTARMPMMusicGetSpeedPv+0x6fac>
   11d30:      	str	x19, [x8, #0xe88]
   11d34:      	ldr	x19, [sp, #0x10]
   11d38:      	ldp	x29, x30, [sp], #0x20
   11d3c:      	b	0x17140 <pthread_key_create@plt>
   11d40:      	sub	sp, sp, #0x30
   11d44:      	stp	x29, x30, [sp, #0x10]
   11d48:      	stp	x20, x19, [sp, #0x20]
   11d4c:      	add	x29, sp, #0x10
   11d50:      	mrs	x20, TPIDR_EL0
   11d54:      	mov	w2, #0x4                // =4
   11d58:      	mov	x1, sp
   11d5c:      	ldr	x8, [x20, #0x28]
   11d60:      	movk	w2, #0x1, lsl #16
   11d64:      	mov	x19, x0
   11d68:      	str	x8, [sp, #0x8]
   11d6c:      	ldr	x8, [x0]
   11d70:      	str	xzr, [sp]
   11d74:      	ldr	x8, [x8, #0x30]
   11d78:      	blr	x8
   11d7c:      	cmn	w0, #0x3
   11d80:      	b.eq	0x11dc8 <_Z20MTARMPMMusicGetSpeedPv+0x70cc>
   11d84:      	cmn	w0, #0x2
   11d88:      	b.eq	0x11d94 <_Z20MTARMPMMusicGetSpeedPv+0x7098>
   11d8c:      	cbz	w0, 0x11db0 <_Z20MTARMPMMusicGetSpeedPv+0x70b4>
   11d90:      	b	0x11de0 <_Z20MTARMPMMusicGetSpeedPv+0x70e4>
   11d94:      	ldr	x8, [x19]
   11d98:      	mov	x1, sp
   11d9c:      	mov	x0, x19
   11da0:      	mov	x2, xzr
   11da4:      	ldr	x8, [x8, #0x20]
   11da8:      	blr	x8
   11dac:      	tbnz	w0, #0x1f, 0x11e1c <_Z20MTARMPMMusicGetSpeedPv+0x7120>
   11db0:      	adrp	x8, 0x1f000
   11db4:      	ldr	x1, [sp]
   11db8:      	ldr	w0, [x8, #0xe90]
   11dbc:      	bl	0x17070 <pthread_setspecific@plt>
   11dc0:      	ldr	x0, [sp]
   11dc4:      	b	0x11dfc <_Z20MTARMPMMusicGetSpeedPv+0x7100>
   11dc8:      	nop
   11dcc:      	adr	x1, 0x5139
   11dd0:      	adrp	x2, 0x5000
   11dd4:      	add	x2, x2, #0xda2
   11dd8:      	mov	w0, #0x6                // =6
   11ddc:      	bl	0x16e90 <__android_log_print@plt>
   11de0:      	nop
   11de4:      	adr	x1, 0x5139
   11de8:      	adrp	x2, 0x4000
   11dec:      	add	x2, x2, #0xc6b
   11df0:      	mov	w0, #0x6                // =6
   11df4:      	bl	0x16e90 <__android_log_print@plt>
   11df8:      	mov	x0, xzr
   11dfc:      	ldr	x8, [x20, #0x28]
   11e00:      	ldr	x9, [sp, #0x8]
   11e04:      	cmp	x8, x9
   11e08:      	b.ne	0x11e30 <_Z20MTARMPMMusicGetSpeedPv+0x7134>
   11e0c:      	ldp	x20, x19, [sp, #0x20]
   11e10:      	ldp	x29, x30, [sp, #0x10]
   11e14:      	add	sp, sp, #0x30
   11e18:      	ret
   11e1c:      	nop
   11e20:      	adr	x1, 0x5139
   11e24:      	adrp	x2, 0x4000
   11e28:      	add	x2, x2, #0xda8
   11e2c:      	b	0x11df0 <_Z20MTARMPMMusicGetSpeedPv+0x70f4>
   11e30:      	bl	0x16b40 <__stack_chk_fail@plt>
   11e34:      	stp	x29, x30, [sp, #-0x20]!
   11e38:      	str	x19, [sp, #0x10]
   11e3c:      	mov	x29, sp
   11e40:      	mov	w0, #0x28               // =40
   11e44:      	bl	0x11e7c <_Z20MTARMPMMusicGetSpeedPv+0x7180>
   11e48:      	mov	x19, x0
   11e4c:      	cbz	x0, 0x11e6c <_Z20MTARMPMMusicGetSpeedPv+0x7170>
   11e50:      	mov	x0, x19
   11e54:      	mov	x1, xzr
   11e58:      	bl	0x17150 <pthread_mutex_init@plt>
   11e5c:      	cbz	w0, 0x11e6c <_Z20MTARMPMMusicGetSpeedPv+0x7170>
   11e60:      	mov	x0, x19
   11e64:      	bl	0x17100 <free@plt>
   11e68:      	mov	x19, xzr
   11e6c:      	mov	x0, x19
   11e70:      	ldr	x19, [sp, #0x10]
   11e74:      	ldp	x29, x30, [sp], #0x20
   11e78:      	ret
   11e7c:      	stp	x29, x30, [sp, #-0x20]!
   11e80:      	stp	x20, x19, [sp, #0x10]
   11e84:      	mov	x29, sp
   11e88:      	mov	x19, x0
   11e8c:      	bl	0x17110 <malloc@plt>
   11e90:      	mov	x20, x0
   11e94:      	cbz	x0, 0x11ea8 <_Z20MTARMPMMusicGetSpeedPv+0x71ac>
   11e98:      	mov	x0, x20
   11e9c:      	mov	w1, wzr
   11ea0:      	mov	x2, x19
   11ea4:      	bl	0x16e80 <memset@plt>
   11ea8:      	mov	x0, x20
   11eac:      	ldp	x20, x19, [sp, #0x10]
   11eb0:      	ldp	x29, x30, [sp], #0x20
   11eb4:      	ret
   11eb8:      	cbz	x0, 0x11ee0 <_Z20MTARMPMMusicGetSpeedPv+0x71e4>
   11ebc:      	stp	x29, x30, [sp, #-0x20]!
   11ec0:      	str	x19, [sp, #0x10]
   11ec4:      	mov	x29, sp
   11ec8:      	mov	x19, x0
   11ecc:      	bl	0x17160 <pthread_mutex_destroy@plt>
   11ed0:      	mov	x0, x19
   11ed4:      	ldr	x19, [sp, #0x10]
   11ed8:      	ldp	x29, x30, [sp], #0x20
   11edc:      	b	0x17100 <free@plt>
   11ee0:      	ret
   11ee4:      	cbz	x0, 0x11eec <_Z20MTARMPMMusicGetSpeedPv+0x71f0>
   11ee8:      	b	0x17170 <pthread_mutex_lock@plt>
   11eec:      	mov	w0, #-0x1               // =-1
   11ef0:      	ret
   11ef4:      	cbz	x0, 0x11efc <_Z20MTARMPMMusicGetSpeedPv+0x7200>
   11ef8:      	b	0x17180 <pthread_mutex_unlock@plt>
   11efc:      	mov	w0, #-0x1               // =-1
   11f00:      	ret
   11f04:      	stp	x29, x30, [sp, #-0x20]!
   11f08:      	str	x19, [sp, #0x10]
   11f0c:      	mov	x29, sp
   11f10:      	mov	w0, #0x30               // =48
   11f14:      	bl	0x11e7c <_Z20MTARMPMMusicGetSpeedPv+0x7180>
   11f18:      	mov	x19, x0
   11f1c:      	cbz	x0, 0x11f3c <_Z20MTARMPMMusicGetSpeedPv+0x7240>
   11f20:      	mov	x0, x19
   11f24:      	mov	x1, xzr
   11f28:      	bl	0x17190 <pthread_cond_init@plt>
   11f2c:      	cbz	w0, 0x11f3c <_Z20MTARMPMMusicGetSpeedPv+0x7240>
   11f30:      	mov	x0, x19
   11f34:      	bl	0x17100 <free@plt>
   11f38:      	mov	x19, xzr
   11f3c:      	mov	x0, x19
   11f40:      	ldr	x19, [sp, #0x10]
   11f44:      	ldp	x29, x30, [sp], #0x20
   11f48:      	ret
   11f4c:      	cbz	x0, 0x11f74 <_Z20MTARMPMMusicGetSpeedPv+0x7278>
   11f50:      	stp	x29, x30, [sp, #-0x20]!
   11f54:      	str	x19, [sp, #0x10]
   11f58:      	mov	x29, sp
   11f5c:      	mov	x19, x0
   11f60:      	bl	0x171a0 <pthread_cond_destroy@plt>
   11f64:      	mov	x0, x19
   11f68:      	ldr	x19, [sp, #0x10]
   11f6c:      	ldp	x29, x30, [sp], #0x20
   11f70:      	b	0x17100 <free@plt>
   11f74:      	ret
   11f78:      	cbz	x0, 0x11f80 <_Z20MTARMPMMusicGetSpeedPv+0x7284>
   11f7c:      	b	0x171b0 <pthread_cond_signal@plt>
   11f80:      	mov	w0, #-0x1               // =-1
   11f84:      	ret
   11f88:      	sub	sp, sp, #0x60
   11f8c:      	stp	x29, x30, [sp, #0x30]
   11f90:      	stp	x22, x21, [sp, #0x40]
   11f94:      	stp	x20, x19, [sp, #0x50]
   11f98:      	add	x29, sp, #0x30
   11f9c:      	mrs	x22, TPIDR_EL0
   11fa0:      	mov	x20, x0
   11fa4:      	mov	w0, #-0x1               // =-1
   11fa8:      	ldr	x8, [x22, #0x28]
   11fac:      	stur	x8, [x29, #-0x8]
   11fb0:      	cbz	x20, 0x12050 <_Z20MTARMPMMusicGetSpeedPv+0x7354>
   11fb4:      	mov	x19, x1
   11fb8:      	cbz	x1, 0x12050 <_Z20MTARMPMMusicGetSpeedPv+0x7354>
   11fbc:      	add	x0, sp, #0x18
   11fc0:      	mov	x1, xzr
   11fc4:      	mov	w21, w2
   11fc8:      	bl	0x171c0 <gettimeofday@plt>
   11fcc:      	mov	w8, #0x4dd3             // =19923
   11fd0:      	mov	w10, #0x3e8             // =1000
   11fd4:      	movk	w8, #0x1062, lsl #16
   11fd8:      	ldp	x12, x11, [sp, #0x18]
   11fdc:      	umull	x9, w21, w8
   11fe0:      	lsr	x8, x9, #38
   11fe4:      	add	x9, x12, x9, lsr #38
   11fe8:      	msub	w8, w8, w10, w21
   11fec:      	mul	w8, w8, w10
   11ff0:      	add	x11, x11, x8
   11ff4:      	mul	x8, x11, x10
   11ff8:      	mov	w10, #0x4241            // =16961
   11ffc:      	movk	w10, #0xf, lsl #16
   12000:      	cmp	x11, x10
   12004:      	stp	x9, x8, [sp, #0x8]
   12008:      	b.lt	0x12020 <_Z20MTARMPMMusicGetSpeedPv+0x7324>
   1200c:      	mov	x10, #-0xca00           // =-51712
   12010:      	add	x9, x9, #0x1
   12014:      	movk	x10, #0xc465, lsl #16
   12018:      	add	x8, x8, x10
   1201c:      	stp	x9, x8, [sp, #0x8]
   12020:      	add	x2, sp, #0x8
   12024:      	mov	x0, x20
   12028:      	mov	x1, x19
   1202c:      	bl	0x171d0 <pthread_cond_timedwait@plt>
   12030:      	cmp	w0, #0x4
   12034:      	b.eq	0x12020 <_Z20MTARMPMMusicGetSpeedPv+0x7324>
   12038:      	cmp	w0, #0x6e
   1203c:      	b.eq	0x1204c <_Z20MTARMPMMusicGetSpeedPv+0x7350>
   12040:      	cbz	w0, 0x12050 <_Z20MTARMPMMusicGetSpeedPv+0x7354>
   12044:      	mov	w0, #-0x1               // =-1
   12048:      	b	0x12050 <_Z20MTARMPMMusicGetSpeedPv+0x7354>
   1204c:      	mov	w0, #0x1                // =1
   12050:      	ldr	x8, [x22, #0x28]
   12054:      	ldur	x9, [x29, #-0x8]
   12058:      	cmp	x8, x9
   1205c:      	b.ne	0x12074 <_Z20MTARMPMMusicGetSpeedPv+0x7378>
   12060:      	ldp	x20, x19, [sp, #0x50]
   12064:      	ldp	x22, x21, [sp, #0x40]
   12068:      	ldp	x29, x30, [sp, #0x30]
   1206c:      	add	sp, sp, #0x60
   12070:      	ret
   12074:      	bl	0x16b40 <__stack_chk_fail@plt>
   12078:      	stp	x29, x30, [sp, #-0x20]!
   1207c:      	str	x19, [sp, #0x10]
   12080:      	mov	x29, sp
   12084:      	mov	x19, x0
   12088:      	stp	x1, x2, [x0, #0x8]
   1208c:      	add	x0, x0, #0x18
   12090:      	mov	x1, x3
   12094:      	mov	w2, #0x1f               // =31
   12098:      	mov	w3, #0x20               // =32
   1209c:      	bl	0x171e0 <__strlcpy_chk@plt>
   120a0:      	nop
   120a4:      	adr	x2, 0x120cc <_Z20MTARMPMMusicGetSpeedPv+0x73d0>
   120a8:      	mov	x0, x19
   120ac:      	mov	x1, xzr
   120b0:      	mov	x3, x19
   120b4:      	bl	0x16df0 <pthread_create@plt>
   120b8:      	cmp	w0, #0x0
   120bc:      	csel	x0, x19, xzr, eq
   120c0:      	ldr	x19, [sp, #0x10]
   120c4:      	ldp	x29, x30, [sp], #0x20
   120c8:      	ret
   120cc:      	stp	x29, x30, [sp, #-0x20]!
   120d0:      	str	x19, [sp, #0x10]
   120d4:      	mov	x29, sp
   120d8:      	mov	x19, x0
   120dc:      	ldp	x8, x0, [x0, #0x8]
   120e0:      	blr	x8
   120e4:      	mov	w8, w0
   120e8:      	mov	x0, xzr
   120ec:      	str	w8, [x19, #0x38]
   120f0:      	ldr	x19, [sp, #0x10]
   120f4:      	ldp	x29, x30, [sp], #0x20
   120f8:      	ret
   120fc:      	sub	sp, sp, #0x40
   12100:      	stp	x29, x30, [sp, #0x10]
   12104:      	str	x21, [sp, #0x20]
   12108:      	stp	x20, x19, [sp, #0x30]
   1210c:      	add	x29, sp, #0x10
   12110:      	mrs	x21, TPIDR_EL0
   12114:      	mov	w20, w0
   12118:      	ldr	x8, [x21, #0x28]
   1211c:      	str	x8, [sp, #0x8]
   12120:      	bl	0x17130 <pthread_self@plt>
   12124:      	mov	x1, sp
   12128:      	add	x2, sp, #0x4
   1212c:      	mov	x19, x0
   12130:      	bl	0x171f0 <pthread_getschedparam@plt>
   12134:      	tbnz	w0, #0x1f, 0x12150 <_Z20MTARMPMMusicGetSpeedPv+0x7454>
   12138:      	ldr	w0, [sp]
   1213c:      	cmp	w20, #0x2
   12140:      	b.eq	0x1215c <_Z20MTARMPMMusicGetSpeedPv+0x7460>
   12144:      	cbnz	w20, 0x12168 <_Z20MTARMPMMusicGetSpeedPv+0x746c>
   12148:      	bl	0x17200 <sched_get_priority_min@plt>
   1214c:      	b	0x12160 <_Z20MTARMPMMusicGetSpeedPv+0x7464>
   12150:      	adrp	x2, 0x4000
   12154:      	add	x2, x2, #0xc21
   12158:      	b	0x121b0 <_Z20MTARMPMMusicGetSpeedPv+0x74b4>
   1215c:      	bl	0x17210 <sched_get_priority_max@plt>
   12160:      	str	w0, [sp, #0x4]
   12164:      	b	0x1218c <_Z20MTARMPMMusicGetSpeedPv+0x7490>
   12168:      	bl	0x17200 <sched_get_priority_min@plt>
   1216c:      	ldr	w8, [sp]
   12170:      	mov	w20, w0
   12174:      	mov	w0, w8
   12178:      	bl	0x17210 <sched_get_priority_max@plt>
   1217c:      	subs	w8, w0, w20
   12180:      	cinc	w8, w8, lt
   12184:      	add	w8, w20, w8, asr #1
   12188:      	str	w8, [sp, #0x4]
   1218c:      	ldr	w1, [sp]
   12190:      	add	x2, sp, #0x4
   12194:      	mov	x0, x19
   12198:      	bl	0x17220 <pthread_setschedparam@plt>
   1219c:      	tbnz	w0, #0x1f, 0x121a8 <_Z20MTARMPMMusicGetSpeedPv+0x74ac>
   121a0:      	mov	w0, wzr
   121a4:      	b	0x121c4 <_Z20MTARMPMMusicGetSpeedPv+0x74c8>
   121a8:      	adrp	x2, 0x5000
   121ac:      	add	x2, x2, #0xb8
   121b0:      	nop
   121b4:      	adr	x1, 0x4e4c
   121b8:      	mov	w0, #0x6                // =6
   121bc:      	bl	0x16e90 <__android_log_print@plt>
   121c0:      	mov	w0, #-0x1               // =-1
   121c4:      	ldr	x8, [x21, #0x28]
   121c8:      	ldr	x9, [sp, #0x8]
   121cc:      	cmp	x8, x9
   121d0:      	b.ne	0x121e8 <_Z20MTARMPMMusicGetSpeedPv+0x74ec>
   121d4:      	ldp	x20, x19, [sp, #0x30]
   121d8:      	ldr	x21, [sp, #0x20]
   121dc:      	ldp	x29, x30, [sp, #0x10]
   121e0:      	add	sp, sp, #0x40
   121e4:      	ret
   121e8:      	bl	0x16b40 <__stack_chk_fail@plt>
   121ec:      	cbz	x0, 0x12224 <_Z20MTARMPMMusicGetSpeedPv+0x7528>
   121f0:      	stp	x29, x30, [sp, #-0x20]!
   121f4:      	stp	x20, x19, [sp, #0x10]
   121f8:      	mov	x29, sp
   121fc:      	mov	x19, x0
   12200:      	ldr	x0, [x0]
   12204:      	mov	x20, x1
   12208:      	mov	x1, xzr
   1220c:      	bl	0x17230 <pthread_join@plt>
   12210:      	cbz	x20, 0x1221c <_Z20MTARMPMMusicGetSpeedPv+0x7520>
   12214:      	ldr	w8, [x19, #0x38]
   12218:      	str	w8, [x20]
   1221c:      	ldp	x20, x19, [sp, #0x10]
   12220:      	ldp	x29, x30, [sp], #0x20
   12224:      	ret
   12228:      	cbz	x0, 0x1223c <_Z20MTARMPMMusicGetSpeedPv+0x7540>
   1222c:      	cbz	x1, 0x1223c <_Z20MTARMPMMusicGetSpeedPv+0x7540>
   12230:      	ldr	x3, [x0, #0x18]
   12234:      	cbz	x3, 0x1223c <_Z20MTARMPMMusicGetSpeedPv+0x7540>
   12238:      	br	x3
   1223c:      	mov	w0, #-0x1               // =-1
   12240:      	ret
   12244:      	cbz	x0, 0x12254 <_Z20MTARMPMMusicGetSpeedPv+0x7558>
   12248:      	ldr	x2, [x0, #0x20]
   1224c:      	cbz	x2, 0x12254 <_Z20MTARMPMMusicGetSpeedPv+0x7558>
   12250:      	br	x2
   12254:      	ret
   12258:      	cbz	x0, 0x12268 <_Z20MTARMPMMusicGetSpeedPv+0x756c>
   1225c:      	ldr	x2, [x0, #0x40]
   12260:      	cbz	x2, 0x12268 <_Z20MTARMPMMusicGetSpeedPv+0x756c>
   12264:      	br	x2
   12268:      	ret
   1226c:      	cbz	x0, 0x1227c <_Z20MTARMPMMusicGetSpeedPv+0x7580>
   12270:      	ldr	x1, [x0, #0x38]
   12274:      	cbz	x1, 0x1227c <_Z20MTARMPMMusicGetSpeedPv+0x7580>
   12278:      	br	x1
   1227c:      	ret
   12280:      	cbz	x0, 0x12290 <_Z20MTARMPMMusicGetSpeedPv+0x7594>
   12284:      	ldr	x1, [x0, #0x10]
   12288:      	cbz	x1, 0x12294 <_Z20MTARMPMMusicGetSpeedPv+0x7598>
   1228c:      	br	x1
   12290:      	ret
   12294:      	b	0x17100 <free@plt>
   12298:      	stp	x29, x30, [sp, #-0x20]!
   1229c:      	stp	x20, x19, [sp, #0x10]
   122a0:      	mov	x29, sp
   122a4:      	mov	w20, w0
   122a8:      	mov	w0, #0x1                // =1
   122ac:      	mov	w1, #0x20               // =32
   122b0:      	bl	0x170f0 <calloc@plt>
   122b4:      	mov	x19, x0
   122b8:      	cbz	x0, 0x122f4 <_Z20MTARMPMMusicGetSpeedPv+0x75f8>
   122bc:      	cmp	w20, #0x0
   122c0:      	mov	w8, #0x1001             // =4097
   122c4:      	csinc	w20, w8, w20, eq
   122c8:      	sxtw	x0, w20
   122cc:      	str	w20, [x19, #0x8]
   122d0:      	bl	0x17110 <malloc@plt>
   122d4:      	str	x0, [x19]
   122d8:      	cbz	x0, 0x122e8 <_Z20MTARMPMMusicGetSpeedPv+0x75ec>
   122dc:      	sub	w8, w20, #0x1
   122e0:      	str	w8, [x19, #0xc]
   122e4:      	b	0x122f4 <_Z20MTARMPMMusicGetSpeedPv+0x75f8>
   122e8:      	mov	x0, x19
   122ec:      	bl	0x17100 <free@plt>
   122f0:      	mov	x19, xzr
   122f4:      	mov	x0, x19
   122f8:      	ldp	x20, x19, [sp, #0x10]
   122fc:      	ldp	x29, x30, [sp], #0x20
   12300:      	ret
   12304:      	stp	x29, x30, [sp, #-0x40]!
   12308:      	str	x23, [sp, #0x10]
   1230c:      	stp	x22, x21, [sp, #0x20]
   12310:      	stp	x20, x19, [sp, #0x30]
   12314:      	mov	x29, sp
   12318:      	ldp	w9, w8, [x0, #0x10]
   1231c:      	mov	x19, x0
   12320:      	cmp	w9, w2
   12324:      	csel	w20, w9, w2, lt
   12328:      	cmp	w20, #0x1
   1232c:      	b.lt	0x1239c <_Z20MTARMPMMusicGetSpeedPv+0x76a0>
   12330:      	ldr	w11, [x19, #0x18]
   12334:      	sxtw	x9, w8
   12338:      	ldr	x10, [x19]
   1233c:      	mov	x21, x1
   12340:      	cmp	w11, w8
   12344:      	b.gt	0x12380 <_Z20MTARMPMMusicGetSpeedPv+0x7684>
   12348:      	ldrsw	x11, [x19, #0x8]
   1234c:      	sub	x22, x11, w8, sxtw
   12350:      	subs	w23, w20, w22
   12354:      	b.le	0x12380 <_Z20MTARMPMMusicGetSpeedPv+0x7684>
   12358:      	add	x1, x10, x9
   1235c:      	mov	x0, x21
   12360:      	mov	x2, x22
   12364:      	bl	0x17240 <memcpy@plt>
   12368:      	ldr	x1, [x19]
   1236c:      	sxtw	x2, w23
   12370:      	add	x0, x21, x22
   12374:      	bl	0x17240 <memcpy@plt>
   12378:      	mov	w8, w23
   1237c:      	b	0x12398 <_Z20MTARMPMMusicGetSpeedPv+0x769c>
   12380:      	add	x1, x10, x9
   12384:      	mov	x0, x21
   12388:      	mov	x2, x20
   1238c:      	bl	0x17240 <memcpy@plt>
   12390:      	ldr	w8, [x19, #0x14]
   12394:      	add	w8, w8, w20
   12398:      	str	w8, [x19, #0x14]
   1239c:      	ldr	w9, [x19, #0x18]
   123a0:      	subs	w8, w9, w8
   123a4:      	b.eq	0x123b4 <_Z20MTARMPMMusicGetSpeedPv+0x76b8>
   123a8:      	b.ge	0x123b4 <_Z20MTARMPMMusicGetSpeedPv+0x76b8>
   123ac:      	ldr	w9, [x19, #0x8]
   123b0:      	add	w8, w8, w9
   123b4:      	ldr	w9, [x19, #0x8]
   123b8:      	mvn	w10, w8
   123bc:      	add	w9, w9, w10
   123c0:      	stp	w9, w8, [x19, #0xc]
   123c4:      	mov	w0, w20
   123c8:      	ldp	x20, x19, [sp, #0x30]
   123cc:      	ldr	x23, [sp, #0x10]
   123d0:      	ldp	x22, x21, [sp, #0x20]
   123d4:      	ldp	x29, x30, [sp], #0x40
   123d8:      	ret
   123dc:      	stp	x29, x30, [sp, #-0x40]!
   123e0:      	str	x23, [sp, #0x10]
   123e4:      	stp	x22, x21, [sp, #0x20]
   123e8:      	stp	x20, x19, [sp, #0x30]
   123ec:      	mov	x29, sp
   123f0:      	mov	x19, x0
   123f4:      	mov	w0, wzr
   123f8:      	cbz	x19, 0x12504 <_Z20MTARMPMMusicGetSpeedPv+0x7808>
   123fc:      	mov	x21, x1
   12400:      	cbz	x1, 0x12504 <_Z20MTARMPMMusicGetSpeedPv+0x7808>
   12404:      	mov	w20, w2
   12408:      	cbz	w2, 0x12504 <_Z20MTARMPMMusicGetSpeedPv+0x7808>
   1240c:      	ldr	w22, [x19, #0xc]
   12410:      	subs	w8, w20, w22
   12414:      	b.ge	0x12420 <_Z20MTARMPMMusicGetSpeedPv+0x7724>
   12418:      	mov	w22, w20
   1241c:      	b	0x12458 <_Z20MTARMPMMusicGetSpeedPv+0x775c>
   12420:      	ldr	w9, [x19, #0x1c]
   12424:      	cmp	w9, #0x1
   12428:      	b.ne	0x12458 <_Z20MTARMPMMusicGetSpeedPv+0x775c>
   1242c:      	ldrsw	x23, [x19, #0x8]
   12430:      	cmp	w23, w20
   12434:      	b.le	0x12518 <_Z20MTARMPMMusicGetSpeedPv+0x781c>
   12438:      	ldr	w9, [x19, #0x14]
   1243c:      	add	w8, w9, w8
   12440:      	cmp	w8, w23
   12444:      	str	w8, [x19, #0x14]
   12448:      	b.lt	0x12418 <_Z20MTARMPMMusicGetSpeedPv+0x771c>
   1244c:      	sub	w8, w8, w23
   12450:      	str	w8, [x19, #0x14]
   12454:      	b	0x12418 <_Z20MTARMPMMusicGetSpeedPv+0x771c>
   12458:      	ldp	w9, w8, [x19, #0x14]
   1245c:      	sxtw	x8, w8
   12460:      	cmp	w8, w9
   12464:      	b.ge	0x1247c <_Z20MTARMPMMusicGetSpeedPv+0x7780>
   12468:      	mov	w9, w22
   1246c:      	ldr	x10, [x19]
   12470:      	sxtw	x2, w9
   12474:      	add	x0, x10, x8
   12478:      	b	0x124bc <_Z20MTARMPMMusicGetSpeedPv+0x77c0>
   1247c:      	ldrsw	x9, [x19, #0x8]
   12480:      	sub	x20, x9, x8
   12484:      	ldr	x9, [x19]
   12488:      	subs	w23, w22, w20
   1248c:      	b.le	0x124b4 <_Z20MTARMPMMusicGetSpeedPv+0x77b8>
   12490:      	add	x0, x9, x8
   12494:      	mov	x1, x21
   12498:      	mov	x2, x20
   1249c:      	bl	0x17240 <memcpy@plt>
   124a0:      	ldr	x0, [x19]
   124a4:      	sxtw	x2, w23
   124a8:      	add	x1, x21, x20
   124ac:      	bl	0x17240 <memcpy@plt>
   124b0:      	b	0x124cc <_Z20MTARMPMMusicGetSpeedPv+0x77d0>
   124b4:      	sxtw	x2, w22
   124b8:      	add	x0, x9, x8
   124bc:      	mov	x1, x21
   124c0:      	bl	0x17240 <memcpy@plt>
   124c4:      	ldr	w8, [x19, #0x18]
   124c8:      	add	w23, w8, w22
   124cc:      	ldr	w8, [x19, #0x14]
   124d0:      	str	w23, [x19, #0x18]
   124d4:      	subs	w8, w23, w8
   124d8:      	b.eq	0x124e8 <_Z20MTARMPMMusicGetSpeedPv+0x77ec>
   124dc:      	b.ge	0x124e8 <_Z20MTARMPMMusicGetSpeedPv+0x77ec>
   124e0:      	ldr	w9, [x19, #0x8]
   124e4:      	add	w8, w8, w9
   124e8:      	mov	w20, w22
   124ec:      	str	w8, [x19, #0x10]
   124f0:      	ldr	w9, [x19, #0x8]
   124f4:      	mvn	w8, w8
   124f8:      	mov	w0, w20
   124fc:      	add	w8, w9, w8
   12500:      	str	w8, [x19, #0xc]
   12504:      	ldp	x20, x19, [sp, #0x30]
   12508:      	ldr	x23, [sp, #0x10]
   1250c:      	ldp	x22, x21, [sp, #0x20]
   12510:      	ldp	x29, x30, [sp], #0x40
   12514:      	ret
   12518:      	sub	x22, x23, #0x1
   1251c:      	ldr	x0, [x19]
   12520:      	str	wzr, [x19, #0x14]
   12524:      	sub	w8, w20, w22
   12528:      	mov	x2, x22
   1252c:      	add	x1, x21, w8, sxtw
   12530:      	bl	0x17240 <memcpy@plt>
   12534:      	ldr	w10, [x19, #0x14]
   12538:      	mov	w8, wzr
   1253c:      	str	w22, [x19, #0x18]
   12540:      	subs	w9, w22, w10
   12544:      	b.eq	0x124ec <_Z20MTARMPMMusicGetSpeedPv+0x77f0>
   12548:      	cmp	w23, w10
   1254c:      	b.le	0x12558 <_Z20MTARMPMMusicGetSpeedPv+0x785c>
   12550:      	mov	w8, w9
   12554:      	b	0x124ec <_Z20MTARMPMMusicGetSpeedPv+0x77f0>
   12558:      	ldr	w8, [x19, #0x8]
   1255c:      	add	w8, w9, w8
   12560:      	b	0x124ec <_Z20MTARMPMMusicGetSpeedPv+0x77f0>
   12564:      	ldr	w0, [x0, #0x10]
   12568:      	ret
   1256c:      	ldr	w0, [x0, #0xc]
   12570:      	ret
   12574:      	ldr	w8, [x0, #0x8]
   12578:      	str	wzr, [x0, #0x18]
   1257c:      	str	xzr, [x0, #0x10]
   12580:      	sub	w8, w8, #0x1
   12584:      	str	w8, [x0, #0xc]
   12588:      	ret
   1258c:      	stp	x29, x30, [sp, #-0x20]!
   12590:      	str	x19, [sp, #0x10]
   12594:      	mov	x29, sp
   12598:      	mov	x19, x0
   1259c:      	ldr	x0, [x0]
   125a0:      	bl	0x17100 <free@plt>
   125a4:      	mov	x0, x19
   125a8:      	ldr	x19, [sp, #0x10]
   125ac:      	ldp	x29, x30, [sp], #0x20
   125b0:      	b	0x17100 <free@plt>
		...
   125c0:      	bti	c
   125c4:      	adrp	x16, 0x1f000
   125c8:      	ldrb	w16, [x16, #0xe94]
   125cc:      	cbz	w16, 0x125d8 <_Z20MTARMPMMusicGetSpeedPv+0x78dc>
   125d0:      	ldadd	x0, x0, [x1]
   125d4:      	ret
   125d8:      	mov	x16, x0
   125dc:      	ldxr	x0, [x1]
   125e0:      	add	x17, x0, x16
   125e4:      	stxr	w15, x17, [x1]
   125e8:      	cbnz	w15, 0x125dc <_Z20MTARMPMMusicGetSpeedPv+0x78e0>
   125ec:      	ret
   125f0:      	paciasp
   125f4:      	sub	sp, sp, #0x70
   125f8:      	str	x30, [sp, #0x60]
   125fc:      	mov	w0, #0x10               // =16
   12600:      	bl	0x17250 <getauxval@plt>
   12604:      	tbnz	w0, #0x8, 0x12620 <_Z20MTARMPMMusicGetSpeedPv+0x7924>
   12608:      	adrp	x9, 0x1f000
   1260c:      	ldr	x30, [sp, #0x60]
   12610:      	strb	wzr, [x9, #0xe94]
   12614:      	add	sp, sp, #0x70
   12618:      	autiasp
   1261c:      	ret
   12620:      	nop
   12624:      	adr	x0, 0x4c40
   12628:      	add	x1, sp, #0x4
   1262c:      	bl	0x17260 <__system_property_get@plt>
   12630:      	cmp	w0, #0x0
   12634:      	b.le	0x1266c <_Z20MTARMPMMusicGetSpeedPv+0x7970>
   12638:      	adrp	x1, 0x4000
   1263c:      	add	x1, x1, #0xde2
   12640:      	add	x0, sp, #0x4
   12644:      	mov	w2, #0xa                // =10
   12648:      	bl	0x17270 <strncmp@plt>
   1264c:      	cmp	w0, #0x0
   12650:      	cset	w8, ne
   12654:      	adrp	x9, 0x1f000
   12658:      	ldr	x30, [sp, #0x60]
   1265c:      	strb	w8, [x9, #0xe94]
   12660:      	add	sp, sp, #0x70
   12664:      	autiasp
   12668:      	ret
   1266c:      	mov	w8, #0x1                // =1
   12670:      	adrp	x9, 0x1f000
   12674:      	ldr	x30, [sp, #0x60]
   12678:      	strb	w8, [x9, #0xe94]
   1267c:      	add	sp, sp, #0x70
   12680:      	autiasp
   12684:      	ret
   12688:      	bti	c
   1268c:      	tbnz	x0, #0x3e, 0x126a0 <_Z20MTARMPMMusicGetSpeedPv+0x79a4>
   12690:      	mov	x9, xzr
   12694:      	adrp	x8, 0x1f000
   12698:      	tbnz	w0, #0x7, 0x126ac <_Z20MTARMPMMusicGetSpeedPv+0x79b0>
   1269c:      	b	0x126b8 <_Z20MTARMPMMusicGetSpeedPv+0x79bc>
   126a0:      	ldr	x9, [x1, #0x10]
   126a4:      	adrp	x8, 0x1f000
   126a8:      	tbz	w0, #0x7, 0x126b8 <_Z20MTARMPMMusicGetSpeedPv+0x79bc>
   126ac:      	ldr	x10, [x8, #0xe98]
   126b0:      	orr	x10, x10, #0x400
   126b4:      	str	x10, [x8, #0xe98]
   126b8:      	tbnz	w0, #0x4, 0x127fc <_Z20MTARMPMMusicGetSpeedPv+0x7b00>
   126bc:      	tbnz	w0, #0x1b, 0x1280c <_Z20MTARMPMMusicGetSpeedPv+0x7b10>
   126c0:      	tbnz	w9, #0x7, 0x1281c <_Z20MTARMPMMusicGetSpeedPv+0x7b20>
   126c4:      	mvn	w10, w0
   126c8:      	tst	x10, #0xc0000
   126cc:      	b.eq	0x12834 <_Z20MTARMPMMusicGetSpeedPv+0x7b38>
   126d0:      	tbnz	w0, #0x14, 0x12844 <_Z20MTARMPMMusicGetSpeedPv+0x7b48>
   126d4:      	tbnz	w0, #0x17, 0x12854 <_Z20MTARMPMMusicGetSpeedPv+0x7b58>
   126d8:      	tbnz	w0, #0x9, 0x12864 <_Z20MTARMPMMusicGetSpeedPv+0x7b68>
   126dc:      	tbnz	w0, #0x18, 0x1287c <_Z20MTARMPMMusicGetSpeedPv+0x7b80>
   126e0:      	tbnz	w0, #0xc, 0x1288c <_Z20MTARMPMMusicGetSpeedPv+0x7b90>
   126e4:      	tbnz	w0, #0x1a, 0x1289c <_Z20MTARMPMMusicGetSpeedPv+0x7ba0>
   126e8:      	tbnz	w0, #0x3, 0x128ac <_Z20MTARMPMMusicGetSpeedPv+0x7bb0>
   126ec:      	tbnz	w0, #0x5, 0x128bc <_Z20MTARMPMMusicGetSpeedPv+0x7bc0>
   126f0:      	tbnz	w0, #0x6, 0x128cc <_Z20MTARMPMMusicGetSpeedPv+0x7bd0>
   126f4:      	tbnz	w0, #0xd, 0x128dc <_Z20MTARMPMMusicGetSpeedPv+0x7be0>
   126f8:      	tbnz	w0, #0xe, 0x128ec <_Z20MTARMPMMusicGetSpeedPv+0x7bf0>
   126fc:      	tbnz	w0, #0x1d, 0x128fc <_Z20MTARMPMMusicGetSpeedPv+0x7c00>
   12700:      	tbnz	w0, #0x1c, 0x1290c <_Z20MTARMPMMusicGetSpeedPv+0x7c10>
   12704:      	tbnz	w9, #0x12, 0x1291c <_Z20MTARMPMMusicGetSpeedPv+0x7c20>
   12708:      	tbnz	w9, #0x16, 0x1292c <_Z20MTARMPMMusicGetSpeedPv+0x7c30>
   1270c:      	tbnz	w9, #0x2, 0x1293c <_Z20MTARMPMMusicGetSpeedPv+0x7c40>
   12710:      	tbnz	w9, #0x3, 0x1294c <_Z20MTARMPMMusicGetSpeedPv+0x7c50>
   12714:      	tbnz	w9, #0x4, 0x1295c <_Z20MTARMPMMusicGetSpeedPv+0x7c60>
   12718:      	tbnz	w9, #0x5, 0x1296c <_Z20MTARMPMMusicGetSpeedPv+0x7c70>
   1271c:      	tbnz	w9, #0x6, 0x1297c <_Z20MTARMPMMusicGetSpeedPv+0x7c80>
   12720:      	tbnz	w9, #0x0, 0x1298c <_Z20MTARMPMMusicGetSpeedPv+0x7c90>
   12724:      	tbnz	w0, #0x8, 0x1299c <_Z20MTARMPMMusicGetSpeedPv+0x7ca0>
   12728:      	tbnz	w9, #0x10, 0x129ac <_Z20MTARMPMMusicGetSpeedPv+0x7cb0>
   1272c:      	tbnz	w9, #0xd, 0x129bc <_Z20MTARMPMMusicGetSpeedPv+0x7cc0>
   12730:      	tbnz	x9, #0x20, 0x129cc <_Z20MTARMPMMusicGetSpeedPv+0x7cd0>
   12734:      	tbnz	x9, #0x21, 0x129dc <_Z20MTARMPMMusicGetSpeedPv+0x7ce0>
   12738:      	tbnz	w9, #0xf, 0x129ec <_Z20MTARMPMMusicGetSpeedPv+0x7cf0>
   1273c:      	tbnz	w9, #0x8, 0x129fc <_Z20MTARMPMMusicGetSpeedPv+0x7d00>
   12740:      	tbnz	w9, #0x9, 0x12a0c <_Z20MTARMPMMusicGetSpeedPv+0x7d10>
   12744:      	tbnz	w9, #0xa, 0x12a1c <_Z20MTARMPMMusicGetSpeedPv+0x7d20>
   12748:      	tbnz	w9, #0xb, 0x12a2c <_Z20MTARMPMMusicGetSpeedPv+0x7d30>
   1274c:      	tbnz	w9, #0x11, 0x12a3c <_Z20MTARMPMMusicGetSpeedPv+0x7d40>
   12750:      	tbnz	w9, #0x15, 0x12a4c <_Z20MTARMPMMusicGetSpeedPv+0x7d50>
   12754:      	tbnz	w9, #0x1f, 0x12a5c <_Z20MTARMPMMusicGetSpeedPv+0x7d60>
   12758:      	tbnz	w9, #0x17, 0x12a6c <_Z20MTARMPMMusicGetSpeedPv+0x7d70>
   1275c:      	tbnz	w9, #0x18, 0x12a7c <_Z20MTARMPMMusicGetSpeedPv+0x7d80>
   12760:      	tbnz	w9, #0x19, 0x12a8c <_Z20MTARMPMMusicGetSpeedPv+0x7d90>
   12764:      	tbnz	x9, #0x2b, 0x12a9c <_Z20MTARMPMMusicGetSpeedPv+0x7da0>
   12768:      	tbnz	w0, #0xb, 0x12aac <_Z20MTARMPMMusicGetSpeedPv+0x7db0>
   1276c:      	ldr	x10, [x8, #0xe98]
   12770:      	mov	w12, #0x201             // =513
   12774:      	and	x11, x9, #0x1
   12778:      	tst	x0, x12
   1277c:      	and	x12, x0, #0x10000
   12780:      	orr	x13, x10, #0x300
   12784:      	orr	x11, x11, x12
   12788:      	csel	x10, x10, x13, eq
   1278c:      	cmp	x11, #0x0
   12790:      	mov	w11, #0x8000            // =32768
   12794:      	orr	x12, x10, #0x40000
   12798:      	movk	w11, #0x400, lsl #16
   1279c:      	csel	x10, x10, x12, eq
   127a0:      	tst	x0, x11
   127a4:      	b.eq	0x127b0 <_Z20MTARMPMMusicGetSpeedPv+0x7ab4>
   127a8:      	orr	x10, x10, #0x400000
   127ac:      	str	x10, [x8, #0xe98]
   127b0:      	mov	x11, #0x4000            // =16384
   127b4:      	lsl	w12, w9, #19
   127b8:      	orr	x13, x10, #0x8000000
   127bc:      	movk	x11, #0x1, lsl #32
   127c0:      	tst	x9, x11
   127c4:      	and	x11, x12, #0x80000000
   127c8:      	csel	x10, x10, x13, eq
   127cc:      	tst	x9, #0x2
   127d0:      	and	x9, x0, #0x400000
   127d4:      	orr	x10, x10, x11
   127d8:      	lsr	x11, x0, #4
   127dc:      	ccmp	x9, #0x0, #0x4, ne
   127e0:      	orr	x9, x10, #0x1000000000
   127e4:      	csel	x9, x10, x9, eq
   127e8:      	and	x10, x11, #0x2000
   127ec:      	orr	x10, x9, x10
   127f0:      	orr	x9, x10, #0x8000000000000000
   127f4:      	str	x9, [x8, #0xe98]
   127f8:      	ret
   127fc:      	ldr	x10, [x8, #0xe98]
   12800:      	orr	x10, x10, #0x8000
   12804:      	str	x10, [x8, #0xe98]
   12808:      	tbz	w0, #0x1b, 0x126c0 <_Z20MTARMPMMusicGetSpeedPv+0x79c4>
   1280c:      	ldr	x10, [x8, #0xe98]
   12810:      	orr	x10, x10, #0x2
   12814:      	str	x10, [x8, #0xe98]
   12818:      	tbz	w9, #0x7, 0x126c4 <_Z20MTARMPMMusicGetSpeedPv+0x79c8>
   1281c:      	ldr	x10, [x8, #0xe98]
   12820:      	orr	x10, x10, #0x6
   12824:      	str	x10, [x8, #0xe98]
   12828:      	mvn	w10, w0
   1282c:      	tst	x10, #0xc0000
   12830:      	b.ne	0x126d0 <_Z20MTARMPMMusicGetSpeedPv+0x79d4>
   12834:      	ldr	x10, [x8, #0xe98]
   12838:      	orr	x10, x10, #0x20
   1283c:      	str	x10, [x8, #0xe98]
   12840:      	tbz	w0, #0x14, 0x126d4 <_Z20MTARMPMMusicGetSpeedPv+0x79d8>
   12844:      	ldr	x10, [x8, #0xe98]
   12848:      	orr	x10, x10, #0x10
   1284c:      	str	x10, [x8, #0xe98]
   12850:      	tbz	w0, #0x17, 0x126d8 <_Z20MTARMPMMusicGetSpeedPv+0x79dc>
   12854:      	ldr	x10, [x8, #0xe98]
   12858:      	orr	x10, x10, #0x8
   1285c:      	str	x10, [x8, #0xe98]
   12860:      	tbz	w0, #0x9, 0x126dc <_Z20MTARMPMMusicGetSpeedPv+0x79e0>
   12864:      	ldr	x10, [x8, #0xe98]
   12868:      	mov	w11, #0x100             // =256
   1286c:      	movk	w11, #0x1, lsl #16
   12870:      	orr	x10, x10, x11
   12874:      	str	x10, [x8, #0xe98]
   12878:      	tbz	w0, #0x18, 0x126e0 <_Z20MTARMPMMusicGetSpeedPv+0x79e4>
   1287c:      	ldr	x10, [x8, #0xe98]
   12880:      	orr	x10, x10, #0x20000
   12884:      	str	x10, [x8, #0xe98]
   12888:      	tbz	w0, #0xc, 0x126e4 <_Z20MTARMPMMusicGetSpeedPv+0x79e8>
   1288c:      	ldr	x10, [x8, #0xe98]
   12890:      	orr	x10, x10, #0x40
   12894:      	str	x10, [x8, #0xe98]
   12898:      	tbz	w0, #0x1a, 0x126e8 <_Z20MTARMPMMusicGetSpeedPv+0x79ec>
   1289c:      	ldr	x10, [x8, #0xe98]
   128a0:      	orr	x10, x10, #0x800000
   128a4:      	str	x10, [x8, #0xe98]
   128a8:      	tbz	w0, #0x3, 0x126ec <_Z20MTARMPMMusicGetSpeedPv+0x79f0>
   128ac:      	ldr	x10, [x8, #0xe98]
   128b0:      	orr	x10, x10, #0x4000
   128b4:      	str	x10, [x8, #0xe98]
   128b8:      	tbz	w0, #0x5, 0x126f0 <_Z20MTARMPMMusicGetSpeedPv+0x79f4>
   128bc:      	ldr	x10, [x8, #0xe98]
   128c0:      	orr	x10, x10, #0x800
   128c4:      	str	x10, [x8, #0xe98]
   128c8:      	tbz	w0, #0x6, 0x126f4 <_Z20MTARMPMMusicGetSpeedPv+0x79f8>
   128cc:      	ldr	x10, [x8, #0xe98]
   128d0:      	orr	x10, x10, #0x1000
   128d4:      	str	x10, [x8, #0xe98]
   128d8:      	tbz	w0, #0xd, 0x126f8 <_Z20MTARMPMMusicGetSpeedPv+0x79fc>
   128dc:      	ldr	x10, [x8, #0xe98]
   128e0:      	orr	x10, x10, #0x100000
   128e4:      	str	x10, [x8, #0xe98]
   128e8:      	tbz	w0, #0xe, 0x126fc <_Z20MTARMPMMusicGetSpeedPv+0x7a00>
   128ec:      	ldr	x10, [x8, #0xe98]
   128f0:      	orr	x10, x10, #0x200000
   128f4:      	str	x10, [x8, #0xe98]
   128f8:      	tbz	w0, #0x1d, 0x12700 <_Z20MTARMPMMusicGetSpeedPv+0x7a04>
   128fc:      	ldr	x10, [x8, #0xe98]
   12900:      	orr	x10, x10, #0x400000000000
   12904:      	str	x10, [x8, #0xe98]
   12908:      	tbz	w0, #0x1c, 0x12704 <_Z20MTARMPMMusicGetSpeedPv+0x7a08>
   1290c:      	ldr	x10, [x8, #0xe98]
   12910:      	orr	x10, x10, #0x2000000000000
   12914:      	str	x10, [x8, #0xe98]
   12918:      	tbz	w9, #0x12, 0x12708 <_Z20MTARMPMMusicGetSpeedPv+0x7a0c>
   1291c:      	ldr	x10, [x8, #0xe98]
   12920:      	orr	x10, x10, #0x180000000000
   12924:      	str	x10, [x8, #0xe98]
   12928:      	tbz	w9, #0x16, 0x1270c <_Z20MTARMPMMusicGetSpeedPv+0x7a10>
   1292c:      	ldr	x10, [x8, #0xe98]
   12930:      	orr	x10, x10, #0x380000000000
   12934:      	str	x10, [x8, #0xe98]
   12938:      	tbz	w9, #0x2, 0x12710 <_Z20MTARMPMMusicGetSpeedPv+0x7a14>
   1293c:      	ldr	x10, [x8, #0xe98]
   12940:      	orr	x10, x10, #0x2000000000
   12944:      	str	x10, [x8, #0xe98]
   12948:      	tbz	w9, #0x3, 0x12714 <_Z20MTARMPMMusicGetSpeedPv+0x7a18>
   1294c:      	ldr	x10, [x8, #0xe98]
   12950:      	orr	x10, x10, #0x6000000000
   12954:      	str	x10, [x8, #0xe98]
   12958:      	tbz	w9, #0x4, 0x12718 <_Z20MTARMPMMusicGetSpeedPv+0x7a1c>
   1295c:      	ldr	x10, [x8, #0xe98]
   12960:      	orr	x10, x10, #0x8000000000
   12964:      	str	x10, [x8, #0xe98]
   12968:      	tbz	w9, #0x5, 0x1271c <_Z20MTARMPMMusicGetSpeedPv+0x7a20>
   1296c:      	ldr	x10, [x8, #0xe98]
   12970:      	orr	x10, x10, #0x10000000000
   12974:      	str	x10, [x8, #0xe98]
   12978:      	tbz	w9, #0x6, 0x12720 <_Z20MTARMPMMusicGetSpeedPv+0x7a24>
   1297c:      	ldr	x10, [x8, #0xe98]
   12980:      	orr	x10, x10, #0x20000000000
   12984:      	str	x10, [x8, #0xe98]
   12988:      	tbz	w9, #0x0, 0x12724 <_Z20MTARMPMMusicGetSpeedPv+0x7a28>
   1298c:      	ldr	x10, [x8, #0xe98]
   12990:      	orr	x10, x10, #0x80000
   12994:      	str	x10, [x8, #0xe98]
   12998:      	tbz	w0, #0x8, 0x12728 <_Z20MTARMPMMusicGetSpeedPv+0x7a2c>
   1299c:      	ldr	x10, [x8, #0xe98]
   129a0:      	orr	x10, x10, #0x80
   129a4:      	str	x10, [x8, #0xe98]
   129a8:      	tbz	w9, #0x10, 0x1272c <_Z20MTARMPMMusicGetSpeedPv+0x7a30>
   129ac:      	ldr	x10, [x8, #0xe98]
   129b0:      	orr	x10, x10, #0x1
   129b4:      	str	x10, [x8, #0xe98]
   129b8:      	tbz	w9, #0xd, 0x12730 <_Z20MTARMPMMusicGetSpeedPv+0x7a34>
   129bc:      	ldr	x10, [x8, #0xe98]
   129c0:      	orr	x10, x10, #0x4000000
   129c4:      	str	x10, [x8, #0xe98]
   129c8:      	tbz	x9, #0x20, 0x12734 <_Z20MTARMPMMusicGetSpeedPv+0x7a38>
   129cc:      	ldr	x10, [x8, #0xe98]
   129d0:      	orr	x10, x10, #0x10000000
   129d4:      	str	x10, [x8, #0xe98]
   129d8:      	tbz	x9, #0x21, 0x12738 <_Z20MTARMPMMusicGetSpeedPv+0x7a3c>
   129dc:      	ldr	x10, [x8, #0xe98]
   129e0:      	orr	x10, x10, #0x100000000
   129e4:      	str	x10, [x8, #0xe98]
   129e8:      	tbz	w9, #0xf, 0x1273c <_Z20MTARMPMMusicGetSpeedPv+0x7a40>
   129ec:      	ldr	x10, [x8, #0xe98]
   129f0:      	orr	x10, x10, #0x2000000
   129f4:      	str	x10, [x8, #0xe98]
   129f8:      	tbz	w9, #0x8, 0x12740 <_Z20MTARMPMMusicGetSpeedPv+0x7a44>
   129fc:      	ldr	x10, [x8, #0xe98]
   12a00:      	orr	x10, x10, #0x1000000
   12a04:      	str	x10, [x8, #0xe98]
   12a08:      	tbz	w9, #0x9, 0x12744 <_Z20MTARMPMMusicGetSpeedPv+0x7a48>
   12a0c:      	ldr	x10, [x8, #0xe98]
   12a10:      	orr	x10, x10, #0x200000000
   12a14:      	str	x10, [x8, #0xe98]
   12a18:      	tbz	w9, #0xa, 0x12748 <_Z20MTARMPMMusicGetSpeedPv+0x7a4c>
   12a1c:      	ldr	x10, [x8, #0xe98]
   12a20:      	orr	x10, x10, #0x400000000
   12a24:      	str	x10, [x8, #0xe98]
   12a28:      	tbz	w9, #0xb, 0x1274c <_Z20MTARMPMMusicGetSpeedPv+0x7a50>
   12a2c:      	ldr	x10, [x8, #0xe98]
   12a30:      	orr	x10, x10, #0x800000000
   12a34:      	str	x10, [x8, #0xe98]
   12a38:      	tbz	w9, #0x11, 0x12750 <_Z20MTARMPMMusicGetSpeedPv+0x7a54>
   12a3c:      	ldr	x10, [x8, #0xe98]
   12a40:      	orr	x10, x10, #0x4000000000000
   12a44:      	str	x10, [x8, #0xe98]
   12a48:      	tbz	w9, #0x15, 0x12754 <_Z20MTARMPMMusicGetSpeedPv+0x7a58>
   12a4c:      	ldr	x10, [x8, #0xe98]
   12a50:      	orr	x10, x10, #0x20000000
   12a54:      	str	x10, [x8, #0xe98]
   12a58:      	tbz	w9, #0x1f, 0x12758 <_Z20MTARMPMMusicGetSpeedPv+0x7a5c>
   12a5c:      	ldr	x10, [x8, #0xe98]
   12a60:      	orr	x10, x10, #0x40000000000000
   12a64:      	str	x10, [x8, #0xe98]
   12a68:      	tbz	w9, #0x17, 0x1275c <_Z20MTARMPMMusicGetSpeedPv+0x7a60>
   12a6c:      	ldr	x10, [x8, #0xe98]
   12a70:      	orr	x10, x10, #0x40000000000
   12a74:      	str	x10, [x8, #0xe98]
   12a78:      	tbz	w9, #0x18, 0x12760 <_Z20MTARMPMMusicGetSpeedPv+0x7a64>
   12a7c:      	ldr	x10, [x8, #0xe98]
   12a80:      	orr	x10, x10, #0x100000000000000
   12a84:      	str	x10, [x8, #0xe98]
   12a88:      	tbz	w9, #0x19, 0x12764 <_Z20MTARMPMMusicGetSpeedPv+0x7a68>
   12a8c:      	ldr	x10, [x8, #0xe98]
   12a90:      	orr	x10, x10, #0x80000000000000
   12a94:      	str	x10, [x8, #0xe98]
   12a98:      	tbz	x9, #0x2b, 0x12768 <_Z20MTARMPMMusicGetSpeedPv+0x7a6c>
   12a9c:      	ldr	x10, [x8, #0xe98]
   12aa0:      	orr	x10, x10, #0x800000000000000
   12aa4:      	str	x10, [x8, #0xe98]
   12aa8:      	tbz	w0, #0xb, 0x1276c <_Z20MTARMPMMusicGetSpeedPv+0x7a70>
   12aac:      	mrs	x9, ID_AA64PFR1_EL1
   12ab0:      	tst	x9, #0xf00
   12ab4:      	b.eq	0x12ac4 <_Z20MTARMPMMusicGetSpeedPv+0x7dc8>
   12ab8:      	ldr	x10, [x8, #0xe98]
   12abc:      	orr	x10, x10, #0x80000000000
   12ac0:      	str	x10, [x8, #0xe98]
   12ac4:      	and	x10, x9, #0xf0
   12ac8:      	cmp	x10, #0x10
   12acc:      	b.eq	0x12b18 <_Z20MTARMPMMusicGetSpeedPv+0x7e1c>
   12ad0:      	and	x9, x9, #0xf000000
   12ad4:      	mov	w10, #0x2000000         // =33554432
   12ad8:      	cmp	x9, x10
   12adc:      	b.eq	0x12b34 <_Z20MTARMPMMusicGetSpeedPv+0x7e38>
   12ae0:      	mrs	x9, ID_AA64PFR0_EL1
   12ae4:      	mvn	w10, w9
   12ae8:      	tst	x10, #0xf0000
   12aec:      	b.ne	0x12b50 <_Z20MTARMPMMusicGetSpeedPv+0x7e54>
   12af0:      	tst	x9, #0xf00000000
   12af4:      	b.eq	0x12b64 <_Z20MTARMPMMusicGetSpeedPv+0x7e68>
   12af8:      	mrs	x9, ID_AA64ZFR0_EL1
   12afc:      	and	x11, x9, #0xf
   12b00:      	ldr	x10, [x8, #0xe98]
   12b04:      	cmp	x11, #0x1
   12b08:      	b.eq	0x12b6c <_Z20MTARMPMMusicGetSpeedPv+0x7e70>
   12b0c:      	cbnz	x11, 0x12b70 <_Z20MTARMPMMusicGetSpeedPv+0x7e74>
   12b10:      	orr	x10, x10, #0x40000000
   12b14:      	b	0x12b70 <_Z20MTARMPMMusicGetSpeedPv+0x7e74>
   12b18:      	ldr	x10, [x8, #0xe98]
   12b1c:      	orr	x10, x10, #0x1000000000000
   12b20:      	str	x10, [x8, #0xe98]
   12b24:      	and	x9, x9, #0xf000000
   12b28:      	mov	w10, #0x2000000         // =33554432
   12b2c:      	cmp	x9, x10
   12b30:      	b.ne	0x12ae0 <_Z20MTARMPMMusicGetSpeedPv+0x7de4>
   12b34:      	ldr	x9, [x8, #0xe98]
   12b38:      	orr	x9, x9, #0x200000000000000
   12b3c:      	str	x9, [x8, #0xe98]
   12b40:      	mrs	x9, ID_AA64PFR0_EL1
   12b44:      	mvn	w10, w9
   12b48:      	tst	x10, #0xf0000
   12b4c:      	b.eq	0x12af0 <_Z20MTARMPMMusicGetSpeedPv+0x7df4>
   12b50:      	ldr	x10, [x8, #0xe98]
   12b54:      	orr	x10, x10, #0x300
   12b58:      	str	x10, [x8, #0xe98]
   12b5c:      	tst	x9, #0xf00000000
   12b60:      	b.ne	0x12af8 <_Z20MTARMPMMusicGetSpeedPv+0x7dfc>
   12b64:      	ldr	x10, [x8, #0xe98]
   12b68:      	b	0x12b7c <_Z20MTARMPMMusicGetSpeedPv+0x7e80>
   12b6c:      	orr	x10, x10, #0x1000000000
   12b70:      	orr	x11, x10, #0x80000000
   12b74:      	tst	x9, #0xf00000
   12b78:      	csel	x10, x10, x11, eq
   12b7c:      	mrs	x9, ID_AA64ISAR0_EL1
   12b80:      	orr	x11, x10, #0x2000
   12b84:      	tst	x9, #0xf00000000
   12b88:      	csel	x10, x10, x11, eq
   12b8c:      	mrs	x9, ID_AA64ISAR1_EL1
   12b90:      	ubfx	x11, x9, #20, #4
   12b94:      	orr	x12, x10, #0x40000
   12b98:      	tst	x9, #0xf
   12b9c:      	csel	x10, x10, x12, eq
   12ba0:      	cbz	x11, 0x12bc4 <_Z20MTARMPMMusicGetSpeedPv+0x7ec8>
   12ba4:      	cmp	x11, #0x3
   12ba8:      	b.ne	0x12bc0 <_Z20MTARMPMMusicGetSpeedPv+0x7ec4>
   12bac:      	mov	x11, #0x400000          // =4194304
   12bb0:      	movk	x11, #0x400, lsl #48
   12bb4:      	orr	x10, x10, x11
   12bb8:      	str	x10, [x8, #0xe98]
   12bbc:      	b	0x12bc4 <_Z20MTARMPMMusicGetSpeedPv+0x7ec8>
   12bc0:      	orr	x10, x10, #0x400000
   12bc4:      	and	x11, x9, #0xf0000000000
   12bc8:      	mov	x12, #0x20000000000     // =2199023255552
   12bcc:      	orr	x13, x10, #0x800000000000
   12bd0:      	cmp	x11, x12
   12bd4:      	lsr	x11, x9, #60
   12bd8:      	csel	x10, x13, x10, eq
   12bdc:      	tst	x9, #0xf00000000000
   12be0:      	orr	x12, x10, #0x8000000
   12be4:      	csel	x10, x10, x12, eq
   12be8:      	cbz	x11, 0x127f0 <_Z20MTARMPMMusicGetSpeedPv+0x7af4>
   12bec:      	lsr	x9, x9, #61
   12bf0:      	cbz	x9, 0x12c14 <_Z20MTARMPMMusicGetSpeedPv+0x7f18>
   12bf4:      	cmp	x11, #0x2
   12bf8:      	mov	x9, #0x18000000000000   // =6755399441055744
   12bfc:      	mov	x11, #0x38000000000000  // =15762598695796736
   12c00:      	csel	x9, x11, x9, hi
   12c04:      	orr	x10, x10, x9
   12c08:      	orr	x9, x10, #0x8000000000000000
   12c0c:      	str	x9, [x8, #0xe98]
   12c10:      	ret
   12c14:      	orr	x10, x10, #0x8000000000000
   12c18:      	orr	x9, x10, #0x8000000000000000
   12c1c:      	str	x9, [x8, #0xe98]
   12c20:      	ret
   12c24:      	bti	c
   12c28:      	adrp	x8, 0x1f000
   12c2c:      	ldr	x8, [x8, #0xe98]
   12c30:      	cbz	x8, 0x12c38 <_Z20MTARMPMMusicGetSpeedPv+0x7f3c>
   12c34:      	ret
   12c38:      	paciasp
   12c3c:      	sub	sp, sp, #0x70
   12c40:      	stp	x30, x19, [sp, #0x60]
   12c44:      	nop
   12c48:      	adr	x0, 0x4c40
   12c4c:      	mov	x1, sp
   12c50:      	bl	0x17260 <__system_property_get@plt>
   12c54:      	cmp	w0, #0x0
   12c58:      	b.le	0x12c74 <_Z20MTARMPMMusicGetSpeedPv+0x7f78>
   12c5c:      	adrp	x1, 0x4000
   12c60:      	add	x1, x1, #0xde2
   12c64:      	mov	x0, sp
   12c68:      	mov	w2, #0xa                // =10
   12c6c:      	bl	0x17270 <strncmp@plt>
   12c70:      	cbz	w0, 0x12ca0 <_Z20MTARMPMMusicGetSpeedPv+0x7fa4>
   12c74:      	mov	w0, #0x10               // =16
   12c78:      	bl	0x17250 <getauxval@plt>
   12c7c:      	mov	x19, x0
   12c80:      	mov	w0, #0x1a               // =26
   12c84:      	bl	0x17250 <getauxval@plt>
   12c88:      	mov	w8, #0x18               // =24
   12c8c:      	str	x0, [sp, #0x10]
   12c90:      	orr	x0, x19, #0x4000000000000000
   12c94:      	mov	x1, sp
   12c98:      	stp	x8, x19, [sp]
   12c9c:      	bl	0x12688 <_Z20MTARMPMMusicGetSpeedPv+0x798c>
   12ca0:      	ldp	x30, x19, [sp, #0x60]
   12ca4:      	add	sp, sp, #0x70
   12ca8:      	autiasp
   12cac:      	ret
   12cb0:      	bti	c
   12cb4:      	adrp	x16, 0x1f000
   12cb8:      	ldrb	w16, [x16, #0xe94]
   12cbc:      	cbz	w16, 0x12cc8 <_Z20MTARMPMMusicGetSpeedPv+0x7fcc>
   12cc0:      	ldaddal	x0, x0, [x1]
   12cc4:      	ret
   12cc8:      	mov	x16, x0
   12ccc:      	ldaxr	x0, [x1]
   12cd0:      	add	x17, x0, x16
   12cd4:      	stlxr	w15, x17, [x1]
   12cd8:      	cbnz	w15, 0x12ccc <_Z20MTARMPMMusicGetSpeedPv+0x7fd0>
   12cdc:      	ret
   12ce0:      	paciasp
   12ce4:      	sub	sp, sp, #0x80
   12ce8:      	stp	x29, x30, [sp, #0x50]
   12cec:      	stp	x22, x21, [sp, #0x60]
   12cf0:      	stp	x20, x19, [sp, #0x70]
   12cf4:      	add	x29, sp, #0x50
   12cf8:      	mov	x19, x1
   12cfc:      	mov	x1, x0
   12d00:      	mov	x20, x2
   12d04:      	mov	x0, x19
   12d08:      	bl	0x12f8c <_Z20MTARMPMMusicGetSpeedPv+0x8290>
   12d0c:      	mov	x0, x19
   12d10:      	bl	0x130b0 <_Z20MTARMPMMusicGetSpeedPv+0x83b4>
   12d14:      	cbz	w0, 0x12dcc <_Z20MTARMPMMusicGetSpeedPv+0x80d0>
   12d18:      	mov	w21, #0x2               // =2
   12d1c:      	mov	w22, #0x6               // =6
   12d20:      	b	0x12d30 <_Z20MTARMPMMusicGetSpeedPv+0x8034>
   12d24:      	mov	x0, x19
   12d28:      	bl	0x130b0 <_Z20MTARMPMMusicGetSpeedPv+0x83b4>
   12d2c:      	cbz	w0, 0x12dcc <_Z20MTARMPMMusicGetSpeedPv+0x80d0>
   12d30:      	tbnz	w0, #0x1f, 0x12df8 <_Z20MTARMPMMusicGetSpeedPv+0x80fc>
   12d34:      	sub	x2, x29, #0x8
   12d38:      	mov	x0, x19
   12d3c:      	mov	w1, #-0x2               // =-2
   12d40:      	bl	0x13034 <_Z20MTARMPMMusicGetSpeedPv+0x8338>
   12d44:      	mov	x1, sp
   12d48:      	mov	x0, x19
   12d4c:      	bl	0x130c4 <_Z20MTARMPMMusicGetSpeedPv+0x83c8>
   12d50:      	cbnz	w0, 0x12df8 <_Z20MTARMPMMusicGetSpeedPv+0x80fc>
   12d54:      	ldr	x8, [sp, #0x18]
   12d58:      	cbz	x8, 0x12d24 <_Z20MTARMPMMusicGetSpeedPv+0x8028>
   12d5c:      	ldur	x9, [x29, #-0x8]
   12d60:      	ldr	x10, [x20, #0x18]
   12d64:      	mov	w0, #0x1                // =1
   12d68:      	ldr	x2, [x20]
   12d6c:      	mov	x3, x20
   12d70:      	mov	x4, x19
   12d74:      	cmp	x9, x10
   12d78:      	csel	w1, w22, w21, eq
   12d7c:      	blr	x8
   12d80:      	cmp	w0, #0x8
   12d84:      	b.ne	0x12de8 <_Z20MTARMPMMusicGetSpeedPv+0x80ec>
   12d88:      	ldur	x8, [x29, #-0x8]
   12d8c:      	ldr	x9, [x20, #0x18]
   12d90:      	cmp	x8, x9
   12d94:      	b.ne	0x12d24 <_Z20MTARMPMMusicGetSpeedPv+0x8028>
   12d98:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   12d9c:      	nop
   12da0:      	adr	x1, 0x479e
   12da4:      	ldr	x19, [x19, #0x998]
   12da8:      	adrp	x2, 0x5000
   12dac:      	add	x2, x2, #0xd7
   12db0:      	adrp	x3, 0x5000
   12db4:      	add	x3, x3, #0x544
   12db8:      	add	x0, x19, #0x130
   12dbc:      	bl	0x17280 <fprintf@plt>
   12dc0:      	add	x0, x19, #0x130
   12dc4:      	bl	0x17290 <fflush@plt>
   12dc8:      	bl	0x172a0 <abort@plt>
   12dcc:      	mov	w0, #0x5                // =5
   12dd0:      	ldp	x20, x19, [sp, #0x70]
   12dd4:      	ldp	x22, x21, [sp, #0x60]
   12dd8:      	ldp	x29, x30, [sp, #0x50]
   12ddc:      	add	sp, sp, #0x80
   12de0:      	autiasp
   12de4:      	ret
   12de8:      	cmp	w0, #0x7
   12dec:      	b.ne	0x12df8 <_Z20MTARMPMMusicGetSpeedPv+0x80fc>
   12df0:      	mov	x0, x19
   12df4:      	bl	0x13104 <_Z20MTARMPMMusicGetSpeedPv+0x8408>
   12df8:      	mov	w0, #0x2                // =2
   12dfc:      	ldp	x20, x19, [sp, #0x70]
   12e00:      	ldp	x22, x21, [sp, #0x60]
   12e04:      	ldp	x29, x30, [sp, #0x50]
   12e08:      	add	sp, sp, #0x80
   12e0c:      	autiasp
   12e10:      	ret
   12e14:      	paciasp
   12e18:      	stp	x29, x30, [sp, #-0x20]!
   12e1c:      	stp	x28, x19, [sp, #0x10]
   12e20:      	mov	x29, sp
   12e24:      	sub	sp, sp, #0x480
   12e28:      	mov	x19, x0
   12e2c:      	add	x0, sp, #0x270
   12e30:      	bl	0x16a38 <_Z20MTARMPMMusicGetSpeedPv+0xbd3c>
   12e34:      	ldr	x3, [x19, #0x10]
   12e38:      	cbnz	x3, 0x12e50 <_Z20MTARMPMMusicGetSpeedPv+0x8154>
   12e3c:      	add	x0, sp, #0x270
   12e40:      	mov	x1, sp
   12e44:      	mov	x2, x19
   12e48:      	bl	0x12ce0 <_Z20MTARMPMMusicGetSpeedPv+0x7fe4>
   12e4c:      	b	0x12e64 <_Z20MTARMPMMusicGetSpeedPv+0x8168>
   12e50:      	ldr	x4, [x19, #0x18]
   12e54:      	add	x0, sp, #0x270
   12e58:      	mov	x1, sp
   12e5c:      	mov	x2, x19
   12e60:      	bl	0x12e98 <_Z20MTARMPMMusicGetSpeedPv+0x819c>
   12e64:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   12e68:      	nop
   12e6c:      	adr	x1, 0x479e
   12e70:      	ldr	x19, [x19, #0x998]
   12e74:      	adrp	x2, 0x5000
   12e78:      	add	x2, x2, #0xc31
   12e7c:      	adrp	x3, 0x4000
   12e80:      	add	x3, x3, #0xb23
   12e84:      	add	x0, x19, #0x130
   12e88:      	bl	0x17280 <fprintf@plt>
   12e8c:      	add	x0, x19, #0x130
   12e90:      	bl	0x17290 <fflush@plt>
   12e94:      	bl	0x172a0 <abort@plt>
   12e98:      	paciasp
   12e9c:      	sub	sp, sp, #0x80
   12ea0:      	stp	x29, x30, [sp, #0x50]
   12ea4:      	stp	x22, x21, [sp, #0x60]
   12ea8:      	stp	x20, x19, [sp, #0x70]
   12eac:      	add	x29, sp, #0x50
   12eb0:      	mov	x21, x1
   12eb4:      	mov	x1, x0
   12eb8:      	mov	x20, x4
   12ebc:      	mov	x0, x21
   12ec0:      	mov	x19, x3
   12ec4:      	mov	x22, x2
   12ec8:      	bl	0x12f8c <_Z20MTARMPMMusicGetSpeedPv+0x8290>
   12ecc:      	mov	x0, x21
   12ed0:      	bl	0x130b0 <_Z20MTARMPMMusicGetSpeedPv+0x83b4>
   12ed4:      	cmp	w0, #0x1
   12ed8:      	b.ge	0x12f20 <_Z20MTARMPMMusicGetSpeedPv+0x8224>
   12edc:      	ldr	x2, [x22]
   12ee0:      	mov	w0, #0x1                // =1
   12ee4:      	mov	w1, #0x1a               // =26
   12ee8:      	mov	x3, x22
   12eec:      	mov	x4, x21
   12ef0:      	mov	x5, x20
   12ef4:      	blr	x19
   12ef8:      	ldp	x20, x19, [sp, #0x70]
   12efc:      	ldp	x22, x21, [sp, #0x60]
   12f00:      	ldp	x29, x30, [sp, #0x50]
   12f04:      	add	sp, sp, #0x80
   12f08:      	autiasp
   12f0c:      	ret
   12f10:      	mov	x0, x21
   12f14:      	bl	0x130b0 <_Z20MTARMPMMusicGetSpeedPv+0x83b4>
   12f18:      	cmp	w0, #0x0
   12f1c:      	b.le	0x12edc <_Z20MTARMPMMusicGetSpeedPv+0x81e0>
   12f20:      	add	x1, sp, #0x8
   12f24:      	mov	x0, x21
   12f28:      	bl	0x130c4 <_Z20MTARMPMMusicGetSpeedPv+0x83c8>
   12f2c:      	cbnz	w0, 0x12ef8 <_Z20MTARMPMMusicGetSpeedPv+0x81fc>
   12f30:      	ldr	x2, [x22]
   12f34:      	mov	w0, #0x1                // =1
   12f38:      	mov	w1, #0xa                // =10
   12f3c:      	mov	x3, x22
   12f40:      	mov	x4, x21
   12f44:      	mov	x5, x20
   12f48:      	blr	x19
   12f4c:      	cbnz	w0, 0x12ef8 <_Z20MTARMPMMusicGetSpeedPv+0x81fc>
   12f50:      	ldr	x8, [sp, #0x20]
   12f54:      	cbz	x8, 0x12f10 <_Z20MTARMPMMusicGetSpeedPv+0x8214>
   12f58:      	ldr	x2, [x22]
   12f5c:      	mov	w0, #0x1                // =1
   12f60:      	mov	w1, #0xa                // =10
   12f64:      	mov	x3, x22
   12f68:      	mov	x4, x21
   12f6c:      	blr	x8
   12f70:      	cmp	w0, #0x8
   12f74:      	b.eq	0x12f10 <_Z20MTARMPMMusicGetSpeedPv+0x8214>
   12f78:      	cmp	w0, #0x7
   12f7c:      	b.ne	0x12ef8 <_Z20MTARMPMMusicGetSpeedPv+0x81fc>
   12f80:      	mov	x0, x21
   12f84:      	bl	0x13104 <_Z20MTARMPMMusicGetSpeedPv+0x8408>
   12f88:      	b	0x12f10 <_Z20MTARMPMMusicGetSpeedPv+0x8214>
   12f8c:      	paciasp
   12f90:      	stp	x29, x30, [sp, #-0x20]!
   12f94:      	stp	x20, x19, [sp, #0x10]
   12f98:      	mov	x29, sp
   12f9c:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   12fa0:      	add	x8, x8, #0x6a0
   12fa4:      	nop
   12fa8:      	adr	x9, 0x1fea0 <__bss_start+0xb8>
   12fac:      	mov	w2, #0x110              // =272
   12fb0:      	mov	x20, x1
   12fb4:      	mov	x19, x0
   12fb8:      	stp	x8, x9, [x0], #0x10
   12fbc:      	bl	0x17240 <memcpy@plt>
   12fc0:      	ldp	q1, q0, [x20, #0x130]
   12fc4:      	add	x8, x19, #0x220
   12fc8:      	ldp	q3, q2, [x20, #0x110]
   12fcc:      	mov	x0, x19
   12fd0:      	mov	w1, wzr
   12fd4:      	stp	q1, q0, [x19, #0x140]
   12fd8:      	stp	q3, q2, [x19, #0x120]
   12fdc:      	ldp	q1, q0, [x20, #0x170]
   12fe0:      	ldp	q3, q2, [x20, #0x150]
   12fe4:      	stp	q1, q0, [x19, #0x180]
   12fe8:      	stp	q3, q2, [x19, #0x160]
   12fec:      	ldp	q1, q0, [x20, #0x1b0]
   12ff0:      	ldp	q3, q2, [x20, #0x190]
   12ff4:      	stp	q1, q0, [x19, #0x1c0]
   12ff8:      	stp	q3, q2, [x19, #0x1a0]
   12ffc:      	movi	v2.2d, #0000000000000000
   13000:      	ldp	q1, q0, [x20, #0x1f0]
   13004:      	ldp	q4, q3, [x20, #0x1d0]
   13008:      	stp	q1, q0, [x19, #0x200]
   1300c:      	stp	q4, q3, [x19, #0x1e0]
   13010:      	stur	q2, [x8, #0x3b]
   13014:      	stp	q2, q2, [x19, #0x220]
   13018:      	stp	q2, q2, [x19, #0x240]
   1301c:      	bl	0x13954 <_Z20MTARMPMMusicGetSpeedPv+0x8c58>
   13020:      	mov	w0, wzr
   13024:      	ldp	x20, x19, [sp, #0x10]
   13028:      	ldp	x29, x30, [sp], #0x20
   1302c:      	autiasp
   13030:      	ret
   13034:      	paciasp
   13038:      	stp	x29, x30, [sp, #-0x30]!
   1303c:      	str	x21, [sp, #0x10]
   13040:      	stp	x20, x19, [sp, #0x20]
   13044:      	mov	x29, sp
   13048:      	ldr	x8, [x0]
   1304c:      	mov	x19, x2
   13050:      	mov	x20, x0
   13054:      	mov	w21, w1
   13058:      	ldr	x8, [x8, #0x10]
   1305c:      	blr	x8
   13060:      	tbz	w0, #0x0, 0x13098 <_Z20MTARMPMMusicGetSpeedPv+0x839c>
   13064:      	ldr	x8, [x20]
   13068:      	mov	x0, x20
   1306c:      	mov	w1, w21
   13070:      	ldr	x8, [x8, #0x18]
   13074:      	blr	x8
   13078:      	mov	x8, x0
   1307c:      	mov	w0, wzr
   13080:      	str	x8, [x19]
   13084:      	ldp	x20, x19, [sp, #0x20]
   13088:      	ldr	x21, [sp, #0x10]
   1308c:      	ldp	x29, x30, [sp], #0x30
   13090:      	autiasp
   13094:      	ret
   13098:      	mov	w0, #-0x198e            // =-6542
   1309c:      	ldp	x20, x19, [sp, #0x20]
   130a0:      	ldr	x21, [sp, #0x10]
   130a4:      	ldp	x29, x30, [sp], #0x30
   130a8:      	autiasp
   130ac:      	ret
   130b0:      	bti	c
   130b4:      	ldr	x8, [x0]
   130b8:      	mov	w1, #0x1                // =1
   130bc:      	ldr	x16, [x8, #0x40]
   130c0:      	br	x16
   130c4:      	paciasp
   130c8:      	stp	x29, x30, [sp, #-0x20]!
   130cc:      	str	x19, [sp, #0x10]
   130d0:      	mov	x29, sp
   130d4:      	ldr	x8, [x0]
   130d8:      	mov	x19, x1
   130dc:      	ldr	x8, [x8, #0x48]
   130e0:      	blr	x8
   130e4:      	ldr	x8, [x19, #0x8]
   130e8:      	cmp	x8, #0x0
   130ec:      	mov	w8, #-0x1995            // =-6549
   130f0:      	csel	w0, w8, wzr, eq
   130f4:      	ldr	x19, [sp, #0x10]
   130f8:      	ldp	x29, x30, [sp], #0x20
   130fc:      	autiasp
   13100:      	ret
   13104:      	paciasp
   13108:      	stp	x29, x30, [sp, #-0x10]!
   1310c:      	mov	x29, sp
   13110:      	ldr	x8, [x0]
   13114:      	ldr	x8, [x8, #0x50]
   13118:      	blr	x8
   1311c:      	mov	w0, #-0x198c            // =-6540
   13120:      	ldp	x29, x30, [sp], #0x10
   13124:      	autiasp
   13128:      	ret
   1312c:      	paciasp
   13130:      	stp	x29, x30, [sp, #-0x60]!
   13134:      	str	x27, [sp, #0x10]
   13138:      	stp	x26, x25, [sp, #0x20]
   1313c:      	stp	x24, x23, [sp, #0x30]
   13140:      	stp	x22, x21, [sp, #0x40]
   13144:      	stp	x20, x19, [sp, #0x50]
   13148:      	mov	x29, sp
   1314c:      	mov	x23, x1
   13150:      	mov	x20, x3
   13154:      	mov	x19, x2
   13158:      	ldr	w22, [x23], #0x4
   1315c:      	mov	x21, x0
   13160:      	cmn	w22, #0x1
   13164:      	b.eq	0x13198 <_Z20MTARMPMMusicGetSpeedPv+0x849c>
   13168:      	cbz	x22, 0x131a4 <_Z20MTARMPMMusicGetSpeedPv+0x84a8>
   1316c:      	ldr	w8, [x23]
   13170:      	cbz	w8, 0x131b0 <_Z20MTARMPMMusicGetSpeedPv+0x84b4>
   13174:      	mov	x25, x1
   13178:      	sub	x1, x23, x8
   1317c:      	tbz	w4, #0x0, 0x131bc <_Z20MTARMPMMusicGetSpeedPv+0x84c0>
   13180:      	ldr	x8, [x20]
   13184:      	cmp	x8, x1
   13188:      	b.eq	0x131cc <_Z20MTARMPMMusicGetSpeedPv+0x84d0>
   1318c:      	adrp	x0, 0x5000
   13190:      	add	x0, x0, #0xcd9
   13194:      	b	0x1329c <_Z20MTARMPMMusicGetSpeedPv+0x85a0>
   13198:      	ldur	x22, [x1, #0x4]
   1319c:      	add	x23, x1, #0xc
   131a0:      	cbnz	x22, 0x1316c <_Z20MTARMPMMusicGetSpeedPv+0x8470>
   131a4:      	adrp	x0, 0x4000
   131a8:      	add	x0, x0, #0xce2
   131ac:      	b	0x1329c <_Z20MTARMPMMusicGetSpeedPv+0x85a0>
   131b0:      	adrp	x0, 0x5000
   131b4:      	add	x0, x0, #0x2a1
   131b8:      	b	0x1329c <_Z20MTARMPMMusicGetSpeedPv+0x85a0>
   131bc:      	mov	x0, x21
   131c0:      	mov	x2, x20
   131c4:      	bl	0x132bc <_Z20MTARMPMMusicGetSpeedPv+0x85c0>
   131c8:      	cbnz	x0, 0x1329c <_Z20MTARMPMMusicGetSpeedPv+0x85a0>
   131cc:      	ldrb	w3, [x20, #0x18]
   131d0:      	add	x22, x23, x22
   131d4:      	add	x8, x23, #0x4
   131d8:      	add	x1, x29, #0x18
   131dc:      	mov	x0, x21
   131e0:      	mov	x2, x22
   131e4:      	mov	x4, xzr
   131e8:      	str	x8, [x29, #0x18]
   131ec:      	bl	0x15114 <_Z20MTARMPMMusicGetSpeedPv+0xa418>
   131f0:      	ldrb	w8, [x20, #0x18]
   131f4:      	mov	x23, x0
   131f8:      	add	x1, x29, #0x18
   131fc:      	mov	x0, x21
   13200:      	mov	x2, x22
   13204:      	mov	x4, xzr
   13208:      	and	w3, w8, #0xf
   1320c:      	bl	0x15114 <_Z20MTARMPMMusicGetSpeedPv+0xa418>
   13210:      	ldrb	w8, [x20, #0x31]
   13214:      	mov	x24, x0
   13218:      	str	xzr, [x19, #0x28]
   1321c:      	cbz	w8, 0x13280 <_Z20MTARMPMMusicGetSpeedPv+0x8584>
   13220:      	add	x0, x29, #0x18
   13224:      	mov	x1, x22
   13228:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   1322c:      	ldrb	w8, [x20, #0x19]
   13230:      	ldr	x27, [x29, #0x18]
   13234:      	cmp	w8, #0xff
   13238:      	add	x26, x27, x0
   1323c:      	b.eq	0x13284 <_Z20MTARMPMMusicGetSpeedPv+0x8588>
   13240:      	add	x1, x29, #0x18
   13244:      	and	w3, w8, #0xf
   13248:      	mov	x0, x21
   1324c:      	mov	x2, x22
   13250:      	mov	x4, xzr
   13254:      	bl	0x15114 <_Z20MTARMPMMusicGetSpeedPv+0xa418>
   13258:      	cbz	x0, 0x13284 <_Z20MTARMPMMusicGetSpeedPv+0x8588>
   1325c:      	ldrb	w3, [x20, #0x19]
   13260:      	add	x1, x29, #0x18
   13264:      	mov	x0, x21
   13268:      	mov	x2, x22
   1326c:      	mov	x4, xzr
   13270:      	str	x27, [x29, #0x18]
   13274:      	bl	0x15114 <_Z20MTARMPMMusicGetSpeedPv+0xa418>
   13278:      	str	x0, [x19, #0x28]
   1327c:      	b	0x13284 <_Z20MTARMPMMusicGetSpeedPv+0x8588>
   13280:      	ldr	x26, [x29, #0x18]
   13284:      	sub	x8, x22, x25
   13288:      	mov	x0, xzr
   1328c:      	stp	x26, x23, [x19, #0x10]
   13290:      	stp	x25, x8, [x19]
   13294:      	add	x8, x24, x23
   13298:      	str	x8, [x19, #0x20]
   1329c:      	ldp	x20, x19, [sp, #0x50]
   132a0:      	ldr	x27, [sp, #0x10]
   132a4:      	ldp	x22, x21, [sp, #0x40]
   132a8:      	ldp	x24, x23, [sp, #0x30]
   132ac:      	ldp	x26, x25, [sp, #0x20]
   132b0:      	ldp	x29, x30, [sp], #0x60
   132b4:      	autiasp
   132b8:      	ret
   132bc:      	paciasp
   132c0:      	sub	sp, sp, #0x50
   132c4:      	stp	x29, x30, [sp, #0x10]
   132c8:      	stp	x24, x23, [sp, #0x20]
   132cc:      	stp	x22, x21, [sp, #0x30]
   132d0:      	stp	x20, x19, [sp, #0x40]
   132d4:      	add	x29, sp, #0x10
   132d8:      	movi	d0, #0x00ff000000ff00
   132dc:      	sturh	wzr, [x2, #0x33]
   132e0:      	mov	x8, x1
   132e4:      	stp	xzr, xzr, [x2, #0x20]
   132e8:      	mov	x19, x2
   132ec:      	mov	x20, x1
   132f0:      	strh	wzr, [x2, #0x30]
   132f4:      	mov	x21, x0
   132f8:      	str	x1, [x2]
   132fc:      	str	s0, [x2, #0x18]
   13300:      	ldr	w9, [x8], #0x4
   13304:      	cmn	w9, #0x1
   13308:      	b.eq	0x13328 <_Z20MTARMPMMusicGetSpeedPv+0x862c>
   1330c:      	add	x22, x8, x9
   13310:      	cbz	x9, 0x13338 <_Z20MTARMPMMusicGetSpeedPv+0x863c>
   13314:      	ldr	w9, [x8]
   13318:      	cbz	w9, 0x13340 <_Z20MTARMPMMusicGetSpeedPv+0x8644>
   1331c:      	adrp	x0, 0x5000
   13320:      	add	x0, x0, #0xc84
   13324:      	b	0x13534 <_Z20MTARMPMMusicGetSpeedPv+0x8838>
   13328:      	ldur	x9, [x20, #0x4]
   1332c:      	add	x8, x20, #0xc
   13330:      	add	x22, x9, x8
   13334:      	cbnz	x9, 0x13314 <_Z20MTARMPMMusicGetSpeedPv+0x8618>
   13338:      	mov	x0, xzr
   1333c:      	b	0x13534 <_Z20MTARMPMMusicGetSpeedPv+0x8838>
   13340:      	ldrb	w24, [x8, #0x4]
   13344:      	and	w9, w24, #0xfffffffd
   13348:      	cmp	w9, #0x1
   1334c:      	b.ne	0x133f8 <_Z20MTARMPMMusicGetSpeedPv+0x86fc>
   13350:      	add	x23, x8, #0x5
   13354:      	mov	x8, x23
   13358:      	ldrb	w9, [x8], #0x1
   1335c:      	cbnz	w9, 0x13358 <_Z20MTARMPMMusicGetSpeedPv+0x865c>
   13360:      	add	x0, sp, #0x8
   13364:      	mov	x1, x22
   13368:      	str	x8, [sp, #0x8]
   1336c:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   13370:      	ldr	x8, [sp, #0x8]
   13374:      	mov	x11, xzr
   13378:      	mov	x9, xzr
   1337c:      	str	w0, [x19, #0x28]
   13380:      	mov	x10, x8
   13384:      	cmp	x10, x22
   13388:      	b.eq	0x13550 <_Z20MTARMPMMusicGetSpeedPv+0x8854>
   1338c:      	ldrb	w12, [x10], #0x1
   13390:      	add	x8, x8, #0x1
   13394:      	and	x13, x12, #0x7f
   13398:      	lsl	x13, x13, x11
   1339c:      	add	x11, x11, #0x7
   133a0:      	orr	x9, x13, x9
   133a4:      	tbnz	w12, #0x7, 0x13384 <_Z20MTARMPMMusicGetSpeedPv+0x8688>
   133a8:      	sub	w13, w11, #0x7
   133ac:      	mov	x14, #-0x1              // =-1
   133b0:      	str	x8, [sp, #0x8]
   133b4:      	cmp	w13, #0x39
   133b8:      	mov	w13, #0x3f              // =63
   133bc:      	lsl	x11, x14, x11
   133c0:      	ccmp	w12, w13, #0x0, lo
   133c4:      	csel	w11, w11, wzr, hi
   133c8:      	cmp	w24, #0x1
   133cc:      	orr	w9, w9, w11
   133d0:      	str	w9, [x19, #0x2c]
   133d4:      	b.ne	0x13404 <_Z20MTARMPMMusicGetSpeedPv+0x8708>
   133d8:      	add	x8, x8, #0x1
   133dc:      	str	x8, [sp, #0x8]
   133e0:      	ldrb	w0, [x10]
   133e4:      	strb	w0, [x19, #0x32]
   133e8:      	ldrb	w8, [x23]
   133ec:      	cmp	w8, #0x7a
   133f0:      	b.eq	0x13420 <_Z20MTARMPMMusicGetSpeedPv+0x8724>
   133f4:      	b	0x13520 <_Z20MTARMPMMusicGetSpeedPv+0x8824>
   133f8:      	adrp	x0, 0x4000
   133fc:      	add	x0, x0, #0xac5
   13400:      	b	0x13534 <_Z20MTARMPMMusicGetSpeedPv+0x8838>
   13404:      	add	x0, sp, #0x8
   13408:      	mov	x1, x22
   1340c:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   13410:      	strb	w0, [x19, #0x32]
   13414:      	ldrb	w8, [x23]
   13418:      	cmp	w8, #0x7a
   1341c:      	b.ne	0x13520 <_Z20MTARMPMMusicGetSpeedPv+0x8824>
   13420:      	add	x0, sp, #0x8
   13424:      	mov	x1, x22
   13428:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   1342c:      	mov	w24, #0x1               // =1
   13430:      	b	0x1343c <_Z20MTARMPMMusicGetSpeedPv+0x8740>
   13434:      	strb	w24, [x19, #0x30]
   13438:      	add	x23, x23, #0x1
   1343c:      	ldrb	w8, [x23]
   13440:      	cmp	w8, #0x4f
   13444:      	b.le	0x13478 <_Z20MTARMPMMusicGetSpeedPv+0x877c>
   13448:      	cmp	w8, #0x52
   1344c:      	b.gt	0x134a8 <_Z20MTARMPMMusicGetSpeedPv+0x87ac>
   13450:      	cmp	w8, #0x50
   13454:      	b.eq	0x134e4 <_Z20MTARMPMMusicGetSpeedPv+0x87e8>
   13458:      	cmp	w8, #0x52
   1345c:      	b.ne	0x134dc <_Z20MTARMPMMusicGetSpeedPv+0x87e0>
   13460:      	ldr	x8, [sp, #0x8]
   13464:      	add	x23, x23, #0x1
   13468:      	ldrb	w9, [x8], #0x1
   1346c:      	str	x8, [sp, #0x8]
   13470:      	strb	w9, [x19, #0x18]
   13474:      	b	0x1343c <_Z20MTARMPMMusicGetSpeedPv+0x8740>
   13478:      	cmp	w8, #0x46
   1347c:      	b.le	0x134c4 <_Z20MTARMPMMusicGetSpeedPv+0x87c8>
   13480:      	cmp	w8, #0x47
   13484:      	b.eq	0x134d8 <_Z20MTARMPMMusicGetSpeedPv+0x87dc>
   13488:      	cmp	w8, #0x4c
   1348c:      	b.ne	0x134dc <_Z20MTARMPMMusicGetSpeedPv+0x87e0>
   13490:      	ldr	x8, [sp, #0x8]
   13494:      	add	x23, x23, #0x1
   13498:      	ldrb	w9, [x8], #0x1
   1349c:      	str	x8, [sp, #0x8]
   134a0:      	strb	w9, [x19, #0x19]
   134a4:      	b	0x1343c <_Z20MTARMPMMusicGetSpeedPv+0x8740>
   134a8:      	cmp	w8, #0x53
   134ac:      	b.eq	0x13434 <_Z20MTARMPMMusicGetSpeedPv+0x8738>
   134b0:      	cmp	w8, #0x7a
   134b4:      	b.ne	0x134dc <_Z20MTARMPMMusicGetSpeedPv+0x87e0>
   134b8:      	strb	w24, [x19, #0x31]
   134bc:      	add	x23, x23, #0x1
   134c0:      	b	0x1343c <_Z20MTARMPMMusicGetSpeedPv+0x8740>
   134c4:      	cmp	w8, #0x42
   134c8:      	b.ne	0x1351c <_Z20MTARMPMMusicGetSpeedPv+0x8820>
   134cc:      	strb	w24, [x19, #0x33]
   134d0:      	add	x23, x23, #0x1
   134d4:      	b	0x1343c <_Z20MTARMPMMusicGetSpeedPv+0x8740>
   134d8:      	strb	w24, [x19, #0x34]
   134dc:      	add	x23, x23, #0x1
   134e0:      	b	0x1343c <_Z20MTARMPMMusicGetSpeedPv+0x8740>
   134e4:      	ldr	x8, [sp, #0x8]
   134e8:      	add	x1, sp, #0x8
   134ec:      	mov	x0, x21
   134f0:      	mov	x2, x22
   134f4:      	mov	x4, xzr
   134f8:      	ldrb	w3, [x8], #0x1
   134fc:      	str	x8, [sp, #0x8]
   13500:      	sub	w8, w8, w20
   13504:      	strb	w3, [x19, #0x1a]
   13508:      	strb	w8, [x19, #0x1b]
   1350c:      	bl	0x15114 <_Z20MTARMPMMusicGetSpeedPv+0xa418>
   13510:      	str	x0, [x19, #0x20]
   13514:      	add	x23, x23, #0x1
   13518:      	b	0x1343c <_Z20MTARMPMMusicGetSpeedPv+0x8740>
   1351c:      	cbnz	w8, 0x134dc <_Z20MTARMPMMusicGetSpeedPv+0x87e0>
   13520:      	ldr	x8, [x19]
   13524:      	ldr	x9, [sp, #0x8]
   13528:      	mov	x0, xzr
   1352c:      	sub	x8, x22, x8
   13530:      	stp	x8, x9, [x19, #0x8]
   13534:      	ldp	x20, x19, [sp, #0x40]
   13538:      	ldp	x22, x21, [sp, #0x30]
   1353c:      	ldp	x24, x23, [sp, #0x20]
   13540:      	ldp	x29, x30, [sp, #0x10]
   13544:      	add	sp, sp, #0x50
   13548:      	autiasp
   1354c:      	ret
   13550:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   13554:      	nop
   13558:      	adr	x1, 0x479e
   1355c:      	ldr	x19, [x19, #0x998]
   13560:      	adrp	x2, 0x5000
   13564:      	add	x2, x2, #0x4c8
   13568:      	adrp	x3, 0x4000
   1356c:      	add	x3, x3, #0xf20
   13570:      	add	x0, x19, #0x130
   13574:      	bl	0x17280 <fprintf@plt>
   13578:      	add	x0, x19, #0x130
   1357c:      	bl	0x17290 <fflush@plt>
   13580:      	bl	0x172a0 <abort@plt>
   13584:      	bti	c
   13588:      	ret
   1358c:      	bti	c
   13590:      	ret
   13594:      	bti	c
   13598:      	cmn	w1, #0x3
   1359c:      	b.ls	0x135a8 <_Z20MTARMPMMusicGetSpeedPv+0x88ac>
   135a0:      	mov	w0, #0x1                // =1
   135a4:      	ret
   135a8:      	cmp	w1, #0x5f
   135ac:      	b.ls	0x135b8 <_Z20MTARMPMMusicGetSpeedPv+0x88bc>
   135b0:      	mov	w0, wzr
   135b4:      	ret
   135b8:      	cmp	w1, #0x22
   135bc:      	b.ne	0x135c8 <_Z20MTARMPMMusicGetSpeedPv+0x88cc>
   135c0:      	mov	w0, #0x1                // =1
   135c4:      	ret
   135c8:      	sub	w8, w1, #0x40
   135cc:      	cmn	w8, #0x1f
   135d0:      	cset	w0, lo
   135d4:      	ret
   135d8:      	bti	c
   135dc:      	cmp	w1, #0x1d
   135e0:      	b.le	0x13600 <_Z20MTARMPMMusicGetSpeedPv+0x8904>
   135e4:      	cmp	w1, #0x1f
   135e8:      	b.gt	0x13624 <_Z20MTARMPMMusicGetSpeedPv+0x8928>
   135ec:      	cmp	w1, #0x1e
   135f0:      	b.eq	0x13664 <_Z20MTARMPMMusicGetSpeedPv+0x8968>
   135f4:      	cmp	w1, #0x1f
   135f8:      	b.eq	0x13640 <_Z20MTARMPMMusicGetSpeedPv+0x8944>
   135fc:      	b	0x1364c <_Z20MTARMPMMusicGetSpeedPv+0x8950>
   13600:      	cmn	w1, #0x2
   13604:      	b.eq	0x13640 <_Z20MTARMPMMusicGetSpeedPv+0x8944>
   13608:      	cmn	w1, #0x1
   1360c:      	b.eq	0x13634 <_Z20MTARMPMMusicGetSpeedPv+0x8938>
   13610:      	cmp	w1, #0x1d
   13614:      	b.ne	0x1364c <_Z20MTARMPMMusicGetSpeedPv+0x8950>
   13618:      	add	x8, x0, #0xf8
   1361c:      	ldr	x0, [x8]
   13620:      	ret
   13624:      	cmp	w1, #0x22
   13628:      	b.eq	0x13670 <_Z20MTARMPMMusicGetSpeedPv+0x8974>
   1362c:      	cmp	w1, #0x20
   13630:      	b.ne	0x1364c <_Z20MTARMPMMusicGetSpeedPv+0x8950>
   13634:      	add	x8, x0, #0x110
   13638:      	ldr	x0, [x8]
   1363c:      	ret
   13640:      	add	x8, x0, #0x108
   13644:      	ldr	x0, [x8]
   13648:      	ret
   1364c:      	cmp	w1, #0x1c
   13650:      	b.hi	0x1367c <_Z20MTARMPMMusicGetSpeedPv+0x8980>
   13654:      	add	x8, x0, #0x10
   13658:      	add	x8, x8, w1, uxtw #3
   1365c:      	ldr	x0, [x8]
   13660:      	ret
   13664:      	add	x8, x0, #0x100
   13668:      	ldr	x0, [x8]
   1366c:      	ret
   13670:      	add	x8, x0, #0x118
   13674:      	ldr	x0, [x8]
   13678:      	ret
   1367c:      	paciasp
   13680:      	stp	x29, x30, [sp, #-0x20]!
   13684:      	str	x19, [sp, #0x10]
   13688:      	mov	x29, sp
   1368c:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   13690:      	nop
   13694:      	adr	x1, 0x479e
   13698:      	ldr	x19, [x19, #0x998]
   1369c:      	adrp	x2, 0x5000
   136a0:      	add	x2, x2, #0x28d
   136a4:      	adrp	x3, 0x4000
   136a8:      	add	x3, x3, #0xded
   136ac:      	add	x0, x19, #0x130
   136b0:      	bl	0x17280 <fprintf@plt>
   136b4:      	add	x0, x19, #0x130
   136b8:      	bl	0x17290 <fflush@plt>
   136bc:      	bl	0x172a0 <abort@plt>
   136c0:      	bti	c
   136c4:      	cmp	w1, #0x1d
   136c8:      	b.le	0x136e8 <_Z20MTARMPMMusicGetSpeedPv+0x89ec>
   136cc:      	cmp	w1, #0x1f
   136d0:      	b.gt	0x1370c <_Z20MTARMPMMusicGetSpeedPv+0x8a10>
   136d4:      	cmp	w1, #0x1e
   136d8:      	b.eq	0x1374c <_Z20MTARMPMMusicGetSpeedPv+0x8a50>
   136dc:      	cmp	w1, #0x1f
   136e0:      	b.eq	0x13728 <_Z20MTARMPMMusicGetSpeedPv+0x8a2c>
   136e4:      	b	0x13734 <_Z20MTARMPMMusicGetSpeedPv+0x8a38>
   136e8:      	cmn	w1, #0x2
   136ec:      	b.eq	0x13728 <_Z20MTARMPMMusicGetSpeedPv+0x8a2c>
   136f0:      	cmn	w1, #0x1
   136f4:      	b.eq	0x1371c <_Z20MTARMPMMusicGetSpeedPv+0x8a20>
   136f8:      	cmp	w1, #0x1d
   136fc:      	b.ne	0x13734 <_Z20MTARMPMMusicGetSpeedPv+0x8a38>
   13700:      	add	x8, x0, #0xf8
   13704:      	str	x2, [x8]
   13708:      	ret
   1370c:      	cmp	w1, #0x22
   13710:      	b.eq	0x13758 <_Z20MTARMPMMusicGetSpeedPv+0x8a5c>
   13714:      	cmp	w1, #0x20
   13718:      	b.ne	0x13734 <_Z20MTARMPMMusicGetSpeedPv+0x8a38>
   1371c:      	add	x8, x0, #0x110
   13720:      	str	x2, [x8]
   13724:      	ret
   13728:      	add	x8, x0, #0x108
   1372c:      	str	x2, [x8]
   13730:      	ret
   13734:      	cmp	w1, #0x1c
   13738:      	b.hi	0x13764 <_Z20MTARMPMMusicGetSpeedPv+0x8a68>
   1373c:      	add	x8, x0, #0x10
   13740:      	add	x8, x8, w1, uxtw #3
   13744:      	str	x2, [x8]
   13748:      	ret
   1374c:      	add	x8, x0, #0x100
   13750:      	str	x2, [x8]
   13754:      	ret
   13758:      	add	x8, x0, #0x118
   1375c:      	str	x2, [x8]
   13760:      	ret
   13764:      	paciasp
   13768:      	stp	x29, x30, [sp, #-0x20]!
   1376c:      	str	x19, [sp, #0x10]
   13770:      	mov	x29, sp
   13774:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   13778:      	nop
   1377c:      	adr	x1, 0x479e
   13780:      	ldr	x19, [x19, #0x998]
   13784:      	adrp	x2, 0x5000
   13788:      	add	x2, x2, #0x6e9
   1378c:      	adrp	x3, 0x4000
   13790:      	add	x3, x3, #0xded
   13794:      	add	x0, x19, #0x130
   13798:      	bl	0x17280 <fprintf@plt>
   1379c:      	add	x0, x19, #0x130
   137a0:      	bl	0x17290 <fflush@plt>
   137a4:      	bl	0x172a0 <abort@plt>
   137a8:      	bti	c
   137ac:      	and	w8, w1, #0xffffffe0
   137b0:      	cmp	w8, #0x40
   137b4:      	cset	w0, eq
   137b8:      	ret
   137bc:      	bti	c
   137c0:      	add	x8, x0, w1, sxtw #3
   137c4:      	ldur	d0, [x8, #-0xe0]
   137c8:      	ret
   137cc:      	bti	c
   137d0:      	add	x8, x0, w1, sxtw #3
   137d4:      	stur	d0, [x8, #-0xe0]
   137d8:      	ret
   137dc:      	bti	c
   137e0:      	ldrb	w8, [x0, #0x268]
   137e4:      	cbz	w8, 0x137f0 <_Z20MTARMPMMusicGetSpeedPv+0x8af4>
   137e8:      	mov	w0, wzr
   137ec:      	ret
   137f0:      	paciasp
   137f4:      	stp	x29, x30, [sp, #-0x30]!
   137f8:      	stp	x28, x21, [sp, #0x10]
   137fc:      	stp	x20, x19, [sp, #0x20]
   13800:      	mov	x29, sp
   13804:      	sub	sp, sp, #0x210
   13808:      	ldrb	w8, [x0, #0x26a]
   1380c:      	mov	x19, x0
   13810:      	cbz	w8, 0x13850 <_Z20MTARMPMMusicGetSpeedPv+0x8b54>
   13814:      	mov	x0, sp
   13818:      	mov	w1, wzr
   1381c:      	mov	w2, #0x210              // =528
   13820:      	bl	0x16e80 <memset@plt>
   13824:      	mov	x1, sp
   13828:      	mov	x0, x19
   1382c:      	bl	0x13be0 <_Z20MTARMPMMusicGetSpeedPv+0x8ee4>
   13830:      	cmp	w0, #0x1
   13834:      	b.eq	0x1388c <_Z20MTARMPMMusicGetSpeedPv+0x8b90>
   13838:      	add	sp, sp, #0x210
   1383c:      	ldp	x20, x19, [sp, #0x20]
   13840:      	ldp	x28, x21, [sp, #0x10]
   13844:      	ldp	x29, x30, [sp], #0x30
   13848:      	autiasp
   1384c:      	ret
   13850:      	ldp	x8, x20, [x19]
   13854:      	mov	x0, x19
   13858:      	mov	w21, w1
   1385c:      	mov	w1, #-0x1               // =-1
   13860:      	ldr	x8, [x8, #0x18]
   13864:      	blr	x8
   13868:      	ldr	x2, [x19, #0x258]
   1386c:      	mov	x1, x0
   13870:      	add	x3, x19, #0x10
   13874:      	add	x4, x19, #0x269
   13878:      	and	w5, w21, #0x1
   1387c:      	mov	x0, x20
   13880:      	bl	0x13d00 <_Z20MTARMPMMusicGetSpeedPv+0x9004>
   13884:      	cmp	w0, #0x1
   13888:      	b.ne	0x13838 <_Z20MTARMPMMusicGetSpeedPv+0x8b3c>
   1388c:      	ldr	x8, [x19]
   13890:      	mov	w20, w0
   13894:      	mov	x0, x19
   13898:      	mov	w1, #0x1                // =1
   1389c:      	ldr	x8, [x8, #0x68]
   138a0:      	blr	x8
   138a4:      	ldrb	w8, [x19, #0x268]
   138a8:      	mov	w0, w20
   138ac:      	cbz	w8, 0x13838 <_Z20MTARMPMMusicGetSpeedPv+0x8b3c>
   138b0:      	mov	w0, wzr
   138b4:      	add	sp, sp, #0x210
   138b8:      	ldp	x20, x19, [sp, #0x20]
   138bc:      	ldp	x28, x21, [sp, #0x10]
   138c0:      	ldp	x29, x30, [sp], #0x30
   138c4:      	autiasp
   138c8:      	ret
   138cc:      	bti	c
   138d0:      	ldrb	w8, [x0, #0x268]
   138d4:      	cbz	w8, 0x138ec <_Z20MTARMPMMusicGetSpeedPv+0x8bf0>
   138d8:      	movi	v0.2d, #0000000000000000
   138dc:      	str	xzr, [x1, #0x40]
   138e0:      	stp	q0, q0, [x1]
   138e4:      	stp	q0, q0, [x1, #0x20]
   138e8:      	ret
   138ec:      	ldr	q0, [x0, #0x220]
   138f0:      	str	q0, [x1]
   138f4:      	ldp	q2, q0, [x0, #0x240]
   138f8:      	ldr	x8, [x0, #0x260]
   138fc:      	ldr	q1, [x0, #0x230]
   13900:      	str	x8, [x1, #0x40]
   13904:      	stp	q2, q0, [x1, #0x20]
   13908:      	str	q1, [x1, #0x10]
   1390c:      	ret
   13910:      	bti	c
   13914:      	add	x0, x0, #0x10
   13918:      	b	0x169a8 <_Z20MTARMPMMusicGetSpeedPv+0xbcac>
   1391c:      	bti	c
   13920:      	ldrb	w0, [x0, #0x269]
   13924:      	ret
   13928:      	paciasp
   1392c:      	stp	x29, x30, [sp, #-0x10]!
   13930:      	mov	x29, sp
   13934:      	ldr	x8, [x0]
   13938:      	mov	w1, #-0x1               // =-1
   1393c:      	ldr	x8, [x8, #0x18]
   13940:      	blr	x8
   13944:      	mov	w0, wzr
   13948:      	ldp	x29, x30, [sp], #0x10
   1394c:      	autiasp
   13950:      	ret
   13954:      	paciasp
   13958:      	stp	x29, x30, [sp, #-0x30]!
   1395c:      	stp	x28, x21, [sp, #0x10]
   13960:      	stp	x20, x19, [sp, #0x20]
   13964:      	mov	x29, sp
   13968:      	sub	sp, sp, #0x6b0
   1396c:      	ldr	x8, [x0]
   13970:      	strb	wzr, [x0, #0x26a]
   13974:      	mov	w20, w1
   13978:      	mov	w1, #-0x1               // =-1
   1397c:      	mov	x19, x0
   13980:      	ldr	x8, [x8, #0x18]
   13984:      	blr	x8
   13988:      	cbz	x0, 0x13b98 <_Z20MTARMPMMusicGetSpeedPv+0x8e9c>
   1398c:      	ldr	x8, [x19, #0x8]
   13990:      	and	x9, x20, #0x1
   13994:      	add	x10, sp, #0x68
   13998:      	sub	x20, x0, x9
   1399c:      	nop
   139a0:      	adr	x0, 0x162f8 <_Z20MTARMPMMusicGetSpeedPv+0xb5fc>
   139a4:      	add	x1, sp, #0x98
   139a8:      	stp	x8, x10, [sp, #0x98]
   139ac:      	str	x20, [sp, #0xa8]
   139b0:      	bl	0x172d0 <dl_iterate_phdr@plt>
   139b4:      	cbz	w0, 0x139d8 <_Z20MTARMPMMusicGetSpeedPv+0x8cdc>
   139b8:      	ldr	x8, [sp, #0x78]
   139bc:      	cbz	x8, 0x139d8 <_Z20MTARMPMMusicGetSpeedPv+0x8cdc>
   139c0:      	add	x2, sp, #0x68
   139c4:      	mov	x0, x19
   139c8:      	mov	x1, x20
   139cc:      	mov	w3, wzr
   139d0:      	bl	0x16024 <_Z20MTARMPMMusicGetSpeedPv+0xb328>
   139d4:      	tbnz	w0, #0x0, 0x13b80 <_Z20MTARMPMMusicGetSpeedPv+0x8e84>
   139d8:      	nop
   139dc:      	adr	x0, 0x1fea4 <__bss_start+0xbc>
   139e0:      	bl	0x172e0 <pthread_rwlock_rdlock@plt>
   139e4:      	adrp	x8, 0x1f000
   139e8:      	adrp	x9, 0x1f000
   139ec:      	ldr	x8, [x8, #0xdd0]
   139f0:      	ldr	x9, [x9, #0xdd8]
   139f4:      	b	0x139fc <_Z20MTARMPMMusicGetSpeedPv+0x8d00>
   139f8:      	add	x8, x8, #0x20
   139fc:      	cmp	x8, x9
   13a00:      	b.hs	0x13ad0 <_Z20MTARMPMMusicGetSpeedPv+0x8dd4>
   13a04:      	ldr	x10, [x8, #0x8]
   13a08:      	cmp	x10, x20
   13a0c:      	b.hi	0x139f8 <_Z20MTARMPMMusicGetSpeedPv+0x8cfc>
   13a10:      	ldr	x10, [x8, #0x10]
   13a14:      	cmp	x10, x20
   13a18:      	b.ls	0x139f8 <_Z20MTARMPMMusicGetSpeedPv+0x8cfc>
   13a1c:      	ldr	x21, [x8, #0x18]
   13a20:      	nop
   13a24:      	adr	x0, 0x1fea4 <__bss_start+0xbc>
   13a28:      	bl	0x172c0 <pthread_rwlock_unlock@plt>
   13a2c:      	cbz	x21, 0x13adc <_Z20MTARMPMMusicGetSpeedPv+0x8de0>
   13a30:      	ldr	x0, [x19, #0x8]
   13a34:      	add	x2, sp, #0x38
   13a38:      	mov	x3, sp
   13a3c:      	mov	x1, x21
   13a40:      	mov	w4, wzr
   13a44:      	bl	0x1312c <_Z20MTARMPMMusicGetSpeedPv+0x8430>
   13a48:      	cbnz	x0, 0x13adc <_Z20MTARMPMMusicGetSpeedPv+0x8de0>
   13a4c:      	add	x0, sp, #0x98
   13a50:      	mov	w1, wzr
   13a54:      	mov	w2, #0x618              // =1560
   13a58:      	bl	0x16e80 <memset@plt>
   13a5c:      	ldr	x0, [x19, #0x8]
   13a60:      	add	x1, sp, #0x38
   13a64:      	mov	x2, sp
   13a68:      	add	x5, sp, #0x98
   13a6c:      	mov	x3, x20
   13a70:      	mov	w4, #0x4                // =4
   13a74:      	bl	0x14188 <_Z20MTARMPMMusicGetSpeedPv+0x948c>
   13a78:      	tbz	w0, #0x0, 0x13adc <_Z20MTARMPMMusicGetSpeedPv+0x8de0>
   13a7c:      	ldr	x8, [sp, #0x60]
   13a80:      	ldr	x9, [sp, #0x20]
   13a84:      	ldur	q0, [sp, #0x50]
   13a88:      	str	xzr, [x19, #0x248]
   13a8c:      	str	x8, [x19, #0x230]
   13a90:      	ldr	w8, [sp, #0xa8]
   13a94:      	str	x9, [x19, #0x238]
   13a98:      	mov	w9, #0x3000000          // =50331648
   13a9c:      	str	x8, [x19, #0x240]
   13aa0:      	str	w9, [x19, #0x250]
   13aa4:      	ldp	x8, x9, [sp, #0x38]
   13aa8:      	str	q0, [x19, #0x220]
   13aac:      	str	xzr, [x19, #0x260]
   13ab0:      	str	x8, [x19, #0x258]
   13ab4:      	str	w9, [x19, #0x254]
   13ab8:      	add	sp, sp, #0x6b0
   13abc:      	ldp	x20, x19, [sp, #0x20]
   13ac0:      	ldp	x28, x21, [sp, #0x10]
   13ac4:      	ldp	x29, x30, [sp], #0x30
   13ac8:      	autiasp
   13acc:      	ret
   13ad0:      	nop
   13ad4:      	adr	x0, 0x1fea4 <__bss_start+0xbc>
   13ad8:      	bl	0x172c0 <pthread_rwlock_unlock@plt>
   13adc:      	ldr	x8, [x19]
   13ae0:      	mov	x0, x19
   13ae4:      	mov	w1, #-0x1               // =-1
   13ae8:      	ldr	x8, [x8, #0x18]
   13aec:      	blr	x8
   13af0:      	add	x8, sp, #0x38
   13af4:      	mov	w9, #0x8                // =8
   13af8:      	mov	x20, x0
   13afc:      	stp	x8, x9, [sp, #0x98]
   13b00:      	stp	x0, x9, [sp]
   13b04:      	bl	0x172f0 <getpid@plt>
   13b08:      	mov	w1, w0
   13b0c:      	add	x2, sp, #0x98
   13b10:      	mov	x4, sp
   13b14:      	mov	w0, #0x10e              // =270
   13b18:      	mov	w3, #0x1                // =1
   13b1c:      	mov	w5, #0x1                // =1
   13b20:      	mov	w6, wzr
   13b24:      	mov	w21, #0x1               // =1
   13b28:      	bl	0x17300 <syscall@plt>
   13b2c:      	cmp	x0, #0x8
   13b30:      	b.ne	0x13bb8 <_Z20MTARMPMMusicGetSpeedPv+0x8ebc>
   13b34:      	ldr	w8, [sp, #0x38]
   13b38:      	mov	w9, #0x1168             // =4456
   13b3c:      	movk	w9, #0xd280, lsl #16
   13b40:      	cmp	w8, w9
   13b44:      	b.ne	0x13bb8 <_Z20MTARMPMMusicGetSpeedPv+0x8ebc>
   13b48:      	ldr	w8, [sp, #0x3c]
   13b4c:      	mov	w9, #0x1                // =1
   13b50:      	movk	w9, #0xd400, lsl #16
   13b54:      	cmp	w8, w9
   13b58:      	b.ne	0x13bb8 <_Z20MTARMPMMusicGetSpeedPv+0x8ebc>
   13b5c:      	movi	v0.2d, #0000000000000000
   13b60:      	add	x8, x20, #0x4
   13b64:      	str	xzr, [x19, #0x260]
   13b68:      	str	x8, [x19, #0x228]
   13b6c:      	mov	w8, #0x1                // =1
   13b70:      	str	x20, [x19, #0x220]
   13b74:      	strb	w8, [x19, #0x26a]
   13b78:      	stp	q0, q0, [x19, #0x240]
   13b7c:      	str	q0, [x19, #0x230]
   13b80:      	add	sp, sp, #0x6b0
   13b84:      	ldp	x20, x19, [sp, #0x20]
   13b88:      	ldp	x28, x21, [sp, #0x10]
   13b8c:      	ldp	x29, x30, [sp], #0x30
   13b90:      	autiasp
   13b94:      	ret
   13b98:      	mov	w8, #0x1                // =1
   13b9c:      	strb	w8, [x19, #0x268]
   13ba0:      	add	sp, sp, #0x6b0
   13ba4:      	ldp	x20, x19, [sp, #0x20]
   13ba8:      	ldp	x28, x21, [sp, #0x10]
   13bac:      	ldp	x29, x30, [sp], #0x30
   13bb0:      	autiasp
   13bb4:      	ret
   13bb8:      	strb	w21, [x19, #0x268]
   13bbc:      	add	sp, sp, #0x6b0
   13bc0:      	ldp	x20, x19, [sp, #0x20]
   13bc4:      	ldp	x28, x21, [sp, #0x10]
   13bc8:      	ldp	x29, x30, [sp], #0x30
   13bcc:      	autiasp
   13bd0:      	ret
   13bd4:      	bti	c
   13bd8:      	mov	w0, w1
   13bdc:      	b	0x16978 <_Z20MTARMPMMusicGetSpeedPv+0xbc7c>
   13be0:      	bti	c
   13be4:      	ldr	x10, [x0, #0x108]
   13be8:      	mov	w9, #0x1                // =1
   13bec:      	ldr	x11, [x10, #0x138]
   13bf0:      	str	x11, [x0, #0x10]
   13bf4:      	ldr	x11, [x10, #0x140]
   13bf8:      	str	x11, [x0, #0x18]
   13bfc:      	ldr	x11, [x10, #0x148]
   13c00:      	str	x11, [x0, #0x20]
   13c04:      	ldr	x11, [x10, #0x150]
   13c08:      	str	x11, [x0, #0x28]
   13c0c:      	ldr	x11, [x10, #0x158]
   13c10:      	str	x11, [x0, #0x30]
   13c14:      	ldr	x11, [x10, #0x160]
   13c18:      	str	x11, [x0, #0x38]
   13c1c:      	ldr	x11, [x10, #0x168]
   13c20:      	str	x11, [x0, #0x40]
   13c24:      	ldr	x11, [x10, #0x170]
   13c28:      	str	x11, [x0, #0x48]
   13c2c:      	ldr	x11, [x10, #0x178]
   13c30:      	str	x11, [x0, #0x50]
   13c34:      	ldr	x11, [x10, #0x180]
   13c38:      	str	x11, [x0, #0x58]
   13c3c:      	ldr	x11, [x10, #0x188]
   13c40:      	str	x11, [x0, #0x60]
   13c44:      	ldr	x11, [x10, #0x190]
   13c48:      	str	x11, [x0, #0x68]
   13c4c:      	ldr	x11, [x10, #0x198]
   13c50:      	str	x11, [x0, #0x70]
   13c54:      	ldr	x11, [x10, #0x1a0]
   13c58:      	str	x11, [x0, #0x78]
   13c5c:      	ldr	x11, [x10, #0x1a8]
   13c60:      	str	x11, [x0, #0x80]
   13c64:      	ldr	x11, [x10, #0x1b0]
   13c68:      	str	x11, [x0, #0x88]
   13c6c:      	ldr	x11, [x10, #0x1b8]
   13c70:      	str	x11, [x0, #0x90]
   13c74:      	ldr	x11, [x10, #0x1c0]
   13c78:      	str	x11, [x0, #0x98]
   13c7c:      	ldr	x11, [x10, #0x1c8]
   13c80:      	str	x11, [x0, #0xa0]
   13c84:      	ldr	x11, [x10, #0x1d0]
   13c88:      	str	x11, [x0, #0xa8]
   13c8c:      	ldr	x11, [x10, #0x1d8]
   13c90:      	str	x11, [x0, #0xb0]
   13c94:      	ldr	x11, [x10, #0x1e0]
   13c98:      	str	x11, [x0, #0xb8]
   13c9c:      	ldr	x11, [x10, #0x1e8]
   13ca0:      	str	x11, [x0, #0xc0]
   13ca4:      	ldr	x11, [x10, #0x1f0]
   13ca8:      	str	x11, [x0, #0xc8]
   13cac:      	ldr	x11, [x10, #0x1f8]
   13cb0:      	str	x11, [x0, #0xd0]
   13cb4:      	ldr	x11, [x10, #0x200]
   13cb8:      	str	x11, [x0, #0xd8]
   13cbc:      	ldr	x11, [x10, #0x208]
   13cc0:      	str	x11, [x0, #0xe0]
   13cc4:      	ldr	x11, [x10, #0x210]
   13cc8:      	str	x11, [x0, #0xe8]
   13ccc:      	ldr	x11, [x10, #0x218]
   13cd0:      	str	x11, [x0, #0xf0]
   13cd4:      	ldr	x11, [x10, #0x220]
   13cd8:      	str	x11, [x0, #0xf8]
   13cdc:      	ldr	x11, [x10, #0x228]
   13ce0:      	str	x11, [x0, #0x100]
   13ce4:      	ldr	x11, [x10, #0x230]
   13ce8:      	str	x11, [x0, #0x108]
   13cec:      	ldr	x10, [x10, #0x238]
   13cf0:      	strb	w9, [x0, #0x269]
   13cf4:      	str	x10, [x0, #0x110]
   13cf8:      	mov	w0, #0x1                // =1
   13cfc:      	ret
   13d00:      	paciasp
   13d04:      	stp	x29, x30, [sp, #-0x60]!
   13d08:      	stp	x28, x27, [sp, #0x10]
   13d0c:      	stp	x26, x25, [sp, #0x20]
   13d10:      	stp	x24, x23, [sp, #0x30]
   13d14:      	stp	x22, x21, [sp, #0x40]
   13d18:      	stp	x20, x19, [sp, #0x50]
   13d1c:      	mov	x29, sp
   13d20:      	sub	sp, sp, #0xb10
   13d24:      	mov	x8, x2
   13d28:      	mov	x21, x4
   13d2c:      	mov	x19, x3
   13d30:      	mov	x22, x1
   13d34:      	sub	x2, x29, #0x50
   13d38:      	sub	x3, x29, #0x88
   13d3c:      	mov	x1, x8
   13d40:      	mov	w4, wzr
   13d44:      	mov	w23, w5
   13d48:      	mov	x20, x0
   13d4c:      	bl	0x1312c <_Z20MTARMPMMusicGetSpeedPv+0x8430>
   13d50:      	cbnz	x0, 0x13e30 <_Z20MTARMPMMusicGetSpeedPv+0x9134>
   13d54:      	add	x0, sp, #0x470
   13d58:      	mov	w1, wzr
   13d5c:      	mov	w2, #0x618              // =1560
   13d60:      	bl	0x16e80 <memset@plt>
   13d64:      	sub	x1, x29, #0x50
   13d68:      	sub	x2, x29, #0x88
   13d6c:      	add	x5, sp, #0x470
   13d70:      	mov	x0, x20
   13d74:      	mov	x3, x22
   13d78:      	mov	w4, #0x4                // =4
   13d7c:      	bl	0x14188 <_Z20MTARMPMMusicGetSpeedPv+0x948c>
   13d80:      	tbz	w0, #0x0, 0x13e30 <_Z20MTARMPMMusicGetSpeedPv+0x9134>
   13d84:      	add	x1, sp, #0x470
   13d88:      	mov	x0, x20
   13d8c:      	mov	x2, x19
   13d90:      	add	x24, sp, #0x470
   13d94:      	bl	0x14dd0 <_Z20MTARMPMMusicGetSpeedPv+0xa0d4>
   13d98:      	mov	x22, x0
   13d9c:      	tbz	w23, #0x0, 0x13dc8 <_Z20MTARMPMMusicGetSpeedPv+0x90cc>
   13da0:      	ldurb	w8, [x29, #-0x54]
   13da4:      	cbz	w8, 0x13dc8 <_Z20MTARMPMMusicGetSpeedPv+0x90cc>
   13da8:      	ldr	x8, [x19, #0xf8]
   13dac:      	and	x8, x8, #0xfffffffffffffff0
   13db0:      	cmp	x8, x22
   13db4:      	b.hs	0x13dc8 <_Z20MTARMPMMusicGetSpeedPv+0x90cc>
   13db8:      	stg	x8, [x8]
   13dbc:      	add	x8, x8, #0x10
   13dc0:      	cmp	x8, x22
   13dc4:      	b.lo	0x13db8 <_Z20MTARMPMMusicGetSpeedPv+0x90bc>
   13dc8:      	add	x0, sp, #0x260
   13dcc:      	mov	x1, x19
   13dd0:      	mov	w2, #0x210              // =528
   13dd4:      	add	x25, sp, #0x260
   13dd8:      	bl	0x17240 <memcpy@plt>
   13ddc:      	add	x9, x25, #0xf8
   13de0:      	add	x8, x25, #0xe8
   13de4:      	add	x10, x19, #0xf8
   13de8:      	stp	x8, x9, [sp, #0x18]
   13dec:      	add	x9, x25, #0x100
   13df0:      	add	x8, x25, #0xf0
   13df4:      	stp	x8, x9, [sp, #0x8]
   13df8:      	add	x9, x25, #0x108
   13dfc:      	add	x8, x19, #0xe8
   13e00:      	stp	x8, x9, [sp, #0x40]
   13e04:      	add	x8, x19, #0x100
   13e08:      	mov	x26, xzr
   13e0c:      	mov	x23, xzr
   13e10:      	add	x28, x19, #0x108
   13e14:      	stp	x10, x8, [sp, #0x30]
   13e18:      	add	x8, x19, #0xf0
   13e1c:      	add	x24, x24, #0x18
   13e20:      	add	x27, sp, #0x260
   13e24:      	str	x22, [sp, #0x358]
   13e28:      	str	x8, [sp, #0x28]
   13e2c:      	b	0x13e88 <_Z20MTARMPMMusicGetSpeedPv+0x918c>
   13e30:      	mov	w0, #-0x1992            // =-6546
   13e34:      	add	sp, sp, #0xb10
   13e38:      	ldp	x20, x19, [sp, #0x50]
   13e3c:      	ldp	x22, x21, [sp, #0x40]
   13e40:      	ldp	x24, x23, [sp, #0x30]
   13e44:      	ldp	x26, x25, [sp, #0x20]
   13e48:      	ldp	x28, x27, [sp, #0x10]
   13e4c:      	ldp	x29, x30, [sp], #0x60
   13e50:      	autiasp
   13e54:      	ret
   13e58:      	ldr	x8, [x24, #0x8]
   13e5c:      	mov	x9, #-0x4000000000      // =-274877906944
   13e60:      	add	x8, x9, x8, lsl #32
   13e64:      	add	x8, x19, x8, asr #29
   13e68:      	ldr	d0, [x8, #0x110]
   13e6c:      	add	x8, x25, x26, lsl #3
   13e70:      	stur	d0, [x8, #-0xf0]
   13e74:      	add	x26, x26, #0x1
   13e78:      	add	x24, x24, #0x10
   13e7c:      	add	x27, x27, #0x8
   13e80:      	cmp	x26, #0x60
   13e84:      	b.eq	0x14048 <_Z20MTARMPMMusicGetSpeedPv+0x934c>
   13e88:      	ldr	w8, [x24]
   13e8c:      	cbz	w8, 0x13ec4 <_Z20MTARMPMMusicGetSpeedPv+0x91c8>
   13e90:      	and	w9, w26, #0x60
   13e94:      	cmp	w9, #0x40
   13e98:      	b.ne	0x13f00 <_Z20MTARMPMMusicGetSpeedPv+0x9204>
   13e9c:      	cmp	w8, #0x4
   13ea0:      	b.gt	0x13f28 <_Z20MTARMPMMusicGetSpeedPv+0x922c>
   13ea4:      	movi	d0, #0000000000000000
   13ea8:      	cmp	w8, #0x1
   13eac:      	b.eq	0x13e6c <_Z20MTARMPMMusicGetSpeedPv+0x9170>
   13eb0:      	cmp	w8, #0x2
   13eb4:      	b.ne	0x140ec <_Z20MTARMPMMusicGetSpeedPv+0x93f0>
   13eb8:      	ldr	x8, [x24, #0x8]
   13ebc:      	ldr	d0, [x8, x22]
   13ec0:      	b	0x13e6c <_Z20MTARMPMMusicGetSpeedPv+0x9170>
   13ec4:      	ldurb	w8, [x29, #-0x56]
   13ec8:      	cmp	x26, x8
   13ecc:      	b.ne	0x13e74 <_Z20MTARMPMMusicGetSpeedPv+0x9178>
   13ed0:      	cmp	w8, #0x1e
   13ed4:      	b.le	0x13fc8 <_Z20MTARMPMMusicGetSpeedPv+0x92cc>
   13ed8:      	cmp	w8, #0x22
   13edc:      	mov	x9, x28
   13ee0:      	b.eq	0x13fec <_Z20MTARMPMMusicGetSpeedPv+0x92f0>
   13ee4:      	ldr	x9, [sp, #0x38]
   13ee8:      	cmp	w8, #0x20
   13eec:      	b.eq	0x13fec <_Z20MTARMPMMusicGetSpeedPv+0x92f0>
   13ef0:      	ldr	x9, [sp, #0x30]
   13ef4:      	cmp	w8, #0x1f
   13ef8:      	b.eq	0x13fec <_Z20MTARMPMMusicGetSpeedPv+0x92f0>
   13efc:      	b	0x13fe0 <_Z20MTARMPMMusicGetSpeedPv+0x92e4>
   13f00:      	ldurb	w8, [x29, #-0x56]
   13f04:      	cmp	x26, x8
   13f08:      	b.ne	0x13f54 <_Z20MTARMPMMusicGetSpeedPv+0x9258>
   13f0c:      	mov	x0, x20
   13f10:      	mov	x1, x19
   13f14:      	mov	x2, x22
   13f18:      	mov	x3, x24
   13f1c:      	bl	0x14f04 <_Z20MTARMPMMusicGetSpeedPv+0xa208>
   13f20:      	mov	x23, x0
   13f24:      	b	0x13e74 <_Z20MTARMPMMusicGetSpeedPv+0x9178>
   13f28:      	cmp	w8, #0x5
   13f2c:      	b.eq	0x13e58 <_Z20MTARMPMMusicGetSpeedPv+0x915c>
   13f30:      	cmp	w8, #0x6
   13f34:      	b.ne	0x140ec <_Z20MTARMPMMusicGetSpeedPv+0x93f0>
   13f38:      	ldr	x0, [x24, #0x8]
   13f3c:      	mov	x1, x20
   13f40:      	mov	x2, x19
   13f44:      	mov	x3, x22
   13f48:      	bl	0x15668 <_Z20MTARMPMMusicGetSpeedPv+0xa96c>
   13f4c:      	ldr	d0, [x0]
   13f50:      	b	0x13e6c <_Z20MTARMPMMusicGetSpeedPv+0x9170>
   13f54:      	cmp	x26, #0x22
   13f58:      	b.ne	0x13f7c <_Z20MTARMPMMusicGetSpeedPv+0x9280>
   13f5c:      	mov	x0, x20
   13f60:      	mov	x1, x19
   13f64:      	mov	x2, x22
   13f68:      	mov	x3, x24
   13f6c:      	bl	0x14f04 <_Z20MTARMPMMusicGetSpeedPv+0xa208>
   13f70:      	ldr	x8, [sp, #0x48]
   13f74:      	str	x0, [x8]
   13f78:      	b	0x13e74 <_Z20MTARMPMMusicGetSpeedPv+0x9178>
   13f7c:      	sub	w8, w26, #0x40
   13f80:      	cmn	w8, #0x20
   13f84:      	b.hi	0x140e4 <_Z20MTARMPMMusicGetSpeedPv+0x93e8>
   13f88:      	mov	x0, x20
   13f8c:      	mov	x1, x19
   13f90:      	mov	x2, x22
   13f94:      	mov	x3, x24
   13f98:      	bl	0x14f04 <_Z20MTARMPMMusicGetSpeedPv+0xa208>
   13f9c:      	cmp	w26, #0x1e
   13fa0:      	b.le	0x13ff4 <_Z20MTARMPMMusicGetSpeedPv+0x92f8>
   13fa4:      	cmp	w26, #0x1f
   13fa8:      	b.eq	0x14010 <_Z20MTARMPMMusicGetSpeedPv+0x9314>
   13fac:      	cmp	w26, #0x22
   13fb0:      	b.eq	0x1401c <_Z20MTARMPMMusicGetSpeedPv+0x9320>
   13fb4:      	cmp	w26, #0x20
   13fb8:      	b.ne	0x14034 <_Z20MTARMPMMusicGetSpeedPv+0x9338>
   13fbc:      	ldr	x8, [sp, #0x10]
   13fc0:      	str	x0, [x8]
   13fc4:      	b	0x13e74 <_Z20MTARMPMMusicGetSpeedPv+0x9178>
   13fc8:      	ldr	x9, [sp, #0x40]
   13fcc:      	cmp	w8, #0x1d
   13fd0:      	b.eq	0x13fec <_Z20MTARMPMMusicGetSpeedPv+0x92f0>
   13fd4:      	ldr	x9, [sp, #0x28]
   13fd8:      	cmp	w8, #0x1e
   13fdc:      	b.eq	0x13fec <_Z20MTARMPMMusicGetSpeedPv+0x92f0>
   13fe0:      	cmp	w8, #0x1c
   13fe4:      	b.hi	0x14120 <_Z20MTARMPMMusicGetSpeedPv+0x9424>
   13fe8:      	add	x9, x19, x8, lsl #3
   13fec:      	ldr	x23, [x9]
   13ff0:      	b	0x13e74 <_Z20MTARMPMMusicGetSpeedPv+0x9178>
   13ff4:      	cmp	w26, #0x1d
   13ff8:      	b.eq	0x14028 <_Z20MTARMPMMusicGetSpeedPv+0x932c>
   13ffc:      	cmp	w26, #0x1e
   14000:      	b.ne	0x14034 <_Z20MTARMPMMusicGetSpeedPv+0x9338>
   14004:      	ldr	x8, [sp, #0x8]
   14008:      	str	x0, [x8]
   1400c:      	b	0x13e74 <_Z20MTARMPMMusicGetSpeedPv+0x9178>
   14010:      	ldr	x8, [sp, #0x20]
   14014:      	str	x0, [x8]
   14018:      	b	0x13e74 <_Z20MTARMPMMusicGetSpeedPv+0x9178>
   1401c:      	ldr	x8, [sp, #0x48]
   14020:      	str	x0, [x8]
   14024:      	b	0x13e74 <_Z20MTARMPMMusicGetSpeedPv+0x9178>
   14028:      	ldr	x8, [sp, #0x18]
   1402c:      	str	x0, [x8]
   14030:      	b	0x13e74 <_Z20MTARMPMMusicGetSpeedPv+0x9178>
   14034:      	cmp	x26, #0x1d
   14038:      	mov	x8, x27
   1403c:      	b.hs	0x14154 <_Z20MTARMPMMusicGetSpeedPv+0x9458>
   14040:      	str	x0, [x8]
   14044:      	b	0x13e74 <_Z20MTARMPMMusicGetSpeedPv+0x9178>
   14048:      	ldurb	w8, [x29, #-0x58]
   1404c:      	add	x0, sp, #0x50
   14050:      	mov	x1, x19
   14054:      	mov	w2, #0x210              // =528
   14058:      	strb	w8, [x21]
   1405c:      	bl	0x17240 <memcpy@plt>
   14060:      	add	x8, sp, #0x470
   14064:      	add	x8, x8, #0x238
   14068:      	ldr	q0, [x8]
   1406c:      	stur	q0, [x29, #-0x20]
   14070:      	ldur	w8, [x29, #-0x20]
   14074:      	cbz	w8, 0x14094 <_Z20MTARMPMMusicGetSpeedPv+0x9398>
   14078:      	add	x1, sp, #0x50
   1407c:      	sub	x3, x29, #0x20
   14080:      	mov	x0, x20
   14084:      	mov	x2, x22
   14088:      	bl	0x14f04 <_Z20MTARMPMMusicGetSpeedPv+0xa208>
   1408c:      	tbnz	w0, #0x0, 0x1409c <_Z20MTARMPMMusicGetSpeedPv+0x93a0>
   14090:      	b	0x140c8 <_Z20MTARMPMMusicGetSpeedPv+0x93cc>
   14094:      	ldur	x0, [x29, #-0x18]
   14098:      	tbz	w0, #0x0, 0x140c8 <_Z20MTARMPMMusicGetSpeedPv+0x93cc>
   1409c:      	cbz	x23, 0x140c8 <_Z20MTARMPMMusicGetSpeedPv+0x93cc>
   140a0:      	ldurb	w8, [x29, #-0x55]
   140a4:      	cbz	w8, 0x140b8 <_Z20MTARMPMMusicGetSpeedPv+0x93bc>
   140a8:      	mov	x17, x23
   140ac:      	mov	x16, x22
   140b0:      	autib1716
   140b4:      	b	0x140c4 <_Z20MTARMPMMusicGetSpeedPv+0x93c8>
   140b8:      	mov	x17, x23
   140bc:      	mov	x16, x22
   140c0:      	autia1716
   140c4:      	mov	x23, x17
   140c8:      	add	x1, sp, #0x260
   140cc:      	mov	x0, x19
   140d0:      	mov	w2, #0x210              // =528
   140d4:      	str	x23, [sp, #0x360]
   140d8:      	bl	0x17240 <memcpy@plt>
   140dc:      	mov	w0, #0x1                // =1
   140e0:      	b	0x13e34 <_Z20MTARMPMMusicGetSpeedPv+0x9138>
   140e4:      	mov	w0, #-0x198e            // =-6542
   140e8:      	b	0x13e34 <_Z20MTARMPMMusicGetSpeedPv+0x9138>
   140ec:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   140f0:      	nop
   140f4:      	adr	x1, 0x479e
   140f8:      	ldr	x19, [x19, #0x998]
   140fc:      	adrp	x2, 0x4000
   14100:      	add	x2, x2, #0x863
   14104:      	adrp	x3, 0x5000
   14108:      	add	x3, x3, #0x102
   1410c:      	add	x0, x19, #0x130
   14110:      	bl	0x17280 <fprintf@plt>
   14114:      	add	x0, x19, #0x130
   14118:      	bl	0x17290 <fflush@plt>
   1411c:      	bl	0x172a0 <abort@plt>
   14120:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   14124:      	nop
   14128:      	adr	x1, 0x479e
   1412c:      	ldr	x19, [x19, #0x998]
   14130:      	adrp	x2, 0x5000
   14134:      	add	x2, x2, #0x28d
   14138:      	adrp	x3, 0x4000
   1413c:      	add	x3, x3, #0xded
   14140:      	add	x0, x19, #0x130
   14144:      	bl	0x17280 <fprintf@plt>
   14148:      	add	x0, x19, #0x130
   1414c:      	bl	0x17290 <fflush@plt>
   14150:      	bl	0x172a0 <abort@plt>
   14154:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   14158:      	nop
   1415c:      	adr	x1, 0x479e
   14160:      	ldr	x19, [x19, #0x998]
   14164:      	adrp	x2, 0x5000
   14168:      	add	x2, x2, #0x6e9
   1416c:      	adrp	x3, 0x4000
   14170:      	add	x3, x3, #0xded
   14174:      	add	x0, x19, #0x130
   14178:      	bl	0x17280 <fprintf@plt>
   1417c:      	add	x0, x19, #0x130
   14180:      	bl	0x17290 <fflush@plt>
   14184:      	bl	0x172a0 <abort@plt>
   14188:      	paciasp
   1418c:      	stp	x29, x30, [sp, #-0x60]!
   14190:      	stp	x28, x27, [sp, #0x10]
   14194:      	stp	x26, x25, [sp, #0x20]
   14198:      	stp	x24, x23, [sp, #0x30]
   1419c:      	stp	x22, x21, [sp, #0x40]
   141a0:      	stp	x20, x19, [sp, #0x50]
   141a4:      	mov	x29, sp
   141a8:      	sub	sp, sp, #0x680
   141ac:      	ldp	x10, x8, [x2, #0x8]
   141b0:      	mov	x19, sp
   141b4:      	ldr	x9, [x2]
   141b8:      	ldp	x11, x12, [x1, #0x10]
   141bc:      	mov	x20, x5
   141c0:      	mov	w28, w4
   141c4:      	mov	x22, x2
   141c8:      	add	x9, x10, x9
   141cc:      	mov	x27, xzr
   141d0:      	nop
   141d4:      	adr	x23, 0x5f90 <_ZTSSt9bad_alloc+0x4f>
   141d8:      	stp	x8, x9, [x29, #-0x38]
   141dc:      	mov	x8, #-0x1               // =-1
   141e0:      	ldp	x9, x10, [x1]
   141e4:      	stp	x8, x11, [x29, #-0x28]
   141e8:      	stp	x0, xzr, [x19, #0x18]
   141ec:      	add	x8, x10, x9
   141f0:      	sub	x9, x3, x12
   141f4:      	stp	x8, x9, [x29, #-0x18]
   141f8:      	add	x8, x19, #0x28
   141fc:      	add	x9, x5, #0x238
   14200:      	add	x8, x8, #0x238
   14204:      	stp	x8, x9, [x19, #0x8]
   14208:      	b	0x14218 <_Z20MTARMPMMusicGetSpeedPv+0x951c>
   1420c:      	add	x27, x27, #0x18
   14210:      	cmp	x27, #0x30
   14214:      	b.eq	0x14b44 <_Z20MTARMPMMusicGetSpeedPv+0x9e48>
   14218:      	sub	x8, x29, #0x38
   1421c:      	add	x8, x8, x27
   14220:      	ldp	x9, x24, [x8]
   14224:      	ldr	x21, [x8, #0x10]
   14228:      	cmp	x9, x24
   1422c:      	stur	x9, [x29, #-0x40]
   14230:      	ccmp	x21, #0x0, #0x4, lo
   14234:      	b.eq	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   14238:      	mov	x25, xzr
   1423c:      	mov	x8, x9
   14240:      	ldrb	w10, [x8], #0x1
   14244:      	stur	x8, [x29, #-0x40]
   14248:      	cmp	w10, #0x2f
   1424c:      	b.hi	0x1483c <_Z20MTARMPMMusicGetSpeedPv+0x9b40>
   14250:      	adr	x11, 0x14260 <_Z20MTARMPMMusicGetSpeedPv+0x9564>
   14254:      	ldrh	w12, [x23, x10, lsl #1]
   14258:      	add	x11, x11, x12, lsl #2
   1425c:      	br	x11
   14260:      	bti	j
   14264:      	ldrb	w3, [x22, #0x18]
   14268:      	ldr	x0, [x19, #0x18]
   1426c:      	sub	x1, x29, #0x40
   14270:      	mov	x2, x24
   14274:      	mov	x4, xzr
   14278:      	bl	0x15114 <_Z20MTARMPMMusicGetSpeedPv+0xa418>
   1427c:      	mov	x25, x0
   14280:      	ldur	x9, [x29, #-0x40]
   14284:      	cmp	x9, x24
   14288:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   1428c:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   14290:      	bti	j
   14294:      	sub	x0, x29, #0x40
   14298:      	mov	x1, x24
   1429c:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   142a0:      	ldur	x10, [x29, #-0x40]
   142a4:      	mov	x9, xzr
   142a8:      	mov	x8, xzr
   142ac:      	mov	x12, x10
   142b0:      	cmp	x12, x24
   142b4:      	b.eq	0x14d34 <_Z20MTARMPMMusicGetSpeedPv+0xa038>
   142b8:      	ldrb	w11, [x12], #0x1
   142bc:      	add	x10, x10, #0x1
   142c0:      	and	x13, x11, #0x7f
   142c4:      	lsl	x13, x13, x9
   142c8:      	add	x9, x9, #0x7
   142cc:      	orr	x8, x13, x8
   142d0:      	tbnz	w11, #0x7, 0x142b0 <_Z20MTARMPMMusicGetSpeedPv+0x95b4>
   142d4:      	cmp	x0, #0x60
   142d8:      	stur	x10, [x29, #-0x40]
   142dc:      	b.hs	0x14c8c <_Z20MTARMPMMusicGetSpeedPv+0x9f90>
   142e0:      	sub	w10, w9, #0x7
   142e4:      	mov	x12, #-0x1              // =-1
   142e8:      	cmp	w10, #0x39
   142ec:      	mov	w10, #0x3f              // =63
   142f0:      	lsl	x9, x12, x9
   142f4:      	ccmp	w11, w10, #0x0, lo
   142f8:      	ldr	w10, [x22, #0x2c]
   142fc:      	csel	w9, w9, wzr, hi
   14300:      	orr	w8, w8, w9
   14304:      	mul	w8, w10, w8
   14308:      	stp	w0, w8, [x20]
   1430c:      	ldur	x9, [x29, #-0x40]
   14310:      	cmp	x9, x24
   14314:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   14318:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   1431c:      	bti	j
   14320:      	sub	x0, x29, #0x40
   14324:      	mov	x1, x24
   14328:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   1432c:      	cmp	x0, #0x60
   14330:      	b.hs	0x14b78 <_Z20MTARMPMMusicGetSpeedPv+0x9e7c>
   14334:      	ldur	x9, [x29, #-0x40]
   14338:      	mov	x10, xzr
   1433c:      	mov	x8, xzr
   14340:      	mov	x12, x9
   14344:      	cmp	x12, x24
   14348:      	b.eq	0x14d9c <_Z20MTARMPMMusicGetSpeedPv+0xa0a0>
   1434c:      	ldrb	w11, [x12], #0x1
   14350:      	add	x9, x9, #0x1
   14354:      	and	x13, x11, #0x7f
   14358:      	lsl	x13, x13, x10
   1435c:      	add	x10, x10, #0x7
   14360:      	orr	x8, x13, x8
   14364:      	tbnz	w11, #0x7, 0x14344 <_Z20MTARMPMMusicGetSpeedPv+0x9648>
   14368:      	add	x12, x20, x0, lsl #4
   1436c:      	sub	w13, w10, #0x7
   14370:      	mov	x15, #-0x1              // =-1
   14374:      	cmp	w13, #0x39
   14378:      	mov	w14, #0x3f              // =63
   1437c:      	lsl	x15, x15, x10
   14380:      	mov	x13, x12
   14384:      	ccmp	w11, w14, #0x0, lo
   14388:      	ldrsw	x10, [x22, #0x2c]
   1438c:      	ldrb	w16, [x13, #0x1c]!
   14390:      	csel	x11, x15, xzr, hi
   14394:      	stur	x9, [x29, #-0x40]
   14398:      	cbnz	w16, 0x143bc <_Z20MTARMPMMusicGetSpeedPv+0x96c0>
   1439c:      	lsl	x9, x0, #4
   143a0:      	add	x15, x19, #0x28
   143a4:      	add	x14, x20, x9
   143a8:      	add	x9, x15, x9
   143ac:      	ldur	q0, [x14, #0x18]
   143b0:      	mov	w14, #0x1               // =1
   143b4:      	strb	w14, [x13]
   143b8:      	stur	q0, [x9, #0x18]
   143bc:      	orr	x8, x8, x11
   143c0:      	mov	w9, #0x4                // =4
   143c4:      	b	0x149d0 <_Z20MTARMPMMusicGetSpeedPv+0x9cd4>
   143c8:      	bti	j
   143cc:      	sub	x0, x29, #0x40
   143d0:      	mov	x1, x24
   143d4:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   143d8:      	cmp	x0, #0x60
   143dc:      	b.hs	0x14b4c <_Z20MTARMPMMusicGetSpeedPv+0x9e50>
   143e0:      	str	w0, [x20]
   143e4:      	ldur	x9, [x29, #-0x40]
   143e8:      	cmp	x9, x24
   143ec:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   143f0:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   143f4:      	bti	j
   143f8:      	sub	x0, x29, #0x40
   143fc:      	mov	x1, x24
   14400:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   14404:      	cmp	x0, #0x60
   14408:      	b.hs	0x14bdc <_Z20MTARMPMMusicGetSpeedPv+0x9ee0>
   1440c:      	mov	x26, x0
   14410:      	sub	x0, x29, #0x40
   14414:      	mov	x1, x24
   14418:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   1441c:      	add	x8, x20, x26, lsl #4
   14420:      	ldrsw	x9, [x22, #0x2c]
   14424:      	mov	x10, x8
   14428:      	ldrb	w11, [x10, #0x1c]!
   1442c:      	cbnz	w11, 0x14450 <_Z20MTARMPMMusicGetSpeedPv+0x9754>
   14430:      	lsl	x11, x26, #4
   14434:      	add	x13, x19, #0x28
   14438:      	add	x12, x20, x11
   1443c:      	add	x11, x13, x11
   14440:      	ldur	q0, [x12, #0x18]
   14444:      	mov	w12, #0x1               // =1
   14448:      	strb	w12, [x10]
   1444c:      	stur	q0, [x11, #0x18]
   14450:      	mneg	x9, x0, x9
   14454:      	b	0x14660 <_Z20MTARMPMMusicGetSpeedPv+0x9964>
   14458:      	bti	j
   1445c:      	cmp	w28, #0x4
   14460:      	b.ne	0x14b0c <_Z20MTARMPMMusicGetSpeedPv+0x9e10>
   14464:      	ldrb	w8, [x20, #0x23c]
   14468:      	cbnz	w8, 0x14480 <_Z20MTARMPMMusicGetSpeedPv+0x9784>
   1446c:      	ldp	x9, x8, [x19, #0x8]
   14470:      	ldr	q0, [x8]
   14474:      	mov	w8, #0x1                // =1
   14478:      	strb	w8, [x20, #0x23c]
   1447c:      	str	q0, [x9]
   14480:      	ldr	x8, [x20, #0x240]
   14484:      	eor	x8, x8, #0x1
   14488:      	str	x8, [x20, #0x240]
   1448c:      	ldur	x9, [x29, #-0x40]
   14490:      	cmp	x9, x24
   14494:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   14498:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   1449c:      	bti	j
   144a0:      	sub	x26, sp, #0x620
   144a4:      	mov	sp, x26
   144a8:      	ldr	x8, [x19, #0x20]
   144ac:      	mov	x0, x26
   144b0:      	mov	x1, x20
   144b4:      	mov	w2, #0x618              // =1560
   144b8:      	str	x8, [x0], #0x8
   144bc:      	bl	0x17240 <memcpy@plt>
   144c0:      	str	x26, [x19, #0x20]
   144c4:      	ldur	x9, [x29, #-0x40]
   144c8:      	cmp	x9, x24
   144cc:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   144d0:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   144d4:      	bti	j
   144d8:      	ldrb	w8, [x9, #0x1]
   144dc:      	ldr	w10, [x22, #0x28]
   144e0:      	add	x9, x9, #0x2
   144e4:      	b	0x146c4 <_Z20MTARMPMMusicGetSpeedPv+0x99c8>
   144e8:      	bti	j
   144ec:      	ldur	w8, [x9, #0x1]
   144f0:      	ldr	w10, [x22, #0x28]
   144f4:      	add	x9, x9, #0x5
   144f8:      	b	0x146c4 <_Z20MTARMPMMusicGetSpeedPv+0x99c8>
   144fc:      	bti	j
   14500:      	sub	x0, x29, #0x40
   14504:      	mov	x1, x24
   14508:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   1450c:      	cmp	x0, #0x60
   14510:      	b.hs	0x14b5c <_Z20MTARMPMMusicGetSpeedPv+0x9e60>
   14514:      	add	x8, x20, x0, lsl #4
   14518:      	mov	x9, x8
   1451c:      	ldrb	w10, [x9, #0x1c]!
   14520:      	cbnz	w10, 0x14544 <_Z20MTARMPMMusicGetSpeedPv+0x9848>
   14524:      	lsl	x10, x0, #4
   14528:      	add	x12, x19, #0x28
   1452c:      	add	x11, x20, x10
   14530:      	add	x10, x12, x10
   14534:      	ldur	q0, [x11, #0x18]
   14538:      	mov	w11, #0x1               // =1
   1453c:      	strb	w11, [x9]
   14540:      	stur	q0, [x10, #0x18]
   14544:      	ldur	x9, [x29, #-0x40]
   14548:      	mov	w10, #0x7               // =7
   1454c:      	b	0x14a3c <_Z20MTARMPMMusicGetSpeedPv+0x9d40>
   14550:      	bti	j
   14554:      	sub	x0, x29, #0x40
   14558:      	mov	x1, x24
   1455c:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   14560:      	mov	x26, x0
   14564:      	sub	x0, x29, #0x40
   14568:      	mov	x1, x24
   1456c:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   14570:      	cmp	x26, #0x60
   14574:      	b.hs	0x14bf8 <_Z20MTARMPMMusicGetSpeedPv+0x9efc>
   14578:      	stp	w26, w0, [x20]
   1457c:      	ldur	x9, [x29, #-0x40]
   14580:      	cmp	x9, x24
   14584:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   14588:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   1458c:      	bti	j
   14590:      	mov	x10, xzr
   14594:      	mov	x9, xzr
   14598:      	mov	x11, x8
   1459c:      	cmp	x11, x24
   145a0:      	b.eq	0x14d00 <_Z20MTARMPMMusicGetSpeedPv+0xa004>
   145a4:      	ldrb	w12, [x11], #0x1
   145a8:      	add	x8, x8, #0x1
   145ac:      	and	x13, x12, #0x7f
   145b0:      	lsl	x13, x13, x10
   145b4:      	add	x10, x10, #0x7
   145b8:      	orr	x9, x13, x9
   145bc:      	tbnz	w12, #0x7, 0x1459c <_Z20MTARMPMMusicGetSpeedPv+0x98a0>
   145c0:      	sub	w11, w10, #0x7
   145c4:      	mov	x13, #-0x1              // =-1
   145c8:      	stur	x8, [x29, #-0x40]
   145cc:      	cmp	w11, #0x39
   145d0:      	mov	w11, #0x3f              // =63
   145d4:      	lsl	x10, x13, x10
   145d8:      	ccmp	w12, w11, #0x0, lo
   145dc:      	ldr	w11, [x22, #0x2c]
   145e0:      	csel	w10, w10, wzr, hi
   145e4:      	orr	w9, w9, w10
   145e8:      	mul	w9, w11, w9
   145ec:      	str	w9, [x20, #0x4]
   145f0:      	mov	x9, x8
   145f4:      	cmp	x8, x24
   145f8:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   145fc:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   14600:      	bti	j
   14604:      	sub	x0, x29, #0x40
   14608:      	mov	x1, x24
   1460c:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   14610:      	mov	x26, x0
   14614:      	sub	x0, x29, #0x40
   14618:      	mov	x1, x24
   1461c:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   14620:      	cmp	x26, #0x60
   14624:      	b.hs	0x14bc0 <_Z20MTARMPMMusicGetSpeedPv+0x9ec4>
   14628:      	add	x8, x20, x26, lsl #4
   1462c:      	ldrsw	x9, [x22, #0x2c]
   14630:      	mov	x10, x8
   14634:      	ldrb	w11, [x10, #0x1c]!
   14638:      	cbnz	w11, 0x1465c <_Z20MTARMPMMusicGetSpeedPv+0x9960>
   1463c:      	lsl	x11, x26, #4
   14640:      	add	x13, x19, #0x28
   14644:      	add	x12, x20, x11
   14648:      	add	x11, x13, x11
   1464c:      	ldur	q0, [x12, #0x18]
   14650:      	mov	w12, #0x1               // =1
   14654:      	strb	w12, [x10]
   14658:      	stur	q0, [x11, #0x18]
   1465c:      	mul	x9, x0, x9
   14660:      	mov	w10, #0x2               // =2
   14664:      	str	w10, [x8, #0x18]
   14668:      	str	x9, [x8, #0x20]
   1466c:      	ldur	x9, [x29, #-0x40]
   14670:      	cmp	x9, x24
   14674:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   14678:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   1467c:      	bti	j
   14680:      	ldr	x8, [x19, #0x20]
   14684:      	cbz	x8, 0x14cd8 <_Z20MTARMPMMusicGetSpeedPv+0x9fdc>
   14688:      	add	x1, x8, #0x8
   1468c:      	mov	x0, x20
   14690:      	mov	w2, #0x618              // =1560
   14694:      	mov	x26, x8
   14698:      	bl	0x17240 <memcpy@plt>
   1469c:      	ldr	x26, [x26]
   146a0:      	str	x26, [x19, #0x20]
   146a4:      	ldur	x9, [x29, #-0x40]
   146a8:      	cmp	x9, x24
   146ac:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   146b0:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   146b4:      	bti	j
   146b8:      	ldurh	w8, [x9, #0x1]
   146bc:      	ldr	w10, [x22, #0x28]
   146c0:      	add	x9, x9, #0x3
   146c4:      	mul	w8, w10, w8
   146c8:      	add	x25, x25, x8
   146cc:      	stur	x9, [x29, #-0x40]
   146d0:      	cmp	x9, x24
   146d4:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   146d8:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   146dc:      	bti	j
   146e0:      	sub	x0, x29, #0x40
   146e4:      	mov	x1, x24
   146e8:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   146ec:      	str	w0, [x20, #0x10]
   146f0:      	ldur	x9, [x29, #-0x40]
   146f4:      	cmp	x9, x24
   146f8:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   146fc:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   14700:      	bti	j
   14704:      	sub	x0, x29, #0x40
   14708:      	mov	x1, x24
   1470c:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   14710:      	cmp	x0, #0x60
   14714:      	b.hs	0x14ba4 <_Z20MTARMPMMusicGetSpeedPv+0x9ea8>
   14718:      	add	x8, x20, x0, lsl #4
   1471c:      	ldrb	w8, [x8, #0x1c]
   14720:      	cbz	w8, 0x14b0c <_Z20MTARMPMMusicGetSpeedPv+0x9e10>
   14724:      	lsl	x8, x0, #4
   14728:      	b	0x14af8 <_Z20MTARMPMMusicGetSpeedPv+0x9dfc>
   1472c:      	bti	j
   14730:      	sub	x0, x29, #0x40
   14734:      	mov	x1, x24
   14738:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   1473c:      	cmp	x0, #0x60
   14740:      	b.hs	0x14c14 <_Z20MTARMPMMusicGetSpeedPv+0x9f18>
   14744:      	add	x8, x20, x0, lsl #4
   14748:      	mov	x9, x8
   1474c:      	ldrb	w10, [x9, #0x1c]!
   14750:      	cbnz	w10, 0x14774 <_Z20MTARMPMMusicGetSpeedPv+0x9a78>
   14754:      	lsl	x10, x0, #4
   14758:      	add	x12, x19, #0x28
   1475c:      	add	x11, x20, x10
   14760:      	add	x10, x12, x10
   14764:      	ldur	q0, [x11, #0x18]
   14768:      	mov	w11, #0x1               // =1
   1476c:      	strb	w11, [x9]
   14770:      	stur	q0, [x10, #0x18]
   14774:      	mov	w9, #0x1                // =1
   14778:      	str	w9, [x8, #0x18]
   1477c:      	ldur	x9, [x29, #-0x40]
   14780:      	cmp	x9, x24
   14784:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   14788:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   1478c:      	bti	j
   14790:      	sub	x0, x29, #0x40
   14794:      	mov	x1, x24
   14798:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   1479c:      	str	w0, [x20, #0x4]
   147a0:      	ldur	x9, [x29, #-0x40]
   147a4:      	cmp	x9, x24
   147a8:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   147ac:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   147b0:      	bti	j
   147b4:      	str	wzr, [x20]
   147b8:      	str	x8, [x20, #0x8]
   147bc:      	b	0x14a44 <_Z20MTARMPMMusicGetSpeedPv+0x9d48>
   147c0:      	bti	j
   147c4:      	sub	x0, x29, #0x40
   147c8:      	mov	x1, x24
   147cc:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   147d0:      	mov	x26, x0
   147d4:      	sub	x0, x29, #0x40
   147d8:      	mov	x1, x24
   147dc:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   147e0:      	cmp	x26, #0x60
   147e4:      	b.hs	0x14c60 <_Z20MTARMPMMusicGetSpeedPv+0x9f64>
   147e8:      	cmp	x0, #0x60
   147ec:      	b.hs	0x14ca8 <_Z20MTARMPMMusicGetSpeedPv+0x9fac>
   147f0:      	add	x8, x20, x26, lsl #4
   147f4:      	mov	x9, x8
   147f8:      	ldrb	w10, [x9, #0x1c]!
   147fc:      	cbnz	w10, 0x14820 <_Z20MTARMPMMusicGetSpeedPv+0x9b24>
   14800:      	lsl	x10, x26, #4
   14804:      	add	x12, x19, #0x28
   14808:      	add	x11, x20, x10
   1480c:      	add	x10, x12, x10
   14810:      	ldur	q0, [x11, #0x18]
   14814:      	mov	w11, #0x1               // =1
   14818:      	strb	w11, [x9]
   1481c:      	stur	q0, [x10, #0x18]
   14820:      	mov	w9, #0x5                // =5
   14824:      	str	x0, [x8, #0x20]
   14828:      	str	w9, [x8, #0x18]
   1482c:      	ldur	x9, [x29, #-0x40]
   14830:      	cmp	x9, x24
   14834:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   14838:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   1483c:      	bti	j
   14840:      	and	w8, w10, #0xc0
   14844:      	and	x26, x10, #0x3f
   14848:      	cmp	w8, #0x40
   1484c:      	b.eq	0x14b28 <_Z20MTARMPMMusicGetSpeedPv+0x9e2c>
   14850:      	cmp	w8, #0xc0
   14854:      	b.eq	0x14ae8 <_Z20MTARMPMMusicGetSpeedPv+0x9dec>
   14858:      	cmp	w8, #0x80
   1485c:      	b.ne	0x14cd8 <_Z20MTARMPMMusicGetSpeedPv+0x9fdc>
   14860:      	sub	x0, x29, #0x40
   14864:      	mov	x1, x24
   14868:      	str	w28, [x19, #0x4]
   1486c:      	mov	w28, w26
   14870:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   14874:      	add	x8, x20, w26, uxtw #4
   14878:      	ldrsw	x9, [x22, #0x2c]
   1487c:      	ldrb	w10, [x8, #0x1c]!
   14880:      	cbnz	w10, 0x148a4 <_Z20MTARMPMMusicGetSpeedPv+0x9ba8>
   14884:      	lsl	x10, x28, #4
   14888:      	add	x11, x20, x10
   1488c:      	ldur	q0, [x11, #0x18]
   14890:      	add	x11, x19, #0x28
   14894:      	add	x10, x11, x10
   14898:      	stur	q0, [x10, #0x18]
   1489c:      	mov	w10, #0x1               // =1
   148a0:      	strb	w10, [x8]
   148a4:      	mul	x8, x0, x9
   148a8:      	add	x9, x20, x28, lsl #4
   148ac:      	mov	w10, #0x2               // =2
   148b0:      	ldr	w28, [x19, #0x4]
   148b4:      	str	w10, [x9, #0x18]
   148b8:      	str	x8, [x9, #0x20]
   148bc:      	ldur	x9, [x29, #-0x40]
   148c0:      	cmp	x9, x24
   148c4:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   148c8:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   148cc:      	bti	j
   148d0:      	sub	x0, x29, #0x40
   148d4:      	mov	x1, x24
   148d8:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   148dc:      	cmp	x0, #0x60
   148e0:      	b.hs	0x14b94 <_Z20MTARMPMMusicGetSpeedPv+0x9e98>
   148e4:      	add	x8, x20, x0, lsl #4
   148e8:      	mov	x9, x8
   148ec:      	ldrb	w10, [x9, #0x1c]!
   148f0:      	cbnz	w10, 0x14914 <_Z20MTARMPMMusicGetSpeedPv+0x9c18>
   148f4:      	lsl	x10, x0, #4
   148f8:      	add	x12, x19, #0x28
   148fc:      	add	x11, x20, x10
   14900:      	add	x10, x12, x10
   14904:      	ldur	q0, [x11, #0x18]
   14908:      	mov	w11, #0x1               // =1
   1490c:      	strb	w11, [x9]
   14910:      	stur	q0, [x10, #0x18]
   14914:      	str	wzr, [x8, #0x18]
   14918:      	ldur	x9, [x29, #-0x40]
   1491c:      	cmp	x9, x24
   14920:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   14924:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   14928:      	bti	j
   1492c:      	sub	x0, x29, #0x40
   14930:      	mov	x1, x24
   14934:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   14938:      	cmp	x0, #0x60
   1493c:      	b.hs	0x14c44 <_Z20MTARMPMMusicGetSpeedPv+0x9f48>
   14940:      	ldur	x9, [x29, #-0x40]
   14944:      	mov	x10, xzr
   14948:      	mov	x8, xzr
   1494c:      	mov	x12, x9
   14950:      	cmp	x12, x24
   14954:      	b.eq	0x14d68 <_Z20MTARMPMMusicGetSpeedPv+0xa06c>
   14958:      	ldrb	w11, [x12], #0x1
   1495c:      	add	x9, x9, #0x1
   14960:      	and	x13, x11, #0x7f
   14964:      	lsl	x13, x13, x10
   14968:      	add	x10, x10, #0x7
   1496c:      	orr	x8, x13, x8
   14970:      	tbnz	w11, #0x7, 0x14950 <_Z20MTARMPMMusicGetSpeedPv+0x9c54>
   14974:      	add	x12, x20, x0, lsl #4
   14978:      	sub	w13, w10, #0x7
   1497c:      	mov	x15, #-0x1              // =-1
   14980:      	cmp	w13, #0x39
   14984:      	mov	w14, #0x3f              // =63
   14988:      	lsl	x15, x15, x10
   1498c:      	mov	x13, x12
   14990:      	ccmp	w11, w14, #0x0, lo
   14994:      	ldrsw	x10, [x22, #0x2c]
   14998:      	ldrb	w16, [x13, #0x1c]!
   1499c:      	csel	x11, x15, xzr, hi
   149a0:      	stur	x9, [x29, #-0x40]
   149a4:      	cbnz	w16, 0x149c8 <_Z20MTARMPMMusicGetSpeedPv+0x9ccc>
   149a8:      	lsl	x9, x0, #4
   149ac:      	add	x15, x19, #0x28
   149b0:      	add	x14, x20, x9
   149b4:      	add	x9, x15, x9
   149b8:      	ldur	q0, [x14, #0x18]
   149bc:      	mov	w14, #0x1               // =1
   149c0:      	strb	w14, [x13]
   149c4:      	stur	q0, [x9, #0x18]
   149c8:      	orr	x8, x8, x11
   149cc:      	mov	w9, #0x2                // =2
   149d0:      	mul	x8, x8, x10
   149d4:      	str	w9, [x12, #0x18]
   149d8:      	str	x8, [x12, #0x20]
   149dc:      	ldur	x9, [x29, #-0x40]
   149e0:      	cmp	x9, x24
   149e4:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   149e8:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   149ec:      	bti	j
   149f0:      	sub	x0, x29, #0x40
   149f4:      	mov	x1, x24
   149f8:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   149fc:      	cmp	x0, #0x60
   14a00:      	b.hs	0x14c7c <_Z20MTARMPMMusicGetSpeedPv+0x9f80>
   14a04:      	add	x8, x20, x0, lsl #4
   14a08:      	mov	x9, x8
   14a0c:      	ldrb	w10, [x9, #0x1c]!
   14a10:      	cbnz	w10, 0x14a34 <_Z20MTARMPMMusicGetSpeedPv+0x9d38>
   14a14:      	lsl	x10, x0, #4
   14a18:      	add	x12, x19, #0x28
   14a1c:      	add	x11, x20, x10
   14a20:      	add	x10, x12, x10
   14a24:      	ldur	q0, [x11, #0x18]
   14a28:      	mov	w11, #0x1               // =1
   14a2c:      	strb	w11, [x9]
   14a30:      	stur	q0, [x10, #0x18]
   14a34:      	ldur	x9, [x29, #-0x40]
   14a38:      	mov	w10, #0x6               // =6
   14a3c:      	str	w10, [x8, #0x18]
   14a40:      	str	x9, [x8, #0x20]
   14a44:      	sub	x0, x29, #0x40
   14a48:      	mov	x1, x24
   14a4c:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   14a50:      	ldur	x8, [x29, #-0x40]
   14a54:      	add	x8, x8, x0
   14a58:      	stur	x8, [x29, #-0x40]
   14a5c:      	mov	x9, x8
   14a60:      	cmp	x8, x24
   14a64:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   14a68:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   14a6c:      	bti	j
   14a70:      	sub	x0, x29, #0x40
   14a74:      	mov	x1, x24
   14a78:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   14a7c:      	mov	x26, x0
   14a80:      	cmp	x0, #0x60
   14a84:      	b.hs	0x14c24 <_Z20MTARMPMMusicGetSpeedPv+0x9f28>
   14a88:      	sub	x0, x29, #0x40
   14a8c:      	mov	x1, x24
   14a90:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   14a94:      	add	x8, x20, x26, lsl #4
   14a98:      	ldrsw	x9, [x22, #0x2c]
   14a9c:      	mov	x10, x8
   14aa0:      	ldrb	w11, [x10, #0x1c]!
   14aa4:      	cbnz	w11, 0x14ac8 <_Z20MTARMPMMusicGetSpeedPv+0x9dcc>
   14aa8:      	lsl	x11, x26, #4
   14aac:      	add	x13, x19, #0x28
   14ab0:      	add	x12, x20, x11
   14ab4:      	add	x11, x13, x11
   14ab8:      	ldur	q0, [x12, #0x18]
   14abc:      	mov	w12, #0x1               // =1
   14ac0:      	strb	w12, [x10]
   14ac4:      	stur	q0, [x11, #0x18]
   14ac8:      	mul	x9, x0, x9
   14acc:      	mov	w10, #0x4               // =4
   14ad0:      	str	w10, [x8, #0x18]
   14ad4:      	str	x9, [x8, #0x20]
   14ad8:      	ldur	x9, [x29, #-0x40]
   14adc:      	cmp	x9, x24
   14ae0:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   14ae4:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   14ae8:      	add	x8, x20, x26, lsl #4
   14aec:      	ldrb	w8, [x8, #0x1c]
   14af0:      	cbz	w8, 0x14b0c <_Z20MTARMPMMusicGetSpeedPv+0x9e10>
   14af4:      	lsl	x8, x26, #4
   14af8:      	add	x9, x19, #0x28
   14afc:      	add	x9, x9, x8
   14b00:      	add	x8, x20, x8
   14b04:      	ldur	q0, [x9, #0x18]
   14b08:      	stur	q0, [x8, #0x18]
   14b0c:      	bti	j
   14b10:      	ldur	x9, [x29, #-0x40]
   14b14:      	cmp	x9, x24
   14b18:      	b.hs	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   14b1c:      	cmp	x25, x21
   14b20:      	b.lo	0x1423c <_Z20MTARMPMMusicGetSpeedPv+0x9540>
   14b24:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   14b28:      	ldr	w8, [x22, #0x28]
   14b2c:      	mul	w8, w8, w26
   14b30:      	add	x25, x25, x8
   14b34:      	ldur	x9, [x29, #-0x40]
   14b38:      	cmp	x9, x24
   14b3c:      	b.lo	0x14b1c <_Z20MTARMPMMusicGetSpeedPv+0x9e20>
   14b40:      	b	0x1420c <_Z20MTARMPMMusicGetSpeedPv+0x9510>
   14b44:      	mov	w0, #0x1                // =1
   14b48:      	b	0x14cdc <_Z20MTARMPMMusicGetSpeedPv+0x9fe0>
   14b4c:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14b50:      	adrp	x0, 0x5000
   14b54:      	add	x0, x0, #0xb4e
   14b58:      	b	0x14bb0 <_Z20MTARMPMMusicGetSpeedPv+0x9eb4>
   14b5c:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14b60:      	adrp	x0, 0x5000
   14b64:      	add	x0, x0, #0x856
   14b68:      	ldr	x8, [x8, #0x998]
   14b6c:      	mov	w1, #0x45               // =69
   14b70:      	add	x3, x8, #0x130
   14b74:      	b	0x14cc0 <_Z20MTARMPMMusicGetSpeedPv+0x9fc4>
   14b78:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14b7c:      	adrp	x0, 0x5000
   14b80:      	add	x0, x0, #0xdca
   14b84:      	ldr	x8, [x8, #0x998]
   14b88:      	mov	w1, #0x44               // =68
   14b8c:      	add	x3, x8, #0x130
   14b90:      	b	0x14cc0 <_Z20MTARMPMMusicGetSpeedPv+0x9fc4>
   14b94:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14b98:      	adrp	x0, 0x5000
   14b9c:      	add	x0, x0, #0xe61
   14ba0:      	b	0x14c98 <_Z20MTARMPMMusicGetSpeedPv+0x9f9c>
   14ba4:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14ba8:      	adrp	x0, 0x5000
   14bac:      	add	x0, x0, #0x776
   14bb0:      	ldr	x8, [x8, #0x998]
   14bb4:      	add	x3, x8, #0x130
   14bb8:      	mov	w1, #0x47               // =71
   14bbc:      	b	0x14cc0 <_Z20MTARMPMMusicGetSpeedPv+0x9fc4>
   14bc0:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14bc4:      	adrp	x0, 0x4000
   14bc8:      	add	x0, x0, #0xc98
   14bcc:      	ldr	x8, [x8, #0x998]
   14bd0:      	mov	w1, #0x46               // =70
   14bd4:      	add	x3, x8, #0x130
   14bd8:      	b	0x14cc0 <_Z20MTARMPMMusicGetSpeedPv+0x9fc4>
   14bdc:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14be0:      	adrp	x0, 0x5000
   14be4:      	add	x0, x0, #0xa6e
   14be8:      	ldr	x8, [x8, #0x998]
   14bec:      	mov	w1, #0x53               // =83
   14bf0:      	add	x3, x8, #0x130
   14bf4:      	b	0x14cc0 <_Z20MTARMPMMusicGetSpeedPv+0x9fc4>
   14bf8:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14bfc:      	adrp	x0, 0x4000
   14c00:      	add	x0, x0, #0x931
   14c04:      	ldr	x8, [x8, #0x998]
   14c08:      	mov	w1, #0x3e               // =62
   14c0c:      	add	x3, x8, #0x130
   14c10:      	b	0x14cc0 <_Z20MTARMPMMusicGetSpeedPv+0x9fc4>
   14c14:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14c18:      	adrp	x0, 0x5000
   14c1c:      	add	x0, x0, #0xc40
   14c20:      	b	0x14cb4 <_Z20MTARMPMMusicGetSpeedPv+0x9fb8>
   14c24:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14c28:      	adrp	x1, 0x4000
   14c2c:      	add	x1, x1, #0xa5f
   14c30:      	ldr	x8, [x8, #0x998]
   14c34:      	mov	x2, x26
   14c38:      	add	x0, x8, #0x130
   14c3c:      	bl	0x17280 <fprintf@plt>
   14c40:      	b	0x14cc8 <_Z20MTARMPMMusicGetSpeedPv+0x9fcc>
   14c44:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14c48:      	adrp	x0, 0x5000
   14c4c:      	add	x0, x0, #0x3e0
   14c50:      	ldr	x8, [x8, #0x998]
   14c54:      	mov	w1, #0x49               // =73
   14c58:      	add	x3, x8, #0x130
   14c5c:      	b	0x14cc0 <_Z20MTARMPMMusicGetSpeedPv+0x9fc4>
   14c60:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14c64:      	adrp	x0, 0x5000
   14c68:      	add	x0, x0, #0xb0e
   14c6c:      	ldr	x8, [x8, #0x998]
   14c70:      	mov	w1, #0x3f               // =63
   14c74:      	add	x3, x8, #0x130
   14c78:      	b	0x14cc0 <_Z20MTARMPMMusicGetSpeedPv+0x9fc4>
   14c7c:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14c80:      	adrp	x0, 0x5000
   14c84:      	add	x0, x0, #0x385
   14c88:      	b	0x14c98 <_Z20MTARMPMMusicGetSpeedPv+0x9f9c>
   14c8c:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14c90:      	adrp	x0, 0x4000
   14c94:      	add	x0, x0, #0xb41
   14c98:      	ldr	x8, [x8, #0x998]
   14c9c:      	add	x3, x8, #0x130
   14ca0:      	mov	w1, #0x41               // =65
   14ca4:      	b	0x14cc0 <_Z20MTARMPMMusicGetSpeedPv+0x9fc4>
   14ca8:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14cac:      	adrp	x0, 0x5000
   14cb0:      	add	x0, x0, #0x143
   14cb4:      	ldr	x8, [x8, #0x998]
   14cb8:      	add	x3, x8, #0x130
   14cbc:      	mov	w1, #0x40               // =64
   14cc0:      	mov	w2, #0x1                // =1
   14cc4:      	bl	0x16e20 <fwrite@plt>
   14cc8:      	adrp	x8, 0x1b000 <syscall@plt+0x3d00>
   14ccc:      	ldr	x8, [x8, #0x998]
   14cd0:      	add	x0, x8, #0x130
   14cd4:      	bl	0x17290 <fflush@plt>
   14cd8:      	mov	w0, wzr
   14cdc:      	mov	sp, x29
   14ce0:      	ldp	x20, x19, [sp, #0x50]
   14ce4:      	ldp	x22, x21, [sp, #0x40]
   14ce8:      	ldp	x24, x23, [sp, #0x30]
   14cec:      	ldp	x26, x25, [sp, #0x20]
   14cf0:      	ldp	x28, x27, [sp, #0x10]
   14cf4:      	ldp	x29, x30, [sp], #0x60
   14cf8:      	autiasp
   14cfc:      	ret
   14d00:      	adrp	x20, 0x1b000 <syscall@plt+0x3d00>
   14d04:      	nop
   14d08:      	adr	x1, 0x479e
   14d0c:      	ldr	x20, [x20, #0x998]
   14d10:      	adrp	x2, 0x5000
   14d14:      	add	x2, x2, #0x4c8
   14d18:      	adrp	x3, 0x4000
   14d1c:      	add	x3, x3, #0xf20
   14d20:      	add	x0, x20, #0x130
   14d24:      	bl	0x17280 <fprintf@plt>
   14d28:      	add	x0, x20, #0x130
   14d2c:      	bl	0x17290 <fflush@plt>
   14d30:      	bl	0x172a0 <abort@plt>
   14d34:      	adrp	x20, 0x1b000 <syscall@plt+0x3d00>
   14d38:      	nop
   14d3c:      	adr	x1, 0x479e
   14d40:      	ldr	x20, [x20, #0x998]
   14d44:      	adrp	x2, 0x5000
   14d48:      	add	x2, x2, #0x4c8
   14d4c:      	adrp	x3, 0x4000
   14d50:      	add	x3, x3, #0xf20
   14d54:      	add	x0, x20, #0x130
   14d58:      	bl	0x17280 <fprintf@plt>
   14d5c:      	add	x0, x20, #0x130
   14d60:      	bl	0x17290 <fflush@plt>
   14d64:      	bl	0x172a0 <abort@plt>
   14d68:      	adrp	x20, 0x1b000 <syscall@plt+0x3d00>
   14d6c:      	nop
   14d70:      	adr	x1, 0x479e
   14d74:      	ldr	x20, [x20, #0x998]
   14d78:      	adrp	x2, 0x5000
   14d7c:      	add	x2, x2, #0x4c8
   14d80:      	adrp	x3, 0x4000
   14d84:      	add	x3, x3, #0xf20
   14d88:      	add	x0, x20, #0x130
   14d8c:      	bl	0x17280 <fprintf@plt>
   14d90:      	add	x0, x20, #0x130
   14d94:      	bl	0x17290 <fflush@plt>
   14d98:      	bl	0x172a0 <abort@plt>
   14d9c:      	adrp	x20, 0x1b000 <syscall@plt+0x3d00>
   14da0:      	nop
   14da4:      	adr	x1, 0x479e
   14da8:      	ldr	x20, [x20, #0x998]
   14dac:      	adrp	x2, 0x5000
   14db0:      	add	x2, x2, #0x4c8
   14db4:      	adrp	x3, 0x4000
   14db8:      	add	x3, x3, #0xf20
   14dbc:      	add	x0, x20, #0x130
   14dc0:      	bl	0x17280 <fprintf@plt>
   14dc4:      	add	x0, x20, #0x130
   14dc8:      	bl	0x17290 <fflush@plt>
   14dcc:      	bl	0x172a0 <abort@plt>
   14dd0:      	bti	c
   14dd4:      	ldr	w8, [x1]
   14dd8:      	cmp	w8, #0x1d
   14ddc:      	b.gt	0x14df8 <_Z20MTARMPMMusicGetSpeedPv+0xa0fc>
   14de0:      	tbz	w8, #0x1f, 0x14e24 <_Z20MTARMPMMusicGetSpeedPv+0xa128>
   14de4:      	cmn	w8, #0x2
   14de8:      	b.eq	0x14e10 <_Z20MTARMPMMusicGetSpeedPv+0xa114>
   14dec:      	cmn	w8, #0x1
   14df0:      	b.eq	0x14e54 <_Z20MTARMPMMusicGetSpeedPv+0xa158>
   14df4:      	b	0x14ea4 <_Z20MTARMPMMusicGetSpeedPv+0xa1a8>
   14df8:      	cmp	w8, #0x1f
   14dfc:      	b.gt	0x14e44 <_Z20MTARMPMMusicGetSpeedPv+0xa148>
   14e00:      	cmp	w8, #0x1e
   14e04:      	b.eq	0x14e68 <_Z20MTARMPMMusicGetSpeedPv+0xa16c>
   14e08:      	cmp	w8, #0x1f
   14e0c:      	b.ne	0x14ea4 <_Z20MTARMPMMusicGetSpeedPv+0xa1a8>
   14e10:      	add	x8, x2, #0xf8
   14e14:      	ldr	x8, [x8]
   14e18:      	ldrsw	x9, [x1, #0x4]
   14e1c:      	add	x0, x8, x9
   14e20:      	ret
   14e24:      	cbz	w8, 0x14e7c <_Z20MTARMPMMusicGetSpeedPv+0xa180>
   14e28:      	cmp	w8, #0x1d
   14e2c:      	b.ne	0x14ea4 <_Z20MTARMPMMusicGetSpeedPv+0xa1a8>
   14e30:      	add	x8, x2, #0xe8
   14e34:      	ldr	x8, [x8]
   14e38:      	ldrsw	x9, [x1, #0x4]
   14e3c:      	add	x0, x8, x9
   14e40:      	ret
   14e44:      	cmp	w8, #0x22
   14e48:      	b.eq	0x14e90 <_Z20MTARMPMMusicGetSpeedPv+0xa194>
   14e4c:      	cmp	w8, #0x20
   14e50:      	b.ne	0x14ea4 <_Z20MTARMPMMusicGetSpeedPv+0xa1a8>
   14e54:      	add	x8, x2, #0x100
   14e58:      	ldr	x8, [x8]
   14e5c:      	ldrsw	x9, [x1, #0x4]
   14e60:      	add	x0, x8, x9
   14e64:      	ret
   14e68:      	add	x8, x2, #0xf0
   14e6c:      	ldr	x8, [x8]
   14e70:      	ldrsw	x9, [x1, #0x4]
   14e74:      	add	x0, x8, x9
   14e78:      	ret
   14e7c:      	ldr	x8, [x1, #0x8]
   14e80:      	mov	x1, x0
   14e84:      	mov	x3, xzr
   14e88:      	mov	x0, x8
   14e8c:      	b	0x15668 <_Z20MTARMPMMusicGetSpeedPv+0xa96c>
   14e90:      	add	x8, x2, #0x108
   14e94:      	ldr	x8, [x8]
   14e98:      	ldrsw	x9, [x1, #0x4]
   14e9c:      	add	x0, x8, x9
   14ea0:      	ret
   14ea4:      	cmp	w8, #0x1c
   14ea8:      	b.hi	0x14ec0 <_Z20MTARMPMMusicGetSpeedPv+0xa1c4>
   14eac:      	add	x8, x2, x8, lsl #3
   14eb0:      	ldr	x8, [x8]
   14eb4:      	ldrsw	x9, [x1, #0x4]
   14eb8:      	add	x0, x8, x9
   14ebc:      	ret
   14ec0:      	paciasp
   14ec4:      	stp	x29, x30, [sp, #-0x20]!
   14ec8:      	str	x19, [sp, #0x10]
   14ecc:      	mov	x29, sp
   14ed0:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   14ed4:      	nop
   14ed8:      	adr	x1, 0x479e
   14edc:      	ldr	x19, [x19, #0x998]
   14ee0:      	adrp	x2, 0x5000
   14ee4:      	add	x2, x2, #0x28d
   14ee8:      	adrp	x3, 0x4000
   14eec:      	add	x3, x3, #0xded
   14ef0:      	add	x0, x19, #0x130
   14ef4:      	bl	0x17280 <fprintf@plt>
   14ef8:      	add	x0, x19, #0x130
   14efc:      	bl	0x17290 <fflush@plt>
   14f00:      	bl	0x172a0 <abort@plt>
   14f04:      	paciasp
   14f08:      	stp	x29, x30, [sp, #-0x20]!
   14f0c:      	str	x19, [sp, #0x10]
   14f10:      	mov	x29, sp
   14f14:      	ldr	w9, [x3]
   14f18:      	mov	x8, x2
   14f1c:      	cmp	w9, #0x4
   14f20:      	b.gt	0x14f54 <_Z20MTARMPMMusicGetSpeedPv+0xa258>
   14f24:      	cmp	w9, #0x1
   14f28:      	b.eq	0x14fac <_Z20MTARMPMMusicGetSpeedPv+0xa2b0>
   14f2c:      	cmp	w9, #0x2
   14f30:      	b.eq	0x14f3c <_Z20MTARMPMMusicGetSpeedPv+0xa240>
   14f34:      	cmp	w9, #0x3
   14f38:      	b.ne	0x150ac <_Z20MTARMPMMusicGetSpeedPv+0xa3b0>
   14f3c:      	ldr	x9, [x3, #0x8]
   14f40:      	ldr	x0, [x9, x8]
   14f44:      	ldr	x19, [sp, #0x10]
   14f48:      	ldp	x29, x30, [sp], #0x20
   14f4c:      	autiasp
   14f50:      	ret
   14f54:      	mov	x2, x1
   14f58:      	cmp	w9, #0x5
   14f5c:      	b.eq	0x14fc0 <_Z20MTARMPMMusicGetSpeedPv+0xa2c4>
   14f60:      	mov	x1, x0
   14f64:      	cmp	w9, #0x6
   14f68:      	b.eq	0x14f8c <_Z20MTARMPMMusicGetSpeedPv+0xa290>
   14f6c:      	cmp	w9, #0x7
   14f70:      	b.ne	0x150ac <_Z20MTARMPMMusicGetSpeedPv+0xa3b0>
   14f74:      	ldr	x0, [x3, #0x8]
   14f78:      	mov	x3, x8
   14f7c:      	ldr	x19, [sp, #0x10]
   14f80:      	ldp	x29, x30, [sp], #0x20
   14f84:      	autiasp
   14f88:      	b	0x15668 <_Z20MTARMPMMusicGetSpeedPv+0xa96c>
   14f8c:      	ldr	x0, [x3, #0x8]
   14f90:      	mov	x3, x8
   14f94:      	bl	0x15668 <_Z20MTARMPMMusicGetSpeedPv+0xa96c>
   14f98:      	ldr	x0, [x0]
   14f9c:      	ldr	x19, [sp, #0x10]
   14fa0:      	ldp	x29, x30, [sp], #0x20
   14fa4:      	autiasp
   14fa8:      	ret
   14fac:      	mov	x0, xzr
   14fb0:      	ldr	x19, [sp, #0x10]
   14fb4:      	ldp	x29, x30, [sp], #0x20
   14fb8:      	autiasp
   14fbc:      	ret
   14fc0:      	ldr	x8, [x3, #0x8]
   14fc4:      	cmp	w8, #0x1d
   14fc8:      	b.le	0x14fe8 <_Z20MTARMPMMusicGetSpeedPv+0xa2ec>
   14fcc:      	cmp	w8, #0x1f
   14fd0:      	b.gt	0x15018 <_Z20MTARMPMMusicGetSpeedPv+0xa31c>
   14fd4:      	cmp	w8, #0x1e
   14fd8:      	b.eq	0x1507c <_Z20MTARMPMMusicGetSpeedPv+0xa380>
   14fdc:      	cmp	w8, #0x1f
   14fe0:      	b.eq	0x15040 <_Z20MTARMPMMusicGetSpeedPv+0xa344>
   14fe4:      	b	0x15058 <_Z20MTARMPMMusicGetSpeedPv+0xa35c>
   14fe8:      	cmn	w8, #0x2
   14fec:      	b.eq	0x15040 <_Z20MTARMPMMusicGetSpeedPv+0xa344>
   14ff0:      	cmn	w8, #0x1
   14ff4:      	b.eq	0x15028 <_Z20MTARMPMMusicGetSpeedPv+0xa32c>
   14ff8:      	cmp	w8, #0x1d
   14ffc:      	b.ne	0x15058 <_Z20MTARMPMMusicGetSpeedPv+0xa35c>
   15000:      	add	x8, x2, #0xe8
   15004:      	ldr	x0, [x8]
   15008:      	ldr	x19, [sp, #0x10]
   1500c:      	ldp	x29, x30, [sp], #0x20
   15010:      	autiasp
   15014:      	ret
   15018:      	cmp	w8, #0x22
   1501c:      	b.eq	0x15094 <_Z20MTARMPMMusicGetSpeedPv+0xa398>
   15020:      	cmp	w8, #0x20
   15024:      	b.ne	0x15058 <_Z20MTARMPMMusicGetSpeedPv+0xa35c>
   15028:      	add	x8, x2, #0x100
   1502c:      	ldr	x0, [x8]
   15030:      	ldr	x19, [sp, #0x10]
   15034:      	ldp	x29, x30, [sp], #0x20
   15038:      	autiasp
   1503c:      	ret
   15040:      	add	x8, x2, #0xf8
   15044:      	ldr	x0, [x8]
   15048:      	ldr	x19, [sp, #0x10]
   1504c:      	ldp	x29, x30, [sp], #0x20
   15050:      	autiasp
   15054:      	ret
   15058:      	cmp	w8, #0x1c
   1505c:      	b.hi	0x150e0 <_Z20MTARMPMMusicGetSpeedPv+0xa3e4>
   15060:      	and	x8, x8, #0xffffffff
   15064:      	add	x8, x2, x8, lsl #3
   15068:      	ldr	x0, [x8]
   1506c:      	ldr	x19, [sp, #0x10]
   15070:      	ldp	x29, x30, [sp], #0x20
   15074:      	autiasp
   15078:      	ret
   1507c:      	add	x8, x2, #0xf0
   15080:      	ldr	x0, [x8]
   15084:      	ldr	x19, [sp, #0x10]
   15088:      	ldp	x29, x30, [sp], #0x20
   1508c:      	autiasp
   15090:      	ret
   15094:      	add	x8, x2, #0x108
   15098:      	ldr	x0, [x8]
   1509c:      	ldr	x19, [sp, #0x10]
   150a0:      	ldp	x29, x30, [sp], #0x20
   150a4:      	autiasp
   150a8:      	ret
   150ac:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   150b0:      	nop
   150b4:      	adr	x1, 0x479e
   150b8:      	ldr	x19, [x19, #0x998]
   150bc:      	adrp	x2, 0x5000
   150c0:      	add	x2, x2, #0x1b4
   150c4:      	adrp	x3, 0x4000
   150c8:      	add	x3, x3, #0xe08
   150cc:      	add	x0, x19, #0x130
   150d0:      	bl	0x17280 <fprintf@plt>
   150d4:      	add	x0, x19, #0x130
   150d8:      	bl	0x17290 <fflush@plt>
   150dc:      	bl	0x172a0 <abort@plt>
   150e0:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   150e4:      	nop
   150e8:      	adr	x1, 0x479e
   150ec:      	ldr	x19, [x19, #0x998]
   150f0:      	adrp	x2, 0x5000
   150f4:      	add	x2, x2, #0x28d
   150f8:      	adrp	x3, 0x4000
   150fc:      	add	x3, x3, #0xded
   15100:      	add	x0, x19, #0x130
   15104:      	bl	0x17280 <fprintf@plt>
   15108:      	add	x0, x19, #0x130
   1510c:      	bl	0x17290 <fflush@plt>
   15110:      	bl	0x172a0 <abort@plt>
   15114:      	paciasp
   15118:      	stp	x29, x30, [sp, #-0x30]!
   1511c:      	str	x21, [sp, #0x10]
   15120:      	stp	x20, x19, [sp, #0x20]
   15124:      	mov	x29, sp
   15128:      	and	w8, w3, #0xf
   1512c:      	ldr	x19, [x1]
   15130:      	cmp	w8, #0x3
   15134:      	b.le	0x1515c <_Z20MTARMPMMusicGetSpeedPv+0xa460>
   15138:      	cmp	w8, #0x9
   1513c:      	b.le	0x151d0 <_Z20MTARMPMMusicGetSpeedPv+0xa4d4>
   15140:      	cmp	w8, #0xa
   15144:      	b.eq	0x152a0 <_Z20MTARMPMMusicGetSpeedPv+0xa5a4>
   15148:      	cmp	w8, #0xb
   1514c:      	b.eq	0x152c0 <_Z20MTARMPMMusicGetSpeedPv+0xa5c4>
   15150:      	cmp	w8, #0xc
   15154:      	b.eq	0x15260 <_Z20MTARMPMMusicGetSpeedPv+0xa564>
   15158:      	b	0x1546c <_Z20MTARMPMMusicGetSpeedPv+0xa770>
   1515c:      	cmp	w8, #0x1
   15160:      	b.gt	0x151a0 <_Z20MTARMPMMusicGetSpeedPv+0xa4a4>
   15164:      	cbz	w8, 0x15260 <_Z20MTARMPMMusicGetSpeedPv+0xa564>
   15168:      	cmp	w8, #0x1
   1516c:      	b.ne	0x1546c <_Z20MTARMPMMusicGetSpeedPv+0xa770>
   15170:      	mov	x0, x1
   15174:      	mov	x1, x2
   15178:      	mov	w20, w3
   1517c:      	mov	x21, x4
   15180:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   15184:      	mov	x4, x21
   15188:      	mov	w3, w20
   1518c:      	and	w8, w20, #0xff
   15190:      	ubfx	w8, w8, #4, #3
   15194:      	cmp	w8, #0x1
   15198:      	b.le	0x152dc <_Z20MTARMPMMusicGetSpeedPv+0xa5e0>
   1519c:      	b	0x15248 <_Z20MTARMPMMusicGetSpeedPv+0xa54c>
   151a0:      	cmp	w8, #0x2
   151a4:      	b.eq	0x15280 <_Z20MTARMPMMusicGetSpeedPv+0xa584>
   151a8:      	cmp	w8, #0x3
   151ac:      	b.ne	0x1546c <_Z20MTARMPMMusicGetSpeedPv+0xa770>
   151b0:      	mov	x8, x19
   151b4:      	ldr	w0, [x8], #0x4
   151b8:      	str	x8, [x1]
   151bc:      	and	w8, w3, #0xff
   151c0:      	ubfx	w8, w8, #4, #3
   151c4:      	cmp	w8, #0x1
   151c8:      	b.le	0x152dc <_Z20MTARMPMMusicGetSpeedPv+0xa5e0>
   151cc:      	b	0x15248 <_Z20MTARMPMMusicGetSpeedPv+0xa54c>
   151d0:      	cmp	w8, #0x4
   151d4:      	b.eq	0x15260 <_Z20MTARMPMMusicGetSpeedPv+0xa564>
   151d8:      	cmp	w8, #0x9
   151dc:      	b.ne	0x1546c <_Z20MTARMPMMusicGetSpeedPv+0xa770>
   151e0:      	mov	x10, xzr
   151e4:      	mov	x8, xzr
   151e8:      	mov	x9, x19
   151ec:      	mov	x11, x19
   151f0:      	cmp	x11, x2
   151f4:      	b.eq	0x1531c <_Z20MTARMPMMusicGetSpeedPv+0xa620>
   151f8:      	ldrb	w12, [x11], #0x1
   151fc:      	add	x9, x9, #0x1
   15200:      	and	x13, x12, #0x7f
   15204:      	lsl	x13, x13, x10
   15208:      	add	x10, x10, #0x7
   1520c:      	orr	x8, x13, x8
   15210:      	tbnz	w12, #0x7, 0x151f0 <_Z20MTARMPMMusicGetSpeedPv+0xa4f4>
   15214:      	sub	w11, w10, #0x7
   15218:      	mov	x13, #-0x1              // =-1
   1521c:      	str	x9, [x1]
   15220:      	cmp	w11, #0x39
   15224:      	mov	w11, #0x3f              // =63
   15228:      	lsl	x10, x13, x10
   1522c:      	ccmp	w12, w11, #0x0, lo
   15230:      	csel	x10, x10, xzr, hi
   15234:      	orr	x0, x8, x10
   15238:      	and	w8, w3, #0xff
   1523c:      	ubfx	w8, w8, #4, #3
   15240:      	cmp	w8, #0x1
   15244:      	b.le	0x152dc <_Z20MTARMPMMusicGetSpeedPv+0xa5e0>
   15248:      	cmp	w8, #0x3
   1524c:      	b.gt	0x15350 <_Z20MTARMPMMusicGetSpeedPv+0xa654>
   15250:      	b.ne	0x15394 <_Z20MTARMPMMusicGetSpeedPv+0xa698>
   15254:      	cbz	x4, 0x15404 <_Z20MTARMPMMusicGetSpeedPv+0xa708>
   15258:      	add	x0, x0, x4
   1525c:      	b	0x152ec <_Z20MTARMPMMusicGetSpeedPv+0xa5f0>
   15260:      	mov	x8, x19
   15264:      	ldr	x0, [x8], #0x8
   15268:      	str	x8, [x1]
   1526c:      	and	w8, w3, #0xff
   15270:      	ubfx	w8, w8, #4, #3
   15274:      	cmp	w8, #0x1
   15278:      	b.le	0x152dc <_Z20MTARMPMMusicGetSpeedPv+0xa5e0>
   1527c:      	b	0x15248 <_Z20MTARMPMMusicGetSpeedPv+0xa54c>
   15280:      	mov	x8, x19
   15284:      	ldrh	w0, [x8], #0x2
   15288:      	str	x8, [x1]
   1528c:      	and	w8, w3, #0xff
   15290:      	ubfx	w8, w8, #4, #3
   15294:      	cmp	w8, #0x1
   15298:      	b.le	0x152dc <_Z20MTARMPMMusicGetSpeedPv+0xa5e0>
   1529c:      	b	0x15248 <_Z20MTARMPMMusicGetSpeedPv+0xa54c>
   152a0:      	mov	x8, x19
   152a4:      	ldrsh	x0, [x8], #0x2
   152a8:      	str	x8, [x1]
   152ac:      	and	w8, w3, #0xff
   152b0:      	ubfx	w8, w8, #4, #3
   152b4:      	cmp	w8, #0x1
   152b8:      	b.le	0x152dc <_Z20MTARMPMMusicGetSpeedPv+0xa5e0>
   152bc:      	b	0x15248 <_Z20MTARMPMMusicGetSpeedPv+0xa54c>
   152c0:      	mov	x8, x19
   152c4:      	ldrsw	x0, [x8], #0x4
   152c8:      	str	x8, [x1]
   152cc:      	and	w8, w3, #0xff
   152d0:      	ubfx	w8, w8, #4, #3
   152d4:      	cmp	w8, #0x1
   152d8:      	b.gt	0x15248 <_Z20MTARMPMMusicGetSpeedPv+0xa54c>
   152dc:      	cbz	w8, 0x152ec <_Z20MTARMPMMusicGetSpeedPv+0xa5f0>
   152e0:      	cmp	w8, #0x1
   152e4:      	b.ne	0x15438 <_Z20MTARMPMMusicGetSpeedPv+0xa73c>
   152e8:      	add	x0, x0, x19
   152ec:      	tbnz	w3, #0x7, 0x15304 <_Z20MTARMPMMusicGetSpeedPv+0xa608>
   152f0:      	ldp	x20, x19, [sp, #0x20]
   152f4:      	ldr	x21, [sp, #0x10]
   152f8:      	ldp	x29, x30, [sp], #0x30
   152fc:      	autiasp
   15300:      	ret
   15304:      	ldr	x0, [x0]
   15308:      	ldp	x20, x19, [sp, #0x20]
   1530c:      	ldr	x21, [sp, #0x10]
   15310:      	ldp	x29, x30, [sp], #0x30
   15314:      	autiasp
   15318:      	ret
   1531c:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15320:      	nop
   15324:      	adr	x1, 0x479e
   15328:      	ldr	x19, [x19, #0x998]
   1532c:      	adrp	x2, 0x5000
   15330:      	add	x2, x2, #0x4c8
   15334:      	adrp	x3, 0x4000
   15338:      	add	x3, x3, #0xf20
   1533c:      	add	x0, x19, #0x130
   15340:      	bl	0x17280 <fprintf@plt>
   15344:      	add	x0, x19, #0x130
   15348:      	bl	0x17290 <fflush@plt>
   1534c:      	bl	0x172a0 <abort@plt>
   15350:      	cmp	w8, #0x4
   15354:      	b.eq	0x153d0 <_Z20MTARMPMMusicGetSpeedPv+0xa6d4>
   15358:      	cmp	w8, #0x5
   1535c:      	b.ne	0x15438 <_Z20MTARMPMMusicGetSpeedPv+0xa73c>
   15360:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15364:      	nop
   15368:      	adr	x1, 0x479e
   1536c:      	ldr	x19, [x19, #0x998]
   15370:      	adrp	x2, 0x5000
   15374:      	add	x2, x2, #0xe0f
   15378:      	adrp	x3, 0x5000
   1537c:      	add	x3, x3, #0x184
   15380:      	add	x0, x19, #0x130
   15384:      	bl	0x17280 <fprintf@plt>
   15388:      	add	x0, x19, #0x130
   1538c:      	bl	0x17290 <fflush@plt>
   15390:      	bl	0x172a0 <abort@plt>
   15394:      	cmp	w8, #0x2
   15398:      	b.ne	0x15438 <_Z20MTARMPMMusicGetSpeedPv+0xa73c>
   1539c:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   153a0:      	nop
   153a4:      	adr	x1, 0x479e
   153a8:      	ldr	x19, [x19, #0x998]
   153ac:      	adrp	x2, 0x5000
   153b0:      	add	x2, x2, #0xe0f
   153b4:      	adrp	x3, 0x5000
   153b8:      	add	x3, x3, #0x7be
   153bc:      	add	x0, x19, #0x130
   153c0:      	bl	0x17280 <fprintf@plt>
   153c4:      	add	x0, x19, #0x130
   153c8:      	bl	0x17290 <fflush@plt>
   153cc:      	bl	0x172a0 <abort@plt>
   153d0:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   153d4:      	nop
   153d8:      	adr	x1, 0x479e
   153dc:      	ldr	x19, [x19, #0x998]
   153e0:      	adrp	x2, 0x5000
   153e4:      	add	x2, x2, #0xe0f
   153e8:      	adrp	x3, 0x4000
   153ec:      	add	x3, x3, #0x7b2
   153f0:      	add	x0, x19, #0x130
   153f4:      	bl	0x17280 <fprintf@plt>
   153f8:      	add	x0, x19, #0x130
   153fc:      	bl	0x17290 <fflush@plt>
   15400:      	bl	0x172a0 <abort@plt>
   15404:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15408:      	nop
   1540c:      	adr	x1, 0x479e
   15410:      	ldr	x19, [x19, #0x998]
   15414:      	adrp	x2, 0x5000
   15418:      	add	x2, x2, #0xe0f
   1541c:      	adrp	x3, 0x5000
   15420:      	add	x3, x3, #0x9a2
   15424:      	add	x0, x19, #0x130
   15428:      	bl	0x17280 <fprintf@plt>
   1542c:      	add	x0, x19, #0x130
   15430:      	bl	0x17290 <fflush@plt>
   15434:      	bl	0x172a0 <abort@plt>
   15438:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   1543c:      	nop
   15440:      	adr	x1, 0x479e
   15444:      	ldr	x19, [x19, #0x998]
   15448:      	adrp	x2, 0x5000
   1544c:      	add	x2, x2, #0xe0f
   15450:      	adrp	x3, 0x5000
   15454:      	add	x3, x3, #0x4af
   15458:      	add	x0, x19, #0x130
   1545c:      	bl	0x17280 <fprintf@plt>
   15460:      	add	x0, x19, #0x130
   15464:      	bl	0x17290 <fflush@plt>
   15468:      	bl	0x172a0 <abort@plt>
   1546c:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15470:      	nop
   15474:      	adr	x1, 0x479e
   15478:      	ldr	x19, [x19, #0x998]
   1547c:      	adrp	x2, 0x5000
   15480:      	add	x2, x2, #0xe0f
   15484:      	adrp	x3, 0x5000
   15488:      	add	x3, x3, #0x4af
   1548c:      	add	x0, x19, #0x130
   15490:      	bl	0x17280 <fprintf@plt>
   15494:      	add	x0, x19, #0x130
   15498:      	bl	0x17290 <fflush@plt>
   1549c:      	bl	0x172a0 <abort@plt>
   154a0:      	paciasp
   154a4:      	stp	x29, x30, [sp, #-0x20]!
   154a8:      	str	x19, [sp, #0x10]
   154ac:      	mov	x29, sp
   154b0:      	ldr	x9, [x0]
   154b4:      	cmp	x9, x1
   154b8:      	b.eq	0x15600 <_Z20MTARMPMMusicGetSpeedPv+0xa904>
   154bc:      	mov	x10, x9
   154c0:      	mov	x8, x0
   154c4:      	ldrb	w11, [x10], #0x1
   154c8:      	and	x0, x11, #0x7f
   154cc:      	tbnz	w11, #0x7, 0x154e4 <_Z20MTARMPMMusicGetSpeedPv+0xa7e8>
   154d0:      	str	x10, [x8]
   154d4:      	ldr	x19, [sp, #0x10]
   154d8:      	ldp	x29, x30, [sp], #0x20
   154dc:      	autiasp
   154e0:      	ret
   154e4:      	cmp	x10, x1
   154e8:      	b.eq	0x15600 <_Z20MTARMPMMusicGetSpeedPv+0xa904>
   154ec:      	ldrsb	w11, [x9, #0x1]
   154f0:      	and	w10, w11, #0x7f
   154f4:      	orr	x0, x0, x10, lsl #7
   154f8:      	add	x10, x9, #0x2
   154fc:      	tbz	w11, #0x1f, 0x154d0 <_Z20MTARMPMMusicGetSpeedPv+0xa7d4>
   15500:      	cmp	x10, x1
   15504:      	b.eq	0x15600 <_Z20MTARMPMMusicGetSpeedPv+0xa904>
   15508:      	ldrsb	w11, [x9, #0x2]
   1550c:      	and	w10, w11, #0x7f
   15510:      	orr	x0, x0, x10, lsl #14
   15514:      	add	x10, x9, #0x3
   15518:      	tbz	w11, #0x1f, 0x154d0 <_Z20MTARMPMMusicGetSpeedPv+0xa7d4>
   1551c:      	cmp	x10, x1
   15520:      	b.eq	0x15600 <_Z20MTARMPMMusicGetSpeedPv+0xa904>
   15524:      	ldrsb	w11, [x9, #0x3]
   15528:      	and	w10, w11, #0x7f
   1552c:      	orr	x0, x0, x10, lsl #21
   15530:      	add	x10, x9, #0x4
   15534:      	tbz	w11, #0x1f, 0x154d0 <_Z20MTARMPMMusicGetSpeedPv+0xa7d4>
   15538:      	cmp	x10, x1
   1553c:      	b.eq	0x15600 <_Z20MTARMPMMusicGetSpeedPv+0xa904>
   15540:      	ldrsb	w11, [x9, #0x4]
   15544:      	and	w10, w11, #0x7f
   15548:      	orr	x0, x0, x10, lsl #28
   1554c:      	add	x10, x9, #0x5
   15550:      	tbz	w11, #0x1f, 0x154d0 <_Z20MTARMPMMusicGetSpeedPv+0xa7d4>
   15554:      	cmp	x10, x1
   15558:      	b.eq	0x15600 <_Z20MTARMPMMusicGetSpeedPv+0xa904>
   1555c:      	ldrsb	w11, [x9, #0x5]
   15560:      	and	w10, w11, #0x7f
   15564:      	orr	x0, x0, x10, lsl #35
   15568:      	add	x10, x9, #0x6
   1556c:      	tbz	w11, #0x1f, 0x154d0 <_Z20MTARMPMMusicGetSpeedPv+0xa7d4>
   15570:      	cmp	x10, x1
   15574:      	b.eq	0x15600 <_Z20MTARMPMMusicGetSpeedPv+0xa904>
   15578:      	ldrsb	w11, [x9, #0x6]
   1557c:      	and	w10, w11, #0x7f
   15580:      	orr	x0, x0, x10, lsl #42
   15584:      	add	x10, x9, #0x7
   15588:      	tbz	w11, #0x1f, 0x154d0 <_Z20MTARMPMMusicGetSpeedPv+0xa7d4>
   1558c:      	cmp	x10, x1
   15590:      	b.eq	0x15600 <_Z20MTARMPMMusicGetSpeedPv+0xa904>
   15594:      	ldrsb	w11, [x9, #0x7]
   15598:      	and	w10, w11, #0x7f
   1559c:      	orr	x0, x0, x10, lsl #49
   155a0:      	add	x10, x9, #0x8
   155a4:      	tbz	w11, #0x1f, 0x154d0 <_Z20MTARMPMMusicGetSpeedPv+0xa7d4>
   155a8:      	cmp	x10, x1
   155ac:      	b.eq	0x15600 <_Z20MTARMPMMusicGetSpeedPv+0xa904>
   155b0:      	ldrsb	w11, [x9, #0x8]
   155b4:      	and	w10, w11, #0x7f
   155b8:      	orr	x0, x0, x10, lsl #56
   155bc:      	add	x10, x9, #0x9
   155c0:      	tbz	w11, #0x1f, 0x154d0 <_Z20MTARMPMMusicGetSpeedPv+0xa7d4>
   155c4:      	cmp	x10, x1
   155c8:      	b.eq	0x15600 <_Z20MTARMPMMusicGetSpeedPv+0xa904>
   155cc:      	ldrb	w11, [x10]
   155d0:      	tst	w11, #0x7e
   155d4:      	b.ne	0x15634 <_Z20MTARMPMMusicGetSpeedPv+0xa938>
   155d8:      	add	x10, x9, #0xa
   155dc:      	tbnz	w11, #0x7, 0x155f8 <_Z20MTARMPMMusicGetSpeedPv+0xa8fc>
   155e0:      	orr	x0, x0, x11, lsl #63
   155e4:      	str	x10, [x8]
   155e8:      	ldr	x19, [sp, #0x10]
   155ec:      	ldp	x29, x30, [sp], #0x20
   155f0:      	autiasp
   155f4:      	ret
   155f8:      	cmp	x10, x1
   155fc:      	b.ne	0x15634 <_Z20MTARMPMMusicGetSpeedPv+0xa938>
   15600:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15604:      	nop
   15608:      	adr	x1, 0x479e
   1560c:      	ldr	x19, [x19, #0x998]
   15610:      	adrp	x2, 0x4000
   15614:      	add	x2, x2, #0xc48
   15618:      	adrp	x3, 0x4000
   1561c:      	add	x3, x3, #0xd23
   15620:      	add	x0, x19, #0x130
   15624:      	bl	0x17280 <fprintf@plt>
   15628:      	add	x0, x19, #0x130
   1562c:      	bl	0x17290 <fflush@plt>
   15630:      	bl	0x172a0 <abort@plt>
   15634:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15638:      	nop
   1563c:      	adr	x1, 0x479e
   15640:      	ldr	x19, [x19, #0x998]
   15644:      	adrp	x2, 0x4000
   15648:      	add	x2, x2, #0xc48
   1564c:      	adrp	x3, 0x5000
   15650:      	add	x3, x3, #0xe5
   15654:      	add	x0, x19, #0x130
   15658:      	bl	0x17280 <fprintf@plt>
   1565c:      	add	x0, x19, #0x130
   15660:      	bl	0x17290 <fflush@plt>
   15664:      	bl	0x172a0 <abort@plt>
   15668:      	paciasp
   1566c:      	stp	x29, x30, [sp, #-0x60]!
   15670:      	stp	x28, x27, [sp, #0x10]
   15674:      	stp	x26, x25, [sp, #0x20]
   15678:      	stp	x24, x23, [sp, #0x30]
   1567c:      	stp	x22, x21, [sp, #0x40]
   15680:      	stp	x20, x19, [sp, #0x50]
   15684:      	mov	x29, sp
   15688:      	sub	sp, sp, #0x330
   1568c:      	mov	x8, x0
   15690:      	stur	x0, [x29, #-0x8]
   15694:      	sub	x0, x29, #0x8
   15698:      	add	x1, x8, #0x14
   1569c:      	mov	x21, x3
   156a0:      	mov	x19, x2
   156a4:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   156a8:      	ldur	x10, [x29, #-0x8]
   156ac:      	str	x21, [sp, #0x10]
   156b0:      	add	x20, x10, x0
   156b4:      	cmp	x10, x20
   156b8:      	b.hs	0x15de8 <_Z20MTARMPMMusicGetSpeedPv+0xb0ec>
   156bc:      	add	x8, sp, #0x8
   156c0:      	add	x21, x19, #0xf0
   156c4:      	add	x22, x19, #0xe8
   156c8:      	add	x23, x19, #0x108
   156cc:      	add	x24, x19, #0xf8
   156d0:      	add	x27, x8, #0x8
   156d4:      	add	x25, x19, #0x100
   156d8:      	nop
   156dc:      	adr	x26, 0x5ff0 <_ZTSSt9bad_alloc+0xaf>
   156e0:      	b	0x156f8 <_Z20MTARMPMMusicGetSpeedPv+0xa9fc>
   156e4:      	ldr	x8, [x8]
   156e8:      	str	x8, [x27, #0x8]!
   156ec:      	ldur	x10, [x29, #-0x8]
   156f0:      	cmp	x10, x20
   156f4:      	b.hs	0x15de4 <_Z20MTARMPMMusicGetSpeedPv+0xb0e8>
   156f8:      	add	x8, x10, #0x1
   156fc:      	stur	x8, [x29, #-0x8]
   15700:      	ldrb	w9, [x10]
   15704:      	sub	w11, w9, #0x3
   15708:      	cmp	w11, #0x91
   1570c:      	b.hi	0x15ee0 <_Z20MTARMPMMusicGetSpeedPv+0xb1e4>
   15710:      	adr	x12, 0x15720 <_Z20MTARMPMMusicGetSpeedPv+0xaa24>
   15714:      	ldrh	w13, [x26, x11, lsl #1]
   15718:      	add	x12, x12, x13, lsl #2
   1571c:      	br	x12
   15720:      	bti	j
   15724:      	sub	w8, w9, #0x30
   15728:      	b	0x156e8 <_Z20MTARMPMMusicGetSpeedPv+0xa9ec>
   1572c:      	bti	j
   15730:      	mov	x12, xzr
   15734:      	mov	x10, xzr
   15738:      	sub	w11, w9, #0x70
   1573c:      	mov	x13, x8
   15740:      	cmp	x13, x20
   15744:      	b.eq	0x15e10 <_Z20MTARMPMMusicGetSpeedPv+0xb114>
   15748:      	ldrb	w14, [x13], #0x1
   1574c:      	add	x8, x8, #0x1
   15750:      	and	x15, x14, #0x7f
   15754:      	lsl	x15, x15, x12
   15758:      	add	x12, x12, #0x7
   1575c:      	orr	x10, x15, x10
   15760:      	tbnz	w14, #0x7, 0x15740 <_Z20MTARMPMMusicGetSpeedPv+0xaa44>
   15764:      	sub	w13, w12, #0x7
   15768:      	mov	x15, #-0x1              // =-1
   1576c:      	stur	x8, [x29, #-0x8]
   15770:      	cmp	w13, #0x39
   15774:      	mov	w13, #0x3f              // =63
   15778:      	lsl	x12, x15, x12
   1577c:      	ccmp	w14, w13, #0x0, lo
   15780:      	csel	x12, x12, xzr, hi
   15784:      	cmp	w9, #0x8d
   15788:      	b.le	0x157e4 <_Z20MTARMPMMusicGetSpeedPv+0xaae8>
   1578c:      	cmp	w9, #0x8f
   15790:      	b.gt	0x1580c <_Z20MTARMPMMusicGetSpeedPv+0xab10>
   15794:      	cmp	w9, #0x8e
   15798:      	mov	x8, x21
   1579c:      	b.eq	0x15830 <_Z20MTARMPMMusicGetSpeedPv+0xab34>
   157a0:      	cmp	w9, #0x8f
   157a4:      	mov	x8, x24
   157a8:      	b.eq	0x15830 <_Z20MTARMPMMusicGetSpeedPv+0xab34>
   157ac:      	b	0x15824 <_Z20MTARMPMMusicGetSpeedPv+0xab28>
   157b0:      	bti	j
   157b4:      	cmp	w9, #0x6f
   157b8:      	mov	x8, x24
   157bc:      	b.eq	0x156e4 <_Z20MTARMPMMusicGetSpeedPv+0xa9e8>
   157c0:      	cmp	w9, #0x6e
   157c4:      	mov	x8, x21
   157c8:      	b.eq	0x156e4 <_Z20MTARMPMMusicGetSpeedPv+0xa9e8>
   157cc:      	cmp	w9, #0x6d
   157d0:      	mov	x8, x22
   157d4:      	b.eq	0x156e4 <_Z20MTARMPMMusicGetSpeedPv+0xa9e8>
   157d8:      	sub	w8, w9, #0x50
   157dc:      	add	x8, x19, w8, uxtw #3
   157e0:      	b	0x156e4 <_Z20MTARMPMMusicGetSpeedPv+0xa9e8>
   157e4:      	cmp	w9, #0x6e
   157e8:      	mov	x8, x24
   157ec:      	b.eq	0x15830 <_Z20MTARMPMMusicGetSpeedPv+0xab34>
   157f0:      	cmp	w9, #0x6f
   157f4:      	mov	x8, x25
   157f8:      	b.eq	0x15830 <_Z20MTARMPMMusicGetSpeedPv+0xab34>
   157fc:      	cmp	w9, #0x8d
   15800:      	mov	x8, x22
   15804:      	b.eq	0x15830 <_Z20MTARMPMMusicGetSpeedPv+0xab34>
   15808:      	b	0x15824 <_Z20MTARMPMMusicGetSpeedPv+0xab28>
   1580c:      	cmp	w9, #0x90
   15810:      	mov	x8, x25
   15814:      	b.eq	0x15830 <_Z20MTARMPMMusicGetSpeedPv+0xab34>
   15818:      	cmp	w9, #0x92
   1581c:      	mov	x8, x23
   15820:      	b.eq	0x15830 <_Z20MTARMPMMusicGetSpeedPv+0xab34>
   15824:      	cmp	w11, #0x1c
   15828:      	b.hi	0x15eac <_Z20MTARMPMMusicGetSpeedPv+0xb1b0>
   1582c:      	add	x8, x19, w11, uxtw #3
   15830:      	ldr	x8, [x8]
   15834:      	orr	x9, x10, x12
   15838:      	add	x8, x8, x9
   1583c:      	b	0x156e8 <_Z20MTARMPMMusicGetSpeedPv+0xa9ec>
   15840:      	bti	j
   15844:      	ldur	x8, [x10, #0x1]
   15848:      	add	x9, x10, #0x9
   1584c:      	b	0x15b50 <_Z20MTARMPMMusicGetSpeedPv+0xae54>
   15850:      	bti	j
   15854:      	sub	x0, x29, #0x8
   15858:      	mov	x1, x20
   1585c:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   15860:      	ldur	x10, [x29, #-0x8]
   15864:      	mov	x9, xzr
   15868:      	mov	x8, xzr
   1586c:      	mov	x11, x10
   15870:      	cmp	x11, x20
   15874:      	b.eq	0x15e44 <_Z20MTARMPMMusicGetSpeedPv+0xb148>
   15878:      	ldrb	w12, [x11], #0x1
   1587c:      	add	x10, x10, #0x1
   15880:      	and	x13, x12, #0x7f
   15884:      	lsl	x13, x13, x9
   15888:      	add	x9, x9, #0x7
   1588c:      	orr	x8, x13, x8
   15890:      	tbnz	w12, #0x7, 0x15870 <_Z20MTARMPMMusicGetSpeedPv+0xab74>
   15894:      	sub	w11, w9, #0x7
   15898:      	mov	x13, #-0x1              // =-1
   1589c:      	stur	x10, [x29, #-0x8]
   158a0:      	cmp	w11, #0x39
   158a4:      	mov	w11, #0x3f              // =63
   158a8:      	lsl	x9, x13, x9
   158ac:      	ccmp	w12, w11, #0x0, lo
   158b0:      	csel	x9, x9, xzr, hi
   158b4:      	cmp	w0, #0x1d
   158b8:      	b.le	0x15d48 <_Z20MTARMPMMusicGetSpeedPv+0xb04c>
   158bc:      	cmp	w0, #0x1f
   158c0:      	b.gt	0x15d98 <_Z20MTARMPMMusicGetSpeedPv+0xb09c>
   158c4:      	cmp	w0, #0x1e
   158c8:      	mov	x10, x21
   158cc:      	b.eq	0x15dbc <_Z20MTARMPMMusicGetSpeedPv+0xb0c0>
   158d0:      	cmp	w0, #0x1f
   158d4:      	mov	x10, x24
   158d8:      	b.eq	0x15dbc <_Z20MTARMPMMusicGetSpeedPv+0xb0c0>
   158dc:      	b	0x15db0 <_Z20MTARMPMMusicGetSpeedPv+0xb0b4>
   158e0:      	bti	j
   158e4:      	mov	x8, x27
   158e8:      	ldr	x9, [x27]
   158ec:      	ldr	x10, [x8, #-0x8]!
   158f0:      	cmp	x10, x9
   158f4:      	cset	w9, lo
   158f8:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   158fc:      	bti	j
   15900:      	mov	x8, x27
   15904:      	ldr	x9, [x27]
   15908:      	ldr	x10, [x8, #-0x8]!
   1590c:      	cmp	x10, x9
   15910:      	cset	w9, ls
   15914:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   15918:      	bti	j
   1591c:      	mov	x8, x27
   15920:      	ldr	x9, [x27]
   15924:      	ldr	x10, [x8, #-0x8]!
   15928:      	sdiv	x11, x10, x9
   1592c:      	msub	x9, x11, x9, x10
   15930:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   15934:      	bti	j
   15938:      	mov	x8, x27
   1593c:      	ldr	x9, [x27]
   15940:      	ldr	x10, [x8, #-0x8]!
   15944:      	cmp	x10, x9
   15948:      	cset	w9, eq
   1594c:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   15950:      	bti	j
   15954:      	ldursh	x8, [x10, #0x1]
   15958:      	add	x9, x10, #0x3
   1595c:      	b	0x15b50 <_Z20MTARMPMMusicGetSpeedPv+0xae54>
   15960:      	bti	j
   15964:      	ldr	x11, [x27], #-0x8
   15968:      	ldursh	x8, [x10, #0x1]
   1596c:      	add	x9, x10, #0x3
   15970:      	stur	x9, [x29, #-0x8]
   15974:      	cbz	x11, 0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15978:      	add	x8, x9, x8
   1597c:      	stur	x8, [x29, #-0x8]
   15980:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15984:      	bti	j
   15988:      	mov	x8, x27
   1598c:      	ldr	x9, [x27]
   15990:      	ldr	x10, [x8, #-0x8]!
   15994:      	cmp	x10, x9
   15998:      	cset	w9, hs
   1599c:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   159a0:      	bti	j
   159a4:      	mov	x10, xzr
   159a8:      	mov	x9, xzr
   159ac:      	mov	x11, x8
   159b0:      	cmp	x11, x20
   159b4:      	b.eq	0x15e78 <_Z20MTARMPMMusicGetSpeedPv+0xb17c>
   159b8:      	ldrb	w12, [x11], #0x1
   159bc:      	add	x8, x8, #0x1
   159c0:      	and	x13, x12, #0x7f
   159c4:      	lsl	x13, x13, x10
   159c8:      	add	x10, x10, #0x7
   159cc:      	orr	x9, x13, x9
   159d0:      	tbnz	w12, #0x7, 0x159b0 <_Z20MTARMPMMusicGetSpeedPv+0xacb4>
   159d4:      	sub	w11, w10, #0x7
   159d8:      	mov	x13, #-0x1              // =-1
   159dc:      	stur	x8, [x29, #-0x8]
   159e0:      	cmp	w11, #0x39
   159e4:      	mov	w11, #0x3f              // =63
   159e8:      	lsl	x10, x13, x10
   159ec:      	ccmp	w12, w11, #0x0, lo
   159f0:      	csel	x10, x10, xzr, hi
   159f4:      	orr	x9, x9, x10
   159f8:      	str	x9, [x27, #0x8]!
   159fc:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15a00:      	bti	j
   15a04:      	mov	x8, x27
   15a08:      	ldr	x9, [x27]
   15a0c:      	ldr	x10, [x8, #-0x8]!
   15a10:      	and	x9, x10, x9
   15a14:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   15a18:      	bti	j
   15a1c:      	mov	x8, x27
   15a20:      	ldr	x9, [x27]
   15a24:      	ldr	x10, [x8, #-0x8]!
   15a28:      	cmp	x10, x9
   15a2c:      	cset	w9, hi
   15a30:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   15a34:      	bti	j
   15a38:      	ldursw	x8, [x10, #0x1]
   15a3c:      	add	x9, x10, #0x5
   15a40:      	b	0x15b50 <_Z20MTARMPMMusicGetSpeedPv+0xae54>
   15a44:      	bti	j
   15a48:      	mov	x8, x27
   15a4c:      	ldr	x9, [x27]
   15a50:      	ldr	x10, [x8, #-0x8]!
   15a54:      	eor	x9, x10, x9
   15a58:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   15a5c:      	bti	j
   15a60:      	ldr	x8, [x27]
   15a64:      	tbz	x8, #0x3f, 0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15a68:      	b	0x15c88 <_Z20MTARMPMMusicGetSpeedPv+0xaf8c>
   15a6c:      	bti	j
   15a70:      	ldrsb	x8, [x10, #0x1]
   15a74:      	b	0x15ab4 <_Z20MTARMPMMusicGetSpeedPv+0xadb8>
   15a78:      	bti	j
   15a7c:      	ldr	x8, [x27]
   15a80:      	b	0x156e8 <_Z20MTARMPMMusicGetSpeedPv+0xa9ec>
   15a84:      	bti	j
   15a88:      	sub	x0, x29, #0x8
   15a8c:      	mov	x1, x20
   15a90:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   15a94:      	str	x0, [x27, #0x8]!
   15a98:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15a9c:      	bti	j
   15aa0:      	ldur	w8, [x10, #0x1]
   15aa4:      	add	x9, x10, #0x5
   15aa8:      	b	0x15b50 <_Z20MTARMPMMusicGetSpeedPv+0xae54>
   15aac:      	bti	j
   15ab0:      	ldrb	w8, [x10, #0x1]
   15ab4:      	add	x9, x10, #0x2
   15ab8:      	b	0x15b50 <_Z20MTARMPMMusicGetSpeedPv+0xae54>
   15abc:      	bti	j
   15ac0:      	sub	x27, x27, #0x8
   15ac4:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15ac8:      	bti	j
   15acc:      	ldurh	w8, [x10, #0x1]
   15ad0:      	add	x9, x10, #0x3
   15ad4:      	b	0x15b50 <_Z20MTARMPMMusicGetSpeedPv+0xae54>
   15ad8:      	bti	j
   15adc:      	ldr	x8, [x27]
   15ae0:      	ldr	x8, [x8]
   15ae4:      	str	x8, [x27]
   15ae8:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15aec:      	bti	j
   15af0:      	ldur	q0, [x27, #-0x10]
   15af4:      	ldr	x8, [x27]
   15af8:      	stur	q0, [x27, #-0x8]
   15afc:      	stur	x8, [x27, #-0x10]
   15b00:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15b04:      	bti	j
   15b08:      	mov	x8, x27
   15b0c:      	ldr	x9, [x27]
   15b10:      	ldr	x10, [x8, #-0x8]!
   15b14:      	sdiv	x9, x10, x9
   15b18:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   15b1c:      	bti	j
   15b20:      	ldur	x8, [x27, #-0x8]
   15b24:      	b	0x156e8 <_Z20MTARMPMMusicGetSpeedPv+0xa9ec>
   15b28:      	bti	j
   15b2c:      	ldur	q0, [x27, #-0x8]
   15b30:      	ext	v0.16b, v0.16b, v0.16b, #0x8
   15b34:      	stur	q0, [x27, #-0x8]
   15b38:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15b3c:      	bti	j
   15b40:      	ldrb	w8, [x10, #0x1]
   15b44:      	add	x9, x10, #0x2
   15b48:      	sub	x8, x27, x8, lsl #3
   15b4c:      	ldr	x8, [x8]
   15b50:      	stur	x9, [x29, #-0x8]
   15b54:      	b	0x156e8 <_Z20MTARMPMMusicGetSpeedPv+0xa9ec>
   15b58:      	bti	j
   15b5c:      	ldr	x8, [x27]
   15b60:      	mvn	x8, x8
   15b64:      	str	x8, [x27]
   15b68:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15b6c:      	bti	j
   15b70:      	mov	x8, x27
   15b74:      	ldr	x9, [x27]
   15b78:      	ldr	x10, [x8, #-0x8]!
   15b7c:      	lsl	x9, x10, x9
   15b80:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   15b84:      	bti	j
   15b88:      	mov	x8, x27
   15b8c:      	ldr	x9, [x27]
   15b90:      	ldr	x10, [x8, #-0x8]!
   15b94:      	lsr	x9, x10, x9
   15b98:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   15b9c:      	bti	j
   15ba0:      	mov	x8, x27
   15ba4:      	ldr	x9, [x27]
   15ba8:      	ldr	x10, [x8, #-0x8]!
   15bac:      	add	x9, x10, x9
   15bb0:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   15bb4:      	bti	j
   15bb8:      	add	x8, x10, #0x2
   15bbc:      	stur	x8, [x29, #-0x8]
   15bc0:      	ldr	x8, [x27]
   15bc4:      	ldrb	w9, [x10, #0x1]
   15bc8:      	cmp	w9, #0x3
   15bcc:      	b.gt	0x15d0c <_Z20MTARMPMMusicGetSpeedPv+0xb010>
   15bd0:      	cmp	w9, #0x1
   15bd4:      	b.eq	0x15dcc <_Z20MTARMPMMusicGetSpeedPv+0xb0d0>
   15bd8:      	cmp	w9, #0x2
   15bdc:      	b.ne	0x15f88 <_Z20MTARMPMMusicGetSpeedPv+0xb28c>
   15be0:      	ldrh	w8, [x8]
   15be4:      	str	x8, [x27]
   15be8:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15bec:      	bti	j
   15bf0:      	sub	x0, x29, #0x8
   15bf4:      	mov	x1, x20
   15bf8:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   15bfc:      	ldr	x8, [x27]
   15c00:      	add	x8, x8, x0
   15c04:      	str	x8, [x27]
   15c08:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15c0c:      	bti	j
   15c10:      	mov	x8, x27
   15c14:      	ldr	x9, [x27]
   15c18:      	ldr	x10, [x8, #-0x8]!
   15c1c:      	asr	x9, x10, x9
   15c20:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   15c24:      	bti	j
   15c28:      	ldr	x8, [x27]
   15c2c:      	ldr	x8, [x8]
   15c30:      	str	x8, [x27, #-0x8]!
   15c34:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15c38:      	bti	j
   15c3c:      	mov	x8, x27
   15c40:      	ldr	x9, [x27]
   15c44:      	ldr	x10, [x8, #-0x8]!
   15c48:      	mul	x9, x10, x9
   15c4c:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   15c50:      	bti	j
   15c54:      	mov	x8, x27
   15c58:      	ldr	x9, [x27]
   15c5c:      	ldr	x10, [x8, #-0x8]!
   15c60:      	sub	x9, x10, x9
   15c64:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   15c68:      	bti	j
   15c6c:      	mov	x8, x27
   15c70:      	ldr	x9, [x27]
   15c74:      	ldr	x10, [x8, #-0x8]!
   15c78:      	orr	x9, x10, x9
   15c7c:      	b	0x15cac <_Z20MTARMPMMusicGetSpeedPv+0xafb0>
   15c80:      	bti	j
   15c84:      	ldr	x8, [x27]
   15c88:      	neg	x8, x8
   15c8c:      	str	x8, [x27]
   15c90:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15c94:      	bti	j
   15c98:      	mov	x8, x27
   15c9c:      	ldr	x9, [x27]
   15ca0:      	ldr	x10, [x8, #-0x8]!
   15ca4:      	cmp	x10, x9
   15ca8:      	cset	w9, ne
   15cac:      	str	x9, [x8]
   15cb0:      	mov	x27, x8
   15cb4:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15cb8:      	bti	j
   15cbc:      	ldursh	x8, [x10, #0x1]
   15cc0:      	add	x8, x10, x8
   15cc4:      	add	x8, x8, #0x3
   15cc8:      	stur	x8, [x29, #-0x8]
   15ccc:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15cd0:      	bti	j
   15cd4:      	sub	x0, x29, #0x8
   15cd8:      	mov	x1, x20
   15cdc:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   15ce0:      	cmp	w0, #0x1d
   15ce4:      	b.le	0x15d20 <_Z20MTARMPMMusicGetSpeedPv+0xb024>
   15ce8:      	cmp	w0, #0x1f
   15cec:      	b.gt	0x15d70 <_Z20MTARMPMMusicGetSpeedPv+0xb074>
   15cf0:      	cmp	w0, #0x1e
   15cf4:      	mov	x8, x21
   15cf8:      	b.eq	0x156e4 <_Z20MTARMPMMusicGetSpeedPv+0xa9e8>
   15cfc:      	cmp	w0, #0x1f
   15d00:      	mov	x8, x24
   15d04:      	b.eq	0x156e4 <_Z20MTARMPMMusicGetSpeedPv+0xa9e8>
   15d08:      	b	0x15d88 <_Z20MTARMPMMusicGetSpeedPv+0xb08c>
   15d0c:      	cmp	w9, #0x4
   15d10:      	b.eq	0x15dd8 <_Z20MTARMPMMusicGetSpeedPv+0xb0dc>
   15d14:      	cmp	w9, #0x8
   15d18:      	b.eq	0x15ae0 <_Z20MTARMPMMusicGetSpeedPv+0xade4>
   15d1c:      	b	0x15f88 <_Z20MTARMPMMusicGetSpeedPv+0xb28c>
   15d20:      	cmn	w0, #0x2
   15d24:      	mov	x8, x24
   15d28:      	b.eq	0x156e4 <_Z20MTARMPMMusicGetSpeedPv+0xa9e8>
   15d2c:      	cmn	w0, #0x1
   15d30:      	mov	x8, x25
   15d34:      	b.eq	0x156e4 <_Z20MTARMPMMusicGetSpeedPv+0xa9e8>
   15d38:      	cmp	w0, #0x1d
   15d3c:      	mov	x8, x22
   15d40:      	b.eq	0x156e4 <_Z20MTARMPMMusicGetSpeedPv+0xa9e8>
   15d44:      	b	0x15d88 <_Z20MTARMPMMusicGetSpeedPv+0xb08c>
   15d48:      	cmn	w0, #0x2
   15d4c:      	mov	x10, x24
   15d50:      	b.eq	0x15dbc <_Z20MTARMPMMusicGetSpeedPv+0xb0c0>
   15d54:      	cmn	w0, #0x1
   15d58:      	mov	x10, x25
   15d5c:      	b.eq	0x15dbc <_Z20MTARMPMMusicGetSpeedPv+0xb0c0>
   15d60:      	cmp	w0, #0x1d
   15d64:      	mov	x10, x22
   15d68:      	b.eq	0x15dbc <_Z20MTARMPMMusicGetSpeedPv+0xb0c0>
   15d6c:      	b	0x15db0 <_Z20MTARMPMMusicGetSpeedPv+0xb0b4>
   15d70:      	cmp	w0, #0x20
   15d74:      	mov	x8, x25
   15d78:      	b.eq	0x156e4 <_Z20MTARMPMMusicGetSpeedPv+0xa9e8>
   15d7c:      	cmp	w0, #0x22
   15d80:      	mov	x8, x23
   15d84:      	b.eq	0x156e4 <_Z20MTARMPMMusicGetSpeedPv+0xa9e8>
   15d88:      	cmp	w0, #0x1c
   15d8c:      	b.hi	0x15ff0 <_Z20MTARMPMMusicGetSpeedPv+0xb2f4>
   15d90:      	add	x8, x19, w0, uxtw #3
   15d94:      	b	0x156e4 <_Z20MTARMPMMusicGetSpeedPv+0xa9e8>
   15d98:      	cmp	w0, #0x20
   15d9c:      	mov	x10, x25
   15da0:      	b.eq	0x15dbc <_Z20MTARMPMMusicGetSpeedPv+0xb0c0>
   15da4:      	cmp	w0, #0x22
   15da8:      	mov	x10, x23
   15dac:      	b.eq	0x15dbc <_Z20MTARMPMMusicGetSpeedPv+0xb0c0>
   15db0:      	cmp	w0, #0x1c
   15db4:      	b.hi	0x15fbc <_Z20MTARMPMMusicGetSpeedPv+0xb2c0>
   15db8:      	add	x10, x19, w0, uxtw #3
   15dbc:      	ldr	x10, [x10]
   15dc0:      	orr	x8, x8, x9
   15dc4:      	add	x8, x10, x8
   15dc8:      	b	0x156e8 <_Z20MTARMPMMusicGetSpeedPv+0xa9ec>
   15dcc:      	ldrb	w8, [x8]
   15dd0:      	str	x8, [x27]
   15dd4:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15dd8:      	ldr	w8, [x8]
   15ddc:      	str	x8, [x27]
   15de0:      	b	0x156ec <_Z20MTARMPMMusicGetSpeedPv+0xa9f0>
   15de4:      	ldr	x21, [x27]
   15de8:      	mov	x0, x21
   15dec:      	add	sp, sp, #0x330
   15df0:      	ldp	x20, x19, [sp, #0x50]
   15df4:      	ldp	x22, x21, [sp, #0x40]
   15df8:      	ldp	x24, x23, [sp, #0x30]
   15dfc:      	ldp	x26, x25, [sp, #0x20]
   15e00:      	ldp	x28, x27, [sp, #0x10]
   15e04:      	ldp	x29, x30, [sp], #0x60
   15e08:      	autiasp
   15e0c:      	ret
   15e10:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15e14:      	nop
   15e18:      	adr	x1, 0x479e
   15e1c:      	ldr	x19, [x19, #0x998]
   15e20:      	adrp	x2, 0x5000
   15e24:      	add	x2, x2, #0x4c8
   15e28:      	adrp	x3, 0x4000
   15e2c:      	add	x3, x3, #0xf20
   15e30:      	add	x0, x19, #0x130
   15e34:      	bl	0x17280 <fprintf@plt>
   15e38:      	add	x0, x19, #0x130
   15e3c:      	bl	0x17290 <fflush@plt>
   15e40:      	bl	0x172a0 <abort@plt>
   15e44:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15e48:      	nop
   15e4c:      	adr	x1, 0x479e
   15e50:      	ldr	x19, [x19, #0x998]
   15e54:      	adrp	x2, 0x5000
   15e58:      	add	x2, x2, #0x4c8
   15e5c:      	adrp	x3, 0x4000
   15e60:      	add	x3, x3, #0xf20
   15e64:      	add	x0, x19, #0x130
   15e68:      	bl	0x17280 <fprintf@plt>
   15e6c:      	add	x0, x19, #0x130
   15e70:      	bl	0x17290 <fflush@plt>
   15e74:      	bl	0x172a0 <abort@plt>
   15e78:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15e7c:      	nop
   15e80:      	adr	x1, 0x479e
   15e84:      	ldr	x19, [x19, #0x998]
   15e88:      	adrp	x2, 0x5000
   15e8c:      	add	x2, x2, #0x4c8
   15e90:      	adrp	x3, 0x4000
   15e94:      	add	x3, x3, #0xf20
   15e98:      	add	x0, x19, #0x130
   15e9c:      	bl	0x17280 <fprintf@plt>
   15ea0:      	add	x0, x19, #0x130
   15ea4:      	bl	0x17290 <fflush@plt>
   15ea8:      	bl	0x172a0 <abort@plt>
   15eac:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15eb0:      	nop
   15eb4:      	adr	x1, 0x479e
   15eb8:      	ldr	x19, [x19, #0x998]
   15ebc:      	adrp	x2, 0x5000
   15ec0:      	add	x2, x2, #0x28d
   15ec4:      	adrp	x3, 0x4000
   15ec8:      	add	x3, x3, #0xded
   15ecc:      	add	x0, x19, #0x130
   15ed0:      	bl	0x17280 <fprintf@plt>
   15ed4:      	add	x0, x19, #0x130
   15ed8:      	bl	0x17290 <fflush@plt>
   15edc:      	bl	0x172a0 <abort@plt>
   15ee0:      	bti	j
   15ee4:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15ee8:      	nop
   15eec:      	adr	x1, 0x479e
   15ef0:      	ldr	x19, [x19, #0x998]
   15ef4:      	adrp	x2, 0x4000
   15ef8:      	add	x2, x2, #0xfbc
   15efc:      	adrp	x3, 0x5000
   15f00:      	add	x3, x3, #0x7ee
   15f04:      	add	x0, x19, #0x130
   15f08:      	bl	0x17280 <fprintf@plt>
   15f0c:      	add	x0, x19, #0x130
   15f10:      	bl	0x17290 <fflush@plt>
   15f14:      	bl	0x172a0 <abort@plt>
   15f18:      	bti	j
   15f1c:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15f20:      	nop
   15f24:      	adr	x1, 0x479e
   15f28:      	ldr	x19, [x19, #0x998]
   15f2c:      	adrp	x2, 0x4000
   15f30:      	add	x2, x2, #0xfbc
   15f34:      	adrp	x3, 0x4000
   15f38:      	add	x3, x3, #0xf3d
   15f3c:      	add	x0, x19, #0x130
   15f40:      	bl	0x17280 <fprintf@plt>
   15f44:      	add	x0, x19, #0x130
   15f48:      	bl	0x17290 <fflush@plt>
   15f4c:      	bl	0x172a0 <abort@plt>
   15f50:      	bti	j
   15f54:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15f58:      	nop
   15f5c:      	adr	x1, 0x479e
   15f60:      	ldr	x19, [x19, #0x998]
   15f64:      	adrp	x2, 0x4000
   15f68:      	add	x2, x2, #0xfbc
   15f6c:      	adrp	x3, 0x5000
   15f70:      	add	x3, x3, #0xe1b
   15f74:      	add	x0, x19, #0x130
   15f78:      	bl	0x17280 <fprintf@plt>
   15f7c:      	add	x0, x19, #0x130
   15f80:      	bl	0x17290 <fflush@plt>
   15f84:      	bl	0x172a0 <abort@plt>
   15f88:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15f8c:      	nop
   15f90:      	adr	x1, 0x479e
   15f94:      	ldr	x19, [x19, #0x998]
   15f98:      	adrp	x2, 0x4000
   15f9c:      	add	x2, x2, #0xfbc
   15fa0:      	adrp	x3, 0x5000
   15fa4:      	add	x3, x3, #0x4d3
   15fa8:      	add	x0, x19, #0x130
   15fac:      	bl	0x17280 <fprintf@plt>
   15fb0:      	add	x0, x19, #0x130
   15fb4:      	bl	0x17290 <fflush@plt>
   15fb8:      	bl	0x172a0 <abort@plt>
   15fbc:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15fc0:      	nop
   15fc4:      	adr	x1, 0x479e
   15fc8:      	ldr	x19, [x19, #0x998]
   15fcc:      	adrp	x2, 0x5000
   15fd0:      	add	x2, x2, #0x28d
   15fd4:      	adrp	x3, 0x4000
   15fd8:      	add	x3, x3, #0xded
   15fdc:      	add	x0, x19, #0x130
   15fe0:      	bl	0x17280 <fprintf@plt>
   15fe4:      	add	x0, x19, #0x130
   15fe8:      	bl	0x17290 <fflush@plt>
   15fec:      	bl	0x172a0 <abort@plt>
   15ff0:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   15ff4:      	nop
   15ff8:      	adr	x1, 0x479e
   15ffc:      	ldr	x19, [x19, #0x998]
   16000:      	adrp	x2, 0x5000
   16004:      	add	x2, x2, #0x28d
   16008:      	adrp	x3, 0x4000
   1600c:      	add	x3, x3, #0xded
   16010:      	add	x0, x19, #0x130
   16014:      	bl	0x17280 <fprintf@plt>
   16018:      	add	x0, x19, #0x130
   1601c:      	bl	0x17290 <fflush@plt>
   16020:      	bl	0x172a0 <abort@plt>
   16024:      	paciasp
   16028:      	stp	x29, x30, [sp, #-0x60]!
   1602c:      	stp	x28, x27, [sp, #0x10]
   16030:      	stp	x26, x25, [sp, #0x20]
   16034:      	stp	x24, x23, [sp, #0x30]
   16038:      	stp	x22, x21, [sp, #0x40]
   1603c:      	stp	x20, x19, [sp, #0x50]
   16040:      	mov	x29, sp
   16044:      	sub	sp, sp, #0x6a0
   16048:      	mov	w21, w3
   1604c:      	mov	x19, x2
   16050:      	mov	x22, x1
   16054:      	mov	x20, x0
   16058:      	cbz	w3, 0x1607c <_Z20MTARMPMMusicGetSpeedPv+0xb380>
   1605c:      	ldp	x2, x3, [x19, #0x10]
   16060:      	add	x5, sp, #0x50
   16064:      	ldr	x0, [x20, #0x8]
   16068:      	add	x6, sp, #0x18
   1606c:      	mov	x1, x22
   16070:      	add	x4, x2, w21, uxtw
   16074:      	bl	0x1654c <_Z20MTARMPMMusicGetSpeedPv+0xb850>
   16078:      	tbnz	w0, #0x0, 0x16194 <_Z20MTARMPMMusicGetSpeedPv+0xb498>
   1607c:      	ldr	x2, [x19, #0x20]
   16080:      	cbz	x2, 0x160a0 <_Z20MTARMPMMusicGetSpeedPv+0xb3a4>
   16084:      	ldr	x0, [x20, #0x8]
   16088:      	ldr	w3, [x19, #0x28]
   1608c:      	add	x4, sp, #0x50
   16090:      	add	x5, sp, #0x18
   16094:      	mov	x1, x22
   16098:      	bl	0x16714 <_Z20MTARMPMMusicGetSpeedPv+0xba18>
   1609c:      	tbnz	w0, #0x0, 0x16194 <_Z20MTARMPMMusicGetSpeedPv+0xb498>
   160a0:      	ldr	x23, [x19]
   160a4:      	nop
   160a8:      	adr	x0, 0x1fea4 <__bss_start+0xbc>
   160ac:      	bl	0x172e0 <pthread_rwlock_rdlock@plt>
   160b0:      	adrp	x8, 0x1f000
   160b4:      	adrp	x9, 0x1f000
   160b8:      	ldr	x8, [x8, #0xdd0]
   160bc:      	ldr	x9, [x9, #0xdd8]
   160c0:      	cmp	x8, x9
   160c4:      	b.hs	0x16168 <_Z20MTARMPMMusicGetSpeedPv+0xb46c>
   160c8:      	cmn	x23, #0x1
   160cc:      	b.ne	0x160e0 <_Z20MTARMPMMusicGetSpeedPv+0xb3e4>
   160d0:      	b	0x16114 <_Z20MTARMPMMusicGetSpeedPv+0xb418>
   160d4:      	add	x8, x8, #0x20
   160d8:      	cmp	x8, x9
   160dc:      	b.hs	0x16168 <_Z20MTARMPMMusicGetSpeedPv+0xb46c>
   160e0:      	ldr	x10, [x8]
   160e4:      	cmp	x10, x23
   160e8:      	b.ne	0x160d4 <_Z20MTARMPMMusicGetSpeedPv+0xb3d8>
   160ec:      	ldr	x10, [x8, #0x8]
   160f0:      	cmp	x10, x22
   160f4:      	b.hi	0x160d4 <_Z20MTARMPMMusicGetSpeedPv+0xb3d8>
   160f8:      	ldr	x10, [x8, #0x10]
   160fc:      	cmp	x10, x22
   16100:      	b.ls	0x160d4 <_Z20MTARMPMMusicGetSpeedPv+0xb3d8>
   16104:      	b	0x1612c <_Z20MTARMPMMusicGetSpeedPv+0xb430>
   16108:      	add	x8, x8, #0x20
   1610c:      	cmp	x8, x9
   16110:      	b.hs	0x16168 <_Z20MTARMPMMusicGetSpeedPv+0xb46c>
   16114:      	ldr	x10, [x8, #0x8]
   16118:      	cmp	x10, x22
   1611c:      	b.hi	0x16108 <_Z20MTARMPMMusicGetSpeedPv+0xb40c>
   16120:      	ldr	x10, [x8, #0x10]
   16124:      	cmp	x10, x22
   16128:      	b.ls	0x16108 <_Z20MTARMPMMusicGetSpeedPv+0xb40c>
   1612c:      	ldr	x23, [x8, #0x18]
   16130:      	nop
   16134:      	adr	x0, 0x1fea4 <__bss_start+0xbc>
   16138:      	bl	0x172c0 <pthread_rwlock_unlock@plt>
   1613c:      	cbz	x23, 0x16174 <_Z20MTARMPMMusicGetSpeedPv+0xb478>
   16140:      	ldp	x2, x3, [x19, #0x10]
   16144:      	add	x5, sp, #0x50
   16148:      	ldr	x0, [x20, #0x8]
   1614c:      	add	x6, sp, #0x18
   16150:      	mov	x1, x22
   16154:      	mov	x4, x23
   16158:      	bl	0x1654c <_Z20MTARMPMMusicGetSpeedPv+0xb850>
   1615c:      	tbz	w0, #0x0, 0x16174 <_Z20MTARMPMMusicGetSpeedPv+0xb478>
   16160:      	mov	w24, wzr
   16164:      	b	0x16198 <_Z20MTARMPMMusicGetSpeedPv+0xb49c>
   16168:      	nop
   1616c:      	adr	x0, 0x1fea4 <__bss_start+0xbc>
   16170:      	bl	0x172c0 <pthread_rwlock_unlock@plt>
   16174:      	ldp	x2, x3, [x19, #0x10]
   16178:      	add	x5, sp, #0x50
   1617c:      	ldr	x0, [x20, #0x8]
   16180:      	add	x6, sp, #0x18
   16184:      	mov	x1, x22
   16188:      	mov	x4, xzr
   1618c:      	bl	0x1654c <_Z20MTARMPMMusicGetSpeedPv+0xb850>
   16190:      	tbz	w0, #0x0, 0x162d0 <_Z20MTARMPMMusicGetSpeedPv+0xb5d4>
   16194:      	mov	w24, #0x1               // =1
   16198:      	ldr	x25, [x19]
   1619c:      	add	x0, sp, #0x80
   161a0:      	mov	w1, wzr
   161a4:      	mov	w2, #0x618              // =1560
   161a8:      	bl	0x16e80 <memset@plt>
   161ac:      	ldr	x0, [x20, #0x8]
   161b0:      	add	x1, sp, #0x50
   161b4:      	add	x2, sp, #0x18
   161b8:      	add	x5, sp, #0x80
   161bc:      	mov	x3, x22
   161c0:      	mov	w4, #0x4                // =4
   161c4:      	bl	0x14188 <_Z20MTARMPMMusicGetSpeedPv+0x948c>
   161c8:      	tbz	w0, #0x0, 0x162d0 <_Z20MTARMPMMusicGetSpeedPv+0xb5d4>
   161cc:      	ldr	q0, [sp, #0x70]
   161d0:      	add	x8, x20, #0x220
   161d4:      	ldr	x9, [sp, #0x38]
   161d8:      	ldr	x22, [sp, #0x68]
   161dc:      	cmp	w21, #0x0
   161e0:      	mov	w0, #0x1                // =1
   161e4:      	stur	q0, [x8, #0x8]
   161e8:      	ldr	w8, [sp, #0x90]
   161ec:      	str	x9, [x20, #0x238]
   161f0:      	eor	w9, w24, #0x1
   161f4:      	str	x8, [x20, #0x240]
   161f8:      	mov	w8, #0x3000000          // =50331648
   161fc:      	str	w8, [x20, #0x250]
   16200:      	ldp	x23, x8, [sp, #0x50]
   16204:      	str	x22, [x20, #0x220]
   16208:      	str	xzr, [x20, #0x248]
   1620c:      	str	w8, [x20, #0x254]
   16210:      	csinc	w8, w9, wzr, eq
   16214:      	str	x23, [x20, #0x258]
   16218:      	str	x25, [x20, #0x260]
   1621c:      	tbnz	w8, #0x0, 0x162d4 <_Z20MTARMPMMusicGetSpeedPv+0xb5d8>
   16220:      	ldr	x8, [x19, #0x20]
   16224:      	cbnz	x8, 0x162d4 <_Z20MTARMPMMusicGetSpeedPv+0xb5d8>
   16228:      	ldr	x24, [x19]
   1622c:      	nop
   16230:      	adr	x0, 0x1fea4 <__bss_start+0xbc>
   16234:      	str	q0, [sp]
   16238:      	bl	0x172b0 <pthread_rwlock_wrlock@plt>
   1623c:      	adrp	x25, 0x1f000
   16240:      	adrp	x26, 0x1f000
   16244:      	ldr	x8, [x25, #0xdd8]
   16248:      	ldr	x9, [x26, #0xde0]
   1624c:      	cmp	x8, x9
   16250:      	b.lo	0x162a4 <_Z20MTARMPMMusicGetSpeedPv+0xb5a8>
   16254:      	adrp	x27, 0x1f000
   16258:      	ldr	x21, [x27, #0xdd0]
   1625c:      	sub	x19, x9, x21
   16260:      	lsl	x0, x19, #2
   16264:      	asr	x28, x19, #3
   16268:      	bl	0x17110 <malloc@plt>
   1626c:      	mov	x1, x21
   16270:      	mov	x2, x19
   16274:      	mov	x20, x0
   16278:      	bl	0x17240 <memcpy@plt>
   1627c:      	nop
   16280:      	adr	x8, 0x1fee0 <__bss_start+0xf8>
   16284:      	cmp	x21, x8
   16288:      	b.eq	0x16294 <_Z20MTARMPMMusicGetSpeedPv+0xb598>
   1628c:      	mov	x0, x21
   16290:      	bl	0x17100 <free@plt>
   16294:      	add	x9, x20, x28, lsl #5
   16298:      	add	x8, x20, x19
   1629c:      	str	x20, [x27, #0xdd0]
   162a0:      	str	x9, [x26, #0xde0]
   162a4:      	ldr	q0, [sp]
   162a8:      	stp	x24, x22, [x8]
   162ac:      	nop
   162b0:      	adr	x0, 0x1fea4 <__bss_start+0xbc>
   162b4:      	str	x23, [x8, #0x18]
   162b8:      	str	d0, [x8, #0x10]
   162bc:      	add	x8, x8, #0x20
   162c0:      	str	x8, [x25, #0xdd8]
   162c4:      	bl	0x172c0 <pthread_rwlock_unlock@plt>
   162c8:      	mov	w0, #0x1                // =1
   162cc:      	b	0x162d4 <_Z20MTARMPMMusicGetSpeedPv+0xb5d8>
   162d0:      	mov	w0, wzr
   162d4:      	add	sp, sp, #0x6a0
   162d8:      	ldp	x20, x19, [sp, #0x50]
   162dc:      	ldp	x22, x21, [sp, #0x40]
   162e0:      	ldp	x24, x23, [sp, #0x30]
   162e4:      	ldp	x26, x25, [sp, #0x20]
   162e8:      	ldp	x28, x27, [sp, #0x10]
   162ec:      	ldp	x29, x30, [sp], #0x60
   162f0:      	autiasp
   162f4:      	ret
   162f8:      	paciasp
   162fc:      	sub	sp, sp, #0x70
   16300:      	stp	x29, x30, [sp, #0x20]
   16304:      	str	x25, [sp, #0x30]
   16308:      	stp	x24, x23, [sp, #0x40]
   1630c:      	stp	x22, x21, [sp, #0x50]
   16310:      	stp	x20, x19, [sp, #0x60]
   16314:      	add	x29, sp, #0x20
   16318:      	ldrh	w21, [x0, #0x18]
   1631c:      	cbz	x21, 0x16338 <_Z20MTARMPMMusicGetSpeedPv+0xb63c>
   16320:      	ldr	x8, [x2, #0x10]
   16324:      	ldr	x22, [x0]
   16328:      	mov	x20, x0
   1632c:      	mov	x19, x2
   16330:      	cmp	x8, x22
   16334:      	b.hs	0x1635c <_Z20MTARMPMMusicGetSpeedPv+0xb660>
   16338:      	mov	w0, wzr
   1633c:      	ldp	x20, x19, [sp, #0x60]
   16340:      	ldr	x25, [sp, #0x30]
   16344:      	ldp	x22, x21, [sp, #0x50]
   16348:      	ldp	x24, x23, [sp, #0x40]
   1634c:      	ldp	x29, x30, [sp, #0x20]
   16350:      	add	sp, sp, #0x70
   16354:      	autiasp
   16358:      	ret
   1635c:      	ldr	x11, [x20, #0x10]
   16360:      	mov	x9, x21
   16364:      	mov	x10, x11
   16368:      	b	0x16378 <_Z20MTARMPMMusicGetSpeedPv+0xb67c>
   1636c:      	subs	x9, x9, #0x1
   16370:      	mov	x11, x10
   16374:      	b.eq	0x16338 <_Z20MTARMPMMusicGetSpeedPv+0xb63c>
   16378:      	ldr	w12, [x10], #0x38
   1637c:      	cmp	w12, #0x1
   16380:      	b.ne	0x1636c <_Z20MTARMPMMusicGetSpeedPv+0xb670>
   16384:      	ldr	x12, [x11, #0x10]
   16388:      	add	x12, x12, x22
   1638c:      	cmp	x8, x12
   16390:      	b.lo	0x1636c <_Z20MTARMPMMusicGetSpeedPv+0xb670>
   16394:      	ldr	x11, [x11, #0x28]
   16398:      	add	x13, x11, x12
   1639c:      	cmp	x8, x13
   163a0:      	b.hs	0x1636c <_Z20MTARMPMMusicGetSpeedPv+0xb670>
   163a4:      	ldr	x8, [x19, #0x8]
   163a8:      	mov	w9, #-0x1               // =-1
   163ac:      	mov	w25, #0xe550            // =58704
   163b0:      	add	x23, x21, x9
   163b4:      	mov	w24, #0x38              // =56
   163b8:      	movk	w25, #0x6474, lsl #16
   163bc:      	stp	x12, x11, [x8]
   163c0:      	b	0x163d4 <_Z20MTARMPMMusicGetSpeedPv+0xb6d8>
   163c4:      	sub	w21, w21, #0x1
   163c8:      	sub	x23, x23, #0x1
   163cc:      	and	w8, w21, #0xffff
   163d0:      	cbz	w8, 0x16338 <_Z20MTARMPMMusicGetSpeedPv+0xb63c>
   163d4:      	and	x8, x23, #0xffffffff
   163d8:      	ldr	x9, [x20, #0x10]
   163dc:      	umull	x10, w8, w24
   163e0:      	ldr	w10, [x9, x10]
   163e4:      	cmp	w10, w25
   163e8:      	b.ne	0x163c4 <_Z20MTARMPMMusicGetSpeedPv+0xb6c8>
   163ec:      	umaddl	x8, w8, w24, x9
   163f0:      	ldp	x0, x10, [x19]
   163f4:      	mov	x3, sp
   163f8:      	ldr	x9, [x8, #0x10]
   163fc:      	ldr	x8, [x8, #0x28]
   16400:      	add	x1, x9, x22
   16404:      	add	x2, x8, x1
   16408:      	stp	x1, x8, [x10, #0x20]
   1640c:      	bl	0x1642c <_Z20MTARMPMMusicGetSpeedPv+0xb730>
   16410:      	tbz	w0, #0x0, 0x163c4 <_Z20MTARMPMMusicGetSpeedPv+0xb6c8>
   16414:      	ldr	x8, [sp]
   16418:      	ldr	x9, [x19, #0x8]
   1641c:      	mov	x10, #-0x1              // =-1
   16420:      	mov	w0, #0x1                // =1
   16424:      	stp	x8, x10, [x9, #0x10]
   16428:      	b	0x1633c <_Z20MTARMPMMusicGetSpeedPv+0xb640>
   1642c:      	paciasp
   16430:      	stp	x29, x30, [sp, #-0x40]!
   16434:      	str	x23, [sp, #0x10]
   16438:      	stp	x22, x21, [sp, #0x20]
   1643c:      	stp	x20, x19, [sp, #0x30]
   16440:      	mov	x29, sp
   16444:      	mov	x20, x3
   16448:      	sub	x3, x2, x1
   1644c:      	mov	x19, x1
   16450:      	cmp	x3, #0x3
   16454:      	b.hi	0x16480 <_Z20MTARMPMMusicGetSpeedPv+0xb784>
   16458:      	cmp	x2, x19
   1645c:      	b.eq	0x16508 <_Z20MTARMPMMusicGetSpeedPv+0xb80c>
   16460:      	adrp	x20, 0x1b000 <syscall@plt+0x3d00>
   16464:      	adrp	x1, 0x5000
   16468:      	add	x1, x1, #0x5a7
   1646c:      	ldr	x20, [x20, #0x998]
   16470:      	mov	x2, x19
   16474:      	add	x0, x20, #0x130
   16478:      	bl	0x17280 <fprintf@plt>
   1647c:      	b	0x16500 <_Z20MTARMPMMusicGetSpeedPv+0xb804>
   16480:      	ldrb	w8, [x19]
   16484:      	cmp	w8, #0x1
   16488:      	b.ne	0x164e0 <_Z20MTARMPMMusicGetSpeedPv+0xb7e4>
   1648c:      	add	x8, x19, #0x4
   16490:      	ldrb	w21, [x19, #0x2]
   16494:      	ldrb	w3, [x19, #0x1]
   16498:      	str	x8, [x29, #0x18]
   1649c:      	add	x1, x29, #0x18
   164a0:      	mov	x4, x19
   164a4:      	ldrb	w8, [x19, #0x3]
   164a8:      	mov	x23, x0
   164ac:      	mov	x22, x2
   164b0:      	strb	w8, [x20, #0x18]
   164b4:      	bl	0x15114 <_Z20MTARMPMMusicGetSpeedPv+0xa418>
   164b8:      	cmp	w21, #0xff
   164bc:      	str	x0, [x20]
   164c0:      	b.eq	0x16524 <_Z20MTARMPMMusicGetSpeedPv+0xb828>
   164c4:      	add	x1, x29, #0x18
   164c8:      	mov	x0, x23
   164cc:      	mov	x2, x22
   164d0:      	mov	w3, w21
   164d4:      	mov	x4, x19
   164d8:      	bl	0x15114 <_Z20MTARMPMMusicGetSpeedPv+0xa418>
   164dc:      	b	0x16528 <_Z20MTARMPMMusicGetSpeedPv+0xb82c>
   164e0:      	adrp	x20, 0x1b000 <syscall@plt+0x3d00>
   164e4:      	adrp	x1, 0x4000
   164e8:      	add	x1, x1, #0xd40
   164ec:      	ldr	x20, [x20, #0x998]
   164f0:      	mov	w2, w8
   164f4:      	mov	x3, x19
   164f8:      	add	x0, x20, #0x130
   164fc:      	bl	0x17280 <fprintf@plt>
   16500:      	add	x0, x20, #0x130
   16504:      	bl	0x17290 <fflush@plt>
   16508:      	mov	w0, wzr
   1650c:      	ldp	x20, x19, [sp, #0x30]
   16510:      	ldr	x23, [sp, #0x10]
   16514:      	ldp	x22, x21, [sp, #0x20]
   16518:      	ldp	x29, x30, [sp], #0x40
   1651c:      	autiasp
   16520:      	ret
   16524:      	mov	x0, xzr
   16528:      	ldr	x8, [x29, #0x18]
   1652c:      	stp	x0, x8, [x20, #0x8]
   16530:      	mov	w0, #0x1                // =1
   16534:      	ldp	x20, x19, [sp, #0x30]
   16538:      	ldr	x23, [sp, #0x10]
   1653c:      	ldp	x22, x21, [sp, #0x20]
   16540:      	ldp	x29, x30, [sp], #0x40
   16544:      	autiasp
   16548:      	ret
   1654c:      	paciasp
   16550:      	sub	sp, sp, #0x70
   16554:      	stp	x29, x30, [sp, #0x10]
   16558:      	stp	x28, x27, [sp, #0x20]
   1655c:      	stp	x26, x25, [sp, #0x30]
   16560:      	stp	x24, x23, [sp, #0x40]
   16564:      	stp	x22, x21, [sp, #0x50]
   16568:      	stp	x20, x19, [sp, #0x60]
   1656c:      	add	x29, sp, #0x10
   16570:      	cmp	x4, #0x0
   16574:      	add	x8, x3, x2
   16578:      	csel	x22, x2, x4, eq
   1657c:      	cmn	x3, #0x1
   16580:      	csinv	x27, x8, xzr, ne
   16584:      	str	x22, [sp, #0x8]
   16588:      	cmp	x22, x27
   1658c:      	b.hs	0x166d0 <_Z20MTARMPMMusicGetSpeedPv+0xb9d4>
   16590:      	mov	x21, x6
   16594:      	mov	x19, x5
   16598:      	mov	x23, x2
   1659c:      	mov	x24, x1
   165a0:      	mov	x20, x0
   165a4:      	b	0x165b4 <_Z20MTARMPMMusicGetSpeedPv+0xb8b8>
   165a8:      	cmp	x22, x27
   165ac:      	str	x22, [sp, #0x8]
   165b0:      	b.hs	0x166d0 <_Z20MTARMPMMusicGetSpeedPv+0xb9d4>
   165b4:      	mov	x8, x22
   165b8:      	mov	x26, x22
   165bc:      	ldr	w9, [x8], #0x4
   165c0:      	str	x8, [sp, #0x8]
   165c4:      	cmn	w9, #0x1
   165c8:      	b.ne	0x165d8 <_Z20MTARMPMMusicGetSpeedPv+0xb8dc>
   165cc:      	ldur	x9, [x26, #0x4]
   165d0:      	add	x8, x26, #0xc
   165d4:      	str	x8, [sp, #0x8]
   165d8:      	cbz	x9, 0x166d0 <_Z20MTARMPMMusicGetSpeedPv+0xb9d4>
   165dc:      	ldr	w10, [x8]
   165e0:      	add	x22, x8, x9
   165e4:      	cbz	w10, 0x165a8 <_Z20MTARMPMMusicGetSpeedPv+0xb8ac>
   165e8:      	sub	x1, x8, x10
   165ec:      	cmp	x1, x23
   165f0:      	b.lo	0x165a8 <_Z20MTARMPMMusicGetSpeedPv+0xb8ac>
   165f4:      	cmp	x1, x27
   165f8:      	b.hs	0x165a8 <_Z20MTARMPMMusicGetSpeedPv+0xb8ac>
   165fc:      	mov	x0, x20
   16600:      	mov	x2, x21
   16604:      	bl	0x132bc <_Z20MTARMPMMusicGetSpeedPv+0x85c0>
   16608:      	cbnz	x0, 0x165a8 <_Z20MTARMPMMusicGetSpeedPv+0xb8ac>
   1660c:      	ldr	x8, [sp, #0x8]
   16610:      	ldrb	w3, [x21, #0x18]
   16614:      	add	x1, sp, #0x8
   16618:      	mov	x0, x20
   1661c:      	mov	x2, x22
   16620:      	mov	x4, xzr
   16624:      	add	x8, x8, #0x4
   16628:      	str	x8, [sp, #0x8]
   1662c:      	bl	0x15114 <_Z20MTARMPMMusicGetSpeedPv+0xa418>
   16630:      	ldrb	w8, [x21, #0x18]
   16634:      	mov	x25, x0
   16638:      	add	x1, sp, #0x8
   1663c:      	mov	x0, x20
   16640:      	mov	x2, x22
   16644:      	mov	x4, xzr
   16648:      	and	w3, w8, #0xf
   1664c:      	bl	0x15114 <_Z20MTARMPMMusicGetSpeedPv+0xa418>
   16650:      	cmp	x25, x24
   16654:      	b.hs	0x165a8 <_Z20MTARMPMMusicGetSpeedPv+0xb8ac>
   16658:      	add	x28, x0, x25
   1665c:      	cmp	x28, x24
   16660:      	b.lo	0x165a8 <_Z20MTARMPMMusicGetSpeedPv+0xb8ac>
   16664:      	ldrb	w8, [x21, #0x31]
   16668:      	str	xzr, [x19, #0x28]
   1666c:      	cbz	w8, 0x166f8 <_Z20MTARMPMMusicGetSpeedPv+0xb9fc>
   16670:      	add	x0, sp, #0x8
   16674:      	mov	x1, x22
   16678:      	bl	0x154a0 <_Z20MTARMPMMusicGetSpeedPv+0xa7a4>
   1667c:      	ldrb	w8, [x21, #0x19]
   16680:      	ldr	x24, [sp, #0x8]
   16684:      	cmp	w8, #0xff
   16688:      	add	x23, x24, x0
   1668c:      	b.eq	0x166fc <_Z20MTARMPMMusicGetSpeedPv+0xba00>
   16690:      	add	x1, sp, #0x8
   16694:      	and	w3, w8, #0xf
   16698:      	mov	x0, x20
   1669c:      	mov	x2, x22
   166a0:      	mov	x4, xzr
   166a4:      	bl	0x15114 <_Z20MTARMPMMusicGetSpeedPv+0xa418>
   166a8:      	cbz	x0, 0x166fc <_Z20MTARMPMMusicGetSpeedPv+0xba00>
   166ac:      	ldrb	w3, [x21, #0x19]
   166b0:      	add	x1, sp, #0x8
   166b4:      	mov	x0, x20
   166b8:      	mov	x2, x22
   166bc:      	mov	x4, xzr
   166c0:      	str	x24, [sp, #0x8]
   166c4:      	bl	0x15114 <_Z20MTARMPMMusicGetSpeedPv+0xa418>
   166c8:      	str	x0, [x19, #0x28]
   166cc:      	b	0x166fc <_Z20MTARMPMMusicGetSpeedPv+0xba00>
   166d0:      	mov	w0, wzr
   166d4:      	ldp	x20, x19, [sp, #0x60]
   166d8:      	ldp	x22, x21, [sp, #0x50]
   166dc:      	ldp	x24, x23, [sp, #0x40]
   166e0:      	ldp	x26, x25, [sp, #0x30]
   166e4:      	ldp	x28, x27, [sp, #0x20]
   166e8:      	ldp	x29, x30, [sp, #0x10]
   166ec:      	add	sp, sp, #0x70
   166f0:      	autiasp
   166f4:      	ret
   166f8:      	ldr	x23, [sp, #0x8]
   166fc:      	sub	x8, x22, x26
   16700:      	stp	x23, x25, [x19, #0x10]
   16704:      	mov	w0, #0x1                // =1
   16708:      	stp	x26, x8, [x19]
   1670c:      	str	x28, [x19, #0x20]
   16710:      	b	0x166d4 <_Z20MTARMPMMusicGetSpeedPv+0xb9d8>
   16714:      	paciasp
   16718:      	sub	sp, sp, #0xa0
   1671c:      	stp	x29, x30, [sp, #0x40]
   16720:      	stp	x28, x27, [sp, #0x50]
   16724:      	stp	x26, x25, [sp, #0x60]
   16728:      	stp	x24, x23, [sp, #0x70]
   1672c:      	stp	x22, x21, [sp, #0x80]
   16730:      	stp	x20, x19, [sp, #0x90]
   16734:      	add	x29, sp, #0x40
   16738:      	add	x24, x2, w3, uxtw
   1673c:      	mov	x23, x2
   16740:      	mov	x20, x1
   16744:      	add	x3, sp, #0x20
   16748:      	mov	x1, x2
   1674c:      	mov	x21, x5
   16750:      	mov	x2, x24
   16754:      	mov	x19, x4
   16758:      	mov	x22, x0
   1675c:      	bl	0x1642c <_Z20MTARMPMMusicGetSpeedPv+0xb730>
   16760:      	tbz	w0, #0x0, 0x16854 <_Z20MTARMPMMusicGetSpeedPv+0xbb58>
   16764:      	ldr	x8, [sp, #0x28]
   16768:      	cbz	x8, 0x16854 <_Z20MTARMPMMusicGetSpeedPv+0xbb58>
   1676c:      	ldrb	w0, [sp, #0x38]
   16770:      	stp	x21, x19, [sp, #0x8]
   16774:      	bl	0x1687c <_Z20MTARMPMMusicGetSpeedPv+0xbb80>
   16778:      	ldr	x27, [sp, #0x28]
   1677c:      	mov	x25, x0
   16780:      	mov	x26, xzr
   16784:      	cmp	x27, #0x1
   16788:      	b.ls	0x167d4 <_Z20MTARMPMMusicGetSpeedPv+0xbad8>
   1678c:      	lsr	x21, x27, #1
   16790:      	ldr	x8, [sp, #0x30]
   16794:      	ldrb	w3, [sp, #0x38]
   16798:      	add	x1, sp, #0x18
   1679c:      	mov	x0, x22
   167a0:      	mov	x2, x24
   167a4:      	add	x19, x21, x26
   167a8:      	mov	x4, x23
   167ac:      	mul	x28, x19, x25
   167b0:      	add	x8, x8, x28
   167b4:      	str	x8, [sp, #0x18]
   167b8:      	bl	0x15114 <_Z20MTARMPMMusicGetSpeedPv+0xa418>
   167bc:      	sub	x8, x27, x21
   167c0:      	cmp	x0, x20
   167c4:      	csel	x26, x26, x19, hs
   167c8:      	csel	x27, x21, x8, hs
   167cc:      	b.ne	0x16784 <_Z20MTARMPMMusicGetSpeedPv+0xba88>
   167d0:      	b	0x167d8 <_Z20MTARMPMMusicGetSpeedPv+0xbadc>
   167d4:      	mul	x28, x26, x25
   167d8:      	ldr	x8, [sp, #0x30]
   167dc:      	ldrb	w25, [sp, #0x38]
   167e0:      	add	x1, sp, #0x18
   167e4:      	mov	x0, x22
   167e8:      	mov	x2, x24
   167ec:      	mov	x4, x23
   167f0:      	add	x8, x8, x28
   167f4:      	mov	w3, w25
   167f8:      	str	x8, [sp, #0x18]
   167fc:      	bl	0x15114 <_Z20MTARMPMMusicGetSpeedPv+0xa418>
   16800:      	add	x1, sp, #0x18
   16804:      	mov	x0, x22
   16808:      	mov	x2, x24
   1680c:      	mov	w3, w25
   16810:      	mov	x4, x23
   16814:      	bl	0x15114 <_Z20MTARMPMMusicGetSpeedPv+0xa418>
   16818:      	ldp	x3, x19, [sp, #0x8]
   1681c:      	mov	x1, x0
   16820:      	mov	x0, x22
   16824:      	mov	w4, wzr
   16828:      	mov	x2, x19
   1682c:      	bl	0x1312c <_Z20MTARMPMMusicGetSpeedPv+0x8430>
   16830:      	cbnz	x0, 0x16854 <_Z20MTARMPMMusicGetSpeedPv+0xbb58>
   16834:      	ldr	x8, [x19, #0x18]
   16838:      	cmp	x8, x20
   1683c:      	b.hi	0x16854 <_Z20MTARMPMMusicGetSpeedPv+0xbb58>
   16840:      	ldr	x8, [x19, #0x20]
   16844:      	cmp	x8, x20
   16848:      	b.ls	0x16854 <_Z20MTARMPMMusicGetSpeedPv+0xbb58>
   1684c:      	mov	w0, #0x1                // =1
   16850:      	b	0x16858 <_Z20MTARMPMMusicGetSpeedPv+0xbb5c>
   16854:      	mov	w0, wzr
   16858:      	ldp	x20, x19, [sp, #0x90]
   1685c:      	ldp	x22, x21, [sp, #0x80]
   16860:      	ldp	x24, x23, [sp, #0x70]
   16864:      	ldp	x26, x25, [sp, #0x60]
   16868:      	ldp	x28, x27, [sp, #0x50]
   1686c:      	ldp	x29, x30, [sp, #0x40]
   16870:      	add	sp, sp, #0xa0
   16874:      	autiasp
   16878:      	ret
   1687c:      	paciasp
   16880:      	stp	x29, x30, [sp, #-0x20]!
   16884:      	str	x19, [sp, #0x10]
   16888:      	mov	x29, sp
   1688c:      	and	w8, w0, #0xf
   16890:      	mov	w0, #0x4                // =4
   16894:      	cmp	w8, #0x8
   16898:      	b.gt	0x168b8 <_Z20MTARMPMMusicGetSpeedPv+0xbbbc>
   1689c:      	cmp	w8, #0x2
   168a0:      	b.le	0x168f8 <_Z20MTARMPMMusicGetSpeedPv+0xbbfc>
   168a4:      	cmp	w8, #0x3
   168a8:      	b.eq	0x168d0 <_Z20MTARMPMMusicGetSpeedPv+0xbbd4>
   168ac:      	cmp	w8, #0x4
   168b0:      	b.eq	0x168e4 <_Z20MTARMPMMusicGetSpeedPv+0xbbe8>
   168b4:      	b	0x16904 <_Z20MTARMPMMusicGetSpeedPv+0xbc08>
   168b8:      	cmp	w8, #0xa
   168bc:      	b.le	0x16938 <_Z20MTARMPMMusicGetSpeedPv+0xbc3c>
   168c0:      	cmp	w8, #0xc
   168c4:      	b.eq	0x168e4 <_Z20MTARMPMMusicGetSpeedPv+0xbbe8>
   168c8:      	cmp	w8, #0xb
   168cc:      	b.ne	0x16904 <_Z20MTARMPMMusicGetSpeedPv+0xbc08>
   168d0:      	mov	w0, #0x8                // =8
   168d4:      	ldr	x19, [sp, #0x10]
   168d8:      	ldp	x29, x30, [sp], #0x20
   168dc:      	autiasp
   168e0:      	ret
   168e4:      	mov	w0, #0x10               // =16
   168e8:      	ldr	x19, [sp, #0x10]
   168ec:      	ldp	x29, x30, [sp], #0x20
   168f0:      	autiasp
   168f4:      	ret
   168f8:      	b.eq	0x168d4 <_Z20MTARMPMMusicGetSpeedPv+0xbbd8>
   168fc:      	cmp	w8, #0x1
   16900:      	b.eq	0x16944 <_Z20MTARMPMMusicGetSpeedPv+0xbc48>
   16904:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   16908:      	nop
   1690c:      	adr	x1, 0x479e
   16910:      	ldr	x19, [x19, #0x998]
   16914:      	adrp	x2, 0x4000
   16918:      	add	x2, x2, #0xe32
   1691c:      	adrp	x3, 0x5000
   16920:      	add	x3, x3, #0x9d6
   16924:      	add	x0, x19, #0x130
   16928:      	bl	0x17280 <fprintf@plt>
   1692c:      	add	x0, x19, #0x130
   16930:      	bl	0x17290 <fflush@plt>
   16934:      	bl	0x172a0 <abort@plt>
   16938:      	b.eq	0x168d4 <_Z20MTARMPMMusicGetSpeedPv+0xbbd8>
   1693c:      	cmp	w8, #0x9
   16940:      	b.ne	0x16904 <_Z20MTARMPMMusicGetSpeedPv+0xbc08>
   16944:      	adrp	x19, 0x1b000 <syscall@plt+0x3d00>
   16948:      	nop
   1694c:      	adr	x1, 0x479e
   16950:      	ldr	x19, [x19, #0x998]
   16954:      	adrp	x2, 0x4000
   16958:      	add	x2, x2, #0xe32
   1695c:      	adrp	x3, 0x4000
   16960:      	add	x3, x3, #0xb83
   16964:      	add	x0, x19, #0x130
   16968:      	bl	0x17280 <fprintf@plt>
   1696c:      	add	x0, x19, #0x130
   16970:      	bl	0x17290 <fflush@plt>
   16974:      	bl	0x172a0 <abort@plt>
   16978:      	bti	c
   1697c:      	add	w8, w0, #0x2
   16980:      	cmp	w8, #0x61
   16984:      	b.hi	0x1699c <_Z20MTARMPMMusicGetSpeedPv+0xbca0>
   16988:      	nop
   1698c:      	adr	x9, 0x6114 <_ZTSSt9bad_alloc+0x1d3>
   16990:      	ldrsw	x8, [x9, w8, uxtw #2]
   16994:      	add	x0, x9, x8
   16998:      	ret
   1699c:      	adrp	x0, 0x5000
   169a0:      	add	x0, x0, #0x94a
   169a4:      	ret
   169a8:      	bti	c
   169ac:      	ldp	x2, x3, [x0, #0x10]
   169b0:      	ldp	x4, x5, [x0, #0x20]
   169b4:      	ldp	x6, x7, [x0, #0x30]
   169b8:      	ldp	x8, x9, [x0, #0x40]
   169bc:      	ldp	x10, x11, [x0, #0x50]
   169c0:      	ldp	x12, x13, [x0, #0x60]
   169c4:      	ldp	x14, x15, [x0, #0x70]
   169c8:      	ldp	x18, x19, [x0, #0x90]
   169cc:      	ldp	x20, x21, [x0, #0xa0]
   169d0:      	ldp	x22, x23, [x0, #0xb0]
   169d4:      	ldp	x24, x25, [x0, #0xc0]
   169d8:      	ldp	x26, x27, [x0, #0xd0]
   169dc:      	ldp	x28, x29, [x0, #0xe0]
   169e0:      	ldr	x30, [x0, #0x100]
   169e4:      	ldp	d0, d1, [x0, #0x110]
   169e8:      	ldp	d2, d3, [x0, #0x120]
   169ec:      	ldp	d4, d5, [x0, #0x130]
   169f0:      	ldp	d6, d7, [x0, #0x140]
   169f4:      	ldp	d8, d9, [x0, #0x150]
   169f8:      	ldp	d10, d11, [x0, #0x160]
   169fc:      	ldp	d12, d13, [x0, #0x170]
   16a00:      	ldp	d14, d15, [x0, #0x180]
   16a04:      	ldp	d16, d17, [x0, #0x190]
   16a08:      	ldp	d18, d19, [x0, #0x1a0]
   16a0c:      	ldp	d20, d21, [x0, #0x1b0]
   16a10:      	ldp	d22, d23, [x0, #0x1c0]
   16a14:      	ldp	d24, d25, [x0, #0x1d0]
   16a18:      	ldp	d26, d27, [x0, #0x1e0]
   16a1c:      	ldp	d28, d29, [x0, #0x1f0]
   16a20:      	ldr	d30, [x0, #0x200]
   16a24:      	ldr	d31, [x0, #0x208]
   16a28:      	ldr	x16, [x0, #0xf8]
   16a2c:      	ldp	x0, x1, [x0]
   16a30:      	mov	sp, x16
   16a34:      	ret
   16a38:      	bti	c
   16a3c:      	stp	x0, x1, [x0]
   16a40:      	stp	x2, x3, [x0, #0x10]
   16a44:      	stp	x4, x5, [x0, #0x20]
   16a48:      	stp	x6, x7, [x0, #0x30]
   16a4c:      	stp	x8, x9, [x0, #0x40]
   16a50:      	stp	x10, x11, [x0, #0x50]
   16a54:      	stp	x12, x13, [x0, #0x60]
   16a58:      	stp	x14, x15, [x0, #0x70]
   16a5c:      	stp	x16, x17, [x0, #0x80]
   16a60:      	stp	x18, x19, [x0, #0x90]
   16a64:      	stp	x20, x21, [x0, #0xa0]
   16a68:      	stp	x22, x23, [x0, #0xb0]
   16a6c:      	stp	x24, x25, [x0, #0xc0]
   16a70:      	stp	x26, x27, [x0, #0xd0]
   16a74:      	stp	x28, x29, [x0, #0xe0]
   16a78:      	str	x30, [x0, #0xf0]
   16a7c:      	mov	x1, sp
   16a80:      	str	x1, [x0, #0xf8]
   16a84:      	str	x30, [x0, #0x100]
   16a88:      	stp	d0, d1, [x0, #0x110]
   16a8c:      	stp	d2, d3, [x0, #0x120]
   16a90:      	stp	d4, d5, [x0, #0x130]
   16a94:      	stp	d6, d7, [x0, #0x140]
   16a98:      	stp	d8, d9, [x0, #0x150]
   16a9c:      	stp	d10, d11, [x0, #0x160]
   16aa0:      	stp	d12, d13, [x0, #0x170]
   16aa4:      	stp	d14, d15, [x0, #0x180]
   16aa8:      	stp	d16, d17, [x0, #0x190]
   16aac:      	stp	d18, d19, [x0, #0x1a0]
   16ab0:      	stp	d20, d21, [x0, #0x1b0]
   16ab4:      	stp	d22, d23, [x0, #0x1c0]
   16ab8:      	stp	d24, d25, [x0, #0x1d0]
   16abc:      	stp	d26, d27, [x0, #0x1e0]
   16ac0:      	stp	d28, d29, [x0, #0x1f0]
   16ac4:      	str	d30, [x0, #0x200]
   16ac8:      	str	d31, [x0, #0x208]
   16acc:      	mov	x0, #0x0                // =0
   16ad0:      	ret

Disassembly of section .plt:

0000000000016ae0 <.plt>:
   16ae0:      	stp	x16, x30, [sp, #-0x10]!
   16ae4:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16ae8:      	ldr	x17, [x16, #0x9b0]
   16aec:      	add	x16, x16, #0x9b0
   16af0:      	br	x17
   16af4:      	nop
   16af8:      	nop
   16afc:      	nop

0000000000016b00 <__cxa_finalize@plt>:
   16b00:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16b04:      	ldr	x17, [x16, #0x9b8]
   16b08:      	add	x16, x16, #0x9b8
   16b0c:      	br	x17

0000000000016b10 <__cxa_atexit@plt>:
   16b10:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16b14:      	ldr	x17, [x16, #0x9c0]
   16b18:      	add	x16, x16, #0x9c0
   16b1c:      	br	x17

0000000000016b20 <__register_atfork@plt>:
   16b20:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16b24:      	ldr	x17, [x16, #0x9c8]
   16b28:      	add	x16, x16, #0x9c8
   16b2c:      	br	x17

0000000000016b30 <_ZNSt6__ndk119__shared_weak_count14__release_weakEv@plt>:
   16b30:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16b34:      	ldr	x17, [x16, #0x9d0]
   16b38:      	add	x16, x16, #0x9d0
   16b3c:      	br	x17

0000000000016b40 <__stack_chk_fail@plt>:
   16b40:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16b44:      	ldr	x17, [x16, #0x9d8]
   16b48:      	add	x16, x16, #0x9d8
   16b4c:      	br	x17

0000000000016b50 <_Znwm@plt>:
   16b50:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16b54:      	ldr	x17, [x16, #0x9e0]
   16b58:      	add	x16, x16, #0x9e0
   16b5c:      	br	x17

0000000000016b60 <_ZdlPv@plt>:
   16b60:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16b64:      	ldr	x17, [x16, #0x9e8]
   16b68:      	add	x16, x16, #0x9e8
   16b6c:      	br	x17

0000000000016b70 <strlen@plt>:
   16b70:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16b74:      	ldr	x17, [x16, #0x9f0]
   16b78:      	add	x16, x16, #0x9f0
   16b7c:      	br	x17

0000000000016b80 <memmove@plt>:
   16b80:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16b84:      	ldr	x17, [x16, #0x9f8]
   16b88:      	add	x16, x16, #0x9f8
   16b8c:      	br	x17

0000000000016b90 <__cxa_begin_catch@plt>:
   16b90:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16b94:      	ldr	x17, [x16, #0xa00]
   16b98:      	add	x16, x16, #0xa00
   16b9c:      	br	x17

0000000000016ba0 <_ZSt9terminatev@plt>:
   16ba0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16ba4:      	ldr	x17, [x16, #0xa08]
   16ba8:      	add	x16, x16, #0xa08
   16bac:      	br	x17

0000000000016bb0 <__cxa_allocate_exception@plt>:
   16bb0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16bb4:      	ldr	x17, [x16, #0xa10]
   16bb8:      	add	x16, x16, #0xa10
   16bbc:      	br	x17

0000000000016bc0 <__cxa_throw@plt>:
   16bc0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16bc4:      	ldr	x17, [x16, #0xa18]
   16bc8:      	add	x16, x16, #0xa18
   16bcc:      	br	x17

0000000000016bd0 <__cxa_free_exception@plt>:
   16bd0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16bd4:      	ldr	x17, [x16, #0xa20]
   16bd8:      	add	x16, x16, #0xa20
   16bdc:      	br	x17

0000000000016be0 <_ZNSt11logic_errorC2EPKc@plt>:
   16be0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16be4:      	ldr	x17, [x16, #0xa28]
   16be8:      	add	x16, x16, #0xa28
   16bec:      	br	x17

0000000000016bf0 <_ZNSt6__ndk118condition_variableD1Ev@plt>:
   16bf0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16bf4:      	ldr	x17, [x16, #0xa30]
   16bf8:      	add	x16, x16, #0xa30
   16bfc:      	br	x17

0000000000016c00 <_ZNSt6__ndk15mutexD1Ev@plt>:
   16c00:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16c04:      	ldr	x17, [x16, #0xa38]
   16c08:      	add	x16, x16, #0xa38
   16c0c:      	br	x17

0000000000016c10 <_ZNSt6__ndk15mutex4lockEv@plt>:
   16c10:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16c14:      	ldr	x17, [x16, #0xa40]
   16c18:      	add	x16, x16, #0xa40
   16c1c:      	br	x17

0000000000016c20 <_ZNSt6__ndk118condition_variable10notify_allEv@plt>:
   16c20:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16c24:      	ldr	x17, [x16, #0xa48]
   16c28:      	add	x16, x16, #0xa48
   16c2c:      	br	x17

0000000000016c30 <_ZNSt6__ndk15mutex6unlockEv@plt>:
   16c30:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16c34:      	ldr	x17, [x16, #0xa50]
   16c38:      	add	x16, x16, #0xa50
   16c3c:      	br	x17

0000000000016c40 <_ZNSt6__ndk16thread4joinEv@plt>:
   16c40:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16c44:      	ldr	x17, [x16, #0xa58]
   16c48:      	add	x16, x16, #0xa58
   16c4c:      	br	x17

0000000000016c50 <swr_free@plt>:
   16c50:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16c54:      	ldr	x17, [x16, #0xa60]
   16c58:      	add	x16, x16, #0xa60
   16c5c:      	br	x17

0000000000016c60 <avcodec_close@plt>:
   16c60:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16c64:      	ldr	x17, [x16, #0xa68]
   16c68:      	add	x16, x16, #0xa68
   16c6c:      	br	x17

0000000000016c70 <avformat_close_input@plt>:
   16c70:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16c74:      	ldr	x17, [x16, #0xa70]
   16c78:      	add	x16, x16, #0xa70
   16c7c:      	br	x17

0000000000016c80 <av_freep@plt>:
   16c80:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16c84:      	ldr	x17, [x16, #0xa78]
   16c88:      	add	x16, x16, #0xa78
   16c8c:      	br	x17

0000000000016c90 <avformat_alloc_context@plt>:
   16c90:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16c94:      	ldr	x17, [x16, #0xa80]
   16c98:      	add	x16, x16, #0xa80
   16c9c:      	br	x17

0000000000016ca0 <avformat_open_input@plt>:
   16ca0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16ca4:      	ldr	x17, [x16, #0xa88]
   16ca8:      	add	x16, x16, #0xa88
   16cac:      	br	x17

0000000000016cb0 <av_format_inject_global_side_data@plt>:
   16cb0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16cb4:      	ldr	x17, [x16, #0xa90]
   16cb8:      	add	x16, x16, #0xa90
   16cbc:      	br	x17

0000000000016cc0 <avformat_find_stream_info@plt>:
   16cc0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16cc4:      	ldr	x17, [x16, #0xa98]
   16cc8:      	add	x16, x16, #0xa98
   16ccc:      	br	x17

0000000000016cd0 <av_log@plt>:
   16cd0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16cd4:      	ldr	x17, [x16, #0xaa0]
   16cd8:      	add	x16, x16, #0xaa0
   16cdc:      	br	x17

0000000000016ce0 <av_strerror@plt>:
   16ce0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16ce4:      	ldr	x17, [x16, #0xaa8]
   16ce8:      	add	x16, x16, #0xaa8
   16cec:      	br	x17

0000000000016cf0 <strerror@plt>:
   16cf0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16cf4:      	ldr	x17, [x16, #0xab0]
   16cf8:      	add	x16, x16, #0xab0
   16cfc:      	br	x17

0000000000016d00 <strcmp@plt>:
   16d00:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16d04:      	ldr	x17, [x16, #0xab8]
   16d08:      	add	x16, x16, #0xab8
   16d0c:      	br	x17

0000000000016d10 <avformat_seek_file@plt>:
   16d10:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16d14:      	ldr	x17, [x16, #0xac0]
   16d18:      	add	x16, x16, #0xac0
   16d1c:      	br	x17

0000000000016d20 <av_dump_format@plt>:
   16d20:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16d24:      	ldr	x17, [x16, #0xac8]
   16d28:      	add	x16, x16, #0xac8
   16d2c:      	br	x17

0000000000016d30 <av_find_best_stream@plt>:
   16d30:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16d34:      	ldr	x17, [x16, #0xad0]
   16d38:      	add	x16, x16, #0xad0
   16d3c:      	br	x17

0000000000016d40 <avcodec_alloc_context3@plt>:
   16d40:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16d44:      	ldr	x17, [x16, #0xad8]
   16d48:      	add	x16, x16, #0xad8
   16d4c:      	br	x17

0000000000016d50 <avcodec_parameters_to_context@plt>:
   16d50:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16d54:      	ldr	x17, [x16, #0xae0]
   16d58:      	add	x16, x16, #0xae0
   16d5c:      	br	x17

0000000000016d60 <avcodec_find_decoder@plt>:
   16d60:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16d64:      	ldr	x17, [x16, #0xae8]
   16d68:      	add	x16, x16, #0xae8
   16d6c:      	br	x17

0000000000016d70 <av_opt_set_int@plt>:
   16d70:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16d74:      	ldr	x17, [x16, #0xaf0]
   16d78:      	add	x16, x16, #0xaf0
   16d7c:      	br	x17

0000000000016d80 <av_dict_get@plt>:
   16d80:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16d84:      	ldr	x17, [x16, #0xaf8]
   16d88:      	add	x16, x16, #0xaf8
   16d8c:      	br	x17

0000000000016d90 <av_dict_set@plt>:
   16d90:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16d94:      	ldr	x17, [x16, #0xb00]
   16d98:      	add	x16, x16, #0xb00
   16d9c:      	br	x17

0000000000016da0 <avcodec_open2@plt>:
   16da0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16da4:      	ldr	x17, [x16, #0xb08]
   16da8:      	add	x16, x16, #0xb08
   16dac:      	br	x17

0000000000016db0 <av_channel_layout_default@plt>:
   16db0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16db4:      	ldr	x17, [x16, #0xb10]
   16db8:      	add	x16, x16, #0xb10
   16dbc:      	br	x17

0000000000016dc0 <av_rescale_q@plt>:
   16dc0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16dc4:      	ldr	x17, [x16, #0xb18]
   16dc8:      	add	x16, x16, #0xb18
   16dcc:      	br	x17

0000000000016dd0 <av_samples_get_buffer_size@plt>:
   16dd0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16dd4:      	ldr	x17, [x16, #0xb20]
   16dd8:      	add	x16, x16, #0xb20
   16ddc:      	br	x17

0000000000016de0 <_ZNSt6__ndk115__thread_structC1Ev@plt>:
   16de0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16de4:      	ldr	x17, [x16, #0xb28]
   16de8:      	add	x16, x16, #0xb28
   16dec:      	br	x17

0000000000016df0 <pthread_create@plt>:
   16df0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16df4:      	ldr	x17, [x16, #0xb30]
   16df8:      	add	x16, x16, #0xb30
   16dfc:      	br	x17

0000000000016e00 <avcodec_free_context@plt>:
   16e00:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16e04:      	ldr	x17, [x16, #0xb38]
   16e08:      	add	x16, x16, #0xb38
   16e0c:      	br	x17

0000000000016e10 <av_dict_free@plt>:
   16e10:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16e14:      	ldr	x17, [x16, #0xb40]
   16e18:      	add	x16, x16, #0xb40
   16e1c:      	br	x17

0000000000016e20 <fwrite@plt>:
   16e20:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16e24:      	ldr	x17, [x16, #0xb48]
   16e28:      	add	x16, x16, #0xb48
   16e2c:      	br	x17

0000000000016e30 <_ZNSt6__ndk120__throw_system_errorEiPKc@plt>:
   16e30:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16e34:      	ldr	x17, [x16, #0xb50]
   16e38:      	add	x16, x16, #0xb50
   16e3c:      	br	x17

0000000000016e40 <_ZNSt6__ndk115__thread_structD1Ev@plt>:
   16e40:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16e44:      	ldr	x17, [x16, #0xb58]
   16e48:      	add	x16, x16, #0xb58
   16e4c:      	br	x17

0000000000016e50 <_ZNSt6__ndk119__shared_weak_countD2Ev@plt>:
   16e50:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16e54:      	ldr	x17, [x16, #0xb60]
   16e58:      	add	x16, x16, #0xb60
   16e5c:      	br	x17

0000000000016e60 <_ZNSt6__ndk118condition_variable10notify_oneEv@plt>:
   16e60:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16e64:      	ldr	x17, [x16, #0xb68]
   16e68:      	add	x16, x16, #0xb68
   16e6c:      	br	x17

0000000000016e70 <_ZNSt6__ndk118condition_variable4waitERNS_11unique_lockINS_5mutexEEE@plt>:
   16e70:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16e74:      	ldr	x17, [x16, #0xb70]
   16e78:      	add	x16, x16, #0xb70
   16e7c:      	br	x17

0000000000016e80 <memset@plt>:
   16e80:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16e84:      	ldr	x17, [x16, #0xb78]
   16e88:      	add	x16, x16, #0xb78
   16e8c:      	br	x17

0000000000016e90 <__android_log_print@plt>:
   16e90:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16e94:      	ldr	x17, [x16, #0xb80]
   16e98:      	add	x16, x16, #0xb80
   16e9c:      	br	x17

0000000000016ea0 <av_channel_layout_from_mask@plt>:
   16ea0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16ea4:      	ldr	x17, [x16, #0xb88]
   16ea8:      	add	x16, x16, #0xb88
   16eac:      	br	x17

0000000000016eb0 <swr_alloc_set_opts2@plt>:
   16eb0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16eb4:      	ldr	x17, [x16, #0xb90]
   16eb8:      	add	x16, x16, #0xb90
   16ebc:      	br	x17

0000000000016ec0 <swr_init@plt>:
   16ec0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16ec4:      	ldr	x17, [x16, #0xb98]
   16ec8:      	add	x16, x16, #0xb98
   16ecc:      	br	x17

0000000000016ed0 <av_get_sample_fmt_name@plt>:
   16ed0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16ed4:      	ldr	x17, [x16, #0xba0]
   16ed8:      	add	x16, x16, #0xba0
   16edc:      	br	x17

0000000000016ee0 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEElsEl@plt>:
   16ee0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16ee4:      	ldr	x17, [x16, #0xba8]
   16ee8:      	add	x16, x16, #0xba8
   16eec:      	br	x17

0000000000016ef0 <_ZNKSt6__ndk115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strEv@plt>:
   16ef0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16ef4:      	ldr	x17, [x16, #0xbb0]
   16ef8:      	add	x16, x16, #0xbb0
   16efc:      	br	x17

0000000000016f00 <_ZNSt6__ndk115basic_streambufIcNS_11char_traitsIcEEED2Ev@plt>:
   16f00:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16f04:      	ldr	x17, [x16, #0xbb8]
   16f08:      	add	x16, x16, #0xbb8
   16f0c:      	br	x17

0000000000016f10 <_ZNSt6__ndk113basic_ostreamIcNS_11char_traitsIcEEED2Ev@plt>:
   16f10:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16f14:      	ldr	x17, [x16, #0xbc0]
   16f18:      	add	x16, x16, #0xbc0
   16f1c:      	br	x17

0000000000016f20 <_ZNSt6__ndk19basic_iosIcNS_11char_traitsIcEEED2Ev@plt>:
   16f20:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16f24:      	ldr	x17, [x16, #0xbc8]
   16f28:      	add	x16, x16, #0xbc8
   16f2c:      	br	x17

0000000000016f30 <av_fast_malloc@plt>:
   16f30:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16f34:      	ldr	x17, [x16, #0xbd0]
   16f38:      	add	x16, x16, #0xbd0
   16f3c:      	br	x17

0000000000016f40 <swr_convert@plt>:
   16f40:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16f44:      	ldr	x17, [x16, #0xbd8]
   16f48:      	add	x16, x16, #0xbd8
   16f4c:      	br	x17

0000000000016f50 <av_read_frame@plt>:
   16f50:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16f54:      	ldr	x17, [x16, #0xbe0]
   16f58:      	add	x16, x16, #0xbe0
   16f5c:      	br	x17

0000000000016f60 <av_init_packet@plt>:
   16f60:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16f64:      	ldr	x17, [x16, #0xbe8]
   16f68:      	add	x16, x16, #0xbe8
   16f6c:      	br	x17

0000000000016f70 <av_frame_alloc@plt>:
   16f70:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16f74:      	ldr	x17, [x16, #0xbf0]
   16f78:      	add	x16, x16, #0xbf0
   16f7c:      	br	x17

0000000000016f80 <av_seek_frame@plt>:
   16f80:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16f84:      	ldr	x17, [x16, #0xbf8]
   16f88:      	add	x16, x16, #0xbf8
   16f8c:      	br	x17

0000000000016f90 <avcodec_flush_buffers@plt>:
   16f90:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16f94:      	ldr	x17, [x16, #0xc00]
   16f98:      	add	x16, x16, #0xc00
   16f9c:      	br	x17

0000000000016fa0 <avcodec_send_packet@plt>:
   16fa0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16fa4:      	ldr	x17, [x16, #0xc08]
   16fa8:      	add	x16, x16, #0xc08
   16fac:      	br	x17

0000000000016fb0 <avcodec_receive_frame@plt>:
   16fb0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16fb4:      	ldr	x17, [x16, #0xc10]
   16fb8:      	add	x16, x16, #0xc10
   16fbc:      	br	x17

0000000000016fc0 <printf@plt>:
   16fc0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16fc4:      	ldr	x17, [x16, #0xc18]
   16fc8:      	add	x16, x16, #0xc18
   16fcc:      	br	x17

0000000000016fd0 <swr_set_compensation@plt>:
   16fd0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16fd4:      	ldr	x17, [x16, #0xc20]
   16fd8:      	add	x16, x16, #0xc20
   16fdc:      	br	x17

0000000000016fe0 <av_get_bytes_per_sample@plt>:
   16fe0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16fe4:      	ldr	x17, [x16, #0xc28]
   16fe8:      	add	x16, x16, #0xc28
   16fec:      	br	x17

0000000000016ff0 <av_frame_unref@plt>:
   16ff0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   16ff4:      	ldr	x17, [x16, #0xc30]
   16ff8:      	add	x16, x16, #0xc30
   16ffc:      	br	x17

0000000000017000 <av_packet_unref@plt>:
   17000:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17004:      	ldr	x17, [x16, #0xc38]
   17008:      	add	x16, x16, #0xc38
   1700c:      	br	x17

0000000000017010 <av_frame_free@plt>:
   17010:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17014:      	ldr	x17, [x16, #0xc40]
   17018:      	add	x16, x16, #0xc40
   1701c:      	br	x17

0000000000017020 <_ZNSt9exceptionD2Ev@plt>:
   17020:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17024:      	ldr	x17, [x16, #0xc48]
   17028:      	add	x16, x16, #0xc48
   1702c:      	br	x17

0000000000017030 <_ZNSt6__ndk18ios_base4initEPv@plt>:
   17030:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17034:      	ldr	x17, [x16, #0xc50]
   17038:      	add	x16, x16, #0xc50
   1703c:      	br	x17

0000000000017040 <_ZNSt6__ndk115basic_streambufIcNS_11char_traitsIcEEEC2Ev@plt>:
   17040:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17044:      	ldr	x17, [x16, #0xc58]
   17048:      	add	x16, x16, #0xc58
   1704c:      	br	x17

0000000000017050 <_ZNSt6__ndk16threadD1Ev@plt>:
   17050:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17054:      	ldr	x17, [x16, #0xc60]
   17058:      	add	x16, x16, #0xc60
   1705c:      	br	x17

0000000000017060 <_ZNSt6__ndk119__thread_local_dataEv@plt>:
   17060:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17064:      	ldr	x17, [x16, #0xc68]
   17068:      	add	x16, x16, #0xc68
   1706c:      	br	x17

0000000000017070 <pthread_setspecific@plt>:
   17070:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17074:      	ldr	x17, [x16, #0xc70]
   17078:      	add	x16, x16, #0xc70
   1707c:      	br	x17

0000000000017080 <memcmp@plt>:
   17080:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17084:      	ldr	x17, [x16, #0xc78]
   17088:      	add	x16, x16, #0xc78
   1708c:      	br	x17

0000000000017090 <_ZNSt20bad_array_new_lengthC1Ev@plt>:
   17090:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17094:      	ldr	x17, [x16, #0xc80]
   17098:      	add	x16, x16, #0xc80
   1709c:      	br	x17

00000000000170a0 <log@plt>:
   170a0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   170a4:      	ldr	x17, [x16, #0xc88]
   170a8:      	add	x16, x16, #0xc88
   170ac:      	br	x17

00000000000170b0 <_Znam@plt>:
   170b0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   170b4:      	ldr	x17, [x16, #0xc90]
   170b8:      	add	x16, x16, #0xc90
   170bc:      	br	x17

00000000000170c0 <_ZdaPv@plt>:
   170c0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   170c4:      	ldr	x17, [x16, #0xc98]
   170c8:      	add	x16, x16, #0xc98
   170cc:      	br	x17

00000000000170d0 <__cxa_rethrow@plt>:
   170d0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   170d4:      	ldr	x17, [x16, #0xca0]
   170d8:      	add	x16, x16, #0xca0
   170dc:      	br	x17

00000000000170e0 <__cxa_end_catch@plt>:
   170e0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   170e4:      	ldr	x17, [x16, #0xca8]
   170e8:      	add	x16, x16, #0xca8
   170ec:      	br	x17

00000000000170f0 <calloc@plt>:
   170f0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   170f4:      	ldr	x17, [x16, #0xcb0]
   170f8:      	add	x16, x16, #0xcb0
   170fc:      	br	x17

0000000000017100 <free@plt>:
   17100:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17104:      	ldr	x17, [x16, #0xcb8]
   17108:      	add	x16, x16, #0xcb8
   1710c:      	br	x17

0000000000017110 <malloc@plt>:
   17110:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17114:      	ldr	x17, [x16, #0xcc0]
   17118:      	add	x16, x16, #0xcc0
   1711c:      	br	x17

0000000000017120 <pthread_getspecific@plt>:
   17120:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17124:      	ldr	x17, [x16, #0xcc8]
   17128:      	add	x16, x16, #0xcc8
   1712c:      	br	x17

0000000000017130 <pthread_self@plt>:
   17130:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17134:      	ldr	x17, [x16, #0xcd0]
   17138:      	add	x16, x16, #0xcd0
   1713c:      	br	x17

0000000000017140 <pthread_key_create@plt>:
   17140:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17144:      	ldr	x17, [x16, #0xcd8]
   17148:      	add	x16, x16, #0xcd8
   1714c:      	br	x17

0000000000017150 <pthread_mutex_init@plt>:
   17150:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17154:      	ldr	x17, [x16, #0xce0]
   17158:      	add	x16, x16, #0xce0
   1715c:      	br	x17

0000000000017160 <pthread_mutex_destroy@plt>:
   17160:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17164:      	ldr	x17, [x16, #0xce8]
   17168:      	add	x16, x16, #0xce8
   1716c:      	br	x17

0000000000017170 <pthread_mutex_lock@plt>:
   17170:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17174:      	ldr	x17, [x16, #0xcf0]
   17178:      	add	x16, x16, #0xcf0
   1717c:      	br	x17

0000000000017180 <pthread_mutex_unlock@plt>:
   17180:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17184:      	ldr	x17, [x16, #0xcf8]
   17188:      	add	x16, x16, #0xcf8
   1718c:      	br	x17

0000000000017190 <pthread_cond_init@plt>:
   17190:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17194:      	ldr	x17, [x16, #0xd00]
   17198:      	add	x16, x16, #0xd00
   1719c:      	br	x17

00000000000171a0 <pthread_cond_destroy@plt>:
   171a0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   171a4:      	ldr	x17, [x16, #0xd08]
   171a8:      	add	x16, x16, #0xd08
   171ac:      	br	x17

00000000000171b0 <pthread_cond_signal@plt>:
   171b0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   171b4:      	ldr	x17, [x16, #0xd10]
   171b8:      	add	x16, x16, #0xd10
   171bc:      	br	x17

00000000000171c0 <gettimeofday@plt>:
   171c0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   171c4:      	ldr	x17, [x16, #0xd18]
   171c8:      	add	x16, x16, #0xd18
   171cc:      	br	x17

00000000000171d0 <pthread_cond_timedwait@plt>:
   171d0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   171d4:      	ldr	x17, [x16, #0xd20]
   171d8:      	add	x16, x16, #0xd20
   171dc:      	br	x17

00000000000171e0 <__strlcpy_chk@plt>:
   171e0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   171e4:      	ldr	x17, [x16, #0xd28]
   171e8:      	add	x16, x16, #0xd28
   171ec:      	br	x17

00000000000171f0 <pthread_getschedparam@plt>:
   171f0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   171f4:      	ldr	x17, [x16, #0xd30]
   171f8:      	add	x16, x16, #0xd30
   171fc:      	br	x17

0000000000017200 <sched_get_priority_min@plt>:
   17200:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17204:      	ldr	x17, [x16, #0xd38]
   17208:      	add	x16, x16, #0xd38
   1720c:      	br	x17

0000000000017210 <sched_get_priority_max@plt>:
   17210:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17214:      	ldr	x17, [x16, #0xd40]
   17218:      	add	x16, x16, #0xd40
   1721c:      	br	x17

0000000000017220 <pthread_setschedparam@plt>:
   17220:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17224:      	ldr	x17, [x16, #0xd48]
   17228:      	add	x16, x16, #0xd48
   1722c:      	br	x17

0000000000017230 <pthread_join@plt>:
   17230:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17234:      	ldr	x17, [x16, #0xd50]
   17238:      	add	x16, x16, #0xd50
   1723c:      	br	x17

0000000000017240 <memcpy@plt>:
   17240:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17244:      	ldr	x17, [x16, #0xd58]
   17248:      	add	x16, x16, #0xd58
   1724c:      	br	x17

0000000000017250 <getauxval@plt>:
   17250:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17254:      	ldr	x17, [x16, #0xd60]
   17258:      	add	x16, x16, #0xd60
   1725c:      	br	x17

0000000000017260 <__system_property_get@plt>:
   17260:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17264:      	ldr	x17, [x16, #0xd68]
   17268:      	add	x16, x16, #0xd68
   1726c:      	br	x17

0000000000017270 <strncmp@plt>:
   17270:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17274:      	ldr	x17, [x16, #0xd70]
   17278:      	add	x16, x16, #0xd70
   1727c:      	br	x17

0000000000017280 <fprintf@plt>:
   17280:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17284:      	ldr	x17, [x16, #0xd78]
   17288:      	add	x16, x16, #0xd78
   1728c:      	br	x17

0000000000017290 <fflush@plt>:
   17290:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17294:      	ldr	x17, [x16, #0xd80]
   17298:      	add	x16, x16, #0xd80
   1729c:      	br	x17

00000000000172a0 <abort@plt>:
   172a0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   172a4:      	ldr	x17, [x16, #0xd88]
   172a8:      	add	x16, x16, #0xd88
   172ac:      	br	x17

00000000000172b0 <pthread_rwlock_wrlock@plt>:
   172b0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   172b4:      	ldr	x17, [x16, #0xd90]
   172b8:      	add	x16, x16, #0xd90
   172bc:      	br	x17

00000000000172c0 <pthread_rwlock_unlock@plt>:
   172c0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   172c4:      	ldr	x17, [x16, #0xd98]
   172c8:      	add	x16, x16, #0xd98
   172cc:      	br	x17

00000000000172d0 <dl_iterate_phdr@plt>:
   172d0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   172d4:      	ldr	x17, [x16, #0xda0]
   172d8:      	add	x16, x16, #0xda0
   172dc:      	br	x17

00000000000172e0 <pthread_rwlock_rdlock@plt>:
   172e0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   172e4:      	ldr	x17, [x16, #0xda8]
   172e8:      	add	x16, x16, #0xda8
   172ec:      	br	x17

00000000000172f0 <getpid@plt>:
   172f0:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   172f4:      	ldr	x17, [x16, #0xdb0]
   172f8:      	add	x16, x16, #0xdb0
   172fc:      	br	x17

0000000000017300 <syscall@plt>:
   17300:      	adrp	x16, 0x1b000 <syscall@plt+0x3d00>
   17304:      	ldr	x17, [x16, #0xdb8]
   17308:      	add	x16, x16, #0xdb8
   1730c:      	br	x17
