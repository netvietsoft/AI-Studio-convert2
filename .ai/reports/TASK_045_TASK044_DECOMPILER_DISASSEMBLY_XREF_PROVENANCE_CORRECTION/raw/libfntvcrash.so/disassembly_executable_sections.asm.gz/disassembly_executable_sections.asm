
F:\CONVERT\com.mt.mtxx.mtxx\SOURCE\extracted_native_libs\lib\arm64-v8a\libfntvcrash.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000004924 <.text>:
    4924:      	bti	c
    4928:      	nop
    492c:      	adr	x0, 0x11120
    4930:      	b	0xcd50 <__cxa_finalize@plt>
    4934:      	bti	c
    4938:      	ret
    493c:      	bti	c
    4940:      	b	0x4934 <.text+0x10>
    4944:      	bti	c
    4948:      	cbz	x0, 0x4954 <.text+0x30>
    494c:      	mov	x16, x0
    4950:      	br	x16
    4954:      	ret
    4958:      	bti	c
    495c:      	mov	x1, x0
    4960:      	nop
    4964:      	adr	x0, 0x4944 <.text+0x20>
    4968:      	nop
    496c:      	adr	x2, 0x11120
    4970:      	b	0xcd60 <__cxa_atexit@plt>
    4974:      	paciasp
    4978:      	sub	sp, sp, #0x20
    497c:      	stp	x29, x30, [sp, #0x10]
    4980:      	add	x29, sp, #0x10
    4984:      	add	x2, sp, #0x8
    4988:      	mov	w1, #-0x1               // =-1
    498c:      	bl	0x4a4c <.text+0x128>
    4990:      	ldr	x0, [sp, #0x8]
    4994:      	ldp	x29, x30, [sp, #0x10]
    4998:      	add	sp, sp, #0x20
    499c:      	autiasp
    49a0:      	ret
    49a4:      	paciasp
    49a8:      	stp	x29, x30, [sp, #-0x20]!
    49ac:      	stp	x20, x19, [sp, #0x10]
    49b0:      	mov	x29, sp
    49b4:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    49b8:      	add	x8, x8, #0x138
    49bc:      	nop
    49c0:      	adr	x9, 0x15800
    49c4:      	mov	w2, #0x110              // =272
    49c8:      	mov	x20, x1
    49cc:      	mov	x19, x0
    49d0:      	stp	x8, x9, [x0], #0x10
    49d4:      	bl	0xd0b0 <memcpy@plt>
    49d8:      	ldp	q1, q0, [x20, #0x130]
    49dc:      	add	x8, x19, #0x220
    49e0:      	ldp	q3, q2, [x20, #0x110]
    49e4:      	mov	x0, x19
    49e8:      	mov	w1, wzr
    49ec:      	stp	q1, q0, [x19, #0x140]
    49f0:      	stp	q3, q2, [x19, #0x120]
    49f4:      	ldp	q1, q0, [x20, #0x170]
    49f8:      	ldp	q3, q2, [x20, #0x150]
    49fc:      	stp	q1, q0, [x19, #0x180]
    4a00:      	stp	q3, q2, [x19, #0x160]
    4a04:      	ldp	q1, q0, [x20, #0x1b0]
    4a08:      	ldp	q3, q2, [x20, #0x190]
    4a0c:      	stp	q1, q0, [x19, #0x1c0]
    4a10:      	stp	q3, q2, [x19, #0x1a0]
    4a14:      	movi	v2.2d, #0000000000000000
    4a18:      	ldp	q1, q0, [x20, #0x1f0]
    4a1c:      	ldp	q4, q3, [x20, #0x1d0]
    4a20:      	stp	q1, q0, [x19, #0x200]
    4a24:      	stp	q4, q3, [x19, #0x1e0]
    4a28:      	stur	q2, [x8, #0x3b]
    4a2c:      	stp	q2, q2, [x19, #0x220]
    4a30:      	stp	q2, q2, [x19, #0x240]
    4a34:      	bl	0x5304 <.text+0x9e0>
    4a38:      	mov	w0, wzr
    4a3c:      	ldp	x20, x19, [sp, #0x10]
    4a40:      	ldp	x29, x30, [sp], #0x20
    4a44:      	autiasp
    4a48:      	ret
    4a4c:      	paciasp
    4a50:      	stp	x29, x30, [sp, #-0x30]!
    4a54:      	str	x21, [sp, #0x10]
    4a58:      	stp	x20, x19, [sp, #0x20]
    4a5c:      	mov	x29, sp
    4a60:      	ldr	x8, [x0]
    4a64:      	mov	x19, x2
    4a68:      	mov	x20, x0
    4a6c:      	mov	w21, w1
    4a70:      	ldr	x8, [x8, #0x10]
    4a74:      	blr	x8
    4a78:      	tbz	w0, #0x0, 0x4ab0 <.text+0x18c>
    4a7c:      	ldr	x8, [x20]
    4a80:      	mov	x0, x20
    4a84:      	mov	w1, w21
    4a88:      	ldr	x8, [x8, #0x18]
    4a8c:      	blr	x8
    4a90:      	mov	x8, x0
    4a94:      	mov	w0, wzr
    4a98:      	str	x8, [x19]
    4a9c:      	ldp	x20, x19, [sp, #0x20]
    4aa0:      	ldr	x21, [sp, #0x10]
    4aa4:      	ldp	x29, x30, [sp], #0x30
    4aa8:      	autiasp
    4aac:      	ret
    4ab0:      	mov	w0, #-0x198e            // =-6542
    4ab4:      	ldp	x20, x19, [sp, #0x20]
    4ab8:      	ldr	x21, [sp, #0x10]
    4abc:      	ldp	x29, x30, [sp], #0x30
    4ac0:      	autiasp
    4ac4:      	ret
    4ac8:      	bti	c
    4acc:      	ldr	x8, [x0]
    4ad0:      	mov	w1, wzr
    4ad4:      	ldr	x16, [x8, #0x40]
    4ad8:      	br	x16
    4adc:      	paciasp
    4ae0:      	stp	x29, x30, [sp, #-0x60]!
    4ae4:      	str	x27, [sp, #0x10]
    4ae8:      	stp	x26, x25, [sp, #0x20]
    4aec:      	stp	x24, x23, [sp, #0x30]
    4af0:      	stp	x22, x21, [sp, #0x40]
    4af4:      	stp	x20, x19, [sp, #0x50]
    4af8:      	mov	x29, sp
    4afc:      	mov	x23, x1
    4b00:      	mov	x20, x3
    4b04:      	mov	x19, x2
    4b08:      	ldr	w22, [x23], #0x4
    4b0c:      	mov	x21, x0
    4b10:      	cmn	w22, #0x1
    4b14:      	b.eq	0x4b48 <.text+0x224>
    4b18:      	cbz	x22, 0x4b54 <.text+0x230>
    4b1c:      	ldr	w8, [x23]
    4b20:      	cbz	w8, 0x4b60 <.text+0x23c>
    4b24:      	mov	x25, x1
    4b28:      	sub	x1, x23, x8
    4b2c:      	tbz	w4, #0x0, 0x4b6c <.text+0x248>
    4b30:      	ldr	x8, [x20]
    4b34:      	cmp	x8, x1
    4b38:      	b.eq	0x4b7c <.text+0x258>
    4b3c:      	adrp	x0, 0x2000
    4b40:      	add	x0, x0, #0xd56
    4b44:      	b	0x4c4c <.text+0x328>
    4b48:      	ldur	x22, [x1, #0x4]
    4b4c:      	add	x23, x1, #0xc
    4b50:      	cbnz	x22, 0x4b1c <.text+0x1f8>
    4b54:      	adrp	x0, 0x1000
    4b58:      	add	x0, x0, #0xed7
    4b5c:      	b	0x4c4c <.text+0x328>
    4b60:      	adrp	x0, 0x2000
    4b64:      	add	x0, x0, #0x1ca
    4b68:      	b	0x4c4c <.text+0x328>
    4b6c:      	mov	x0, x21
    4b70:      	mov	x2, x20
    4b74:      	bl	0x4c6c <.text+0x348>
    4b78:      	cbnz	x0, 0x4c4c <.text+0x328>
    4b7c:      	ldrb	w3, [x20, #0x18]
    4b80:      	add	x22, x23, x22
    4b84:      	add	x8, x23, #0x4
    4b88:      	add	x1, x29, #0x18
    4b8c:      	mov	x0, x21
    4b90:      	mov	x2, x22
    4b94:      	mov	x4, xzr
    4b98:      	str	x8, [x29, #0x18]
    4b9c:      	bl	0x6ac4 <.text+0x21a0>
    4ba0:      	ldrb	w8, [x20, #0x18]
    4ba4:      	mov	x23, x0
    4ba8:      	add	x1, x29, #0x18
    4bac:      	mov	x0, x21
    4bb0:      	mov	x2, x22
    4bb4:      	mov	x4, xzr
    4bb8:      	and	w3, w8, #0xf
    4bbc:      	bl	0x6ac4 <.text+0x21a0>
    4bc0:      	ldrb	w8, [x20, #0x31]
    4bc4:      	mov	x24, x0
    4bc8:      	str	xzr, [x19, #0x28]
    4bcc:      	cbz	w8, 0x4c30 <.text+0x30c>
    4bd0:      	add	x0, x29, #0x18
    4bd4:      	mov	x1, x22
    4bd8:      	bl	0x6e50 <.text+0x252c>
    4bdc:      	ldrb	w8, [x20, #0x19]
    4be0:      	ldr	x27, [x29, #0x18]
    4be4:      	cmp	w8, #0xff
    4be8:      	add	x26, x27, x0
    4bec:      	b.eq	0x4c34 <.text+0x310>
    4bf0:      	add	x1, x29, #0x18
    4bf4:      	and	w3, w8, #0xf
    4bf8:      	mov	x0, x21
    4bfc:      	mov	x2, x22
    4c00:      	mov	x4, xzr
    4c04:      	bl	0x6ac4 <.text+0x21a0>
    4c08:      	cbz	x0, 0x4c34 <.text+0x310>
    4c0c:      	ldrb	w3, [x20, #0x19]
    4c10:      	add	x1, x29, #0x18
    4c14:      	mov	x0, x21
    4c18:      	mov	x2, x22
    4c1c:      	mov	x4, xzr
    4c20:      	str	x27, [x29, #0x18]
    4c24:      	bl	0x6ac4 <.text+0x21a0>
    4c28:      	str	x0, [x19, #0x28]
    4c2c:      	b	0x4c34 <.text+0x310>
    4c30:      	ldr	x26, [x29, #0x18]
    4c34:      	sub	x8, x22, x25
    4c38:      	mov	x0, xzr
    4c3c:      	stp	x26, x23, [x19, #0x10]
    4c40:      	stp	x25, x8, [x19]
    4c44:      	add	x8, x24, x23
    4c48:      	str	x8, [x19, #0x20]
    4c4c:      	ldp	x20, x19, [sp, #0x50]
    4c50:      	ldr	x27, [sp, #0x10]
    4c54:      	ldp	x22, x21, [sp, #0x40]
    4c58:      	ldp	x24, x23, [sp, #0x30]
    4c5c:      	ldp	x26, x25, [sp, #0x20]
    4c60:      	ldp	x29, x30, [sp], #0x60
    4c64:      	autiasp
    4c68:      	ret
    4c6c:      	paciasp
    4c70:      	sub	sp, sp, #0x50
    4c74:      	stp	x29, x30, [sp, #0x10]
    4c78:      	stp	x24, x23, [sp, #0x20]
    4c7c:      	stp	x22, x21, [sp, #0x30]
    4c80:      	stp	x20, x19, [sp, #0x40]
    4c84:      	add	x29, sp, #0x10
    4c88:      	movi	d0, #0x00ff000000ff00
    4c8c:      	sturh	wzr, [x2, #0x33]
    4c90:      	mov	x8, x1
    4c94:      	stp	xzr, xzr, [x2, #0x20]
    4c98:      	mov	x19, x2
    4c9c:      	mov	x20, x1
    4ca0:      	strh	wzr, [x2, #0x30]
    4ca4:      	mov	x21, x0
    4ca8:      	str	x1, [x2]
    4cac:      	str	s0, [x2, #0x18]
    4cb0:      	ldr	w9, [x8], #0x4
    4cb4:      	cmn	w9, #0x1
    4cb8:      	b.eq	0x4cd8 <.text+0x3b4>
    4cbc:      	add	x22, x8, x9
    4cc0:      	cbz	x9, 0x4ce8 <.text+0x3c4>
    4cc4:      	ldr	w9, [x8]
    4cc8:      	cbz	w9, 0x4cf0 <.text+0x3cc>
    4ccc:      	adrp	x0, 0x2000
    4cd0:      	add	x0, x0, #0xb8e
    4cd4:      	b	0x4ee4 <.text+0x5c0>
    4cd8:      	ldur	x9, [x20, #0x4]
    4cdc:      	add	x8, x20, #0xc
    4ce0:      	add	x22, x9, x8
    4ce4:      	cbnz	x9, 0x4cc4 <.text+0x3a0>
    4ce8:      	mov	x0, xzr
    4cec:      	b	0x4ee4 <.text+0x5c0>
    4cf0:      	ldrb	w24, [x8, #0x4]
    4cf4:      	and	w9, w24, #0xfffffffd
    4cf8:      	cmp	w9, #0x1
    4cfc:      	b.ne	0x4da8 <.text+0x484>
    4d00:      	add	x23, x8, #0x5
    4d04:      	mov	x8, x23
    4d08:      	ldrb	w9, [x8], #0x1
    4d0c:      	cbnz	w9, 0x4d08 <.text+0x3e4>
    4d10:      	add	x0, sp, #0x8
    4d14:      	mov	x1, x22
    4d18:      	str	x8, [sp, #0x8]
    4d1c:      	bl	0x6e50 <.text+0x252c>
    4d20:      	ldr	x8, [sp, #0x8]
    4d24:      	mov	x11, xzr
    4d28:      	mov	x9, xzr
    4d2c:      	str	w0, [x19, #0x28]
    4d30:      	mov	x10, x8
    4d34:      	cmp	x10, x22
    4d38:      	b.eq	0x4f00 <.text+0x5dc>
    4d3c:      	ldrb	w12, [x10], #0x1
    4d40:      	add	x8, x8, #0x1
    4d44:      	and	x13, x12, #0x7f
    4d48:      	lsl	x13, x13, x11
    4d4c:      	add	x11, x11, #0x7
    4d50:      	orr	x9, x13, x9
    4d54:      	tbnz	w12, #0x7, 0x4d34 <.text+0x410>
    4d58:      	sub	w13, w11, #0x7
    4d5c:      	mov	x14, #-0x1              // =-1
    4d60:      	str	x8, [sp, #0x8]
    4d64:      	cmp	w13, #0x39
    4d68:      	mov	w13, #0x3f              // =63
    4d6c:      	lsl	x11, x14, x11
    4d70:      	ccmp	w12, w13, #0x0, lo
    4d74:      	csel	w11, w11, wzr, hi
    4d78:      	cmp	w24, #0x1
    4d7c:      	orr	w9, w9, w11
    4d80:      	str	w9, [x19, #0x2c]
    4d84:      	b.ne	0x4db4 <.text+0x490>
    4d88:      	add	x8, x8, #0x1
    4d8c:      	str	x8, [sp, #0x8]
    4d90:      	ldrb	w0, [x10]
    4d94:      	strb	w0, [x19, #0x32]
    4d98:      	ldrb	w8, [x23]
    4d9c:      	cmp	w8, #0x7a
    4da0:      	b.eq	0x4dd0 <.text+0x4ac>
    4da4:      	b	0x4ed0 <.text+0x5ac>
    4da8:      	adrp	x0, 0x1000
    4dac:      	add	x0, x0, #0xcb7
    4db0:      	b	0x4ee4 <.text+0x5c0>
    4db4:      	add	x0, sp, #0x8
    4db8:      	mov	x1, x22
    4dbc:      	bl	0x6e50 <.text+0x252c>
    4dc0:      	strb	w0, [x19, #0x32]
    4dc4:      	ldrb	w8, [x23]
    4dc8:      	cmp	w8, #0x7a
    4dcc:      	b.ne	0x4ed0 <.text+0x5ac>
    4dd0:      	add	x0, sp, #0x8
    4dd4:      	mov	x1, x22
    4dd8:      	bl	0x6e50 <.text+0x252c>
    4ddc:      	mov	w24, #0x1               // =1
    4de0:      	b	0x4dec <.text+0x4c8>
    4de4:      	strb	w24, [x19, #0x30]
    4de8:      	add	x23, x23, #0x1
    4dec:      	ldrb	w8, [x23]
    4df0:      	cmp	w8, #0x4f
    4df4:      	b.le	0x4e28 <.text+0x504>
    4df8:      	cmp	w8, #0x52
    4dfc:      	b.gt	0x4e58 <.text+0x534>
    4e00:      	cmp	w8, #0x50
    4e04:      	b.eq	0x4e94 <.text+0x570>
    4e08:      	cmp	w8, #0x52
    4e0c:      	b.ne	0x4e8c <.text+0x568>
    4e10:      	ldr	x8, [sp, #0x8]
    4e14:      	add	x23, x23, #0x1
    4e18:      	ldrb	w9, [x8], #0x1
    4e1c:      	str	x8, [sp, #0x8]
    4e20:      	strb	w9, [x19, #0x18]
    4e24:      	b	0x4dec <.text+0x4c8>
    4e28:      	cmp	w8, #0x46
    4e2c:      	b.le	0x4e74 <.text+0x550>
    4e30:      	cmp	w8, #0x47
    4e34:      	b.eq	0x4e88 <.text+0x564>
    4e38:      	cmp	w8, #0x4c
    4e3c:      	b.ne	0x4e8c <.text+0x568>
    4e40:      	ldr	x8, [sp, #0x8]
    4e44:      	add	x23, x23, #0x1
    4e48:      	ldrb	w9, [x8], #0x1
    4e4c:      	str	x8, [sp, #0x8]
    4e50:      	strb	w9, [x19, #0x19]
    4e54:      	b	0x4dec <.text+0x4c8>
    4e58:      	cmp	w8, #0x53
    4e5c:      	b.eq	0x4de4 <.text+0x4c0>
    4e60:      	cmp	w8, #0x7a
    4e64:      	b.ne	0x4e8c <.text+0x568>
    4e68:      	strb	w24, [x19, #0x31]
    4e6c:      	add	x23, x23, #0x1
    4e70:      	b	0x4dec <.text+0x4c8>
    4e74:      	cmp	w8, #0x42
    4e78:      	b.ne	0x4ecc <.text+0x5a8>
    4e7c:      	strb	w24, [x19, #0x33]
    4e80:      	add	x23, x23, #0x1
    4e84:      	b	0x4dec <.text+0x4c8>
    4e88:      	strb	w24, [x19, #0x34]
    4e8c:      	add	x23, x23, #0x1
    4e90:      	b	0x4dec <.text+0x4c8>
    4e94:      	ldr	x8, [sp, #0x8]
    4e98:      	add	x1, sp, #0x8
    4e9c:      	mov	x0, x21
    4ea0:      	mov	x2, x22
    4ea4:      	mov	x4, xzr
    4ea8:      	ldrb	w3, [x8], #0x1
    4eac:      	str	x8, [sp, #0x8]
    4eb0:      	sub	w8, w8, w20
    4eb4:      	strb	w3, [x19, #0x1a]
    4eb8:      	strb	w8, [x19, #0x1b]
    4ebc:      	bl	0x6ac4 <.text+0x21a0>
    4ec0:      	str	x0, [x19, #0x20]
    4ec4:      	add	x23, x23, #0x1
    4ec8:      	b	0x4dec <.text+0x4c8>
    4ecc:      	cbnz	w8, 0x4e8c <.text+0x568>
    4ed0:      	ldr	x8, [x19]
    4ed4:      	ldr	x9, [sp, #0x8]
    4ed8:      	mov	x0, xzr
    4edc:      	sub	x8, x22, x8
    4ee0:      	stp	x8, x9, [x19, #0x8]
    4ee4:      	ldp	x20, x19, [sp, #0x40]
    4ee8:      	ldp	x22, x21, [sp, #0x30]
    4eec:      	ldp	x24, x23, [sp, #0x20]
    4ef0:      	ldp	x29, x30, [sp, #0x10]
    4ef4:      	add	sp, sp, #0x50
    4ef8:      	autiasp
    4efc:      	ret
    4f00:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    4f04:      	nop
    4f08:      	adr	x1, 0x1af2
    4f0c:      	ldr	x19, [x19, #0x3e0]
    4f10:      	adrp	x2, 0x2000
    4f14:      	add	x2, x2, #0x398
    4f18:      	adrp	x3, 0x1000
    4f1c:      	add	x3, x3, #0xfd2
    4f20:      	add	x0, x19, #0x130
    4f24:      	bl	0xd080 <fprintf@plt>
    4f28:      	add	x0, x19, #0x130
    4f2c:      	bl	0xd090 <fflush@plt>
    4f30:      	bl	0xd0a0 <abort@plt>
    4f34:      	bti	c
    4f38:      	ret
    4f3c:      	bti	c
    4f40:      	ret
    4f44:      	bti	c
    4f48:      	cmn	w1, #0x3
    4f4c:      	b.ls	0x4f58 <.text+0x634>
    4f50:      	mov	w0, #0x1                // =1
    4f54:      	ret
    4f58:      	cmp	w1, #0x5f
    4f5c:      	b.ls	0x4f68 <.text+0x644>
    4f60:      	mov	w0, wzr
    4f64:      	ret
    4f68:      	cmp	w1, #0x22
    4f6c:      	b.ne	0x4f78 <.text+0x654>
    4f70:      	mov	w0, #0x1                // =1
    4f74:      	ret
    4f78:      	sub	w8, w1, #0x40
    4f7c:      	cmn	w8, #0x1f
    4f80:      	cset	w0, lo
    4f84:      	ret
    4f88:      	bti	c
    4f8c:      	cmp	w1, #0x1d
    4f90:      	b.le	0x4fb0 <.text+0x68c>
    4f94:      	cmp	w1, #0x1f
    4f98:      	b.gt	0x4fd4 <.text+0x6b0>
    4f9c:      	cmp	w1, #0x1e
    4fa0:      	b.eq	0x5014 <.text+0x6f0>
    4fa4:      	cmp	w1, #0x1f
    4fa8:      	b.eq	0x4ff0 <.text+0x6cc>
    4fac:      	b	0x4ffc <.text+0x6d8>
    4fb0:      	cmn	w1, #0x2
    4fb4:      	b.eq	0x4ff0 <.text+0x6cc>
    4fb8:      	cmn	w1, #0x1
    4fbc:      	b.eq	0x4fe4 <.text+0x6c0>
    4fc0:      	cmp	w1, #0x1d
    4fc4:      	b.ne	0x4ffc <.text+0x6d8>
    4fc8:      	add	x8, x0, #0xf8
    4fcc:      	ldr	x0, [x8]
    4fd0:      	ret
    4fd4:      	cmp	w1, #0x22
    4fd8:      	b.eq	0x5020 <.text+0x6fc>
    4fdc:      	cmp	w1, #0x20
    4fe0:      	b.ne	0x4ffc <.text+0x6d8>
    4fe4:      	add	x8, x0, #0x110
    4fe8:      	ldr	x0, [x8]
    4fec:      	ret
    4ff0:      	add	x8, x0, #0x108
    4ff4:      	ldr	x0, [x8]
    4ff8:      	ret
    4ffc:      	cmp	w1, #0x1c
    5000:      	b.hi	0x502c <.text+0x708>
    5004:      	add	x8, x0, #0x10
    5008:      	add	x8, x8, w1, uxtw #3
    500c:      	ldr	x0, [x8]
    5010:      	ret
    5014:      	add	x8, x0, #0x100
    5018:      	ldr	x0, [x8]
    501c:      	ret
    5020:      	add	x8, x0, #0x118
    5024:      	ldr	x0, [x8]
    5028:      	ret
    502c:      	paciasp
    5030:      	stp	x29, x30, [sp, #-0x20]!
    5034:      	str	x19, [sp, #0x10]
    5038:      	mov	x29, sp
    503c:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    5040:      	nop
    5044:      	adr	x1, 0x1af2
    5048:      	ldr	x19, [x19, #0x3e0]
    504c:      	adrp	x2, 0x2000
    5050:      	add	x2, x2, #0x1b6
    5054:      	adrp	x3, 0x1000
    5058:      	add	x3, x3, #0xf64
    505c:      	add	x0, x19, #0x130
    5060:      	bl	0xd080 <fprintf@plt>
    5064:      	add	x0, x19, #0x130
    5068:      	bl	0xd090 <fflush@plt>
    506c:      	bl	0xd0a0 <abort@plt>
    5070:      	bti	c
    5074:      	cmp	w1, #0x1d
    5078:      	b.le	0x5098 <.text+0x774>
    507c:      	cmp	w1, #0x1f
    5080:      	b.gt	0x50bc <.text+0x798>
    5084:      	cmp	w1, #0x1e
    5088:      	b.eq	0x50fc <.text+0x7d8>
    508c:      	cmp	w1, #0x1f
    5090:      	b.eq	0x50d8 <.text+0x7b4>
    5094:      	b	0x50e4 <.text+0x7c0>
    5098:      	cmn	w1, #0x2
    509c:      	b.eq	0x50d8 <.text+0x7b4>
    50a0:      	cmn	w1, #0x1
    50a4:      	b.eq	0x50cc <.text+0x7a8>
    50a8:      	cmp	w1, #0x1d
    50ac:      	b.ne	0x50e4 <.text+0x7c0>
    50b0:      	add	x8, x0, #0xf8
    50b4:      	str	x2, [x8]
    50b8:      	ret
    50bc:      	cmp	w1, #0x22
    50c0:      	b.eq	0x5108 <.text+0x7e4>
    50c4:      	cmp	w1, #0x20
    50c8:      	b.ne	0x50e4 <.text+0x7c0>
    50cc:      	add	x8, x0, #0x110
    50d0:      	str	x2, [x8]
    50d4:      	ret
    50d8:      	add	x8, x0, #0x108
    50dc:      	str	x2, [x8]
    50e0:      	ret
    50e4:      	cmp	w1, #0x1c
    50e8:      	b.hi	0x5114 <.text+0x7f0>
    50ec:      	add	x8, x0, #0x10
    50f0:      	add	x8, x8, w1, uxtw #3
    50f4:      	str	x2, [x8]
    50f8:      	ret
    50fc:      	add	x8, x0, #0x100
    5100:      	str	x2, [x8]
    5104:      	ret
    5108:      	add	x8, x0, #0x118
    510c:      	str	x2, [x8]
    5110:      	ret
    5114:      	paciasp
    5118:      	stp	x29, x30, [sp, #-0x20]!
    511c:      	str	x19, [sp, #0x10]
    5120:      	mov	x29, sp
    5124:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    5128:      	nop
    512c:      	adr	x1, 0x1af2
    5130:      	ldr	x19, [x19, #0x3e0]
    5134:      	adrp	x2, 0x2000
    5138:      	add	x2, x2, #0x579
    513c:      	adrp	x3, 0x1000
    5140:      	add	x3, x3, #0xf64
    5144:      	add	x0, x19, #0x130
    5148:      	bl	0xd080 <fprintf@plt>
    514c:      	add	x0, x19, #0x130
    5150:      	bl	0xd090 <fflush@plt>
    5154:      	bl	0xd0a0 <abort@plt>
    5158:      	bti	c
    515c:      	and	w8, w1, #0xffffffe0
    5160:      	cmp	w8, #0x40
    5164:      	cset	w0, eq
    5168:      	ret
    516c:      	bti	c
    5170:      	add	x8, x0, w1, sxtw #3
    5174:      	ldur	d0, [x8, #-0xe0]
    5178:      	ret
    517c:      	bti	c
    5180:      	add	x8, x0, w1, sxtw #3
    5184:      	stur	d0, [x8, #-0xe0]
    5188:      	ret
    518c:      	bti	c
    5190:      	ldrb	w8, [x0, #0x268]
    5194:      	cbz	w8, 0x51a0 <.text+0x87c>
    5198:      	mov	w0, wzr
    519c:      	ret
    51a0:      	paciasp
    51a4:      	stp	x29, x30, [sp, #-0x30]!
    51a8:      	stp	x28, x21, [sp, #0x10]
    51ac:      	stp	x20, x19, [sp, #0x20]
    51b0:      	mov	x29, sp
    51b4:      	sub	sp, sp, #0x210
    51b8:      	ldrb	w8, [x0, #0x26a]
    51bc:      	mov	x19, x0
    51c0:      	cbz	w8, 0x5200 <.text+0x8dc>
    51c4:      	mov	x0, sp
    51c8:      	mov	w1, wzr
    51cc:      	mov	w2, #0x210              // =528
    51d0:      	bl	0xd0e0 <memset@plt>
    51d4:      	mov	x1, sp
    51d8:      	mov	x0, x19
    51dc:      	bl	0x5590 <.text+0xc6c>
    51e0:      	cmp	w0, #0x1
    51e4:      	b.eq	0x523c <.text+0x918>
    51e8:      	add	sp, sp, #0x210
    51ec:      	ldp	x20, x19, [sp, #0x20]
    51f0:      	ldp	x28, x21, [sp, #0x10]
    51f4:      	ldp	x29, x30, [sp], #0x30
    51f8:      	autiasp
    51fc:      	ret
    5200:      	ldp	x8, x20, [x19]
    5204:      	mov	x0, x19
    5208:      	mov	w21, w1
    520c:      	mov	w1, #-0x1               // =-1
    5210:      	ldr	x8, [x8, #0x18]
    5214:      	blr	x8
    5218:      	ldr	x2, [x19, #0x258]
    521c:      	mov	x1, x0
    5220:      	add	x3, x19, #0x10
    5224:      	add	x4, x19, #0x269
    5228:      	and	w5, w21, #0x1
    522c:      	mov	x0, x20
    5230:      	bl	0x56b0 <.text+0xd8c>
    5234:      	cmp	w0, #0x1
    5238:      	b.ne	0x51e8 <.text+0x8c4>
    523c:      	ldr	x8, [x19]
    5240:      	mov	w20, w0
    5244:      	mov	x0, x19
    5248:      	mov	w1, #0x1                // =1
    524c:      	ldr	x8, [x8, #0x68]
    5250:      	blr	x8
    5254:      	ldrb	w8, [x19, #0x268]
    5258:      	mov	w0, w20
    525c:      	cbz	w8, 0x51e8 <.text+0x8c4>
    5260:      	mov	w0, wzr
    5264:      	add	sp, sp, #0x210
    5268:      	ldp	x20, x19, [sp, #0x20]
    526c:      	ldp	x28, x21, [sp, #0x10]
    5270:      	ldp	x29, x30, [sp], #0x30
    5274:      	autiasp
    5278:      	ret
    527c:      	bti	c
    5280:      	ldrb	w8, [x0, #0x268]
    5284:      	cbz	w8, 0x529c <.text+0x978>
    5288:      	movi	v0.2d, #0000000000000000
    528c:      	str	xzr, [x1, #0x40]
    5290:      	stp	q0, q0, [x1]
    5294:      	stp	q0, q0, [x1, #0x20]
    5298:      	ret
    529c:      	ldr	q0, [x0, #0x220]
    52a0:      	str	q0, [x1]
    52a4:      	ldp	q2, q0, [x0, #0x240]
    52a8:      	ldr	x8, [x0, #0x260]
    52ac:      	ldr	q1, [x0, #0x230]
    52b0:      	str	x8, [x1, #0x40]
    52b4:      	stp	q2, q0, [x1, #0x20]
    52b8:      	str	q1, [x1, #0x10]
    52bc:      	ret
    52c0:      	bti	c
    52c4:      	add	x0, x0, #0x10
    52c8:      	b	0x8410 <.text+0x3aec>
    52cc:      	bti	c
    52d0:      	ldrb	w0, [x0, #0x269]
    52d4:      	ret
    52d8:      	paciasp
    52dc:      	stp	x29, x30, [sp, #-0x10]!
    52e0:      	mov	x29, sp
    52e4:      	ldr	x8, [x0]
    52e8:      	mov	w1, #-0x1               // =-1
    52ec:      	ldr	x8, [x8, #0x18]
    52f0:      	blr	x8
    52f4:      	mov	w0, wzr
    52f8:      	ldp	x29, x30, [sp], #0x10
    52fc:      	autiasp
    5300:      	ret
    5304:      	paciasp
    5308:      	stp	x29, x30, [sp, #-0x30]!
    530c:      	stp	x28, x21, [sp, #0x10]
    5310:      	stp	x20, x19, [sp, #0x20]
    5314:      	mov	x29, sp
    5318:      	sub	sp, sp, #0x6b0
    531c:      	ldr	x8, [x0]
    5320:      	strb	wzr, [x0, #0x26a]
    5324:      	mov	w20, w1
    5328:      	mov	w1, #-0x1               // =-1
    532c:      	mov	x19, x0
    5330:      	ldr	x8, [x8, #0x18]
    5334:      	blr	x8
    5338:      	cbz	x0, 0x5548 <.text+0xc24>
    533c:      	ldr	x8, [x19, #0x8]
    5340:      	and	x9, x20, #0x1
    5344:      	add	x10, sp, #0x68
    5348:      	sub	x20, x0, x9
    534c:      	nop
    5350:      	adr	x0, 0x7ca8 <.text+0x3384>
    5354:      	add	x1, sp, #0x98
    5358:      	stp	x8, x10, [sp, #0x98]
    535c:      	str	x20, [sp, #0xa8]
    5360:      	bl	0xd070 <dl_iterate_phdr@plt>
    5364:      	cbz	w0, 0x5388 <.text+0xa64>
    5368:      	ldr	x8, [sp, #0x78]
    536c:      	cbz	x8, 0x5388 <.text+0xa64>
    5370:      	add	x2, sp, #0x68
    5374:      	mov	x0, x19
    5378:      	mov	x1, x20
    537c:      	mov	w3, wzr
    5380:      	bl	0x79d4 <.text+0x30b0>
    5384:      	tbnz	w0, #0x0, 0x5530 <.text+0xc0c>
    5388:      	nop
    538c:      	adr	x0, 0x15804
    5390:      	bl	0xd0f0 <pthread_rwlock_rdlock@plt>
    5394:      	adrp	x8, 0x15000
    5398:      	adrp	x9, 0x15000
    539c:      	ldr	x8, [x8, #0x5e8]
    53a0:      	ldr	x9, [x9, #0x5f0]
    53a4:      	b	0x53ac <.text+0xa88>
    53a8:      	add	x8, x8, #0x20
    53ac:      	cmp	x8, x9
    53b0:      	b.hs	0x5480 <.text+0xb5c>
    53b4:      	ldr	x10, [x8, #0x8]
    53b8:      	cmp	x10, x20
    53bc:      	b.hi	0x53a8 <.text+0xa84>
    53c0:      	ldr	x10, [x8, #0x10]
    53c4:      	cmp	x10, x20
    53c8:      	b.ls	0x53a8 <.text+0xa84>
    53cc:      	ldr	x21, [x8, #0x18]
    53d0:      	nop
    53d4:      	adr	x0, 0x15804
    53d8:      	bl	0xd0d0 <pthread_rwlock_unlock@plt>
    53dc:      	cbz	x21, 0x548c <.text+0xb68>
    53e0:      	ldr	x0, [x19, #0x8]
    53e4:      	add	x2, sp, #0x38
    53e8:      	mov	x3, sp
    53ec:      	mov	x1, x21
    53f0:      	mov	w4, wzr
    53f4:      	bl	0x4adc <.text+0x1b8>
    53f8:      	cbnz	x0, 0x548c <.text+0xb68>
    53fc:      	add	x0, sp, #0x98
    5400:      	mov	w1, wzr
    5404:      	mov	w2, #0x618              // =1560
    5408:      	bl	0xd0e0 <memset@plt>
    540c:      	ldr	x0, [x19, #0x8]
    5410:      	add	x1, sp, #0x38
    5414:      	mov	x2, sp
    5418:      	add	x5, sp, #0x98
    541c:      	mov	x3, x20
    5420:      	mov	w4, #0x4                // =4
    5424:      	bl	0x5b38 <.text+0x1214>
    5428:      	tbz	w0, #0x0, 0x548c <.text+0xb68>
    542c:      	ldr	x8, [sp, #0x60]
    5430:      	ldr	x9, [sp, #0x20]
    5434:      	ldur	q0, [sp, #0x50]
    5438:      	str	xzr, [x19, #0x248]
    543c:      	str	x8, [x19, #0x230]
    5440:      	ldr	w8, [sp, #0xa8]
    5444:      	str	x9, [x19, #0x238]
    5448:      	mov	w9, #0x3000000          // =50331648
    544c:      	str	x8, [x19, #0x240]
    5450:      	str	w9, [x19, #0x250]
    5454:      	ldp	x8, x9, [sp, #0x38]
    5458:      	str	q0, [x19, #0x220]
    545c:      	str	xzr, [x19, #0x260]
    5460:      	str	x8, [x19, #0x258]
    5464:      	str	w9, [x19, #0x254]
    5468:      	add	sp, sp, #0x6b0
    546c:      	ldp	x20, x19, [sp, #0x20]
    5470:      	ldp	x28, x21, [sp, #0x10]
    5474:      	ldp	x29, x30, [sp], #0x30
    5478:      	autiasp
    547c:      	ret
    5480:      	nop
    5484:      	adr	x0, 0x15804
    5488:      	bl	0xd0d0 <pthread_rwlock_unlock@plt>
    548c:      	ldr	x8, [x19]
    5490:      	mov	x0, x19
    5494:      	mov	w1, #-0x1               // =-1
    5498:      	ldr	x8, [x8, #0x18]
    549c:      	blr	x8
    54a0:      	add	x8, sp, #0x38
    54a4:      	mov	w9, #0x8                // =8
    54a8:      	mov	x20, x0
    54ac:      	stp	x8, x9, [sp, #0x98]
    54b0:      	stp	x0, x9, [sp]
    54b4:      	bl	0xcdb0 <getpid@plt>
    54b8:      	mov	w1, w0
    54bc:      	add	x2, sp, #0x98
    54c0:      	mov	x4, sp
    54c4:      	mov	w0, #0x10e              // =270
    54c8:      	mov	w3, #0x1                // =1
    54cc:      	mov	w5, #0x1                // =1
    54d0:      	mov	w6, wzr
    54d4:      	mov	w21, #0x1               // =1
    54d8:      	bl	0xce10 <syscall@plt>
    54dc:      	cmp	x0, #0x8
    54e0:      	b.ne	0x5568 <.text+0xc44>
    54e4:      	ldr	w8, [sp, #0x38]
    54e8:      	mov	w9, #0x1168             // =4456
    54ec:      	movk	w9, #0xd280, lsl #16
    54f0:      	cmp	w8, w9
    54f4:      	b.ne	0x5568 <.text+0xc44>
    54f8:      	ldr	w8, [sp, #0x3c]
    54fc:      	mov	w9, #0x1                // =1
    5500:      	movk	w9, #0xd400, lsl #16
    5504:      	cmp	w8, w9
    5508:      	b.ne	0x5568 <.text+0xc44>
    550c:      	movi	v0.2d, #0000000000000000
    5510:      	add	x8, x20, #0x4
    5514:      	str	xzr, [x19, #0x260]
    5518:      	str	x8, [x19, #0x228]
    551c:      	mov	w8, #0x1                // =1
    5520:      	str	x20, [x19, #0x220]
    5524:      	strb	w8, [x19, #0x26a]
    5528:      	stp	q0, q0, [x19, #0x240]
    552c:      	str	q0, [x19, #0x230]
    5530:      	add	sp, sp, #0x6b0
    5534:      	ldp	x20, x19, [sp, #0x20]
    5538:      	ldp	x28, x21, [sp, #0x10]
    553c:      	ldp	x29, x30, [sp], #0x30
    5540:      	autiasp
    5544:      	ret
    5548:      	mov	w8, #0x1                // =1
    554c:      	strb	w8, [x19, #0x268]
    5550:      	add	sp, sp, #0x6b0
    5554:      	ldp	x20, x19, [sp, #0x20]
    5558:      	ldp	x28, x21, [sp, #0x10]
    555c:      	ldp	x29, x30, [sp], #0x30
    5560:      	autiasp
    5564:      	ret
    5568:      	strb	w21, [x19, #0x268]
    556c:      	add	sp, sp, #0x6b0
    5570:      	ldp	x20, x19, [sp, #0x20]
    5574:      	ldp	x28, x21, [sp, #0x10]
    5578:      	ldp	x29, x30, [sp], #0x30
    557c:      	autiasp
    5580:      	ret
    5584:      	bti	c
    5588:      	mov	w0, w1
    558c:      	b	0x8328 <.text+0x3a04>
    5590:      	bti	c
    5594:      	ldr	x10, [x0, #0x108]
    5598:      	mov	w9, #0x1                // =1
    559c:      	ldr	x11, [x10, #0x138]
    55a0:      	str	x11, [x0, #0x10]
    55a4:      	ldr	x11, [x10, #0x140]
    55a8:      	str	x11, [x0, #0x18]
    55ac:      	ldr	x11, [x10, #0x148]
    55b0:      	str	x11, [x0, #0x20]
    55b4:      	ldr	x11, [x10, #0x150]
    55b8:      	str	x11, [x0, #0x28]
    55bc:      	ldr	x11, [x10, #0x158]
    55c0:      	str	x11, [x0, #0x30]
    55c4:      	ldr	x11, [x10, #0x160]
    55c8:      	str	x11, [x0, #0x38]
    55cc:      	ldr	x11, [x10, #0x168]
    55d0:      	str	x11, [x0, #0x40]
    55d4:      	ldr	x11, [x10, #0x170]
    55d8:      	str	x11, [x0, #0x48]
    55dc:      	ldr	x11, [x10, #0x178]
    55e0:      	str	x11, [x0, #0x50]
    55e4:      	ldr	x11, [x10, #0x180]
    55e8:      	str	x11, [x0, #0x58]
    55ec:      	ldr	x11, [x10, #0x188]
    55f0:      	str	x11, [x0, #0x60]
    55f4:      	ldr	x11, [x10, #0x190]
    55f8:      	str	x11, [x0, #0x68]
    55fc:      	ldr	x11, [x10, #0x198]
    5600:      	str	x11, [x0, #0x70]
    5604:      	ldr	x11, [x10, #0x1a0]
    5608:      	str	x11, [x0, #0x78]
    560c:      	ldr	x11, [x10, #0x1a8]
    5610:      	str	x11, [x0, #0x80]
    5614:      	ldr	x11, [x10, #0x1b0]
    5618:      	str	x11, [x0, #0x88]
    561c:      	ldr	x11, [x10, #0x1b8]
    5620:      	str	x11, [x0, #0x90]
    5624:      	ldr	x11, [x10, #0x1c0]
    5628:      	str	x11, [x0, #0x98]
    562c:      	ldr	x11, [x10, #0x1c8]
    5630:      	str	x11, [x0, #0xa0]
    5634:      	ldr	x11, [x10, #0x1d0]
    5638:      	str	x11, [x0, #0xa8]
    563c:      	ldr	x11, [x10, #0x1d8]
    5640:      	str	x11, [x0, #0xb0]
    5644:      	ldr	x11, [x10, #0x1e0]
    5648:      	str	x11, [x0, #0xb8]
    564c:      	ldr	x11, [x10, #0x1e8]
    5650:      	str	x11, [x0, #0xc0]
    5654:      	ldr	x11, [x10, #0x1f0]
    5658:      	str	x11, [x0, #0xc8]
    565c:      	ldr	x11, [x10, #0x1f8]
    5660:      	str	x11, [x0, #0xd0]
    5664:      	ldr	x11, [x10, #0x200]
    5668:      	str	x11, [x0, #0xd8]
    566c:      	ldr	x11, [x10, #0x208]
    5670:      	str	x11, [x0, #0xe0]
    5674:      	ldr	x11, [x10, #0x210]
    5678:      	str	x11, [x0, #0xe8]
    567c:      	ldr	x11, [x10, #0x218]
    5680:      	str	x11, [x0, #0xf0]
    5684:      	ldr	x11, [x10, #0x220]
    5688:      	str	x11, [x0, #0xf8]
    568c:      	ldr	x11, [x10, #0x228]
    5690:      	str	x11, [x0, #0x100]
    5694:      	ldr	x11, [x10, #0x230]
    5698:      	str	x11, [x0, #0x108]
    569c:      	ldr	x10, [x10, #0x238]
    56a0:      	strb	w9, [x0, #0x269]
    56a4:      	str	x10, [x0, #0x110]
    56a8:      	mov	w0, #0x1                // =1
    56ac:      	ret
    56b0:      	paciasp
    56b4:      	stp	x29, x30, [sp, #-0x60]!
    56b8:      	stp	x28, x27, [sp, #0x10]
    56bc:      	stp	x26, x25, [sp, #0x20]
    56c0:      	stp	x24, x23, [sp, #0x30]
    56c4:      	stp	x22, x21, [sp, #0x40]
    56c8:      	stp	x20, x19, [sp, #0x50]
    56cc:      	mov	x29, sp
    56d0:      	sub	sp, sp, #0xb10
    56d4:      	mov	x8, x2
    56d8:      	mov	x21, x4
    56dc:      	mov	x19, x3
    56e0:      	mov	x22, x1
    56e4:      	sub	x2, x29, #0x50
    56e8:      	sub	x3, x29, #0x88
    56ec:      	mov	x1, x8
    56f0:      	mov	w4, wzr
    56f4:      	mov	w23, w5
    56f8:      	mov	x20, x0
    56fc:      	bl	0x4adc <.text+0x1b8>
    5700:      	cbnz	x0, 0x57e0 <.text+0xebc>
    5704:      	add	x0, sp, #0x470
    5708:      	mov	w1, wzr
    570c:      	mov	w2, #0x618              // =1560
    5710:      	bl	0xd0e0 <memset@plt>
    5714:      	sub	x1, x29, #0x50
    5718:      	sub	x2, x29, #0x88
    571c:      	add	x5, sp, #0x470
    5720:      	mov	x0, x20
    5724:      	mov	x3, x22
    5728:      	mov	w4, #0x4                // =4
    572c:      	bl	0x5b38 <.text+0x1214>
    5730:      	tbz	w0, #0x0, 0x57e0 <.text+0xebc>
    5734:      	add	x1, sp, #0x470
    5738:      	mov	x0, x20
    573c:      	mov	x2, x19
    5740:      	add	x24, sp, #0x470
    5744:      	bl	0x6780 <.text+0x1e5c>
    5748:      	mov	x22, x0
    574c:      	tbz	w23, #0x0, 0x5778 <.text+0xe54>
    5750:      	ldurb	w8, [x29, #-0x54]
    5754:      	cbz	w8, 0x5778 <.text+0xe54>
    5758:      	ldr	x8, [x19, #0xf8]
    575c:      	and	x8, x8, #0xfffffffffffffff0
    5760:      	cmp	x8, x22
    5764:      	b.hs	0x5778 <.text+0xe54>
    5768:      	stg	x8, [x8]
    576c:      	add	x8, x8, #0x10
    5770:      	cmp	x8, x22
    5774:      	b.lo	0x5768 <.text+0xe44>
    5778:      	add	x0, sp, #0x260
    577c:      	mov	x1, x19
    5780:      	mov	w2, #0x210              // =528
    5784:      	add	x25, sp, #0x260
    5788:      	bl	0xd0b0 <memcpy@plt>
    578c:      	add	x9, x25, #0xf8
    5790:      	add	x8, x25, #0xe8
    5794:      	add	x10, x19, #0xf8
    5798:      	stp	x8, x9, [sp, #0x18]
    579c:      	add	x9, x25, #0x100
    57a0:      	add	x8, x25, #0xf0
    57a4:      	stp	x8, x9, [sp, #0x8]
    57a8:      	add	x9, x25, #0x108
    57ac:      	add	x8, x19, #0xe8
    57b0:      	stp	x8, x9, [sp, #0x40]
    57b4:      	add	x8, x19, #0x100
    57b8:      	mov	x26, xzr
    57bc:      	mov	x23, xzr
    57c0:      	add	x28, x19, #0x108
    57c4:      	stp	x10, x8, [sp, #0x30]
    57c8:      	add	x8, x19, #0xf0
    57cc:      	add	x24, x24, #0x18
    57d0:      	add	x27, sp, #0x260
    57d4:      	str	x22, [sp, #0x358]
    57d8:      	str	x8, [sp, #0x28]
    57dc:      	b	0x5838 <.text+0xf14>
    57e0:      	mov	w0, #-0x1992            // =-6546
    57e4:      	add	sp, sp, #0xb10
    57e8:      	ldp	x20, x19, [sp, #0x50]
    57ec:      	ldp	x22, x21, [sp, #0x40]
    57f0:      	ldp	x24, x23, [sp, #0x30]
    57f4:      	ldp	x26, x25, [sp, #0x20]
    57f8:      	ldp	x28, x27, [sp, #0x10]
    57fc:      	ldp	x29, x30, [sp], #0x60
    5800:      	autiasp
    5804:      	ret
    5808:      	ldr	x8, [x24, #0x8]
    580c:      	mov	x9, #-0x4000000000      // =-274877906944
    5810:      	add	x8, x9, x8, lsl #32
    5814:      	add	x8, x19, x8, asr #29
    5818:      	ldr	d0, [x8, #0x110]
    581c:      	add	x8, x25, x26, lsl #3
    5820:      	stur	d0, [x8, #-0xf0]
    5824:      	add	x26, x26, #0x1
    5828:      	add	x24, x24, #0x10
    582c:      	add	x27, x27, #0x8
    5830:      	cmp	x26, #0x60
    5834:      	b.eq	0x59f8 <.text+0x10d4>
    5838:      	ldr	w8, [x24]
    583c:      	cbz	w8, 0x5874 <.text+0xf50>
    5840:      	and	w9, w26, #0x60
    5844:      	cmp	w9, #0x40
    5848:      	b.ne	0x58b0 <.text+0xf8c>
    584c:      	cmp	w8, #0x4
    5850:      	b.gt	0x58d8 <.text+0xfb4>
    5854:      	movi	d0, #0000000000000000
    5858:      	cmp	w8, #0x1
    585c:      	b.eq	0x581c <.text+0xef8>
    5860:      	cmp	w8, #0x2
    5864:      	b.ne	0x5a9c <.text+0x1178>
    5868:      	ldr	x8, [x24, #0x8]
    586c:      	ldr	d0, [x8, x22]
    5870:      	b	0x581c <.text+0xef8>
    5874:      	ldurb	w8, [x29, #-0x56]
    5878:      	cmp	x26, x8
    587c:      	b.ne	0x5824 <.text+0xf00>
    5880:      	cmp	w8, #0x1e
    5884:      	b.le	0x5978 <.text+0x1054>
    5888:      	cmp	w8, #0x22
    588c:      	mov	x9, x28
    5890:      	b.eq	0x599c <.text+0x1078>
    5894:      	ldr	x9, [sp, #0x38]
    5898:      	cmp	w8, #0x20
    589c:      	b.eq	0x599c <.text+0x1078>
    58a0:      	ldr	x9, [sp, #0x30]
    58a4:      	cmp	w8, #0x1f
    58a8:      	b.eq	0x599c <.text+0x1078>
    58ac:      	b	0x5990 <.text+0x106c>
    58b0:      	ldurb	w8, [x29, #-0x56]
    58b4:      	cmp	x26, x8
    58b8:      	b.ne	0x5904 <.text+0xfe0>
    58bc:      	mov	x0, x20
    58c0:      	mov	x1, x19
    58c4:      	mov	x2, x22
    58c8:      	mov	x3, x24
    58cc:      	bl	0x68b4 <.text+0x1f90>
    58d0:      	mov	x23, x0
    58d4:      	b	0x5824 <.text+0xf00>
    58d8:      	cmp	w8, #0x5
    58dc:      	b.eq	0x5808 <.text+0xee4>
    58e0:      	cmp	w8, #0x6
    58e4:      	b.ne	0x5a9c <.text+0x1178>
    58e8:      	ldr	x0, [x24, #0x8]
    58ec:      	mov	x1, x20
    58f0:      	mov	x2, x19
    58f4:      	mov	x3, x22
    58f8:      	bl	0x7018 <.text+0x26f4>
    58fc:      	ldr	d0, [x0]
    5900:      	b	0x581c <.text+0xef8>
    5904:      	cmp	x26, #0x22
    5908:      	b.ne	0x592c <.text+0x1008>
    590c:      	mov	x0, x20
    5910:      	mov	x1, x19
    5914:      	mov	x2, x22
    5918:      	mov	x3, x24
    591c:      	bl	0x68b4 <.text+0x1f90>
    5920:      	ldr	x8, [sp, #0x48]
    5924:      	str	x0, [x8]
    5928:      	b	0x5824 <.text+0xf00>
    592c:      	sub	w8, w26, #0x40
    5930:      	cmn	w8, #0x20
    5934:      	b.hi	0x5a94 <.text+0x1170>
    5938:      	mov	x0, x20
    593c:      	mov	x1, x19
    5940:      	mov	x2, x22
    5944:      	mov	x3, x24
    5948:      	bl	0x68b4 <.text+0x1f90>
    594c:      	cmp	w26, #0x1e
    5950:      	b.le	0x59a4 <.text+0x1080>
    5954:      	cmp	w26, #0x1f
    5958:      	b.eq	0x59c0 <.text+0x109c>
    595c:      	cmp	w26, #0x22
    5960:      	b.eq	0x59cc <.text+0x10a8>
    5964:      	cmp	w26, #0x20
    5968:      	b.ne	0x59e4 <.text+0x10c0>
    596c:      	ldr	x8, [sp, #0x10]
    5970:      	str	x0, [x8]
    5974:      	b	0x5824 <.text+0xf00>
    5978:      	ldr	x9, [sp, #0x40]
    597c:      	cmp	w8, #0x1d
    5980:      	b.eq	0x599c <.text+0x1078>
    5984:      	ldr	x9, [sp, #0x28]
    5988:      	cmp	w8, #0x1e
    598c:      	b.eq	0x599c <.text+0x1078>
    5990:      	cmp	w8, #0x1c
    5994:      	b.hi	0x5ad0 <.text+0x11ac>
    5998:      	add	x9, x19, x8, lsl #3
    599c:      	ldr	x23, [x9]
    59a0:      	b	0x5824 <.text+0xf00>
    59a4:      	cmp	w26, #0x1d
    59a8:      	b.eq	0x59d8 <.text+0x10b4>
    59ac:      	cmp	w26, #0x1e
    59b0:      	b.ne	0x59e4 <.text+0x10c0>
    59b4:      	ldr	x8, [sp, #0x8]
    59b8:      	str	x0, [x8]
    59bc:      	b	0x5824 <.text+0xf00>
    59c0:      	ldr	x8, [sp, #0x20]
    59c4:      	str	x0, [x8]
    59c8:      	b	0x5824 <.text+0xf00>
    59cc:      	ldr	x8, [sp, #0x48]
    59d0:      	str	x0, [x8]
    59d4:      	b	0x5824 <.text+0xf00>
    59d8:      	ldr	x8, [sp, #0x18]
    59dc:      	str	x0, [x8]
    59e0:      	b	0x5824 <.text+0xf00>
    59e4:      	cmp	x26, #0x1d
    59e8:      	mov	x8, x27
    59ec:      	b.hs	0x5b04 <.text+0x11e0>
    59f0:      	str	x0, [x8]
    59f4:      	b	0x5824 <.text+0xf00>
    59f8:      	ldurb	w8, [x29, #-0x58]
    59fc:      	add	x0, sp, #0x50
    5a00:      	mov	x1, x19
    5a04:      	mov	w2, #0x210              // =528
    5a08:      	strb	w8, [x21]
    5a0c:      	bl	0xd0b0 <memcpy@plt>
    5a10:      	add	x8, sp, #0x470
    5a14:      	add	x8, x8, #0x238
    5a18:      	ldr	q0, [x8]
    5a1c:      	stur	q0, [x29, #-0x20]
    5a20:      	ldur	w8, [x29, #-0x20]
    5a24:      	cbz	w8, 0x5a44 <.text+0x1120>
    5a28:      	add	x1, sp, #0x50
    5a2c:      	sub	x3, x29, #0x20
    5a30:      	mov	x0, x20
    5a34:      	mov	x2, x22
    5a38:      	bl	0x68b4 <.text+0x1f90>
    5a3c:      	tbnz	w0, #0x0, 0x5a4c <.text+0x1128>
    5a40:      	b	0x5a78 <.text+0x1154>
    5a44:      	ldur	x0, [x29, #-0x18]
    5a48:      	tbz	w0, #0x0, 0x5a78 <.text+0x1154>
    5a4c:      	cbz	x23, 0x5a78 <.text+0x1154>
    5a50:      	ldurb	w8, [x29, #-0x55]
    5a54:      	cbz	w8, 0x5a68 <.text+0x1144>
    5a58:      	mov	x17, x23
    5a5c:      	mov	x16, x22
    5a60:      	autib1716
    5a64:      	b	0x5a74 <.text+0x1150>
    5a68:      	mov	x17, x23
    5a6c:      	mov	x16, x22
    5a70:      	autia1716
    5a74:      	mov	x23, x17
    5a78:      	add	x1, sp, #0x260
    5a7c:      	mov	x0, x19
    5a80:      	mov	w2, #0x210              // =528
    5a84:      	str	x23, [sp, #0x360]
    5a88:      	bl	0xd0b0 <memcpy@plt>
    5a8c:      	mov	w0, #0x1                // =1
    5a90:      	b	0x57e4 <.text+0xec0>
    5a94:      	mov	w0, #-0x198e            // =-6542
    5a98:      	b	0x57e4 <.text+0xec0>
    5a9c:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    5aa0:      	nop
    5aa4:      	adr	x1, 0x1af2
    5aa8:      	ldr	x19, [x19, #0x3e0]
    5aac:      	adrp	x2, 0x1000
    5ab0:      	add	x2, x2, #0xb6a
    5ab4:      	adrp	x3, 0x2000
    5ab8:      	add	x3, x3, #0x8e
    5abc:      	add	x0, x19, #0x130
    5ac0:      	bl	0xd080 <fprintf@plt>
    5ac4:      	add	x0, x19, #0x130
    5ac8:      	bl	0xd090 <fflush@plt>
    5acc:      	bl	0xd0a0 <abort@plt>
    5ad0:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    5ad4:      	nop
    5ad8:      	adr	x1, 0x1af2
    5adc:      	ldr	x19, [x19, #0x3e0]
    5ae0:      	adrp	x2, 0x2000
    5ae4:      	add	x2, x2, #0x1b6
    5ae8:      	adrp	x3, 0x1000
    5aec:      	add	x3, x3, #0xf64
    5af0:      	add	x0, x19, #0x130
    5af4:      	bl	0xd080 <fprintf@plt>
    5af8:      	add	x0, x19, #0x130
    5afc:      	bl	0xd090 <fflush@plt>
    5b00:      	bl	0xd0a0 <abort@plt>
    5b04:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    5b08:      	nop
    5b0c:      	adr	x1, 0x1af2
    5b10:      	ldr	x19, [x19, #0x3e0]
    5b14:      	adrp	x2, 0x2000
    5b18:      	add	x2, x2, #0x579
    5b1c:      	adrp	x3, 0x1000
    5b20:      	add	x3, x3, #0xf64
    5b24:      	add	x0, x19, #0x130
    5b28:      	bl	0xd080 <fprintf@plt>
    5b2c:      	add	x0, x19, #0x130
    5b30:      	bl	0xd090 <fflush@plt>
    5b34:      	bl	0xd0a0 <abort@plt>
    5b38:      	paciasp
    5b3c:      	stp	x29, x30, [sp, #-0x60]!
    5b40:      	stp	x28, x27, [sp, #0x10]
    5b44:      	stp	x26, x25, [sp, #0x20]
    5b48:      	stp	x24, x23, [sp, #0x30]
    5b4c:      	stp	x22, x21, [sp, #0x40]
    5b50:      	stp	x20, x19, [sp, #0x50]
    5b54:      	mov	x29, sp
    5b58:      	sub	sp, sp, #0x680
    5b5c:      	ldp	x10, x8, [x2, #0x8]
    5b60:      	mov	x19, sp
    5b64:      	ldr	x9, [x2]
    5b68:      	ldp	x11, x12, [x1, #0x10]
    5b6c:      	mov	x20, x5
    5b70:      	mov	w28, w4
    5b74:      	mov	x22, x2
    5b78:      	add	x9, x10, x9
    5b7c:      	mov	x27, xzr
    5b80:      	nop
    5b84:      	adr	x23, 0x1958
    5b88:      	stp	x8, x9, [x29, #-0x38]
    5b8c:      	mov	x8, #-0x1               // =-1
    5b90:      	ldp	x9, x10, [x1]
    5b94:      	stp	x8, x11, [x29, #-0x28]
    5b98:      	stp	x0, xzr, [x19, #0x18]
    5b9c:      	add	x8, x10, x9
    5ba0:      	sub	x9, x3, x12
    5ba4:      	stp	x8, x9, [x29, #-0x18]
    5ba8:      	add	x8, x19, #0x28
    5bac:      	add	x9, x5, #0x238
    5bb0:      	add	x8, x8, #0x238
    5bb4:      	stp	x8, x9, [x19, #0x8]
    5bb8:      	b	0x5bc8 <.text+0x12a4>
    5bbc:      	add	x27, x27, #0x18
    5bc0:      	cmp	x27, #0x30
    5bc4:      	b.eq	0x64f4 <.text+0x1bd0>
    5bc8:      	sub	x8, x29, #0x38
    5bcc:      	add	x8, x8, x27
    5bd0:      	ldp	x9, x24, [x8]
    5bd4:      	ldr	x21, [x8, #0x10]
    5bd8:      	cmp	x9, x24
    5bdc:      	stur	x9, [x29, #-0x40]
    5be0:      	ccmp	x21, #0x0, #0x4, lo
    5be4:      	b.eq	0x5bbc <.text+0x1298>
    5be8:      	mov	x25, xzr
    5bec:      	mov	x8, x9
    5bf0:      	ldrb	w10, [x8], #0x1
    5bf4:      	stur	x8, [x29, #-0x40]
    5bf8:      	cmp	w10, #0x2f
    5bfc:      	b.hi	0x61ec <.text+0x18c8>
    5c00:      	adr	x11, 0x5c10 <.text+0x12ec>
    5c04:      	ldrh	w12, [x23, x10, lsl #1]
    5c08:      	add	x11, x11, x12, lsl #2
    5c0c:      	br	x11
    5c10:      	bti	j
    5c14:      	ldrb	w3, [x22, #0x18]
    5c18:      	ldr	x0, [x19, #0x18]
    5c1c:      	sub	x1, x29, #0x40
    5c20:      	mov	x2, x24
    5c24:      	mov	x4, xzr
    5c28:      	bl	0x6ac4 <.text+0x21a0>
    5c2c:      	mov	x25, x0
    5c30:      	ldur	x9, [x29, #-0x40]
    5c34:      	cmp	x9, x24
    5c38:      	b.lo	0x64cc <.text+0x1ba8>
    5c3c:      	b	0x5bbc <.text+0x1298>
    5c40:      	bti	j
    5c44:      	sub	x0, x29, #0x40
    5c48:      	mov	x1, x24
    5c4c:      	bl	0x6e50 <.text+0x252c>
    5c50:      	ldur	x10, [x29, #-0x40]
    5c54:      	mov	x9, xzr
    5c58:      	mov	x8, xzr
    5c5c:      	mov	x12, x10
    5c60:      	cmp	x12, x24
    5c64:      	b.eq	0x66e4 <.text+0x1dc0>
    5c68:      	ldrb	w11, [x12], #0x1
    5c6c:      	add	x10, x10, #0x1
    5c70:      	and	x13, x11, #0x7f
    5c74:      	lsl	x13, x13, x9
    5c78:      	add	x9, x9, #0x7
    5c7c:      	orr	x8, x13, x8
    5c80:      	tbnz	w11, #0x7, 0x5c60 <.text+0x133c>
    5c84:      	cmp	x0, #0x60
    5c88:      	stur	x10, [x29, #-0x40]
    5c8c:      	b.hs	0x663c <.text+0x1d18>
    5c90:      	sub	w10, w9, #0x7
    5c94:      	mov	x12, #-0x1              // =-1
    5c98:      	cmp	w10, #0x39
    5c9c:      	mov	w10, #0x3f              // =63
    5ca0:      	lsl	x9, x12, x9
    5ca4:      	ccmp	w11, w10, #0x0, lo
    5ca8:      	ldr	w10, [x22, #0x2c]
    5cac:      	csel	w9, w9, wzr, hi
    5cb0:      	orr	w8, w8, w9
    5cb4:      	mul	w8, w10, w8
    5cb8:      	stp	w0, w8, [x20]
    5cbc:      	ldur	x9, [x29, #-0x40]
    5cc0:      	cmp	x9, x24
    5cc4:      	b.lo	0x64cc <.text+0x1ba8>
    5cc8:      	b	0x5bbc <.text+0x1298>
    5ccc:      	bti	j
    5cd0:      	sub	x0, x29, #0x40
    5cd4:      	mov	x1, x24
    5cd8:      	bl	0x6e50 <.text+0x252c>
    5cdc:      	cmp	x0, #0x60
    5ce0:      	b.hs	0x6528 <.text+0x1c04>
    5ce4:      	ldur	x9, [x29, #-0x40]
    5ce8:      	mov	x10, xzr
    5cec:      	mov	x8, xzr
    5cf0:      	mov	x12, x9
    5cf4:      	cmp	x12, x24
    5cf8:      	b.eq	0x674c <.text+0x1e28>
    5cfc:      	ldrb	w11, [x12], #0x1
    5d00:      	add	x9, x9, #0x1
    5d04:      	and	x13, x11, #0x7f
    5d08:      	lsl	x13, x13, x10
    5d0c:      	add	x10, x10, #0x7
    5d10:      	orr	x8, x13, x8
    5d14:      	tbnz	w11, #0x7, 0x5cf4 <.text+0x13d0>
    5d18:      	add	x12, x20, x0, lsl #4
    5d1c:      	sub	w13, w10, #0x7
    5d20:      	mov	x15, #-0x1              // =-1
    5d24:      	cmp	w13, #0x39
    5d28:      	mov	w14, #0x3f              // =63
    5d2c:      	lsl	x15, x15, x10
    5d30:      	mov	x13, x12
    5d34:      	ccmp	w11, w14, #0x0, lo
    5d38:      	ldrsw	x10, [x22, #0x2c]
    5d3c:      	ldrb	w16, [x13, #0x1c]!
    5d40:      	csel	x11, x15, xzr, hi
    5d44:      	stur	x9, [x29, #-0x40]
    5d48:      	cbnz	w16, 0x5d6c <.text+0x1448>
    5d4c:      	lsl	x9, x0, #4
    5d50:      	add	x15, x19, #0x28
    5d54:      	add	x14, x20, x9
    5d58:      	add	x9, x15, x9
    5d5c:      	ldur	q0, [x14, #0x18]
    5d60:      	mov	w14, #0x1               // =1
    5d64:      	strb	w14, [x13]
    5d68:      	stur	q0, [x9, #0x18]
    5d6c:      	orr	x8, x8, x11
    5d70:      	mov	w9, #0x4                // =4
    5d74:      	b	0x6380 <.text+0x1a5c>
    5d78:      	bti	j
    5d7c:      	sub	x0, x29, #0x40
    5d80:      	mov	x1, x24
    5d84:      	bl	0x6e50 <.text+0x252c>
    5d88:      	cmp	x0, #0x60
    5d8c:      	b.hs	0x64fc <.text+0x1bd8>
    5d90:      	str	w0, [x20]
    5d94:      	ldur	x9, [x29, #-0x40]
    5d98:      	cmp	x9, x24
    5d9c:      	b.lo	0x64cc <.text+0x1ba8>
    5da0:      	b	0x5bbc <.text+0x1298>
    5da4:      	bti	j
    5da8:      	sub	x0, x29, #0x40
    5dac:      	mov	x1, x24
    5db0:      	bl	0x6e50 <.text+0x252c>
    5db4:      	cmp	x0, #0x60
    5db8:      	b.hs	0x658c <.text+0x1c68>
    5dbc:      	mov	x26, x0
    5dc0:      	sub	x0, x29, #0x40
    5dc4:      	mov	x1, x24
    5dc8:      	bl	0x6e50 <.text+0x252c>
    5dcc:      	add	x8, x20, x26, lsl #4
    5dd0:      	ldrsw	x9, [x22, #0x2c]
    5dd4:      	mov	x10, x8
    5dd8:      	ldrb	w11, [x10, #0x1c]!
    5ddc:      	cbnz	w11, 0x5e00 <.text+0x14dc>
    5de0:      	lsl	x11, x26, #4
    5de4:      	add	x13, x19, #0x28
    5de8:      	add	x12, x20, x11
    5dec:      	add	x11, x13, x11
    5df0:      	ldur	q0, [x12, #0x18]
    5df4:      	mov	w12, #0x1               // =1
    5df8:      	strb	w12, [x10]
    5dfc:      	stur	q0, [x11, #0x18]
    5e00:      	mneg	x9, x0, x9
    5e04:      	b	0x6010 <.text+0x16ec>
    5e08:      	bti	j
    5e0c:      	cmp	w28, #0x4
    5e10:      	b.ne	0x64bc <.text+0x1b98>
    5e14:      	ldrb	w8, [x20, #0x23c]
    5e18:      	cbnz	w8, 0x5e30 <.text+0x150c>
    5e1c:      	ldp	x9, x8, [x19, #0x8]
    5e20:      	ldr	q0, [x8]
    5e24:      	mov	w8, #0x1                // =1
    5e28:      	strb	w8, [x20, #0x23c]
    5e2c:      	str	q0, [x9]
    5e30:      	ldr	x8, [x20, #0x240]
    5e34:      	eor	x8, x8, #0x1
    5e38:      	str	x8, [x20, #0x240]
    5e3c:      	ldur	x9, [x29, #-0x40]
    5e40:      	cmp	x9, x24
    5e44:      	b.lo	0x64cc <.text+0x1ba8>
    5e48:      	b	0x5bbc <.text+0x1298>
    5e4c:      	bti	j
    5e50:      	sub	x26, sp, #0x620
    5e54:      	mov	sp, x26
    5e58:      	ldr	x8, [x19, #0x20]
    5e5c:      	mov	x0, x26
    5e60:      	mov	x1, x20
    5e64:      	mov	w2, #0x618              // =1560
    5e68:      	str	x8, [x0], #0x8
    5e6c:      	bl	0xd0b0 <memcpy@plt>
    5e70:      	str	x26, [x19, #0x20]
    5e74:      	ldur	x9, [x29, #-0x40]
    5e78:      	cmp	x9, x24
    5e7c:      	b.lo	0x64cc <.text+0x1ba8>
    5e80:      	b	0x5bbc <.text+0x1298>
    5e84:      	bti	j
    5e88:      	ldrb	w8, [x9, #0x1]
    5e8c:      	ldr	w10, [x22, #0x28]
    5e90:      	add	x9, x9, #0x2
    5e94:      	b	0x6074 <.text+0x1750>
    5e98:      	bti	j
    5e9c:      	ldur	w8, [x9, #0x1]
    5ea0:      	ldr	w10, [x22, #0x28]
    5ea4:      	add	x9, x9, #0x5
    5ea8:      	b	0x6074 <.text+0x1750>
    5eac:      	bti	j
    5eb0:      	sub	x0, x29, #0x40
    5eb4:      	mov	x1, x24
    5eb8:      	bl	0x6e50 <.text+0x252c>
    5ebc:      	cmp	x0, #0x60
    5ec0:      	b.hs	0x650c <.text+0x1be8>
    5ec4:      	add	x8, x20, x0, lsl #4
    5ec8:      	mov	x9, x8
    5ecc:      	ldrb	w10, [x9, #0x1c]!
    5ed0:      	cbnz	w10, 0x5ef4 <.text+0x15d0>
    5ed4:      	lsl	x10, x0, #4
    5ed8:      	add	x12, x19, #0x28
    5edc:      	add	x11, x20, x10
    5ee0:      	add	x10, x12, x10
    5ee4:      	ldur	q0, [x11, #0x18]
    5ee8:      	mov	w11, #0x1               // =1
    5eec:      	strb	w11, [x9]
    5ef0:      	stur	q0, [x10, #0x18]
    5ef4:      	ldur	x9, [x29, #-0x40]
    5ef8:      	mov	w10, #0x7               // =7
    5efc:      	b	0x63ec <.text+0x1ac8>
    5f00:      	bti	j
    5f04:      	sub	x0, x29, #0x40
    5f08:      	mov	x1, x24
    5f0c:      	bl	0x6e50 <.text+0x252c>
    5f10:      	mov	x26, x0
    5f14:      	sub	x0, x29, #0x40
    5f18:      	mov	x1, x24
    5f1c:      	bl	0x6e50 <.text+0x252c>
    5f20:      	cmp	x26, #0x60
    5f24:      	b.hs	0x65a8 <.text+0x1c84>
    5f28:      	stp	w26, w0, [x20]
    5f2c:      	ldur	x9, [x29, #-0x40]
    5f30:      	cmp	x9, x24
    5f34:      	b.lo	0x64cc <.text+0x1ba8>
    5f38:      	b	0x5bbc <.text+0x1298>
    5f3c:      	bti	j
    5f40:      	mov	x10, xzr
    5f44:      	mov	x9, xzr
    5f48:      	mov	x11, x8
    5f4c:      	cmp	x11, x24
    5f50:      	b.eq	0x66b0 <.text+0x1d8c>
    5f54:      	ldrb	w12, [x11], #0x1
    5f58:      	add	x8, x8, #0x1
    5f5c:      	and	x13, x12, #0x7f
    5f60:      	lsl	x13, x13, x10
    5f64:      	add	x10, x10, #0x7
    5f68:      	orr	x9, x13, x9
    5f6c:      	tbnz	w12, #0x7, 0x5f4c <.text+0x1628>
    5f70:      	sub	w11, w10, #0x7
    5f74:      	mov	x13, #-0x1              // =-1
    5f78:      	stur	x8, [x29, #-0x40]
    5f7c:      	cmp	w11, #0x39
    5f80:      	mov	w11, #0x3f              // =63
    5f84:      	lsl	x10, x13, x10
    5f88:      	ccmp	w12, w11, #0x0, lo
    5f8c:      	ldr	w11, [x22, #0x2c]
    5f90:      	csel	w10, w10, wzr, hi
    5f94:      	orr	w9, w9, w10
    5f98:      	mul	w9, w11, w9
    5f9c:      	str	w9, [x20, #0x4]
    5fa0:      	mov	x9, x8
    5fa4:      	cmp	x8, x24
    5fa8:      	b.lo	0x64cc <.text+0x1ba8>
    5fac:      	b	0x5bbc <.text+0x1298>
    5fb0:      	bti	j
    5fb4:      	sub	x0, x29, #0x40
    5fb8:      	mov	x1, x24
    5fbc:      	bl	0x6e50 <.text+0x252c>
    5fc0:      	mov	x26, x0
    5fc4:      	sub	x0, x29, #0x40
    5fc8:      	mov	x1, x24
    5fcc:      	bl	0x6e50 <.text+0x252c>
    5fd0:      	cmp	x26, #0x60
    5fd4:      	b.hs	0x6570 <.text+0x1c4c>
    5fd8:      	add	x8, x20, x26, lsl #4
    5fdc:      	ldrsw	x9, [x22, #0x2c]
    5fe0:      	mov	x10, x8
    5fe4:      	ldrb	w11, [x10, #0x1c]!
    5fe8:      	cbnz	w11, 0x600c <.text+0x16e8>
    5fec:      	lsl	x11, x26, #4
    5ff0:      	add	x13, x19, #0x28
    5ff4:      	add	x12, x20, x11
    5ff8:      	add	x11, x13, x11
    5ffc:      	ldur	q0, [x12, #0x18]
    6000:      	mov	w12, #0x1               // =1
    6004:      	strb	w12, [x10]
    6008:      	stur	q0, [x11, #0x18]
    600c:      	mul	x9, x0, x9
    6010:      	mov	w10, #0x2               // =2
    6014:      	str	w10, [x8, #0x18]
    6018:      	str	x9, [x8, #0x20]
    601c:      	ldur	x9, [x29, #-0x40]
    6020:      	cmp	x9, x24
    6024:      	b.lo	0x64cc <.text+0x1ba8>
    6028:      	b	0x5bbc <.text+0x1298>
    602c:      	bti	j
    6030:      	ldr	x8, [x19, #0x20]
    6034:      	cbz	x8, 0x6688 <.text+0x1d64>
    6038:      	add	x1, x8, #0x8
    603c:      	mov	x0, x20
    6040:      	mov	w2, #0x618              // =1560
    6044:      	mov	x26, x8
    6048:      	bl	0xd0b0 <memcpy@plt>
    604c:      	ldr	x26, [x26]
    6050:      	str	x26, [x19, #0x20]
    6054:      	ldur	x9, [x29, #-0x40]
    6058:      	cmp	x9, x24
    605c:      	b.lo	0x64cc <.text+0x1ba8>
    6060:      	b	0x5bbc <.text+0x1298>
    6064:      	bti	j
    6068:      	ldurh	w8, [x9, #0x1]
    606c:      	ldr	w10, [x22, #0x28]
    6070:      	add	x9, x9, #0x3
    6074:      	mul	w8, w10, w8
    6078:      	add	x25, x25, x8
    607c:      	stur	x9, [x29, #-0x40]
    6080:      	cmp	x9, x24
    6084:      	b.lo	0x64cc <.text+0x1ba8>
    6088:      	b	0x5bbc <.text+0x1298>
    608c:      	bti	j
    6090:      	sub	x0, x29, #0x40
    6094:      	mov	x1, x24
    6098:      	bl	0x6e50 <.text+0x252c>
    609c:      	str	w0, [x20, #0x10]
    60a0:      	ldur	x9, [x29, #-0x40]
    60a4:      	cmp	x9, x24
    60a8:      	b.lo	0x64cc <.text+0x1ba8>
    60ac:      	b	0x5bbc <.text+0x1298>
    60b0:      	bti	j
    60b4:      	sub	x0, x29, #0x40
    60b8:      	mov	x1, x24
    60bc:      	bl	0x6e50 <.text+0x252c>
    60c0:      	cmp	x0, #0x60
    60c4:      	b.hs	0x6554 <.text+0x1c30>
    60c8:      	add	x8, x20, x0, lsl #4
    60cc:      	ldrb	w8, [x8, #0x1c]
    60d0:      	cbz	w8, 0x64bc <.text+0x1b98>
    60d4:      	lsl	x8, x0, #4
    60d8:      	b	0x64a8 <.text+0x1b84>
    60dc:      	bti	j
    60e0:      	sub	x0, x29, #0x40
    60e4:      	mov	x1, x24
    60e8:      	bl	0x6e50 <.text+0x252c>
    60ec:      	cmp	x0, #0x60
    60f0:      	b.hs	0x65c4 <.text+0x1ca0>
    60f4:      	add	x8, x20, x0, lsl #4
    60f8:      	mov	x9, x8
    60fc:      	ldrb	w10, [x9, #0x1c]!
    6100:      	cbnz	w10, 0x6124 <.text+0x1800>
    6104:      	lsl	x10, x0, #4
    6108:      	add	x12, x19, #0x28
    610c:      	add	x11, x20, x10
    6110:      	add	x10, x12, x10
    6114:      	ldur	q0, [x11, #0x18]
    6118:      	mov	w11, #0x1               // =1
    611c:      	strb	w11, [x9]
    6120:      	stur	q0, [x10, #0x18]
    6124:      	mov	w9, #0x1                // =1
    6128:      	str	w9, [x8, #0x18]
    612c:      	ldur	x9, [x29, #-0x40]
    6130:      	cmp	x9, x24
    6134:      	b.lo	0x64cc <.text+0x1ba8>
    6138:      	b	0x5bbc <.text+0x1298>
    613c:      	bti	j
    6140:      	sub	x0, x29, #0x40
    6144:      	mov	x1, x24
    6148:      	bl	0x6e50 <.text+0x252c>
    614c:      	str	w0, [x20, #0x4]
    6150:      	ldur	x9, [x29, #-0x40]
    6154:      	cmp	x9, x24
    6158:      	b.lo	0x64cc <.text+0x1ba8>
    615c:      	b	0x5bbc <.text+0x1298>
    6160:      	bti	j
    6164:      	str	wzr, [x20]
    6168:      	str	x8, [x20, #0x8]
    616c:      	b	0x63f4 <.text+0x1ad0>
    6170:      	bti	j
    6174:      	sub	x0, x29, #0x40
    6178:      	mov	x1, x24
    617c:      	bl	0x6e50 <.text+0x252c>
    6180:      	mov	x26, x0
    6184:      	sub	x0, x29, #0x40
    6188:      	mov	x1, x24
    618c:      	bl	0x6e50 <.text+0x252c>
    6190:      	cmp	x26, #0x60
    6194:      	b.hs	0x6610 <.text+0x1cec>
    6198:      	cmp	x0, #0x60
    619c:      	b.hs	0x6658 <.text+0x1d34>
    61a0:      	add	x8, x20, x26, lsl #4
    61a4:      	mov	x9, x8
    61a8:      	ldrb	w10, [x9, #0x1c]!
    61ac:      	cbnz	w10, 0x61d0 <.text+0x18ac>
    61b0:      	lsl	x10, x26, #4
    61b4:      	add	x12, x19, #0x28
    61b8:      	add	x11, x20, x10
    61bc:      	add	x10, x12, x10
    61c0:      	ldur	q0, [x11, #0x18]
    61c4:      	mov	w11, #0x1               // =1
    61c8:      	strb	w11, [x9]
    61cc:      	stur	q0, [x10, #0x18]
    61d0:      	mov	w9, #0x5                // =5
    61d4:      	str	x0, [x8, #0x20]
    61d8:      	str	w9, [x8, #0x18]
    61dc:      	ldur	x9, [x29, #-0x40]
    61e0:      	cmp	x9, x24
    61e4:      	b.lo	0x64cc <.text+0x1ba8>
    61e8:      	b	0x5bbc <.text+0x1298>
    61ec:      	bti	j
    61f0:      	and	w8, w10, #0xc0
    61f4:      	and	x26, x10, #0x3f
    61f8:      	cmp	w8, #0x40
    61fc:      	b.eq	0x64d8 <.text+0x1bb4>
    6200:      	cmp	w8, #0xc0
    6204:      	b.eq	0x6498 <.text+0x1b74>
    6208:      	cmp	w8, #0x80
    620c:      	b.ne	0x6688 <.text+0x1d64>
    6210:      	sub	x0, x29, #0x40
    6214:      	mov	x1, x24
    6218:      	str	w28, [x19, #0x4]
    621c:      	mov	w28, w26
    6220:      	bl	0x6e50 <.text+0x252c>
    6224:      	add	x8, x20, w26, uxtw #4
    6228:      	ldrsw	x9, [x22, #0x2c]
    622c:      	ldrb	w10, [x8, #0x1c]!
    6230:      	cbnz	w10, 0x6254 <.text+0x1930>
    6234:      	lsl	x10, x28, #4
    6238:      	add	x11, x20, x10
    623c:      	ldur	q0, [x11, #0x18]
    6240:      	add	x11, x19, #0x28
    6244:      	add	x10, x11, x10
    6248:      	stur	q0, [x10, #0x18]
    624c:      	mov	w10, #0x1               // =1
    6250:      	strb	w10, [x8]
    6254:      	mul	x8, x0, x9
    6258:      	add	x9, x20, x28, lsl #4
    625c:      	mov	w10, #0x2               // =2
    6260:      	ldr	w28, [x19, #0x4]
    6264:      	str	w10, [x9, #0x18]
    6268:      	str	x8, [x9, #0x20]
    626c:      	ldur	x9, [x29, #-0x40]
    6270:      	cmp	x9, x24
    6274:      	b.lo	0x64cc <.text+0x1ba8>
    6278:      	b	0x5bbc <.text+0x1298>
    627c:      	bti	j
    6280:      	sub	x0, x29, #0x40
    6284:      	mov	x1, x24
    6288:      	bl	0x6e50 <.text+0x252c>
    628c:      	cmp	x0, #0x60
    6290:      	b.hs	0x6544 <.text+0x1c20>
    6294:      	add	x8, x20, x0, lsl #4
    6298:      	mov	x9, x8
    629c:      	ldrb	w10, [x9, #0x1c]!
    62a0:      	cbnz	w10, 0x62c4 <.text+0x19a0>
    62a4:      	lsl	x10, x0, #4
    62a8:      	add	x12, x19, #0x28
    62ac:      	add	x11, x20, x10
    62b0:      	add	x10, x12, x10
    62b4:      	ldur	q0, [x11, #0x18]
    62b8:      	mov	w11, #0x1               // =1
    62bc:      	strb	w11, [x9]
    62c0:      	stur	q0, [x10, #0x18]
    62c4:      	str	wzr, [x8, #0x18]
    62c8:      	ldur	x9, [x29, #-0x40]
    62cc:      	cmp	x9, x24
    62d0:      	b.lo	0x64cc <.text+0x1ba8>
    62d4:      	b	0x5bbc <.text+0x1298>
    62d8:      	bti	j
    62dc:      	sub	x0, x29, #0x40
    62e0:      	mov	x1, x24
    62e4:      	bl	0x6e50 <.text+0x252c>
    62e8:      	cmp	x0, #0x60
    62ec:      	b.hs	0x65f4 <.text+0x1cd0>
    62f0:      	ldur	x9, [x29, #-0x40]
    62f4:      	mov	x10, xzr
    62f8:      	mov	x8, xzr
    62fc:      	mov	x12, x9
    6300:      	cmp	x12, x24
    6304:      	b.eq	0x6718 <.text+0x1df4>
    6308:      	ldrb	w11, [x12], #0x1
    630c:      	add	x9, x9, #0x1
    6310:      	and	x13, x11, #0x7f
    6314:      	lsl	x13, x13, x10
    6318:      	add	x10, x10, #0x7
    631c:      	orr	x8, x13, x8
    6320:      	tbnz	w11, #0x7, 0x6300 <.text+0x19dc>
    6324:      	add	x12, x20, x0, lsl #4
    6328:      	sub	w13, w10, #0x7
    632c:      	mov	x15, #-0x1              // =-1
    6330:      	cmp	w13, #0x39
    6334:      	mov	w14, #0x3f              // =63
    6338:      	lsl	x15, x15, x10
    633c:      	mov	x13, x12
    6340:      	ccmp	w11, w14, #0x0, lo
    6344:      	ldrsw	x10, [x22, #0x2c]
    6348:      	ldrb	w16, [x13, #0x1c]!
    634c:      	csel	x11, x15, xzr, hi
    6350:      	stur	x9, [x29, #-0x40]
    6354:      	cbnz	w16, 0x6378 <.text+0x1a54>
    6358:      	lsl	x9, x0, #4
    635c:      	add	x15, x19, #0x28
    6360:      	add	x14, x20, x9
    6364:      	add	x9, x15, x9
    6368:      	ldur	q0, [x14, #0x18]
    636c:      	mov	w14, #0x1               // =1
    6370:      	strb	w14, [x13]
    6374:      	stur	q0, [x9, #0x18]
    6378:      	orr	x8, x8, x11
    637c:      	mov	w9, #0x2                // =2
    6380:      	mul	x8, x8, x10
    6384:      	str	w9, [x12, #0x18]
    6388:      	str	x8, [x12, #0x20]
    638c:      	ldur	x9, [x29, #-0x40]
    6390:      	cmp	x9, x24
    6394:      	b.lo	0x64cc <.text+0x1ba8>
    6398:      	b	0x5bbc <.text+0x1298>
    639c:      	bti	j
    63a0:      	sub	x0, x29, #0x40
    63a4:      	mov	x1, x24
    63a8:      	bl	0x6e50 <.text+0x252c>
    63ac:      	cmp	x0, #0x60
    63b0:      	b.hs	0x662c <.text+0x1d08>
    63b4:      	add	x8, x20, x0, lsl #4
    63b8:      	mov	x9, x8
    63bc:      	ldrb	w10, [x9, #0x1c]!
    63c0:      	cbnz	w10, 0x63e4 <.text+0x1ac0>
    63c4:      	lsl	x10, x0, #4
    63c8:      	add	x12, x19, #0x28
    63cc:      	add	x11, x20, x10
    63d0:      	add	x10, x12, x10
    63d4:      	ldur	q0, [x11, #0x18]
    63d8:      	mov	w11, #0x1               // =1
    63dc:      	strb	w11, [x9]
    63e0:      	stur	q0, [x10, #0x18]
    63e4:      	ldur	x9, [x29, #-0x40]
    63e8:      	mov	w10, #0x6               // =6
    63ec:      	str	w10, [x8, #0x18]
    63f0:      	str	x9, [x8, #0x20]
    63f4:      	sub	x0, x29, #0x40
    63f8:      	mov	x1, x24
    63fc:      	bl	0x6e50 <.text+0x252c>
    6400:      	ldur	x8, [x29, #-0x40]
    6404:      	add	x8, x8, x0
    6408:      	stur	x8, [x29, #-0x40]
    640c:      	mov	x9, x8
    6410:      	cmp	x8, x24
    6414:      	b.lo	0x64cc <.text+0x1ba8>
    6418:      	b	0x5bbc <.text+0x1298>
    641c:      	bti	j
    6420:      	sub	x0, x29, #0x40
    6424:      	mov	x1, x24
    6428:      	bl	0x6e50 <.text+0x252c>
    642c:      	mov	x26, x0
    6430:      	cmp	x0, #0x60
    6434:      	b.hs	0x65d4 <.text+0x1cb0>
    6438:      	sub	x0, x29, #0x40
    643c:      	mov	x1, x24
    6440:      	bl	0x6e50 <.text+0x252c>
    6444:      	add	x8, x20, x26, lsl #4
    6448:      	ldrsw	x9, [x22, #0x2c]
    644c:      	mov	x10, x8
    6450:      	ldrb	w11, [x10, #0x1c]!
    6454:      	cbnz	w11, 0x6478 <.text+0x1b54>
    6458:      	lsl	x11, x26, #4
    645c:      	add	x13, x19, #0x28
    6460:      	add	x12, x20, x11
    6464:      	add	x11, x13, x11
    6468:      	ldur	q0, [x12, #0x18]
    646c:      	mov	w12, #0x1               // =1
    6470:      	strb	w12, [x10]
    6474:      	stur	q0, [x11, #0x18]
    6478:      	mul	x9, x0, x9
    647c:      	mov	w10, #0x4               // =4
    6480:      	str	w10, [x8, #0x18]
    6484:      	str	x9, [x8, #0x20]
    6488:      	ldur	x9, [x29, #-0x40]
    648c:      	cmp	x9, x24
    6490:      	b.lo	0x64cc <.text+0x1ba8>
    6494:      	b	0x5bbc <.text+0x1298>
    6498:      	add	x8, x20, x26, lsl #4
    649c:      	ldrb	w8, [x8, #0x1c]
    64a0:      	cbz	w8, 0x64bc <.text+0x1b98>
    64a4:      	lsl	x8, x26, #4
    64a8:      	add	x9, x19, #0x28
    64ac:      	add	x9, x9, x8
    64b0:      	add	x8, x20, x8
    64b4:      	ldur	q0, [x9, #0x18]
    64b8:      	stur	q0, [x8, #0x18]
    64bc:      	bti	j
    64c0:      	ldur	x9, [x29, #-0x40]
    64c4:      	cmp	x9, x24
    64c8:      	b.hs	0x5bbc <.text+0x1298>
    64cc:      	cmp	x25, x21
    64d0:      	b.lo	0x5bec <.text+0x12c8>
    64d4:      	b	0x5bbc <.text+0x1298>
    64d8:      	ldr	w8, [x22, #0x28]
    64dc:      	mul	w8, w8, w26
    64e0:      	add	x25, x25, x8
    64e4:      	ldur	x9, [x29, #-0x40]
    64e8:      	cmp	x9, x24
    64ec:      	b.lo	0x64cc <.text+0x1ba8>
    64f0:      	b	0x5bbc <.text+0x1298>
    64f4:      	mov	w0, #0x1                // =1
    64f8:      	b	0x668c <.text+0x1d68>
    64fc:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6500:      	adrp	x0, 0x2000
    6504:      	add	x0, x0, #0xafe
    6508:      	b	0x6560 <.text+0x1c3c>
    650c:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6510:      	adrp	x0, 0x2000
    6514:      	add	x0, x0, #0x68d
    6518:      	ldr	x8, [x8, #0x3e0]
    651c:      	mov	w1, #0x45               // =69
    6520:      	add	x3, x8, #0x130
    6524:      	b	0x6670 <.text+0x1d4c>
    6528:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    652c:      	adrp	x0, 0x2000
    6530:      	add	x0, x0, #0xdd8
    6534:      	ldr	x8, [x8, #0x3e0]
    6538:      	mov	w1, #0x44               // =68
    653c:      	add	x3, x8, #0x130
    6540:      	b	0x6670 <.text+0x1d4c>
    6544:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6548:      	adrp	x0, 0x2000
    654c:      	add	x0, x0, #0xef7
    6550:      	b	0x6648 <.text+0x1d24>
    6554:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6558:      	adrp	x0, 0x2000
    655c:      	add	x0, x0, #0x5b2
    6560:      	ldr	x8, [x8, #0x3e0]
    6564:      	add	x3, x8, #0x130
    6568:      	mov	w1, #0x47               // =71
    656c:      	b	0x6670 <.text+0x1d4c>
    6570:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6574:      	adrp	x0, 0x1000
    6578:      	add	x0, x0, #0xe8d
    657c:      	ldr	x8, [x8, #0x3e0]
    6580:      	mov	w1, #0x46               // =70
    6584:      	add	x3, x8, #0x130
    6588:      	b	0x6670 <.text+0x1d4c>
    658c:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6590:      	adrp	x0, 0x2000
    6594:      	add	x0, x0, #0x8bb
    6598:      	ldr	x8, [x8, #0x3e0]
    659c:      	mov	w1, #0x53               // =83
    65a0:      	add	x3, x8, #0x130
    65a4:      	b	0x6670 <.text+0x1d4c>
    65a8:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    65ac:      	adrp	x0, 0x1000
    65b0:      	add	x0, x0, #0xbba
    65b4:      	ldr	x8, [x8, #0x3e0]
    65b8:      	mov	w1, #0x3e               // =62
    65bc:      	add	x3, x8, #0x130
    65c0:      	b	0x6670 <.text+0x1d4c>
    65c4:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    65c8:      	adrp	x0, 0x2000
    65cc:      	add	x0, x0, #0xb4a
    65d0:      	b	0x6664 <.text+0x1d40>
    65d4:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    65d8:      	adrp	x1, 0x1000
    65dc:      	add	x1, x1, #0xc51
    65e0:      	ldr	x8, [x8, #0x3e0]
    65e4:      	mov	x2, x26
    65e8:      	add	x0, x8, #0x130
    65ec:      	bl	0xd080 <fprintf@plt>
    65f0:      	b	0x6678 <.text+0x1d54>
    65f4:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    65f8:      	adrp	x0, 0x2000
    65fc:      	add	x0, x0, #0x2e4
    6600:      	ldr	x8, [x8, #0x3e0]
    6604:      	mov	w1, #0x49               // =73
    6608:      	add	x3, x8, #0x130
    660c:      	b	0x6670 <.text+0x1d4c>
    6610:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6614:      	adrp	x0, 0x2000
    6618:      	add	x0, x0, #0xabe
    661c:      	ldr	x8, [x8, #0x3e0]
    6620:      	mov	w1, #0x3f               // =63
    6624:      	add	x3, x8, #0x130
    6628:      	b	0x6670 <.text+0x1d4c>
    662c:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6630:      	adrp	x0, 0x2000
    6634:      	add	x0, x0, #0x259
    6638:      	b	0x6648 <.text+0x1d24>
    663c:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6640:      	adrp	x0, 0x1000
    6644:      	add	x0, x0, #0xd58
    6648:      	ldr	x8, [x8, #0x3e0]
    664c:      	add	x3, x8, #0x130
    6650:      	mov	w1, #0x41               // =65
    6654:      	b	0x6670 <.text+0x1d4c>
    6658:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    665c:      	adrp	x0, 0x2000
    6660:      	add	x0, x0, #0x127
    6664:      	ldr	x8, [x8, #0x3e0]
    6668:      	add	x3, x8, #0x130
    666c:      	mov	w1, #0x40               // =64
    6670:      	mov	w2, #0x1                // =1
    6674:      	bl	0xd100 <fwrite@plt>
    6678:      	adrp	x8, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    667c:      	ldr	x8, [x8, #0x3e0]
    6680:      	add	x0, x8, #0x130
    6684:      	bl	0xd090 <fflush@plt>
    6688:      	mov	w0, wzr
    668c:      	mov	sp, x29
    6690:      	ldp	x20, x19, [sp, #0x50]
    6694:      	ldp	x22, x21, [sp, #0x40]
    6698:      	ldp	x24, x23, [sp, #0x30]
    669c:      	ldp	x26, x25, [sp, #0x20]
    66a0:      	ldp	x28, x27, [sp, #0x10]
    66a4:      	ldp	x29, x30, [sp], #0x60
    66a8:      	autiasp
    66ac:      	ret
    66b0:      	adrp	x20, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    66b4:      	nop
    66b8:      	adr	x1, 0x1af2
    66bc:      	ldr	x20, [x20, #0x3e0]
    66c0:      	adrp	x2, 0x2000
    66c4:      	add	x2, x2, #0x398
    66c8:      	adrp	x3, 0x1000
    66cc:      	add	x3, x3, #0xfd2
    66d0:      	add	x0, x20, #0x130
    66d4:      	bl	0xd080 <fprintf@plt>
    66d8:      	add	x0, x20, #0x130
    66dc:      	bl	0xd090 <fflush@plt>
    66e0:      	bl	0xd0a0 <abort@plt>
    66e4:      	adrp	x20, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    66e8:      	nop
    66ec:      	adr	x1, 0x1af2
    66f0:      	ldr	x20, [x20, #0x3e0]
    66f4:      	adrp	x2, 0x2000
    66f8:      	add	x2, x2, #0x398
    66fc:      	adrp	x3, 0x1000
    6700:      	add	x3, x3, #0xfd2
    6704:      	add	x0, x20, #0x130
    6708:      	bl	0xd080 <fprintf@plt>
    670c:      	add	x0, x20, #0x130
    6710:      	bl	0xd090 <fflush@plt>
    6714:      	bl	0xd0a0 <abort@plt>
    6718:      	adrp	x20, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    671c:      	nop
    6720:      	adr	x1, 0x1af2
    6724:      	ldr	x20, [x20, #0x3e0]
    6728:      	adrp	x2, 0x2000
    672c:      	add	x2, x2, #0x398
    6730:      	adrp	x3, 0x1000
    6734:      	add	x3, x3, #0xfd2
    6738:      	add	x0, x20, #0x130
    673c:      	bl	0xd080 <fprintf@plt>
    6740:      	add	x0, x20, #0x130
    6744:      	bl	0xd090 <fflush@plt>
    6748:      	bl	0xd0a0 <abort@plt>
    674c:      	adrp	x20, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6750:      	nop
    6754:      	adr	x1, 0x1af2
    6758:      	ldr	x20, [x20, #0x3e0]
    675c:      	adrp	x2, 0x2000
    6760:      	add	x2, x2, #0x398
    6764:      	adrp	x3, 0x1000
    6768:      	add	x3, x3, #0xfd2
    676c:      	add	x0, x20, #0x130
    6770:      	bl	0xd080 <fprintf@plt>
    6774:      	add	x0, x20, #0x130
    6778:      	bl	0xd090 <fflush@plt>
    677c:      	bl	0xd0a0 <abort@plt>
    6780:      	bti	c
    6784:      	ldr	w8, [x1]
    6788:      	cmp	w8, #0x1d
    678c:      	b.gt	0x67a8 <.text+0x1e84>
    6790:      	tbz	w8, #0x1f, 0x67d4 <.text+0x1eb0>
    6794:      	cmn	w8, #0x2
    6798:      	b.eq	0x67c0 <.text+0x1e9c>
    679c:      	cmn	w8, #0x1
    67a0:      	b.eq	0x6804 <.text+0x1ee0>
    67a4:      	b	0x6854 <.text+0x1f30>
    67a8:      	cmp	w8, #0x1f
    67ac:      	b.gt	0x67f4 <.text+0x1ed0>
    67b0:      	cmp	w8, #0x1e
    67b4:      	b.eq	0x6818 <.text+0x1ef4>
    67b8:      	cmp	w8, #0x1f
    67bc:      	b.ne	0x6854 <.text+0x1f30>
    67c0:      	add	x8, x2, #0xf8
    67c4:      	ldr	x8, [x8]
    67c8:      	ldrsw	x9, [x1, #0x4]
    67cc:      	add	x0, x8, x9
    67d0:      	ret
    67d4:      	cbz	w8, 0x682c <.text+0x1f08>
    67d8:      	cmp	w8, #0x1d
    67dc:      	b.ne	0x6854 <.text+0x1f30>
    67e0:      	add	x8, x2, #0xe8
    67e4:      	ldr	x8, [x8]
    67e8:      	ldrsw	x9, [x1, #0x4]
    67ec:      	add	x0, x8, x9
    67f0:      	ret
    67f4:      	cmp	w8, #0x22
    67f8:      	b.eq	0x6840 <.text+0x1f1c>
    67fc:      	cmp	w8, #0x20
    6800:      	b.ne	0x6854 <.text+0x1f30>
    6804:      	add	x8, x2, #0x100
    6808:      	ldr	x8, [x8]
    680c:      	ldrsw	x9, [x1, #0x4]
    6810:      	add	x0, x8, x9
    6814:      	ret
    6818:      	add	x8, x2, #0xf0
    681c:      	ldr	x8, [x8]
    6820:      	ldrsw	x9, [x1, #0x4]
    6824:      	add	x0, x8, x9
    6828:      	ret
    682c:      	ldr	x8, [x1, #0x8]
    6830:      	mov	x1, x0
    6834:      	mov	x3, xzr
    6838:      	mov	x0, x8
    683c:      	b	0x7018 <.text+0x26f4>
    6840:      	add	x8, x2, #0x108
    6844:      	ldr	x8, [x8]
    6848:      	ldrsw	x9, [x1, #0x4]
    684c:      	add	x0, x8, x9
    6850:      	ret
    6854:      	cmp	w8, #0x1c
    6858:      	b.hi	0x6870 <.text+0x1f4c>
    685c:      	add	x8, x2, x8, lsl #3
    6860:      	ldr	x8, [x8]
    6864:      	ldrsw	x9, [x1, #0x4]
    6868:      	add	x0, x8, x9
    686c:      	ret
    6870:      	paciasp
    6874:      	stp	x29, x30, [sp, #-0x20]!
    6878:      	str	x19, [sp, #0x10]
    687c:      	mov	x29, sp
    6880:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6884:      	nop
    6888:      	adr	x1, 0x1af2
    688c:      	ldr	x19, [x19, #0x3e0]
    6890:      	adrp	x2, 0x2000
    6894:      	add	x2, x2, #0x1b6
    6898:      	adrp	x3, 0x1000
    689c:      	add	x3, x3, #0xf64
    68a0:      	add	x0, x19, #0x130
    68a4:      	bl	0xd080 <fprintf@plt>
    68a8:      	add	x0, x19, #0x130
    68ac:      	bl	0xd090 <fflush@plt>
    68b0:      	bl	0xd0a0 <abort@plt>
    68b4:      	paciasp
    68b8:      	stp	x29, x30, [sp, #-0x20]!
    68bc:      	str	x19, [sp, #0x10]
    68c0:      	mov	x29, sp
    68c4:      	ldr	w9, [x3]
    68c8:      	mov	x8, x2
    68cc:      	cmp	w9, #0x4
    68d0:      	b.gt	0x6904 <.text+0x1fe0>
    68d4:      	cmp	w9, #0x1
    68d8:      	b.eq	0x695c <.text+0x2038>
    68dc:      	cmp	w9, #0x2
    68e0:      	b.eq	0x68ec <.text+0x1fc8>
    68e4:      	cmp	w9, #0x3
    68e8:      	b.ne	0x6a5c <.text+0x2138>
    68ec:      	ldr	x9, [x3, #0x8]
    68f0:      	ldr	x0, [x9, x8]
    68f4:      	ldr	x19, [sp, #0x10]
    68f8:      	ldp	x29, x30, [sp], #0x20
    68fc:      	autiasp
    6900:      	ret
    6904:      	mov	x2, x1
    6908:      	cmp	w9, #0x5
    690c:      	b.eq	0x6970 <.text+0x204c>
    6910:      	mov	x1, x0
    6914:      	cmp	w9, #0x6
    6918:      	b.eq	0x693c <.text+0x2018>
    691c:      	cmp	w9, #0x7
    6920:      	b.ne	0x6a5c <.text+0x2138>
    6924:      	ldr	x0, [x3, #0x8]
    6928:      	mov	x3, x8
    692c:      	ldr	x19, [sp, #0x10]
    6930:      	ldp	x29, x30, [sp], #0x20
    6934:      	autiasp
    6938:      	b	0x7018 <.text+0x26f4>
    693c:      	ldr	x0, [x3, #0x8]
    6940:      	mov	x3, x8
    6944:      	bl	0x7018 <.text+0x26f4>
    6948:      	ldr	x0, [x0]
    694c:      	ldr	x19, [sp, #0x10]
    6950:      	ldp	x29, x30, [sp], #0x20
    6954:      	autiasp
    6958:      	ret
    695c:      	mov	x0, xzr
    6960:      	ldr	x19, [sp, #0x10]
    6964:      	ldp	x29, x30, [sp], #0x20
    6968:      	autiasp
    696c:      	ret
    6970:      	ldr	x8, [x3, #0x8]
    6974:      	cmp	w8, #0x1d
    6978:      	b.le	0x6998 <.text+0x2074>
    697c:      	cmp	w8, #0x1f
    6980:      	b.gt	0x69c8 <.text+0x20a4>
    6984:      	cmp	w8, #0x1e
    6988:      	b.eq	0x6a2c <.text+0x2108>
    698c:      	cmp	w8, #0x1f
    6990:      	b.eq	0x69f0 <.text+0x20cc>
    6994:      	b	0x6a08 <.text+0x20e4>
    6998:      	cmn	w8, #0x2
    699c:      	b.eq	0x69f0 <.text+0x20cc>
    69a0:      	cmn	w8, #0x1
    69a4:      	b.eq	0x69d8 <.text+0x20b4>
    69a8:      	cmp	w8, #0x1d
    69ac:      	b.ne	0x6a08 <.text+0x20e4>
    69b0:      	add	x8, x2, #0xe8
    69b4:      	ldr	x0, [x8]
    69b8:      	ldr	x19, [sp, #0x10]
    69bc:      	ldp	x29, x30, [sp], #0x20
    69c0:      	autiasp
    69c4:      	ret
    69c8:      	cmp	w8, #0x22
    69cc:      	b.eq	0x6a44 <.text+0x2120>
    69d0:      	cmp	w8, #0x20
    69d4:      	b.ne	0x6a08 <.text+0x20e4>
    69d8:      	add	x8, x2, #0x100
    69dc:      	ldr	x0, [x8]
    69e0:      	ldr	x19, [sp, #0x10]
    69e4:      	ldp	x29, x30, [sp], #0x20
    69e8:      	autiasp
    69ec:      	ret
    69f0:      	add	x8, x2, #0xf8
    69f4:      	ldr	x0, [x8]
    69f8:      	ldr	x19, [sp, #0x10]
    69fc:      	ldp	x29, x30, [sp], #0x20
    6a00:      	autiasp
    6a04:      	ret
    6a08:      	cmp	w8, #0x1c
    6a0c:      	b.hi	0x6a90 <.text+0x216c>
    6a10:      	and	x8, x8, #0xffffffff
    6a14:      	add	x8, x2, x8, lsl #3
    6a18:      	ldr	x0, [x8]
    6a1c:      	ldr	x19, [sp, #0x10]
    6a20:      	ldp	x29, x30, [sp], #0x20
    6a24:      	autiasp
    6a28:      	ret
    6a2c:      	add	x8, x2, #0xf0
    6a30:      	ldr	x0, [x8]
    6a34:      	ldr	x19, [sp, #0x10]
    6a38:      	ldp	x29, x30, [sp], #0x20
    6a3c:      	autiasp
    6a40:      	ret
    6a44:      	add	x8, x2, #0x108
    6a48:      	ldr	x0, [x8]
    6a4c:      	ldr	x19, [sp, #0x10]
    6a50:      	ldp	x29, x30, [sp], #0x20
    6a54:      	autiasp
    6a58:      	ret
    6a5c:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6a60:      	nop
    6a64:      	adr	x1, 0x1af2
    6a68:      	ldr	x19, [x19, #0x3e0]
    6a6c:      	adrp	x2, 0x2000
    6a70:      	add	x2, x2, #0x198
    6a74:      	adrp	x3, 0x1000
    6a78:      	add	x3, x3, #0xf7f
    6a7c:      	add	x0, x19, #0x130
    6a80:      	bl	0xd080 <fprintf@plt>
    6a84:      	add	x0, x19, #0x130
    6a88:      	bl	0xd090 <fflush@plt>
    6a8c:      	bl	0xd0a0 <abort@plt>
    6a90:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6a94:      	nop
    6a98:      	adr	x1, 0x1af2
    6a9c:      	ldr	x19, [x19, #0x3e0]
    6aa0:      	adrp	x2, 0x2000
    6aa4:      	add	x2, x2, #0x1b6
    6aa8:      	adrp	x3, 0x1000
    6aac:      	add	x3, x3, #0xf64
    6ab0:      	add	x0, x19, #0x130
    6ab4:      	bl	0xd080 <fprintf@plt>
    6ab8:      	add	x0, x19, #0x130
    6abc:      	bl	0xd090 <fflush@plt>
    6ac0:      	bl	0xd0a0 <abort@plt>
    6ac4:      	paciasp
    6ac8:      	stp	x29, x30, [sp, #-0x30]!
    6acc:      	str	x21, [sp, #0x10]
    6ad0:      	stp	x20, x19, [sp, #0x20]
    6ad4:      	mov	x29, sp
    6ad8:      	and	w8, w3, #0xf
    6adc:      	ldr	x19, [x1]
    6ae0:      	cmp	w8, #0x3
    6ae4:      	b.le	0x6b0c <.text+0x21e8>
    6ae8:      	cmp	w8, #0x9
    6aec:      	b.le	0x6b80 <.text+0x225c>
    6af0:      	cmp	w8, #0xa
    6af4:      	b.eq	0x6c50 <.text+0x232c>
    6af8:      	cmp	w8, #0xb
    6afc:      	b.eq	0x6c70 <.text+0x234c>
    6b00:      	cmp	w8, #0xc
    6b04:      	b.eq	0x6c10 <.text+0x22ec>
    6b08:      	b	0x6e1c <.text+0x24f8>
    6b0c:      	cmp	w8, #0x1
    6b10:      	b.gt	0x6b50 <.text+0x222c>
    6b14:      	cbz	w8, 0x6c10 <.text+0x22ec>
    6b18:      	cmp	w8, #0x1
    6b1c:      	b.ne	0x6e1c <.text+0x24f8>
    6b20:      	mov	x0, x1
    6b24:      	mov	x1, x2
    6b28:      	mov	w20, w3
    6b2c:      	mov	x21, x4
    6b30:      	bl	0x6e50 <.text+0x252c>
    6b34:      	mov	x4, x21
    6b38:      	mov	w3, w20
    6b3c:      	and	w8, w20, #0xff
    6b40:      	ubfx	w8, w8, #4, #3
    6b44:      	cmp	w8, #0x1
    6b48:      	b.le	0x6c8c <.text+0x2368>
    6b4c:      	b	0x6bf8 <.text+0x22d4>
    6b50:      	cmp	w8, #0x2
    6b54:      	b.eq	0x6c30 <.text+0x230c>
    6b58:      	cmp	w8, #0x3
    6b5c:      	b.ne	0x6e1c <.text+0x24f8>
    6b60:      	mov	x8, x19
    6b64:      	ldr	w0, [x8], #0x4
    6b68:      	str	x8, [x1]
    6b6c:      	and	w8, w3, #0xff
    6b70:      	ubfx	w8, w8, #4, #3
    6b74:      	cmp	w8, #0x1
    6b78:      	b.le	0x6c8c <.text+0x2368>
    6b7c:      	b	0x6bf8 <.text+0x22d4>
    6b80:      	cmp	w8, #0x4
    6b84:      	b.eq	0x6c10 <.text+0x22ec>
    6b88:      	cmp	w8, #0x9
    6b8c:      	b.ne	0x6e1c <.text+0x24f8>
    6b90:      	mov	x10, xzr
    6b94:      	mov	x8, xzr
    6b98:      	mov	x9, x19
    6b9c:      	mov	x11, x19
    6ba0:      	cmp	x11, x2
    6ba4:      	b.eq	0x6ccc <.text+0x23a8>
    6ba8:      	ldrb	w12, [x11], #0x1
    6bac:      	add	x9, x9, #0x1
    6bb0:      	and	x13, x12, #0x7f
    6bb4:      	lsl	x13, x13, x10
    6bb8:      	add	x10, x10, #0x7
    6bbc:      	orr	x8, x13, x8
    6bc0:      	tbnz	w12, #0x7, 0x6ba0 <.text+0x227c>
    6bc4:      	sub	w11, w10, #0x7
    6bc8:      	mov	x13, #-0x1              // =-1
    6bcc:      	str	x9, [x1]
    6bd0:      	cmp	w11, #0x39
    6bd4:      	mov	w11, #0x3f              // =63
    6bd8:      	lsl	x10, x13, x10
    6bdc:      	ccmp	w12, w11, #0x0, lo
    6be0:      	csel	x10, x10, xzr, hi
    6be4:      	orr	x0, x8, x10
    6be8:      	and	w8, w3, #0xff
    6bec:      	ubfx	w8, w8, #4, #3
    6bf0:      	cmp	w8, #0x1
    6bf4:      	b.le	0x6c8c <.text+0x2368>
    6bf8:      	cmp	w8, #0x3
    6bfc:      	b.gt	0x6d00 <.text+0x23dc>
    6c00:      	b.ne	0x6d44 <.text+0x2420>
    6c04:      	cbz	x4, 0x6db4 <.text+0x2490>
    6c08:      	add	x0, x0, x4
    6c0c:      	b	0x6c9c <.text+0x2378>
    6c10:      	mov	x8, x19
    6c14:      	ldr	x0, [x8], #0x8
    6c18:      	str	x8, [x1]
    6c1c:      	and	w8, w3, #0xff
    6c20:      	ubfx	w8, w8, #4, #3
    6c24:      	cmp	w8, #0x1
    6c28:      	b.le	0x6c8c <.text+0x2368>
    6c2c:      	b	0x6bf8 <.text+0x22d4>
    6c30:      	mov	x8, x19
    6c34:      	ldrh	w0, [x8], #0x2
    6c38:      	str	x8, [x1]
    6c3c:      	and	w8, w3, #0xff
    6c40:      	ubfx	w8, w8, #4, #3
    6c44:      	cmp	w8, #0x1
    6c48:      	b.le	0x6c8c <.text+0x2368>
    6c4c:      	b	0x6bf8 <.text+0x22d4>
    6c50:      	mov	x8, x19
    6c54:      	ldrsh	x0, [x8], #0x2
    6c58:      	str	x8, [x1]
    6c5c:      	and	w8, w3, #0xff
    6c60:      	ubfx	w8, w8, #4, #3
    6c64:      	cmp	w8, #0x1
    6c68:      	b.le	0x6c8c <.text+0x2368>
    6c6c:      	b	0x6bf8 <.text+0x22d4>
    6c70:      	mov	x8, x19
    6c74:      	ldrsw	x0, [x8], #0x4
    6c78:      	str	x8, [x1]
    6c7c:      	and	w8, w3, #0xff
    6c80:      	ubfx	w8, w8, #4, #3
    6c84:      	cmp	w8, #0x1
    6c88:      	b.gt	0x6bf8 <.text+0x22d4>
    6c8c:      	cbz	w8, 0x6c9c <.text+0x2378>
    6c90:      	cmp	w8, #0x1
    6c94:      	b.ne	0x6de8 <.text+0x24c4>
    6c98:      	add	x0, x0, x19
    6c9c:      	tbnz	w3, #0x7, 0x6cb4 <.text+0x2390>
    6ca0:      	ldp	x20, x19, [sp, #0x20]
    6ca4:      	ldr	x21, [sp, #0x10]
    6ca8:      	ldp	x29, x30, [sp], #0x30
    6cac:      	autiasp
    6cb0:      	ret
    6cb4:      	ldr	x0, [x0]
    6cb8:      	ldp	x20, x19, [sp, #0x20]
    6cbc:      	ldr	x21, [sp, #0x10]
    6cc0:      	ldp	x29, x30, [sp], #0x30
    6cc4:      	autiasp
    6cc8:      	ret
    6ccc:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6cd0:      	nop
    6cd4:      	adr	x1, 0x1af2
    6cd8:      	ldr	x19, [x19, #0x3e0]
    6cdc:      	adrp	x2, 0x2000
    6ce0:      	add	x2, x2, #0x398
    6ce4:      	adrp	x3, 0x1000
    6ce8:      	add	x3, x3, #0xfd2
    6cec:      	add	x0, x19, #0x130
    6cf0:      	bl	0xd080 <fprintf@plt>
    6cf4:      	add	x0, x19, #0x130
    6cf8:      	bl	0xd090 <fflush@plt>
    6cfc:      	bl	0xd0a0 <abort@plt>
    6d00:      	cmp	w8, #0x4
    6d04:      	b.eq	0x6d80 <.text+0x245c>
    6d08:      	cmp	w8, #0x5
    6d0c:      	b.ne	0x6de8 <.text+0x24c4>
    6d10:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6d14:      	nop
    6d18:      	adr	x1, 0x1af2
    6d1c:      	ldr	x19, [x19, #0x3e0]
    6d20:      	adrp	x2, 0x2000
    6d24:      	add	x2, x2, #0xe1d
    6d28:      	adrp	x3, 0x2000
    6d2c:      	add	x3, x3, #0x168
    6d30:      	add	x0, x19, #0x130
    6d34:      	bl	0xd080 <fprintf@plt>
    6d38:      	add	x0, x19, #0x130
    6d3c:      	bl	0xd090 <fflush@plt>
    6d40:      	bl	0xd0a0 <abort@plt>
    6d44:      	cmp	w8, #0x2
    6d48:      	b.ne	0x6de8 <.text+0x24c4>
    6d4c:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6d50:      	nop
    6d54:      	adr	x1, 0x1af2
    6d58:      	ldr	x19, [x19, #0x3e0]
    6d5c:      	adrp	x2, 0x2000
    6d60:      	add	x2, x2, #0xe1d
    6d64:      	adrp	x3, 0x2000
    6d68:      	add	x3, x3, #0x5fa
    6d6c:      	add	x0, x19, #0x130
    6d70:      	bl	0xd080 <fprintf@plt>
    6d74:      	add	x0, x19, #0x130
    6d78:      	bl	0xd090 <fflush@plt>
    6d7c:      	bl	0xd0a0 <abort@plt>
    6d80:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6d84:      	nop
    6d88:      	adr	x1, 0x1af2
    6d8c:      	ldr	x19, [x19, #0x3e0]
    6d90:      	adrp	x2, 0x2000
    6d94:      	add	x2, x2, #0xe1d
    6d98:      	adrp	x3, 0x1000
    6d9c:      	add	x3, x3, #0xb06
    6da0:      	add	x0, x19, #0x130
    6da4:      	bl	0xd080 <fprintf@plt>
    6da8:      	add	x0, x19, #0x130
    6dac:      	bl	0xd090 <fflush@plt>
    6db0:      	bl	0xd0a0 <abort@plt>
    6db4:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6db8:      	nop
    6dbc:      	adr	x1, 0x1af2
    6dc0:      	ldr	x19, [x19, #0x3e0]
    6dc4:      	adrp	x2, 0x2000
    6dc8:      	add	x2, x2, #0xe1d
    6dcc:      	adrp	x3, 0x2000
    6dd0:      	add	x3, x3, #0x84e
    6dd4:      	add	x0, x19, #0x130
    6dd8:      	bl	0xd080 <fprintf@plt>
    6ddc:      	add	x0, x19, #0x130
    6de0:      	bl	0xd090 <fflush@plt>
    6de4:      	bl	0xd0a0 <abort@plt>
    6de8:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6dec:      	nop
    6df0:      	adr	x1, 0x1af2
    6df4:      	ldr	x19, [x19, #0x3e0]
    6df8:      	adrp	x2, 0x2000
    6dfc:      	add	x2, x2, #0xe1d
    6e00:      	adrp	x3, 0x2000
    6e04:      	add	x3, x3, #0x37f
    6e08:      	add	x0, x19, #0x130
    6e0c:      	bl	0xd080 <fprintf@plt>
    6e10:      	add	x0, x19, #0x130
    6e14:      	bl	0xd090 <fflush@plt>
    6e18:      	bl	0xd0a0 <abort@plt>
    6e1c:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6e20:      	nop
    6e24:      	adr	x1, 0x1af2
    6e28:      	ldr	x19, [x19, #0x3e0]
    6e2c:      	adrp	x2, 0x2000
    6e30:      	add	x2, x2, #0xe1d
    6e34:      	adrp	x3, 0x2000
    6e38:      	add	x3, x3, #0x37f
    6e3c:      	add	x0, x19, #0x130
    6e40:      	bl	0xd080 <fprintf@plt>
    6e44:      	add	x0, x19, #0x130
    6e48:      	bl	0xd090 <fflush@plt>
    6e4c:      	bl	0xd0a0 <abort@plt>
    6e50:      	paciasp
    6e54:      	stp	x29, x30, [sp, #-0x20]!
    6e58:      	str	x19, [sp, #0x10]
    6e5c:      	mov	x29, sp
    6e60:      	ldr	x9, [x0]
    6e64:      	cmp	x9, x1
    6e68:      	b.eq	0x6fb0 <.text+0x268c>
    6e6c:      	mov	x10, x9
    6e70:      	mov	x8, x0
    6e74:      	ldrb	w11, [x10], #0x1
    6e78:      	and	x0, x11, #0x7f
    6e7c:      	tbnz	w11, #0x7, 0x6e94 <.text+0x2570>
    6e80:      	str	x10, [x8]
    6e84:      	ldr	x19, [sp, #0x10]
    6e88:      	ldp	x29, x30, [sp], #0x20
    6e8c:      	autiasp
    6e90:      	ret
    6e94:      	cmp	x10, x1
    6e98:      	b.eq	0x6fb0 <.text+0x268c>
    6e9c:      	ldrsb	w11, [x9, #0x1]
    6ea0:      	and	w10, w11, #0x7f
    6ea4:      	orr	x0, x0, x10, lsl #7
    6ea8:      	add	x10, x9, #0x2
    6eac:      	tbz	w11, #0x1f, 0x6e80 <.text+0x255c>
    6eb0:      	cmp	x10, x1
    6eb4:      	b.eq	0x6fb0 <.text+0x268c>
    6eb8:      	ldrsb	w11, [x9, #0x2]
    6ebc:      	and	w10, w11, #0x7f
    6ec0:      	orr	x0, x0, x10, lsl #14
    6ec4:      	add	x10, x9, #0x3
    6ec8:      	tbz	w11, #0x1f, 0x6e80 <.text+0x255c>
    6ecc:      	cmp	x10, x1
    6ed0:      	b.eq	0x6fb0 <.text+0x268c>
    6ed4:      	ldrsb	w11, [x9, #0x3]
    6ed8:      	and	w10, w11, #0x7f
    6edc:      	orr	x0, x0, x10, lsl #21
    6ee0:      	add	x10, x9, #0x4
    6ee4:      	tbz	w11, #0x1f, 0x6e80 <.text+0x255c>
    6ee8:      	cmp	x10, x1
    6eec:      	b.eq	0x6fb0 <.text+0x268c>
    6ef0:      	ldrsb	w11, [x9, #0x4]
    6ef4:      	and	w10, w11, #0x7f
    6ef8:      	orr	x0, x0, x10, lsl #28
    6efc:      	add	x10, x9, #0x5
    6f00:      	tbz	w11, #0x1f, 0x6e80 <.text+0x255c>
    6f04:      	cmp	x10, x1
    6f08:      	b.eq	0x6fb0 <.text+0x268c>
    6f0c:      	ldrsb	w11, [x9, #0x5]
    6f10:      	and	w10, w11, #0x7f
    6f14:      	orr	x0, x0, x10, lsl #35
    6f18:      	add	x10, x9, #0x6
    6f1c:      	tbz	w11, #0x1f, 0x6e80 <.text+0x255c>
    6f20:      	cmp	x10, x1
    6f24:      	b.eq	0x6fb0 <.text+0x268c>
    6f28:      	ldrsb	w11, [x9, #0x6]
    6f2c:      	and	w10, w11, #0x7f
    6f30:      	orr	x0, x0, x10, lsl #42
    6f34:      	add	x10, x9, #0x7
    6f38:      	tbz	w11, #0x1f, 0x6e80 <.text+0x255c>
    6f3c:      	cmp	x10, x1
    6f40:      	b.eq	0x6fb0 <.text+0x268c>
    6f44:      	ldrsb	w11, [x9, #0x7]
    6f48:      	and	w10, w11, #0x7f
    6f4c:      	orr	x0, x0, x10, lsl #49
    6f50:      	add	x10, x9, #0x8
    6f54:      	tbz	w11, #0x1f, 0x6e80 <.text+0x255c>
    6f58:      	cmp	x10, x1
    6f5c:      	b.eq	0x6fb0 <.text+0x268c>
    6f60:      	ldrsb	w11, [x9, #0x8]
    6f64:      	and	w10, w11, #0x7f
    6f68:      	orr	x0, x0, x10, lsl #56
    6f6c:      	add	x10, x9, #0x9
    6f70:      	tbz	w11, #0x1f, 0x6e80 <.text+0x255c>
    6f74:      	cmp	x10, x1
    6f78:      	b.eq	0x6fb0 <.text+0x268c>
    6f7c:      	ldrb	w11, [x10]
    6f80:      	tst	w11, #0x7e
    6f84:      	b.ne	0x6fe4 <.text+0x26c0>
    6f88:      	add	x10, x9, #0xa
    6f8c:      	tbnz	w11, #0x7, 0x6fa8 <.text+0x2684>
    6f90:      	orr	x0, x0, x11, lsl #63
    6f94:      	str	x10, [x8]
    6f98:      	ldr	x19, [sp, #0x10]
    6f9c:      	ldp	x29, x30, [sp], #0x20
    6fa0:      	autiasp
    6fa4:      	ret
    6fa8:      	cmp	x10, x1
    6fac:      	b.ne	0x6fe4 <.text+0x26c0>
    6fb0:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6fb4:      	nop
    6fb8:      	adr	x1, 0x1af2
    6fbc:      	ldr	x19, [x19, #0x3e0]
    6fc0:      	adrp	x2, 0x1000
    6fc4:      	add	x2, x2, #0xe08
    6fc8:      	adrp	x3, 0x1000
    6fcc:      	add	x3, x3, #0xef4
    6fd0:      	add	x0, x19, #0x130
    6fd4:      	bl	0xd080 <fprintf@plt>
    6fd8:      	add	x0, x19, #0x130
    6fdc:      	bl	0xd090 <fflush@plt>
    6fe0:      	bl	0xd0a0 <abort@plt>
    6fe4:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    6fe8:      	nop
    6fec:      	adr	x1, 0x1af2
    6ff0:      	ldr	x19, [x19, #0x3e0]
    6ff4:      	adrp	x2, 0x1000
    6ff8:      	add	x2, x2, #0xe08
    6ffc:      	adrp	x3, 0x2000
    7000:      	add	x3, x3, #0x71
    7004:      	add	x0, x19, #0x130
    7008:      	bl	0xd080 <fprintf@plt>
    700c:      	add	x0, x19, #0x130
    7010:      	bl	0xd090 <fflush@plt>
    7014:      	bl	0xd0a0 <abort@plt>
    7018:      	paciasp
    701c:      	stp	x29, x30, [sp, #-0x60]!
    7020:      	stp	x28, x27, [sp, #0x10]
    7024:      	stp	x26, x25, [sp, #0x20]
    7028:      	stp	x24, x23, [sp, #0x30]
    702c:      	stp	x22, x21, [sp, #0x40]
    7030:      	stp	x20, x19, [sp, #0x50]
    7034:      	mov	x29, sp
    7038:      	sub	sp, sp, #0x330
    703c:      	mov	x8, x0
    7040:      	stur	x0, [x29, #-0x8]
    7044:      	sub	x0, x29, #0x8
    7048:      	add	x1, x8, #0x14
    704c:      	mov	x21, x3
    7050:      	mov	x19, x2
    7054:      	bl	0x6e50 <.text+0x252c>
    7058:      	ldur	x10, [x29, #-0x8]
    705c:      	str	x21, [sp, #0x10]
    7060:      	add	x20, x10, x0
    7064:      	cmp	x10, x20
    7068:      	b.hs	0x7798 <.text+0x2e74>
    706c:      	add	x8, sp, #0x8
    7070:      	add	x21, x19, #0xf0
    7074:      	add	x22, x19, #0xe8
    7078:      	add	x23, x19, #0x108
    707c:      	add	x24, x19, #0xf8
    7080:      	add	x27, x8, #0x8
    7084:      	add	x25, x19, #0x100
    7088:      	nop
    708c:      	adr	x26, 0x19b8
    7090:      	b	0x70a8 <.text+0x2784>
    7094:      	ldr	x8, [x8]
    7098:      	str	x8, [x27, #0x8]!
    709c:      	ldur	x10, [x29, #-0x8]
    70a0:      	cmp	x10, x20
    70a4:      	b.hs	0x7794 <.text+0x2e70>
    70a8:      	add	x8, x10, #0x1
    70ac:      	stur	x8, [x29, #-0x8]
    70b0:      	ldrb	w9, [x10]
    70b4:      	sub	w11, w9, #0x3
    70b8:      	cmp	w11, #0x91
    70bc:      	b.hi	0x7890 <.text+0x2f6c>
    70c0:      	adr	x12, 0x70d0 <.text+0x27ac>
    70c4:      	ldrh	w13, [x26, x11, lsl #1]
    70c8:      	add	x12, x12, x13, lsl #2
    70cc:      	br	x12
    70d0:      	bti	j
    70d4:      	sub	w8, w9, #0x30
    70d8:      	b	0x7098 <.text+0x2774>
    70dc:      	bti	j
    70e0:      	mov	x12, xzr
    70e4:      	mov	x10, xzr
    70e8:      	sub	w11, w9, #0x70
    70ec:      	mov	x13, x8
    70f0:      	cmp	x13, x20
    70f4:      	b.eq	0x77c0 <.text+0x2e9c>
    70f8:      	ldrb	w14, [x13], #0x1
    70fc:      	add	x8, x8, #0x1
    7100:      	and	x15, x14, #0x7f
    7104:      	lsl	x15, x15, x12
    7108:      	add	x12, x12, #0x7
    710c:      	orr	x10, x15, x10
    7110:      	tbnz	w14, #0x7, 0x70f0 <.text+0x27cc>
    7114:      	sub	w13, w12, #0x7
    7118:      	mov	x15, #-0x1              // =-1
    711c:      	stur	x8, [x29, #-0x8]
    7120:      	cmp	w13, #0x39
    7124:      	mov	w13, #0x3f              // =63
    7128:      	lsl	x12, x15, x12
    712c:      	ccmp	w14, w13, #0x0, lo
    7130:      	csel	x12, x12, xzr, hi
    7134:      	cmp	w9, #0x8d
    7138:      	b.le	0x7194 <.text+0x2870>
    713c:      	cmp	w9, #0x8f
    7140:      	b.gt	0x71bc <.text+0x2898>
    7144:      	cmp	w9, #0x8e
    7148:      	mov	x8, x21
    714c:      	b.eq	0x71e0 <.text+0x28bc>
    7150:      	cmp	w9, #0x8f
    7154:      	mov	x8, x24
    7158:      	b.eq	0x71e0 <.text+0x28bc>
    715c:      	b	0x71d4 <.text+0x28b0>
    7160:      	bti	j
    7164:      	cmp	w9, #0x6f
    7168:      	mov	x8, x24
    716c:      	b.eq	0x7094 <.text+0x2770>
    7170:      	cmp	w9, #0x6e
    7174:      	mov	x8, x21
    7178:      	b.eq	0x7094 <.text+0x2770>
    717c:      	cmp	w9, #0x6d
    7180:      	mov	x8, x22
    7184:      	b.eq	0x7094 <.text+0x2770>
    7188:      	sub	w8, w9, #0x50
    718c:      	add	x8, x19, w8, uxtw #3
    7190:      	b	0x7094 <.text+0x2770>
    7194:      	cmp	w9, #0x6e
    7198:      	mov	x8, x24
    719c:      	b.eq	0x71e0 <.text+0x28bc>
    71a0:      	cmp	w9, #0x6f
    71a4:      	mov	x8, x25
    71a8:      	b.eq	0x71e0 <.text+0x28bc>
    71ac:      	cmp	w9, #0x8d
    71b0:      	mov	x8, x22
    71b4:      	b.eq	0x71e0 <.text+0x28bc>
    71b8:      	b	0x71d4 <.text+0x28b0>
    71bc:      	cmp	w9, #0x90
    71c0:      	mov	x8, x25
    71c4:      	b.eq	0x71e0 <.text+0x28bc>
    71c8:      	cmp	w9, #0x92
    71cc:      	mov	x8, x23
    71d0:      	b.eq	0x71e0 <.text+0x28bc>
    71d4:      	cmp	w11, #0x1c
    71d8:      	b.hi	0x785c <.text+0x2f38>
    71dc:      	add	x8, x19, w11, uxtw #3
    71e0:      	ldr	x8, [x8]
    71e4:      	orr	x9, x10, x12
    71e8:      	add	x8, x8, x9
    71ec:      	b	0x7098 <.text+0x2774>
    71f0:      	bti	j
    71f4:      	ldur	x8, [x10, #0x1]
    71f8:      	add	x9, x10, #0x9
    71fc:      	b	0x7500 <.text+0x2bdc>
    7200:      	bti	j
    7204:      	sub	x0, x29, #0x8
    7208:      	mov	x1, x20
    720c:      	bl	0x6e50 <.text+0x252c>
    7210:      	ldur	x10, [x29, #-0x8]
    7214:      	mov	x9, xzr
    7218:      	mov	x8, xzr
    721c:      	mov	x11, x10
    7220:      	cmp	x11, x20
    7224:      	b.eq	0x77f4 <.text+0x2ed0>
    7228:      	ldrb	w12, [x11], #0x1
    722c:      	add	x10, x10, #0x1
    7230:      	and	x13, x12, #0x7f
    7234:      	lsl	x13, x13, x9
    7238:      	add	x9, x9, #0x7
    723c:      	orr	x8, x13, x8
    7240:      	tbnz	w12, #0x7, 0x7220 <.text+0x28fc>
    7244:      	sub	w11, w9, #0x7
    7248:      	mov	x13, #-0x1              // =-1
    724c:      	stur	x10, [x29, #-0x8]
    7250:      	cmp	w11, #0x39
    7254:      	mov	w11, #0x3f              // =63
    7258:      	lsl	x9, x13, x9
    725c:      	ccmp	w12, w11, #0x0, lo
    7260:      	csel	x9, x9, xzr, hi
    7264:      	cmp	w0, #0x1d
    7268:      	b.le	0x76f8 <.text+0x2dd4>
    726c:      	cmp	w0, #0x1f
    7270:      	b.gt	0x7748 <.text+0x2e24>
    7274:      	cmp	w0, #0x1e
    7278:      	mov	x10, x21
    727c:      	b.eq	0x776c <.text+0x2e48>
    7280:      	cmp	w0, #0x1f
    7284:      	mov	x10, x24
    7288:      	b.eq	0x776c <.text+0x2e48>
    728c:      	b	0x7760 <.text+0x2e3c>
    7290:      	bti	j
    7294:      	mov	x8, x27
    7298:      	ldr	x9, [x27]
    729c:      	ldr	x10, [x8, #-0x8]!
    72a0:      	cmp	x10, x9
    72a4:      	cset	w9, lo
    72a8:      	b	0x765c <.text+0x2d38>
    72ac:      	bti	j
    72b0:      	mov	x8, x27
    72b4:      	ldr	x9, [x27]
    72b8:      	ldr	x10, [x8, #-0x8]!
    72bc:      	cmp	x10, x9
    72c0:      	cset	w9, ls
    72c4:      	b	0x765c <.text+0x2d38>
    72c8:      	bti	j
    72cc:      	mov	x8, x27
    72d0:      	ldr	x9, [x27]
    72d4:      	ldr	x10, [x8, #-0x8]!
    72d8:      	sdiv	x11, x10, x9
    72dc:      	msub	x9, x11, x9, x10
    72e0:      	b	0x765c <.text+0x2d38>
    72e4:      	bti	j
    72e8:      	mov	x8, x27
    72ec:      	ldr	x9, [x27]
    72f0:      	ldr	x10, [x8, #-0x8]!
    72f4:      	cmp	x10, x9
    72f8:      	cset	w9, eq
    72fc:      	b	0x765c <.text+0x2d38>
    7300:      	bti	j
    7304:      	ldursh	x8, [x10, #0x1]
    7308:      	add	x9, x10, #0x3
    730c:      	b	0x7500 <.text+0x2bdc>
    7310:      	bti	j
    7314:      	ldr	x11, [x27], #-0x8
    7318:      	ldursh	x8, [x10, #0x1]
    731c:      	add	x9, x10, #0x3
    7320:      	stur	x9, [x29, #-0x8]
    7324:      	cbz	x11, 0x709c <.text+0x2778>
    7328:      	add	x8, x9, x8
    732c:      	stur	x8, [x29, #-0x8]
    7330:      	b	0x709c <.text+0x2778>
    7334:      	bti	j
    7338:      	mov	x8, x27
    733c:      	ldr	x9, [x27]
    7340:      	ldr	x10, [x8, #-0x8]!
    7344:      	cmp	x10, x9
    7348:      	cset	w9, hs
    734c:      	b	0x765c <.text+0x2d38>
    7350:      	bti	j
    7354:      	mov	x10, xzr
    7358:      	mov	x9, xzr
    735c:      	mov	x11, x8
    7360:      	cmp	x11, x20
    7364:      	b.eq	0x7828 <.text+0x2f04>
    7368:      	ldrb	w12, [x11], #0x1
    736c:      	add	x8, x8, #0x1
    7370:      	and	x13, x12, #0x7f
    7374:      	lsl	x13, x13, x10
    7378:      	add	x10, x10, #0x7
    737c:      	orr	x9, x13, x9
    7380:      	tbnz	w12, #0x7, 0x7360 <.text+0x2a3c>
    7384:      	sub	w11, w10, #0x7
    7388:      	mov	x13, #-0x1              // =-1
    738c:      	stur	x8, [x29, #-0x8]
    7390:      	cmp	w11, #0x39
    7394:      	mov	w11, #0x3f              // =63
    7398:      	lsl	x10, x13, x10
    739c:      	ccmp	w12, w11, #0x0, lo
    73a0:      	csel	x10, x10, xzr, hi
    73a4:      	orr	x9, x9, x10
    73a8:      	str	x9, [x27, #0x8]!
    73ac:      	b	0x709c <.text+0x2778>
    73b0:      	bti	j
    73b4:      	mov	x8, x27
    73b8:      	ldr	x9, [x27]
    73bc:      	ldr	x10, [x8, #-0x8]!
    73c0:      	and	x9, x10, x9
    73c4:      	b	0x765c <.text+0x2d38>
    73c8:      	bti	j
    73cc:      	mov	x8, x27
    73d0:      	ldr	x9, [x27]
    73d4:      	ldr	x10, [x8, #-0x8]!
    73d8:      	cmp	x10, x9
    73dc:      	cset	w9, hi
    73e0:      	b	0x765c <.text+0x2d38>
    73e4:      	bti	j
    73e8:      	ldursw	x8, [x10, #0x1]
    73ec:      	add	x9, x10, #0x5
    73f0:      	b	0x7500 <.text+0x2bdc>
    73f4:      	bti	j
    73f8:      	mov	x8, x27
    73fc:      	ldr	x9, [x27]
    7400:      	ldr	x10, [x8, #-0x8]!
    7404:      	eor	x9, x10, x9
    7408:      	b	0x765c <.text+0x2d38>
    740c:      	bti	j
    7410:      	ldr	x8, [x27]
    7414:      	tbz	x8, #0x3f, 0x709c <.text+0x2778>
    7418:      	b	0x7638 <.text+0x2d14>
    741c:      	bti	j
    7420:      	ldrsb	x8, [x10, #0x1]
    7424:      	b	0x7464 <.text+0x2b40>
    7428:      	bti	j
    742c:      	ldr	x8, [x27]
    7430:      	b	0x7098 <.text+0x2774>
    7434:      	bti	j
    7438:      	sub	x0, x29, #0x8
    743c:      	mov	x1, x20
    7440:      	bl	0x6e50 <.text+0x252c>
    7444:      	str	x0, [x27, #0x8]!
    7448:      	b	0x709c <.text+0x2778>
    744c:      	bti	j
    7450:      	ldur	w8, [x10, #0x1]
    7454:      	add	x9, x10, #0x5
    7458:      	b	0x7500 <.text+0x2bdc>
    745c:      	bti	j
    7460:      	ldrb	w8, [x10, #0x1]
    7464:      	add	x9, x10, #0x2
    7468:      	b	0x7500 <.text+0x2bdc>
    746c:      	bti	j
    7470:      	sub	x27, x27, #0x8
    7474:      	b	0x709c <.text+0x2778>
    7478:      	bti	j
    747c:      	ldurh	w8, [x10, #0x1]
    7480:      	add	x9, x10, #0x3
    7484:      	b	0x7500 <.text+0x2bdc>
    7488:      	bti	j
    748c:      	ldr	x8, [x27]
    7490:      	ldr	x8, [x8]
    7494:      	str	x8, [x27]
    7498:      	b	0x709c <.text+0x2778>
    749c:      	bti	j
    74a0:      	ldur	q0, [x27, #-0x10]
    74a4:      	ldr	x8, [x27]
    74a8:      	stur	q0, [x27, #-0x8]
    74ac:      	stur	x8, [x27, #-0x10]
    74b0:      	b	0x709c <.text+0x2778>
    74b4:      	bti	j
    74b8:      	mov	x8, x27
    74bc:      	ldr	x9, [x27]
    74c0:      	ldr	x10, [x8, #-0x8]!
    74c4:      	sdiv	x9, x10, x9
    74c8:      	b	0x765c <.text+0x2d38>
    74cc:      	bti	j
    74d0:      	ldur	x8, [x27, #-0x8]
    74d4:      	b	0x7098 <.text+0x2774>
    74d8:      	bti	j
    74dc:      	ldur	q0, [x27, #-0x8]
    74e0:      	ext	v0.16b, v0.16b, v0.16b, #0x8
    74e4:      	stur	q0, [x27, #-0x8]
    74e8:      	b	0x709c <.text+0x2778>
    74ec:      	bti	j
    74f0:      	ldrb	w8, [x10, #0x1]
    74f4:      	add	x9, x10, #0x2
    74f8:      	sub	x8, x27, x8, lsl #3
    74fc:      	ldr	x8, [x8]
    7500:      	stur	x9, [x29, #-0x8]
    7504:      	b	0x7098 <.text+0x2774>
    7508:      	bti	j
    750c:      	ldr	x8, [x27]
    7510:      	mvn	x8, x8
    7514:      	str	x8, [x27]
    7518:      	b	0x709c <.text+0x2778>
    751c:      	bti	j
    7520:      	mov	x8, x27
    7524:      	ldr	x9, [x27]
    7528:      	ldr	x10, [x8, #-0x8]!
    752c:      	lsl	x9, x10, x9
    7530:      	b	0x765c <.text+0x2d38>
    7534:      	bti	j
    7538:      	mov	x8, x27
    753c:      	ldr	x9, [x27]
    7540:      	ldr	x10, [x8, #-0x8]!
    7544:      	lsr	x9, x10, x9
    7548:      	b	0x765c <.text+0x2d38>
    754c:      	bti	j
    7550:      	mov	x8, x27
    7554:      	ldr	x9, [x27]
    7558:      	ldr	x10, [x8, #-0x8]!
    755c:      	add	x9, x10, x9
    7560:      	b	0x765c <.text+0x2d38>
    7564:      	bti	j
    7568:      	add	x8, x10, #0x2
    756c:      	stur	x8, [x29, #-0x8]
    7570:      	ldr	x8, [x27]
    7574:      	ldrb	w9, [x10, #0x1]
    7578:      	cmp	w9, #0x3
    757c:      	b.gt	0x76bc <.text+0x2d98>
    7580:      	cmp	w9, #0x1
    7584:      	b.eq	0x777c <.text+0x2e58>
    7588:      	cmp	w9, #0x2
    758c:      	b.ne	0x7938 <.text+0x3014>
    7590:      	ldrh	w8, [x8]
    7594:      	str	x8, [x27]
    7598:      	b	0x709c <.text+0x2778>
    759c:      	bti	j
    75a0:      	sub	x0, x29, #0x8
    75a4:      	mov	x1, x20
    75a8:      	bl	0x6e50 <.text+0x252c>
    75ac:      	ldr	x8, [x27]
    75b0:      	add	x8, x8, x0
    75b4:      	str	x8, [x27]
    75b8:      	b	0x709c <.text+0x2778>
    75bc:      	bti	j
    75c0:      	mov	x8, x27
    75c4:      	ldr	x9, [x27]
    75c8:      	ldr	x10, [x8, #-0x8]!
    75cc:      	asr	x9, x10, x9
    75d0:      	b	0x765c <.text+0x2d38>
    75d4:      	bti	j
    75d8:      	ldr	x8, [x27]
    75dc:      	ldr	x8, [x8]
    75e0:      	str	x8, [x27, #-0x8]!
    75e4:      	b	0x709c <.text+0x2778>
    75e8:      	bti	j
    75ec:      	mov	x8, x27
    75f0:      	ldr	x9, [x27]
    75f4:      	ldr	x10, [x8, #-0x8]!
    75f8:      	mul	x9, x10, x9
    75fc:      	b	0x765c <.text+0x2d38>
    7600:      	bti	j
    7604:      	mov	x8, x27
    7608:      	ldr	x9, [x27]
    760c:      	ldr	x10, [x8, #-0x8]!
    7610:      	sub	x9, x10, x9
    7614:      	b	0x765c <.text+0x2d38>
    7618:      	bti	j
    761c:      	mov	x8, x27
    7620:      	ldr	x9, [x27]
    7624:      	ldr	x10, [x8, #-0x8]!
    7628:      	orr	x9, x10, x9
    762c:      	b	0x765c <.text+0x2d38>
    7630:      	bti	j
    7634:      	ldr	x8, [x27]
    7638:      	neg	x8, x8
    763c:      	str	x8, [x27]
    7640:      	b	0x709c <.text+0x2778>
    7644:      	bti	j
    7648:      	mov	x8, x27
    764c:      	ldr	x9, [x27]
    7650:      	ldr	x10, [x8, #-0x8]!
    7654:      	cmp	x10, x9
    7658:      	cset	w9, ne
    765c:      	str	x9, [x8]
    7660:      	mov	x27, x8
    7664:      	b	0x709c <.text+0x2778>
    7668:      	bti	j
    766c:      	ldursh	x8, [x10, #0x1]
    7670:      	add	x8, x10, x8
    7674:      	add	x8, x8, #0x3
    7678:      	stur	x8, [x29, #-0x8]
    767c:      	b	0x709c <.text+0x2778>
    7680:      	bti	j
    7684:      	sub	x0, x29, #0x8
    7688:      	mov	x1, x20
    768c:      	bl	0x6e50 <.text+0x252c>
    7690:      	cmp	w0, #0x1d
    7694:      	b.le	0x76d0 <.text+0x2dac>
    7698:      	cmp	w0, #0x1f
    769c:      	b.gt	0x7720 <.text+0x2dfc>
    76a0:      	cmp	w0, #0x1e
    76a4:      	mov	x8, x21
    76a8:      	b.eq	0x7094 <.text+0x2770>
    76ac:      	cmp	w0, #0x1f
    76b0:      	mov	x8, x24
    76b4:      	b.eq	0x7094 <.text+0x2770>
    76b8:      	b	0x7738 <.text+0x2e14>
    76bc:      	cmp	w9, #0x4
    76c0:      	b.eq	0x7788 <.text+0x2e64>
    76c4:      	cmp	w9, #0x8
    76c8:      	b.eq	0x7490 <.text+0x2b6c>
    76cc:      	b	0x7938 <.text+0x3014>
    76d0:      	cmn	w0, #0x2
    76d4:      	mov	x8, x24
    76d8:      	b.eq	0x7094 <.text+0x2770>
    76dc:      	cmn	w0, #0x1
    76e0:      	mov	x8, x25
    76e4:      	b.eq	0x7094 <.text+0x2770>
    76e8:      	cmp	w0, #0x1d
    76ec:      	mov	x8, x22
    76f0:      	b.eq	0x7094 <.text+0x2770>
    76f4:      	b	0x7738 <.text+0x2e14>
    76f8:      	cmn	w0, #0x2
    76fc:      	mov	x10, x24
    7700:      	b.eq	0x776c <.text+0x2e48>
    7704:      	cmn	w0, #0x1
    7708:      	mov	x10, x25
    770c:      	b.eq	0x776c <.text+0x2e48>
    7710:      	cmp	w0, #0x1d
    7714:      	mov	x10, x22
    7718:      	b.eq	0x776c <.text+0x2e48>
    771c:      	b	0x7760 <.text+0x2e3c>
    7720:      	cmp	w0, #0x20
    7724:      	mov	x8, x25
    7728:      	b.eq	0x7094 <.text+0x2770>
    772c:      	cmp	w0, #0x22
    7730:      	mov	x8, x23
    7734:      	b.eq	0x7094 <.text+0x2770>
    7738:      	cmp	w0, #0x1c
    773c:      	b.hi	0x79a0 <.text+0x307c>
    7740:      	add	x8, x19, w0, uxtw #3
    7744:      	b	0x7094 <.text+0x2770>
    7748:      	cmp	w0, #0x20
    774c:      	mov	x10, x25
    7750:      	b.eq	0x776c <.text+0x2e48>
    7754:      	cmp	w0, #0x22
    7758:      	mov	x10, x23
    775c:      	b.eq	0x776c <.text+0x2e48>
    7760:      	cmp	w0, #0x1c
    7764:      	b.hi	0x796c <.text+0x3048>
    7768:      	add	x10, x19, w0, uxtw #3
    776c:      	ldr	x10, [x10]
    7770:      	orr	x8, x8, x9
    7774:      	add	x8, x10, x8
    7778:      	b	0x7098 <.text+0x2774>
    777c:      	ldrb	w8, [x8]
    7780:      	str	x8, [x27]
    7784:      	b	0x709c <.text+0x2778>
    7788:      	ldr	w8, [x8]
    778c:      	str	x8, [x27]
    7790:      	b	0x709c <.text+0x2778>
    7794:      	ldr	x21, [x27]
    7798:      	mov	x0, x21
    779c:      	add	sp, sp, #0x330
    77a0:      	ldp	x20, x19, [sp, #0x50]
    77a4:      	ldp	x22, x21, [sp, #0x40]
    77a8:      	ldp	x24, x23, [sp, #0x30]
    77ac:      	ldp	x26, x25, [sp, #0x20]
    77b0:      	ldp	x28, x27, [sp, #0x10]
    77b4:      	ldp	x29, x30, [sp], #0x60
    77b8:      	autiasp
    77bc:      	ret
    77c0:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    77c4:      	nop
    77c8:      	adr	x1, 0x1af2
    77cc:      	ldr	x19, [x19, #0x3e0]
    77d0:      	adrp	x2, 0x2000
    77d4:      	add	x2, x2, #0x398
    77d8:      	adrp	x3, 0x1000
    77dc:      	add	x3, x3, #0xfd2
    77e0:      	add	x0, x19, #0x130
    77e4:      	bl	0xd080 <fprintf@plt>
    77e8:      	add	x0, x19, #0x130
    77ec:      	bl	0xd090 <fflush@plt>
    77f0:      	bl	0xd0a0 <abort@plt>
    77f4:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    77f8:      	nop
    77fc:      	adr	x1, 0x1af2
    7800:      	ldr	x19, [x19, #0x3e0]
    7804:      	adrp	x2, 0x2000
    7808:      	add	x2, x2, #0x398
    780c:      	adrp	x3, 0x1000
    7810:      	add	x3, x3, #0xfd2
    7814:      	add	x0, x19, #0x130
    7818:      	bl	0xd080 <fprintf@plt>
    781c:      	add	x0, x19, #0x130
    7820:      	bl	0xd090 <fflush@plt>
    7824:      	bl	0xd0a0 <abort@plt>
    7828:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    782c:      	nop
    7830:      	adr	x1, 0x1af2
    7834:      	ldr	x19, [x19, #0x3e0]
    7838:      	adrp	x2, 0x2000
    783c:      	add	x2, x2, #0x398
    7840:      	adrp	x3, 0x1000
    7844:      	add	x3, x3, #0xfd2
    7848:      	add	x0, x19, #0x130
    784c:      	bl	0xd080 <fprintf@plt>
    7850:      	add	x0, x19, #0x130
    7854:      	bl	0xd090 <fflush@plt>
    7858:      	bl	0xd0a0 <abort@plt>
    785c:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    7860:      	nop
    7864:      	adr	x1, 0x1af2
    7868:      	ldr	x19, [x19, #0x3e0]
    786c:      	adrp	x2, 0x2000
    7870:      	add	x2, x2, #0x1b6
    7874:      	adrp	x3, 0x1000
    7878:      	add	x3, x3, #0xf64
    787c:      	add	x0, x19, #0x130
    7880:      	bl	0xd080 <fprintf@plt>
    7884:      	add	x0, x19, #0x130
    7888:      	bl	0xd090 <fflush@plt>
    788c:      	bl	0xd0a0 <abort@plt>
    7890:      	bti	j
    7894:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    7898:      	nop
    789c:      	adr	x1, 0x1af2
    78a0:      	ldr	x19, [x19, #0x3e0]
    78a4:      	adrp	x2, 0x2000
    78a8:      	add	x2, x2, #0x37
    78ac:      	adrp	x3, 0x2000
    78b0:      	add	x3, x3, #0x62a
    78b4:      	add	x0, x19, #0x130
    78b8:      	bl	0xd080 <fprintf@plt>
    78bc:      	add	x0, x19, #0x130
    78c0:      	bl	0xd090 <fflush@plt>
    78c4:      	bl	0xd0a0 <abort@plt>
    78c8:      	bti	j
    78cc:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    78d0:      	nop
    78d4:      	adr	x1, 0x1af2
    78d8:      	ldr	x19, [x19, #0x3e0]
    78dc:      	adrp	x2, 0x2000
    78e0:      	add	x2, x2, #0x37
    78e4:      	adrp	x3, 0x1000
    78e8:      	add	x3, x3, #0xfef
    78ec:      	add	x0, x19, #0x130
    78f0:      	bl	0xd080 <fprintf@plt>
    78f4:      	add	x0, x19, #0x130
    78f8:      	bl	0xd090 <fflush@plt>
    78fc:      	bl	0xd0a0 <abort@plt>
    7900:      	bti	j
    7904:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    7908:      	nop
    790c:      	adr	x1, 0x1af2
    7910:      	ldr	x19, [x19, #0x3e0]
    7914:      	adrp	x2, 0x2000
    7918:      	add	x2, x2, #0x37
    791c:      	adrp	x3, 0x2000
    7920:      	add	x3, x3, #0xe29
    7924:      	add	x0, x19, #0x130
    7928:      	bl	0xd080 <fprintf@plt>
    792c:      	add	x0, x19, #0x130
    7930:      	bl	0xd090 <fflush@plt>
    7934:      	bl	0xd0a0 <abort@plt>
    7938:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    793c:      	nop
    7940:      	adr	x1, 0x1af2
    7944:      	ldr	x19, [x19, #0x3e0]
    7948:      	adrp	x2, 0x2000
    794c:      	add	x2, x2, #0x37
    7950:      	adrp	x3, 0x2000
    7954:      	add	x3, x3, #0x3a3
    7958:      	add	x0, x19, #0x130
    795c:      	bl	0xd080 <fprintf@plt>
    7960:      	add	x0, x19, #0x130
    7964:      	bl	0xd090 <fflush@plt>
    7968:      	bl	0xd0a0 <abort@plt>
    796c:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    7970:      	nop
    7974:      	adr	x1, 0x1af2
    7978:      	ldr	x19, [x19, #0x3e0]
    797c:      	adrp	x2, 0x2000
    7980:      	add	x2, x2, #0x1b6
    7984:      	adrp	x3, 0x1000
    7988:      	add	x3, x3, #0xf64
    798c:      	add	x0, x19, #0x130
    7990:      	bl	0xd080 <fprintf@plt>
    7994:      	add	x0, x19, #0x130
    7998:      	bl	0xd090 <fflush@plt>
    799c:      	bl	0xd0a0 <abort@plt>
    79a0:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    79a4:      	nop
    79a8:      	adr	x1, 0x1af2
    79ac:      	ldr	x19, [x19, #0x3e0]
    79b0:      	adrp	x2, 0x2000
    79b4:      	add	x2, x2, #0x1b6
    79b8:      	adrp	x3, 0x1000
    79bc:      	add	x3, x3, #0xf64
    79c0:      	add	x0, x19, #0x130
    79c4:      	bl	0xd080 <fprintf@plt>
    79c8:      	add	x0, x19, #0x130
    79cc:      	bl	0xd090 <fflush@plt>
    79d0:      	bl	0xd0a0 <abort@plt>
    79d4:      	paciasp
    79d8:      	stp	x29, x30, [sp, #-0x60]!
    79dc:      	stp	x28, x27, [sp, #0x10]
    79e0:      	stp	x26, x25, [sp, #0x20]
    79e4:      	stp	x24, x23, [sp, #0x30]
    79e8:      	stp	x22, x21, [sp, #0x40]
    79ec:      	stp	x20, x19, [sp, #0x50]
    79f0:      	mov	x29, sp
    79f4:      	sub	sp, sp, #0x6a0
    79f8:      	mov	w21, w3
    79fc:      	mov	x19, x2
    7a00:      	mov	x22, x1
    7a04:      	mov	x20, x0
    7a08:      	cbz	w3, 0x7a2c <.text+0x3108>
    7a0c:      	ldp	x2, x3, [x19, #0x10]
    7a10:      	add	x5, sp, #0x50
    7a14:      	ldr	x0, [x20, #0x8]
    7a18:      	add	x6, sp, #0x18
    7a1c:      	mov	x1, x22
    7a20:      	add	x4, x2, w21, uxtw
    7a24:      	bl	0x7efc <.text+0x35d8>
    7a28:      	tbnz	w0, #0x0, 0x7b44 <.text+0x3220>
    7a2c:      	ldr	x2, [x19, #0x20]
    7a30:      	cbz	x2, 0x7a50 <.text+0x312c>
    7a34:      	ldr	x0, [x20, #0x8]
    7a38:      	ldr	w3, [x19, #0x28]
    7a3c:      	add	x4, sp, #0x50
    7a40:      	add	x5, sp, #0x18
    7a44:      	mov	x1, x22
    7a48:      	bl	0x80c4 <.text+0x37a0>
    7a4c:      	tbnz	w0, #0x0, 0x7b44 <.text+0x3220>
    7a50:      	ldr	x23, [x19]
    7a54:      	nop
    7a58:      	adr	x0, 0x15804
    7a5c:      	bl	0xd0f0 <pthread_rwlock_rdlock@plt>
    7a60:      	adrp	x8, 0x15000
    7a64:      	adrp	x9, 0x15000
    7a68:      	ldr	x8, [x8, #0x5e8]
    7a6c:      	ldr	x9, [x9, #0x5f0]
    7a70:      	cmp	x8, x9
    7a74:      	b.hs	0x7b18 <.text+0x31f4>
    7a78:      	cmn	x23, #0x1
    7a7c:      	b.ne	0x7a90 <.text+0x316c>
    7a80:      	b	0x7ac4 <.text+0x31a0>
    7a84:      	add	x8, x8, #0x20
    7a88:      	cmp	x8, x9
    7a8c:      	b.hs	0x7b18 <.text+0x31f4>
    7a90:      	ldr	x10, [x8]
    7a94:      	cmp	x10, x23
    7a98:      	b.ne	0x7a84 <.text+0x3160>
    7a9c:      	ldr	x10, [x8, #0x8]
    7aa0:      	cmp	x10, x22
    7aa4:      	b.hi	0x7a84 <.text+0x3160>
    7aa8:      	ldr	x10, [x8, #0x10]
    7aac:      	cmp	x10, x22
    7ab0:      	b.ls	0x7a84 <.text+0x3160>
    7ab4:      	b	0x7adc <.text+0x31b8>
    7ab8:      	add	x8, x8, #0x20
    7abc:      	cmp	x8, x9
    7ac0:      	b.hs	0x7b18 <.text+0x31f4>
    7ac4:      	ldr	x10, [x8, #0x8]
    7ac8:      	cmp	x10, x22
    7acc:      	b.hi	0x7ab8 <.text+0x3194>
    7ad0:      	ldr	x10, [x8, #0x10]
    7ad4:      	cmp	x10, x22
    7ad8:      	b.ls	0x7ab8 <.text+0x3194>
    7adc:      	ldr	x23, [x8, #0x18]
    7ae0:      	nop
    7ae4:      	adr	x0, 0x15804
    7ae8:      	bl	0xd0d0 <pthread_rwlock_unlock@plt>
    7aec:      	cbz	x23, 0x7b24 <.text+0x3200>
    7af0:      	ldp	x2, x3, [x19, #0x10]
    7af4:      	add	x5, sp, #0x50
    7af8:      	ldr	x0, [x20, #0x8]
    7afc:      	add	x6, sp, #0x18
    7b00:      	mov	x1, x22
    7b04:      	mov	x4, x23
    7b08:      	bl	0x7efc <.text+0x35d8>
    7b0c:      	tbz	w0, #0x0, 0x7b24 <.text+0x3200>
    7b10:      	mov	w24, wzr
    7b14:      	b	0x7b48 <.text+0x3224>
    7b18:      	nop
    7b1c:      	adr	x0, 0x15804
    7b20:      	bl	0xd0d0 <pthread_rwlock_unlock@plt>
    7b24:      	ldp	x2, x3, [x19, #0x10]
    7b28:      	add	x5, sp, #0x50
    7b2c:      	ldr	x0, [x20, #0x8]
    7b30:      	add	x6, sp, #0x18
    7b34:      	mov	x1, x22
    7b38:      	mov	x4, xzr
    7b3c:      	bl	0x7efc <.text+0x35d8>
    7b40:      	tbz	w0, #0x0, 0x7c80 <.text+0x335c>
    7b44:      	mov	w24, #0x1               // =1
    7b48:      	ldr	x25, [x19]
    7b4c:      	add	x0, sp, #0x80
    7b50:      	mov	w1, wzr
    7b54:      	mov	w2, #0x618              // =1560
    7b58:      	bl	0xd0e0 <memset@plt>
    7b5c:      	ldr	x0, [x20, #0x8]
    7b60:      	add	x1, sp, #0x50
    7b64:      	add	x2, sp, #0x18
    7b68:      	add	x5, sp, #0x80
    7b6c:      	mov	x3, x22
    7b70:      	mov	w4, #0x4                // =4
    7b74:      	bl	0x5b38 <.text+0x1214>
    7b78:      	tbz	w0, #0x0, 0x7c80 <.text+0x335c>
    7b7c:      	ldr	q0, [sp, #0x70]
    7b80:      	add	x8, x20, #0x220
    7b84:      	ldr	x9, [sp, #0x38]
    7b88:      	ldr	x22, [sp, #0x68]
    7b8c:      	cmp	w21, #0x0
    7b90:      	mov	w0, #0x1                // =1
    7b94:      	stur	q0, [x8, #0x8]
    7b98:      	ldr	w8, [sp, #0x90]
    7b9c:      	str	x9, [x20, #0x238]
    7ba0:      	eor	w9, w24, #0x1
    7ba4:      	str	x8, [x20, #0x240]
    7ba8:      	mov	w8, #0x3000000          // =50331648
    7bac:      	str	w8, [x20, #0x250]
    7bb0:      	ldp	x23, x8, [sp, #0x50]
    7bb4:      	str	x22, [x20, #0x220]
    7bb8:      	str	xzr, [x20, #0x248]
    7bbc:      	str	w8, [x20, #0x254]
    7bc0:      	csinc	w8, w9, wzr, eq
    7bc4:      	str	x23, [x20, #0x258]
    7bc8:      	str	x25, [x20, #0x260]
    7bcc:      	tbnz	w8, #0x0, 0x7c84 <.text+0x3360>
    7bd0:      	ldr	x8, [x19, #0x20]
    7bd4:      	cbnz	x8, 0x7c84 <.text+0x3360>
    7bd8:      	ldr	x24, [x19]
    7bdc:      	nop
    7be0:      	adr	x0, 0x15804
    7be4:      	str	q0, [sp]
    7be8:      	bl	0xd0c0 <pthread_rwlock_wrlock@plt>
    7bec:      	adrp	x25, 0x15000
    7bf0:      	adrp	x26, 0x15000
    7bf4:      	ldr	x8, [x25, #0x5f0]
    7bf8:      	ldr	x9, [x26, #0x5f8]
    7bfc:      	cmp	x8, x9
    7c00:      	b.lo	0x7c54 <.text+0x3330>
    7c04:      	adrp	x27, 0x15000
    7c08:      	ldr	x21, [x27, #0x5e8]
    7c0c:      	sub	x19, x9, x21
    7c10:      	lsl	x0, x19, #2
    7c14:      	asr	x28, x19, #3
    7c18:      	bl	0xcf30 <malloc@plt>
    7c1c:      	mov	x1, x21
    7c20:      	mov	x2, x19
    7c24:      	mov	x20, x0
    7c28:      	bl	0xd0b0 <memcpy@plt>
    7c2c:      	nop
    7c30:      	adr	x8, 0x15840
    7c34:      	cmp	x21, x8
    7c38:      	b.eq	0x7c44 <.text+0x3320>
    7c3c:      	mov	x0, x21
    7c40:      	bl	0xcdc0 <free@plt>
    7c44:      	add	x9, x20, x28, lsl #5
    7c48:      	add	x8, x20, x19
    7c4c:      	str	x20, [x27, #0x5e8]
    7c50:      	str	x9, [x26, #0x5f8]
    7c54:      	ldr	q0, [sp]
    7c58:      	stp	x24, x22, [x8]
    7c5c:      	nop
    7c60:      	adr	x0, 0x15804
    7c64:      	str	x23, [x8, #0x18]
    7c68:      	str	d0, [x8, #0x10]
    7c6c:      	add	x8, x8, #0x20
    7c70:      	str	x8, [x25, #0x5f0]
    7c74:      	bl	0xd0d0 <pthread_rwlock_unlock@plt>
    7c78:      	mov	w0, #0x1                // =1
    7c7c:      	b	0x7c84 <.text+0x3360>
    7c80:      	mov	w0, wzr
    7c84:      	add	sp, sp, #0x6a0
    7c88:      	ldp	x20, x19, [sp, #0x50]
    7c8c:      	ldp	x22, x21, [sp, #0x40]
    7c90:      	ldp	x24, x23, [sp, #0x30]
    7c94:      	ldp	x26, x25, [sp, #0x20]
    7c98:      	ldp	x28, x27, [sp, #0x10]
    7c9c:      	ldp	x29, x30, [sp], #0x60
    7ca0:      	autiasp
    7ca4:      	ret
    7ca8:      	paciasp
    7cac:      	sub	sp, sp, #0x70
    7cb0:      	stp	x29, x30, [sp, #0x20]
    7cb4:      	str	x25, [sp, #0x30]
    7cb8:      	stp	x24, x23, [sp, #0x40]
    7cbc:      	stp	x22, x21, [sp, #0x50]
    7cc0:      	stp	x20, x19, [sp, #0x60]
    7cc4:      	add	x29, sp, #0x20
    7cc8:      	ldrh	w21, [x0, #0x18]
    7ccc:      	cbz	x21, 0x7ce8 <.text+0x33c4>
    7cd0:      	ldr	x8, [x2, #0x10]
    7cd4:      	ldr	x22, [x0]
    7cd8:      	mov	x20, x0
    7cdc:      	mov	x19, x2
    7ce0:      	cmp	x8, x22
    7ce4:      	b.hs	0x7d0c <.text+0x33e8>
    7ce8:      	mov	w0, wzr
    7cec:      	ldp	x20, x19, [sp, #0x60]
    7cf0:      	ldr	x25, [sp, #0x30]
    7cf4:      	ldp	x22, x21, [sp, #0x50]
    7cf8:      	ldp	x24, x23, [sp, #0x40]
    7cfc:      	ldp	x29, x30, [sp, #0x20]
    7d00:      	add	sp, sp, #0x70
    7d04:      	autiasp
    7d08:      	ret
    7d0c:      	ldr	x11, [x20, #0x10]
    7d10:      	mov	x9, x21
    7d14:      	mov	x10, x11
    7d18:      	b	0x7d28 <.text+0x3404>
    7d1c:      	subs	x9, x9, #0x1
    7d20:      	mov	x11, x10
    7d24:      	b.eq	0x7ce8 <.text+0x33c4>
    7d28:      	ldr	w12, [x10], #0x38
    7d2c:      	cmp	w12, #0x1
    7d30:      	b.ne	0x7d1c <.text+0x33f8>
    7d34:      	ldr	x12, [x11, #0x10]
    7d38:      	add	x12, x12, x22
    7d3c:      	cmp	x8, x12
    7d40:      	b.lo	0x7d1c <.text+0x33f8>
    7d44:      	ldr	x11, [x11, #0x28]
    7d48:      	add	x13, x11, x12
    7d4c:      	cmp	x8, x13
    7d50:      	b.hs	0x7d1c <.text+0x33f8>
    7d54:      	ldr	x8, [x19, #0x8]
    7d58:      	mov	w9, #-0x1               // =-1
    7d5c:      	mov	w25, #0xe550            // =58704
    7d60:      	add	x23, x21, x9
    7d64:      	mov	w24, #0x38              // =56
    7d68:      	movk	w25, #0x6474, lsl #16
    7d6c:      	stp	x12, x11, [x8]
    7d70:      	b	0x7d84 <.text+0x3460>
    7d74:      	sub	w21, w21, #0x1
    7d78:      	sub	x23, x23, #0x1
    7d7c:      	and	w8, w21, #0xffff
    7d80:      	cbz	w8, 0x7ce8 <.text+0x33c4>
    7d84:      	and	x8, x23, #0xffffffff
    7d88:      	ldr	x9, [x20, #0x10]
    7d8c:      	umull	x10, w8, w24
    7d90:      	ldr	w10, [x9, x10]
    7d94:      	cmp	w10, w25
    7d98:      	b.ne	0x7d74 <.text+0x3450>
    7d9c:      	umaddl	x8, w8, w24, x9
    7da0:      	ldp	x0, x10, [x19]
    7da4:      	mov	x3, sp
    7da8:      	ldr	x9, [x8, #0x10]
    7dac:      	ldr	x8, [x8, #0x28]
    7db0:      	add	x1, x9, x22
    7db4:      	add	x2, x8, x1
    7db8:      	stp	x1, x8, [x10, #0x20]
    7dbc:      	bl	0x7ddc <.text+0x34b8>
    7dc0:      	tbz	w0, #0x0, 0x7d74 <.text+0x3450>
    7dc4:      	ldr	x8, [sp]
    7dc8:      	ldr	x9, [x19, #0x8]
    7dcc:      	mov	x10, #-0x1              // =-1
    7dd0:      	mov	w0, #0x1                // =1
    7dd4:      	stp	x8, x10, [x9, #0x10]
    7dd8:      	b	0x7cec <.text+0x33c8>
    7ddc:      	paciasp
    7de0:      	stp	x29, x30, [sp, #-0x40]!
    7de4:      	str	x23, [sp, #0x10]
    7de8:      	stp	x22, x21, [sp, #0x20]
    7dec:      	stp	x20, x19, [sp, #0x30]
    7df0:      	mov	x29, sp
    7df4:      	mov	x20, x3
    7df8:      	sub	x3, x2, x1
    7dfc:      	mov	x19, x1
    7e00:      	cmp	x3, #0x3
    7e04:      	b.hi	0x7e30 <.text+0x350c>
    7e08:      	cmp	x2, x19
    7e0c:      	b.eq	0x7eb8 <.text+0x3594>
    7e10:      	adrp	x20, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    7e14:      	adrp	x1, 0x2000
    7e18:      	add	x1, x1, #0x4a0
    7e1c:      	ldr	x20, [x20, #0x3e0]
    7e20:      	mov	x2, x19
    7e24:      	add	x0, x20, #0x130
    7e28:      	bl	0xd080 <fprintf@plt>
    7e2c:      	b	0x7eb0 <.text+0x358c>
    7e30:      	ldrb	w8, [x19]
    7e34:      	cmp	w8, #0x1
    7e38:      	b.ne	0x7e90 <.text+0x356c>
    7e3c:      	add	x8, x19, #0x4
    7e40:      	ldrb	w21, [x19, #0x2]
    7e44:      	ldrb	w3, [x19, #0x1]
    7e48:      	str	x8, [x29, #0x18]
    7e4c:      	add	x1, x29, #0x18
    7e50:      	mov	x4, x19
    7e54:      	ldrb	w8, [x19, #0x3]
    7e58:      	mov	x23, x0
    7e5c:      	mov	x22, x2
    7e60:      	strb	w8, [x20, #0x18]
    7e64:      	bl	0x6ac4 <.text+0x21a0>
    7e68:      	cmp	w21, #0xff
    7e6c:      	str	x0, [x20]
    7e70:      	b.eq	0x7ed4 <.text+0x35b0>
    7e74:      	add	x1, x29, #0x18
    7e78:      	mov	x0, x23
    7e7c:      	mov	x2, x22
    7e80:      	mov	w3, w21
    7e84:      	mov	x4, x19
    7e88:      	bl	0x6ac4 <.text+0x21a0>
    7e8c:      	b	0x7ed8 <.text+0x35b4>
    7e90:      	adrp	x20, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    7e94:      	adrp	x1, 0x1000
    7e98:      	add	x1, x1, #0xf11
    7e9c:      	ldr	x20, [x20, #0x3e0]
    7ea0:      	mov	w2, w8
    7ea4:      	mov	x3, x19
    7ea8:      	add	x0, x20, #0x130
    7eac:      	bl	0xd080 <fprintf@plt>
    7eb0:      	add	x0, x20, #0x130
    7eb4:      	bl	0xd090 <fflush@plt>
    7eb8:      	mov	w0, wzr
    7ebc:      	ldp	x20, x19, [sp, #0x30]
    7ec0:      	ldr	x23, [sp, #0x10]
    7ec4:      	ldp	x22, x21, [sp, #0x20]
    7ec8:      	ldp	x29, x30, [sp], #0x40
    7ecc:      	autiasp
    7ed0:      	ret
    7ed4:      	mov	x0, xzr
    7ed8:      	ldr	x8, [x29, #0x18]
    7edc:      	stp	x0, x8, [x20, #0x8]
    7ee0:      	mov	w0, #0x1                // =1
    7ee4:      	ldp	x20, x19, [sp, #0x30]
    7ee8:      	ldr	x23, [sp, #0x10]
    7eec:      	ldp	x22, x21, [sp, #0x20]
    7ef0:      	ldp	x29, x30, [sp], #0x40
    7ef4:      	autiasp
    7ef8:      	ret
    7efc:      	paciasp
    7f00:      	sub	sp, sp, #0x70
    7f04:      	stp	x29, x30, [sp, #0x10]
    7f08:      	stp	x28, x27, [sp, #0x20]
    7f0c:      	stp	x26, x25, [sp, #0x30]
    7f10:      	stp	x24, x23, [sp, #0x40]
    7f14:      	stp	x22, x21, [sp, #0x50]
    7f18:      	stp	x20, x19, [sp, #0x60]
    7f1c:      	add	x29, sp, #0x10
    7f20:      	cmp	x4, #0x0
    7f24:      	add	x8, x3, x2
    7f28:      	csel	x22, x2, x4, eq
    7f2c:      	cmn	x3, #0x1
    7f30:      	csinv	x27, x8, xzr, ne
    7f34:      	str	x22, [sp, #0x8]
    7f38:      	cmp	x22, x27
    7f3c:      	b.hs	0x8080 <.text+0x375c>
    7f40:      	mov	x21, x6
    7f44:      	mov	x19, x5
    7f48:      	mov	x23, x2
    7f4c:      	mov	x24, x1
    7f50:      	mov	x20, x0
    7f54:      	b	0x7f64 <.text+0x3640>
    7f58:      	cmp	x22, x27
    7f5c:      	str	x22, [sp, #0x8]
    7f60:      	b.hs	0x8080 <.text+0x375c>
    7f64:      	mov	x8, x22
    7f68:      	mov	x26, x22
    7f6c:      	ldr	w9, [x8], #0x4
    7f70:      	str	x8, [sp, #0x8]
    7f74:      	cmn	w9, #0x1
    7f78:      	b.ne	0x7f88 <.text+0x3664>
    7f7c:      	ldur	x9, [x26, #0x4]
    7f80:      	add	x8, x26, #0xc
    7f84:      	str	x8, [sp, #0x8]
    7f88:      	cbz	x9, 0x8080 <.text+0x375c>
    7f8c:      	ldr	w10, [x8]
    7f90:      	add	x22, x8, x9
    7f94:      	cbz	w10, 0x7f58 <.text+0x3634>
    7f98:      	sub	x1, x8, x10
    7f9c:      	cmp	x1, x23
    7fa0:      	b.lo	0x7f58 <.text+0x3634>
    7fa4:      	cmp	x1, x27
    7fa8:      	b.hs	0x7f58 <.text+0x3634>
    7fac:      	mov	x0, x20
    7fb0:      	mov	x2, x21
    7fb4:      	bl	0x4c6c <.text+0x348>
    7fb8:      	cbnz	x0, 0x7f58 <.text+0x3634>
    7fbc:      	ldr	x8, [sp, #0x8]
    7fc0:      	ldrb	w3, [x21, #0x18]
    7fc4:      	add	x1, sp, #0x8
    7fc8:      	mov	x0, x20
    7fcc:      	mov	x2, x22
    7fd0:      	mov	x4, xzr
    7fd4:      	add	x8, x8, #0x4
    7fd8:      	str	x8, [sp, #0x8]
    7fdc:      	bl	0x6ac4 <.text+0x21a0>
    7fe0:      	ldrb	w8, [x21, #0x18]
    7fe4:      	mov	x25, x0
    7fe8:      	add	x1, sp, #0x8
    7fec:      	mov	x0, x20
    7ff0:      	mov	x2, x22
    7ff4:      	mov	x4, xzr
    7ff8:      	and	w3, w8, #0xf
    7ffc:      	bl	0x6ac4 <.text+0x21a0>
    8000:      	cmp	x25, x24
    8004:      	b.hs	0x7f58 <.text+0x3634>
    8008:      	add	x28, x0, x25
    800c:      	cmp	x28, x24
    8010:      	b.lo	0x7f58 <.text+0x3634>
    8014:      	ldrb	w8, [x21, #0x31]
    8018:      	str	xzr, [x19, #0x28]
    801c:      	cbz	w8, 0x80a8 <.text+0x3784>
    8020:      	add	x0, sp, #0x8
    8024:      	mov	x1, x22
    8028:      	bl	0x6e50 <.text+0x252c>
    802c:      	ldrb	w8, [x21, #0x19]
    8030:      	ldr	x24, [sp, #0x8]
    8034:      	cmp	w8, #0xff
    8038:      	add	x23, x24, x0
    803c:      	b.eq	0x80ac <.text+0x3788>
    8040:      	add	x1, sp, #0x8
    8044:      	and	w3, w8, #0xf
    8048:      	mov	x0, x20
    804c:      	mov	x2, x22
    8050:      	mov	x4, xzr
    8054:      	bl	0x6ac4 <.text+0x21a0>
    8058:      	cbz	x0, 0x80ac <.text+0x3788>
    805c:      	ldrb	w3, [x21, #0x19]
    8060:      	add	x1, sp, #0x8
    8064:      	mov	x0, x20
    8068:      	mov	x2, x22
    806c:      	mov	x4, xzr
    8070:      	str	x24, [sp, #0x8]
    8074:      	bl	0x6ac4 <.text+0x21a0>
    8078:      	str	x0, [x19, #0x28]
    807c:      	b	0x80ac <.text+0x3788>
    8080:      	mov	w0, wzr
    8084:      	ldp	x20, x19, [sp, #0x60]
    8088:      	ldp	x22, x21, [sp, #0x50]
    808c:      	ldp	x24, x23, [sp, #0x40]
    8090:      	ldp	x26, x25, [sp, #0x30]
    8094:      	ldp	x28, x27, [sp, #0x20]
    8098:      	ldp	x29, x30, [sp, #0x10]
    809c:      	add	sp, sp, #0x70
    80a0:      	autiasp
    80a4:      	ret
    80a8:      	ldr	x23, [sp, #0x8]
    80ac:      	sub	x8, x22, x26
    80b0:      	stp	x23, x25, [x19, #0x10]
    80b4:      	mov	w0, #0x1                // =1
    80b8:      	stp	x26, x8, [x19]
    80bc:      	str	x28, [x19, #0x20]
    80c0:      	b	0x8084 <.text+0x3760>
    80c4:      	paciasp
    80c8:      	sub	sp, sp, #0xa0
    80cc:      	stp	x29, x30, [sp, #0x40]
    80d0:      	stp	x28, x27, [sp, #0x50]
    80d4:      	stp	x26, x25, [sp, #0x60]
    80d8:      	stp	x24, x23, [sp, #0x70]
    80dc:      	stp	x22, x21, [sp, #0x80]
    80e0:      	stp	x20, x19, [sp, #0x90]
    80e4:      	add	x29, sp, #0x40
    80e8:      	add	x24, x2, w3, uxtw
    80ec:      	mov	x23, x2
    80f0:      	mov	x20, x1
    80f4:      	add	x3, sp, #0x20
    80f8:      	mov	x1, x2
    80fc:      	mov	x21, x5
    8100:      	mov	x2, x24
    8104:      	mov	x19, x4
    8108:      	mov	x22, x0
    810c:      	bl	0x7ddc <.text+0x34b8>
    8110:      	tbz	w0, #0x0, 0x8204 <.text+0x38e0>
    8114:      	ldr	x8, [sp, #0x28]
    8118:      	cbz	x8, 0x8204 <.text+0x38e0>
    811c:      	ldrb	w0, [sp, #0x38]
    8120:      	stp	x21, x19, [sp, #0x8]
    8124:      	bl	0x822c <.text+0x3908>
    8128:      	ldr	x27, [sp, #0x28]
    812c:      	mov	x25, x0
    8130:      	mov	x26, xzr
    8134:      	cmp	x27, #0x1
    8138:      	b.ls	0x8184 <.text+0x3860>
    813c:      	lsr	x21, x27, #1
    8140:      	ldr	x8, [sp, #0x30]
    8144:      	ldrb	w3, [sp, #0x38]
    8148:      	add	x1, sp, #0x18
    814c:      	mov	x0, x22
    8150:      	mov	x2, x24
    8154:      	add	x19, x21, x26
    8158:      	mov	x4, x23
    815c:      	mul	x28, x19, x25
    8160:      	add	x8, x8, x28
    8164:      	str	x8, [sp, #0x18]
    8168:      	bl	0x6ac4 <.text+0x21a0>
    816c:      	sub	x8, x27, x21
    8170:      	cmp	x0, x20
    8174:      	csel	x26, x26, x19, hs
    8178:      	csel	x27, x21, x8, hs
    817c:      	b.ne	0x8134 <.text+0x3810>
    8180:      	b	0x8188 <.text+0x3864>
    8184:      	mul	x28, x26, x25
    8188:      	ldr	x8, [sp, #0x30]
    818c:      	ldrb	w25, [sp, #0x38]
    8190:      	add	x1, sp, #0x18
    8194:      	mov	x0, x22
    8198:      	mov	x2, x24
    819c:      	mov	x4, x23
    81a0:      	add	x8, x8, x28
    81a4:      	mov	w3, w25
    81a8:      	str	x8, [sp, #0x18]
    81ac:      	bl	0x6ac4 <.text+0x21a0>
    81b0:      	add	x1, sp, #0x18
    81b4:      	mov	x0, x22
    81b8:      	mov	x2, x24
    81bc:      	mov	w3, w25
    81c0:      	mov	x4, x23
    81c4:      	bl	0x6ac4 <.text+0x21a0>
    81c8:      	ldp	x3, x19, [sp, #0x8]
    81cc:      	mov	x1, x0
    81d0:      	mov	x0, x22
    81d4:      	mov	w4, wzr
    81d8:      	mov	x2, x19
    81dc:      	bl	0x4adc <.text+0x1b8>
    81e0:      	cbnz	x0, 0x8204 <.text+0x38e0>
    81e4:      	ldr	x8, [x19, #0x18]
    81e8:      	cmp	x8, x20
    81ec:      	b.hi	0x8204 <.text+0x38e0>
    81f0:      	ldr	x8, [x19, #0x20]
    81f4:      	cmp	x8, x20
    81f8:      	b.ls	0x8204 <.text+0x38e0>
    81fc:      	mov	w0, #0x1                // =1
    8200:      	b	0x8208 <.text+0x38e4>
    8204:      	mov	w0, wzr
    8208:      	ldp	x20, x19, [sp, #0x90]
    820c:      	ldp	x22, x21, [sp, #0x80]
    8210:      	ldp	x24, x23, [sp, #0x70]
    8214:      	ldp	x26, x25, [sp, #0x60]
    8218:      	ldp	x28, x27, [sp, #0x50]
    821c:      	ldp	x29, x30, [sp, #0x40]
    8220:      	add	sp, sp, #0xa0
    8224:      	autiasp
    8228:      	ret
    822c:      	paciasp
    8230:      	stp	x29, x30, [sp, #-0x20]!
    8234:      	str	x19, [sp, #0x10]
    8238:      	mov	x29, sp
    823c:      	and	w8, w0, #0xf
    8240:      	mov	w0, #0x4                // =4
    8244:      	cmp	w8, #0x8
    8248:      	b.gt	0x8268 <.text+0x3944>
    824c:      	cmp	w8, #0x2
    8250:      	b.le	0x82a8 <.text+0x3984>
    8254:      	cmp	w8, #0x3
    8258:      	b.eq	0x8280 <.text+0x395c>
    825c:      	cmp	w8, #0x4
    8260:      	b.eq	0x8294 <.text+0x3970>
    8264:      	b	0x82b4 <.text+0x3990>
    8268:      	cmp	w8, #0xa
    826c:      	b.le	0x82e8 <.text+0x39c4>
    8270:      	cmp	w8, #0xc
    8274:      	b.eq	0x8294 <.text+0x3970>
    8278:      	cmp	w8, #0xb
    827c:      	b.ne	0x82b4 <.text+0x3990>
    8280:      	mov	w0, #0x8                // =8
    8284:      	ldr	x19, [sp, #0x10]
    8288:      	ldp	x29, x30, [sp], #0x20
    828c:      	autiasp
    8290:      	ret
    8294:      	mov	w0, #0x10               // =16
    8298:      	ldr	x19, [sp, #0x10]
    829c:      	ldp	x29, x30, [sp], #0x20
    82a0:      	autiasp
    82a4:      	ret
    82a8:      	b.eq	0x8284 <.text+0x3960>
    82ac:      	cmp	w8, #0x1
    82b0:      	b.eq	0x82f4 <.text+0x39d0>
    82b4:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    82b8:      	nop
    82bc:      	adr	x1, 0x1af2
    82c0:      	ldr	x19, [x19, #0x3e0]
    82c4:      	adrp	x2, 0x1000
    82c8:      	add	x2, x2, #0xfa9
    82cc:      	adrp	x3, 0x2000
    82d0:      	add	x3, x3, #0x882
    82d4:      	add	x0, x19, #0x130
    82d8:      	bl	0xd080 <fprintf@plt>
    82dc:      	add	x0, x19, #0x130
    82e0:      	bl	0xd090 <fflush@plt>
    82e4:      	bl	0xd0a0 <abort@plt>
    82e8:      	b.eq	0x8284 <.text+0x3960>
    82ec:      	cmp	w8, #0x9
    82f0:      	b.ne	0x82b4 <.text+0x3990>
    82f4:      	adrp	x19, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    82f8:      	nop
    82fc:      	adr	x1, 0x1af2
    8300:      	ldr	x19, [x19, #0x3e0]
    8304:      	adrp	x2, 0x1000
    8308:      	add	x2, x2, #0xfa9
    830c:      	adrp	x3, 0x1000
    8310:      	add	x3, x3, #0xd9a
    8314:      	add	x0, x19, #0x130
    8318:      	bl	0xd080 <fprintf@plt>
    831c:      	add	x0, x19, #0x130
    8320:      	bl	0xd090 <fflush@plt>
    8324:      	bl	0xd0a0 <abort@plt>
    8328:      	bti	c
    832c:      	add	w8, w0, #0x2
    8330:      	cmp	w8, #0x61
    8334:      	b.hi	0x834c <.text+0x3a28>
    8338:      	nop
    833c:      	adr	x9, 0x3064
    8340:      	ldrsw	x8, [x9, w8, uxtw #2]
    8344:      	add	x0, x9, x8
    8348:      	ret
    834c:      	adrp	x0, 0x2000
    8350:      	add	x0, x0, #0x827
    8354:      	ret
    8358:      	paciasp
    835c:      	stp	x29, x30, [sp, #-0x30]!
    8360:      	str	x28, [sp, #0x10]
    8364:      	stp	x20, x19, [sp, #0x20]
    8368:      	mov	x29, sp
    836c:      	sub	sp, sp, #0x480
    8370:      	mov	x20, x0
    8374:      	mov	x0, sp
    8378:      	mov	x19, x1
    837c:      	bl	0x84a0 <.text+0x3b7c>
    8380:      	add	x0, sp, #0x210
    8384:      	mov	x1, sp
    8388:      	bl	0x49a4 <.text+0x80>
    838c:      	add	x0, sp, #0x210
    8390:      	bl	0x4ac8 <.text+0x1a4>
    8394:      	cmp	w0, #0x1
    8398:      	b.lt	0x83c4 <.text+0x3aa0>
    839c:      	add	x0, sp, #0x210
    83a0:      	mov	x1, x19
    83a4:      	blr	x20
    83a8:      	cbz	w0, 0x838c <.text+0x3a68>
    83ac:      	add	sp, sp, #0x480
    83b0:      	ldp	x20, x19, [sp, #0x20]
    83b4:      	ldr	x28, [sp, #0x10]
    83b8:      	ldp	x29, x30, [sp], #0x30
    83bc:      	autiasp
    83c0:      	ret
    83c4:      	mov	w0, #0x5                // =5
    83c8:      	add	sp, sp, #0x480
    83cc:      	ldp	x20, x19, [sp, #0x20]
    83d0:      	ldr	x28, [sp, #0x10]
    83d4:      	ldp	x29, x30, [sp], #0x30
    83d8:      	autiasp
    83dc:      	ret
    83e0:      	paciasp
    83e4:      	sub	sp, sp, #0x20
    83e8:      	stp	x29, x30, [sp, #0x10]
    83ec:      	add	x29, sp, #0x10
    83f0:      	add	x2, sp, #0x8
    83f4:      	mov	w1, #-0x2               // =-2
    83f8:      	bl	0x4a4c <.text+0x128>
    83fc:      	ldr	x0, [sp, #0x8]
    8400:      	ldp	x29, x30, [sp, #0x10]
    8404:      	add	sp, sp, #0x20
    8408:      	autiasp
    840c:      	ret
    8410:      	bti	c
    8414:      	ldp	x2, x3, [x0, #0x10]
    8418:      	ldp	x4, x5, [x0, #0x20]
    841c:      	ldp	x6, x7, [x0, #0x30]
    8420:      	ldp	x8, x9, [x0, #0x40]
    8424:      	ldp	x10, x11, [x0, #0x50]
    8428:      	ldp	x12, x13, [x0, #0x60]
    842c:      	ldp	x14, x15, [x0, #0x70]
    8430:      	ldp	x18, x19, [x0, #0x90]
    8434:      	ldp	x20, x21, [x0, #0xa0]
    8438:      	ldp	x22, x23, [x0, #0xb0]
    843c:      	ldp	x24, x25, [x0, #0xc0]
    8440:      	ldp	x26, x27, [x0, #0xd0]
    8444:      	ldp	x28, x29, [x0, #0xe0]
    8448:      	ldr	x30, [x0, #0x100]
    844c:      	ldp	d0, d1, [x0, #0x110]
    8450:      	ldp	d2, d3, [x0, #0x120]
    8454:      	ldp	d4, d5, [x0, #0x130]
    8458:      	ldp	d6, d7, [x0, #0x140]
    845c:      	ldp	d8, d9, [x0, #0x150]
    8460:      	ldp	d10, d11, [x0, #0x160]
    8464:      	ldp	d12, d13, [x0, #0x170]
    8468:      	ldp	d14, d15, [x0, #0x180]
    846c:      	ldp	d16, d17, [x0, #0x190]
    8470:      	ldp	d18, d19, [x0, #0x1a0]
    8474:      	ldp	d20, d21, [x0, #0x1b0]
    8478:      	ldp	d22, d23, [x0, #0x1c0]
    847c:      	ldp	d24, d25, [x0, #0x1d0]
    8480:      	ldp	d26, d27, [x0, #0x1e0]
    8484:      	ldp	d28, d29, [x0, #0x1f0]
    8488:      	ldr	d30, [x0, #0x200]
    848c:      	ldr	d31, [x0, #0x208]
    8490:      	ldr	x16, [x0, #0xf8]
    8494:      	ldp	x0, x1, [x0]
    8498:      	mov	sp, x16
    849c:      	ret
    84a0:      	bti	c
    84a4:      	stp	x0, x1, [x0]
    84a8:      	stp	x2, x3, [x0, #0x10]
    84ac:      	stp	x4, x5, [x0, #0x20]
    84b0:      	stp	x6, x7, [x0, #0x30]
    84b4:      	stp	x8, x9, [x0, #0x40]
    84b8:      	stp	x10, x11, [x0, #0x50]
    84bc:      	stp	x12, x13, [x0, #0x60]
    84c0:      	stp	x14, x15, [x0, #0x70]
    84c4:      	stp	x16, x17, [x0, #0x80]
    84c8:      	stp	x18, x19, [x0, #0x90]
    84cc:      	stp	x20, x21, [x0, #0xa0]
    84d0:      	stp	x22, x23, [x0, #0xb0]
    84d4:      	stp	x24, x25, [x0, #0xc0]
    84d8:      	stp	x26, x27, [x0, #0xd0]
    84dc:      	stp	x28, x29, [x0, #0xe0]
    84e0:      	str	x30, [x0, #0xf0]
    84e4:      	mov	x1, sp
    84e8:      	str	x1, [x0, #0xf8]
    84ec:      	str	x30, [x0, #0x100]
    84f0:      	stp	d0, d1, [x0, #0x110]
    84f4:      	stp	d2, d3, [x0, #0x120]
    84f8:      	stp	d4, d5, [x0, #0x130]
    84fc:      	stp	d6, d7, [x0, #0x140]
    8500:      	stp	d8, d9, [x0, #0x150]
    8504:      	stp	d10, d11, [x0, #0x160]
    8508:      	stp	d12, d13, [x0, #0x170]
    850c:      	stp	d14, d15, [x0, #0x180]
    8510:      	stp	d16, d17, [x0, #0x190]
    8514:      	stp	d18, d19, [x0, #0x1a0]
    8518:      	stp	d20, d21, [x0, #0x1b0]
    851c:      	stp	d22, d23, [x0, #0x1c0]
    8520:      	stp	d24, d25, [x0, #0x1d0]
    8524:      	stp	d26, d27, [x0, #0x1e0]
    8528:      	stp	d28, d29, [x0, #0x1f0]
    852c:      	str	d30, [x0, #0x200]
    8530:      	str	d31, [x0, #0x208]
    8534:      	mov	x0, #0x0                // =0
    8538:      	ret
    853c:      	stp	x29, x30, [sp, #-0x30]!
    8540:      	stp	x22, x21, [sp, #0x10]
    8544:      	stp	x20, x19, [sp, #0x20]
    8548:      	mov	x29, sp
    854c:      	nop
    8550:      	adr	x22, 0x156a8
    8554:      	cmp	w0, #0x0
    8558:      	add	x8, x22, #0x4
    855c:      	csel	x8, x8, x22, eq
    8560:      	ldr	w8, [x8]
    8564:      	tbz	w8, #0x1f, 0x85a8 <.text+0x3c84>
    8568:      	mov	w19, w0
    856c:      	bl	0xcd80 <__errno@plt>
    8570:      	mov	x20, x0
    8574:      	adrp	x21, 0x2000
    8578:      	add	x21, x21, #0xf41
    857c:      	mov	x0, x21
    8580:      	mov	w1, #0x2                // =2
    8584:      	bl	0xccd4 <JNI_OnLoad+0x3a98>
    8588:      	cmn	w0, #0x1
    858c:      	b.ne	0x859c <.text+0x3c78>
    8590:      	bl	0xca80 <JNI_OnLoad+0x3844>
    8594:      	b.eq	0x857c <.text+0x3c58>
    8598:      	mov	w0, #-0x1               // =-1
    859c:      	cmp	w19, #0x0
    85a0:      	cset	w8, eq
    85a4:      	str	w0, [x22, w8, uxtw #2]
    85a8:      	ldp	x20, x19, [sp, #0x20]
    85ac:      	ldp	x22, x21, [sp, #0x10]
    85b0:      	ldp	x29, x30, [sp], #0x30
    85b4:      	ret
    85b8:      	stp	x29, x30, [sp, #-0x20]!
    85bc:      	str	x19, [sp, #0x10]
    85c0:      	mov	x29, sp
    85c4:      	adrp	x19, 0x15000
    85c8:      	ldr	w0, [x19, #0x6a8]
    85cc:      	tbnz	w0, #0x1f, 0x85e4 <.text+0x3cc0>
    85d0:      	bl	0xcde0 <close@plt>
    85d4:      	mov	w0, wzr
    85d8:      	mov	w8, #-0x1               // =-1
    85dc:      	str	w8, [x19, #0x6a8]
    85e0:      	b	0x85e8 <.text+0x3cc4>
    85e4:      	mov	w0, #0x3f8              // =1016
    85e8:      	ldr	x19, [sp, #0x10]
    85ec:      	ldp	x29, x30, [sp], #0x20
    85f0:      	ret
    85f4:      	sub	sp, sp, #0x100
    85f8:      	stp	x29, x30, [sp, #0xc0]
    85fc:      	str	x23, [sp, #0xd0]
    8600:      	stp	x22, x21, [sp, #0xe0]
    8604:      	stp	x20, x19, [sp, #0xf0]
    8608:      	add	x29, sp, #0xc0
    860c:      	mrs	x22, TPIDR_EL0
    8610:      	adrp	x23, 0x17000
    8614:      	add	x1, sp, #0x20
    8618:      	ldr	x8, [x22, #0x28]
    861c:      	mov	x2, sp
    8620:      	stur	x8, [x29, #-0x8]
    8624:      	nop
    8628:      	adr	x8, 0x111b0
    862c:      	ldr	q0, [x8]
    8630:      	ldr	x8, [x8, #0x10]
    8634:      	ldr	x0, [x23, #0x388]
    8638:      	stp	xzr, xzr, [sp, #0x20]
    863c:      	str	xzr, [sp, #0x30]
    8640:      	str	q0, [sp]
    8644:      	stp	x8, xzr, [sp, #0x10]
    8648:      	ldr	x8, [x0]
    864c:      	ldr	x8, [x8, #0x20]
    8650:      	blr	x8
    8654:      	cbnz	w0, 0x87c8 <.text+0x3ea4>
    8658:      	bl	0xcd80 <__errno@plt>
    865c:      	mov	x19, x0
    8660:      	adrp	x20, 0x15000
    8664:      	str	wzr, [x19]
    8668:      	add	x1, sp, #0x18
    866c:      	mov	w2, #0x8                // =8
    8670:      	ldr	w0, [x20, #0x6b0]
    8674:      	bl	0xce50 <read@plt>
    8678:      	cmn	x0, #0x1
    867c:      	b.ne	0x8690 <.text+0x3d6c>
    8680:      	ldr	w8, [x19]
    8684:      	cmp	w8, #0x4
    8688:      	b.eq	0x8664 <.text+0x3d40>
    868c:      	b	0x87b8 <.text+0x3e94>
    8690:      	cmp	x0, #0x8
    8694:      	b.ne	0x87b8 <.text+0x3e94>
    8698:      	ldr	x0, [sp, #0x20]
    869c:      	adrp	x1, 0x17000
    86a0:      	add	x1, x1, #0x418
    86a4:      	bl	0xcaa8 <JNI_OnLoad+0x386c>
    86a8:      	cbz	x0, 0x87b8 <.text+0x3e94>
    86ac:      	adrp	x8, 0x17000
    86b0:      	mov	x19, x0
    86b4:      	ldr	x1, [x8, #0x350]
    86b8:      	ldrb	w8, [x1]
    86bc:      	cbz	w8, 0x86d4 <.text+0x3db0>
    86c0:      	ldr	x0, [sp, #0x20]
    86c4:      	bl	0xcaa8 <JNI_OnLoad+0x386c>
    86c8:      	mov	x20, x0
    86cc:      	cbnz	x0, 0x86d8 <.text+0x3db4>
    86d0:      	b	0x87b8 <.text+0x3e94>
    86d4:      	mov	x20, xzr
    86d8:      	adrp	x8, 0x17000
    86dc:      	ldrb	w21, [x8, #0x320]
    86e0:      	cmp	w21, #0x1
    86e4:      	b.ne	0x8708 <.text+0x3de4>
    86e8:      	adrp	x8, 0x17000
    86ec:      	add	x8, x8, #0x334
    86f0:      	ldp	w9, w3, [x8]
    86f4:      	cmp	w9, w3
    86f8:      	b.ne	0x8714 <.text+0x3df0>
    86fc:      	mov	x7, xzr
    8700:      	mov	w6, #0x1                // =1
    8704:      	b	0x8770 <.text+0x3e4c>
    8708:      	mov	w6, wzr
    870c:      	mov	x7, xzr
    8710:      	b	0x8770 <.text+0x3e4c>
    8714:      	adrp	x2, 0x2000
    8718:      	add	x2, x2, #0xecf
    871c:      	add	x0, sp, #0x38
    8720:      	mov	w1, #0x80               // =128
    8724:      	bl	0xa6a4 <JNI_OnLoad+0x1468>
    8728:      	add	x0, sp, #0x38
    872c:      	add	x1, sp, #0x28
    8730:      	mov	w2, #0x10               // =16
    8734:      	bl	0xab80 <JNI_OnLoad+0x1944>
    8738:      	cbz	w0, 0x8758 <.text+0x3e34>
    873c:      	adrp	x1, 0x1000
    8740:      	add	x1, x1, #0xeeb
    8744:      	add	x0, sp, #0x28
    8748:      	mov	w2, #0x10               // =16
    874c:      	mov	x3, #-0x1               // =-1
    8750:      	mov	w4, #0x8                // =8
    8754:      	bl	0xcf70 <__strncpy_chk2@plt>
    8758:      	ldr	x0, [sp, #0x20]
    875c:      	add	x1, sp, #0x28
    8760:      	bl	0xcaa8 <JNI_OnLoad+0x386c>
    8764:      	cbz	x0, 0x87b8 <.text+0x3e94>
    8768:      	mov	x7, x0
    876c:      	mov	w6, wzr
    8770:      	ldr	x0, [sp, #0x20]
    8774:      	adrp	x9, 0x17000
    8778:      	add	x9, x9, #0x370
    877c:      	ldp	x1, x2, [x9]
    8780:      	mov	x3, x19
    8784:      	ldr	x8, [x0]
    8788:      	mov	x4, x20
    878c:      	mov	w5, w21
    8790:      	ldr	x8, [x8, #0x468]
    8794:      	blr	x8
    8798:      	ldr	x0, [sp, #0x20]
    879c:      	ldr	x8, [x0]
    87a0:      	bl	0xc984 <JNI_OnLoad+0x3748>
    87a4:      	tst	w0, #0xff
    87a8:      	b.eq	0x87b8 <.text+0x3e94>
    87ac:      	ldr	x0, [sp, #0x20]
    87b0:      	ldr	x8, [x0]
    87b4:      	bl	0xcbe8 <JNI_OnLoad+0x39ac>
    87b8:      	ldr	x0, [x23, #0x388]
    87bc:      	ldr	x8, [x0]
    87c0:      	ldr	x8, [x8, #0x28]
    87c4:      	blr	x8
    87c8:      	ldr	x8, [x22, #0x28]
    87cc:      	bl	0xca50 <JNI_OnLoad+0x3814>
    87d0:      	b.ne	0x87f0 <.text+0x3ecc>
    87d4:      	ldp	x20, x19, [sp, #0xf0]
    87d8:      	mov	x0, xzr
    87dc:      	ldp	x22, x21, [sp, #0xe0]
    87e0:      	ldr	x23, [sp, #0xd0]
    87e4:      	ldp	x29, x30, [sp, #0xc0]
    87e8:      	add	sp, sp, #0x100
    87ec:      	ret
    87f0:      	bl	0xd110 <__stack_chk_fail@plt>
    87f4:      	stp	x29, x30, [sp, #-0x60]!
    87f8:      	bl	0xc9f0 <JNI_OnLoad+0x37b4>
    87fc:      	sub	sp, sp, #0x740
    8800:      	mrs	x8, TPIDR_EL0
    8804:      	adrp	x19, 0x17000
    8808:      	add	x19, x19, #0x324
    880c:      	str	x8, [sp, #0x100]
    8810:      	add	x0, x19, #0xcc
    8814:      	mov	x24, x2
    8818:      	ldr	x8, [x8, #0x28]
    881c:      	mov	x23, x1
    8820:      	stur	x8, [x29, #-0x10]
    8824:      	bl	0xcea0 <pthread_mutex_lock@plt>
    8828:      	ldrb	w8, [x19]
    882c:      	tbnz	w8, #0x0, 0x922c <.text+0x4908>
    8830:      	ldr	w8, [x19, #0xc]
    8834:      	mov	w9, #0x1                // =1
    8838:      	strb	w9, [x19]
    883c:      	nop
    8840:      	adr	x19, 0x156a8
    8844:      	cbz	w8, 0x8894 <.text+0x3f70>
    8848:      	mov	x20, xzr
    884c:      	mov	w22, wzr
    8850:      	mov	w21, #0x3e9             // =1001
    8854:      	cmp	x20, #0x140
    8858:      	b.eq	0x888c <.text+0x3f68>
    885c:      	add	x8, x19, x20
    8860:      	mov	x2, xzr
    8864:      	ldr	w0, [x8, #0x18]
    8868:      	add	x1, x8, #0x20
    886c:      	bl	0xcfa0 <sigaction@plt>
    8870:      	cbz	w0, 0x8884 <.text+0x3f60>
    8874:      	bl	0xcd80 <__errno@plt>
    8878:      	ldr	w8, [x0]
    887c:      	cmp	w8, #0x0
    8880:      	csel	w22, w21, w8, eq
    8884:      	add	x20, x20, #0x28
    8888:      	b	0x8854 <.text+0x3f30>
    888c:      	cbz	w22, 0x890c <.text+0x3fe8>
    8890:      	b	0x922c <.text+0x4908>
    8894:      	mov	x8, xzr
    8898:      	add	x9, sp, #0x330
    889c:      	cmp	x8, #0x20
    88a0:      	b.eq	0x88b0 <.text+0x3f8c>
    88a4:      	strb	wzr, [x9, x8]
    88a8:      	add	x8, x8, #0x1
    88ac:      	b	0x889c <.text+0x3f78>
    88b0:      	add	x8, sp, #0x330
    88b4:      	add	x0, x8, #0x10
    88b8:      	bl	0xcfb0 <sigemptyset@plt>
    88bc:      	mov	w20, wzr
    88c0:      	mov	w8, #0x10000000         // =268435456
    88c4:      	mov	w21, #0x18              // =24
    88c8:      	mov	w22, #0x3e9             // =1001
    88cc:      	str	xzr, [sp, #0x338]
    88d0:      	str	w8, [sp, #0x330]
    88d4:      	cmp	x21, #0x158
    88d8:      	b.eq	0x8908 <.text+0x3fe4>
    88dc:      	ldr	w0, [x19, x21]
    88e0:      	add	x1, sp, #0x330
    88e4:      	mov	x2, xzr
    88e8:      	bl	0xcfa0 <sigaction@plt>
    88ec:      	cbz	w0, 0x8900 <.text+0x3fdc>
    88f0:      	bl	0xcd80 <__errno@plt>
    88f4:      	ldr	w8, [x0]
    88f8:      	cmp	w8, #0x0
    88fc:      	csel	w20, w22, w8, eq
    8900:      	add	x21, x21, #0x28
    8904:      	b	0x88d4 <.text+0x3fb0>
    8908:      	cbnz	w20, 0x922c <.text+0x4908>
    890c:      	add	x1, sp, #0x118
    8910:      	mov	w0, wzr
    8914:      	bl	0xceb0 <clock_gettime@plt>
    8918:      	ldr	x8, [sp, #0x120]
    891c:      	mov	w9, #0x3e8              // =1000
    8920:      	mov	w10, #0x4240            // =16960
    8924:      	movk	w10, #0xf, lsl #16
    8928:      	adrp	x19, 0x17000
    892c:      	add	x19, x19, #0x338
    8930:      	udiv	x8, x8, x9
    8934:      	ldr	x9, [sp, #0x118]
    8938:      	nop
    893c:      	madd	x8, x9, x10, x8
    8940:      	str	x8, [x19, #0x58]
    8944:      	bl	0xcec0 <gettid@plt>
    8948:      	ldp	x3, x6, [x19, #0x8]
    894c:      	nop
    8950:      	adr	x2, 0x2e51
    8954:      	ldr	x4, [x19, #0x68]
    8958:      	ldr	x5, [x19, #0x78]
    895c:      	str	w0, [x19]
    8960:      	adrp	x7, 0x1000
    8964:      	add	x7, x7, #0xcd1
    8968:      	add	x0, x19, #0xe0
    896c:      	mov	w1, #0x400              // =1024
    8970:      	bl	0xa6a4 <JNI_OnLoad+0x1468>
    8974:      	bl	0xcd80 <__errno@plt>
    8978:      	mov	x20, x0
    897c:      	adrp	x21, 0x17000
    8980:      	adrp	x26, 0x15000
    8984:      	adrp	x19, 0x17000
    8988:      	stp	x23, x24, [sp, #0x108]
    898c:      	bl	0xcb1c <JNI_OnLoad+0x38e0>
    8990:      	cmn	w0, #0x1
    8994:      	b.ne	0x89a4 <.text+0x4080>
    8998:      	bl	0xca80 <JNI_OnLoad+0x3844>
    899c:      	b.eq	0x898c <.text+0x4068>
    89a0:      	b	0x89ac <.text+0x4088>
    89a4:      	mov	w22, w0
    89a8:      	tbz	w0, #0x1f, 0x89d4 <.text+0x40b0>
    89ac:      	bl	0x85b8 <.text+0x3c94>
    89b0:      	cbnz	w0, 0x8af4 <.text+0x41d0>
    89b4:      	b	0x89c0 <.text+0x409c>
    89b8:      	bl	0xca80 <JNI_OnLoad+0x3844>
    89bc:      	b.ne	0x8af4 <.text+0x41d0>
    89c0:      	bl	0xcb1c <JNI_OnLoad+0x38e0>
    89c4:      	cmn	w0, #0x1
    89c8:      	b.eq	0x89b8 <.text+0x4094>
    89cc:      	mov	w22, w0
    89d0:      	tbnz	w0, #0x1f, 0x8af4 <.text+0x41d0>
    89d4:      	adrp	x23, 0x2000
    89d8:      	add	x23, x23, #0x15
    89dc:      	adrp	x24, 0x2000
    89e0:      	add	x24, x24, #0x4d
    89e4:      	add	x21, sp, #0x130
    89e8:      	add	x2, sp, #0x130
    89ec:      	mov	w0, #0x3d               // =61
    89f0:      	mov	w1, w22
    89f4:      	mov	w3, #0x200              // =512
    89f8:      	bl	0xce10 <syscall@plt>
    89fc:      	cmp	x0, #0x1
    8a00:      	b.lt	0x8adc <.text+0x41b8>
    8a04:      	mov	x26, x0
    8a08:      	mov	x28, xzr
    8a0c:      	cmp	x28, x26
    8a10:      	b.ge	0x89e8 <.text+0x40c4>
    8a14:      	add	x25, x21, x28
    8a18:      	add	x0, x25, #0x13
    8a1c:      	bl	0xce60 <strlen@plt>
    8a20:      	cmp	x0, #0x2d
    8a24:      	b.ne	0x8a84 <.text+0x4160>
    8a28:      	add	x0, x25, #0x13
    8a2c:      	mov	x1, x23
    8a30:      	mov	w2, #0xc                // =12
    8a34:      	bl	0xce20 <memcmp@plt>
    8a38:      	cbnz	w0, 0x8a84 <.text+0x4160>
    8a3c:      	add	x0, x25, #0x33
    8a40:      	mov	x1, x24
    8a44:      	mov	w2, #0xd                // =13
    8a48:      	bl	0xce20 <memcmp@plt>
    8a4c:      	cbnz	w0, 0x8a84 <.text+0x4160>
    8a50:      	adrp	x27, 0x17000
    8a54:      	add	x27, x27, #0x340
    8a58:      	add	x0, sp, #0x330
    8a5c:      	ldr	x3, [x27], #0xd8
    8a60:      	add	x4, x25, #0x13
    8a64:      	mov	w1, #0x400              // =1024
    8a68:      	adrp	x2, 0x1000
    8a6c:      	add	x2, x2, #0xce0
    8a70:      	bl	0xa6a4 <JNI_OnLoad+0x1468>
    8a74:      	add	x0, sp, #0x330
    8a78:      	mov	x1, x27
    8a7c:      	bl	0xce30 <rename@plt>
    8a80:      	cbz	w0, 0x8a90 <.text+0x416c>
    8a84:      	ldrh	w8, [x25, #0x10]
    8a88:      	add	x28, x28, x8
    8a8c:      	b	0x8a0c <.text+0x40e8>
    8a90:      	mov	w21, #0x641             // =1601
    8a94:      	mov	w0, w22
    8a98:      	movk	w21, #0x8, lsl #16
    8a9c:      	bl	0xcde0 <close@plt>
    8aa0:      	ldr	x24, [sp, #0x110]
    8aa4:      	mov	w8, #0x1                // =1
    8aa8:      	sub	w22, w21, #0x63f
    8aac:      	adrp	x23, 0x17000
    8ab0:      	add	x23, x23, #0x418
    8ab4:      	adrp	x26, 0x15000
    8ab8:      	strb	w8, [x19, #0x328]
    8abc:      	mov	x0, x23
    8ac0:      	mov	w1, w22
    8ac4:      	bl	0xccd4 <JNI_OnLoad+0x3a98>
    8ac8:      	cmn	w0, #0x1
    8acc:      	b.ne	0x8b54 <.text+0x4230>
    8ad0:      	bl	0xca80 <JNI_OnLoad+0x3844>
    8ad4:      	b.eq	0x8abc <.text+0x4198>
    8ad8:      	b	0x8b48 <.text+0x4224>
    8adc:      	mov	w0, w22
    8ae0:      	bl	0xcde0 <close@plt>
    8ae4:      	mov	w0, #0x1                // =1
    8ae8:      	bl	0x853c <.text+0x3c18>
    8aec:      	ldr	x24, [sp, #0x110]
    8af0:      	adrp	x26, 0x15000
    8af4:      	adrp	x22, 0x17000
    8af8:      	add	x22, x22, #0x418
    8afc:      	strb	wzr, [x19, #0x328]
    8b00:      	bl	0xcad4 <JNI_OnLoad+0x3898>
    8b04:      	cmn	w0, #0x1
    8b08:      	b.ne	0x8b18 <.text+0x41f4>
    8b0c:      	bl	0xca80 <JNI_OnLoad+0x3844>
    8b10:      	b.eq	0x8b00 <.text+0x41dc>
    8b14:      	b	0x8b24 <.text+0x4200>
    8b18:      	tbnz	w0, #0x1f, 0x8b24 <.text+0x4200>
    8b1c:      	str	w0, [x26, #0x6b4]
    8b20:      	b	0x8b5c <.text+0x4238>
    8b24:      	bl	0x85b8 <.text+0x3c94>
    8b28:      	cbnz	w0, 0x8b48 <.text+0x4224>
    8b2c:      	adrp	x22, 0x17000
    8b30:      	add	x22, x22, #0x418
    8b34:      	bl	0xcad4 <JNI_OnLoad+0x3898>
    8b38:      	cmn	w0, #0x1
    8b3c:      	b.ne	0x8b54 <.text+0x4230>
    8b40:      	bl	0xca80 <JNI_OnLoad+0x3844>
    8b44:      	b.eq	0x8b34 <.text+0x4210>
    8b48:      	mov	w8, #-0x1               // =-1
    8b4c:      	str	w8, [x26, #0x6b4]
    8b50:      	b	0x8d10 <.text+0x43ec>
    8b54:      	str	w0, [x26, #0x6b4]
    8b58:      	tbnz	w0, #0x1f, 0x8d10 <.text+0x43ec>
    8b5c:      	mov	w0, #0x3                // =3
    8b60:      	bl	0xced0 <prctl@plt>
    8b64:      	mov	w22, w0
    8b68:      	mov	w0, #0x4                // =4
    8b6c:      	mov	w1, #0x1                // =1
    8b70:      	str	wzr, [x20]
    8b74:      	bl	0xced0 <prctl@plt>
    8b78:      	cbz	w0, 0x8b94 <.text+0x4270>
    8b7c:      	ldr	w0, [x26, #0x6b4]
    8b80:      	ldr	w2, [x20]
    8b84:      	adrp	x1, 0x1000
    8b88:      	add	x1, x1, #0xc01
    8b8c:      	bl	0xaabc <JNI_OnLoad+0x1880>
    8b90:      	b	0x8d10 <.text+0x43ec>
    8b94:      	mov	w0, #0x6d61             // =28001
    8b98:      	mov	x1, #-0x1               // =-1
    8b9c:      	str	wzr, [x20]
    8ba0:      	movk	w0, #0x5961, lsl #16
    8ba4:      	bl	0xced0 <prctl@plt>
    8ba8:      	cbz	w0, 0x8bc0 <.text+0x429c>
    8bac:      	ldr	w2, [x20]
    8bb0:      	cmp	w2, #0x16
    8bb4:      	b.ne	0x8cb4 <.text+0x4390>
    8bb8:      	mov	w25, wzr
    8bbc:      	b	0x8bc4 <.text+0x42a0>
    8bc0:      	mov	w25, #0x1               // =1
    8bc4:      	adrp	x19, 0x17000
    8bc8:      	add	x19, x19, #0x328
    8bcc:      	ldr	x1, [sp, #0x108]
    8bd0:      	ldr	x8, [x19, #0x68]
    8bd4:      	ldr	w9, [x19, #0x10]
    8bd8:      	nop
    8bdc:      	adr	x21, 0x16040
    8be0:      	mov	w2, #0x80               // =128
    8be4:      	add	x0, x21, #0x8
    8be8:      	str	x8, [x21, #0x1260]
    8bec:      	str	w9, [x21]
    8bf0:      	bl	0xd0b0 <memcpy@plt>
    8bf4:      	add	x0, x21, #0x90
    8bf8:      	mov	x1, x24
    8bfc:      	mov	w2, #0x11d0             // =4560
    8c00:      	bl	0xd0b0 <memcpy@plt>
    8c04:      	add	x0, x19, #0xf0
    8c08:      	mov	w1, #0x400              // =1024
    8c0c:      	bl	0xcdf0 <__strlen_chk@plt>
    8c10:      	ldrb	w8, [x19]
    8c14:      	str	x0, [x21, #0x1280]
    8c18:      	cmp	w8, #0x1
    8c1c:      	b.ne	0x8cf0 <.text+0x43cc>
    8c20:      	ldr	w23, [x26, #0x6b4]
    8c24:      	mov	x1, xzr
    8c28:      	mov	w2, wzr
    8c2c:      	mov	w0, w23
    8c30:      	bl	0xcdd0 <lseek@plt>
    8c34:      	tbnz	x0, #0x3f, 0x8ce0 <.text+0x43bc>
    8c38:      	add	x8, sp, #0x330
    8c3c:      	mov	x24, xzr
    8c40:      	sub	x19, x8, #0x1
    8c44:      	add	x1, sp, #0x330
    8c48:      	mov	w0, w23
    8c4c:      	mov	w2, #0x400              // =1024
    8c50:      	str	wzr, [x20]
    8c54:      	bl	0xce50 <read@plt>
    8c58:      	cmn	x0, #0x1
    8c5c:      	b.ne	0x8c6c <.text+0x4348>
    8c60:      	bl	0xca80 <JNI_OnLoad+0x3844>
    8c64:      	b.eq	0x8c44 <.text+0x4320>
    8c68:      	b	0x8ce0 <.text+0x43bc>
    8c6c:      	tbnz	x0, #0x3f, 0x8ce0 <.text+0x43bc>
    8c70:      	mov	x8, x0
    8c74:      	cbz	x0, 0x8ccc <.text+0x43a8>
    8c78:      	subs	x9, x8, #0x1
    8c7c:      	b.lt	0x8c94 <.text+0x4370>
    8c80:      	ldrb	w10, [x19, x8]
    8c84:      	mov	x8, x9
    8c88:      	cbz	w10, 0x8c78 <.text+0x4354>
    8c8c:      	add	x8, x9, #0x1
    8c90:      	b	0x8c98 <.text+0x4374>
    8c94:      	mov	x8, xzr
    8c98:      	cmp	x8, x0
    8c9c:      	add	x24, x8, x24
    8ca0:      	b.ge	0x8c44 <.text+0x4320>
    8ca4:      	mov	w0, w23
    8ca8:      	mov	x1, x24
    8cac:      	mov	w2, wzr
    8cb0:      	b	0x8cd8 <.text+0x43b4>
    8cb4:      	ldr	w0, [x26, #0x6b4]
    8cb8:      	adrp	x1, 0x2000
    8cbc:      	add	x1, x1, #0x6ec
    8cc0:      	bl	0xaabc <JNI_OnLoad+0x1880>
    8cc4:      	mov	w25, wzr
    8cc8:      	b	0x8cf0 <.text+0x43cc>
    8ccc:      	mov	w0, w23
    8cd0:      	mov	x1, xzr
    8cd4:      	mov	w2, #0x2                // =2
    8cd8:      	bl	0xcdd0 <lseek@plt>
    8cdc:      	tbz	x0, #0x3f, 0x8cec <.text+0x43c8>
    8ce0:      	mov	w0, w23
    8ce4:      	bl	0xcde0 <close@plt>
    8ce8:      	mov	w23, #-0x1              // =-1
    8cec:      	str	w23, [x26, #0x6b4]
    8cf0:      	mov	w0, #0x4                // =4
    8cf4:      	mov	w1, w22
    8cf8:      	bl	0xced0 <prctl@plt>
    8cfc:      	cbz	w25, 0x8d10 <.text+0x43ec>
    8d00:      	mov	w0, #0x6d61             // =28001
    8d04:      	mov	w1, wzr
    8d08:      	movk	w0, #0x5961, lsl #16
    8d0c:      	bl	0xced0 <prctl@plt>
    8d10:      	adrp	x9, 0x17000
    8d14:      	add	x9, x9, #0x33c
    8d18:      	adrp	x8, 0x15000
    8d1c:      	ldur	x22, [x9, #0x14]
    8d20:      	ldur	x4, [x9, #0x6c]
    8d24:      	ldur	x5, [x9, #0x74]
    8d28:      	ldr	w7, [x9]
    8d2c:      	ldur	x10, [x9, #0x7c]
    8d30:      	ldur	x21, [x9, #0x84]
    8d34:      	ldur	x27, [x9, #0x8c]
    8d38:      	ldur	x28, [x9, #0x94]
    8d3c:      	ldr	w8, [x8, #0x6bc]
    8d40:      	ldur	x26, [x9, #0x9c]
    8d44:      	ldur	x19, [x9, #0xa4]
    8d48:      	ldur	x23, [x9, #0xac]
    8d4c:      	tbz	w8, #0x1f, 0x8da4 <.text+0x4480>
    8d50:      	mov	x24, xzr
    8d54:      	nop
    8d58:      	adr	x25, 0x111c8
    8d5c:      	str	x10, [sp, #0xe0]
    8d60:      	str	w7, [sp, #0xec]
    8d64:      	stp	x5, x4, [sp, #0xf0]
    8d68:      	cmp	x24, #0x58
    8d6c:      	b.eq	0x8d8c <.text+0x4468>
    8d70:      	ldr	x0, [x25, x24]
    8d74:      	mov	w1, wzr
    8d78:      	bl	0xcff0 <access@plt>
    8d7c:      	add	x24, x24, #0x8
    8d80:      	cbnz	w0, 0x8d68 <.text+0x4444>
    8d84:      	mov	w8, #0x1                // =1
    8d88:      	b	0x8d90 <.text+0x446c>
    8d8c:      	mov	w8, wzr
    8d90:      	ldp	x5, x4, [sp, #0xf0]
    8d94:      	adrp	x9, 0x15000
    8d98:      	ldr	w7, [sp, #0xec]
    8d9c:      	ldr	x10, [sp, #0xe0]
    8da0:      	str	w8, [x9, #0x6bc]
    8da4:      	add	x9, x22, #0x7, lsl #12  // =0x7000
    8da8:      	cmp	w8, #0x0
    8dac:      	adrp	x8, 0x1000
    8db0:      	add	x8, x8, #0xfbb
    8db4:      	str	x9, [sp, #0xf8]
    8db8:      	adrp	x9, 0x2000
    8dbc:      	add	x9, x9, #0x1e2
    8dc0:      	adrp	x2, 0x2000
    8dc4:      	add	x2, x2, #0x98a
    8dc8:      	csel	x6, x8, x9, eq
    8dcc:      	adrp	x3, 0x2000
    8dd0:      	add	x3, x3, #0x1ad
    8dd4:      	mov	x0, x22
    8dd8:      	mov	w1, #0x7800             // =30720
    8ddc:      	stp	x19, x23, [sp, #0x28]
    8de0:      	stp	x28, x26, [sp, #0x18]
    8de4:      	stp	x21, x27, [sp, #0x8]
    8de8:      	mov	w21, #0x7800            // =30720
    8dec:      	str	x10, [sp]
    8df0:      	bl	0xa6a4 <JNI_OnLoad+0x1468>
    8df4:      	ldr	x25, [sp, #0x110]
    8df8:      	mov	x23, x0
    8dfc:      	sub	x1, x21, x0
    8e00:      	adrp	x2, 0x2000
    8e04:      	add	x2, x2, #0xba1
    8e08:      	add	x0, x22, x0
    8e0c:      	ldp	x3, x4, [x25, #0xb8]
    8e10:      	ldr	x7, [x25, #0xd8]
    8e14:      	ldp	x5, x6, [x25, #0xc8]
    8e18:      	ldp	q0, q1, [x25, #0xe0]
    8e1c:      	ldp	q2, q3, [x25, #0x100]
    8e20:      	ldp	q4, q5, [x25, #0x120]
    8e24:      	ldp	q6, q7, [x25, #0x140]
    8e28:      	ldp	q16, q17, [x25, #0x160]
    8e2c:      	ldp	q18, q19, [x25, #0x180]
    8e30:      	ldp	x8, x9, [x25, #0x1a0]
    8e34:      	ldp	x10, x11, [x25, #0x1b0]
    8e38:      	stp	q0, q1, [sp]
    8e3c:      	stp	q2, q3, [sp, #0x20]
    8e40:      	stp	q4, q5, [sp, #0x40]
    8e44:      	stp	x9, x11, [sp, #0xd0]
    8e48:      	stp	x8, x10, [sp, #0xc0]
    8e4c:      	stp	q6, q7, [sp, #0x60]
    8e50:      	stp	q16, q17, [sp, #0x80]
    8e54:      	stp	q18, q19, [sp, #0xa0]
    8e58:      	bl	0xa6a4 <JNI_OnLoad+0x1468>
    8e5c:      	add	x19, x0, x23
    8e60:      	adrp	x2, 0x2000
    8e64:      	add	x2, x2, #0x838
    8e68:      	add	x22, x22, x19
    8e6c:      	sub	x23, x21, x19
    8e70:      	mov	x0, x22
    8e74:      	mov	x1, x23
    8e78:      	bl	0xa6a4 <JNI_OnLoad+0x1468>
    8e7c:      	mov	x24, x0
    8e80:      	mov	x9, xzr
    8e84:      	add	x10, sp, #0x330
    8e88:      	add	x8, x22, x0
    8e8c:      	adrp	x26, 0x15000
    8e90:      	cmp	x9, #0x50
    8e94:      	b.eq	0x8ea4 <.text+0x4580>
    8e98:      	strb	wzr, [x10, x9]
    8e9c:      	add	x9, x9, #0x1
    8ea0:      	b	0x8e90 <.text+0x456c>
    8ea4:      	str	x8, [sp, #0x340]
    8ea8:      	ldr	x8, [x25, #0x1b8]
    8eac:      	ldr	x10, [x25, #0x1a8]
    8eb0:      	sub	x9, x23, x24
    8eb4:      	nop
    8eb8:      	adr	x0, 0xa714 <JNI_OnLoad+0x14d8>
    8ebc:      	add	x1, sp, #0x330
    8ec0:      	str	x25, [sp, #0x338]
    8ec4:      	str	x9, [sp, #0x348]
    8ec8:      	str	x8, [sp, #0x368]
    8ecc:      	str	x10, [sp, #0x370]
    8ed0:      	bl	0x8358 <.text+0x3a34>
    8ed4:      	ldr	x8, [sp, #0x350]
    8ed8:      	cbnz	x8, 0x8eec <.text+0x45c8>
    8edc:      	ldr	x1, [sp, #0x368]
    8ee0:      	add	x0, sp, #0x330
    8ee4:      	bl	0xa7d4 <JNI_OnLoad+0x1598>
    8ee8:      	ldr	x8, [sp, #0x350]
    8eec:      	mov	w9, #0x77ff             // =30719
    8ef0:      	add	x8, x8, x24
    8ef4:      	sub	x9, x9, x19
    8ef8:      	cmp	x8, x9
    8efc:      	b.lo	0x8f18 <.text+0x45f4>
    8f00:      	ldr	x8, [sp, #0xf8]
    8f04:      	mov	w9, #0xa                // =10
    8f08:      	mov	w10, #0x77fe            // =30718
    8f0c:      	add	x8, x8, #0x7fd
    8f10:      	strh	w9, [x8]
    8f14:      	sub	x8, x10, x19
    8f18:      	sub	x1, x23, x8
    8f1c:      	adrp	x2, 0x2000
    8f20:      	add	x2, x2, #0x589
    8f24:      	add	x0, x22, x8
    8f28:      	bl	0xa6a4 <JNI_OnLoad+0x1468>
    8f2c:      	ldr	w0, [x26, #0x6b4]
    8f30:      	ldr	x23, [sp, #0x108]
    8f34:      	tbnz	w0, #0x1f, 0x8f5c <.text+0x4638>
    8f38:      	adrp	x8, 0x17000
    8f3c:      	ldr	x21, [x8, #0x350]
    8f40:      	mov	x1, x21
    8f44:      	bl	0xaa90 <JNI_OnLoad+0x1854>
    8f48:      	cbz	w0, 0x9030 <.text+0x470c>
    8f4c:      	ldr	w0, [x26, #0x6b4]
    8f50:      	bl	0xcde0 <close@plt>
    8f54:      	mov	w8, #-0x1               // =-1
    8f58:      	str	w8, [x26, #0x6b4]
    8f5c:      	adrp	x19, 0x15000
    8f60:      	ldr	w8, [x19, #0x6b0]
    8f64:      	tbnz	w8, #0x1f, 0x8fc8 <.text+0x46a4>
    8f68:      	adrp	x8, 0x17000
    8f6c:      	add	x8, x8, #0x370
    8f70:      	ldr	x9, [x8]
    8f74:      	cbz	x9, 0x8fc8 <.text+0x46a4>
    8f78:      	ldr	x8, [x8, #0x8]
    8f7c:      	cbz	x8, 0x8fc8 <.text+0x46a4>
    8f80:      	mov	w8, #0x1                // =1
    8f84:      	str	x8, [sp, #0x330]
    8f88:      	str	wzr, [x20]
    8f8c:      	add	x1, sp, #0x330
    8f90:      	mov	w2, #0x8                // =8
    8f94:      	ldr	w0, [x19, #0x6b0]
    8f98:      	bl	0xcf20 <write@plt>
    8f9c:      	cmn	x0, #0x1
    8fa0:      	b.ne	0x8fb0 <.text+0x468c>
    8fa4:      	bl	0xca80 <JNI_OnLoad+0x3844>
    8fa8:      	b.eq	0x8f88 <.text+0x4664>
    8fac:      	b	0x8fc8 <.text+0x46a4>
    8fb0:      	cmp	x0, #0x8
    8fb4:      	b.ne	0x8fc8 <.text+0x46a4>
    8fb8:      	adrp	x8, 0x17000
    8fbc:      	mov	x1, xzr
    8fc0:      	ldr	x0, [x8, #0x380]
    8fc4:      	bl	0xcf10 <pthread_join@plt>
    8fc8:      	ldr	w8, [x23]
    8fcc:      	cmp	w8, #0x6
    8fd0:      	b.eq	0x8fe0 <.text+0x46bc>
    8fd4:      	ldr	w8, [x23, #0x8]
    8fd8:      	cmp	w8, #0x0
    8fdc:      	b.gt	0x9008 <.text+0x46e4>
    8fe0:      	bl	0xcdb0 <getpid@plt>
    8fe4:      	mov	w20, w0
    8fe8:      	bl	0xcec0 <gettid@plt>
    8fec:      	ldr	w3, [x23]
    8ff0:      	mov	w2, w0
    8ff4:      	mov	w0, #0xf0               // =240
    8ff8:      	mov	w1, w20
    8ffc:      	mov	x4, x23
    9000:      	bl	0xce10 <syscall@plt>
    9004:      	cbnz	x0, 0x922c <.text+0x4908>
    9008:      	bl	0xccbc <JNI_OnLoad+0x3a80>
    900c:      	ldr	x8, [sp, #0x100]
    9010:      	ldr	x8, [x8, #0x28]
    9014:      	ldur	x9, [x29, #-0x10]
    9018:      	cmp	x8, x9
    901c:      	b.ne	0x9238 <.text+0x4914>
    9020:      	add	sp, sp, #0x740
    9024:      	bl	0xca1c <JNI_OnLoad+0x37e0>
    9028:      	ldp	x29, x30, [sp], #0x60
    902c:      	ret
    9030:      	strb	wzr, [x21]
    9034:      	ldr	w8, [x26, #0x6b4]
    9038:      	tbnz	w8, #0x1f, 0x8f5c <.text+0x4638>
    903c:      	adrp	x8, 0x17000
    9040:      	str	xzr, [sp, #0x330]
    9044:      	mov	w2, #0x6                // =6
    9048:      	ldr	x0, [x8, #0x388]
    904c:      	stp	xzr, xzr, [sp, #0x128]
    9050:      	add	x1, sp, #0x330
    9054:      	movk	w2, #0x1, lsl #16
    9058:      	ldr	x8, [x0]
    905c:      	ldr	x8, [x8, #0x30]
    9060:      	blr	x8
    9064:      	cbnz	w0, 0x8f4c <.text+0x4628>
    9068:      	ldr	x0, [sp, #0x330]
    906c:      	ldr	x8, [x0]
    9070:      	bl	0xc984 <JNI_OnLoad+0x3748>
    9074:      	tst	w0, #0xff
    9078:      	b.eq	0x908c <.text+0x4768>
    907c:      	ldr	x0, [sp, #0x330]
    9080:      	ldr	x8, [x0]
    9084:      	bl	0xcbe8 <JNI_OnLoad+0x39ac>
    9088:      	b	0x8f4c <.text+0x4628>
    908c:      	nop
    9090:      	adr	x9, 0x17320
    9094:      	mov	w10, #0x1               // =1
    9098:      	ldr	w8, [x9, #0x1c]
    909c:      	strb	w10, [x9]
    90a0:      	cmp	w8, #0x15
    90a4:      	b.lt	0x8f4c <.text+0x4628>
    90a8:      	cmp	w8, #0x1d
    90ac:      	b.lo	0x90c4 <.text+0x47a0>
    90b0:      	adrp	x0, 0x2000
    90b4:      	add	x0, x0, #0xd5
    90b8:      	bl	0xacf0 <JNI_OnLoad+0x1ab4>
    90bc:      	str	x0, [sp, #0x130]
    90c0:      	cbnz	x0, 0x90d8 <.text+0x47b4>
    90c4:      	adrp	x0, 0x2000
    90c8:      	add	x0, x0, #0x90f
    90cc:      	bl	0xacf0 <JNI_OnLoad+0x1ab4>
    90d0:      	str	x0, [sp, #0x130]
    90d4:      	cbz	x0, 0x8f4c <.text+0x4628>
    90d8:      	adrp	x1, 0x2000
    90dc:      	add	x1, x1, #0xdc8
    90e0:      	bl	0xb088 <JNI_OnLoad+0x1e4c>
    90e4:      	cbz	x0, 0x9108 <.text+0x47e4>
    90e8:      	adrp	x8, 0x17000
    90ec:      	mov	x22, x0
    90f0:      	ldr	w8, [x8, #0x33c]
    90f4:      	cmp	w8, #0x1d
    90f8:      	b.le	0x9110 <.text+0x47ec>
    90fc:      	adrp	x0, 0x2000
    9100:      	add	x0, x0, #0xf4b
    9104:      	b	0x911c <.text+0x47f8>
    9108:      	mov	x21, xzr
    910c:      	b	0x9214 <.text+0x48f0>
    9110:      	b.ne	0x912c <.text+0x4808>
    9114:      	adrp	x0, 0x1000
    9118:      	add	x0, x0, #0xce6
    911c:      	bl	0xacf0 <JNI_OnLoad+0x1ab4>
    9120:      	mov	x21, x0
    9124:      	str	x0, [sp, #0x128]
    9128:      	cbnz	x0, 0x9144 <.text+0x4820>
    912c:      	adrp	x0, 0x1000
    9130:      	add	x0, x0, #0xdd7
    9134:      	bl	0xacf0 <JNI_OnLoad+0x1ab4>
    9138:      	mov	x21, x0
    913c:      	str	x0, [sp, #0x128]
    9140:      	cbz	x0, 0x9214 <.text+0x48f0>
    9144:      	adrp	x1, 0x1000
    9148:      	add	x1, x1, #0xd10
    914c:      	bl	0xcce4 <JNI_OnLoad+0x3aa8>
    9150:      	cbz	x0, 0x9214 <.text+0x48f0>
    9154:      	mov	x25, x0
    9158:      	adrp	x1, 0x2000
    915c:      	add	x1, x1, #0xe6e
    9160:      	bl	0xcce4 <JNI_OnLoad+0x3aa8>
    9164:      	mov	x23, x0
    9168:      	cbz	x0, 0x9174 <.text+0x4850>
    916c:      	mov	x24, xzr
    9170:      	b	0x9188 <.text+0x4864>
    9174:      	adrp	x1, 0x2000
    9178:      	add	x1, x1, #0x405
    917c:      	bl	0xcce4 <JNI_OnLoad+0x3aa8>
    9180:      	mov	x24, x0
    9184:      	cbz	x0, 0x9210 <.text+0x48ec>
    9188:      	blr	x25
    918c:      	cbz	x0, 0x9210 <.text+0x48ec>
    9190:      	mov	x25, x0
    9194:      	ldr	w0, [x26, #0x6b4]
    9198:      	adrp	x8, 0x17000
    919c:      	adrp	x1, 0x2000
    91a0:      	add	x1, x1, #0x29f
    91a4:      	strb	wzr, [x8, #0x320]
    91a8:      	bl	0xaa90 <JNI_OnLoad+0x1854>
    91ac:      	cbnz	w0, 0x9210 <.text+0x48ec>
    91b0:      	ldr	w0, [x26, #0x6b4]
    91b4:      	mov	w1, #0x2                // =2
    91b8:      	bl	0xcf00 <dup2@plt>
    91bc:      	tbnz	w0, #0x1f, 0x9210 <.text+0x48ec>
    91c0:      	cbz	x23, 0x91d4 <.text+0x48b0>
    91c4:      	mov	x0, x25
    91c8:      	mov	x1, x22
    91cc:      	blr	x23
    91d0:      	b	0x91ec <.text+0x48c8>
    91d4:      	cbz	x24, 0x91ec <.text+0x48c8>
    91d8:      	mov	x0, x25
    91dc:      	mov	x1, x22
    91e0:      	mov	w2, wzr
    91e4:      	mov	w3, wzr
    91e8:      	blr	x24
    91ec:      	adrp	x19, 0x15000
    91f0:      	add	x19, x19, #0x6b4
    91f4:      	mov	w1, #0x2                // =2
    91f8:      	ldr	w0, [x19, #0x4]
    91fc:      	bl	0xcf00 <dup2@plt>
    9200:      	ldr	w0, [x19]
    9204:      	adrp	x1, 0x2000
    9208:      	add	x1, x1, #0x589
    920c:      	bl	0xaa90 <JNI_OnLoad+0x1854>
    9210:      	ldr	x23, [sp, #0x108]
    9214:      	add	x0, sp, #0x130
    9218:      	bl	0xaff4 <JNI_OnLoad+0x1db8>
    921c:      	cbz	x21, 0x8f4c <.text+0x4628>
    9220:      	add	x0, sp, #0x128
    9224:      	bl	0xaff4 <JNI_OnLoad+0x1db8>
    9228:      	b	0x8f4c <.text+0x4628>
    922c:      	bl	0xccbc <JNI_OnLoad+0x3a80>
    9230:      	mov	w0, #0x1                // =1
    9234:      	bl	0xcef0 <_exit@plt>
    9238:      	bl	0xd110 <__stack_chk_fail@plt>

000000000000923c <JNI_OnLoad>:
    923c:      	sub	sp, sp, #0x50
    9240:      	stp	x29, x30, [sp, #0x10]
    9244:      	stp	x24, x23, [sp, #0x20]
    9248:      	stp	x22, x21, [sp, #0x30]
    924c:      	stp	x20, x19, [sp, #0x40]
    9250:      	add	x29, sp, #0x10
    9254:      	mrs	x23, TPIDR_EL0
    9258:      	ldr	x8, [x23, #0x28]
    925c:      	str	x8, [sp, #0x8]
    9260:      	cbz	x0, 0x928c <JNI_OnLoad+0x50>
    9264:      	ldr	x8, [x0]
    9268:      	mov	w2, #0x6                // =6
    926c:      	mov	w19, #0x6               // =6
    9270:      	mov	x1, sp
    9274:      	movk	w2, #0x1, lsl #16
    9278:      	mov	x20, x0
    927c:      	ldr	x8, [x8, #0x30]
    9280:      	movk	w19, #0x1, lsl #16
    9284:      	blr	x8
    9288:      	cbz	w0, 0x92bc <JNI_OnLoad+0x80>
    928c:      	mov	w19, #-0x1              // =-1
    9290:      	ldr	x8, [x23, #0x28]
    9294:      	ldr	x9, [sp, #0x8]
    9298:      	cmp	x8, x9
    929c:      	b.ne	0x9368 <JNI_OnLoad+0x12c>
    92a0:      	mov	w0, w19
    92a4:      	ldp	x20, x19, [sp, #0x40]
    92a8:      	ldp	x22, x21, [sp, #0x30]
    92ac:      	ldp	x24, x23, [sp, #0x20]
    92b0:      	ldp	x29, x30, [sp, #0x10]
    92b4:      	add	sp, sp, #0x50
    92b8:      	ret
    92bc:      	ldr	x0, [sp]
    92c0:      	cbz	x0, 0x928c <JNI_OnLoad+0x50>
    92c4:      	ldr	x8, [x0]
    92c8:      	cbz	x8, 0x928c <JNI_OnLoad+0x50>
    92cc:      	ldr	x8, [x8, #0x30]
    92d0:      	adrp	x1, 0x2000
    92d4:      	add	x1, x1, #0x508
    92d8:      	blr	x8
    92dc:      	cbz	x0, 0x928c <JNI_OnLoad+0x50>
    92e0:      	mov	x22, x0
    92e4:      	ldr	x0, [sp]
    92e8:      	nop
    92ec:      	adr	x2, 0x15600
    92f0:      	mov	x1, x22
    92f4:      	mov	w3, #0x7                // =7
    92f8:      	ldr	x8, [x0]
    92fc:      	ldr	x8, [x8, #0x6b8]
    9300:      	blr	x8
    9304:      	cbnz	w0, 0x928c <JNI_OnLoad+0x50>
    9308:      	ldr	x21, [sp]
    930c:      	adrp	x24, 0x17000
    9310:      	add	x24, x24, #0x370
    9314:      	str	x20, [x24, #0x18]
    9318:      	mov	x1, x22
    931c:      	ldr	x8, [x21]
    9320:      	mov	x0, x21
    9324:      	ldr	x8, [x8, #0xa8]
    9328:      	blr	x8
    932c:      	str	x0, [x24]
    9330:      	mov	x0, x21
    9334:      	ldr	x8, [x21]
    9338:      	bl	0xc984 <JNI_OnLoad+0x3748>
    933c:      	tst	w0, #0xff
    9340:      	adrp	x20, 0x17000
    9344:      	b.eq	0x935c <JNI_OnLoad+0x120>
    9348:      	ldr	x8, [x21]
    934c:      	mov	x0, x21
    9350:      	bl	0xcbe8 <JNI_OnLoad+0x39ac>
    9354:      	str	xzr, [x20, #0x370]
    9358:      	b	0x9290 <JNI_OnLoad+0x54>
    935c:      	ldr	x8, [x20, #0x370]
    9360:      	cbnz	x8, 0x9290 <JNI_OnLoad+0x54>
    9364:      	b	0x9354 <JNI_OnLoad+0x118>
    9368:      	bl	0xd110 <__stack_chk_fail@plt>
    936c:      	stp	x29, x30, [sp, #-0x60]!
    9370:      	bl	0xc9f0 <JNI_OnLoad+0x37b4>
    9374:      	sub	sp, sp, #0x1, lsl #12   // =0x1000
    9378:      	sub	sp, sp, #0x1f0
    937c:      	mrs	x21, TPIDR_EL0
    9380:      	ldr	x8, [x21, #0x28]
    9384:      	stur	x8, [x29, #-0x18]
    9388:      	adrp	x8, 0x17000
    938c:      	ldrb	w9, [x8, #0x32c]
    9390:      	tbz	w9, #0x0, 0x939c <JNI_OnLoad+0x160>
    9394:      	mov	w24, #0x3f7             // =1015
    9398:      	b	0x9680 <JNI_OnLoad+0x444>
    939c:      	mov	x19, x0
    93a0:      	mov	w9, #0x1                // =1
    93a4:      	strb	w9, [x8, #0x32c]
    93a8:      	cbz	x0, 0x954c <JNI_OnLoad+0x310>
    93ac:      	ldr	x8, [x29, #0x80]
    93b0:      	mov	w24, #0x3ea             // =1002
    93b4:      	cbz	x8, 0x9680 <JNI_OnLoad+0x444>
    93b8:      	ldr	x9, [x29, #0x78]
    93bc:      	cbz	x9, 0x9680 <JNI_OnLoad+0x444>
    93c0:      	ldr	x10, [x29, #0x70]
    93c4:      	cbz	x10, 0x9680 <JNI_OnLoad+0x444>
    93c8:      	ldr	x11, [x29, #0x68]
    93cc:      	cbz	x11, 0x9680 <JNI_OnLoad+0x444>
    93d0:      	ldr	x12, [x29, #0x60]
    93d4:      	str	x12, [sp, #0x80]
    93d8:      	cbz	x12, 0x9680 <JNI_OnLoad+0x444>
    93dc:      	mov	x23, x7
    93e0:      	cbz	x7, 0x9680 <JNI_OnLoad+0x444>
    93e4:      	mov	x25, x6
    93e8:      	cbz	x6, 0x9680 <JNI_OnLoad+0x444>
    93ec:      	mov	x27, x5
    93f0:      	cbz	x5, 0x9680 <JNI_OnLoad+0x444>
    93f4:      	mov	x28, x4
    93f8:      	cbz	x4, 0x9680 <JNI_OnLoad+0x444>
    93fc:      	mov	x26, x3
    9400:      	cbz	x3, 0x9680 <JNI_OnLoad+0x444>
    9404:      	ldrb	w20, [x29, #0x88]
    9408:      	tst	w20, #0xff
    940c:      	b.eq	0x9680 <JNI_OnLoad+0x444>
    9410:      	mov	w22, w2
    9414:      	tbnz	w2, #0x1f, 0x9680 <JNI_OnLoad+0x444>
    9418:      	stp	x8, x9, [sp, #0x60]
    941c:      	ldr	x8, [x19]
    9420:      	stp	x10, x11, [sp, #0x70]
    9424:      	cbz	x8, 0x9680 <JNI_OnLoad+0x444>
    9428:      	ldr	x8, [x8, #0x548]
    942c:      	mov	x0, x19
    9430:      	mov	x1, x26
    9434:      	mov	x2, xzr
    9438:      	blr	x8
    943c:      	cbz	x0, 0x9394 <JNI_OnLoad+0x158>
    9440:      	ldr	x8, [x19]
    9444:      	mov	x24, x0
    9448:      	mov	x0, x19
    944c:      	mov	x1, x28
    9450:      	mov	x2, xzr
    9454:      	bl	0xca0c <JNI_OnLoad+0x37d0>
    9458:      	str	x0, [sp, #0x58]
    945c:      	cbz	x0, 0x9554 <JNI_OnLoad+0x318>
    9460:      	bl	0xcbb8 <JNI_OnLoad+0x397c>
    9464:      	mov	x2, xzr
    9468:      	bl	0xca0c <JNI_OnLoad+0x37d0>
    946c:      	str	x0, [sp, #0x18]
    9470:      	cbz	x0, 0x9554 <JNI_OnLoad+0x318>
    9474:      	ldr	x8, [x19]
    9478:      	mov	x0, x19
    947c:      	mov	x1, x25
    9480:      	mov	x2, xzr
    9484:      	bl	0xca0c <JNI_OnLoad+0x37d0>
    9488:      	cbz	x0, 0x9574 <JNI_OnLoad+0x338>
    948c:      	ldr	x8, [x19]
    9490:      	str	x0, [sp, #0x50]
    9494:      	bl	0xcc44 <JNI_OnLoad+0x3a08>
    9498:      	mov	x2, xzr
    949c:      	bl	0xca0c <JNI_OnLoad+0x37d0>
    94a0:      	cbz	x0, 0x9580 <JNI_OnLoad+0x344>
    94a4:      	ldr	x8, [x19]
    94a8:      	ldr	x1, [sp, #0x80]
    94ac:      	mov	x2, xzr
    94b0:      	str	x0, [sp, #0x48]
    94b4:      	mov	x0, x19
    94b8:      	bl	0xca0c <JNI_OnLoad+0x37d0>
    94bc:      	cbz	x0, 0x96a8 <JNI_OnLoad+0x46c>
    94c0:      	ldr	x8, [x19]
    94c4:      	ldr	x1, [sp, #0x78]
    94c8:      	mov	x2, xzr
    94cc:      	str	x0, [sp, #0x38]
    94d0:      	mov	x0, x19
    94d4:      	bl	0xca0c <JNI_OnLoad+0x37d0>
    94d8:      	cbz	x0, 0x96b0 <JNI_OnLoad+0x474>
    94dc:      	ldr	x8, [x19]
    94e0:      	ldr	x1, [sp, #0x70]
    94e4:      	mov	x2, xzr
    94e8:      	str	x0, [sp, #0x40]
    94ec:      	mov	x0, x19
    94f0:      	bl	0xca0c <JNI_OnLoad+0x37d0>
    94f4:      	cbz	x0, 0x96b8 <JNI_OnLoad+0x47c>
    94f8:      	ldr	x8, [x19]
    94fc:      	ldr	x1, [sp, #0x68]
    9500:      	mov	x2, xzr
    9504:      	str	x0, [sp, #0x30]
    9508:      	mov	x0, x19
    950c:      	bl	0xca0c <JNI_OnLoad+0x37d0>
    9510:      	cbz	x0, 0x96c0 <JNI_OnLoad+0x484>
    9514:      	ldr	x8, [x19]
    9518:      	ldr	x1, [sp, #0x60]
    951c:      	mov	x2, xzr
    9520:      	str	x0, [sp, #0x28]
    9524:      	mov	x0, x19
    9528:      	bl	0xca0c <JNI_OnLoad+0x37d0>
    952c:      	cbz	x0, 0x96c8 <JNI_OnLoad+0x48c>
    9530:      	str	x0, [sp, #0x20]
    9534:      	add	x0, sp, #0xc0
    9538:      	mov	x1, xzr
    953c:      	bl	0xcd70 <gettimeofday@plt>
    9540:      	cbz	w0, 0x96d0 <JNI_OnLoad+0x494>
    9544:      	mov	x22, x24
    9548:      	b	0x959c <JNI_OnLoad+0x360>
    954c:      	mov	w24, #0x3ea             // =1002
    9550:      	b	0x9680 <JNI_OnLoad+0x444>
    9554:      	mov	x22, x24
    9558:      	mov	x20, xzr
    955c:      	stp	xzr, xzr, [sp, #0x48]
    9560:      	stp	xzr, xzr, [sp, #0x38]
    9564:      	mov	w24, #0x3f7             // =1015
    9568:      	stp	xzr, xzr, [sp, #0x28]
    956c:      	str	xzr, [sp, #0x20]
    9570:      	b	0x95a4 <JNI_OnLoad+0x368>
    9574:      	mov	x22, x24
    9578:      	str	xzr, [sp, #0x50]
    957c:      	b	0x9584 <JNI_OnLoad+0x348>
    9580:      	mov	x22, x24
    9584:      	str	xzr, [sp, #0x48]
    9588:      	str	xzr, [sp, #0x38]
    958c:      	str	xzr, [sp, #0x40]
    9590:      	str	xzr, [sp, #0x30]
    9594:      	str	xzr, [sp, #0x28]
    9598:      	str	xzr, [sp, #0x20]
    959c:      	mov	w24, #0x3f7             // =1015
    95a0:      	ldr	x20, [sp, #0x18]
    95a4:      	ldr	x8, [x19]
    95a8:      	mov	x0, x19
    95ac:      	mov	x1, x26
    95b0:      	mov	x2, x22
    95b4:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    95b8:      	ldr	x2, [sp, #0x58]
    95bc:      	cbz	x2, 0x95cc <JNI_OnLoad+0x390>
    95c0:      	bl	0xcc68 <JNI_OnLoad+0x3a2c>
    95c4:      	mov	x1, x28
    95c8:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    95cc:      	cbz	x20, 0x95dc <JNI_OnLoad+0x3a0>
    95d0:      	bl	0xcbb8 <JNI_OnLoad+0x397c>
    95d4:      	mov	x2, x20
    95d8:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    95dc:      	ldr	x2, [sp, #0x50]
    95e0:      	cbz	x2, 0x95f4 <JNI_OnLoad+0x3b8>
    95e4:      	ldr	x8, [x19]
    95e8:      	mov	x0, x19
    95ec:      	mov	x1, x25
    95f0:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    95f4:      	ldr	x2, [sp, #0x48]
    95f8:      	cbz	x2, 0x9608 <JNI_OnLoad+0x3cc>
    95fc:      	ldr	x8, [x19]
    9600:      	bl	0xcc44 <JNI_OnLoad+0x3a08>
    9604:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    9608:      	ldr	x2, [sp, #0x38]
    960c:      	cbz	x2, 0x9620 <JNI_OnLoad+0x3e4>
    9610:      	ldr	x8, [x19]
    9614:      	ldr	x1, [sp, #0x80]
    9618:      	mov	x0, x19
    961c:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    9620:      	ldr	x2, [sp, #0x40]
    9624:      	cbz	x2, 0x9638 <JNI_OnLoad+0x3fc>
    9628:      	ldr	x8, [x19]
    962c:      	ldr	x1, [sp, #0x78]
    9630:      	mov	x0, x19
    9634:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    9638:      	ldr	x2, [sp, #0x30]
    963c:      	cbz	x2, 0x9650 <JNI_OnLoad+0x414>
    9640:      	ldr	x8, [x19]
    9644:      	ldr	x1, [sp, #0x70]
    9648:      	mov	x0, x19
    964c:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    9650:      	ldr	x2, [sp, #0x28]
    9654:      	cbz	x2, 0x9668 <JNI_OnLoad+0x42c>
    9658:      	ldr	x8, [x19]
    965c:      	ldr	x1, [sp, #0x68]
    9660:      	mov	x0, x19
    9664:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    9668:      	ldr	x2, [sp, #0x20]
    966c:      	cbz	x2, 0x9680 <JNI_OnLoad+0x444>
    9670:      	ldr	x8, [x19]
    9674:      	ldr	x1, [sp, #0x60]
    9678:      	mov	x0, x19
    967c:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    9680:      	ldr	x8, [x21, #0x28]
    9684:      	ldur	x9, [x29, #-0x18]
    9688:      	cmp	x8, x9
    968c:      	b.ne	0x9d68 <JNI_OnLoad+0xb2c>
    9690:      	mov	w0, w24
    9694:      	add	sp, sp, #0x1, lsl #12   // =0x1000
    9698:      	add	sp, sp, #0x1f0
    969c:      	bl	0xca1c <JNI_OnLoad+0x37e0>
    96a0:      	ldp	x29, x30, [sp], #0x60
    96a4:      	ret
    96a8:      	mov	x22, x24
    96ac:      	b	0x9588 <JNI_OnLoad+0x34c>
    96b0:      	mov	x22, x24
    96b4:      	b	0x958c <JNI_OnLoad+0x350>
    96b8:      	mov	x22, x24
    96bc:      	b	0x9590 <JNI_OnLoad+0x354>
    96c0:      	mov	x22, x24
    96c4:      	b	0x9594 <JNI_OnLoad+0x358>
    96c8:      	mov	x22, x24
    96cc:      	b	0x9598 <JNI_OnLoad+0x35c>
    96d0:      	ldp	x8, x10, [sp, #0xc0]
    96d4:      	mov	w9, #0x4240             // =16960
    96d8:      	movk	w9, #0xf, lsl #16
    96dc:      	add	x0, sp, #0xc0
    96e0:      	add	x1, sp, #0x88
    96e4:      	madd	x8, x8, x9, x10
    96e8:      	adrp	x9, 0x17000
    96ec:      	str	x8, [x9, #0x3a0]
    96f0:      	bl	0xcd90 <localtime_r@plt>
    96f4:      	cbz	x0, 0x9544 <JNI_OnLoad+0x308>
    96f8:      	ldr	x8, [sp, #0xb0]
    96fc:      	adrp	x9, 0x17000
    9700:      	add	x9, x9, #0x33c
    9704:      	str	w22, [x9]
    9708:      	adrp	x10, 0x17000
    970c:      	adrp	x22, 0x17000
    9710:      	stur	x8, [x9, #0x5c]
    9714:      	ldrb	w8, [x24]
    9718:      	cbz	w8, 0x9734 <JNI_OnLoad+0x4f8>
    971c:      	mov	x0, x24
    9720:      	bl	0xcda0 <strdup@plt>
    9724:      	adrp	x8, 0x17000
    9728:      	str	x0, [x8, #0x3b8]
    972c:      	cbnz	x0, 0x9740 <JNI_OnLoad+0x504>
    9730:      	b	0x9db4 <JNI_OnLoad+0xb78>
    9734:      	adrp	x8, 0x1000
    9738:      	add	x8, x8, #0xeeb
    973c:      	str	x8, [x10, #0x3b8]
    9740:      	ldr	x0, [sp, #0x58]
    9744:      	ldrb	w8, [x0]
    9748:      	cbz	w8, 0x9760 <JNI_OnLoad+0x524>
    974c:      	bl	0xcda0 <strdup@plt>
    9750:      	adrp	x8, 0x17000
    9754:      	str	x0, [x8, #0x3c8]
    9758:      	cbnz	x0, 0x976c <JNI_OnLoad+0x530>
    975c:      	b	0x9d9c <JNI_OnLoad+0xb60>
    9760:      	adrp	x8, 0x17000
    9764:      	bl	0xca44 <JNI_OnLoad+0x3808>
    9768:      	str	x9, [x8, #0x3c8]
    976c:      	ldr	x0, [sp, #0x18]
    9770:      	ldrb	w8, [x0]
    9774:      	cbz	w8, 0x978c <JNI_OnLoad+0x550>
    9778:      	bl	0xcda0 <strdup@plt>
    977c:      	adrp	x8, 0x17000
    9780:      	str	x0, [x8, #0x3d0]
    9784:      	cbnz	x0, 0x9798 <JNI_OnLoad+0x55c>
    9788:      	b	0x9d9c <JNI_OnLoad+0xb60>
    978c:      	adrp	x8, 0x17000
    9790:      	bl	0xca44 <JNI_OnLoad+0x3808>
    9794:      	str	x9, [x8, #0x3d0]
    9798:      	ldr	x0, [sp, #0x50]
    979c:      	ldrb	w8, [x0]
    97a0:      	cbz	w8, 0x97b8 <JNI_OnLoad+0x57c>
    97a4:      	bl	0xcda0 <strdup@plt>
    97a8:      	adrp	x8, 0x17000
    97ac:      	str	x0, [x8, #0x3d8]
    97b0:      	cbnz	x0, 0x97c4 <JNI_OnLoad+0x588>
    97b4:      	b	0x9d9c <JNI_OnLoad+0xb60>
    97b8:      	adrp	x8, 0x17000
    97bc:      	bl	0xca44 <JNI_OnLoad+0x3808>
    97c0:      	str	x9, [x8, #0x3d8]
    97c4:      	ldr	x0, [sp, #0x48]
    97c8:      	ldrb	w8, [x0]
    97cc:      	cbz	w8, 0x97e4 <JNI_OnLoad+0x5a8>
    97d0:      	bl	0xcda0 <strdup@plt>
    97d4:      	adrp	x8, 0x17000
    97d8:      	str	x0, [x8, #0x3e0]
    97dc:      	cbnz	x0, 0x97f0 <JNI_OnLoad+0x5b4>
    97e0:      	b	0x9d9c <JNI_OnLoad+0xb60>
    97e4:      	adrp	x8, 0x17000
    97e8:      	bl	0xca44 <JNI_OnLoad+0x3808>
    97ec:      	str	x9, [x8, #0x3e0]
    97f0:      	ldr	x0, [sp, #0x38]
    97f4:      	ldrb	w8, [x0]
    97f8:      	cbz	w8, 0x9810 <JNI_OnLoad+0x5d4>
    97fc:      	bl	0xcda0 <strdup@plt>
    9800:      	adrp	x8, 0x17000
    9804:      	str	x0, [x8, #0x3e8]
    9808:      	cbnz	x0, 0x981c <JNI_OnLoad+0x5e0>
    980c:      	b	0x9d9c <JNI_OnLoad+0xb60>
    9810:      	adrp	x8, 0x17000
    9814:      	bl	0xca44 <JNI_OnLoad+0x3808>
    9818:      	str	x9, [x8, #0x3e8]
    981c:      	ldr	x8, [sp, #0x40]
    9820:      	ldrb	w8, [x8]
    9824:      	cbz	w8, 0x9840 <JNI_OnLoad+0x604>
    9828:      	ldr	x0, [sp, #0x40]
    982c:      	bl	0xcda0 <strdup@plt>
    9830:      	adrp	x8, 0x17000
    9834:      	str	x0, [x8, #0x3a8]
    9838:      	cbnz	x0, 0x984c <JNI_OnLoad+0x610>
    983c:      	b	0x9d9c <JNI_OnLoad+0xb60>
    9840:      	adrp	x8, 0x17000
    9844:      	bl	0xca44 <JNI_OnLoad+0x3808>
    9848:      	str	x9, [x8, #0x3a8]
    984c:      	ldr	x8, [sp, #0x30]
    9850:      	mov	x22, x24
    9854:      	ldrb	w8, [x8]
    9858:      	cbz	w8, 0x9878 <JNI_OnLoad+0x63c>
    985c:      	ldr	x0, [sp, #0x30]
    9860:      	bl	0xcda0 <strdup@plt>
    9864:      	adrp	x8, 0x17000
    9868:      	mov	x24, x22
    986c:      	str	x0, [x8, #0x3b0]
    9870:      	cbnz	x0, 0x9884 <JNI_OnLoad+0x648>
    9874:      	b	0x9d9c <JNI_OnLoad+0xb60>
    9878:      	adrp	x8, 0x17000
    987c:      	bl	0xca44 <JNI_OnLoad+0x3808>
    9880:      	str	x9, [x8, #0x3b0]
    9884:      	ldr	x8, [sp, #0x28]
    9888:      	ldrb	w8, [x8]
    988c:      	cbz	w8, 0x98ac <JNI_OnLoad+0x670>
    9890:      	ldr	x0, [sp, #0x28]
    9894:      	bl	0xcda0 <strdup@plt>
    9898:      	adrp	x8, 0x17000
    989c:      	mov	x24, x22
    98a0:      	str	x0, [x8, #0x358]
    98a4:      	cbnz	x0, 0x98b8 <JNI_OnLoad+0x67c>
    98a8:      	b	0x9d9c <JNI_OnLoad+0xb60>
    98ac:      	adrp	x8, 0x17000
    98b0:      	bl	0xca44 <JNI_OnLoad+0x3808>
    98b4:      	str	x9, [x8, #0x358]
    98b8:      	ldr	x8, [sp, #0x20]
    98bc:      	ldrb	w8, [x8]
    98c0:      	cbz	w8, 0x98e0 <JNI_OnLoad+0x6a4>
    98c4:      	ldr	x0, [sp, #0x20]
    98c8:      	bl	0xcda0 <strdup@plt>
    98cc:      	adrp	x8, 0x17000
    98d0:      	mov	x24, x22
    98d4:      	str	x0, [x8, #0x340]
    98d8:      	cbnz	x0, 0x98ec <JNI_OnLoad+0x6b0>
    98dc:      	b	0x9d9c <JNI_OnLoad+0xb60>
    98e0:      	adrp	x8, 0x17000
    98e4:      	bl	0xca44 <JNI_OnLoad+0x3808>
    98e8:      	str	x9, [x8, #0x340]
    98ec:      	add	x0, sp, #0x1d0
    98f0:      	add	x24, sp, #0x1d0
    98f4:      	bl	0xcf50 <uname@plt>
    98f8:      	cbz	w0, 0x9908 <JNI_OnLoad+0x6cc>
    98fc:      	bl	0xca8c <JNI_OnLoad+0x3850>
    9900:      	strb	wzr, [sp, #0x1cf]
    9904:      	b	0x9920 <JNI_OnLoad+0x6e4>
    9908:      	add	x0, sp, #0xd0
    990c:      	add	x4, sp, #0x1d0
    9910:      	add	x5, x24, #0x82
    9914:      	add	x6, x24, #0xc3
    9918:      	add	x7, x24, #0x104
    991c:      	bl	0x9edc <JNI_OnLoad+0xca0>
    9920:      	bl	0xcc30 <JNI_OnLoad+0x39f4>
    9924:      	cbz	x0, 0x9944 <JNI_OnLoad+0x708>
    9928:      	add	x0, sp, #0xd0
    992c:      	bl	0xcda0 <strdup@plt>
    9930:      	adrp	x8, 0x17000
    9934:      	mov	x24, x22
    9938:      	str	x0, [x8, #0x3c0]
    993c:      	cbnz	x0, 0x9950 <JNI_OnLoad+0x714>
    9940:      	b	0x9d9c <JNI_OnLoad+0xb60>
    9944:      	adrp	x8, 0x17000
    9948:      	bl	0xca44 <JNI_OnLoad+0x3808>
    994c:      	str	x9, [x8, #0x3c0]
    9950:      	bl	0xcdb0 <getpid@plt>
    9954:      	adrp	x8, 0x17000
    9958:      	mov	w3, w0
    995c:      	adrp	x2, 0x2000
    9960:      	add	x2, x2, #0xebe
    9964:      	str	w0, [x8, #0x334]
    9968:      	add	x0, sp, #0x1d0
    996c:      	mov	w1, #0x80               // =128
    9970:      	bl	0xa6a4 <JNI_OnLoad+0x1468>
    9974:      	add	x0, sp, #0x1d0
    9978:      	add	x1, sp, #0xd0
    997c:      	mov	w2, #0x100              // =256
    9980:      	bl	0xab80 <JNI_OnLoad+0x1944>
    9984:      	cbz	w0, 0x998c <JNI_OnLoad+0x750>
    9988:      	bl	0xca8c <JNI_OnLoad+0x3850>
    998c:      	bl	0xcc30 <JNI_OnLoad+0x39f4>
    9990:      	cbz	x0, 0x99b0 <JNI_OnLoad+0x774>
    9994:      	add	x0, sp, #0xd0
    9998:      	bl	0xcda0 <strdup@plt>
    999c:      	adrp	x8, 0x17000
    99a0:      	mov	x24, x22
    99a4:      	str	x0, [x8, #0x348]
    99a8:      	cbnz	x0, 0x99bc <JNI_OnLoad+0x780>
    99ac:      	b	0x9d9c <JNI_OnLoad+0xb60>
    99b0:      	adrp	x8, 0x17000
    99b4:      	bl	0xca44 <JNI_OnLoad+0x3808>
    99b8:      	str	x9, [x8, #0x348]
    99bc:      	ldrb	w8, [x29, #0x90]
    99c0:      	str	w8, [sp, #0xc]
    99c4:      	bl	0xcd80 <__errno@plt>
    99c8:      	mov	x24, x0
    99cc:      	adrp	x0, 0x2000
    99d0:      	add	x0, x0, #0xf41
    99d4:      	mov	w1, #0x2                // =2
    99d8:      	str	wzr, [x24]
    99dc:      	bl	0xce00 <__open_2@plt>
    99e0:      	cmn	w0, #0x1
    99e4:      	adrp	x8, 0x15000
    99e8:      	b.ne	0x9a08 <JNI_OnLoad+0x7cc>
    99ec:      	ldr	w9, [x24]
    99f0:      	cmp	w9, #0x4
    99f4:      	b.eq	0x99cc <JNI_OnLoad+0x790>
    99f8:      	mov	w9, #-0x1               // =-1
    99fc:      	str	w9, [x8, #0x6b8]
    9a00:      	mov	x24, x22
    9a04:      	b	0x9d9c <JNI_OnLoad+0xb60>
    9a08:      	str	x24, [sp, #0x10]
    9a0c:      	mov	x24, x22
    9a10:      	str	w0, [x8, #0x6b8]
    9a14:      	tbnz	w0, #0x1f, 0x9d9c <JNI_OnLoad+0xb60>
    9a18:      	ldr	x8, [sp, #0x10]
    9a1c:      	ldr	x0, [sp, #0x20]
    9a20:      	mov	w1, #0x1c0              // =448
    9a24:      	bl	0xcc04 <JNI_OnLoad+0x39c8>
    9a28:      	cbz	w0, 0x9a34 <JNI_OnLoad+0x7f8>
    9a2c:      	bl	0xcb68 <JNI_OnLoad+0x392c>
    9a30:      	b.ne	0x9cbc <JNI_OnLoad+0xa80>
    9a34:      	mov	w0, #0x1                // =1
    9a38:      	and	w20, w20, #0xff
    9a3c:      	bl	0x853c <.text+0x3c18>
    9a40:      	mov	w0, wzr
    9a44:      	bl	0x853c <.text+0x3c18>
    9a48:      	cbz	w20, 0x9d60 <JNI_OnLoad+0xb24>
    9a4c:      	ldr	w8, [sp, #0xc]
    9a50:      	ldr	x20, [sp, #0x10]
    9a54:      	adrp	x24, 0x2000
    9a58:      	add	x24, x24, #0xf41
    9a5c:      	tst	w8, #0xff
    9a60:      	cset	w8, ne
    9a64:      	str	w8, [sp, #0xc]
    9a68:      	mov	x0, x24
    9a6c:      	mov	w1, #0x2                // =2
    9a70:      	bl	0xccd4 <JNI_OnLoad+0x3a98>
    9a74:      	cmn	w0, #0x1
    9a78:      	b.ne	0x9a84 <JNI_OnLoad+0x848>
    9a7c:      	bl	0xca80 <JNI_OnLoad+0x3844>
    9a80:      	b.eq	0x9a68 <JNI_OnLoad+0x82c>
    9a84:      	ldr	w8, [sp, #0xc]
    9a88:      	adrp	x24, 0x17000
    9a8c:      	add	x24, x24, #0x330
    9a90:      	mov	w0, #0x7800             // =30720
    9a94:      	mov	w1, #0x1                // =1
    9a98:      	str	w8, [x24]
    9a9c:      	bl	0xce70 <calloc@plt>
    9aa0:      	str	x0, [x24, #0x20]
    9aa4:      	cbz	x0, 0x959c <JNI_OnLoad+0x360>
    9aa8:      	adrp	x8, 0x17000
    9aac:      	ldr	x24, [x8, #0x358]
    9ab0:      	cbz	x24, 0x9d6c <JNI_OnLoad+0xb30>
    9ab4:      	mov	x0, x24
    9ab8:      	bl	0xce60 <strlen@plt>
    9abc:      	str	x0, [sp, #0x10]
    9ac0:      	add	x0, x0, #0x18
    9ac4:      	bl	0xcf30 <malloc@plt>
    9ac8:      	cbz	x0, 0x9d6c <JNI_OnLoad+0xb30>
    9acc:      	mov	x1, x24
    9ad0:      	ldr	x24, [sp, #0x10]
    9ad4:      	mov	x20, x0
    9ad8:      	mov	x2, x24
    9adc:      	bl	0xd0b0 <memcpy@plt>
    9ae0:      	adrp	x9, 0x1000
    9ae4:      	add	x9, x9, #0xb3e
    9ae8:      	adrp	x10, 0x17000
    9aec:      	add	x10, x10, #0x360
    9af0:      	ldr	q0, [x9]
    9af4:      	ldr	x9, [x9, #0x10]
    9af8:      	ldr	x1, [x10, #0x10]
    9afc:      	add	x8, x20, x24
    9b00:      	str	x20, [x10]
    9b04:      	str	q0, [x8]
    9b08:      	str	x9, [x8, #0x10]
    9b0c:      	cbz	x1, 0x9b70 <JNI_OnLoad+0x934>
    9b10:      	ldr	x8, [x19]
    9b14:      	adrp	x2, 0x1000
    9b18:      	add	x2, x2, #0xae0
    9b1c:      	adrp	x3, 0x2000
    9b20:      	add	x3, x3, #0x3c9
    9b24:      	mov	x0, x19
    9b28:      	ldr	x8, [x8, #0x388]
    9b2c:      	blr	x8
    9b30:      	adrp	x20, 0x17000
    9b34:      	str	x0, [x20, #0x378]
    9b38:      	mov	x0, x19
    9b3c:      	ldr	x8, [x19]
    9b40:      	bl	0xc984 <JNI_OnLoad+0x3748>
    9b44:      	tst	w0, #0xff
    9b48:      	adrp	x24, 0x15000
    9b4c:      	b.eq	0x9e90 <JNI_OnLoad+0xc54>
    9b50:      	bl	0xcc68 <JNI_OnLoad+0x3a2c>
    9b54:      	bl	0xcbe8 <JNI_OnLoad+0x39ac>
    9b58:      	ldr	w0, [x24, #0x6b0]
    9b5c:      	str	xzr, [x20, #0x378]
    9b60:      	tbnz	w0, #0x1f, 0x9b70 <JNI_OnLoad+0x934>
    9b64:      	bl	0xcde0 <close@plt>
    9b68:      	mov	w8, #-0x1               // =-1
    9b6c:      	str	w8, [x24, #0x6b0]
    9b70:      	adrp	x20, 0x17000
    9b74:      	add	x20, x20, #0x334
    9b78:      	adrp	x24, 0x17000
    9b7c:      	add	x24, x24, #0x2a8
    9b80:      	ldr	w8, [x20, #0x8]
    9b84:      	ldr	w9, [x20]
    9b88:      	ldur	x10, [x20, #0x6c]
    9b8c:      	ldur	x0, [x20, #0x84]
    9b90:      	stp	w8, w9, [x24]
    9b94:      	ldur	x8, [x20, #0x64]
    9b98:      	stp	x10, x8, [x24, #0x8]
    9b9c:      	bl	0xce60 <strlen@plt>
    9ba0:      	ldur	x8, [x20, #0x8c]
    9ba4:      	str	x0, [x24, #0x20]
    9ba8:      	bl	0xca78 <JNI_OnLoad+0x383c>
    9bac:      	ldur	x8, [x20, #0x94]
    9bb0:      	str	x0, [x24, #0x28]
    9bb4:      	bl	0xca78 <JNI_OnLoad+0x383c>
    9bb8:      	ldur	x8, [x20, #0x9c]
    9bbc:      	str	x0, [x24, #0x30]
    9bc0:      	bl	0xca78 <JNI_OnLoad+0x383c>
    9bc4:      	ldur	x8, [x20, #0xa4]
    9bc8:      	str	x0, [x24, #0x38]
    9bcc:      	bl	0xca78 <JNI_OnLoad+0x383c>
    9bd0:      	ldur	x8, [x20, #0xac]
    9bd4:      	str	x0, [x24, #0x40]
    9bd8:      	bl	0xca78 <JNI_OnLoad+0x383c>
    9bdc:      	ldur	x8, [x20, #0xb4]
    9be0:      	str	x0, [x24, #0x48]
    9be4:      	bl	0xca78 <JNI_OnLoad+0x383c>
    9be8:      	ldur	x8, [x20, #0x74]
    9bec:      	str	x0, [x24, #0x50]
    9bf0:      	bl	0xca78 <JNI_OnLoad+0x383c>
    9bf4:      	ldur	x8, [x20, #0x7c]
    9bf8:      	str	x0, [x24, #0x58]
    9bfc:      	bl	0xca78 <JNI_OnLoad+0x383c>
    9c00:      	str	x0, [x24, #0x60]
    9c04:      	mov	w0, #0x4000             // =16384
    9c08:      	mov	w1, #0x1                // =1
    9c0c:      	bl	0xce70 <calloc@plt>
    9c10:      	stur	x0, [x20, #0x34]
    9c14:      	cbz	x0, 0x959c <JNI_OnLoad+0x360>
    9c18:      	add	x8, x0, #0x4, lsl #12   // =0x4000
    9c1c:      	adrp	x9, 0x17000
    9c20:      	mov	w0, #0x1                // =1
    9c24:      	mov	w1, #0x20000            // =131072
    9c28:      	str	x8, [x9, #0x368]
    9c2c:      	bl	0xce70 <calloc@plt>
    9c30:      	str	x0, [sp, #0xd0]
    9c34:      	cbz	x0, 0x959c <JNI_OnLoad+0x360>
    9c38:      	mov	w8, #0x20000            // =131072
    9c3c:      	add	x0, sp, #0xd0
    9c40:      	mov	x1, xzr
    9c44:      	str	x8, [sp, #0xe0]
    9c48:      	str	wzr, [sp, #0xd8]
    9c4c:      	bl	0xcf80 <sigaltstack@plt>
    9c50:      	cbnz	w0, 0x959c <JNI_OnLoad+0x360>
    9c54:      	movi	v0.2d, #0000000000000000
    9c58:      	add	x8, sp, #0x1d0
    9c5c:      	stp	q0, q0, [x8]
    9c60:      	add	x8, sp, #0x1d0
    9c64:      	add	x0, x8, #0x10
    9c68:      	bl	0xcf90 <sigfillset@plt>
    9c6c:      	nop
    9c70:      	adr	x9, 0x87f4 <.text+0x3ed0>
    9c74:      	mov	x8, xzr
    9c78:      	str	x9, [sp, #0x1d8]
    9c7c:      	mov	w9, #0x4                // =4
    9c80:      	nop
    9c84:      	adr	x20, 0x156a8
    9c88:      	movk	w9, #0x1800, lsl #16
    9c8c:      	str	w9, [sp, #0x1d0]
    9c90:      	add	x24, x8, #0x28
    9c94:      	cmp	x24, #0x168
    9c98:      	b.eq	0x9d60 <JNI_OnLoad+0xb24>
    9c9c:      	add	x8, x20, x8
    9ca0:      	add	x1, sp, #0x1d0
    9ca4:      	ldr	w0, [x8, #0x18]
    9ca8:      	add	x2, x8, #0x20
    9cac:      	bl	0xcfa0 <sigaction@plt>
    9cb0:      	mov	x8, x24
    9cb4:      	cbz	w0, 0x9c90 <JNI_OnLoad+0xa54>
    9cb8:      	b	0x959c <JNI_OnLoad+0x360>
    9cbc:      	ldr	x0, [sp, #0x20]
    9cc0:      	bl	0xce60 <strlen@plt>
    9cc4:      	cbz	x0, 0x9a00 <JNI_OnLoad+0x7c4>
    9cc8:      	ldr	x8, [sp, #0x20]
    9ccc:      	ldrb	w8, [x8]
    9cd0:      	cmp	w8, #0x2f
    9cd4:      	b.ne	0x9a00 <JNI_OnLoad+0x7c4>
    9cd8:      	mov	x24, x0
    9cdc:      	ldr	x1, [sp, #0x20]
    9ce0:      	add	x0, sp, #0x1d0
    9ce4:      	add	x2, x24, #0x1
    9ce8:      	mov	w3, #0x1000             // =4096
    9cec:      	bl	0xcf60 <__memcpy_chk@plt>
    9cf0:      	sub	x8, x24, #0x1
    9cf4:      	add	x9, sp, #0x1d0
    9cf8:      	ldrb	w9, [x9, x8]
    9cfc:      	cmp	w9, #0x2f
    9d00:      	b.ne	0x9d0c <JNI_OnLoad+0xad0>
    9d04:      	add	x9, sp, #0x1d0
    9d08:      	strb	wzr, [x9, x8]
    9d0c:      	mov	w24, #0x1               // =1
    9d10:      	add	x8, sp, #0x1d0
    9d14:      	ldrb	w8, [x8, x24]
    9d18:      	cmp	w8, #0x2f
    9d1c:      	b.eq	0x9d28 <JNI_OnLoad+0xaec>
    9d20:      	cbnz	w8, 0x9d58 <JNI_OnLoad+0xb1c>
    9d24:      	b	0x9d78 <JNI_OnLoad+0xb3c>
    9d28:      	add	x8, sp, #0x1d0
    9d2c:      	add	x0, sp, #0x1d0
    9d30:      	mov	w1, #0x1c0              // =448
    9d34:      	strb	wzr, [x8, x24]
    9d38:      	ldr	x8, [sp, #0x10]
    9d3c:      	bl	0xcc04 <JNI_OnLoad+0x39c8>
    9d40:      	cbz	w0, 0x9d4c <JNI_OnLoad+0xb10>
    9d44:      	bl	0xcb68 <JNI_OnLoad+0x392c>
    9d48:      	b.ne	0x9d94 <JNI_OnLoad+0xb58>
    9d4c:      	add	x8, sp, #0x1d0
    9d50:      	mov	w9, #0x2f               // =47
    9d54:      	strb	w9, [x8, x24]
    9d58:      	add	x24, x24, #0x1
    9d5c:      	b	0x9d10 <JNI_OnLoad+0xad4>
    9d60:      	mov	w24, wzr
    9d64:      	b	0x95a0 <JNI_OnLoad+0x364>
    9d68:      	bl	0xd110 <__stack_chk_fail@plt>
    9d6c:      	adrp	x8, 0x17000
    9d70:      	str	xzr, [x8, #0x360]
    9d74:      	b	0x959c <JNI_OnLoad+0x360>
    9d78:      	ldr	x8, [sp, #0x10]
    9d7c:      	add	x0, sp, #0x1d0
    9d80:      	mov	w1, #0x1c0              // =448
    9d84:      	bl	0xcc04 <JNI_OnLoad+0x39c8>
    9d88:      	cbz	w0, 0x9a34 <JNI_OnLoad+0x7f8>
    9d8c:      	bl	0xcb68 <JNI_OnLoad+0x392c>
    9d90:      	b.eq	0x9a34 <JNI_OnLoad+0x7f8>
    9d94:      	mov	x24, x22
    9d98:      	cbz	w8, 0x9a34 <JNI_OnLoad+0x7f8>
    9d9c:      	adrp	x8, 0x17000
    9da0:      	adrp	x22, 0x17000
    9da4:      	ldr	x0, [x8, #0x3b8]
    9da8:      	cbz	x0, 0x9db4 <JNI_OnLoad+0xb78>
    9dac:      	bl	0xcaf4 <JNI_OnLoad+0x38b8>
    9db0:      	str	xzr, [x20, #0x3b8]
    9db4:      	adrp	x20, 0x17000
    9db8:      	ldr	x0, [x20, #0x3c8]
    9dbc:      	cbz	x0, 0x9dc8 <JNI_OnLoad+0xb8c>
    9dc0:      	bl	0xcdc0 <free@plt>
    9dc4:      	str	xzr, [x20, #0x3c8]
    9dc8:      	adrp	x8, 0x17000
    9dcc:      	ldr	x0, [x8, #0x3d0]
    9dd0:      	cbz	x0, 0x9ddc <JNI_OnLoad+0xba0>
    9dd4:      	bl	0xcaf4 <JNI_OnLoad+0x38b8>
    9dd8:      	str	xzr, [x20, #0x3d0]
    9ddc:      	adrp	x8, 0x17000
    9de0:      	ldr	x0, [x8, #0x3d8]
    9de4:      	cbz	x0, 0x9df0 <JNI_OnLoad+0xbb4>
    9de8:      	bl	0xcaf4 <JNI_OnLoad+0x38b8>
    9dec:      	str	xzr, [x20, #0x3d8]
    9df0:      	adrp	x20, 0x17000
    9df4:      	ldr	x0, [x20, #0x3e0]
    9df8:      	cbz	x0, 0x9e04 <JNI_OnLoad+0xbc8>
    9dfc:      	bl	0xcdc0 <free@plt>
    9e00:      	str	xzr, [x20, #0x3e0]
    9e04:      	adrp	x8, 0x17000
    9e08:      	ldr	x0, [x8, #0x3e8]
    9e0c:      	cbz	x0, 0x9e18 <JNI_OnLoad+0xbdc>
    9e10:      	bl	0xcaf4 <JNI_OnLoad+0x38b8>
    9e14:      	str	xzr, [x20, #0x3e8]
    9e18:      	adrp	x20, 0x17000
    9e1c:      	ldr	x0, [x20, #0x3a8]
    9e20:      	cbz	x0, 0x9e2c <JNI_OnLoad+0xbf0>
    9e24:      	bl	0xcdc0 <free@plt>
    9e28:      	str	xzr, [x20, #0x3a8]
    9e2c:      	adrp	x8, 0x17000
    9e30:      	ldr	x0, [x8, #0x3b0]
    9e34:      	cbz	x0, 0x9e40 <JNI_OnLoad+0xc04>
    9e38:      	bl	0xcaf4 <JNI_OnLoad+0x38b8>
    9e3c:      	str	xzr, [x20, #0x3b0]
    9e40:      	ldr	x0, [x22, #0x358]
    9e44:      	adrp	x20, 0x17000
    9e48:      	cbz	x0, 0x9e54 <JNI_OnLoad+0xc18>
    9e4c:      	bl	0xcdc0 <free@plt>
    9e50:      	str	xzr, [x22, #0x358]
    9e54:      	adrp	x22, 0x17000
    9e58:      	ldr	x0, [x22, #0x340]
    9e5c:      	cbz	x0, 0x9e68 <JNI_OnLoad+0xc2c>
    9e60:      	bl	0xcdc0 <free@plt>
    9e64:      	str	xzr, [x22, #0x340]
    9e68:      	adrp	x22, 0x17000
    9e6c:      	ldr	x0, [x22, #0x3c0]
    9e70:      	cbz	x0, 0x9e7c <JNI_OnLoad+0xc40>
    9e74:      	bl	0xcdc0 <free@plt>
    9e78:      	str	xzr, [x22, #0x3c0]
    9e7c:      	ldr	x0, [x20, #0x348]
    9e80:      	cbz	x0, 0x9544 <JNI_OnLoad+0x308>
    9e84:      	bl	0xcdc0 <free@plt>
    9e88:      	str	xzr, [x20, #0x348]
    9e8c:      	b	0x9544 <JNI_OnLoad+0x308>
    9e90:      	ldr	x8, [x20, #0x378]
    9e94:      	cbz	x8, 0x9b58 <JNI_OnLoad+0x91c>
    9e98:      	mov	w0, wzr
    9e9c:      	mov	w1, #0x80000            // =524288
    9ea0:      	bl	0xce80 <eventfd@plt>
    9ea4:      	str	w0, [x24, #0x6b0]
    9ea8:      	tbnz	w0, #0x1f, 0x9ed0 <JNI_OnLoad+0xc94>
    9eac:      	adrp	x0, 0x17000
    9eb0:      	add	x0, x0, #0x380
    9eb4:      	nop
    9eb8:      	adr	x2, 0x85f4 <.text+0x3cd0>
    9ebc:      	mov	x1, xzr
    9ec0:      	mov	x3, xzr
    9ec4:      	bl	0xce90 <pthread_create@plt>
    9ec8:      	cbnz	w0, 0x9b58 <JNI_OnLoad+0x91c>
    9ecc:      	b	0x9b70 <JNI_OnLoad+0x934>
    9ed0:      	str	xzr, [x20, #0x378]
    9ed4:      	b	0x9b70 <JNI_OnLoad+0x934>
    9ed8:      	ret
    9edc:      	sub	sp, sp, #0x110
    9ee0:      	stp	x29, x30, [sp, #0xf0]
    9ee4:      	stp	x28, x19, [sp, #0x100]
    9ee8:      	add	x29, sp, #0xf0
    9eec:      	stp	x4, x5, [x29, #-0x70]
    9ef0:      	sub	x9, x29, #0x70
    9ef4:      	mov	x10, sp
    9ef8:      	stp	x6, x7, [x29, #-0x60]
    9efc:      	add	x10, x10, #0x80
    9f00:      	adrp	x2, 0x2000
    9f04:      	add	x2, x2, #0x974
    9f08:      	stp	q0, q1, [sp]
    9f0c:      	sub	x3, x29, #0x50
    9f10:      	stp	q2, q3, [sp, #0x20]
    9f14:      	mov	w1, #0x100              // =256
    9f18:      	bl	0xcb78 <JNI_OnLoad+0x393c>
    9f1c:      	add	x8, x9, #0x20
    9f20:      	add	x9, x29, #0x20
    9f24:      	stp	x9, x8, [x29, #-0x28]
    9f28:      	mov	x8, #-0x20              // =-32
    9f2c:      	bl	0xcba0 <JNI_OnLoad+0x3964>
    9f30:      	bl	0xd010 <vsnprintf@plt>
    9f34:      	ldr	x8, [x19, #0x28]
    9f38:      	bl	0xca50 <JNI_OnLoad+0x3814>
    9f3c:      	b.ne	0x9f50 <JNI_OnLoad+0xd14>
    9f40:      	ldp	x28, x19, [sp, #0x100]
    9f44:      	ldp	x29, x30, [sp, #0xf0]
    9f48:      	add	sp, sp, #0x110
    9f4c:      	ret
    9f50:      	bl	0xd110 <__stack_chk_fail@plt>
    9f54:      	sub	sp, sp, #0xc0
    9f58:      	stp	x29, x30, [sp, #0x60]
    9f5c:      	stp	x28, x27, [sp, #0x70]
    9f60:      	stp	x26, x25, [sp, #0x80]
    9f64:      	stp	x24, x23, [sp, #0x90]
    9f68:      	stp	x22, x21, [sp, #0xa0]
    9f6c:      	stp	x20, x19, [sp, #0xb0]
    9f70:      	add	x29, sp, #0x60
    9f74:      	mrs	x24, TPIDR_EL0
    9f78:      	mov	x19, x2
    9f7c:      	ldr	x8, [x24, #0x28]
    9f80:      	stur	x8, [x29, #-0x8]
    9f84:      	stp	xzr, x0, [sp, #0x18]
    9f88:      	str	x1, [sp, #0x28]
    9f8c:      	cbz	x1, 0x9f94 <JNI_OnLoad+0xd58>
    9f90:      	strb	wzr, [x0]
    9f94:      	ldp	x28, x8, [x3]
    9f98:      	mov	w26, wzr
    9f9c:      	ldr	w21, [x3, #0x18]
    9fa0:      	str	x8, [sp, #0x10]
    9fa4:      	mov	w8, w26
    9fa8:      	sxtw	x8, w8
    9fac:      	mov	x20, x8
    9fb0:      	ldrb	w22, [x19, x20]
    9fb4:      	cbz	w22, 0x9fc8 <JNI_OnLoad+0xd8c>
    9fb8:      	cmp	w22, #0x25
    9fbc:      	b.eq	0x9fc8 <JNI_OnLoad+0xd8c>
    9fc0:      	add	x20, x20, #0x1
    9fc4:      	b	0x9fb0 <JNI_OnLoad+0xd74>
    9fc8:      	subs	w2, w20, w26
    9fcc:      	b.le	0x9fe0 <JNI_OnLoad+0xda4>
    9fd0:      	add	x0, sp, #0x18
    9fd4:      	add	x1, x19, x8
    9fd8:      	bl	0xa430 <JNI_OnLoad+0x11f4>
    9fdc:      	mov	w26, w20
    9fe0:      	cbz	w22, 0xa3fc <JNI_OnLoad+0x11c0>
    9fe4:      	mov	w23, wzr
    9fe8:      	mov	w27, wzr
    9fec:      	mov	w25, wzr
    9ff0:      	add	w26, w26, #0x1
    9ff4:      	sxtw	x26, w26
    9ff8:      	mov	w10, w25
    9ffc:      	ldrb	w3, [x19, x26]
    a000:      	mov	x8, x26
    a004:      	mov	w25, w10
    a008:      	add	x26, x26, #0x1
    a00c:      	mov	w10, #0x1               // =1
    a010:      	subs	w9, w3, #0x30
    a014:      	b.eq	0x9ffc <JNI_OnLoad+0xdc0>
    a018:      	cmp	w3, #0x2d
    a01c:      	b.eq	0xa038 <JNI_OnLoad+0xdfc>
    a020:      	cmp	w3, #0x20
    a024:      	b.eq	0xa030 <JNI_OnLoad+0xdf4>
    a028:      	cmp	w3, #0x2b
    a02c:      	b.ne	0xa040 <JNI_OnLoad+0xe04>
    a030:      	mov	w23, w3
    a034:      	b	0xa03c <JNI_OnLoad+0xe00>
    a038:      	mov	w27, #0x1               // =1
    a03c:      	b	0x9ff4 <JNI_OnLoad+0xdb8>
    a040:      	cbz	w3, 0xa3e4 <JNI_OnLoad+0x11a8>
    a044:      	cmp	w9, #0x9
    a048:      	stur	w26, [x29, #-0x2c]
    a04c:      	b.hi	0xa078 <JNI_OnLoad+0xe3c>
    a050:      	sub	x1, x29, #0x2c
    a054:      	mov	x0, x19
    a058:      	stur	w8, [x29, #-0x2c]
    a05c:      	bl	0xa4bc <JNI_OnLoad+0x1280>
    a060:      	ldursw	x8, [x29, #-0x2c]
    a064:      	mov	w20, w0
    a068:      	ldrb	w3, [x19, x8]
    a06c:      	add	w26, w8, #0x1
    a070:      	stur	w26, [x29, #-0x2c]
    a074:      	b	0xa07c <JNI_OnLoad+0xe40>
    a078:      	mov	w20, #-0x1              // =-1
    a07c:      	cmp	w3, #0x2e
    a080:      	b.ne	0xa0a8 <JNI_OnLoad+0xe6c>
    a084:      	sub	x1, x29, #0x2c
    a088:      	mov	x0, x19
    a08c:      	bl	0xa4bc <JNI_OnLoad+0x1280>
    a090:      	ldursw	x8, [x29, #-0x2c]
    a094:      	str	w0, [sp, #0xc]
    a098:      	ldrb	w3, [x19, x8]
    a09c:      	add	w26, w8, #0x1
    a0a0:      	stur	w26, [x29, #-0x2c]
    a0a4:      	b	0xa0b0 <JNI_OnLoad+0xe74>
    a0a8:      	mov	w8, #-0x1               // =-1
    a0ac:      	str	w8, [sp, #0xc]
    a0b0:      	sub	w8, w3, #0x68
    a0b4:      	extr	w9, w3, w8, #0x1
    a0b8:      	mov	w8, #0x4                // =4
    a0bc:      	cmp	w9, #0x9
    a0c0:      	b.hi	0xa158 <JNI_OnLoad+0xf1c>
    a0c4:      	nop
    a0c8:      	adr	x12, 0x31ec
    a0cc:      	adr	x10, 0xa0dc <JNI_OnLoad+0xea0>
    a0d0:      	ldrb	w11, [x12, x9]
    a0d4:      	add	x10, x10, x11, lsl #2
    a0d8:      	br	x10
    a0dc:      	ldrb	w3, [x19, w26, sxtw]
    a0e0:      	cmp	w3, #0x68
    a0e4:      	b.ne	0xa14c <JNI_OnLoad+0xf10>
    a0e8:      	sxtw	x8, w26
    a0ec:      	add	x26, x8, #0x1
    a0f0:      	mov	w8, #0x1                // =1
    a0f4:      	ldrb	w3, [x19, x26]
    a0f8:      	b	0xa150 <JNI_OnLoad+0xf14>
    a0fc:      	ldrb	w3, [x19, w26, sxtw]
    a100:      	add	w8, w26, #0x1
    a104:      	stur	w8, [x29, #-0x2c]
    a108:      	strb	w3, [sp, #0x30]
    a10c:      	b	0xa140 <JNI_OnLoad+0xf04>
    a110:      	ldrb	w3, [x19, w26, sxtw]
    a114:      	cmp	w3, #0x6c
    a118:      	b.ne	0xa128 <JNI_OnLoad+0xeec>
    a11c:      	sxtw	x8, w26
    a120:      	add	x26, x8, #0x1
    a124:      	ldrb	w3, [x19, x26]
    a128:      	add	w26, w26, #0x1
    a12c:      	stur	w26, [x29, #-0x2c]
    a130:      	b	0xa144 <JNI_OnLoad+0xf08>
    a134:      	ldrb	w3, [x19, w26, sxtw]
    a138:      	add	w8, w26, #0x1
    a13c:      	stur	w8, [x29, #-0x2c]
    a140:      	mov	w26, w8
    a144:      	mov	w8, #0x8                // =8
    a148:      	b	0xa158 <JNI_OnLoad+0xf1c>
    a14c:      	mov	w8, #0x2                // =2
    a150:      	add	w26, w26, #0x1
    a154:      	stur	w26, [x29, #-0x2c]
    a158:      	ldr	x10, [sp, #0x10]
    a15c:      	sub	w9, w3, #0x6f
    a160:      	cmp	w9, #0x9
    a164:      	add	x10, x10, w21, sxtw
    a168:      	b.hi	0xa1a4 <JNI_OnLoad+0xf68>
    a16c:      	adrp	x13, 0x3000
    a170:      	add	x13, x13, #0x1f6
    a174:      	adr	x11, 0xa184 <JNI_OnLoad+0xf48>
    a178:      	ldrb	w12, [x13, x9]
    a17c:      	add	x11, x11, x12, lsl #2
    a180:      	br	x11
    a184:      	str	x24, [sp]
    a188:      	tbz	w21, #0x1f, 0xa394 <JNI_OnLoad+0x1158>
    a18c:      	cmn	w21, #0x8
    a190:      	add	w21, w21, #0x8
    a194:      	b.hi	0xa394 <JNI_OnLoad+0x1158>
    a198:      	mov	x24, x28
    a19c:      	mov	x28, x10
    a1a0:      	b	0xa398 <JNI_OnLoad+0x115c>
    a1a4:      	cmp	w3, #0x25
    a1a8:      	b.eq	0xa364 <JNI_OnLoad+0x1128>
    a1ac:      	cmp	w3, #0x58
    a1b0:      	b.eq	0xa1d4 <JNI_OnLoad+0xf98>
    a1b4:      	cmp	w3, #0x63
    a1b8:      	b.eq	0xa348 <JNI_OnLoad+0x110c>
    a1bc:      	cmp	w3, #0x64
    a1c0:      	mov	w9, #0x1                // =1
    a1c4:      	b.eq	0xa1dc <JNI_OnLoad+0xfa0>
    a1c8:      	cmp	w3, #0x69
    a1cc:      	b.eq	0xa1dc <JNI_OnLoad+0xfa0>
    a1d0:      	b	0xa3fc <JNI_OnLoad+0x11c0>
    a1d4:      	cmp	w3, #0x6f
    a1d8:      	cset	w9, eq
    a1dc:      	sub	x11, x8, #0x1
    a1e0:      	cmp	x11, #0x7
    a1e4:      	b.hi	0xa3fc <JNI_OnLoad+0x11c0>
    a1e8:      	adrp	x14, 0x3000
    a1ec:      	add	x14, x14, #0x200
    a1f0:      	adr	x12, 0xa200 <JNI_OnLoad+0xfc4>
    a1f4:      	ldrb	w13, [x14, x11]
    a1f8:      	add	x12, x12, x13, lsl #2
    a1fc:      	br	x12
    a200:      	tbz	w21, #0x1f, 0xa278 <JNI_OnLoad+0x103c>
    a204:      	cmn	w21, #0x8
    a208:      	add	w21, w21, #0x8
    a20c:      	b.hi	0xa278 <JNI_OnLoad+0x103c>
    a210:      	bl	0xccb0 <JNI_OnLoad+0x3a74>
    a214:      	b	0xa27c <JNI_OnLoad+0x1040>
    a218:      	tbz	w21, #0x1f, 0xa260 <JNI_OnLoad+0x1024>
    a21c:      	cmn	w21, #0x8
    a220:      	add	w21, w21, #0x8
    a224:      	b.hi	0xa260 <JNI_OnLoad+0x1024>
    a228:      	bl	0xccb0 <JNI_OnLoad+0x3a74>
    a22c:      	b	0xa264 <JNI_OnLoad+0x1028>
    a230:      	tbz	w21, #0x1f, 0xa26c <JNI_OnLoad+0x1030>
    a234:      	cmn	w21, #0x8
    a238:      	add	w21, w21, #0x8
    a23c:      	b.hi	0xa26c <JNI_OnLoad+0x1030>
    a240:      	bl	0xccb0 <JNI_OnLoad+0x3a74>
    a244:      	b	0xa270 <JNI_OnLoad+0x1034>
    a248:      	tbz	w21, #0x1f, 0xa284 <JNI_OnLoad+0x1048>
    a24c:      	cmn	w21, #0x8
    a250:      	add	w21, w21, #0x8
    a254:      	b.hi	0xa284 <JNI_OnLoad+0x1048>
    a258:      	bl	0xccb0 <JNI_OnLoad+0x3a74>
    a25c:      	b	0xa288 <JNI_OnLoad+0x104c>
    a260:      	add	x11, x28, #0x8
    a264:      	ldrh	w2, [x28]
    a268:      	b	0xa28c <JNI_OnLoad+0x1050>
    a26c:      	add	x11, x28, #0x8
    a270:      	ldr	x2, [x28]
    a274:      	b	0xa28c <JNI_OnLoad+0x1050>
    a278:      	add	x11, x28, #0x8
    a27c:      	ldrb	w2, [x28]
    a280:      	b	0xa28c <JNI_OnLoad+0x1050>
    a284:      	add	x11, x28, #0x8
    a288:      	ldr	w2, [x28]
    a28c:      	mov	x28, x11
    a290:      	cbz	w9, 0xa2a4 <JNI_OnLoad+0x1068>
    a294:      	lsl	w8, w8, #3
    a298:      	neg	w8, w8
    a29c:      	lsl	x9, x2, x8
    a2a0:      	asr	x2, x9, x8
    a2a4:      	sub	x0, x29, #0x28
    a2a8:      	mov	w1, #0x20               // =32
    a2ac:      	sub	x22, x29, #0x28
    a2b0:      	bl	0xa4f8 <JNI_OnLoad+0x12bc>
    a2b4:      	bl	0xcc3c <JNI_OnLoad+0x3a00>
    a2b8:      	tst	w23, #0xff
    a2bc:      	b.ne	0xa3fc <JNI_OnLoad+0x11c0>
    a2c0:      	ldr	w8, [sp, #0xc]
    a2c4:      	cmn	w8, #0x1
    a2c8:      	b.ne	0xa3fc <JNI_OnLoad+0x11c0>
    a2cc:      	mov	x23, x0
    a2d0:      	subs	w2, w20, w23
    a2d4:      	b.le	0xa2f4 <JNI_OnLoad+0x10b8>
    a2d8:      	cbnz	w27, 0xa2f4 <JNI_OnLoad+0x10b8>
    a2dc:      	cmp	w25, #0x0
    a2e0:      	mov	w8, #0x30               // =48
    a2e4:      	mov	w9, #0x20               // =32
    a2e8:      	csel	w1, w9, w8, eq
    a2ec:      	add	x0, sp, #0x18
    a2f0:      	bl	0xa604 <JNI_OnLoad+0x13c8>
    a2f4:      	add	x0, sp, #0x18
    a2f8:      	mov	x1, x22
    a2fc:      	mov	w2, w23
    a300:      	bl	0xa430 <JNI_OnLoad+0x11f4>
    a304:      	subs	w2, w20, w23
    a308:      	b.le	0x9fa4 <JNI_OnLoad+0xd68>
    a30c:      	cbz	w27, 0x9fa4 <JNI_OnLoad+0xd68>
    a310:      	cmp	w25, #0x0
    a314:      	mov	w8, #0x30               // =48
    a318:      	mov	w9, #0x20               // =32
    a31c:      	csel	w1, w9, w8, eq
    a320:      	add	x0, sp, #0x18
    a324:      	bl	0xa604 <JNI_OnLoad+0x13c8>
    a328:      	b	0x9fa4 <JNI_OnLoad+0xd68>
    a32c:      	tbz	w21, #0x1f, 0xa374 <JNI_OnLoad+0x1138>
    a330:      	cmn	w21, #0x8
    a334:      	add	w21, w21, #0x8
    a338:      	b.hi	0xa374 <JNI_OnLoad+0x1138>
    a33c:      	mov	x8, x28
    a340:      	mov	x28, x10
    a344:      	b	0xa378 <JNI_OnLoad+0x113c>
    a348:      	tbz	w21, #0x1f, 0xa3c8 <JNI_OnLoad+0x118c>
    a34c:      	cmn	w21, #0x8
    a350:      	add	w21, w21, #0x8
    a354:      	b.hi	0xa3c8 <JNI_OnLoad+0x118c>
    a358:      	mov	x8, x28
    a35c:      	mov	x28, x10
    a360:      	b	0xa3cc <JNI_OnLoad+0x1190>
    a364:      	mov	w8, #0x25               // =37
    a368:      	sub	x22, x29, #0x28
    a36c:      	sturh	w8, [x29, #-0x28]
    a370:      	b	0xa2b4 <JNI_OnLoad+0x1078>
    a374:      	add	x8, x28, #0x8
    a378:      	ldr	x9, [x28]
    a37c:      	adrp	x10, 0x3000
    a380:      	add	x10, x10, #0x2f
    a384:      	mov	x28, x8
    a388:      	cmp	x9, #0x0
    a38c:      	csel	x22, x10, x9, eq
    a390:      	b	0xa2b4 <JNI_OnLoad+0x1078>
    a394:      	add	x24, x28, #0x8
    a398:      	mov	w8, #0x7830             // =30768
    a39c:      	ldr	x2, [x28]
    a3a0:      	mov	w1, #0x1e               // =30
    a3a4:      	sturh	w8, [x29, #-0x28]
    a3a8:      	sub	x8, x29, #0x28
    a3ac:      	mov	w3, #0x78               // =120
    a3b0:      	orr	x0, x8, #0x2
    a3b4:      	bl	0xa4f8 <JNI_OnLoad+0x12bc>
    a3b8:      	mov	x28, x24
    a3bc:      	ldr	x24, [sp]
    a3c0:      	sub	x22, x29, #0x28
    a3c4:      	b	0xa2b4 <JNI_OnLoad+0x1078>
    a3c8:      	add	x8, x28, #0x8
    a3cc:      	ldr	w9, [x28]
    a3d0:      	sturb	wzr, [x29, #-0x27]
    a3d4:      	sub	x22, x29, #0x28
    a3d8:      	mov	x28, x8
    a3dc:      	sturb	w9, [x29, #-0x28]
    a3e0:      	b	0xa2b4 <JNI_OnLoad+0x1078>
    a3e4:      	mov	w8, #0x25               // =37
    a3e8:      	add	x0, sp, #0x18
    a3ec:      	add	x1, sp, #0x30
    a3f0:      	mov	w2, #0x1                // =1
    a3f4:      	strb	w8, [sp, #0x30]
    a3f8:      	bl	0xa430 <JNI_OnLoad+0x11f4>
    a3fc:      	ldr	x0, [sp, #0x18]
    a400:      	ldr	x8, [x24, #0x28]
    a404:      	bl	0xca50 <JNI_OnLoad+0x3814>
    a408:      	b.ne	0xa42c <JNI_OnLoad+0x11f0>
    a40c:      	ldp	x20, x19, [sp, #0xb0]
    a410:      	ldp	x22, x21, [sp, #0xa0]
    a414:      	ldp	x24, x23, [sp, #0x90]
    a418:      	ldp	x26, x25, [sp, #0x80]
    a41c:      	ldp	x28, x27, [sp, #0x70]
    a420:      	ldp	x29, x30, [sp, #0x60]
    a424:      	add	sp, sp, #0xc0
    a428:      	ret
    a42c:      	bl	0xd110 <__stack_chk_fail@plt>
    a430:      	stp	x29, x30, [sp, #-0x30]!
    a434:      	str	x21, [sp, #0x10]
    a438:      	stp	x20, x19, [sp, #0x20]
    a43c:      	mov	x29, sp
    a440:      	mov	x20, x1
    a444:      	mov	x19, x0
    a448:      	tbz	w2, #0x1f, 0xa458 <JNI_OnLoad+0x121c>
    a44c:      	mov	x0, x20
    a450:      	bl	0xce60 <strlen@plt>
    a454:      	mov	x2, x0
    a458:      	ldr	x9, [x19]
    a45c:      	ldr	x8, [x19, #0x10]
    a460:      	add	x9, x9, w2, sxtw
    a464:      	cmp	x8, #0x2
    a468:      	str	x9, [x19]
    a46c:      	b.lo	0xa4ac <JNI_OnLoad+0x1270>
    a470:      	sxtw	x9, w2
    a474:      	sub	w10, w8, #0x1
    a478:      	ldr	x0, [x19, #0x8]
    a47c:      	mov	x1, x20
    a480:      	cmp	x8, x9
    a484:      	csel	w21, w9, w10, hi
    a488:      	sxtw	x2, w21
    a48c:      	bl	0xd0b0 <memcpy@plt>
    a490:      	ldr	x8, [x19, #0x8]
    a494:      	add	x9, x8, w21, sxtw
    a498:      	str	x9, [x19, #0x8]
    a49c:      	strb	wzr, [x8, w21, sxtw]
    a4a0:      	ldr	x8, [x19, #0x10]
    a4a4:      	sub	x8, x8, w21, sxtw
    a4a8:      	str	x8, [x19, #0x10]
    a4ac:      	ldp	x20, x19, [sp, #0x20]
    a4b0:      	ldr	x21, [sp, #0x10]
    a4b4:      	ldp	x29, x30, [sp], #0x30
    a4b8:      	ret
    a4bc:      	ldrsw	x8, [x1]
    a4c0:      	mov	w10, wzr
    a4c4:      	mov	w11, #0xa               // =10
    a4c8:      	add	x8, x8, x0
    a4cc:      	sub	x9, x8, #0x1
    a4d0:      	ldrb	w12, [x9, #0x1]!
    a4d4:      	mov	w8, w10
    a4d8:      	sub	w12, w12, #0x30
    a4dc:      	madd	w10, w10, w11, w12
    a4e0:      	cmp	w12, #0xa
    a4e4:      	b.lo	0xa4d0 <JNI_OnLoad+0x1294>
    a4e8:      	sub	w9, w9, w0
    a4ec:      	mov	w0, w8
    a4f0:      	str	w9, [x1]
    a4f4:      	ret
    a4f8:      	sub	w8, w3, #0x64
    a4fc:      	mov	w10, #0x821             // =2081
    a500:      	mov	w11, #0xa               // =10
    a504:      	and	w9, w8, #0xff
    a508:      	lsr	w8, w10, w8
    a50c:      	mov	w12, #0x8               // =8
    a510:      	cmp	w9, #0xc
    a514:      	and	w9, w3, #0xff
    a518:      	cset	w10, lo
    a51c:      	cmp	w9, #0x6f
    a520:      	csel	x11, x11, x12, ne
    a524:      	mov	w12, #0x10              // =16
    a528:      	cmp	w9, #0x78
    a52c:      	and	w10, w10, w8
    a530:      	csel	x8, x12, x11, eq
    a534:      	cmp	w9, #0x58
    a538:      	csel	x8, x12, x8, eq
    a53c:      	cmp	x2, #0x0
    a540:      	eor	w10, w10, #0x1
    a544:      	csinc	w10, w10, wzr, lt
    a548:      	tbnz	w10, #0x0, 0xa55c <JNI_OnLoad+0x1320>
    a54c:      	mov	w10, #0x2d              // =45
    a550:      	sub	x1, x1, #0x1
    a554:      	neg	x2, x2
    a558:      	strb	w10, [x0], #0x1
    a55c:      	add	x10, x0, x1
    a560:      	cmp	w9, #0x58
    a564:      	mov	w9, #0x57               // =87
    a568:      	mov	w11, #0x37              // =55
    a56c:      	sub	x10, x10, #0x1
    a570:      	mov	w12, #0x30              // =48
    a574:      	csel	w11, w11, w9, eq
    a578:      	mov	x14, x0
    a57c:      	mov	x9, x14
    a580:      	cbz	x2, 0xa5b4 <JNI_OnLoad+0x1378>
    a584:      	mov	x13, x2
    a588:      	udiv	x2, x2, x8
    a58c:      	cmp	x9, x10
    a590:      	mov	x14, x10
    a594:      	b.eq	0xa57c <JNI_OnLoad+0x1340>
    a598:      	msub	w13, w2, w8, w13
    a59c:      	cmp	w13, #0xa
    a5a0:      	csel	w14, w12, w11, lo
    a5a4:      	add	w13, w14, w13
    a5a8:      	strb	w13, [x9], #0x1
    a5ac:      	mov	x14, x9
    a5b0:      	b	0xa57c <JNI_OnLoad+0x1340>
    a5b4:      	cmp	x9, x0
    a5b8:      	ccmp	x9, x10, #0x4, eq
    a5bc:      	b.eq	0xa5cc <JNI_OnLoad+0x1390>
    a5c0:      	mov	w8, #0x30               // =48
    a5c4:      	mov	x9, x0
    a5c8:      	strb	w8, [x9], #0x1
    a5cc:      	mvn	x10, x0
    a5d0:      	mov	x8, xzr
    a5d4:      	strb	wzr, [x9]
    a5d8:      	add	x9, x9, x10
    a5dc:      	cmp	x8, x9
    a5e0:      	b.hs	0xa600 <JNI_OnLoad+0x13c4>
    a5e4:      	ldrb	w10, [x0, x9]
    a5e8:      	ldrb	w11, [x0, x8]
    a5ec:      	strb	w10, [x0, x8]
    a5f0:      	add	x8, x8, #0x1
    a5f4:      	strb	w11, [x0, x9]
    a5f8:      	sub	x9, x9, #0x1
    a5fc:      	b	0xa5dc <JNI_OnLoad+0x13a0>
    a600:      	ret
    a604:      	sub	sp, sp, #0x50
    a608:      	stp	x29, x30, [sp, #0x10]
    a60c:      	str	x23, [sp, #0x20]
    a610:      	stp	x22, x21, [sp, #0x30]
    a614:      	stp	x20, x19, [sp, #0x40]
    a618:      	add	x29, sp, #0x10
    a61c:      	mrs	x22, TPIDR_EL0
    a620:      	mov	w19, w2
    a624:      	mov	x20, x0
    a628:      	ldr	x9, [x22, #0x28]
    a62c:      	mov	x8, xzr
    a630:      	str	x9, [sp, #0x8]
    a634:      	mov	x9, sp
    a638:      	cmp	x8, #0x8
    a63c:      	b.eq	0xa64c <JNI_OnLoad+0x1410>
    a640:      	strb	w1, [x9, x8]
    a644:      	add	x8, x8, #0x1
    a648:      	b	0xa638 <JNI_OnLoad+0x13fc>
    a64c:      	mov	w23, #0x8               // =8
    a650:      	cmp	w19, #0x1
    a654:      	b.lt	0xa678 <JNI_OnLoad+0x143c>
    a658:      	cmp	w19, #0x8
    a65c:      	mov	x1, sp
    a660:      	mov	x0, x20
    a664:      	csel	w21, w19, w23, lt
    a668:      	mov	w2, w21
    a66c:      	bl	0xa430 <JNI_OnLoad+0x11f4>
    a670:      	sub	w19, w19, w21
    a674:      	b	0xa650 <JNI_OnLoad+0x1414>
    a678:      	ldr	x8, [x22, #0x28]
    a67c:      	ldr	x9, [sp, #0x8]
    a680:      	cmp	x8, x9
    a684:      	b.ne	0xa6a0 <JNI_OnLoad+0x1464>
    a688:      	ldp	x20, x19, [sp, #0x40]
    a68c:      	ldr	x23, [sp, #0x20]
    a690:      	ldp	x22, x21, [sp, #0x30]
    a694:      	ldp	x29, x30, [sp, #0x10]
    a698:      	add	sp, sp, #0x50
    a69c:      	ret
    a6a0:      	bl	0xd110 <__stack_chk_fail@plt>
    a6a4:      	sub	sp, sp, #0x120
    a6a8:      	stp	x29, x30, [sp, #0x100]
    a6ac:      	stp	x28, x19, [sp, #0x110]
    a6b0:      	add	x29, sp, #0x100
    a6b4:      	stp	x3, x4, [x29, #-0x78]
    a6b8:      	sub	x9, x29, #0x78
    a6bc:      	mov	x10, sp
    a6c0:      	stp	x5, x6, [x29, #-0x68]
    a6c4:      	add	x10, x10, #0x80
    a6c8:      	sub	x3, x29, #0x50
    a6cc:      	stur	x7, [x29, #-0x58]
    a6d0:      	stp	q0, q1, [sp]
    a6d4:      	stp	q2, q3, [sp, #0x20]
    a6d8:      	bl	0xcb78 <JNI_OnLoad+0x393c>
    a6dc:      	add	x8, x9, #0x28
    a6e0:      	add	x9, x29, #0x20
    a6e4:      	stp	x9, x8, [x29, #-0x28]
    a6e8:      	mov	x8, #-0x28              // =-40
    a6ec:      	bl	0xcba0 <JNI_OnLoad+0x3964>
    a6f0:      	bl	0x9f54 <JNI_OnLoad+0xd18>
    a6f4:      	ldr	x8, [x19, #0x28]
    a6f8:      	bl	0xca50 <JNI_OnLoad+0x3814>
    a6fc:      	b.ne	0xa710 <JNI_OnLoad+0x14d4>
    a700:      	ldp	x28, x19, [sp, #0x110]
    a704:      	ldp	x29, x30, [sp, #0x100]
    a708:      	add	sp, sp, #0x120
    a70c:      	ret
    a710:      	bl	0xd110 <__stack_chk_fail@plt>
    a714:      	stp	x29, x30, [sp, #-0x30]!
    a718:      	str	x21, [sp, #0x10]
    a71c:      	stp	x20, x19, [sp, #0x20]
    a720:      	mov	x29, sp
    a724:      	mov	x19, x1
    a728:      	mov	x21, x0
    a72c:      	bl	0x4974 <.text+0x50>
    a730:      	mov	x20, x0
    a734:      	mov	x0, x21
    a738:      	bl	0x83e0 <.text+0x3abc>
    a73c:      	ldr	w8, [x19, #0x48]
    a740:      	mov	x21, x0
    a744:      	cbnz	w8, 0xa788 <JNI_OnLoad+0x154c>
    a748:      	ldr	x8, [x19, #0x38]
    a74c:      	add	x9, x8, #0x8
    a750:      	subs	x8, x8, #0x8
    a754:      	ccmp	x20, x9, #0x2, hs
    a758:      	ccmp	x20, x8, #0x0, ls
    a75c:      	b.hs	0xa780 <JNI_OnLoad+0x1544>
    a760:      	ldr	x8, [x19, #0x40]
    a764:      	add	x9, x8, #0x8
    a768:      	subs	x8, x8, #0x8
    a76c:      	ccmp	x20, x9, #0x2, hs
    a770:      	ccmp	x20, x8, #0x0, ls
    a774:      	b.hs	0xa780 <JNI_OnLoad+0x1544>
    a778:      	mov	w0, wzr
    a77c:      	b	0xa7c4 <JNI_OnLoad+0x1588>
    a780:      	mov	w8, #0x1                // =1
    a784:      	str	w8, [x19, #0x48]
    a788:      	ldr	x8, [x19]
    a78c:      	cbz	x8, 0xa7a8 <JNI_OnLoad+0x156c>
    a790:      	ldr	x8, [x19, #0x28]
    a794:      	cmp	x20, x8
    a798:      	b.ne	0xa7a8 <JNI_OnLoad+0x156c>
    a79c:      	ldr	x8, [x19, #0x30]
    a7a0:      	cmp	x21, x8
    a7a4:      	b.eq	0xa7b8 <JNI_OnLoad+0x157c>
    a7a8:      	mov	x0, x19
    a7ac:      	mov	x1, x20
    a7b0:      	bl	0xa7d4 <JNI_OnLoad+0x1598>
    a7b4:      	cbz	w0, 0xa7c0 <JNI_OnLoad+0x1584>
    a7b8:      	mov	w0, #0x5                // =5
    a7bc:      	b	0xa7c4 <JNI_OnLoad+0x1588>
    a7c0:      	stp	x20, x21, [x19, #0x28]
    a7c4:      	ldp	x20, x19, [sp, #0x20]
    a7c8:      	ldr	x21, [sp, #0x10]
    a7cc:      	ldp	x29, x30, [sp], #0x30
    a7d0:      	ret
    a7d4:      	sub	sp, sp, #0x60
    a7d8:      	stp	x29, x30, [sp, #0x30]
    a7dc:      	str	x21, [sp, #0x40]
    a7e0:      	stp	x20, x19, [sp, #0x50]
    a7e4:      	add	x29, sp, #0x30
    a7e8:      	mrs	x21, TPIDR_EL0
    a7ec:      	mov	x20, x1
    a7f0:      	mov	x19, x0
    a7f4:      	ldr	x8, [x21, #0x28]
    a7f8:      	add	x1, sp, #0x8
    a7fc:      	mov	x0, x20
    a800:      	stur	x8, [x29, #-0x8]
    a804:      	bl	0xcfc0 <dladdr@plt>
    a808:      	cbz	w0, 0xa818 <JNI_OnLoad+0x15dc>
    a80c:      	ldr	x8, [sp, #0x10]
    a810:      	cmp	x8, x20
    a814:      	b.ls	0xa840 <JNI_OnLoad+0x1604>
    a818:      	ldp	x9, x8, [x19, #0x18]
    a81c:      	adrp	x2, 0x3000
    a820:      	add	x2, x2, #0x36
    a824:      	ldr	x10, [x19, #0x10]
    a828:      	ldr	x3, [x19]
    a82c:      	mov	x4, x20
    a830:      	sub	x1, x9, x8
    a834:      	add	x0, x10, x8
    a838:      	bl	0xa6a4 <JNI_OnLoad+0x1468>
    a83c:      	b	0xa8c8 <JNI_OnLoad+0x168c>
    a840:      	ldr	x5, [sp, #0x8]
    a844:      	cbz	x5, 0xa89c <JNI_OnLoad+0x1660>
    a848:      	ldrb	w9, [x5]
    a84c:      	cbz	w9, 0xa89c <JNI_OnLoad+0x1660>
    a850:      	ldr	x6, [sp, #0x18]
    a854:      	cbz	x6, 0xa8b0 <JNI_OnLoad+0x1674>
    a858:      	ldrb	w9, [x6]
    a85c:      	cbz	w9, 0xa8b0 <JNI_OnLoad+0x1674>
    a860:      	ldp	x12, x9, [x19, #0x18]
    a864:      	sub	x4, x20, x8
    a868:      	ldr	x11, [sp, #0x20]
    a86c:      	ldr	x10, [x19, #0x10]
    a870:      	ldr	x3, [x19]
    a874:      	sub	x1, x12, x9
    a878:      	cbz	x11, 0xa954 <JNI_OnLoad+0x1718>
    a87c:      	cmp	x11, x20
    a880:      	b.hi	0xa954 <JNI_OnLoad+0x1718>
    a884:      	sub	x7, x20, x11
    a888:      	adrp	x2, 0x2000
    a88c:      	add	x2, x2, #0x2b3
    a890:      	add	x0, x10, x9
    a894:      	bl	0xa6a4 <JNI_OnLoad+0x1468>
    a898:      	b	0xa8c8 <JNI_OnLoad+0x168c>
    a89c:      	bl	0xcd10 <JNI_OnLoad+0x3ad4>
    a8a0:      	adrp	x2, 0x1000
    a8a4:      	add	x2, x2, #0xe19
    a8a8:      	mov	x5, x8
    a8ac:      	b	0xa8bc <JNI_OnLoad+0x1680>
    a8b0:      	bl	0xcd10 <JNI_OnLoad+0x3ad4>
    a8b4:      	adrp	x2, 0x2000
    a8b8:      	add	x2, x2, #0x542
    a8bc:      	sub	x1, x10, x9
    a8c0:      	add	x0, x11, x9
    a8c4:      	bl	0xa6a4 <JNI_OnLoad+0x1468>
    a8c8:      	ldp	x8, x9, [x19, #0x18]
    a8cc:      	sub	x10, x8, x9
    a8d0:      	cmp	x0, x10
    a8d4:      	b.lo	0xa900 <JNI_OnLoad+0x16c4>
    a8d8:      	ldr	x9, [x19, #0x10]
    a8dc:      	add	x8, x9, x8
    a8e0:      	mov	w9, #0xa                // =10
    a8e4:      	sturb	w9, [x8, #-0x2]
    a8e8:      	ldp	x8, x9, [x19, #0x10]
    a8ec:      	add	x8, x8, x9
    a8f0:      	sturb	wzr, [x8, #-0x1]
    a8f4:      	ldp	x8, x9, [x19, #0x18]
    a8f8:      	mvn	x10, x9
    a8fc:      	add	x0, x8, x10
    a900:      	add	x9, x9, x0
    a904:      	sub	x8, x8, x9
    a908:      	str	x9, [x19, #0x20]
    a90c:      	cmp	x8, #0x14
    a910:      	b.hs	0xa91c <JNI_OnLoad+0x16e0>
    a914:      	mov	w0, #0x3ec              // =1004
    a918:      	b	0xa934 <JNI_OnLoad+0x16f8>
    a91c:      	ldr	x8, [x19]
    a920:      	mov	w9, #0x3ed              // =1005
    a924:      	add	x8, x8, #0x1
    a928:      	cmp	x8, #0x3f
    a92c:      	str	x8, [x19]
    a930:      	csel	w0, w9, wzr, hi
    a934:      	ldr	x8, [x21, #0x28]
    a938:      	bl	0xca50 <JNI_OnLoad+0x3814>
    a93c:      	b.ne	0xa968 <JNI_OnLoad+0x172c>
    a940:      	ldp	x20, x19, [sp, #0x50]
    a944:      	ldr	x21, [sp, #0x40]
    a948:      	ldp	x29, x30, [sp, #0x30]
    a94c:      	add	sp, sp, #0x60
    a950:      	ret
    a954:      	adrp	x2, 0x2000
    a958:      	add	x2, x2, #0x7d8
    a95c:      	add	x0, x10, x9
    a960:      	bl	0xa6a4 <JNI_OnLoad+0x1468>
    a964:      	b	0xa8c8 <JNI_OnLoad+0x168c>
    a968:      	bl	0xd110 <__stack_chk_fail@plt>
    a96c:      	stp	x29, x30, [sp, #-0x20]!
    a970:      	str	x19, [sp, #0x10]
    a974:      	mov	x29, sp
    a978:      	mov	x19, x0
    a97c:      	cbz	x0, 0xa9ec <JNI_OnLoad+0x17b0>
    a980:      	mov	x0, x19
    a984:      	bl	0xce60 <strlen@plt>
    a988:      	cbz	x0, 0xa9ec <JNI_OnLoad+0x17b0>
    a98c:      	add	x8, x19, x0
    a990:      	cmp	x19, x8
    a994:      	b.hs	0xa9b4 <JNI_OnLoad+0x1778>
    a998:      	ldrb	w9, [x19]
    a99c:      	sub	w10, w9, #0xe
    a9a0:      	cmp	w9, #0x20
    a9a4:      	ccmn	w10, #0x5, #0x2, ne
    a9a8:      	b.lo	0xa9b4 <JNI_OnLoad+0x1778>
    a9ac:      	add	x19, x19, #0x1
    a9b0:      	b	0xa990 <JNI_OnLoad+0x1754>
    a9b4:      	cmp	x19, x8
    a9b8:      	b.eq	0xa9e8 <JNI_OnLoad+0x17ac>
    a9bc:      	mov	x9, x8
    a9c0:      	cmp	x19, x8
    a9c4:      	b.hs	0xa9e0 <JNI_OnLoad+0x17a4>
    a9c8:      	mov	x8, x9
    a9cc:      	ldrb	w10, [x8, #-0x1]!
    a9d0:      	sub	w11, w10, #0xe
    a9d4:      	cmp	w10, #0x20
    a9d8:      	ccmn	w11, #0x6, #0x2, ne
    a9dc:      	b.hi	0xa9bc <JNI_OnLoad+0x1780>
    a9e0:      	strb	wzr, [x9]
    a9e4:      	b	0xa9ec <JNI_OnLoad+0x17b0>
    a9e8:      	mov	x19, x8
    a9ec:      	mov	x0, x19
    a9f0:      	ldr	x19, [sp, #0x10]
    a9f4:      	ldp	x29, x30, [sp], #0x20
    a9f8:      	ret
    a9fc:      	tbnz	w0, #0x1f, 0xaa6c <JNI_OnLoad+0x1830>
    aa00:      	stp	x29, x30, [sp, #-0x30]!
    aa04:      	stp	x22, x21, [sp, #0x10]
    aa08:      	stp	x20, x19, [sp, #0x20]
    aa0c:      	mov	x29, sp
    aa10:      	mov	x19, x2
    aa14:      	mov	w20, w0
    aa18:      	mov	x21, x1
    aa1c:      	cbz	x2, 0xaa64 <JNI_OnLoad+0x1828>
    aa20:      	bl	0xcd80 <__errno@plt>
    aa24:      	mov	x22, x0
    aa28:      	str	wzr, [x0]
    aa2c:      	mov	w0, w20
    aa30:      	mov	x1, x21
    aa34:      	mov	x2, x19
    aa38:      	bl	0xcf20 <write@plt>
    aa3c:      	cmp	x0, #0x0
    aa40:      	b.gt	0xaa58 <JNI_OnLoad+0x181c>
    aa44:      	ldr	w8, [x22]
    aa48:      	cbz	x0, 0xaa74 <JNI_OnLoad+0x1838>
    aa4c:      	cmp	w8, #0x4
    aa50:      	b.ne	0xaa74 <JNI_OnLoad+0x1838>
    aa54:      	mov	x0, xzr
    aa58:      	sub	x19, x19, x0
    aa5c:      	add	x21, x21, x0
    aa60:      	cbnz	x19, 0xaa20 <JNI_OnLoad+0x17e4>
    aa64:      	mov	w0, wzr
    aa68:      	b	0xaa80 <JNI_OnLoad+0x1844>
    aa6c:      	mov	w0, #0x3ea              // =1002
    aa70:      	ret
    aa74:      	cmp	w8, #0x0
    aa78:      	mov	w9, #0x3e9              // =1001
    aa7c:      	csel	w0, w9, w8, eq
    aa80:      	ldp	x20, x19, [sp, #0x20]
    aa84:      	ldp	x22, x21, [sp, #0x10]
    aa88:      	ldp	x29, x30, [sp], #0x30
    aa8c:      	ret
    aa90:      	tbnz	w0, #0x1f, 0xaaac <JNI_OnLoad+0x1870>
    aa94:      	sub	x8, x1, #0x1
    aa98:      	ldrb	w9, [x8, #0x1]!
    aa9c:      	cbnz	w9, 0xaa98 <JNI_OnLoad+0x185c>
    aaa0:      	subs	x2, x8, x1
    aaa4:      	b.eq	0xaab4 <JNI_OnLoad+0x1878>
    aaa8:      	b	0xa9fc <JNI_OnLoad+0x17c0>
    aaac:      	mov	w0, #0x3ea              // =1002
    aab0:      	ret
    aab4:      	mov	w0, wzr
    aab8:      	ret
    aabc:      	stp	x29, x30, [sp, #-0x30]!
    aac0:      	str	x28, [sp, #0x10]
    aac4:      	mov	x29, sp
    aac8:      	stp	x20, x19, [sp, #0x20]
    aacc:      	sub	sp, sp, #0x500
    aad0:      	stp	x2, x3, [sp, #0x80]
    aad4:      	stp	x4, x5, [sp, #0x90]
    aad8:      	stp	x6, x7, [sp, #0xa0]
    aadc:      	stp	q0, q1, [sp]
    aae0:      	stp	q2, q3, [sp, #0x20]
    aae4:      	stp	q4, q5, [sp, #0x40]
    aae8:      	stp	q6, q7, [sp, #0x60]
    aaec:      	mrs	x20, TPIDR_EL0
    aaf0:      	ldr	x9, [x20, #0x28]
    aaf4:      	stur	x9, [x29, #-0x8]
    aaf8:      	tbnz	w0, #0x1f, 0xab5c <JNI_OnLoad+0x1920>
    aafc:      	add	x10, sp, #0x80
    ab00:      	add	x9, x29, #0x30
    ab04:      	mov	x11, sp
    ab08:      	add	x10, x10, #0x30
    ab0c:      	add	x11, x11, #0x80
    ab10:      	mov	x8, x1
    ab14:      	stp	x9, x10, [sp, #0xd8]
    ab18:      	mov	x9, #-0x30              // =-48
    ab1c:      	add	x10, sp, #0xd8
    ab20:      	movk	x9, #0xff80, lsl #32
    ab24:      	mov	w19, w0
    ab28:      	add	x0, sp, #0xf8
    ab2c:      	stp	x11, x9, [sp, #0xe8]
    ab30:      	add	x3, sp, #0xb0
    ab34:      	mov	w1, #0x400              // =1024
    ab38:      	ldp	q0, q1, [x10]
    ab3c:      	mov	x2, x8
    ab40:      	stp	q0, q1, [sp, #0xb0]
    ab44:      	bl	0x9f54 <JNI_OnLoad+0xd18>
    ab48:      	cbz	x0, 0xab5c <JNI_OnLoad+0x1920>
    ab4c:      	mov	x2, x0
    ab50:      	add	x1, sp, #0xf8
    ab54:      	mov	w0, w19
    ab58:      	bl	0xa9fc <JNI_OnLoad+0x17c0>
    ab5c:      	ldr	x8, [x20, #0x28]
    ab60:      	bl	0xca50 <JNI_OnLoad+0x3814>
    ab64:      	b.ne	0xab7c <JNI_OnLoad+0x1940>
    ab68:      	add	sp, sp, #0x500
    ab6c:      	ldp	x20, x19, [sp, #0x20]
    ab70:      	ldr	x28, [sp, #0x10]
    ab74:      	ldp	x29, x30, [sp], #0x30
    ab78:      	ret
    ab7c:      	bl	0xd110 <__stack_chk_fail@plt>
    ab80:      	sub	sp, sp, #0x160
    ab84:      	stp	x29, x30, [sp, #0x110]
    ab88:      	stp	x28, x25, [sp, #0x120]
    ab8c:      	stp	x24, x23, [sp, #0x130]
    ab90:      	stp	x22, x21, [sp, #0x140]
    ab94:      	stp	x20, x19, [sp, #0x150]
    ab98:      	add	x29, sp, #0x110
    ab9c:      	mrs	x24, TPIDR_EL0
    aba0:      	mov	x20, x2
    aba4:      	mov	x19, x1
    aba8:      	ldr	x8, [x24, #0x28]
    abac:      	mov	x23, x0
    abb0:      	stur	x8, [x29, #-0x8]
    abb4:      	bl	0xcd80 <__errno@plt>
    abb8:      	mov	x22, x0
    abbc:      	mov	x0, x23
    abc0:      	mov	w1, #0x80000            // =524288
    abc4:      	str	wzr, [x22]
    abc8:      	bl	0xce00 <__open_2@plt>
    abcc:      	cmn	w0, #0x1
    abd0:      	b.ne	0xabe4 <JNI_OnLoad+0x19a8>
    abd4:      	ldr	w8, [x22]
    abd8:      	cmp	w8, #0x4
    abdc:      	b.eq	0xabbc <JNI_OnLoad+0x1980>
    abe0:      	b	0xacac <JNI_OnLoad+0x1a70>
    abe4:      	mov	w21, w0
    abe8:      	tbnz	w0, #0x1f, 0xaca8 <JNI_OnLoad+0x1a6c>
    abec:      	add	x23, sp, #0x8
    abf0:      	mov	w25, #0xff              // =255
    abf4:      	strb	wzr, [sp, #0x8]
    abf8:      	cbz	x25, 0xac40 <JNI_OnLoad+0x1a04>
    abfc:      	add	x1, sp, #0x4
    ac00:      	mov	w0, w21
    ac04:      	mov	w2, #0x1                // =1
    ac08:      	bl	0xce50 <read@plt>
    ac0c:      	cmp	x0, #0x1
    ac10:      	b.eq	0xac28 <JNI_OnLoad+0x19ec>
    ac14:      	cbz	x0, 0xac40 <JNI_OnLoad+0x1a04>
    ac18:      	ldr	w8, [x22]
    ac1c:      	cmp	w8, #0x4
    ac20:      	b.eq	0xac38 <JNI_OnLoad+0x19fc>
    ac24:      	b	0xac54 <JNI_OnLoad+0x1a18>
    ac28:      	ldrb	w8, [sp, #0x4]
    ac2c:      	cmp	w8, #0xa
    ac30:      	strb	w8, [x23], #0x1
    ac34:      	b.eq	0xac40 <JNI_OnLoad+0x1a04>
    ac38:      	sub	x25, x25, #0x1
    ac3c:      	cbnz	x25, 0xabfc <JNI_OnLoad+0x19c0>
    ac40:      	strb	wzr, [x23]
    ac44:      	mov	w23, wzr
    ac48:      	ldrb	w8, [sp, #0x8]
    ac4c:      	cbnz	w8, 0xac60 <JNI_OnLoad+0x1a24>
    ac50:      	ldr	w8, [x22]
    ac54:      	cmp	w8, #0x0
    ac58:      	mov	w9, #0x3e9              // =1001
    ac5c:      	csel	w23, w9, w8, eq
    ac60:      	mov	w0, w21
    ac64:      	bl	0xcde0 <close@plt>
    ac68:      	cbnz	w23, 0xacb8 <JNI_OnLoad+0x1a7c>
    ac6c:      	add	x0, sp, #0x8
    ac70:      	bl	0xa96c <JNI_OnLoad+0x1730>
    ac74:      	mov	x21, x0
    ac78:      	bl	0xce60 <strlen@plt>
    ac7c:      	cbz	x0, 0xace4 <JNI_OnLoad+0x1aa8>
    ac80:      	sub	x8, x20, #0x1
    ac84:      	mov	x1, x21
    ac88:      	cmp	x8, x0
    ac8c:      	csel	x20, x8, x0, lo
    ac90:      	mov	x0, x19
    ac94:      	mov	x2, x20
    ac98:      	bl	0xd0b0 <memcpy@plt>
    ac9c:      	mov	w23, wzr
    aca0:      	strb	wzr, [x19, x20]
    aca4:      	b	0xacb8 <JNI_OnLoad+0x1a7c>
    aca8:      	ldr	w8, [x22]
    acac:      	cmp	w8, #0x0
    acb0:      	mov	w9, #0x3e9              // =1001
    acb4:      	csel	w23, w9, w8, eq
    acb8:      	ldr	x8, [x24, #0x28]
    acbc:      	bl	0xca50 <JNI_OnLoad+0x3814>
    acc0:      	b.ne	0xacec <JNI_OnLoad+0x1ab0>
    acc4:      	mov	w0, w23
    acc8:      	ldp	x20, x19, [sp, #0x150]
    accc:      	ldp	x22, x21, [sp, #0x140]
    acd0:      	ldp	x24, x23, [sp, #0x130]
    acd4:      	ldp	x28, x25, [sp, #0x120]
    acd8:      	ldp	x29, x30, [sp, #0x110]
    acdc:      	add	sp, sp, #0x160
    ace0:      	ret
    ace4:      	mov	w23, #0x3ef             // =1007
    ace8:      	b	0xacb8 <JNI_OnLoad+0x1a7c>
    acec:      	bl	0xd110 <__stack_chk_fail@plt>
    acf0:      	stp	x29, x30, [sp, #-0x60]!
    acf4:      	bl	0xc9f0 <JNI_OnLoad+0x37b4>
    acf8:      	sub	sp, sp, #0x240
    acfc:      	mrs	x23, TPIDR_EL0
    ad00:      	mov	x20, x0
    ad04:      	mov	w0, #0x1                // =1
    ad08:      	ldr	x8, [x23, #0x28]
    ad0c:      	mov	w1, #0x38               // =56
    ad10:      	stur	x8, [x29, #-0x10]
    ad14:      	bl	0xce70 <calloc@plt>
    ad18:      	mov	x19, x0
    ad1c:      	str	x0, [sp, #0x18]
    ad20:      	cbz	x0, 0xae0c <JNI_OnLoad+0x1bd0>
    ad24:      	mov	w8, #-0x1               // =-1
    ad28:      	mov	x9, #-0x1               // =-1
    ad2c:      	adrp	x0, 0x1000
    ad30:      	add	x0, x0, #0xbaa
    ad34:      	str	w8, [x19, #0x8]
    ad38:      	add	x8, x19, #0x28
    ad3c:      	adrp	x1, 0x2000
    ad40:      	add	x1, x1, #0x7f7
    ad44:      	str	x9, [x19, #0x10]
    ad48:      	str	x8, [x19, #0x30]
    ad4c:      	bl	0xcfd0 <fopen@plt>
    ad50:      	cbz	x0, 0xae00 <JNI_OnLoad+0x1bc4>
    ad54:      	mov	x21, x0
    ad58:      	add	x24, sp, #0x30
    ad5c:      	adrp	x22, 0x2000
    ad60:      	add	x22, x22, #0x202
    ad64:      	add	x0, sp, #0x30
    ad68:      	mov	w1, #0x200              // =512
    ad6c:      	mov	x2, x21
    ad70:      	bl	0xd000 <fgets@plt>
    ad74:      	cbz	x0, 0xadf8 <JNI_OnLoad+0x1bbc>
    ad78:      	add	x0, sp, #0x30
    ad7c:      	add	x3, sp, #0x28
    ad80:      	add	x4, sp, #0x24
    ad84:      	mov	x1, x22
    ad88:      	mov	x2, x19
    ad8c:      	bl	0xd040 <sscanf@plt>
    ad90:      	cmp	w0, #0x2
    ad94:      	b.ne	0xad64 <JNI_OnLoad+0x1b28>
    ad98:      	ldr	x8, [sp, #0x28]
    ad9c:      	cbnz	x8, 0xad64 <JNI_OnLoad+0x1b28>
    ada0:      	ldrsw	x8, [sp, #0x24]
    ada4:      	add	x0, x24, x8
    ada8:      	bl	0xa96c <JNI_OnLoad+0x1730>
    adac:      	mov	x1, x20
    adb0:      	bl	0xd030 <strcmp@plt>
    adb4:      	cbnz	w0, 0xad64 <JNI_OnLoad+0x1b28>
    adb8:      	mov	x0, x21
    adbc:      	bl	0xcfe0 <fclose@plt>
    adc0:      	bl	0xcd80 <__errno@plt>
    adc4:      	mov	x21, x0
    adc8:      	mov	x0, x20
    adcc:      	mov	w1, #0x80000            // =524288
    add0:      	str	wzr, [x21]
    add4:      	bl	0xce00 <__open_2@plt>
    add8:      	cmn	w0, #0x1
    addc:      	b.ne	0xae30 <JNI_OnLoad+0x1bf4>
    ade0:      	ldr	w8, [x21]
    ade4:      	cmp	w8, #0x4
    ade8:      	b.eq	0xadc8 <JNI_OnLoad+0x1b8c>
    adec:      	mov	w8, #-0x1               // =-1
    adf0:      	str	w8, [x19, #0x8]
    adf4:      	b	0xae00 <JNI_OnLoad+0x1bc4>
    adf8:      	mov	x0, x21
    adfc:      	bl	0xcfe0 <fclose@plt>
    ae00:      	add	x0, sp, #0x18
    ae04:      	bl	0xaff4 <JNI_OnLoad+0x1db8>
    ae08:      	mov	x19, xzr
    ae0c:      	ldr	x8, [x23, #0x28]
    ae10:      	ldur	x9, [x29, #-0x10]
    ae14:      	cmp	x8, x9
    ae18:      	b.ne	0xaff0 <JNI_OnLoad+0x1db4>
    ae1c:      	mov	x0, x19
    ae20:      	add	sp, sp, #0x240
    ae24:      	bl	0xca1c <JNI_OnLoad+0x37e0>
    ae28:      	ldp	x29, x30, [sp], #0x60
    ae2c:      	ret
    ae30:      	str	w0, [x19, #0x8]
    ae34:      	tbnz	w0, #0x1f, 0xae00 <JNI_OnLoad+0x1bc4>
    ae38:      	add	x1, sp, #0x30
    ae3c:      	bl	0xd050 <fstat@plt>
    ae40:      	cbnz	w0, 0xae00 <JNI_OnLoad+0x1bc4>
    ae44:      	ldr	x1, [sp, #0x60]
    ae48:      	cbz	x1, 0xae00 <JNI_OnLoad+0x1bc4>
    ae4c:      	ldr	w4, [x19, #0x8]
    ae50:      	mov	x0, xzr
    ae54:      	mov	w2, #0x1                // =1
    ae58:      	mov	w3, #0x2                // =2
    ae5c:      	mov	x5, xzr
    ae60:      	str	x1, [x19, #0x18]
    ae64:      	bl	0xd060 <mmap@plt>
    ae68:      	cmn	x0, #0x1
    ae6c:      	str	x0, [x19, #0x10]
    ae70:      	b.eq	0xae00 <JNI_OnLoad+0x1bc4>
    ae74:      	ldr	x21, [x19, #0x18]
    ae78:      	cmp	x21, #0x40
    ae7c:      	b.lo	0xae00 <JNI_OnLoad+0x1bc4>
    ae80:      	mov	x20, x0
    ae84:      	cbz	x0, 0xae00 <JNI_OnLoad+0x1bc4>
    ae88:      	ldrh	w9, [x20, #0x38]
    ae8c:      	ldrh	w8, [x20, #0x36]
    ae90:      	mov	x10, xzr
    ae94:      	umull	x9, w8, w9
    ae98:      	cmp	x10, x9
    ae9c:      	b.hs	0xaef4 <JNI_OnLoad+0x1cb8>
    aea0:      	ldr	x12, [x20, #0x20]
    aea4:      	add	x11, x10, x12
    aea8:      	add	x13, x11, #0x38
    aeac:      	cmp	x13, x21
    aeb0:      	b.hi	0xae00 <JNI_OnLoad+0x1bc4>
    aeb4:      	add	x13, x20, x12
    aeb8:      	ldr	w14, [x13, x10]
    aebc:      	cmp	w14, #0x1
    aec0:      	b.ne	0xaee0 <JNI_OnLoad+0x1ca4>
    aec4:      	add	x13, x13, x10
    aec8:      	ldrb	w13, [x13, #0x4]
    aecc:      	tbz	w13, #0x0, 0xaee0 <JNI_OnLoad+0x1ca4>
    aed0:      	add	x12, x20, x12
    aed4:      	add	x12, x12, x10
    aed8:      	ldr	x12, [x12, #0x8]
    aedc:      	cbz	x12, 0xaee8 <JNI_OnLoad+0x1cac>
    aee0:      	add	x10, x10, x8
    aee4:      	b	0xae98 <JNI_OnLoad+0x1c5c>
    aee8:      	add	x8, x20, x11
    aeec:      	ldr	x8, [x8, #0x10]
    aef0:      	str	x8, [x19, #0x20]
    aef4:      	ldrh	w14, [x20, #0x3a]
    aef8:      	ldrh	w24, [x20, #0x3c]
    aefc:      	mov	x12, xzr
    af00:      	umull	x26, w14, w24
    af04:      	add	x27, x14, #0x20
    af08:      	str	x14, [sp, #0x8]
    af0c:      	sub	x8, x27, #0x20
    af10:      	cmp	x8, x26
    af14:      	b.hs	0xafe8 <JNI_OnLoad+0x1dac>
    af18:      	ldr	x28, [x20, #0x28]
    af1c:      	add	x8, x27, x28
    af20:      	add	x8, x8, #0x20
    af24:      	cmp	x8, x21
    af28:      	b.hi	0xae00 <JNI_OnLoad+0x1bc4>
    af2c:      	ldr	x22, [x19, #0x10]
    af30:      	cbz	x22, 0xae00 <JNI_OnLoad+0x1bc4>
    af34:      	add	x8, x22, x28
    af38:      	add	x8, x8, x27
    af3c:      	ldur	w9, [x8, #-0x1c]
    af40:      	cmp	w9, #0xb
    af44:      	ccmp	w9, #0x2, #0x4, ne
    af48:      	b.ne	0xafe0 <JNI_OnLoad+0x1da4>
    af4c:      	ldr	w8, [x8, #0x8]
    af50:      	cmp	w8, w24
    af54:      	b.hs	0xafe0 <JNI_OnLoad+0x1da4>
    af58:      	umaddl	x8, w8, w14, x28
    af5c:      	add	x9, x8, #0x40
    af60:      	cmp	x9, x21
    af64:      	b.hi	0xae00 <JNI_OnLoad+0x1bc4>
    af68:      	add	x25, x22, x8
    af6c:      	ldr	w8, [x25, #0x4]
    af70:      	cmp	w8, #0x3
    af74:      	b.ne	0xafe0 <JNI_OnLoad+0x1da4>
    af78:      	mov	w0, #0x38               // =56
    af7c:      	str	x12, [sp, #0x10]
    af80:      	bl	0xcf30 <malloc@plt>
    af84:      	ldp	x14, x12, [sp, #0x8]
    af88:      	cbz	x0, 0xae00 <JNI_OnLoad+0x1bc4>
    af8c:      	add	x8, x22, x28
    af90:      	add	x12, x12, #0x1
    af94:      	add	x8, x8, x27
    af98:      	ldur	x9, [x8, #-0x8]
    af9c:      	str	x9, [x0]
    afa0:      	ldr	x10, [x8]
    afa4:      	add	x9, x10, x9
    afa8:      	ldr	x10, [x19, #0x30]
    afac:      	str	x9, [x0, #0x8]
    afb0:      	mov	x9, x0
    afb4:      	ldr	x8, [x8, #0x18]
    afb8:      	str	x8, [x0, #0x10]
    afbc:      	ldr	x8, [x25, #0x18]
    afc0:      	str	x8, [x0, #0x18]
    afc4:      	ldr	x11, [x25, #0x20]
    afc8:      	str	xzr, [x9, #0x28]!
    afcc:      	str	x10, [x0, #0x30]
    afd0:      	add	x8, x11, x8
    afd4:      	str	x8, [x0, #0x20]
    afd8:      	str	x0, [x10]
    afdc:      	str	x9, [x19, #0x30]
    afe0:      	add	x27, x27, x14
    afe4:      	b	0xaf0c <JNI_OnLoad+0x1cd0>
    afe8:      	cbnz	x12, 0xae0c <JNI_OnLoad+0x1bd0>
    afec:      	b	0xae00 <JNI_OnLoad+0x1bc4>
    aff0:      	bl	0xd110 <__stack_chk_fail@plt>
    aff4:      	cbz	x0, 0xb084 <JNI_OnLoad+0x1e48>
    aff8:      	stp	x29, x30, [sp, #-0x20]!
    affc:      	stp	x20, x19, [sp, #0x10]
    b000:      	mov	x29, sp
    b004:      	ldr	x8, [x0]
    b008:      	mov	x19, x0
    b00c:      	cbz	x8, 0xb07c <JNI_OnLoad+0x1e40>
    b010:      	ldr	x0, [x8, #0x10]
    b014:      	cmn	x0, #0x1
    b018:      	b.eq	0xb028 <JNI_OnLoad+0x1dec>
    b01c:      	ldr	x1, [x8, #0x18]
    b020:      	bl	0xd020 <munmap@plt>
    b024:      	ldr	x8, [x19]
    b028:      	ldr	w0, [x8, #0x8]
    b02c:      	tbnz	w0, #0x1f, 0xb038 <JNI_OnLoad+0x1dfc>
    b030:      	bl	0xcde0 <close@plt>
    b034:      	ldr	x8, [x19]
    b038:      	ldr	x0, [x8, #0x28]
    b03c:      	cbz	x0, 0xb070 <JNI_OnLoad+0x1e34>
    b040:      	ldr	x20, [x0, #0x28]
    b044:      	cbz	x20, 0xb050 <JNI_OnLoad+0x1e14>
    b048:      	add	x8, x20, #0x30
    b04c:      	b	0xb058 <JNI_OnLoad+0x1e1c>
    b050:      	ldr	x8, [x19]
    b054:      	add	x8, x8, #0x30
    b058:      	ldr	x9, [x0, #0x30]
    b05c:      	str	x9, [x8]
    b060:      	str	x20, [x9]
    b064:      	bl	0xcdc0 <free@plt>
    b068:      	mov	x0, x20
    b06c:      	cbnz	x20, 0xb040 <JNI_OnLoad+0x1e04>
    b070:      	ldr	x0, [x19]
    b074:      	bl	0xcdc0 <free@plt>
    b078:      	str	xzr, [x19]
    b07c:      	ldp	x20, x19, [sp, #0x10]
    b080:      	ldp	x29, x30, [sp], #0x20
    b084:      	ret
    b088:      	stp	x29, x30, [sp, #-0x40]!
    b08c:      	stp	x24, x23, [sp, #0x10]
    b090:      	stp	x22, x21, [sp, #0x20]
    b094:      	stp	x20, x19, [sp, #0x30]
    b098:      	mov	x29, sp
    b09c:      	mov	x20, x1
    b0a0:      	mov	x19, x0
    b0a4:      	add	x8, x0, #0x28
    b0a8:      	ldr	x21, [x8]
    b0ac:      	cbz	x21, 0xb148 <JNI_OnLoad+0x1f0c>
    b0b0:      	ldp	x22, x23, [x21]
    b0b4:      	cmp	x22, x23
    b0b8:      	b.hs	0xb128 <JNI_OnLoad+0x1eec>
    b0bc:      	ldr	x8, [x19, #0x18]
    b0c0:      	add	x9, x22, #0x18
    b0c4:      	cmp	x9, x8
    b0c8:      	b.hi	0xb128 <JNI_OnLoad+0x1eec>
    b0cc:      	ldr	x9, [x19, #0x10]
    b0d0:      	cbz	x9, 0xb128 <JNI_OnLoad+0x1eec>
    b0d4:      	add	x24, x9, x22
    b0d8:      	ldrh	w10, [x24, #0x6]
    b0dc:      	cbz	w10, 0xb11c <JNI_OnLoad+0x1ee0>
    b0e0:      	ldp	x11, x12, [x21, #0x18]
    b0e4:      	ldr	w10, [x24]
    b0e8:      	add	x10, x11, x10
    b0ec:      	cmp	x10, x12
    b0f0:      	b.hs	0xb11c <JNI_OnLoad+0x1ee0>
    b0f4:      	add	x1, x9, x10
    b0f8:      	add	x8, x9, x8
    b0fc:      	mov	x9, x1
    b100:      	cmp	x9, x8
    b104:      	b.hs	0xb11c <JNI_OnLoad+0x1ee0>
    b108:      	ldrb	w10, [x9], #0x1
    b10c:      	cbnz	w10, 0xb100 <JNI_OnLoad+0x1ec4>
    b110:      	mov	x0, x20
    b114:      	bl	0xd030 <strcmp@plt>
    b118:      	cbz	w0, 0xb130 <JNI_OnLoad+0x1ef4>
    b11c:      	ldr	x8, [x21, #0x10]
    b120:      	add	x22, x8, x22
    b124:      	b	0xb0b4 <JNI_OnLoad+0x1e78>
    b128:      	add	x8, x21, #0x28
    b12c:      	b	0xb0a8 <JNI_OnLoad+0x1e6c>
    b130:      	ldr	x8, [x19]
    b134:      	ldr	x9, [x24, #0x8]
    b138:      	ldr	x10, [x19, #0x20]
    b13c:      	add	x8, x9, x8
    b140:      	sub	x0, x8, x10
    b144:      	b	0xb14c <JNI_OnLoad+0x1f10>
    b148:      	mov	x0, xzr
    b14c:      	ldp	x20, x19, [sp, #0x30]
    b150:      	ldp	x22, x21, [sp, #0x20]
    b154:      	ldp	x24, x23, [sp, #0x10]
    b158:      	ldp	x29, x30, [sp], #0x40
    b15c:      	ret
    b160:      	stp	x29, x30, [sp, #-0x30]!
    b164:      	stp	x22, x21, [sp, #0x10]
    b168:      	stp	x20, x19, [sp, #0x20]
    b16c:      	mov	x29, sp
    b170:      	ldr	x8, [x0]
    b174:      	mov	x20, x2
    b178:      	mov	x1, x2
    b17c:      	mov	x2, xzr
    b180:      	mov	x19, x0
    b184:      	bl	0xca0c <JNI_OnLoad+0x37d0>
    b188:      	ldr	x8, [x19]
    b18c:      	mov	x21, x0
    b190:      	bl	0xc978 <JNI_OnLoad+0x373c>
    b194:      	tst	w0, #0xff
    b198:      	b.ne	0xb1cc <JNI_OnLoad+0x1f90>
    b19c:      	cbz	x21, 0xb1cc <JNI_OnLoad+0x1f90>
    b1a0:      	ldr	x8, [x19]
    b1a4:      	bl	0xcc5c <JNI_OnLoad+0x3a20>
    b1a8:      	bl	0xcaec <JNI_OnLoad+0x38b0>
    b1ac:      	ldr	x8, [x19]
    b1b0:      	mov	x22, x0
    b1b4:      	mov	x0, x19
    b1b8:      	mov	x1, x20
    b1bc:      	mov	x2, x21
    b1c0:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    b1c4:      	mov	x0, x22
    b1c8:      	b	0xb1f4 <JNI_OnLoad+0x1fb8>
    b1cc:      	cbz	x21, 0xb1e4 <JNI_OnLoad+0x1fa8>
    b1d0:      	ldr	x8, [x19]
    b1d4:      	mov	x0, x19
    b1d8:      	mov	x1, x20
    b1dc:      	mov	x2, x21
    b1e0:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    b1e4:      	adrp	x1, 0x2000
    b1e8:      	add	x1, x1, #0x7f9
    b1ec:      	bl	0xca70 <JNI_OnLoad+0x3834>
    b1f0:      	mov	x0, xzr
    b1f4:      	ldp	x20, x19, [sp, #0x20]
    b1f8:      	ldp	x22, x21, [sp, #0x10]
    b1fc:      	ldp	x29, x30, [sp], #0x30
    b200:      	ret
    b204:      	stp	x29, x30, [sp, #-0x30]!
    b208:      	str	x21, [sp, #0x10]
    b20c:      	stp	x20, x19, [sp, #0x20]
    b210:      	mov	x29, sp
    b214:      	ldr	x8, [x0]
    b218:      	mov	x20, x1
    b21c:      	adrp	x1, 0x2000
    b220:      	add	x1, x1, #0x457
    b224:      	mov	x19, x0
    b228:      	bl	0xcaec <JNI_OnLoad+0x38b0>
    b22c:      	ldr	x8, [x19]
    b230:      	mov	x21, x0
    b234:      	bl	0xcc5c <JNI_OnLoad+0x3a20>
    b238:      	mov	x2, x20
    b23c:      	ldr	x8, [x8, #0x70]
    b240:      	blr	x8
    b244:      	ldr	x8, [x19]
    b248:      	bl	0xcc5c <JNI_OnLoad+0x3a20>
    b24c:      	ldp	x20, x19, [sp, #0x20]
    b250:      	ldr	x21, [sp, #0x10]
    b254:      	ldr	x2, [x8, #0xb8]
    b258:      	ldp	x29, x30, [sp], #0x30
    b25c:      	br	x2
    b260:      	stp	x29, x30, [sp, #-0x60]!
    b264:      	bl	0xc9f0 <JNI_OnLoad+0x37b4>
    b268:      	sub	sp, sp, #0x50
    b26c:      	mrs	x23, TPIDR_EL0
    b270:      	mov	x25, x2
    b274:      	mov	x1, x3
    b278:      	ldr	x8, [x23, #0x28]
    b27c:      	mov	x2, xzr
    b280:      	mov	x26, x7
    b284:      	mov	x27, x6
    b288:      	mov	x24, x5
    b28c:      	mov	x19, x0
    b290:      	stur	x8, [x29, #-0x8]
    b294:      	mov	w28, w4
    b298:      	mov	x21, x3
    b29c:      	ldr	x8, [x0]
    b2a0:      	bl	0xca0c <JNI_OnLoad+0x37d0>
    b2a4:      	ldr	x8, [x19]
    b2a8:      	mov	x20, x0
    b2ac:      	bl	0xc978 <JNI_OnLoad+0x373c>
    b2b0:      	tst	w0, #0xff
    b2b4:      	mov	x22, xzr
    b2b8:      	b.ne	0xb49c <JNI_OnLoad+0x2260>
    b2bc:      	cbz	x20, 0xb430 <JNI_OnLoad+0x21f4>
    b2c0:      	bl	0xcbb8 <JNI_OnLoad+0x397c>
    b2c4:      	stur	w28, [x29, #-0x3c]
    b2c8:      	ldr	x8, [x8, #0x558]
    b2cc:      	stur	x25, [x29, #-0x48]
    b2d0:      	stur	x24, [x29, #-0x38]
    b2d4:      	stur	x20, [x29, #-0x18]
    b2d8:      	blr	x8
    b2dc:      	mov	x8, sp
    b2e0:      	mov	x9, sp
    b2e4:      	stur	x8, [x29, #-0x30]
    b2e8:      	ubfiz	x8, x0, #3, #32
    b2ec:      	add	x8, x8, #0xf
    b2f0:      	and	x8, x8, #0xffffffff0
    b2f4:      	sub	x9, x9, x8
    b2f8:      	stur	x9, [x29, #-0x10]
    b2fc:      	mov	sp, x9
    b300:      	mov	x9, sp
    b304:      	sub	x20, x9, x8
    b308:      	mov	sp, x20
    b30c:      	bic	w28, w0, w0, asr #31
    b310:      	mov	x9, x20
    b314:      	mov	x8, x28
    b318:      	cbz	x28, 0xb328 <JNI_OnLoad+0x20ec>
    b31c:      	str	xzr, [x9], #0x8
    b320:      	sub	x8, x8, #0x1
    b324:      	cbnz	x8, 0xb31c <JNI_OnLoad+0x20e0>
    b328:      	stp	x21, x23, [x29, #-0x28]
    b32c:      	mov	x22, xzr
    b330:      	mov	x21, xzr
    b334:      	ldr	x8, [x19]
    b338:      	cmp	x28, x22
    b33c:      	b.eq	0xb4bc <JNI_OnLoad+0x2280>
    b340:      	ldr	x8, [x8, #0x568]
    b344:      	mov	x0, x19
    b348:      	mov	x1, x27
    b34c:      	mov	w2, w22
    b350:      	blr	x8
    b354:      	ldr	x8, [x19]
    b358:      	mov	x24, x0
    b35c:      	bl	0xc978 <JNI_OnLoad+0x373c>
    b360:      	tst	w0, #0xff
    b364:      	b.ne	0xb450 <JNI_OnLoad+0x2214>
    b368:      	cbz	x24, 0xb444 <JNI_OnLoad+0x2208>
    b36c:      	ldr	x8, [x19]
    b370:      	mov	x0, x19
    b374:      	mov	x1, x24
    b378:      	mov	x2, xzr
    b37c:      	bl	0xca0c <JNI_OnLoad+0x37d0>
    b380:      	ldr	x8, [x19]
    b384:      	mov	x25, x0
    b388:      	bl	0xc978 <JNI_OnLoad+0x373c>
    b38c:      	tst	w0, #0xff
    b390:      	b.ne	0xb450 <JNI_OnLoad+0x2214>
    b394:      	cbz	x25, 0xb444 <JNI_OnLoad+0x2208>
    b398:      	cbz	x21, 0xb3b4 <JNI_OnLoad+0x2178>
    b39c:      	mov	x0, x21
    b3a0:      	bl	0xcc28 <JNI_OnLoad+0x39ec>
    b3a4:      	mov	x23, x0
    b3a8:      	bl	0xccec <JNI_OnLoad+0x3ab0>
    b3ac:      	mov	x21, x23
    b3b0:      	b	0xb3c4 <JNI_OnLoad+0x2188>
    b3b4:      	adrp	x0, 0x1000
    b3b8:      	add	x0, x0, #0xef3
    b3bc:      	bl	0xcc28 <JNI_OnLoad+0x39ec>
    b3c0:      	mov	x21, x0
    b3c4:      	ldr	x8, [x19]
    b3c8:      	mov	x0, x19
    b3cc:      	mov	x1, x26
    b3d0:      	mov	w2, w22
    b3d4:      	ldr	x8, [x8, #0x568]
    b3d8:      	blr	x8
    b3dc:      	mov	x2, x0
    b3e0:      	str	x0, [x20, x22, lsl #3]
    b3e4:      	mov	x0, x19
    b3e8:      	mov	x1, x25
    b3ec:      	bl	0xb658 <JNI_OnLoad+0x241c>
    b3f0:      	ldur	x9, [x29, #-0x10]
    b3f4:      	ldr	x8, [x19]
    b3f8:      	bl	0xccc8 <JNI_OnLoad+0x3a8c>
    b3fc:      	str	x0, [x9, x22, lsl #3]
    b400:      	mov	x0, x19
    b404:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    b408:      	ldr	x8, [x19]
    b40c:      	mov	x0, x19
    b410:      	mov	x1, x24
    b414:      	bl	0xca14 <JNI_OnLoad+0x37d8>
    b418:      	ldr	x8, [x19]
    b41c:      	bl	0xc978 <JNI_OnLoad+0x373c>
    b420:      	tst	w0, #0xff
    b424:      	add	x22, x22, #0x1
    b428:      	b.eq	0xb334 <JNI_OnLoad+0x20f8>
    b42c:      	b	0xb450 <JNI_OnLoad+0x2214>
    b430:      	adrp	x1, 0x2000
    b434:      	add	x1, x1, #0xaaa
    b438:      	bl	0xca70 <JNI_OnLoad+0x3834>
    b43c:      	mov	x22, xzr
    b440:      	b	0xb49c <JNI_OnLoad+0x2260>
    b444:      	adrp	x1, 0x2000
    b448:      	add	x1, x1, #0xd72
    b44c:      	bl	0xca70 <JNI_OnLoad+0x3834>
    b450:      	ldp	x24, x23, [x29, #-0x28]
    b454:      	mov	x22, xzr
    b458:      	ldur	x25, [x29, #-0x30]
    b45c:      	ldr	x8, [x19]
    b460:      	ldur	x2, [x29, #-0x18]
    b464:      	mov	x0, x19
    b468:      	mov	x1, x24
    b46c:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    b470:      	bl	0xccec <JNI_OnLoad+0x3ab0>
    b474:      	cbz	x28, 0xb498 <JNI_OnLoad+0x225c>
    b478:      	ldr	x1, [x20]
    b47c:      	cbz	x1, 0xb48c <JNI_OnLoad+0x2250>
    b480:      	bl	0xcc68 <JNI_OnLoad+0x3a2c>
    b484:      	bl	0xca14 <JNI_OnLoad+0x37d8>
    b488:      	str	xzr, [x20]
    b48c:      	add	x20, x20, #0x8
    b490:      	sub	x28, x28, #0x1
    b494:      	cbnz	x28, 0xb478 <JNI_OnLoad+0x223c>
    b498:      	mov	sp, x25
    b49c:      	ldr	x8, [x23, #0x28]
    b4a0:      	bl	0xca50 <JNI_OnLoad+0x3814>
    b4a4:      	b.ne	0xb5c8 <JNI_OnLoad+0x238c>
    b4a8:      	mov	x0, x22
    b4ac:      	mov	sp, x29
    b4b0:      	bl	0xca1c <JNI_OnLoad+0x37e0>
    b4b4:      	ldp	x29, x30, [sp], #0x60
    b4b8:      	ret
    b4bc:      	ldr	x8, [x8, #0x548]
    b4c0:      	ldur	x1, [x29, #-0x38]
    b4c4:      	mov	x0, x19
    b4c8:      	mov	x2, xzr
    b4cc:      	blr	x8
    b4d0:      	ldr	x8, [x19]
    b4d4:      	mov	x26, x0
    b4d8:      	bl	0xc978 <JNI_OnLoad+0x373c>
    b4dc:      	ldp	x24, x23, [x29, #-0x28]
    b4e0:      	tst	w0, #0xff
    b4e4:      	ldur	x25, [x29, #-0x30]
    b4e8:      	b.eq	0xb4f4 <JNI_OnLoad+0x22b8>
    b4ec:      	mov	x22, xzr
    b4f0:      	b	0xb45c <JNI_OnLoad+0x2220>
    b4f4:      	cbz	x26, 0xb514 <JNI_OnLoad+0x22d8>
    b4f8:      	ldur	w8, [x29, #-0x3c]
    b4fc:      	mov	x0, x19
    b500:      	tst	w8, #0xff
    b504:      	b.eq	0xb524 <JNI_OnLoad+0x22e8>
    b508:      	bl	0xccf4 <JNI_OnLoad+0x3ab8>
    b50c:      	bl	0xb7b8 <JNI_OnLoad+0x257c>
    b510:      	b	0xb52c <JNI_OnLoad+0x22f0>
    b514:      	adrp	x1, 0x2000
    b518:      	add	x1, x1, #0x59a
    b51c:      	bl	0xca70 <JNI_OnLoad+0x3834>
    b520:      	b	0xb4ec <JNI_OnLoad+0x22b0>
    b524:      	bl	0xccf4 <JNI_OnLoad+0x3ab8>
    b528:      	bl	0xba64 <JNI_OnLoad+0x2828>
    b52c:      	ldr	x8, [x19]
    b530:      	mov	x22, x0
    b534:      	bl	0xc978 <JNI_OnLoad+0x373c>
    b538:      	tst	w0, #0xff
    b53c:      	b.ne	0xb4ec <JNI_OnLoad+0x22b0>
    b540:      	ldur	x27, [x29, #-0x18]
    b544:      	mov	x0, x27
    b548:      	bl	0xbcb8 <JNI_OnLoad+0x2a7c>
    b54c:      	cmp	x0, #0x6
    b550:      	b.ne	0xb59c <JNI_OnLoad+0x2360>
    b554:      	ldrb	w8, [x27]
    b558:      	cmp	w8, #0x3c
    b55c:      	b.ne	0xb59c <JNI_OnLoad+0x2360>
    b560:      	ldrb	w8, [x27, #0x1]
    b564:      	cmp	w8, #0x69
    b568:      	b.ne	0xb59c <JNI_OnLoad+0x2360>
    b56c:      	ldrb	w8, [x27, #0x2]
    b570:      	cmp	w8, #0x6e
    b574:      	b.ne	0xb59c <JNI_OnLoad+0x2360>
    b578:      	ldrb	w8, [x27, #0x3]
    b57c:      	cmp	w8, #0x69
    b580:      	b.ne	0xb59c <JNI_OnLoad+0x2360>
    b584:      	ldrb	w8, [x27, #0x4]
    b588:      	cmp	w8, #0x74
    b58c:      	b.ne	0xb59c <JNI_OnLoad+0x2360>
    b590:      	ldrb	w8, [x27, #0x5]
    b594:      	cmp	w8, #0x3e
    b598:      	b.eq	0xb5b0 <JNI_OnLoad+0x2374>
    b59c:      	mov	x0, x19
    b5a0:      	mov	x1, x26
    b5a4:      	mov	x2, x22
    b5a8:      	bl	0xbccc <JNI_OnLoad+0x2a90>
    b5ac:      	mov	x22, x0
    b5b0:      	ldr	x8, [x19]
    b5b4:      	ldur	x1, [x29, #-0x38]
    b5b8:      	mov	x0, x19
    b5bc:      	mov	x2, x26
    b5c0:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    b5c4:      	b	0xb45c <JNI_OnLoad+0x2220>
    b5c8:      	bl	0xd110 <__stack_chk_fail@plt>
    b5cc:      	stp	x29, x30, [sp, #-0x40]!
    b5d0:      	str	x23, [sp, #0x10]
    b5d4:      	stp	x22, x21, [sp, #0x20]
    b5d8:      	stp	x20, x19, [sp, #0x30]
    b5dc:      	mov	x29, sp
    b5e0:      	cmp	x0, #0x0
    b5e4:      	adrp	x22, 0x1000
    b5e8:      	add	x22, x22, #0xef3
    b5ec:      	csel	x19, x22, x0, eq
    b5f0:      	mov	x21, x1
    b5f4:      	mov	x0, x19
    b5f8:      	bl	0xce60 <strlen@plt>
    b5fc:      	cmp	x21, #0x0
    b600:      	mov	x20, x0
    b604:      	csel	x21, x22, x21, eq
    b608:      	bl	0xccdc <JNI_OnLoad+0x3aa0>
    b60c:      	add	x22, x0, #0x1
    b610:      	add	x0, x22, x20
    b614:      	bl	0xcf30 <malloc@plt>
    b618:      	mov	x23, x0
    b61c:      	cbz	x0, 0xb640 <JNI_OnLoad+0x2404>
    b620:      	mov	x0, x23
    b624:      	mov	x1, x19
    b628:      	mov	x2, x20
    b62c:      	bl	0xd0b0 <memcpy@plt>
    b630:      	add	x0, x23, x20
    b634:      	mov	x1, x21
    b638:      	mov	x2, x22
    b63c:      	bl	0xd0b0 <memcpy@plt>
    b640:      	ldp	x20, x19, [sp, #0x30]
    b644:      	mov	x0, x23
    b648:      	ldp	x22, x21, [sp, #0x20]
    b64c:      	ldr	x23, [sp, #0x10]
    b650:      	ldp	x29, x30, [sp], #0x40
    b654:      	ret
    b658:      	stp	x29, x30, [sp, #-0x30]!
    b65c:      	str	x21, [sp, #0x10]
    b660:      	stp	x20, x19, [sp, #0x20]
    b664:      	mov	x29, sp
    b668:      	mov	x21, x0
    b66c:      	mov	x0, x1
    b670:      	mov	x20, x2
    b674:      	mov	x19, x1
    b678:      	bl	0xce60 <strlen@plt>
    b67c:      	cmp	x0, #0x2
    b680:      	b.lo	0xb698 <JNI_OnLoad+0x245c>
    b684:      	and	x10, x20, #0xffffffffffffff00
    b688:      	and	x9, x20, #0xffffffffffff0000
    b68c:      	and	x8, x20, #0xffffffff00000000
    b690:      	mov	x0, x20
    b694:      	b	0xb790 <JNI_OnLoad+0x2554>
    b698:      	ldrb	w9, [x19]
    b69c:      	mov	x8, xzr
    b6a0:      	sub	w10, w9, #0x42
    b6a4:      	cmp	w10, #0x8
    b6a8:      	b.hi	0xb6dc <JNI_OnLoad+0x24a0>
    b6ac:      	nop
    b6b0:      	adr	x9, 0x3208
    b6b4:      	mov	x0, x8
    b6b8:      	adr	x11, 0xb6d0 <JNI_OnLoad+0x2494>
    b6bc:      	ldrb	w12, [x9, x10]
    b6c0:      	add	x11, x11, x12, lsl #2
    b6c4:      	mov	x9, x8
    b6c8:      	mov	x10, x8
    b6cc:      	br	x11
    b6d0:      	adrp	x2, 0x1000
    b6d4:      	add	x2, x2, #0xc31
    b6d8:      	b	0xb700 <JNI_OnLoad+0x24c4>
    b6dc:      	cmp	w9, #0x53
    b6e0:      	b.eq	0xb778 <JNI_OnLoad+0x253c>
    b6e4:      	cmp	w9, #0x5a
    b6e8:      	mov	x9, x8
    b6ec:      	mov	x0, x8
    b6f0:      	mov	x10, x8
    b6f4:      	b.ne	0xb790 <JNI_OnLoad+0x2554>
    b6f8:      	adrp	x2, 0x1000
    b6fc:      	add	x2, x2, #0xc44
    b700:      	bl	0xc99c <JNI_OnLoad+0x3760>
    b704:      	mov	x8, xzr
    b708:      	mov	x9, xzr
    b70c:      	mov	x10, xzr
    b710:      	b	0xb790 <JNI_OnLoad+0x2554>
    b714:      	adrp	x2, 0x2000
    b718:      	add	x2, x2, #0x80c
    b71c:      	b	0xb734 <JNI_OnLoad+0x24f8>
    b720:      	adrp	x2, 0x2000
    b724:      	add	x2, x2, #0x22
    b728:      	b	0xb780 <JNI_OnLoad+0x2544>
    b72c:      	adrp	x2, 0x1000
    b730:      	add	x2, x2, #0xc3b
    b734:      	bl	0xc99c <JNI_OnLoad+0x3760>
    b738:      	mov	x8, xzr
    b73c:      	b	0xb76c <JNI_OnLoad+0x2530>
    b740:      	adrp	x2, 0x2000
    b744:      	add	x2, x2, #0xedd
    b748:      	bl	0xc99c <JNI_OnLoad+0x3760>
    b74c:      	and	x10, x0, #0xffffffffffffff00
    b750:      	and	x9, x0, #0xffffffffffff0000
    b754:      	and	x8, x0, #0xffffffff00000000
    b758:      	b	0xb790 <JNI_OnLoad+0x2554>
    b75c:      	adrp	x2, 0x2000
    b760:      	add	x2, x2, #0x844
    b764:      	bl	0xc99c <JNI_OnLoad+0x3760>
    b768:      	and	x8, x0, #0xffffffff00000000
    b76c:      	and	x10, x0, #0xffffffffffffff00
    b770:      	and	x9, x0, #0xffffffffffff0000
    b774:      	b	0xb790 <JNI_OnLoad+0x2554>
    b778:      	adrp	x2, 0x1000
    b77c:      	add	x2, x2, #0xd49
    b780:      	bl	0xc99c <JNI_OnLoad+0x3760>
    b784:      	mov	x8, xzr
    b788:      	mov	x9, xzr
    b78c:      	and	x10, x0, #0xffffffffffffff00
    b790:      	and	x11, x0, #0xff
    b794:      	and	x9, x9, #0xffff0000
    b798:      	and	x10, x10, #0xff00
    b79c:      	orr	x8, x8, x11
    b7a0:      	ldp	x20, x19, [sp, #0x20]
    b7a4:      	orr	x8, x9, x8
    b7a8:      	ldr	x21, [sp, #0x10]
    b7ac:      	orr	x0, x8, x10
    b7b0:      	ldp	x29, x30, [sp], #0x30
    b7b4:      	ret
    b7b8:      	stp	x29, x30, [sp, #-0x50]!
    b7bc:      	str	x25, [sp, #0x10]
    b7c0:      	stp	x24, x23, [sp, #0x20]
    b7c4:      	stp	x22, x21, [sp, #0x30]
    b7c8:      	stp	x20, x19, [sp, #0x40]
    b7cc:      	mov	x29, sp
    b7d0:      	cmp	x4, #0x0
    b7d4:      	adrp	x8, 0x2000
    b7d8:      	add	x8, x8, #0x2d6
    b7dc:      	mov	x21, x0
    b7e0:      	csel	x22, x8, x4, eq
    b7e4:      	cbz	x1, 0xb8a8 <JNI_OnLoad+0x266c>
    b7e8:      	mov	x23, x2
    b7ec:      	cbz	x2, 0xb8a8 <JNI_OnLoad+0x266c>
    b7f0:      	cmp	x3, #0x0
    b7f4:      	adrp	x8, 0x1000
    b7f8:      	add	x8, x8, #0xef3
    b7fc:      	mov	x20, x1
    b800:      	csel	x1, x8, x3, eq
    b804:      	adrp	x0, 0x2000
    b808:      	add	x0, x0, #0x24f
    b80c:      	mov	x19, x5
    b810:      	bl	0xb5cc <JNI_OnLoad+0x2390>
    b814:      	adrp	x1, 0x2000
    b818:      	add	x1, x1, #0x6f
    b81c:      	mov	x24, x0
    b820:      	bl	0xb5cc <JNI_OnLoad+0x2390>
    b824:      	mov	x25, x0
    b828:      	bl	0xcd08 <JNI_OnLoad+0x3acc>
    b82c:      	mov	x0, x25
    b830:      	mov	x1, x22
    b834:      	bl	0xb5cc <JNI_OnLoad+0x2390>
    b838:      	mov	x24, x0
    b83c:      	bl	0xcc0c <JNI_OnLoad+0x39d0>
    b840:      	mov	x0, x23
    b844:      	bl	0xbcb8 <JNI_OnLoad+0x2a7c>
    b848:      	cmp	x0, #0x6
    b84c:      	b.ne	0xb8c0 <JNI_OnLoad+0x2684>
    b850:      	ldrb	w8, [x23]
    b854:      	cmp	w8, #0x3c
    b858:      	b.ne	0xb8c0 <JNI_OnLoad+0x2684>
    b85c:      	ldrb	w8, [x23, #0x1]
    b860:      	cmp	w8, #0x69
    b864:      	b.ne	0xb8c0 <JNI_OnLoad+0x2684>
    b868:      	ldrb	w8, [x23, #0x2]
    b86c:      	cmp	w8, #0x6e
    b870:      	b.ne	0xb8c0 <JNI_OnLoad+0x2684>
    b874:      	ldrb	w8, [x23, #0x3]
    b878:      	cmp	w8, #0x69
    b87c:      	b.ne	0xb8c0 <JNI_OnLoad+0x2684>
    b880:      	ldrb	w8, [x23, #0x4]
    b884:      	cmp	w8, #0x74
    b888:      	b.ne	0xb8c0 <JNI_OnLoad+0x2684>
    b88c:      	ldrb	w8, [x23, #0x5]
    b890:      	cmp	w8, #0x3e
    b894:      	b.ne	0xb8c0 <JNI_OnLoad+0x2684>
    b898:      	ldr	x8, [x21]
    b89c:      	mov	w25, wzr
    b8a0:      	add	x8, x8, #0x108
    b8a4:      	b	0xb8cc <JNI_OnLoad+0x2690>
    b8a8:      	adrp	x1, 0x2000
    b8ac:      	add	x1, x1, #0x55c
    b8b0:      	mov	x0, x21
    b8b4:      	bl	0xb204 <JNI_OnLoad+0x1fc8>
    b8b8:      	mov	x0, xzr
    b8bc:      	b	0xb954 <JNI_OnLoad+0x2718>
    b8c0:      	ldr	x8, [x21]
    b8c4:      	mov	w25, #0x1               // =1
    b8c8:      	add	x8, x8, #0x388
    b8cc:      	ldr	x8, [x8]
    b8d0:      	mov	x0, x21
    b8d4:      	mov	x1, x20
    b8d8:      	mov	x2, x23
    b8dc:      	mov	x3, x24
    b8e0:      	blr	x8
    b8e4:      	mov	x23, x0
    b8e8:      	bl	0xcd08 <JNI_OnLoad+0x3acc>
    b8ec:      	ldr	x8, [x21]
    b8f0:      	mov	x0, x21
    b8f4:      	bl	0xc984 <JNI_OnLoad+0x3748>
    b8f8:      	tst	w0, #0xff
    b8fc:      	mov	x0, xzr
    b900:      	b.ne	0xb954 <JNI_OnLoad+0x2718>
    b904:      	cbz	x23, 0xb954 <JNI_OnLoad+0x2718>
    b908:      	tbz	w25, #0x0, 0xb940 <JNI_OnLoad+0x2704>
    b90c:      	mov	x0, x22
    b910:      	bl	0xbcb8 <JNI_OnLoad+0x2a7c>
    b914:      	cmp	x0, #0x2
    b918:      	b.lo	0xb96c <JNI_OnLoad+0x2730>
    b91c:      	ldr	x8, [x21]
    b920:      	ldr	x8, [x8, #0x3a0]
    b924:      	mov	x0, x21
    b928:      	mov	x1, x20
    b92c:      	mov	x2, x23
    b930:      	mov	x3, x19
    b934:      	blr	x8
    b938:      	bl	0xca34 <JNI_OnLoad+0x37f8>
    b93c:      	b	0xb950 <JNI_OnLoad+0x2714>
    b940:      	bl	0xc9d8 <JNI_OnLoad+0x379c>
    b944:      	ldr	x8, [x8, #0xf0]
    b948:      	blr	x8
    b94c:      	bl	0xca34 <JNI_OnLoad+0x37f8>
    b950:      	bl	0xcbf0 <JNI_OnLoad+0x39b4>
    b954:      	ldp	x20, x19, [sp, #0x40]
    b958:      	ldr	x25, [sp, #0x10]
    b95c:      	ldp	x22, x21, [sp, #0x30]
    b960:      	ldp	x24, x23, [sp, #0x20]
    b964:      	ldp	x29, x30, [sp], #0x50
    b968:      	ret
    b96c:      	ldrb	w10, [x22]
    b970:      	bl	0xca5c <JNI_OnLoad+0x3820>
    b974:      	b.hi	0xb9a4 <JNI_OnLoad+0x2768>
    b978:      	nop
    b97c:      	adr	x10, 0x3211
    b980:      	mov	w0, w9
    b984:      	adr	x12, 0xb950 <JNI_OnLoad+0x2714>
    b988:      	ldrb	w13, [x10, x11]
    b98c:      	add	x12, x12, x13, lsl #2
    b990:      	mov	w10, w9
    b994:      	br	x12
    b998:      	ldr	x8, [x21]
    b99c:      	ldr	x8, [x8, #0x3d0]
    b9a0:      	b	0xba3c <JNI_OnLoad+0x2800>
    b9a4:      	cmp	w10, #0x53
    b9a8:      	b.eq	0xba4c <JNI_OnLoad+0x2810>
    b9ac:      	cmp	w10, #0x5a
    b9b0:      	b.eq	0xba34 <JNI_OnLoad+0x27f8>
    b9b4:      	cmp	w10, #0x56
    b9b8:      	mov	w0, w9
    b9bc:      	mov	w10, w9
    b9c0:      	b.ne	0xb950 <JNI_OnLoad+0x2714>
    b9c4:      	bl	0xc9d8 <JNI_OnLoad+0x379c>
    b9c8:      	ldr	x8, [x8, #0x478]
    b9cc:      	blr	x8
    b9d0:      	mov	x8, xzr
    b9d4:      	mov	w9, wzr
    b9d8:      	mov	w0, wzr
    b9dc:      	b	0xba44 <JNI_OnLoad+0x2808>
    b9e0:      	bl	0xc9d8 <JNI_OnLoad+0x379c>
    b9e4:      	ldr	x8, [x8, #0x418]
    b9e8:      	blr	x8
    b9ec:      	b	0xba00 <JNI_OnLoad+0x27c4>
    b9f0:      	bl	0xc9d8 <JNI_OnLoad+0x379c>
    b9f4:      	ldr	x8, [x8, #0x448]
    b9f8:      	blr	x8
    b9fc:      	fmov	w0, s0
    ba00:      	bl	0xcbd8 <JNI_OnLoad+0x399c>
    ba04:      	b	0xb950 <JNI_OnLoad+0x2714>
    ba08:      	bl	0xc9d8 <JNI_OnLoad+0x379c>
    ba0c:      	ldr	x8, [x8, #0x460]
    ba10:      	blr	x8
    ba14:      	fmov	x0, d0
    ba18:      	b	0xb938 <JNI_OnLoad+0x26fc>
    ba1c:      	ldr	x8, [x21]
    ba20:      	ldr	x8, [x8, #0x3e8]
    ba24:      	b	0xba54 <JNI_OnLoad+0x2818>
    ba28:      	ldr	x8, [x21]
    ba2c:      	ldr	x8, [x8, #0x430]
    ba30:      	b	0xb924 <JNI_OnLoad+0x26e8>
    ba34:      	ldr	x8, [x21]
    ba38:      	ldr	x8, [x8, #0x3b8]
    ba3c:      	bl	0xcb30 <JNI_OnLoad+0x38f4>
    ba40:      	bl	0xcafc <JNI_OnLoad+0x38c0>
    ba44:      	mov	w10, wzr
    ba48:      	b	0xb950 <JNI_OnLoad+0x2714>
    ba4c:      	ldr	x8, [x21]
    ba50:      	ldr	x8, [x8, #0x400]
    ba54:      	bl	0xcb30 <JNI_OnLoad+0x38f4>
    ba58:      	ubfx	w10, w0, #8, #8
    ba5c:      	bl	0xcafc <JNI_OnLoad+0x38c0>
    ba60:      	b	0xb950 <JNI_OnLoad+0x2714>
    ba64:      	stp	x29, x30, [sp, #-0x50]!
    ba68:      	stp	x26, x25, [sp, #0x10]
    ba6c:      	stp	x24, x23, [sp, #0x20]
    ba70:      	stp	x22, x21, [sp, #0x30]
    ba74:      	stp	x20, x19, [sp, #0x40]
    ba78:      	mov	x29, sp
    ba7c:      	cmp	x3, #0x0
    ba80:      	adrp	x8, 0x1000
    ba84:      	add	x8, x8, #0xef3
    ba88:      	mov	x21, x0
    ba8c:      	csel	x25, x8, x3, eq
    ba90:      	cbz	x1, 0xbb88 <JNI_OnLoad+0x294c>
    ba94:      	mov	x22, x2
    ba98:      	cbz	x2, 0xbb88 <JNI_OnLoad+0x294c>
    ba9c:      	ldr	x8, [x21]
    baa0:      	mov	x0, x21
    baa4:      	mov	x19, x5
    baa8:      	mov	x23, x4
    baac:      	mov	x20, x1
    bab0:      	ldr	x8, [x8, #0xf8]
    bab4:      	blr	x8
    bab8:      	ldr	x8, [x21]
    babc:      	mov	x24, x0
    bac0:      	mov	x0, x21
    bac4:      	bl	0xc984 <JNI_OnLoad+0x3748>
    bac8:      	tst	w0, #0xff
    bacc:      	mov	x0, xzr
    bad0:      	b.ne	0xbb9c <JNI_OnLoad+0x2960>
    bad4:      	cbz	x24, 0xbb9c <JNI_OnLoad+0x2960>
    bad8:      	adrp	x0, 0x2000
    badc:      	add	x0, x0, #0x24f
    bae0:      	bl	0xcc28 <JNI_OnLoad+0x39ec>
    bae4:      	adrp	x1, 0x2000
    bae8:      	add	x1, x1, #0x6f
    baec:      	mov	x25, x0
    baf0:      	bl	0xb5cc <JNI_OnLoad+0x2390>
    baf4:      	mov	x26, x0
    baf8:      	bl	0xcc0c <JNI_OnLoad+0x39d0>
    bafc:      	mov	x0, x26
    bb00:      	mov	x1, x23
    bb04:      	bl	0xb5cc <JNI_OnLoad+0x2390>
    bb08:      	mov	x25, x0
    bb0c:      	mov	x0, x26
    bb10:      	bl	0xcdc0 <free@plt>
    bb14:      	ldr	x8, [x21]
    bb18:      	mov	x0, x21
    bb1c:      	mov	x1, x24
    bb20:      	mov	x2, x22
    bb24:      	mov	x3, x25
    bb28:      	ldr	x8, [x8, #0x108]
    bb2c:      	blr	x8
    bb30:      	mov	x22, x0
    bb34:      	bl	0xcc0c <JNI_OnLoad+0x39d0>
    bb38:      	ldr	x8, [x21]
    bb3c:      	mov	x0, x21
    bb40:      	mov	x1, x24
    bb44:      	bl	0xca14 <JNI_OnLoad+0x37d8>
    bb48:      	ldr	x8, [x21]
    bb4c:      	mov	x0, x21
    bb50:      	bl	0xc984 <JNI_OnLoad+0x3748>
    bb54:      	tst	w0, #0xff
    bb58:      	mov	x0, xzr
    bb5c:      	b.ne	0xbb9c <JNI_OnLoad+0x2960>
    bb60:      	cbz	x22, 0xbb9c <JNI_OnLoad+0x2960>
    bb64:      	mov	x0, x23
    bb68:      	bl	0xbcb8 <JNI_OnLoad+0x2a7c>
    bb6c:      	cmp	x0, #0x2
    bb70:      	b.lo	0xbbb4 <JNI_OnLoad+0x2978>
    bb74:      	bl	0xc9c0 <JNI_OnLoad+0x3784>
    bb78:      	ldr	x8, [x8, #0x120]
    bb7c:      	blr	x8
    bb80:      	bl	0xca34 <JNI_OnLoad+0x37f8>
    bb84:      	b	0xbcb0 <JNI_OnLoad+0x2a74>
    bb88:      	adrp	x1, 0x2000
    bb8c:      	add	x1, x1, #0xff
    bb90:      	mov	x0, x21
    bb94:      	bl	0xb204 <JNI_OnLoad+0x1fc8>
    bb98:      	mov	x0, xzr
    bb9c:      	ldp	x20, x19, [sp, #0x40]
    bba0:      	ldp	x22, x21, [sp, #0x30]
    bba4:      	ldp	x24, x23, [sp, #0x20]
    bba8:      	ldp	x26, x25, [sp, #0x10]
    bbac:      	ldp	x29, x30, [sp], #0x50
    bbb0:      	ret
    bbb4:      	ldrb	w10, [x23]
    bbb8:      	bl	0xca5c <JNI_OnLoad+0x3820>
    bbbc:      	b.hi	0xbbec <JNI_OnLoad+0x29b0>
    bbc0:      	nop
    bbc4:      	adr	x10, 0x321a
    bbc8:      	mov	w0, w9
    bbcc:      	adr	x12, 0xbbe0 <JNI_OnLoad+0x29a4>
    bbd0:      	ldrb	w13, [x10, x11]
    bbd4:      	add	x12, x12, x13, lsl #2
    bbd8:      	mov	w10, w9
    bbdc:      	br	x12
    bbe0:      	ldr	x8, [x21]
    bbe4:      	ldr	x8, [x8, #0x150]
    bbe8:      	b	0xbc8c <JNI_OnLoad+0x2a50>
    bbec:      	cmp	w10, #0x53
    bbf0:      	b.eq	0xbc9c <JNI_OnLoad+0x2a60>
    bbf4:      	cmp	w10, #0x5a
    bbf8:      	b.eq	0xbc84 <JNI_OnLoad+0x2a48>
    bbfc:      	cmp	w10, #0x56
    bc00:      	mov	w0, w9
    bc04:      	mov	w10, w9
    bc08:      	b.ne	0xbcb0 <JNI_OnLoad+0x2a74>
    bc0c:      	bl	0xc9c0 <JNI_OnLoad+0x3784>
    bc10:      	ldr	x8, [x8, #0x1f8]
    bc14:      	blr	x8
    bc18:      	mov	x8, xzr
    bc1c:      	mov	w9, wzr
    bc20:      	mov	w0, wzr
    bc24:      	b	0xbc94 <JNI_OnLoad+0x2a58>
    bc28:      	bl	0xc9c0 <JNI_OnLoad+0x3784>
    bc2c:      	ldr	x8, [x8, #0x198]
    bc30:      	blr	x8
    bc34:      	b	0xbc48 <JNI_OnLoad+0x2a0c>
    bc38:      	bl	0xc9c0 <JNI_OnLoad+0x3784>
    bc3c:      	ldr	x8, [x8, #0x1c8]
    bc40:      	blr	x8
    bc44:      	fmov	w0, s0
    bc48:      	bl	0xcbd8 <JNI_OnLoad+0x399c>
    bc4c:      	b	0xbcb0 <JNI_OnLoad+0x2a74>
    bc50:      	bl	0xc9c0 <JNI_OnLoad+0x3784>
    bc54:      	ldr	x8, [x8, #0x1e0]
    bc58:      	blr	x8
    bc5c:      	fmov	x0, d0
    bc60:      	b	0xbc7c <JNI_OnLoad+0x2a40>
    bc64:      	ldr	x8, [x21]
    bc68:      	ldr	x8, [x8, #0x168]
    bc6c:      	b	0xbca4 <JNI_OnLoad+0x2a68>
    bc70:      	bl	0xc9c0 <JNI_OnLoad+0x3784>
    bc74:      	ldr	x8, [x8, #0x1b0]
    bc78:      	blr	x8
    bc7c:      	bl	0xca34 <JNI_OnLoad+0x37f8>
    bc80:      	b	0xbcb0 <JNI_OnLoad+0x2a74>
    bc84:      	ldr	x8, [x21]
    bc88:      	ldr	x8, [x8, #0x138]
    bc8c:      	bl	0xcb44 <JNI_OnLoad+0x3908>
    bc90:      	bl	0xcafc <JNI_OnLoad+0x38c0>
    bc94:      	mov	w10, wzr
    bc98:      	b	0xbcb0 <JNI_OnLoad+0x2a74>
    bc9c:      	ldr	x8, [x21]
    bca0:      	ldr	x8, [x8, #0x180]
    bca4:      	bl	0xcb44 <JNI_OnLoad+0x3908>
    bca8:      	ubfx	w10, w0, #8, #8
    bcac:      	bl	0xcafc <JNI_OnLoad+0x38c0>
    bcb0:      	bl	0xcbf0 <JNI_OnLoad+0x39b4>
    bcb4:      	b	0xbb9c <JNI_OnLoad+0x2960>
    bcb8:      	sub	x8, x0, #0x1
    bcbc:      	ldrb	w9, [x8, #0x1]!
    bcc0:      	cbnz	w9, 0xbcbc <JNI_OnLoad+0x2a80>
    bcc4:      	sub	x0, x8, x0
    bcc8:      	ret
    bccc:      	sub	sp, sp, #0x60
    bcd0:      	stp	x29, x30, [sp, #0x10]
    bcd4:      	str	x25, [sp, #0x20]
    bcd8:      	stp	x24, x23, [sp, #0x30]
    bcdc:      	stp	x22, x21, [sp, #0x40]
    bce0:      	stp	x20, x19, [sp, #0x50]
    bce4:      	add	x29, sp, #0x10
    bce8:      	mrs	x25, TPIDR_EL0
    bcec:      	mov	x19, x0
    bcf0:      	mov	x0, x1
    bcf4:      	ldr	x8, [x25, #0x28]
    bcf8:      	mov	x22, x2
    bcfc:      	mov	x20, x1
    bd00:      	str	x8, [sp, #0x8]
    bd04:      	str	x2, [sp]
    bd08:      	bl	0xce60 <strlen@plt>
    bd0c:      	cmp	x0, #0x2
    bd10:      	b.hs	0xbe54 <JNI_OnLoad+0x2c18>
    bd14:      	ldrb	w8, [x20]
    bd18:      	mov	x22, xzr
    bd1c:      	sub	w9, w8, #0x42
    bd20:      	cmp	w9, #0x8
    bd24:      	b.hi	0xbd54 <JNI_OnLoad+0x2b18>
    bd28:      	nop
    bd2c:      	adr	x8, 0x3223
    bd30:      	adrp	x21, 0x2000
    bd34:      	add	x21, x21, #0x5ad
    bd38:      	adr	x10, 0xbd48 <JNI_OnLoad+0x2b0c>
    bd3c:      	ldrb	w11, [x8, x9]
    bd40:      	add	x10, x10, x11, lsl #2
    bd44:      	br	x10
    bd48:      	adrp	x21, 0x1000
    bd4c:      	add	x21, x21, #0xf5a
    bd50:      	b	0xbda8 <JNI_OnLoad+0x2b6c>
    bd54:      	cmp	w8, #0x5a
    bd58:      	b.eq	0xbda0 <JNI_OnLoad+0x2b64>
    bd5c:      	cmp	w8, #0x53
    bd60:      	b.ne	0xbe54 <JNI_OnLoad+0x2c18>
    bd64:      	adrp	x21, 0x2000
    bd68:      	add	x21, x21, #0x817
    bd6c:      	b	0xbda8 <JNI_OnLoad+0x2b6c>
    bd70:      	adrp	x21, 0x2000
    bd74:      	add	x21, x21, #0xef1
    bd78:      	b	0xbda8 <JNI_OnLoad+0x2b6c>
    bd7c:      	adrp	x21, 0x2000
    bd80:      	add	x21, x21, #0xee9
    bd84:      	b	0xbda8 <JNI_OnLoad+0x2b6c>
    bd88:      	adrp	x21, 0x2000
    bd8c:      	add	x21, x21, #0xab7
    bd90:      	b	0xbda8 <JNI_OnLoad+0x2b6c>
    bd94:      	adrp	x21, 0x1000
    bd98:      	add	x21, x21, #0xe03
    bd9c:      	b	0xbda8 <JNI_OnLoad+0x2b6c>
    bda0:      	adrp	x21, 0x2000
    bda4:      	add	x21, x21, #0x251
    bda8:      	adrp	x0, 0x2000
    bdac:      	add	x0, x0, #0x2c
    bdb0:      	mov	x1, x21
    bdb4:      	bl	0xb5cc <JNI_OnLoad+0x2390>
    bdb8:      	ldr	x8, [x19]
    bdbc:      	mov	x22, x0
    bdc0:      	bl	0xcc50 <JNI_OnLoad+0x3a14>
    bdc4:      	bl	0xcaec <JNI_OnLoad+0x38b0>
    bdc8:      	mov	x23, x0
    bdcc:      	mov	x0, x22
    bdd0:      	bl	0xcdc0 <free@plt>
    bdd4:      	ldr	x8, [x19]
    bdd8:      	bl	0xc978 <JNI_OnLoad+0x373c>
    bddc:      	tst	w0, #0xff
    bde0:      	b.ne	0xbe44 <JNI_OnLoad+0x2c08>
    bde4:      	cbz	x23, 0xbe44 <JNI_OnLoad+0x2c08>
    bde8:      	adrp	x0, 0x2000
    bdec:      	add	x0, x0, #0x2d8
    bdf0:      	mov	x1, x21
    bdf4:      	bl	0xb5cc <JNI_OnLoad+0x2390>
    bdf8:      	adrp	x1, 0x2000
    bdfc:      	add	x1, x1, #0x11d
    be00:      	mov	x21, x0
    be04:      	bl	0xb5cc <JNI_OnLoad+0x2390>
    be08:      	mov	x24, x0
    be0c:      	bl	0xccec <JNI_OnLoad+0x3ab0>
    be10:      	adrp	x2, 0x2000
    be14:      	add	x2, x2, #0x11f
    be18:      	mov	x5, sp
    be1c:      	bl	0xcc44 <JNI_OnLoad+0x3a08>
    be20:      	mov	x3, x20
    be24:      	mov	x4, x24
    be28:      	bl	0xb7b8 <JNI_OnLoad+0x257c>
    be2c:      	mov	x22, x0
    be30:      	bl	0xcd08 <JNI_OnLoad+0x3acc>
    be34:      	ldr	x8, [x19]
    be38:      	bl	0xcc44 <JNI_OnLoad+0x3a08>
    be3c:      	bl	0xca14 <JNI_OnLoad+0x37d8>
    be40:      	b	0xbe54 <JNI_OnLoad+0x2c18>
    be44:      	adrp	x1, 0x1000
    be48:      	add	x1, x1, #0xb56
    be4c:      	bl	0xca70 <JNI_OnLoad+0x3834>
    be50:      	mov	x22, xzr
    be54:      	ldr	x8, [x25, #0x28]
    be58:      	ldr	x9, [sp, #0x8]
    be5c:      	cmp	x8, x9
    be60:      	b.ne	0xbe84 <JNI_OnLoad+0x2c48>
    be64:      	mov	x0, x22
    be68:      	ldp	x20, x19, [sp, #0x50]
    be6c:      	ldp	x22, x21, [sp, #0x40]
    be70:      	ldr	x25, [sp, #0x20]
    be74:      	ldp	x24, x23, [sp, #0x30]
    be78:      	ldp	x29, x30, [sp, #0x10]
    be7c:      	add	sp, sp, #0x60
    be80:      	ret
    be84:      	bl	0xd110 <__stack_chk_fail@plt>
    be88:      	stp	x29, x30, [sp, #-0x60]!
    be8c:      	str	x27, [sp, #0x10]
    be90:      	stp	x26, x25, [sp, #0x20]
    be94:      	stp	x24, x23, [sp, #0x30]
    be98:      	stp	x22, x21, [sp, #0x40]
    be9c:      	stp	x20, x19, [sp, #0x50]
    bea0:      	mov	x29, sp
    bea4:      	bl	0xcc14 <JNI_OnLoad+0x39d8>
    bea8:      	mov	x25, x6
    beac:      	mov	x21, x5
    beb0:      	ldr	x8, [x8, #0x548]
    beb4:      	mov	w26, w4
    beb8:      	mov	x19, x0
    bebc:      	mov	x20, x3
    bec0:      	blr	x8
    bec4:      	ldr	x8, [x19]
    bec8:      	mov	x22, x0
    becc:      	bl	0xc978 <JNI_OnLoad+0x373c>
    bed0:      	tst	w0, #0xff
    bed4:      	b.ne	0xbf60 <JNI_OnLoad+0x2d24>
    bed8:      	cbz	x22, 0xbf60 <JNI_OnLoad+0x2d24>
    bedc:      	ldr	x8, [x19]
    bee0:      	mov	x0, x19
    bee4:      	mov	x1, x20
    bee8:      	mov	x2, xzr
    beec:      	bl	0xca0c <JNI_OnLoad+0x37d0>
    bef0:      	ldr	x8, [x19]
    bef4:      	mov	x23, x0
    bef8:      	bl	0xc978 <JNI_OnLoad+0x373c>
    befc:      	tst	w0, #0xff
    bf00:      	b.ne	0xbf84 <JNI_OnLoad+0x2d48>
    bf04:      	cbz	x23, 0xbf84 <JNI_OnLoad+0x2d48>
    bf08:      	bl	0xcc50 <JNI_OnLoad+0x3a14>
    bf0c:      	mov	x2, x25
    bf10:      	bl	0xb658 <JNI_OnLoad+0x241c>
    bf14:      	ldr	x8, [x19]
    bf18:      	mov	x25, x0
    bf1c:      	bl	0xc978 <JNI_OnLoad+0x373c>
    bf20:      	tst	w0, #0xff
    bf24:      	b.eq	0xbfcc <JNI_OnLoad+0x2d90>
    bf28:      	ldr	x8, [x19]
    bf2c:      	mov	x0, x19
    bf30:      	mov	x1, x21
    bf34:      	mov	x2, x22
    bf38:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    bf3c:      	bl	0xcc74 <JNI_OnLoad+0x3a38>
    bf40:      	ldp	x20, x19, [sp, #0x50]
    bf44:      	ldp	x22, x21, [sp, #0x40]
    bf48:      	ldr	x3, [x8, #0x550]
    bf4c:      	ldp	x24, x23, [sp, #0x30]
    bf50:      	ldr	x27, [sp, #0x10]
    bf54:      	ldp	x26, x25, [sp, #0x20]
    bf58:      	ldp	x29, x30, [sp], #0x60
    bf5c:      	br	x3
    bf60:      	cbz	x22, 0xbf78 <JNI_OnLoad+0x2d3c>
    bf64:      	ldr	x8, [x19]
    bf68:      	mov	x0, x19
    bf6c:      	mov	x1, x21
    bf70:      	mov	x2, x22
    bf74:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    bf78:      	adrp	x1, 0x2000
    bf7c:      	add	x1, x1, #0xd4a
    bf80:      	b	0xbfac <JNI_OnLoad+0x2d70>
    bf84:      	ldr	x8, [x19]
    bf88:      	mov	x0, x19
    bf8c:      	mov	x1, x21
    bf90:      	mov	x2, x22
    bf94:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    bf98:      	cbz	x23, 0xbfa4 <JNI_OnLoad+0x2d68>
    bf9c:      	bl	0xcc74 <JNI_OnLoad+0x3a38>
    bfa0:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    bfa4:      	adrp	x1, 0x2000
    bfa8:      	add	x1, x1, #0xaaa
    bfac:      	mov	x0, x19
    bfb0:      	ldp	x20, x19, [sp, #0x50]
    bfb4:      	ldp	x22, x21, [sp, #0x40]
    bfb8:      	ldr	x27, [sp, #0x10]
    bfbc:      	ldp	x24, x23, [sp, #0x30]
    bfc0:      	ldp	x26, x25, [sp, #0x20]
    bfc4:      	ldp	x29, x30, [sp], #0x60
    bfc8:      	b	0xb204 <JNI_OnLoad+0x1fc8>
    bfcc:      	tst	w26, #0xff
    bfd0:      	b.eq	0xc018 <JNI_OnLoad+0x2ddc>
    bfd4:      	cbz	x24, 0xc088 <JNI_OnLoad+0x2e4c>
    bfd8:      	bl	0xcc88 <JNI_OnLoad+0x3a4c>
    bfdc:      	mov	x3, x22
    bfe0:      	ldr	x8, [x8, #0x480]
    bfe4:      	blr	x8
    bfe8:      	ldr	x8, [x19]
    bfec:      	mov	x26, x0
    bff0:      	bl	0xc978 <JNI_OnLoad+0x373c>
    bff4:      	tst	w0, #0xff
    bff8:      	b.ne	0xbf28 <JNI_OnLoad+0x2cec>
    bffc:      	cbz	x26, 0xbf28 <JNI_OnLoad+0x2cec>
    c000:      	bl	0xcc3c <JNI_OnLoad+0x3a00>
    c004:      	cmp	x0, #0x2
    c008:      	b.lo	0xc0a4 <JNI_OnLoad+0x2e68>
    c00c:      	ldr	x8, [x19]
    c010:      	ldr	x8, [x8, #0x4d0]
    c014:      	b	0xc1dc <JNI_OnLoad+0x2fa0>
    c018:      	cbz	x24, 0xc094 <JNI_OnLoad+0x2e58>
    c01c:      	bl	0xcb08 <JNI_OnLoad+0x38cc>
    c020:      	ldr	x8, [x19]
    c024:      	mov	x27, x0
    c028:      	bl	0xc978 <JNI_OnLoad+0x373c>
    c02c:      	tst	w0, #0xff
    c030:      	b.ne	0xbf28 <JNI_OnLoad+0x2cec>
    c034:      	cbz	x27, 0xbf28 <JNI_OnLoad+0x2cec>
    c038:      	bl	0xcc9c <JNI_OnLoad+0x3a60>
    c03c:      	mov	x3, x22
    c040:      	ldr	x8, [x8, #0x2f0]
    c044:      	blr	x8
    c048:      	ldr	x8, [x19]
    c04c:      	mov	x26, x0
    c050:      	mov	x0, x19
    c054:      	mov	x1, x27
    c058:      	bl	0xca14 <JNI_OnLoad+0x37d8>
    c05c:      	ldr	x8, [x19]
    c060:      	bl	0xc978 <JNI_OnLoad+0x373c>
    c064:      	tst	w0, #0xff
    c068:      	b.ne	0xbf28 <JNI_OnLoad+0x2cec>
    c06c:      	cbz	x26, 0xbf28 <JNI_OnLoad+0x2cec>
    c070:      	bl	0xcc3c <JNI_OnLoad+0x3a00>
    c074:      	cmp	x0, #0x2
    c078:      	b.lo	0xc0d8 <JNI_OnLoad+0x2e9c>
    c07c:      	ldr	x8, [x19]
    c080:      	ldr	x8, [x8, #0x340]
    c084:      	b	0xc1dc <JNI_OnLoad+0x2fa0>
    c088:      	adrp	x1, 0x2000
    c08c:      	add	x1, x1, #0xd82
    c090:      	b	0xc09c <JNI_OnLoad+0x2e60>
    c094:      	adrp	x1, 0x1000
    c098:      	add	x1, x1, #0xe42
    c09c:      	bl	0xca70 <JNI_OnLoad+0x3834>
    c0a0:      	b	0xbf28 <JNI_OnLoad+0x2cec>
    c0a4:      	ldrb	w8, [x22]
    c0a8:      	sub	w9, w8, #0x42
    c0ac:      	cmp	w9, #0x8
    c0b0:      	b.hi	0xc10c <JNI_OnLoad+0x2ed0>
    c0b4:      	nop
    c0b8:      	adr	x8, 0x322c
    c0bc:      	adr	x10, 0xbf28 <JNI_OnLoad+0x2cec>
    c0c0:      	ldrb	w11, [x8, x9]
    c0c4:      	add	x10, x10, x11, lsl #2
    c0c8:      	br	x10
    c0cc:      	ldr	x8, [x19]
    c0d0:      	ldr	x8, [x8, #0x4e0]
    c0d4:      	b	0xc1f4 <JNI_OnLoad+0x2fb8>
    c0d8:      	ldrb	w8, [x22]
    c0dc:      	sub	w9, w8, #0x42
    c0e0:      	cmp	w9, #0x8
    c0e4:      	b.hi	0xc170 <JNI_OnLoad+0x2f34>
    c0e8:      	adrp	x8, 0x3000
    c0ec:      	add	x8, x8, #0x235
    c0f0:      	adr	x10, 0xbf28 <JNI_OnLoad+0x2cec>
    c0f4:      	ldrb	w11, [x8, x9]
    c0f8:      	add	x10, x10, x11, lsl #2
    c0fc:      	br	x10
    c100:      	ldr	x8, [x19]
    c104:      	ldr	x8, [x8, #0x350]
    c108:      	b	0xc1f4 <JNI_OnLoad+0x2fb8>
    c10c:      	cmp	w8, #0x53
    c110:      	b.eq	0xc164 <JNI_OnLoad+0x2f28>
    c114:      	cmp	w8, #0x5a
    c118:      	b.ne	0xbf28 <JNI_OnLoad+0x2cec>
    c11c:      	ldr	x8, [x19]
    c120:      	ldr	x8, [x8, #0x4d8]
    c124:      	b	0xc1f4 <JNI_OnLoad+0x2fb8>
    c128:      	ldr	x8, [x19]
    c12c:      	ldr	x8, [x8, #0x508]
    c130:      	b	0xc194 <JNI_OnLoad+0x2f58>
    c134:      	ldr	x8, [x19]
    c138:      	ldr	x8, [x8, #0x4e8]
    c13c:      	b	0xc1f4 <JNI_OnLoad+0x2fb8>
    c140:      	ldr	x8, [x19]
    c144:      	ldr	x8, [x8, #0x4f8]
    c148:      	b	0xc1f4 <JNI_OnLoad+0x2fb8>
    c14c:      	ldr	x8, [x19]
    c150:      	ldr	x8, [x8, #0x510]
    c154:      	b	0xc1c4 <JNI_OnLoad+0x2f88>
    c158:      	ldr	x8, [x19]
    c15c:      	ldr	x8, [x8, #0x500]
    c160:      	b	0xc1dc <JNI_OnLoad+0x2fa0>
    c164:      	ldr	x8, [x19]
    c168:      	ldr	x8, [x8, #0x4f0]
    c16c:      	b	0xc1f4 <JNI_OnLoad+0x2fb8>
    c170:      	cmp	w8, #0x53
    c174:      	b.eq	0xc1ec <JNI_OnLoad+0x2fb0>
    c178:      	cmp	w8, #0x5a
    c17c:      	b.ne	0xbf28 <JNI_OnLoad+0x2cec>
    c180:      	ldr	x8, [x19]
    c184:      	ldr	x8, [x8, #0x348]
    c188:      	b	0xc1f4 <JNI_OnLoad+0x2fb8>
    c18c:      	ldr	x8, [x19]
    c190:      	ldr	x8, [x8, #0x378]
    c194:      	fmov	s0, w25
    c198:      	bl	0xcac4 <JNI_OnLoad+0x3888>
    c19c:      	blr	x8
    c1a0:      	b	0xbf28 <JNI_OnLoad+0x2cec>
    c1a4:      	ldr	x8, [x19]
    c1a8:      	ldr	x8, [x8, #0x358]
    c1ac:      	b	0xc1f4 <JNI_OnLoad+0x2fb8>
    c1b0:      	ldr	x8, [x19]
    c1b4:      	ldr	x8, [x8, #0x368]
    c1b8:      	b	0xc1f4 <JNI_OnLoad+0x2fb8>
    c1bc:      	ldr	x8, [x19]
    c1c0:      	ldr	x8, [x8, #0x380]
    c1c4:      	fmov	d0, x25
    c1c8:      	bl	0xcac4 <JNI_OnLoad+0x3888>
    c1cc:      	blr	x8
    c1d0:      	b	0xbf28 <JNI_OnLoad+0x2cec>
    c1d4:      	ldr	x8, [x19]
    c1d8:      	ldr	x8, [x8, #0x370]
    c1dc:      	bl	0xcac4 <JNI_OnLoad+0x3888>
    c1e0:      	mov	x3, x25
    c1e4:      	blr	x8
    c1e8:      	b	0xbf28 <JNI_OnLoad+0x2cec>
    c1ec:      	ldr	x8, [x19]
    c1f0:      	ldr	x8, [x8, #0x360]
    c1f4:      	bl	0xcac4 <JNI_OnLoad+0x3888>
    c1f8:      	mov	w3, w25
    c1fc:      	blr	x8
    c200:      	b	0xbf28 <JNI_OnLoad+0x2cec>
    c204:      	stp	x29, x30, [sp, #-0x60]!
    c208:      	str	x27, [sp, #0x10]
    c20c:      	stp	x26, x25, [sp, #0x20]
    c210:      	stp	x24, x23, [sp, #0x30]
    c214:      	stp	x22, x21, [sp, #0x40]
    c218:      	stp	x20, x19, [sp, #0x50]
    c21c:      	mov	x29, sp
    c220:      	bl	0xcc14 <JNI_OnLoad+0x39d8>
    c224:      	mov	x20, x5
    c228:      	mov	w25, w4
    c22c:      	ldr	x8, [x8, #0x548]
    c230:      	mov	x22, x3
    c234:      	mov	x19, x0
    c238:      	blr	x8
    c23c:      	ldr	x8, [x19]
    c240:      	mov	x21, x0
    c244:      	bl	0xc978 <JNI_OnLoad+0x373c>
    c248:      	tst	w0, #0xff
    c24c:      	b.ne	0xc29c <JNI_OnLoad+0x3060>
    c250:      	cbz	x21, 0xc290 <JNI_OnLoad+0x3054>
    c254:      	ldr	x8, [x19]
    c258:      	bl	0xcc50 <JNI_OnLoad+0x3a14>
    c25c:      	mov	x2, xzr
    c260:      	bl	0xca0c <JNI_OnLoad+0x37d0>
    c264:      	ldr	x8, [x19]
    c268:      	mov	x23, x0
    c26c:      	bl	0xc978 <JNI_OnLoad+0x373c>
    c270:      	tst	w0, #0xff
    c274:      	b.eq	0xc2bc <JNI_OnLoad+0x3080>
    c278:      	ldr	x8, [x19]
    c27c:      	mov	x0, x19
    c280:      	mov	x1, x20
    c284:      	mov	x2, x21
    c288:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    c28c:      	b	0xc29c <JNI_OnLoad+0x3060>
    c290:      	adrp	x1, 0x2000
    c294:      	add	x1, x1, #0xd4a
    c298:      	bl	0xca70 <JNI_OnLoad+0x3834>
    c29c:      	mov	x0, xzr
    c2a0:      	ldp	x20, x19, [sp, #0x50]
    c2a4:      	ldr	x27, [sp, #0x10]
    c2a8:      	ldp	x22, x21, [sp, #0x40]
    c2ac:      	ldp	x24, x23, [sp, #0x30]
    c2b0:      	ldp	x26, x25, [sp, #0x20]
    c2b4:      	ldp	x29, x30, [sp], #0x60
    c2b8:      	ret
    c2bc:      	cbz	x23, 0xc310 <JNI_OnLoad+0x30d4>
    c2c0:      	tst	w25, #0xff
    c2c4:      	b.eq	0xc330 <JNI_OnLoad+0x30f4>
    c2c8:      	cbz	x24, 0xc3c0 <JNI_OnLoad+0x3184>
    c2cc:      	bl	0xcc88 <JNI_OnLoad+0x3a4c>
    c2d0:      	mov	x3, x21
    c2d4:      	ldr	x8, [x8, #0x480]
    c2d8:      	blr	x8
    c2dc:      	ldr	x8, [x19]
    c2e0:      	mov	x25, x0
    c2e4:      	bl	0xc978 <JNI_OnLoad+0x373c>
    c2e8:      	tst	w0, #0xff
    c2ec:      	mov	x26, xzr
    c2f0:      	b.ne	0xc3dc <JNI_OnLoad+0x31a0>
    c2f4:      	cbz	x25, 0xc3dc <JNI_OnLoad+0x31a0>
    c2f8:      	bl	0xccdc <JNI_OnLoad+0x3aa0>
    c2fc:      	cmp	x0, #0x2
    c300:      	b.lo	0xc428 <JNI_OnLoad+0x31ec>
    c304:      	ldr	x8, [x19]
    c308:      	ldr	x8, [x8, #0x488]
    c30c:      	b	0xc3a4 <JNI_OnLoad+0x3168>
    c310:      	ldr	x8, [x19]
    c314:      	mov	x0, x19
    c318:      	mov	x1, x20
    c31c:      	mov	x2, x21
    c320:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    c324:      	adrp	x1, 0x2000
    c328:      	add	x1, x1, #0xaaa
    c32c:      	b	0xc298 <JNI_OnLoad+0x305c>
    c330:      	cbz	x24, 0xc3cc <JNI_OnLoad+0x3190>
    c334:      	bl	0xcb08 <JNI_OnLoad+0x38cc>
    c338:      	ldr	x8, [x19]
    c33c:      	mov	x27, x0
    c340:      	bl	0xc978 <JNI_OnLoad+0x373c>
    c344:      	tst	w0, #0xff
    c348:      	mov	x26, xzr
    c34c:      	b.ne	0xc3dc <JNI_OnLoad+0x31a0>
    c350:      	cbz	x27, 0xc3dc <JNI_OnLoad+0x31a0>
    c354:      	bl	0xcc9c <JNI_OnLoad+0x3a60>
    c358:      	mov	x3, x21
    c35c:      	ldr	x8, [x8, #0x2f0]
    c360:      	blr	x8
    c364:      	ldr	x8, [x19]
    c368:      	mov	x25, x0
    c36c:      	mov	x0, x19
    c370:      	mov	x1, x27
    c374:      	bl	0xca14 <JNI_OnLoad+0x37d8>
    c378:      	ldr	x8, [x19]
    c37c:      	bl	0xc978 <JNI_OnLoad+0x373c>
    c380:      	tst	w0, #0xff
    c384:      	mov	x26, xzr
    c388:      	b.ne	0xc3dc <JNI_OnLoad+0x31a0>
    c38c:      	cbz	x25, 0xc3dc <JNI_OnLoad+0x31a0>
    c390:      	bl	0xccdc <JNI_OnLoad+0x3aa0>
    c394:      	cmp	x0, #0x2
    c398:      	b.lo	0xc460 <JNI_OnLoad+0x3224>
    c39c:      	ldr	x8, [x19]
    c3a0:      	ldr	x8, [x8, #0x2f8]
    c3a4:      	bl	0xcb90 <JNI_OnLoad+0x3954>
    c3a8:      	bl	0xca34 <JNI_OnLoad+0x37f8>
    c3ac:      	and	w11, w0, #0xff
    c3b0:      	bfi	w11, w10, #8, #8
    c3b4:      	orr	w9, w11, w9, lsl #16
    c3b8:      	orr	x26, x8, x9
    c3bc:      	b	0xc3dc <JNI_OnLoad+0x31a0>
    c3c0:      	adrp	x1, 0x2000
    c3c4:      	add	x1, x1, #0xd82
    c3c8:      	b	0xc3d4 <JNI_OnLoad+0x3198>
    c3cc:      	adrp	x1, 0x1000
    c3d0:      	add	x1, x1, #0xe42
    c3d4:      	bl	0xca70 <JNI_OnLoad+0x3834>
    c3d8:      	mov	x26, xzr
    c3dc:      	ldr	x8, [x19]
    c3e0:      	bl	0xcc50 <JNI_OnLoad+0x3a14>
    c3e4:      	mov	x2, x23
    c3e8:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    c3ec:      	ldr	x8, [x19]
    c3f0:      	bl	0xc978 <JNI_OnLoad+0x373c>
    c3f4:      	tst	w0, #0xff
    c3f8:      	b.ne	0xc278 <JNI_OnLoad+0x303c>
    c3fc:      	bl	0xcc5c <JNI_OnLoad+0x3a20>
    c400:      	mov	x2, x26
    c404:      	bl	0xbccc <JNI_OnLoad+0x2a90>
    c408:      	ldr	x8, [x19]
    c40c:      	mov	x22, x0
    c410:      	mov	x0, x19
    c414:      	mov	x1, x20
    c418:      	mov	x2, x21
    c41c:      	bl	0xc9b8 <JNI_OnLoad+0x377c>
    c420:      	mov	x0, x22
    c424:      	b	0xc2a0 <JNI_OnLoad+0x3064>
    c428:      	ldrb	w10, [x21]
    c42c:      	bl	0xca5c <JNI_OnLoad+0x3820>
    c430:      	b.hi	0xc498 <JNI_OnLoad+0x325c>
    c434:      	nop
    c438:      	adr	x10, 0x323e
    c43c:      	mov	w0, w9
    c440:      	adr	x12, 0xc3ac <JNI_OnLoad+0x3170>
    c444:      	ldrb	w13, [x10, x11]
    c448:      	add	x12, x12, x13, lsl #2
    c44c:      	mov	w10, w9
    c450:      	br	x12
    c454:      	ldr	x8, [x19]
    c458:      	ldr	x8, [x8, #0x498]
    c45c:      	b	0xc524 <JNI_OnLoad+0x32e8>
    c460:      	ldrb	w10, [x21]
    c464:      	bl	0xca5c <JNI_OnLoad+0x3820>
    c468:      	b.hi	0xc504 <JNI_OnLoad+0x32c8>
    c46c:      	adrp	x10, 0x3000
    c470:      	add	x10, x10, #0x247
    c474:      	mov	w0, w9
    c478:      	adr	x12, 0xc3ac <JNI_OnLoad+0x3170>
    c47c:      	ldrb	w13, [x10, x11]
    c480:      	add	x12, x12, x13, lsl #2
    c484:      	mov	w10, w9
    c488:      	br	x12
    c48c:      	ldr	x8, [x19]
    c490:      	ldr	x8, [x8, #0x308]
    c494:      	b	0xc524 <JNI_OnLoad+0x32e8>
    c498:      	cmp	w10, #0x53
    c49c:      	b.eq	0xc4f8 <JNI_OnLoad+0x32bc>
    c4a0:      	cmp	w10, #0x5a
    c4a4:      	mov	w0, w9
    c4a8:      	mov	w10, w9
    c4ac:      	b.ne	0xc3ac <JNI_OnLoad+0x3170>
    c4b0:      	ldr	x8, [x19]
    c4b4:      	ldr	x8, [x8, #0x490]
    c4b8:      	b	0xc524 <JNI_OnLoad+0x32e8>
    c4bc:      	ldr	x8, [x19]
    c4c0:      	ldr	x8, [x8, #0x4c0]
    c4c4:      	b	0xc53c <JNI_OnLoad+0x3300>
    c4c8:      	ldr	x8, [x19]
    c4cc:      	ldr	x8, [x8, #0x4a0]
    c4d0:      	b	0xc5a8 <JNI_OnLoad+0x336c>
    c4d4:      	ldr	x8, [x19]
    c4d8:      	ldr	x8, [x8, #0x4b0]
    c4dc:      	b	0xc564 <JNI_OnLoad+0x3328>
    c4e0:      	ldr	x8, [x19]
    c4e4:      	ldr	x8, [x8, #0x4c8]
    c4e8:      	b	0xc578 <JNI_OnLoad+0x333c>
    c4ec:      	ldr	x8, [x19]
    c4f0:      	ldr	x8, [x8, #0x4b8]
    c4f4:      	b	0xc594 <JNI_OnLoad+0x3358>
    c4f8:      	ldr	x8, [x19]
    c4fc:      	ldr	x8, [x8, #0x4a8]
    c500:      	b	0xc5a8 <JNI_OnLoad+0x336c>
    c504:      	cmp	w10, #0x53
    c508:      	b.eq	0xc5a0 <JNI_OnLoad+0x3364>
    c50c:      	cmp	w10, #0x5a
    c510:      	mov	w0, w9
    c514:      	mov	w10, w9
    c518:      	b.ne	0xc3ac <JNI_OnLoad+0x3170>
    c51c:      	ldr	x8, [x19]
    c520:      	ldr	x8, [x8, #0x300]
    c524:      	bl	0xcab4 <JNI_OnLoad+0x3878>
    c528:      	bl	0xcafc <JNI_OnLoad+0x38c0>
    c52c:      	mov	w10, wzr
    c530:      	b	0xc3ac <JNI_OnLoad+0x3170>
    c534:      	ldr	x8, [x19]
    c538:      	ldr	x8, [x8, #0x330]
    c53c:      	mov	x0, x19
    c540:      	bl	0xccc8 <JNI_OnLoad+0x3a8c>
    c544:      	blr	x8
    c548:      	fmov	w0, s0
    c54c:      	b	0xc568 <JNI_OnLoad+0x332c>
    c550:      	ldr	x8, [x19]
    c554:      	ldr	x8, [x8, #0x310]
    c558:      	b	0xc5a8 <JNI_OnLoad+0x336c>
    c55c:      	ldr	x8, [x19]
    c560:      	ldr	x8, [x8, #0x320]
    c564:      	bl	0xcab4 <JNI_OnLoad+0x3878>
    c568:      	bl	0xcbd8 <JNI_OnLoad+0x399c>
    c56c:      	b	0xc3ac <JNI_OnLoad+0x3170>
    c570:      	ldr	x8, [x19]
    c574:      	ldr	x8, [x8, #0x338]
    c578:      	mov	x0, x19
    c57c:      	bl	0xccc8 <JNI_OnLoad+0x3a8c>
    c580:      	blr	x8
    c584:      	fmov	x0, d0
    c588:      	b	0xc598 <JNI_OnLoad+0x335c>
    c58c:      	ldr	x8, [x19]
    c590:      	ldr	x8, [x8, #0x328]
    c594:      	bl	0xcb90 <JNI_OnLoad+0x3954>
    c598:      	bl	0xca34 <JNI_OnLoad+0x37f8>
    c59c:      	b	0xc3ac <JNI_OnLoad+0x3170>
    c5a0:      	ldr	x8, [x19]
    c5a4:      	ldr	x8, [x8, #0x318]
    c5a8:      	bl	0xcab4 <JNI_OnLoad+0x3878>
    c5ac:      	ubfx	w10, w0, #8, #8
    c5b0:      	bl	0xcafc <JNI_OnLoad+0x38c0>
    c5b4:      	b	0xc3ac <JNI_OnLoad+0x3170>
    c5b8:      	sub	sp, sp, #0x40
    c5bc:      	stp	x29, x30, [sp, #0x20]
    c5c0:      	str	x19, [sp, #0x30]
    c5c4:      	add	x29, sp, #0x20
    c5c8:      	mrs	x19, TPIDR_EL0
    c5cc:      	add	x1, sp, #0x10
    c5d0:      	ldr	x8, [x19, #0x28]
    c5d4:      	stur	x8, [x29, #-0x8]
    c5d8:      	ldr	x8, [x0]
    c5dc:      	ldr	x8, [x8, #0x6d8]
    c5e0:      	blr	x8
    c5e4:      	ldr	x3, [sp, #0x10]
    c5e8:      	nop
    c5ec:      	adr	x2, 0xc638 <JNI_OnLoad+0x33fc>
    c5f0:      	add	x0, sp, #0x8
    c5f4:      	mov	x1, xzr
    c5f8:      	bl	0xce90 <pthread_create@plt>
    c5fc:      	cbz	w0, 0xc608 <JNI_OnLoad+0x33cc>
    c600:      	mov	w0, wzr
    c604:      	b	0xc618 <JNI_OnLoad+0x33dc>
    c608:      	ldr	x0, [sp, #0x8]
    c60c:      	mov	x1, sp
    c610:      	bl	0xcf10 <pthread_join@plt>
    c614:      	ldrb	w0, [sp]
    c618:      	ldr	x8, [x19, #0x28]
    c61c:      	bl	0xca50 <JNI_OnLoad+0x3814>
    c620:      	b.ne	0xc634 <JNI_OnLoad+0x33f8>
    c624:      	ldp	x29, x30, [sp, #0x20]
    c628:      	ldr	x19, [sp, #0x30]
    c62c:      	add	sp, sp, #0x40
    c630:      	ret
    c634:      	bl	0xd110 <__stack_chk_fail@plt>
    c638:      	sub	sp, sp, #0x70
    c63c:      	stp	x29, x30, [sp, #0x20]
    c640:      	stp	x26, x25, [sp, #0x30]
    c644:      	stp	x24, x23, [sp, #0x40]
    c648:      	stp	x22, x21, [sp, #0x50]
    c64c:      	stp	x20, x19, [sp, #0x60]
    c650:      	add	x29, sp, #0x20
    c654:      	mrs	x26, TPIDR_EL0
    c658:      	ldr	x8, [x26, #0x28]
    c65c:      	stur	x8, [x29, #-0x8]
    c660:      	cbz	x0, 0xc6dc <JNI_OnLoad+0x34a0>
    c664:      	ldr	x8, [x0]
    c668:      	add	x1, sp, #0x10
    c66c:      	mov	x2, xzr
    c670:      	mov	x19, x0
    c674:      	ldr	x8, [x8, #0x20]
    c678:      	blr	x8
    c67c:      	ldr	x0, [sp, #0x10]
    c680:      	adrp	x1, 0x2000
    c684:      	add	x1, x1, #0xda3
    c688:      	ldr	x8, [x0]
    c68c:      	bl	0xcaec <JNI_OnLoad+0x38b0>
    c690:      	ldr	x8, [sp, #0x10]
    c694:      	mov	x20, x0
    c698:      	bl	0xc98c <JNI_OnLoad+0x3750>
    c69c:      	tst	w0, #0xff
    c6a0:      	mov	x25, xzr
    c6a4:      	b.ne	0xc7a0 <JNI_OnLoad+0x3564>
    c6a8:      	ldr	x0, [sp, #0x10]
    c6ac:      	adrp	x2, 0x2000
    c6b0:      	add	x2, x2, #0x222
    c6b4:      	adrp	x3, 0x2000
    c6b8:      	add	x3, x3, #0x340
    c6bc:      	bl	0xcb58 <JNI_OnLoad+0x391c>
    c6c0:      	ldr	x8, [sp, #0x10]
    c6c4:      	mov	x22, x0
    c6c8:      	bl	0xc98c <JNI_OnLoad+0x3750>
    c6cc:      	tst	w0, #0xff
    c6d0:      	b.eq	0xc6e4 <JNI_OnLoad+0x34a8>
    c6d4:      	mov	x25, xzr
    c6d8:      	b	0xc7a0 <JNI_OnLoad+0x3564>
    c6dc:      	mov	x25, xzr
    c6e0:      	b	0xc7c0 <JNI_OnLoad+0x3584>
    c6e4:      	ldr	x0, [sp, #0x10]
    c6e8:      	adrp	x1, 0x2000
    c6ec:      	add	x1, x1, #0x22e
    c6f0:      	ldr	x8, [x0]
    c6f4:      	bl	0xcaec <JNI_OnLoad+0x38b0>
    c6f8:      	ldr	x8, [sp, #0x10]
    c6fc:      	mov	x21, x0
    c700:      	bl	0xc98c <JNI_OnLoad+0x3750>
    c704:      	tst	w0, #0xff
    c708:      	b.eq	0xc714 <JNI_OnLoad+0x34d8>
    c70c:      	mov	x25, xzr
    c710:      	b	0xc78c <JNI_OnLoad+0x3550>
    c714:      	ldr	x0, [sp, #0x10]
    c718:      	mov	x1, x20
    c71c:      	mov	x2, x22
    c720:      	mov	x3, x21
    c724:      	mov	w4, #0x1                // =1
    c728:      	ldr	x8, [x0]
    c72c:      	ldr	x8, [x8, #0x390]
    c730:      	blr	x8
    c734:      	ldr	x8, [sp, #0x10]
    c738:      	mov	x22, x0
    c73c:      	bl	0xc98c <JNI_OnLoad+0x3750>
    c740:      	tst	w0, #0xff
    c744:      	b.ne	0xc774 <JNI_OnLoad+0x3538>
    c748:      	ldr	x0, [sp, #0x10]
    c74c:      	adrp	x2, 0x1000
    c750:      	add	x2, x2, #0xaee
    c754:      	adrp	x3, 0x1000
    c758:      	add	x3, x3, #0xe64
    c75c:      	bl	0xcb58 <JNI_OnLoad+0x391c>
    c760:      	ldr	x8, [sp, #0x10]
    c764:      	mov	x24, x0
    c768:      	bl	0xc98c <JNI_OnLoad+0x3750>
    c76c:      	tst	w0, #0xff
    c770:      	b.eq	0xc7ec <JNI_OnLoad+0x35b0>
    c774:      	mov	x25, xzr
    c778:      	cbz	x22, 0xc78c <JNI_OnLoad+0x3550>
    c77c:      	ldr	x0, [sp, #0x10]
    c780:      	mov	x1, x22
    c784:      	ldr	x8, [x0]
    c788:      	bl	0xca14 <JNI_OnLoad+0x37d8>
    c78c:      	cbz	x21, 0xc7a0 <JNI_OnLoad+0x3564>
    c790:      	ldr	x0, [sp, #0x10]
    c794:      	mov	x1, x21
    c798:      	ldr	x8, [x0]
    c79c:      	bl	0xca14 <JNI_OnLoad+0x37d8>
    c7a0:      	cbz	x20, 0xc7b4 <JNI_OnLoad+0x3578>
    c7a4:      	ldr	x0, [sp, #0x10]
    c7a8:      	mov	x1, x20
    c7ac:      	ldr	x8, [x0]
    c7b0:      	bl	0xca14 <JNI_OnLoad+0x37d8>
    c7b4:      	bl	0xcc68 <JNI_OnLoad+0x3a2c>
    c7b8:      	ldr	x8, [x8, #0x28]
    c7bc:      	blr	x8
    c7c0:      	ldr	x8, [x26, #0x28]
    c7c4:      	bl	0xca50 <JNI_OnLoad+0x3814>
    c7c8:      	b.ne	0xc974 <JNI_OnLoad+0x3738>
    c7cc:      	mov	x0, x25
    c7d0:      	ldp	x20, x19, [sp, #0x60]
    c7d4:      	ldp	x22, x21, [sp, #0x50]
    c7d8:      	ldp	x24, x23, [sp, #0x40]
    c7dc:      	ldp	x26, x25, [sp, #0x30]
    c7e0:      	ldp	x29, x30, [sp, #0x20]
    c7e4:      	add	sp, sp, #0x70
    c7e8:      	ret
    c7ec:      	ldr	x0, [sp, #0x10]
    c7f0:      	adrp	x1, 0x2000
    c7f4:      	add	x1, x1, #0x1b4
    c7f8:      	bl	0xcaa8 <JNI_OnLoad+0x386c>
    c7fc:      	ldr	x8, [sp, #0x10]
    c800:      	mov	x23, x0
    c804:      	bl	0xc98c <JNI_OnLoad+0x3750>
    c808:      	tst	w0, #0xff
    c80c:      	b.ne	0xc848 <JNI_OnLoad+0x360c>
    c810:      	ldr	x0, [sp, #0x10]
    c814:      	mov	x1, x20
    c818:      	mov	x2, x24
    c81c:      	mov	x3, x22
    c820:      	mov	w4, wzr
    c824:      	mov	x5, x23
    c828:      	ldr	x8, [x0]
    c82c:      	ldr	x8, [x8, #0x468]
    c830:      	blr	x8
    c834:      	ldr	x0, [sp, #0x10]
    c838:      	ldr	x8, [x0]
    c83c:      	bl	0xc984 <JNI_OnLoad+0x3748>
    c840:      	tst	w0, #0xff
    c844:      	b.eq	0xc864 <JNI_OnLoad+0x3628>
    c848:      	mov	x25, xzr
    c84c:      	cbz	x23, 0xc778 <JNI_OnLoad+0x353c>
    c850:      	ldr	x0, [sp, #0x10]
    c854:      	mov	x1, x23
    c858:      	ldr	x8, [x0]
    c85c:      	bl	0xca14 <JNI_OnLoad+0x37d8>
    c860:      	b	0xc778 <JNI_OnLoad+0x353c>
    c864:      	ldr	x0, [sp, #0x10]
    c868:      	adrp	x1, 0x2000
    c86c:      	add	x1, x1, #0x367
    c870:      	ldr	x8, [x0]
    c874:      	bl	0xcaec <JNI_OnLoad+0x38b0>
    c878:      	ldr	x8, [sp, #0x10]
    c87c:      	mov	x24, x0
    c880:      	bl	0xc98c <JNI_OnLoad+0x3750>
    c884:      	tst	w0, #0xff
    c888:      	b.ne	0xc8b8 <JNI_OnLoad+0x367c>
    c88c:      	ldr	x0, [sp, #0x10]
    c890:      	adrp	x2, 0x2000
    c894:      	add	x2, x2, #0x686
    c898:      	adrp	x3, 0x1000
    c89c:      	add	x3, x3, #0xd54
    c8a0:      	bl	0xcbc8 <JNI_OnLoad+0x398c>
    c8a4:      	ldr	x8, [sp, #0x10]
    c8a8:      	mov	x25, x0
    c8ac:      	bl	0xc98c <JNI_OnLoad+0x3750>
    c8b0:      	tst	w0, #0xff
    c8b4:      	b.eq	0xc8d4 <JNI_OnLoad+0x3698>
    c8b8:      	mov	x25, xzr
    c8bc:      	cbz	x24, 0xc84c <JNI_OnLoad+0x3610>
    c8c0:      	ldr	x0, [sp, #0x10]
    c8c4:      	mov	x1, x24
    c8c8:      	ldr	x8, [x0]
    c8cc:      	bl	0xca14 <JNI_OnLoad+0x37d8>
    c8d0:      	b	0xc84c <JNI_OnLoad+0x3610>
    c8d4:      	ldr	x0, [sp, #0x10]
    c8d8:      	bl	0xccc8 <JNI_OnLoad+0x3a8c>
    c8dc:      	ldr	x8, [x0]
    c8e0:      	ldr	x8, [x8, #0xe0]
    c8e4:      	blr	x8
    c8e8:      	ldr	x8, [sp, #0x10]
    c8ec:      	str	x0, [sp, #0x8]
    c8f0:      	bl	0xc98c <JNI_OnLoad+0x3750>
    c8f4:      	tst	w0, #0xff
    c8f8:      	b.ne	0xc928 <JNI_OnLoad+0x36ec>
    c8fc:      	ldr	x0, [sp, #0x10]
    c900:      	adrp	x2, 0x2000
    c904:      	add	x2, x2, #0x472
    c908:      	adrp	x3, 0x2000
    c90c:      	add	x3, x3, #0x489
    c910:      	bl	0xcbc8 <JNI_OnLoad+0x398c>
    c914:      	ldr	x8, [sp, #0x10]
    c918:      	mov	x25, x0
    c91c:      	bl	0xc98c <JNI_OnLoad+0x3750>
    c920:      	tst	w0, #0xff
    c924:      	b.eq	0xc944 <JNI_OnLoad+0x3708>
    c928:      	mov	x25, xzr
    c92c:      	ldr	x1, [sp, #0x8]
    c930:      	cbz	x1, 0xc8bc <JNI_OnLoad+0x3680>
    c934:      	ldr	x0, [sp, #0x10]
    c938:      	ldr	x8, [x0]
    c93c:      	bl	0xca14 <JNI_OnLoad+0x37d8>
    c940:      	b	0xc8bc <JNI_OnLoad+0x3680>
    c944:      	ldp	x1, x0, [sp, #0x8]
    c948:      	mov	x2, x25
    c94c:      	mov	x3, x22
    c950:      	ldr	x8, [x0]
    c954:      	ldr	x8, [x8, #0x1e8]
    c958:      	blr	x8
    c95c:      	ldr	x0, [sp, #0x10]
    c960:      	ldr	x8, [x0]
    c964:      	bl	0xc984 <JNI_OnLoad+0x3748>
    c968:      	tst	w0, #0xff
    c96c:      	cset	w25, eq
    c970:      	b	0xc92c <JNI_OnLoad+0x36f0>
    c974:      	bl	0xd110 <__stack_chk_fail@plt>
    c978:      	mov	x0, x19
    c97c:      	ldr	x8, [x8, #0x720]
    c980:      	br	x8
    c984:      	ldr	x8, [x8, #0x720]
    c988:      	br	x8
    c98c:      	ldr	x9, [x8]
    c990:      	mov	x0, x8
    c994:      	ldr	x9, [x9, #0x720]
    c998:      	br	x9
    c99c:      	adrp	x3, 0x1000
    c9a0:      	add	x3, x3, #0xef3
    c9a4:      	mov	x0, x21
    c9a8:      	mov	x1, x20
    c9ac:      	mov	x4, x19
    c9b0:      	mov	x5, xzr
    c9b4:      	b	0xba64 <JNI_OnLoad+0x2828>
    c9b8:      	ldr	x8, [x8, #0x550]
    c9bc:      	br	x8
    c9c0:      	ldr	x8, [x21]
    c9c4:      	mov	x0, x21
    c9c8:      	mov	x1, x20
    c9cc:      	mov	x2, x22
    c9d0:      	mov	x3, x19
    c9d4:      	ret
    c9d8:      	ldr	x8, [x21]
    c9dc:      	mov	x0, x21
    c9e0:      	mov	x1, x20
    c9e4:      	mov	x2, x23
    c9e8:      	mov	x3, x19
    c9ec:      	ret
    c9f0:      	stp	x28, x27, [sp, #0x10]
    c9f4:      	mov	x29, sp
    c9f8:      	stp	x26, x25, [sp, #0x20]
    c9fc:      	stp	x24, x23, [sp, #0x30]
    ca00:      	stp	x22, x21, [sp, #0x40]
    ca04:      	stp	x20, x19, [sp, #0x50]
    ca08:      	ret
    ca0c:      	ldr	x8, [x8, #0x548]
    ca10:      	br	x8
    ca14:      	ldr	x8, [x8, #0xb8]
    ca18:      	br	x8
    ca1c:      	ldp	x20, x19, [sp, #0x50]
    ca20:      	ldp	x22, x21, [sp, #0x40]
    ca24:      	ldp	x24, x23, [sp, #0x30]
    ca28:      	ldp	x26, x25, [sp, #0x20]
    ca2c:      	ldp	x28, x27, [sp, #0x10]
    ca30:      	ret
    ca34:      	lsr	x10, x0, #8
    ca38:      	lsr	x9, x0, #16
    ca3c:      	and	x8, x0, #0xffffffff00000000
    ca40:      	ret
    ca44:      	adrp	x9, 0x1000
    ca48:      	add	x9, x9, #0xeeb
    ca4c:      	ret
    ca50:      	ldur	x9, [x29, #-0x8]
    ca54:      	cmp	x8, x9
    ca58:      	ret
    ca5c:      	mov	w9, wzr
    ca60:      	mov	x8, xzr
    ca64:      	sub	w11, w10, #0x42
    ca68:      	cmp	w11, #0x8
    ca6c:      	ret
    ca70:      	mov	x0, x19
    ca74:      	b	0xb204 <JNI_OnLoad+0x1fc8>
    ca78:      	mov	x0, x8
    ca7c:      	b	0xce60 <strlen@plt>
    ca80:      	ldr	w8, [x20]
    ca84:      	cmp	w8, #0x4
    ca88:      	ret
    ca8c:      	adrp	x1, 0x1000
    ca90:      	add	x1, x1, #0xeeb
    ca94:      	add	x0, sp, #0xd0
    ca98:      	mov	w2, #0x100              // =256
    ca9c:      	mov	x3, #-0x1               // =-1
    caa0:      	mov	w4, #0x8                // =8
    caa4:      	b	0xcf70 <__strncpy_chk2@plt>
    caa8:      	ldr	x8, [x0]
    caac:      	ldr	x8, [x8, #0x538]
    cab0:      	br	x8
    cab4:      	mov	x0, x19
    cab8:      	mov	x1, x24
    cabc:      	mov	x2, x25
    cac0:      	br	x8
    cac4:      	mov	x0, x19
    cac8:      	mov	x1, x24
    cacc:      	mov	x2, x26
    cad0:      	ret
    cad4:      	mov	w1, #0x641              // =1601
    cad8:      	mov	x0, x22
    cadc:      	mov	w2, #0x1a4              // =420
    cae0:      	movk	w1, #0x8, lsl #16
    cae4:      	str	wzr, [x20]
    cae8:      	b	0xce40 <open@plt>
    caec:      	ldr	x8, [x8, #0x30]
    caf0:      	br	x8
    caf4:      	mov	x20, x8
    caf8:      	b	0xcdc0 <free@plt>
    cafc:      	mov	x8, xzr
    cb00:      	mov	w9, wzr
    cb04:      	ret
    cb08:      	ldr	x8, [x19]
    cb0c:      	mov	x0, x19
    cb10:      	mov	x1, x24
    cb14:      	ldr	x8, [x8, #0xf8]
    cb18:      	br	x8
    cb1c:      	str	wzr, [x20]
    cb20:      	mov	w1, #0x4000             // =16384
    cb24:      	ldr	x0, [x21, #0x340]
    cb28:      	movk	w1, #0x8, lsl #16
    cb2c:      	b	0xce00 <__open_2@plt>
    cb30:      	mov	x0, x21
    cb34:      	mov	x1, x20
    cb38:      	mov	x2, x23
    cb3c:      	mov	x3, x19
    cb40:      	br	x8
    cb44:      	mov	x0, x21
    cb48:      	mov	x1, x20
    cb4c:      	mov	x2, x22
    cb50:      	mov	x3, x19
    cb54:      	br	x8
    cb58:      	mov	x1, x20
    cb5c:      	ldr	x8, [x0]
    cb60:      	ldr	x8, [x8, #0x388]
    cb64:      	br	x8
    cb68:      	ldr	x8, [sp, #0x10]
    cb6c:      	ldr	w8, [x8]
    cb70:      	cmp	w8, #0x11
    cb74:      	ret
    cb78:      	stp	q4, q5, [sp, #0x40]
    cb7c:      	stp	q6, q7, [sp, #0x60]
    cb80:      	mrs	x19, TPIDR_EL0
    cb84:      	ldr	x8, [x19, #0x28]
    cb88:      	stur	x8, [x29, #-0x8]
    cb8c:      	ret
    cb90:      	mov	x0, x19
    cb94:      	mov	x1, x24
    cb98:      	mov	x2, x25
    cb9c:      	br	x8
    cba0:      	sub	x9, x29, #0x28
    cba4:      	movk	x8, #0xff80, lsl #32
    cba8:      	stp	x10, x8, [x29, #-0x18]
    cbac:      	ldp	q0, q1, [x9]
    cbb0:      	stp	q0, q1, [x29, #-0x50]
    cbb4:      	ret
    cbb8:      	ldr	x8, [x19]
    cbbc:      	mov	x0, x19
    cbc0:      	mov	x1, x27
    cbc4:      	ret
    cbc8:      	mov	x1, x24
    cbcc:      	ldr	x8, [x0]
    cbd0:      	ldr	x8, [x8, #0x108]
    cbd4:      	br	x8
    cbd8:      	lsr	w10, w0, #8
    cbdc:      	lsr	w9, w0, #16
    cbe0:      	mov	x8, xzr
    cbe4:      	ret
    cbe8:      	ldr	x8, [x8, #0x88]
    cbec:      	br	x8
    cbf0:      	and	w11, w0, #0xff
    cbf4:      	bfi	w11, w10, #8, #8
    cbf8:      	orr	w9, w11, w9, lsl #16
    cbfc:      	orr	x0, x8, x9
    cc00:      	ret
    cc04:      	str	wzr, [x8]
    cc08:      	b	0xcf40 <mkdir@plt>
    cc0c:      	mov	x0, x25
    cc10:      	b	0xcdc0 <free@plt>
    cc14:      	ldr	x8, [x0]
    cc18:      	mov	x24, x2
    cc1c:      	mov	x1, x5
    cc20:      	mov	x2, xzr
    cc24:      	ret
    cc28:      	mov	x1, x25
    cc2c:      	b	0xb5cc <JNI_OnLoad+0x2390>
    cc30:      	add	x0, sp, #0xd0
    cc34:      	mov	w1, #0x100              // =256
    cc38:      	b	0xcdf0 <__strlen_chk@plt>
    cc3c:      	mov	x0, x22
    cc40:      	b	0xce60 <strlen@plt>
    cc44:      	mov	x0, x19
    cc48:      	mov	x1, x23
    cc4c:      	ret
    cc50:      	mov	x0, x19
    cc54:      	mov	x1, x22
    cc58:      	ret
    cc5c:      	mov	x0, x19
    cc60:      	mov	x1, x21
    cc64:      	ret
    cc68:      	ldr	x8, [x19]
    cc6c:      	mov	x0, x19
    cc70:      	ret
    cc74:      	ldr	x8, [x19]
    cc78:      	mov	x0, x19
    cc7c:      	mov	x1, x20
    cc80:      	mov	x2, x23
    cc84:      	ret
    cc88:      	ldr	x8, [x19]
    cc8c:      	mov	x0, x19
    cc90:      	mov	x1, x24
    cc94:      	mov	x2, x23
    cc98:      	ret
    cc9c:      	ldr	x8, [x19]
    cca0:      	mov	x0, x19
    cca4:      	mov	x1, x27
    cca8:      	mov	x2, x23
    ccac:      	ret
    ccb0:      	mov	x11, x28
    ccb4:      	mov	x28, x10
    ccb8:      	ret
    ccbc:      	adrp	x0, 0x17000
    ccc0:      	add	x0, x0, #0x3f0
    ccc4:      	b	0xcee0 <pthread_mutex_unlock@plt>
    ccc8:      	mov	x1, x24
    cccc:      	mov	x2, x25
    ccd0:      	ret
    ccd4:      	str	wzr, [x20]
    ccd8:      	b	0xce00 <__open_2@plt>
    ccdc:      	mov	x0, x21
    cce0:      	b	0xce60 <strlen@plt>
    cce4:      	mov	x0, x21
    cce8:      	b	0xb088 <JNI_OnLoad+0x1e4c>
    ccec:      	mov	x0, x21
    ccf0:      	b	0xcdc0 <free@plt>
    ccf4:      	ldp	x2, x5, [x29, #-0x18]
    ccf8:      	mov	x3, x21
    ccfc:      	ldur	x1, [x29, #-0x48]
    cd00:      	mov	x4, x26
    cd04:      	ret
    cd08:      	mov	x0, x24
    cd0c:      	b	0xcdc0 <free@plt>
    cd10:      	ldp	x10, x9, [x19, #0x18]
    cd14:      	sub	x4, x20, x8
    cd18:      	ldr	x11, [x19, #0x10]
    cd1c:      	ldr	x3, [x19]
    cd20:      	ret

Disassembly of section .plt:

000000000000cd30 <.plt>:
    cd30:      	stp	x16, x30, [sp, #-0x10]!
    cd34:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cd38:      	ldr	x17, [x16, #0x3f8]
    cd3c:      	add	x16, x16, #0x3f8
    cd40:      	br	x17
    cd44:      	nop
    cd48:      	nop
    cd4c:      	nop

000000000000cd50 <__cxa_finalize@plt>:
    cd50:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cd54:      	ldr	x17, [x16, #0x400]
    cd58:      	add	x16, x16, #0x400
    cd5c:      	br	x17

000000000000cd60 <__cxa_atexit@plt>:
    cd60:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cd64:      	ldr	x17, [x16, #0x408]
    cd68:      	add	x16, x16, #0x408
    cd6c:      	br	x17

000000000000cd70 <gettimeofday@plt>:
    cd70:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cd74:      	ldr	x17, [x16, #0x410]
    cd78:      	add	x16, x16, #0x410
    cd7c:      	br	x17

000000000000cd80 <__errno@plt>:
    cd80:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cd84:      	ldr	x17, [x16, #0x418]
    cd88:      	add	x16, x16, #0x418
    cd8c:      	br	x17

000000000000cd90 <localtime_r@plt>:
    cd90:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cd94:      	ldr	x17, [x16, #0x420]
    cd98:      	add	x16, x16, #0x420
    cd9c:      	br	x17

000000000000cda0 <strdup@plt>:
    cda0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cda4:      	ldr	x17, [x16, #0x428]
    cda8:      	add	x16, x16, #0x428
    cdac:      	br	x17

000000000000cdb0 <getpid@plt>:
    cdb0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cdb4:      	ldr	x17, [x16, #0x430]
    cdb8:      	add	x16, x16, #0x430
    cdbc:      	br	x17

000000000000cdc0 <free@plt>:
    cdc0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cdc4:      	ldr	x17, [x16, #0x438]
    cdc8:      	add	x16, x16, #0x438
    cdcc:      	br	x17

000000000000cdd0 <lseek@plt>:
    cdd0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cdd4:      	ldr	x17, [x16, #0x440]
    cdd8:      	add	x16, x16, #0x440
    cddc:      	br	x17

000000000000cde0 <close@plt>:
    cde0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cde4:      	ldr	x17, [x16, #0x448]
    cde8:      	add	x16, x16, #0x448
    cdec:      	br	x17

000000000000cdf0 <__strlen_chk@plt>:
    cdf0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cdf4:      	ldr	x17, [x16, #0x450]
    cdf8:      	add	x16, x16, #0x450
    cdfc:      	br	x17

000000000000ce00 <__open_2@plt>:
    ce00:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    ce04:      	ldr	x17, [x16, #0x458]
    ce08:      	add	x16, x16, #0x458
    ce0c:      	br	x17

000000000000ce10 <syscall@plt>:
    ce10:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    ce14:      	ldr	x17, [x16, #0x460]
    ce18:      	add	x16, x16, #0x460
    ce1c:      	br	x17

000000000000ce20 <memcmp@plt>:
    ce20:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    ce24:      	ldr	x17, [x16, #0x468]
    ce28:      	add	x16, x16, #0x468
    ce2c:      	br	x17

000000000000ce30 <rename@plt>:
    ce30:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    ce34:      	ldr	x17, [x16, #0x470]
    ce38:      	add	x16, x16, #0x470
    ce3c:      	br	x17

000000000000ce40 <open@plt>:
    ce40:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    ce44:      	ldr	x17, [x16, #0x478]
    ce48:      	add	x16, x16, #0x478
    ce4c:      	br	x17

000000000000ce50 <read@plt>:
    ce50:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    ce54:      	ldr	x17, [x16, #0x480]
    ce58:      	add	x16, x16, #0x480
    ce5c:      	br	x17

000000000000ce60 <strlen@plt>:
    ce60:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    ce64:      	ldr	x17, [x16, #0x488]
    ce68:      	add	x16, x16, #0x488
    ce6c:      	br	x17

000000000000ce70 <calloc@plt>:
    ce70:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    ce74:      	ldr	x17, [x16, #0x490]
    ce78:      	add	x16, x16, #0x490
    ce7c:      	br	x17

000000000000ce80 <eventfd@plt>:
    ce80:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    ce84:      	ldr	x17, [x16, #0x498]
    ce88:      	add	x16, x16, #0x498
    ce8c:      	br	x17

000000000000ce90 <pthread_create@plt>:
    ce90:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    ce94:      	ldr	x17, [x16, #0x4a0]
    ce98:      	add	x16, x16, #0x4a0
    ce9c:      	br	x17

000000000000cea0 <pthread_mutex_lock@plt>:
    cea0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cea4:      	ldr	x17, [x16, #0x4a8]
    cea8:      	add	x16, x16, #0x4a8
    ceac:      	br	x17

000000000000ceb0 <clock_gettime@plt>:
    ceb0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    ceb4:      	ldr	x17, [x16, #0x4b0]
    ceb8:      	add	x16, x16, #0x4b0
    cebc:      	br	x17

000000000000cec0 <gettid@plt>:
    cec0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cec4:      	ldr	x17, [x16, #0x4b8]
    cec8:      	add	x16, x16, #0x4b8
    cecc:      	br	x17

000000000000ced0 <prctl@plt>:
    ced0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    ced4:      	ldr	x17, [x16, #0x4c0]
    ced8:      	add	x16, x16, #0x4c0
    cedc:      	br	x17

000000000000cee0 <pthread_mutex_unlock@plt>:
    cee0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cee4:      	ldr	x17, [x16, #0x4c8]
    cee8:      	add	x16, x16, #0x4c8
    ceec:      	br	x17

000000000000cef0 <_exit@plt>:
    cef0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cef4:      	ldr	x17, [x16, #0x4d0]
    cef8:      	add	x16, x16, #0x4d0
    cefc:      	br	x17

000000000000cf00 <dup2@plt>:
    cf00:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cf04:      	ldr	x17, [x16, #0x4d8]
    cf08:      	add	x16, x16, #0x4d8
    cf0c:      	br	x17

000000000000cf10 <pthread_join@plt>:
    cf10:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cf14:      	ldr	x17, [x16, #0x4e0]
    cf18:      	add	x16, x16, #0x4e0
    cf1c:      	br	x17

000000000000cf20 <write@plt>:
    cf20:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cf24:      	ldr	x17, [x16, #0x4e8]
    cf28:      	add	x16, x16, #0x4e8
    cf2c:      	br	x17

000000000000cf30 <malloc@plt>:
    cf30:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cf34:      	ldr	x17, [x16, #0x4f0]
    cf38:      	add	x16, x16, #0x4f0
    cf3c:      	br	x17

000000000000cf40 <mkdir@plt>:
    cf40:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cf44:      	ldr	x17, [x16, #0x4f8]
    cf48:      	add	x16, x16, #0x4f8
    cf4c:      	br	x17

000000000000cf50 <uname@plt>:
    cf50:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cf54:      	ldr	x17, [x16, #0x500]
    cf58:      	add	x16, x16, #0x500
    cf5c:      	br	x17

000000000000cf60 <__memcpy_chk@plt>:
    cf60:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cf64:      	ldr	x17, [x16, #0x508]
    cf68:      	add	x16, x16, #0x508
    cf6c:      	br	x17

000000000000cf70 <__strncpy_chk2@plt>:
    cf70:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cf74:      	ldr	x17, [x16, #0x510]
    cf78:      	add	x16, x16, #0x510
    cf7c:      	br	x17

000000000000cf80 <sigaltstack@plt>:
    cf80:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cf84:      	ldr	x17, [x16, #0x518]
    cf88:      	add	x16, x16, #0x518
    cf8c:      	br	x17

000000000000cf90 <sigfillset@plt>:
    cf90:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cf94:      	ldr	x17, [x16, #0x520]
    cf98:      	add	x16, x16, #0x520
    cf9c:      	br	x17

000000000000cfa0 <sigaction@plt>:
    cfa0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cfa4:      	ldr	x17, [x16, #0x528]
    cfa8:      	add	x16, x16, #0x528
    cfac:      	br	x17

000000000000cfb0 <sigemptyset@plt>:
    cfb0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cfb4:      	ldr	x17, [x16, #0x530]
    cfb8:      	add	x16, x16, #0x530
    cfbc:      	br	x17

000000000000cfc0 <dladdr@plt>:
    cfc0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cfc4:      	ldr	x17, [x16, #0x538]
    cfc8:      	add	x16, x16, #0x538
    cfcc:      	br	x17

000000000000cfd0 <fopen@plt>:
    cfd0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cfd4:      	ldr	x17, [x16, #0x540]
    cfd8:      	add	x16, x16, #0x540
    cfdc:      	br	x17

000000000000cfe0 <fclose@plt>:
    cfe0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cfe4:      	ldr	x17, [x16, #0x548]
    cfe8:      	add	x16, x16, #0x548
    cfec:      	br	x17

000000000000cff0 <access@plt>:
    cff0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    cff4:      	ldr	x17, [x16, #0x550]
    cff8:      	add	x16, x16, #0x550
    cffc:      	br	x17

000000000000d000 <fgets@plt>:
    d000:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d004:      	ldr	x17, [x16, #0x558]
    d008:      	add	x16, x16, #0x558
    d00c:      	br	x17

000000000000d010 <vsnprintf@plt>:
    d010:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d014:      	ldr	x17, [x16, #0x560]
    d018:      	add	x16, x16, #0x560
    d01c:      	br	x17

000000000000d020 <munmap@plt>:
    d020:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d024:      	ldr	x17, [x16, #0x568]
    d028:      	add	x16, x16, #0x568
    d02c:      	br	x17

000000000000d030 <strcmp@plt>:
    d030:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d034:      	ldr	x17, [x16, #0x570]
    d038:      	add	x16, x16, #0x570
    d03c:      	br	x17

000000000000d040 <sscanf@plt>:
    d040:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d044:      	ldr	x17, [x16, #0x578]
    d048:      	add	x16, x16, #0x578
    d04c:      	br	x17

000000000000d050 <fstat@plt>:
    d050:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d054:      	ldr	x17, [x16, #0x580]
    d058:      	add	x16, x16, #0x580
    d05c:      	br	x17

000000000000d060 <mmap@plt>:
    d060:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d064:      	ldr	x17, [x16, #0x588]
    d068:      	add	x16, x16, #0x588
    d06c:      	br	x17

000000000000d070 <dl_iterate_phdr@plt>:
    d070:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d074:      	ldr	x17, [x16, #0x590]
    d078:      	add	x16, x16, #0x590
    d07c:      	br	x17

000000000000d080 <fprintf@plt>:
    d080:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d084:      	ldr	x17, [x16, #0x598]
    d088:      	add	x16, x16, #0x598
    d08c:      	br	x17

000000000000d090 <fflush@plt>:
    d090:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d094:      	ldr	x17, [x16, #0x5a0]
    d098:      	add	x16, x16, #0x5a0
    d09c:      	br	x17

000000000000d0a0 <abort@plt>:
    d0a0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d0a4:      	ldr	x17, [x16, #0x5a8]
    d0a8:      	add	x16, x16, #0x5a8
    d0ac:      	br	x17

000000000000d0b0 <memcpy@plt>:
    d0b0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d0b4:      	ldr	x17, [x16, #0x5b0]
    d0b8:      	add	x16, x16, #0x5b0
    d0bc:      	br	x17

000000000000d0c0 <pthread_rwlock_wrlock@plt>:
    d0c0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d0c4:      	ldr	x17, [x16, #0x5b8]
    d0c8:      	add	x16, x16, #0x5b8
    d0cc:      	br	x17

000000000000d0d0 <pthread_rwlock_unlock@plt>:
    d0d0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d0d4:      	ldr	x17, [x16, #0x5c0]
    d0d8:      	add	x16, x16, #0x5c0
    d0dc:      	br	x17

000000000000d0e0 <memset@plt>:
    d0e0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d0e4:      	ldr	x17, [x16, #0x5c8]
    d0e8:      	add	x16, x16, #0x5c8
    d0ec:      	br	x17

000000000000d0f0 <pthread_rwlock_rdlock@plt>:
    d0f0:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d0f4:      	ldr	x17, [x16, #0x5d0]
    d0f8:      	add	x16, x16, #0x5d0
    d0fc:      	br	x17

000000000000d100 <fwrite@plt>:
    d100:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d104:      	ldr	x17, [x16, #0x5d8]
    d108:      	add	x16, x16, #0x5d8
    d10c:      	br	x17

000000000000d110 <__stack_chk_fail@plt>:
    d110:      	adrp	x16, 0x11000 <__stack_chk_fail@plt+0x3ef0>
    d114:      	ldr	x17, [x16, #0x5e0]
    d118:      	add	x16, x16, #0x5e0
    d11c:      	br	x17
