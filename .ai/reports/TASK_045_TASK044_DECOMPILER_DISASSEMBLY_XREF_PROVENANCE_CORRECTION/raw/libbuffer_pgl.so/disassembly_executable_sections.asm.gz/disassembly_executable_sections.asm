
F:\CONVERT\com.mt.mtxx.mtxx\SOURCE\extracted_native_libs\lib\arm64-v8a\libbuffer_pgl.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000fec <.text>:
     fec:      	adrp	x0, 0x5000 <mremap@plt+0x36c0>
     ff0:      	add	x0, x0, #0x950
     ff4:      	b	0x1840 <__cxa_finalize@plt>
     ff8:      	ret
     ffc:      	b	0xff8 <.text+0xc>
    1000:      	cbz	x0, 0x1008 <.text+0x1c>
    1004:      	br	x0
    1008:      	ret
    100c:      	adrp	x8, 0x1000 <.text+0x14>
    1010:      	add	x8, x8, #0x0
    1014:      	adrp	x2, 0x5000 <mremap@plt+0x36c0>
    1018:      	add	x2, x2, #0x950
    101c:      	mov	x1, x0
    1020:      	mov	x0, x8
    1024:      	b	0x1850 <__cxa_atexit@plt>

0000000000001028 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MMapBuffer_nCreate>:
    1028:      	stp	x29, x30, [sp, #-0x40]!
    102c:      	str	x23, [sp, #0x10]
    1030:      	stp	x22, x21, [sp, #0x20]
    1034:      	stp	x20, x19, [sp, #0x30]
    1038:      	mov	x29, sp
    103c:      	ldr	x8, [x0]
    1040:      	mov	x23, x2
    1044:      	mov	x1, x2
    1048:      	mov	x2, xzr
    104c:      	ldr	x8, [x8, #0x548]
    1050:      	mov	x21, x3
    1054:      	mov	x19, x0
    1058:      	blr	x8
    105c:      	mov	w1, #0x42               // =66
    1060:      	movk	w1, #0x8, lsl #16
    1064:      	mov	w2, #0x1b6              // =438
    1068:      	mov	x20, x0
    106c:      	bl	0x1860 <open@plt>
    1070:      	ldr	x8, [x19]
    1074:      	mov	w22, w0
    1078:      	mov	x0, x19
    107c:      	mov	x1, x23
    1080:      	ldr	x8, [x8, #0x550]
    1084:      	mov	x2, x20
    1088:      	blr	x8
    108c:      	tbnz	w22, #0x1f, 0x110c <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MMapBuffer_nCreate+0xe4>
    1090:      	mov	w2, #0x2                // =2
    1094:      	mov	w0, w22
    1098:      	mov	x1, xzr
    109c:      	bl	0x1870 <lseek@plt>
    10a0:      	cmn	x0, #0x1
    10a4:      	b.eq	0x1104 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MMapBuffer_nCreate+0xdc>
    10a8:      	cmp	x0, #0x1
    10ac:      	b.lt	0x10f4 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MMapBuffer_nCreate+0xcc>
    10b0:      	cmp	x0, x21
    10b4:      	b.eq	0x10f4 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MMapBuffer_nCreate+0xcc>
    10b8:      	mov	w0, w22
    10bc:      	bl	0x1880 <close@plt>
    10c0:      	ldr	x8, [x19]
    10c4:      	adrp	x1, 0x0
    10c8:      	add	x1, x1, #0xd6d
    10cc:      	mov	x0, x19
    10d0:      	ldr	x8, [x8, #0x30]
    10d4:      	blr	x8
    10d8:      	ldr	x8, [x19]
    10dc:      	adrp	x2, 0x0
    10e0:      	mov	x1, x0
    10e4:      	add	x2, x2, #0xd54
    10e8:      	ldr	x8, [x8, #0x70]
    10ec:      	mov	x0, x19
    10f0:      	b	0x1148 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MMapBuffer_nCreate+0x120>
    10f4:      	mov	w0, w22
    10f8:      	mov	x1, x21
    10fc:      	bl	0x1890 <ftruncate@plt>
    1100:      	cbz	w0, 0x1168 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MMapBuffer_nCreate+0x140>
    1104:      	mov	w0, w22
    1108:      	bl	0x1880 <close@plt>
    110c:      	ldr	x8, [x19]
    1110:      	adrp	x1, 0x0
    1114:      	add	x1, x1, #0xd6d
    1118:      	mov	x0, x19
    111c:      	ldr	x8, [x8, #0x30]
    1120:      	blr	x8
    1124:      	mov	x20, x0
    1128:      	bl	0x18a0 <__errno@plt>
    112c:      	ldr	w0, [x0]
    1130:      	bl	0x18b0 <strerror@plt>
    1134:      	ldr	x8, [x19]
    1138:      	mov	x2, x0
    113c:      	mov	x0, x19
    1140:      	mov	x1, x20
    1144:      	ldr	x8, [x8, #0x70]
    1148:      	blr	x8
    114c:      	mov	x21, xzr
    1150:      	mov	x0, x21
    1154:      	ldp	x20, x19, [sp, #0x30]
    1158:      	ldp	x22, x21, [sp, #0x20]
    115c:      	ldr	x23, [sp, #0x10]
    1160:      	ldp	x29, x30, [sp], #0x40
    1164:      	ret
    1168:      	mov	w2, #0x3                // =3
    116c:      	mov	w3, #0x1                // =1
    1170:      	mov	x0, xzr
    1174:      	mov	x1, x21
    1178:      	mov	w4, w22
    117c:      	mov	x5, xzr
    1180:      	bl	0x18c0 <mmap@plt>
    1184:      	mov	x21, x0
    1188:      	mov	w0, w22
    118c:      	bl	0x1880 <close@plt>
    1190:      	cmn	x21, #0x1
    1194:      	b.ne	0x1150 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MMapBuffer_nCreate+0x128>
    1198:      	adrp	x1, 0x0
    119c:      	adrp	x2, 0x0
    11a0:      	add	x1, x1, #0xd81
    11a4:      	add	x2, x2, #0xd2f
    11a8:      	mov	w0, #0x3                // =3
    11ac:      	mov	x3, x20
    11b0:      	bl	0x18d0 <__android_log_print@plt>
    11b4:      	ldr	x8, [x19]
    11b8:      	adrp	x1, 0x0
    11bc:      	add	x1, x1, #0xd6d
    11c0:      	mov	x0, x19
    11c4:      	ldr	x8, [x8, #0x30]
    11c8:      	blr	x8
    11cc:      	ldr	x8, [x19]
    11d0:      	adrp	x2, 0x0
    11d4:      	mov	x1, x0
    11d8:      	add	x2, x2, #0xd18
    11dc:      	b	0x10e8 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MMapBuffer_nCreate+0xc0>

00000000000011e0 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MMapBuffer_nWrite>:
    11e0:      	ldr	x8, [x0]
    11e4:      	mov	x1, x4
    11e8:      	ldr	x7, [x8, #0x640]
    11ec:      	add	x8, x2, x3
    11f0:      	mov	w2, w5
    11f4:      	mov	w3, w6
    11f8:      	mov	x4, x8
    11fc:      	br	x7

0000000000001200 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MMapBuffer_nRelease>:
    1200:      	mov	x1, x3
    1204:      	mov	x0, x2
    1208:      	b	0x18e0 <munmap@plt>

000000000000120c <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MMapBuffer_nRead>:
    120c:      	ldr	x8, [x0]
    1210:      	mov	x1, x4
    1214:      	ldr	x7, [x8, #0x680]
    1218:      	add	x8, x2, x3
    121c:      	mov	w2, w5
    1220:      	mov	w3, w6
    1224:      	mov	x4, x8
    1228:      	br	x7

000000000000122c <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MMapBuffer_nFlush>:
    122c:      	stp	x29, x30, [sp, #-0x30]!
    1230:      	str	x21, [sp, #0x10]
    1234:      	stp	x20, x19, [sp, #0x20]
    1238:      	mov	x29, sp
    123c:      	mov	x8, x2
    1240:      	mov	x1, x3
    1244:      	mov	x19, x0
    1248:      	mov	w2, #0x4                // =4
    124c:      	mov	x0, x8
    1250:      	bl	0x18f0 <msync@plt>
    1254:      	mov	w20, w0
    1258:      	cbz	w0, 0x129c <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MMapBuffer_nFlush+0x70>
    125c:      	ldr	x8, [x19]
    1260:      	adrp	x1, 0x0
    1264:      	add	x1, x1, #0xd6d
    1268:      	mov	x0, x19
    126c:      	ldr	x8, [x8, #0x30]
    1270:      	blr	x8
    1274:      	mov	x21, x0
    1278:      	bl	0x18a0 <__errno@plt>
    127c:      	ldr	w0, [x0]
    1280:      	bl	0x18b0 <strerror@plt>
    1284:      	ldr	x8, [x19]
    1288:      	mov	x2, x0
    128c:      	mov	x0, x19
    1290:      	mov	x1, x21
    1294:      	ldr	x8, [x8, #0x70]
    1298:      	blr	x8
    129c:      	mov	w0, w20
    12a0:      	ldp	x20, x19, [sp, #0x20]
    12a4:      	ldr	x21, [sp, #0x10]
    12a8:      	ldp	x29, x30, [sp], #0x30
    12ac:      	ret

00000000000012b0 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate>:
    12b0:      	stp	x29, x30, [sp, #-0x40]!
    12b4:      	str	x23, [sp, #0x10]
    12b8:      	stp	x22, x21, [sp, #0x20]
    12bc:      	stp	x20, x19, [sp, #0x30]
    12c0:      	mov	x29, sp
    12c4:      	ldr	x8, [x0]
    12c8:      	mov	x19, x0
    12cc:      	tbnz	x3, #0x3f, 0x1380 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0xd0>
    12d0:      	ldr	x8, [x8, #0x548]
    12d4:      	mov	x22, x2
    12d8:      	mov	x0, x19
    12dc:      	mov	x1, x2
    12e0:      	mov	x2, xzr
    12e4:      	mov	x21, x3
    12e8:      	blr	x8
    12ec:      	mov	w1, #0x42               // =66
    12f0:      	movk	w1, #0x8, lsl #16
    12f4:      	mov	w2, #0x1b6              // =438
    12f8:      	mov	x23, x0
    12fc:      	bl	0x1860 <open@plt>
    1300:      	ldr	x8, [x19]
    1304:      	mov	w20, w0
    1308:      	mov	x0, x19
    130c:      	mov	x1, x22
    1310:      	ldr	x8, [x8, #0x550]
    1314:      	mov	x2, x23
    1318:      	blr	x8
    131c:      	tbnz	w20, #0x1f, 0x13c8 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x118>
    1320:      	mov	w2, #0x2                // =2
    1324:      	mov	w0, w20
    1328:      	mov	x1, xzr
    132c:      	bl	0x1870 <lseek@plt>
    1330:      	cmn	x0, #0x1
    1334:      	b.eq	0x13c0 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x110>
    1338:      	mov	x22, x0
    133c:      	cmp	x0, #0x1
    1340:      	b.lt	0x13b0 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x100>
    1344:      	cmp	x22, x21
    1348:      	b.eq	0x13b0 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x100>
    134c:      	mov	w0, w20
    1350:      	bl	0x1880 <close@plt>
    1354:      	ldr	x8, [x19]
    1358:      	adrp	x1, 0x0
    135c:      	add	x1, x1, #0xd6d
    1360:      	mov	x0, x19
    1364:      	ldr	x8, [x8, #0x30]
    1368:      	blr	x8
    136c:      	ldr	x8, [x19]
    1370:      	adrp	x2, 0x0
    1374:      	mov	x1, x0
    1378:      	add	x2, x2, #0xdb2
    137c:      	b	0x13a4 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0xf4>
    1380:      	ldr	x8, [x8, #0x30]
    1384:      	adrp	x1, 0x0
    1388:      	add	x1, x1, #0xd6d
    138c:      	mov	x0, x19
    1390:      	blr	x8
    1394:      	ldr	x8, [x19]
    1398:      	adrp	x2, 0x0
    139c:      	mov	x1, x0
    13a0:      	add	x2, x2, #0xda3
    13a4:      	ldr	x8, [x8, #0x70]
    13a8:      	mov	x0, x19
    13ac:      	b	0x1404 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x154>
    13b0:      	mov	w0, w20
    13b4:      	mov	x1, x21
    13b8:      	bl	0x1890 <ftruncate@plt>
    13bc:      	cbz	w0, 0x1424 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x174>
    13c0:      	mov	w0, w20
    13c4:      	bl	0x1880 <close@plt>
    13c8:      	ldr	x8, [x19]
    13cc:      	adrp	x1, 0x0
    13d0:      	add	x1, x1, #0xd6d
    13d4:      	mov	x0, x19
    13d8:      	ldr	x8, [x8, #0x30]
    13dc:      	blr	x8
    13e0:      	mov	x20, x0
    13e4:      	bl	0x18a0 <__errno@plt>
    13e8:      	ldr	w0, [x0]
    13ec:      	bl	0x18b0 <strerror@plt>
    13f0:      	ldr	x8, [x19]
    13f4:      	mov	x2, x0
    13f8:      	mov	x0, x19
    13fc:      	mov	x1, x20
    1400:      	ldr	x8, [x8, #0x70]
    1404:      	blr	x8
    1408:      	mov	x21, xzr
    140c:      	mov	x0, x21
    1410:      	ldp	x20, x19, [sp, #0x30]
    1414:      	ldp	x22, x21, [sp, #0x20]
    1418:      	ldr	x23, [sp, #0x10]
    141c:      	ldp	x29, x30, [sp], #0x40
    1420:      	ret
    1424:      	mov	w0, w20
    1428:      	mov	x1, xzr
    142c:      	mov	w2, wzr
    1430:      	bl	0x1870 <lseek@plt>
    1434:      	cbz	x0, 0x146c <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x1bc>
    1438:      	mov	w0, w20
    143c:      	bl	0x1880 <close@plt>
    1440:      	ldr	x8, [x19]
    1444:      	adrp	x1, 0x0
    1448:      	add	x1, x1, #0xd6d
    144c:      	mov	x0, x19
    1450:      	ldr	x8, [x8, #0x30]
    1454:      	blr	x8
    1458:      	ldr	x8, [x19]
    145c:      	adrp	x2, 0x0
    1460:      	mov	x1, x0
    1464:      	add	x2, x2, #0xd23
    1468:      	b	0x13a4 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0xf4>
    146c:      	mov	w0, #0x1                // =1
    1470:      	mov	x1, x21
    1474:      	bl	0x1900 <calloc@plt>
    1478:      	mov	x21, x0
    147c:      	cbz	x0, 0x1510 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x260>
    1480:      	cbz	x22, 0x14cc <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x21c>
    1484:      	mov	x23, x21
    1488:      	b	0x14a0 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x1f0>
    148c:      	bl	0x18a0 <__errno@plt>
    1490:      	ldr	w8, [x0]
    1494:      	cmp	w8, #0x4
    1498:      	b.ne	0x1550 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x2a0>
    149c:      	cbz	x22, 0x14cc <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x21c>
    14a0:      	mov	x3, #-0x1               // =-1
    14a4:      	mov	w0, w20
    14a8:      	mov	x1, x23
    14ac:      	mov	x2, x22
    14b0:      	bl	0x1910 <__read_chk@plt>
    14b4:      	cmn	x0, #0x1
    14b8:      	b.eq	0x148c <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x1dc>
    14bc:      	cbz	x0, 0x1550 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x2a0>
    14c0:      	sub	x22, x22, x0
    14c4:      	add	x23, x23, x0
    14c8:      	cbnz	x22, 0x14a0 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x1f0>
    14cc:      	mov	w0, w20
    14d0:      	bl	0x1880 <close@plt>
    14d4:      	cmn	w0, #0x1
    14d8:      	b.ne	0x140c <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x15c>
    14dc:      	mov	x0, x21
    14e0:      	bl	0x1920 <free@plt>
    14e4:      	ldr	x8, [x19]
    14e8:      	adrp	x1, 0x0
    14ec:      	add	x1, x1, #0xd6d
    14f0:      	mov	x0, x19
    14f4:      	ldr	x8, [x8, #0x30]
    14f8:      	blr	x8
    14fc:      	ldr	x8, [x19]
    1500:      	adrp	x2, 0x0
    1504:      	mov	x1, x0
    1508:      	add	x2, x2, #0xd88
    150c:      	b	0x13a4 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0xf4>
    1510:      	mov	w0, w20
    1514:      	bl	0x1880 <close@plt>
    1518:      	ldr	x8, [x19]
    151c:      	adrp	x1, 0x0
    1520:      	add	x1, x1, #0xd6d
    1524:      	mov	x0, x19
    1528:      	ldr	x8, [x8, #0x30]
    152c:      	blr	x8
    1530:      	ldr	x8, [x19]
    1534:      	adrp	x2, 0x0
    1538:      	mov	x1, x0
    153c:      	add	x2, x2, #0xd3f
    1540:      	ldr	x8, [x8, #0x70]
    1544:      	mov	x0, x19
    1548:      	blr	x8
    154c:      	b	0x140c <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x15c>
    1550:      	mov	w0, w20
    1554:      	bl	0x1880 <close@plt>
    1558:      	cbz	x22, 0x14d4 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0x224>
    155c:      	mov	x0, x21
    1560:      	bl	0x1920 <free@plt>
    1564:      	ldr	x8, [x19]
    1568:      	adrp	x1, 0x0
    156c:      	add	x1, x1, #0xd6d
    1570:      	mov	x0, x19
    1574:      	ldr	x8, [x8, #0x30]
    1578:      	blr	x8
    157c:      	ldr	x8, [x19]
    1580:      	adrp	x2, 0x0
    1584:      	mov	x1, x0
    1588:      	add	x2, x2, #0xdd0
    158c:      	b	0x13a4 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nCreate+0xf4>

0000000000001590 <_Z8readFulliPal>:
    1590:      	stp	x29, x30, [sp, #-0x30]!
    1594:      	stp	x22, x21, [sp, #0x10]
    1598:      	stp	x20, x19, [sp, #0x20]
    159c:      	mov	x29, sp
    15a0:      	mov	x19, x2
    15a4:      	cbz	x2, 0x15fc <_Z8readFulliPal+0x6c>
    15a8:      	mov	x21, x1
    15ac:      	mov	w22, w0
    15b0:      	mov	x20, x19
    15b4:      	b	0x15cc <_Z8readFulliPal+0x3c>
    15b8:      	bl	0x18a0 <__errno@plt>
    15bc:      	ldr	w8, [x0]
    15c0:      	cmp	w8, #0x4
    15c4:      	b.ne	0x1600 <_Z8readFulliPal+0x70>
    15c8:      	cbz	x20, 0x1600 <_Z8readFulliPal+0x70>
    15cc:      	mov	x3, #-0x1               // =-1
    15d0:      	mov	w0, w22
    15d4:      	mov	x1, x21
    15d8:      	mov	x2, x20
    15dc:      	bl	0x1910 <__read_chk@plt>
    15e0:      	cmn	x0, #0x1
    15e4:      	b.eq	0x15b8 <_Z8readFulliPal+0x28>
    15e8:      	cbz	x0, 0x1600 <_Z8readFulliPal+0x70>
    15ec:      	sub	x20, x20, x0
    15f0:      	add	x21, x21, x0
    15f4:      	cbnz	x20, 0x15cc <_Z8readFulliPal+0x3c>
    15f8:      	b	0x1600 <_Z8readFulliPal+0x70>
    15fc:      	mov	x20, xzr
    1600:      	sub	x0, x19, x20
    1604:      	ldp	x20, x19, [sp, #0x20]
    1608:      	ldp	x22, x21, [sp, #0x10]
    160c:      	ldp	x29, x30, [sp], #0x30
    1610:      	ret

0000000000001614 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nWrite>:
    1614:      	ldr	x8, [x0]
    1618:      	mov	x1, x4
    161c:      	ldr	x7, [x8, #0x640]
    1620:      	add	x8, x2, x3
    1624:      	mov	w2, w5
    1628:      	mov	w3, w6
    162c:      	mov	x4, x8
    1630:      	br	x7

0000000000001634 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nRead>:
    1634:      	ldr	x8, [x0]
    1638:      	mov	x1, x4
    163c:      	ldr	x7, [x8, #0x680]
    1640:      	add	x8, x2, x3
    1644:      	mov	w2, w5
    1648:      	mov	w3, w6
    164c:      	mov	x4, x8
    1650:      	br	x7

0000000000001654 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nRelease>:
    1654:      	mov	x0, x2
    1658:      	b	0x1920 <free@plt>

000000000000165c <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nFlush>:
    165c:      	stp	x29, x30, [sp, #-0x40]!
    1660:      	stp	x24, x23, [sp, #0x10]
    1664:      	stp	x22, x21, [sp, #0x20]
    1668:      	stp	x20, x19, [sp, #0x30]
    166c:      	mov	x29, sp
    1670:      	ldr	x8, [x0]
    1674:      	mov	x21, x2
    1678:      	mov	x1, x3
    167c:      	mov	x2, xzr
    1680:      	ldr	x8, [x8, #0x548]
    1684:      	mov	x20, x4
    1688:      	mov	x23, x3
    168c:      	mov	x19, x0
    1690:      	blr	x8
    1694:      	mov	w1, #0x241              // =577
    1698:      	movk	w1, #0x8, lsl #16
    169c:      	mov	w2, #0x1b6              // =438
    16a0:      	mov	x24, x0
    16a4:      	bl	0x1860 <open@plt>
    16a8:      	ldr	x8, [x19]
    16ac:      	mov	w22, w0
    16b0:      	mov	x0, x19
    16b4:      	mov	x1, x23
    16b8:      	ldr	x8, [x8, #0x550]
    16bc:      	mov	x2, x24
    16c0:      	blr	x8
    16c4:      	tbnz	w22, #0x1f, 0x1708 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nFlush+0xac>
    16c8:      	mov	w0, w22
    16cc:      	mov	x1, x21
    16d0:      	mov	x2, x20
    16d4:      	bl	0x1930 <write@plt>
    16d8:      	mov	x21, x0
    16dc:      	mov	w0, w22
    16e0:      	bl	0x1880 <close@plt>
    16e4:      	cmp	x21, x20
    16e8:      	b.ne	0x1708 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nFlush+0xac>
    16ec:      	cmn	w0, #0x1
    16f0:      	b.eq	0x1758 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nFlush+0xfc>
    16f4:      	ldp	x20, x19, [sp, #0x30]
    16f8:      	ldp	x22, x21, [sp, #0x20]
    16fc:      	ldp	x24, x23, [sp, #0x10]
    1700:      	ldp	x29, x30, [sp], #0x40
    1704:      	ret
    1708:      	ldr	x8, [x19]
    170c:      	adrp	x1, 0x0
    1710:      	add	x1, x1, #0xd6d
    1714:      	mov	x0, x19
    1718:      	ldr	x8, [x8, #0x30]
    171c:      	blr	x8
    1720:      	mov	x20, x0
    1724:      	bl	0x18a0 <__errno@plt>
    1728:      	ldr	w0, [x0]
    172c:      	bl	0x18b0 <strerror@plt>
    1730:      	ldr	x8, [x19]
    1734:      	mov	x2, x0
    1738:      	mov	x0, x19
    173c:      	mov	x1, x20
    1740:      	ldr	x3, [x8, #0x70]
    1744:      	ldp	x20, x19, [sp, #0x30]
    1748:      	ldp	x22, x21, [sp, #0x20]
    174c:      	ldp	x24, x23, [sp, #0x10]
    1750:      	ldp	x29, x30, [sp], #0x40
    1754:      	br	x3
    1758:      	ldr	x8, [x19]
    175c:      	adrp	x1, 0x0
    1760:      	add	x1, x1, #0xd6d
    1764:      	mov	x0, x19
    1768:      	ldr	x8, [x8, #0x30]
    176c:      	blr	x8
    1770:      	ldr	x8, [x19]
    1774:      	adrp	x2, 0x0
    1778:      	add	x2, x2, #0xde1
    177c:      	mov	x1, x0
    1780:      	ldr	x3, [x8, #0x70]
    1784:      	mov	x0, x19
    1788:      	b	0x1744 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MemoryBuffer_nFlush+0xe8>

000000000000178c <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MReMapBuffer_nMReMap>:
    178c:      	stp	x29, x30, [sp, #-0x20]!
    1790:      	stp	x20, x19, [sp, #0x10]
    1794:      	mov	x29, sp
    1798:      	mov	x1, x3
    179c:      	mov	x19, x0
    17a0:      	mov	w3, #0x1                // =1
    17a4:      	mov	x0, x2
    17a8:      	mov	x2, x4
    17ac:      	bl	0x1940 <mremap@plt>
    17b0:      	cmn	x0, #0x1
    17b4:      	b.ne	0x1808 <Java_com_bykv_vk_openvk_preload_geckox_buffer_impl_MReMapBuffer_nMReMap+0x7c>
    17b8:      	adrp	x20, 0x0
    17bc:      	adrp	x1, 0x0
    17c0:      	add	x20, x20, #0xd95
    17c4:      	add	x1, x1, #0xd81
    17c8:      	mov	w0, #0x3                // =3
    17cc:      	mov	x2, x20
    17d0:      	bl	0x18d0 <__android_log_print@plt>
    17d4:      	ldr	x8, [x19]
    17d8:      	adrp	x1, 0x0
    17dc:      	add	x1, x1, #0xd6d
    17e0:      	mov	x0, x19
    17e4:      	ldr	x8, [x8, #0x30]
    17e8:      	blr	x8
    17ec:      	ldr	x8, [x19]
    17f0:      	mov	x1, x0
    17f4:      	mov	x0, x19
    17f8:      	mov	x2, x20
    17fc:      	ldr	x8, [x8, #0x70]
    1800:      	blr	x8
    1804:      	mov	w0, wzr
    1808:      	ldp	x20, x19, [sp, #0x10]
    180c:      	ldp	x29, x30, [sp], #0x20
    1810:      	ret

Disassembly of section .plt:

0000000000001820 <.plt>:
    1820:      	stp	x16, x30, [sp, #-0x10]!
    1824:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    1828:      	ldr	x17, [x16, #0xb28]
    182c:      	add	x16, x16, #0xb28
    1830:      	br	x17
    1834:      	nop
    1838:      	nop
    183c:      	nop

0000000000001840 <__cxa_finalize@plt>:
    1840:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    1844:      	ldr	x17, [x16, #0xb30]
    1848:      	add	x16, x16, #0xb30
    184c:      	br	x17

0000000000001850 <__cxa_atexit@plt>:
    1850:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    1854:      	ldr	x17, [x16, #0xb38]
    1858:      	add	x16, x16, #0xb38
    185c:      	br	x17

0000000000001860 <open@plt>:
    1860:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    1864:      	ldr	x17, [x16, #0xb40]
    1868:      	add	x16, x16, #0xb40
    186c:      	br	x17

0000000000001870 <lseek@plt>:
    1870:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    1874:      	ldr	x17, [x16, #0xb48]
    1878:      	add	x16, x16, #0xb48
    187c:      	br	x17

0000000000001880 <close@plt>:
    1880:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    1884:      	ldr	x17, [x16, #0xb50]
    1888:      	add	x16, x16, #0xb50
    188c:      	br	x17

0000000000001890 <ftruncate@plt>:
    1890:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    1894:      	ldr	x17, [x16, #0xb58]
    1898:      	add	x16, x16, #0xb58
    189c:      	br	x17

00000000000018a0 <__errno@plt>:
    18a0:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    18a4:      	ldr	x17, [x16, #0xb60]
    18a8:      	add	x16, x16, #0xb60
    18ac:      	br	x17

00000000000018b0 <strerror@plt>:
    18b0:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    18b4:      	ldr	x17, [x16, #0xb68]
    18b8:      	add	x16, x16, #0xb68
    18bc:      	br	x17

00000000000018c0 <mmap@plt>:
    18c0:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    18c4:      	ldr	x17, [x16, #0xb70]
    18c8:      	add	x16, x16, #0xb70
    18cc:      	br	x17

00000000000018d0 <__android_log_print@plt>:
    18d0:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    18d4:      	ldr	x17, [x16, #0xb78]
    18d8:      	add	x16, x16, #0xb78
    18dc:      	br	x17

00000000000018e0 <munmap@plt>:
    18e0:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    18e4:      	ldr	x17, [x16, #0xb80]
    18e8:      	add	x16, x16, #0xb80
    18ec:      	br	x17

00000000000018f0 <msync@plt>:
    18f0:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    18f4:      	ldr	x17, [x16, #0xb88]
    18f8:      	add	x16, x16, #0xb88
    18fc:      	br	x17

0000000000001900 <calloc@plt>:
    1900:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    1904:      	ldr	x17, [x16, #0xb90]
    1908:      	add	x16, x16, #0xb90
    190c:      	br	x17

0000000000001910 <__read_chk@plt>:
    1910:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    1914:      	ldr	x17, [x16, #0xb98]
    1918:      	add	x16, x16, #0xb98
    191c:      	br	x17

0000000000001920 <free@plt>:
    1920:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    1924:      	ldr	x17, [x16, #0xba0]
    1928:      	add	x16, x16, #0xba0
    192c:      	br	x17

0000000000001930 <write@plt>:
    1930:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    1934:      	ldr	x17, [x16, #0xba8]
    1938:      	add	x16, x16, #0xba8
    193c:      	br	x17

0000000000001940 <mremap@plt>:
    1940:      	adrp	x16, 0x5000 <mremap@plt+0x36c0>
    1944:      	ldr	x17, [x16, #0xbb0]
    1948:      	add	x16, x16, #0xbb0
    194c:      	br	x17
