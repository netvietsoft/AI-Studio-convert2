
F:\CONVERT\com.mt.mtxx.mtxx\SOURCE\extracted_native_libs\lib\arm64-v8a\libhttpelf.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000005468 <.text>:
    5468:      	bti	c
    546c:      	nop
    5470:      	adr	x0, 0xfba0
    5474:      	b	0xb990 <__cxa_finalize@plt>
    5478:      	bti	c
    547c:      	ret
    5480:      	bti	c
    5484:      	b	0x5478 <.text+0x10>
    5488:      	bti	c
    548c:      	cbz	x0, 0x5498 <.text+0x30>
    5490:      	mov	x16, x0
    5494:      	br	x16
    5498:      	ret
    549c:      	bti	c
    54a0:      	mov	x1, x0
    54a4:      	nop
    54a8:      	adr	x0, 0x5488 <.text+0x20>
    54ac:      	nop
    54b0:      	adr	x2, 0xfba0
    54b4:      	b	0xb9a0 <__cxa_atexit@plt>

00000000000054b8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send>:
    54b8:      	sub	sp, sp, #0x60
    54bc:      	stp	x29, x30, [sp, #0x10]
    54c0:      	stp	x26, x25, [sp, #0x20]
    54c4:      	stp	x24, x23, [sp, #0x30]
    54c8:      	stp	x22, x21, [sp, #0x40]
    54cc:      	stp	x20, x19, [sp, #0x50]
    54d0:      	add	x29, sp, #0x10
    54d4:      	mrs	x25, TPIDR_EL0
    54d8:      	mov	x19, x2
    54dc:      	mov	x20, x0
    54e0:      	ldr	x8, [x25, #0x28]
    54e4:      	mov	x21, xzr
    54e8:      	cmp	w3, #0x7b
    54ec:      	str	x8, [sp, #0x8]
    54f0:      	b.le	0x55fc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x144>
    54f4:      	cmp	w3, #0x7d
    54f8:      	b.le	0x5684 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1cc>
    54fc:      	cmp	w3, #0x7e
    5500:      	b.eq	0x5770 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2b8>
    5504:      	cmp	w3, #0x8a
    5508:      	b.eq	0x5808 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x350>
    550c:      	cmp	w3, #0x9a
    5510:      	b.ne	0x59c4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c>
    5514:      	mov	x0, x19
    5518:      	bl	0x5ca8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x7f0>
    551c:      	ldr	x8, [x20]
    5520:      	mov	x19, x0
    5524:      	nop
    5528:      	adr	x1, 0x15cc
    552c:      	mov	x0, x20
    5530:      	ldr	x8, [x8, #0x30]
    5534:      	blr	x8
    5538:      	ldr	x8, [x20]
    553c:      	ldr	w1, [x19, #0xf0]
    5540:      	mov	x22, x0
    5544:      	mov	x0, x20
    5548:      	mov	x2, x22
    554c:      	mov	x3, xzr
    5550:      	ldr	x8, [x8, #0x560]
    5554:      	blr	x8
    5558:      	ldr	w8, [x19, #0xf0]
    555c:      	mov	x21, x0
    5560:      	cmp	w8, #0x1
    5564:      	b.lt	0x55dc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x124>
    5568:      	mov	x23, xzr
    556c:      	add	x26, x19, #0x10
    5570:      	ldurb	w8, [x26, #-0x10]
    5574:      	ldr	x9, [x20]
    5578:      	sub	x11, x26, #0xf
    557c:      	ldr	x10, [x26]
    5580:      	mov	x0, x20
    5584:      	tst	w8, #0x1
    5588:      	ldr	x8, [x9, #0x538]
    558c:      	csel	x1, x11, x10, eq
    5590:      	blr	x8
    5594:      	ldr	x8, [x20]
    5598:      	mov	x24, x0
    559c:      	mov	x0, x20
    55a0:      	mov	x1, x21
    55a4:      	mov	w2, w23
    55a8:      	mov	x3, x24
    55ac:      	ldr	x8, [x8, #0x570]
    55b0:      	blr	x8
    55b4:      	ldr	x8, [x20]
    55b8:      	mov	x0, x20
    55bc:      	mov	x1, x24
    55c0:      	ldr	x8, [x8, #0xb8]
    55c4:      	blr	x8
    55c8:      	ldrsw	x8, [x19, #0xf0]
    55cc:      	add	x23, x23, #0x1
    55d0:      	add	x26, x26, #0x18
    55d4:      	cmp	x23, x8
    55d8:      	b.lt	0x5570 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xb8>
    55dc:      	ldr	x8, [x20]
    55e0:      	mov	x0, x20
    55e4:      	mov	x1, x22
    55e8:      	ldr	x8, [x8, #0xb8]
    55ec:      	blr	x8
    55f0:      	mov	x0, x19
    55f4:      	bl	0x6378 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xec0>
    55f8:      	b	0x59c4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c>
    55fc:      	cmp	w3, #0x79
    5600:      	b.gt	0x5620 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x168>
    5604:      	cmp	w3, #0x6a
    5608:      	b.eq	0x56e0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x228>
    560c:      	cmp	w3, #0x6b
    5610:      	b.ne	0x59c4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c>
    5614:      	mov	x0, x19
    5618:      	bl	0x5ad8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x620>
    561c:      	b	0x59c0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x508>
    5620:      	cmp	w3, #0x7a
    5624:      	b.eq	0x5724 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x26c>
    5628:      	cmp	w3, #0x7b
    562c:      	b.ne	0x59c4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c>
    5630:      	cbz	x4, 0x585c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3a4>
    5634:      	ldr	x8, [x20]
    5638:      	mov	x0, x20
    563c:      	mov	x1, x4
    5640:      	mov	x2, xzr
    5644:      	mov	x21, x4
    5648:      	ldr	x8, [x8, #0x5c0]
    564c:      	blr	x8
    5650:      	ldr	x8, [x20]
    5654:      	mov	x22, x0
    5658:      	mov	x0, x20
    565c:      	mov	x1, x21
    5660:      	ldr	x8, [x8, #0x558]
    5664:      	blr	x8
    5668:      	mov	w20, w0
    566c:      	bl	0x64b8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1000>
    5670:      	sxtw	x2, w20
    5674:      	mov	x1, x22
    5678:      	mov	x21, x0
    567c:      	bl	0xb9b0 <memcpy@plt>
    5680:      	b	0x5864 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3ac>
    5684:      	cmp	w3, #0x7c
    5688:      	b.eq	0x57bc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x304>
    568c:      	cmp	w3, #0x7d
    5690:      	b.ne	0x59c4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c>
    5694:      	cbz	x4, 0x5878 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3c0>
    5698:      	ldr	x8, [x20]
    569c:      	mov	x0, x20
    56a0:      	mov	x1, x4
    56a4:      	mov	x2, xzr
    56a8:      	mov	x21, x4
    56ac:      	ldr	x8, [x8, #0x548]
    56b0:      	blr	x8
    56b4:      	mov	x22, x0
    56b8:      	cbz	x0, 0x58c4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x40c>
    56bc:      	mov	x0, x22
    56c0:      	bl	0xb9c0 <strlen@plt>
    56c4:      	mov	x23, x0
    56c8:      	add	w0, w23, #0x1
    56cc:      	bl	0x64b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xff8>
    56d0:      	mov	x1, x22
    56d4:      	mov	x24, x0
    56d8:      	bl	0xb9d0 <strcpy@plt>
    56dc:      	b	0x58d4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x41c>
    56e0:      	bl	0x5aac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5f4>
    56e4:      	ldr	x8, [x20]
    56e8:      	str	x0, [sp]
    56ec:      	mov	x0, x20
    56f0:      	mov	w1, #0x1                // =1
    56f4:      	ldr	x8, [x8, #0x5a0]
    56f8:      	blr	x8
    56fc:      	ldr	x8, [x20]
    5700:      	mov	x21, x0
    5704:      	mov	x4, sp
    5708:      	mov	x0, x20
    570c:      	mov	x1, x21
    5710:      	mov	w2, wzr
    5714:      	ldr	x8, [x8, #0x6a0]
    5718:      	mov	w3, #0x1                // =1
    571c:      	blr	x8
    5720:      	b	0x59c4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c>
    5724:      	cbz	x4, 0x5884 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3cc>
    5728:      	ldr	x8, [x20]
    572c:      	mov	x0, x20
    5730:      	mov	x1, x4
    5734:      	mov	x2, xzr
    5738:      	mov	x21, x4
    573c:      	ldr	x8, [x8, #0x548]
    5740:      	blr	x8
    5744:      	mov	x22, x0
    5748:      	cbz	x0, 0x5904 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44c>
    574c:      	mov	x0, x22
    5750:      	bl	0xb9c0 <strlen@plt>
    5754:      	mov	x23, x0
    5758:      	add	w0, w23, #0x1
    575c:      	bl	0x64b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xff8>
    5760:      	mov	x1, x22
    5764:      	mov	x24, x0
    5768:      	bl	0xb9d0 <strcpy@plt>
    576c:      	b	0x5914 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x45c>
    5770:      	cbz	x4, 0x5890 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3d8>
    5774:      	ldr	x8, [x20]
    5778:      	mov	x0, x20
    577c:      	mov	x1, x4
    5780:      	mov	x2, xzr
    5784:      	mov	x21, x4
    5788:      	ldr	x8, [x8, #0x548]
    578c:      	blr	x8
    5790:      	mov	x22, x0
    5794:      	cbz	x0, 0x5944 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x48c>
    5798:      	mov	x0, x22
    579c:      	bl	0xb9c0 <strlen@plt>
    57a0:      	mov	x23, x0
    57a4:      	add	w0, w23, #0x1
    57a8:      	bl	0x64b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xff8>
    57ac:      	mov	x1, x22
    57b0:      	mov	x24, x0
    57b4:      	bl	0xb9d0 <strcpy@plt>
    57b8:      	b	0x5954 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x49c>
    57bc:      	cbz	x4, 0x589c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3e4>
    57c0:      	ldr	x8, [x20]
    57c4:      	mov	x0, x20
    57c8:      	mov	x1, x4
    57cc:      	mov	x2, xzr
    57d0:      	mov	x21, x4
    57d4:      	ldr	x8, [x8, #0x548]
    57d8:      	blr	x8
    57dc:      	mov	x22, x0
    57e0:      	cbz	x0, 0x5984 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4cc>
    57e4:      	mov	x0, x22
    57e8:      	bl	0xb9c0 <strlen@plt>
    57ec:      	mov	x23, x0
    57f0:      	add	w0, w23, #0x1
    57f4:      	bl	0x64b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xff8>
    57f8:      	mov	x1, x22
    57fc:      	mov	x24, x0
    5800:      	bl	0xb9d0 <strcpy@plt>
    5804:      	b	0x5994 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4dc>
    5808:      	cbz	x4, 0x58a8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3f0>
    580c:      	ldr	x8, [x20]
    5810:      	mov	x0, x20
    5814:      	mov	x1, x4
    5818:      	mov	x2, xzr
    581c:      	mov	x21, x4
    5820:      	ldr	x8, [x8, #0x5c0]
    5824:      	blr	x8
    5828:      	ldr	x8, [x20]
    582c:      	mov	x22, x0
    5830:      	mov	x0, x20
    5834:      	mov	x1, x21
    5838:      	ldr	x8, [x8, #0x558]
    583c:      	blr	x8
    5840:      	mov	w20, w0
    5844:      	bl	0x64b8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1000>
    5848:      	sxtw	x2, w20
    584c:      	mov	x1, x22
    5850:      	mov	x21, x0
    5854:      	bl	0xb9b0 <memcpy@plt>
    5858:      	b	0x58b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3f8>
    585c:      	mov	w20, wzr
    5860:      	mov	x21, xzr
    5864:      	mov	x0, x19
    5868:      	mov	x1, x21
    586c:      	mov	w2, w20
    5870:      	bl	0x5a70 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5b8>
    5874:      	b	0x59c0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x508>
    5878:      	mov	w23, wzr
    587c:      	mov	x24, xzr
    5880:      	b	0x58f0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x438>
    5884:      	mov	w23, wzr
    5888:      	mov	x24, xzr
    588c:      	b	0x5930 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x478>
    5890:      	mov	w23, wzr
    5894:      	mov	x24, xzr
    5898:      	b	0x5970 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4b8>
    589c:      	mov	w23, wzr
    58a0:      	mov	x24, xzr
    58a4:      	b	0x59b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4f8>
    58a8:      	mov	w20, wzr
    58ac:      	mov	x21, xzr
    58b0:      	mov	x0, x19
    58b4:      	mov	x1, x21
    58b8:      	mov	w2, w20
    58bc:      	bl	0x5aa0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5e8>
    58c0:      	b	0x59c0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x508>
    58c4:      	mov	w0, #0x1                // =1
    58c8:      	bl	0x64b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xff8>
    58cc:      	mov	x24, x0
    58d0:      	mov	w23, wzr
    58d4:      	strb	wzr, [x24, w23, sxtw]
    58d8:      	mov	x0, x20
    58dc:      	mov	x1, x21
    58e0:      	ldr	x8, [x20]
    58e4:      	mov	x2, x22
    58e8:      	ldr	x8, [x8, #0x550]
    58ec:      	blr	x8
    58f0:      	mov	x0, x19
    58f4:      	mov	x1, x24
    58f8:      	mov	w2, w23
    58fc:      	bl	0x5a88 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5d0>
    5900:      	b	0x59c0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x508>
    5904:      	mov	w0, #0x1                // =1
    5908:      	bl	0x64b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xff8>
    590c:      	mov	x24, x0
    5910:      	mov	w23, wzr
    5914:      	strb	wzr, [x24, w23, sxtw]
    5918:      	mov	x0, x20
    591c:      	mov	x1, x21
    5920:      	ldr	x8, [x20]
    5924:      	mov	x2, x22
    5928:      	ldr	x8, [x8, #0x550]
    592c:      	blr	x8
    5930:      	mov	x0, x19
    5934:      	mov	x1, x24
    5938:      	mov	w2, w23
    593c:      	bl	0x5a64 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5ac>
    5940:      	b	0x59c0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x508>
    5944:      	mov	w0, #0x1                // =1
    5948:      	bl	0x64b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xff8>
    594c:      	mov	x24, x0
    5950:      	mov	w23, wzr
    5954:      	strb	wzr, [x24, w23, sxtw]
    5958:      	mov	x0, x20
    595c:      	mov	x1, x21
    5960:      	ldr	x8, [x20]
    5964:      	mov	x2, x22
    5968:      	ldr	x8, [x8, #0x550]
    596c:      	blr	x8
    5970:      	mov	x0, x19
    5974:      	mov	x1, x24
    5978:      	mov	w2, w23
    597c:      	bl	0x5a94 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5dc>
    5980:      	b	0x59c0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x508>
    5984:      	mov	w0, #0x1                // =1
    5988:      	bl	0x64b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xff8>
    598c:      	mov	x24, x0
    5990:      	mov	w23, wzr
    5994:      	strb	wzr, [x24, w23, sxtw]
    5998:      	mov	x0, x20
    599c:      	mov	x1, x21
    59a0:      	ldr	x8, [x20]
    59a4:      	mov	x2, x22
    59a8:      	ldr	x8, [x8, #0x550]
    59ac:      	blr	x8
    59b0:      	mov	x0, x19
    59b4:      	mov	x1, x24
    59b8:      	mov	w2, w23
    59bc:      	bl	0x5a7c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5c4>
    59c0:      	mov	x21, xzr
    59c4:      	ldr	x8, [x25, #0x28]
    59c8:      	ldr	x9, [sp, #0x8]
    59cc:      	cmp	x8, x9
    59d0:      	b.ne	0x59f4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x53c>
    59d4:      	mov	x0, x21
    59d8:      	ldp	x20, x19, [sp, #0x50]
    59dc:      	ldp	x22, x21, [sp, #0x40]
    59e0:      	ldp	x24, x23, [sp, #0x30]
    59e4:      	ldp	x26, x25, [sp, #0x20]
    59e8:      	ldp	x29, x30, [sp, #0x10]
    59ec:      	add	sp, sp, #0x60
    59f0:      	ret
    59f4:      	bl	0xb9e0 <__stack_chk_fail@plt>
    59f8:      	stp	x29, x30, [sp, #-0x20]!
    59fc:      	str	x19, [sp, #0x10]
    5a00:      	mov	x29, sp
    5a04:      	mov	x19, x0
    5a08:      	ldr	x0, [x0]
    5a0c:      	cbz	x0, 0x5a14 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x55c>
    5a10:      	bl	0xb9f0 <_ZdaPv@plt>
    5a14:      	ldr	x0, [x19, #0x10]
    5a18:      	cbz	x0, 0x5a20 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568>
    5a1c:      	bl	0xb9f0 <_ZdaPv@plt>
    5a20:      	ldr	x0, [x19, #0x20]
    5a24:      	cbz	x0, 0x5a2c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x574>
    5a28:      	bl	0xb9f0 <_ZdaPv@plt>
    5a2c:      	ldr	x0, [x19, #0x30]
    5a30:      	cbz	x0, 0x5a38 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x580>
    5a34:      	bl	0xb9f0 <_ZdaPv@plt>
    5a38:      	ldr	x0, [x19, #0x40]
    5a3c:      	cbz	x0, 0x5a44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x58c>
    5a40:      	bl	0xb9f0 <_ZdaPv@plt>
    5a44:      	ldr	x0, [x19, #0x50]
    5a48:      	cbz	x0, 0x5a58 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5a0>
    5a4c:      	ldr	x19, [sp, #0x10]
    5a50:      	ldp	x29, x30, [sp], #0x20
    5a54:      	b	0xb9f0 <_ZdaPv@plt>
    5a58:      	ldr	x19, [sp, #0x10]
    5a5c:      	ldp	x29, x30, [sp], #0x20
    5a60:      	ret
    5a64:      	str	x1, [x0]
    5a68:      	str	w2, [x0, #0x8]
    5a6c:      	ret
    5a70:      	str	x1, [x0, #0x10]
    5a74:      	str	w2, [x0, #0x18]
    5a78:      	ret
    5a7c:      	str	x1, [x0, #0x20]
    5a80:      	str	w2, [x0, #0x28]
    5a84:      	ret
    5a88:      	str	x1, [x0, #0x30]
    5a8c:      	str	w2, [x0, #0x38]
    5a90:      	ret
    5a94:      	str	x1, [x0, #0x40]
    5a98:      	str	w2, [x0, #0x48]
    5a9c:      	ret
    5aa0:      	str	x1, [x0, #0x50]
    5aa4:      	str	w2, [x0, #0x58]
    5aa8:      	ret
    5aac:      	stp	x29, x30, [sp, #-0x10]!
    5ab0:      	mov	x29, sp
    5ab4:      	mov	w0, #0x60               // =96
    5ab8:      	bl	0xba00 <_Znwm@plt>
    5abc:      	str	wzr, [x0, #0x18]
    5ac0:      	str	wzr, [x0, #0x28]
    5ac4:      	str	wzr, [x0, #0x48]
    5ac8:      	str	wzr, [x0, #0x58]
    5acc:      	str	wzr, [x0, #0x38]
    5ad0:      	ldp	x29, x30, [sp], #0x10
    5ad4:      	ret
    5ad8:      	cbz	x0, 0x5b00 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x648>
    5adc:      	stp	x29, x30, [sp, #-0x20]!
    5ae0:      	str	x19, [sp, #0x10]
    5ae4:      	mov	x29, sp
    5ae8:      	mov	x19, x0
    5aec:      	bl	0x59f8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x540>
    5af0:      	mov	x0, x19
    5af4:      	ldr	x19, [sp, #0x10]
    5af8:      	ldp	x29, x30, [sp], #0x20
    5afc:      	b	0xba10 <_ZdlPv@plt>
    5b00:      	ret
    5b04:      	stp	x29, x30, [sp, #-0x40]!
    5b08:      	stp	x24, x23, [sp, #0x10]
    5b0c:      	stp	x22, x21, [sp, #0x20]
    5b10:      	stp	x20, x19, [sp, #0x30]
    5b14:      	mov	x29, sp
    5b18:      	sub	sp, sp, #0x20
    5b1c:      	mrs	x23, TPIDR_EL0
    5b20:      	mov	x19, x8
    5b24:      	ldr	x8, [x23, #0x28]
    5b28:      	stur	x8, [x29, #-0x8]
    5b2c:      	ldrb	w8, [x0]
    5b30:      	ldr	x9, [x0, #0x8]
    5b34:      	lsr	x10, x8, #1
    5b38:      	tst	w8, #0x1
    5b3c:      	csel	x22, x10, x9, eq
    5b40:      	mov	x10, sp
    5b44:      	tst	w8, #0x1
    5b48:      	add	x9, x22, #0x10
    5b4c:      	and	x9, x9, #0xfffffffffffffff0
    5b50:      	sub	x20, x10, x9
    5b54:      	mov	sp, x20
    5b58:      	ldr	x8, [x0, #0x10]
    5b5c:      	mov	x2, x22
    5b60:      	csinc	x21, x8, x0, ne
    5b64:      	mov	x0, x20
    5b68:      	mov	x1, x21
    5b6c:      	bl	0xb9b0 <memcpy@plt>
    5b70:      	subs	w8, w22, #0x1
    5b74:      	strb	wzr, [x20, x22]
    5b78:      	b.mi	0x5bb8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x700>
    5b7c:      	mov	x10, xzr
    5b80:      	add	x9, x21, #0x1
    5b84:      	b	0x5b9c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6e4>
    5b88:      	sub	x8, x8, #0x1
    5b8c:      	add	x9, x9, #0x2
    5b90:      	cmp	x10, x8
    5b94:      	add	x10, x10, #0x1
    5b98:      	b.ge	0x5bb8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x700>
    5b9c:      	ldurb	w11, [x9, #-0x1]
    5ba0:      	cmp	x8, x10
    5ba4:      	strb	w11, [x20, x10]
    5ba8:      	b.eq	0x5b88 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6d0>
    5bac:      	ldrb	w11, [x9]
    5bb0:      	strb	w11, [x20, x8]
    5bb4:      	b	0x5b88 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6d0>
    5bb8:      	mov	x0, x20
    5bbc:      	bl	0xb9c0 <strlen@plt>
    5bc0:      	cmn	x0, #0x10
    5bc4:      	b.hs	0x5c60 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x7a8>
    5bc8:      	mov	x21, x0
    5bcc:      	cmp	x0, #0x17
    5bd0:      	b.hs	0x5bec <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x734>
    5bd4:      	lsl	w8, w21, #1
    5bd8:      	sub	x9, x29, #0x20
    5bdc:      	orr	x22, x9, #0x1
    5be0:      	sturb	w8, [x29, #-0x20]
    5be4:      	cbnz	x21, 0x5c08 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x750>
    5be8:      	b	0x5c18 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x760>
    5bec:      	orr	x24, x21, #0xf
    5bf0:      	add	x0, x24, #0x1
    5bf4:      	bl	0xba00 <_Znwm@plt>
    5bf8:      	add	x8, x24, #0x2
    5bfc:      	mov	x22, x0
    5c00:      	stp	x21, x0, [x29, #-0x18]
    5c04:      	stur	x8, [x29, #-0x20]
    5c08:      	mov	x0, x22
    5c0c:      	mov	x1, x20
    5c10:      	mov	x2, x21
    5c14:      	bl	0xb9b0 <memcpy@plt>
    5c18:      	strb	wzr, [x22, x21]
    5c1c:      	sub	x0, x29, #0x20
    5c20:      	mov	x8, x19
    5c24:      	bl	0x7a10 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2558>
    5c28:      	ldurb	w8, [x29, #-0x20]
    5c2c:      	tbz	w8, #0x0, 0x5c38 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x780>
    5c30:      	ldur	x0, [x29, #-0x10]
    5c34:      	bl	0xba10 <_ZdlPv@plt>
    5c38:      	ldr	x8, [x23, #0x28]
    5c3c:      	ldur	x9, [x29, #-0x8]
    5c40:      	cmp	x8, x9
    5c44:      	b.ne	0x5ca4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x7ec>
    5c48:      	mov	sp, x29
    5c4c:      	ldp	x20, x19, [sp, #0x30]
    5c50:      	ldp	x22, x21, [sp, #0x20]
    5c54:      	ldp	x24, x23, [sp, #0x10]
    5c58:      	ldp	x29, x30, [sp], #0x40
    5c5c:      	ret
    5c60:      	ldr	x8, [x23, #0x28]
    5c64:      	ldur	x9, [x29, #-0x8]
    5c68:      	cmp	x8, x9
    5c6c:      	b.ne	0x5ca4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x7ec>
    5c70:      	sub	x0, x29, #0x20
    5c74:      	bl	0x6564 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x10ac>
    5c78:      	ldurb	w8, [x29, #-0x20]
    5c7c:      	mov	x19, x0
    5c80:      	tbz	w8, #0x0, 0x5c8c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x7d4>
    5c84:      	ldur	x0, [x29, #-0x10]
    5c88:      	bl	0xba10 <_ZdlPv@plt>
    5c8c:      	ldr	x8, [x23, #0x28]
    5c90:      	ldur	x9, [x29, #-0x8]
    5c94:      	cmp	x8, x9
    5c98:      	b.ne	0x5ca4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x7ec>
    5c9c:      	mov	x0, x19
    5ca0:      	bl	0x7cac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x27f4>
    5ca4:      	bl	0xb9e0 <__stack_chk_fail@plt>
    5ca8:      	stp	x29, x30, [sp, #-0x50]!
    5cac:      	stp	x28, x25, [sp, #0x10]
    5cb0:      	stp	x24, x23, [sp, #0x20]
    5cb4:      	stp	x22, x21, [sp, #0x30]
    5cb8:      	stp	x20, x19, [sp, #0x40]
    5cbc:      	mov	x29, sp
    5cc0:      	sub	sp, sp, #0x190
    5cc4:      	mrs	x24, TPIDR_EL0
    5cc8:      	mov	x20, x0
    5ccc:      	sub	x2, x29, #0x18
    5cd0:      	ldr	x8, [x24, #0x28]
    5cd4:      	mov	x19, sp
    5cd8:      	sub	x21, x29, #0x18
    5cdc:      	stur	x8, [x29, #-0x8]
    5ce0:      	ldr	x0, [x0, #0x10]
    5ce4:      	ldr	w1, [x20, #0x18]
    5ce8:      	bl	0x65f8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1140>
    5cec:      	sub	x9, x29, #0x39
    5cf0:      	mov	x8, xzr
    5cf4:      	nop
    5cf8:      	adr	x10, 0x1c00
    5cfc:      	add	x9, x9, #0x1
    5d00:      	ldrb	w11, [x21, x8]
    5d04:      	add	x8, x8, #0x1
    5d08:      	cmp	x8, #0x10
    5d0c:      	lsr	x12, x11, #4
    5d10:      	and	x11, x11, #0xf
    5d14:      	ldrb	w11, [x10, x11]
    5d18:      	ldrb	w12, [x10, x12]
    5d1c:      	sturb	w12, [x9, #-0x1]
    5d20:      	strb	w11, [x9], #0x2
    5d24:      	b.ne	0x5d00 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x848>
    5d28:      	add	x0, x19, #0xc8
    5d2c:      	mov	x1, xzr
    5d30:      	sturb	wzr, [x29, #-0x19]
    5d34:      	bl	0xba20 <gettimeofday@plt>
    5d38:      	ldp	x8, x9, [x19, #0xc8]
    5d3c:      	mov	w10, #0x3e8             // =1000
    5d40:      	sub	x0, x29, #0x9d
    5d44:      	mov	w1, #0x64               // =100
    5d48:      	mul	x8, x8, x10
    5d4c:      	mov	x10, #0xf7cf            // =63439
    5d50:      	lsr	x9, x9, #3
    5d54:      	movk	x10, #0xe353, lsl #16
    5d58:      	movk	x10, #0x9ba5, lsl #32
    5d5c:      	movk	x10, #0x20c4, lsl #48
    5d60:      	umulh	x9, x9, x10
    5d64:      	add	x4, x8, x9, lsr #4
    5d68:      	bl	0x64c0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1008>
    5d6c:      	ldr	x1, [x20, #0x20]
    5d70:      	mov	w21, w0
    5d74:      	stp	xzr, xzr, [x19, #0xc8]
    5d78:      	str	xzr, [x19, #0xd8]
    5d7c:      	cbz	x1, 0x5d88 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x8d0>
    5d80:      	add	x0, x19, #0xc8
    5d84:      	bl	0xba30 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>
    5d88:      	ldr	x1, [x20, #0x30]
    5d8c:      	cbz	x1, 0x5d98 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x8e0>
    5d90:      	add	x0, x19, #0xc8
    5d94:      	bl	0xba30 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>
    5d98:      	ldr	x1, [x20, #0x40]
    5d9c:      	cbz	x1, 0x5da8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x8f0>
    5da0:      	add	x0, x19, #0xc8
    5da4:      	bl	0xba30 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>
    5da8:      	add	x0, x19, #0xc8
    5dac:      	sub	x1, x29, #0x39
    5db0:      	bl	0xba30 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>
    5db4:      	add	x0, x19, #0xc8
    5db8:      	sub	x1, x29, #0x9d
    5dbc:      	add	x22, x19, #0xc8
    5dc0:      	bl	0xba30 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>
    5dc4:      	ldrb	w8, [x19, #0xc8]
    5dc8:      	ldr	x9, [x19, #0xd8]
    5dcc:      	orr	x12, x22, #0x1
    5dd0:      	ldr	w10, [x19, #0xd0]
    5dd4:      	lsr	x11, x8, #1
    5dd8:      	tst	w8, #0x1
    5ddc:      	csel	x0, x12, x9, eq
    5de0:      	csel	w1, w11, w10, eq
    5de4:      	sub	x2, x29, #0xad
    5de8:      	bl	0x65f8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1140>
    5dec:      	add	x8, x19, #0xb0
    5df0:      	sub	x0, x29, #0xad
    5df4:      	mov	w1, #0x10               // =16
    5df8:      	bl	0x78b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x23f8>
    5dfc:      	mov	w0, w21
    5e00:      	bl	0x722c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1d74>
    5e04:      	mov	w8, w0
    5e08:      	mov	x9, sp
    5e0c:      	mov	w22, w0
    5e10:      	add	x8, x8, #0xf
    5e14:      	mov	x25, sp
    5e18:      	and	x8, x8, #0x1fffffff0
    5e1c:      	sub	x23, x9, x8
    5e20:      	mov	sp, x23
    5e24:      	sub	x0, x29, #0x9d
    5e28:      	sub	x2, x29, #0x18
    5e2c:      	mov	w1, w21
    5e30:      	mov	x3, x23
    5e34:      	bl	0x7248 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1d90>
    5e38:      	add	x8, x19, #0x98
    5e3c:      	mov	x0, x23
    5e40:      	mov	w1, w22
    5e44:      	bl	0x78b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x23f8>
    5e48:      	ldr	w0, [x20, #0x8]
    5e4c:      	bl	0x722c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1d74>
    5e50:      	mov	w8, w0
    5e54:      	mov	x9, sp
    5e58:      	mov	w21, w0
    5e5c:      	add	x8, x8, #0xf
    5e60:      	and	x8, x8, #0x1fffffff0
    5e64:      	sub	x22, x9, x8
    5e68:      	mov	sp, x22
    5e6c:      	ldr	x0, [x20]
    5e70:      	ldr	w1, [x20, #0x8]
    5e74:      	nop
    5e78:      	adr	x2, 0x1bd3
    5e7c:      	mov	x3, x22
    5e80:      	bl	0x7248 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1d90>
    5e84:      	add	x8, x19, #0x80
    5e88:      	mov	x0, x22
    5e8c:      	mov	w1, w21
    5e90:      	bl	0x78b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x23f8>
    5e94:      	ldr	w0, [x20, #0x58]
    5e98:      	bl	0x722c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1d74>
    5e9c:      	mov	w8, w0
    5ea0:      	mov	x9, sp
    5ea4:      	mov	w21, w0
    5ea8:      	add	x8, x8, #0xf
    5eac:      	and	x8, x8, #0x1fffffff0
    5eb0:      	sub	x22, x9, x8
    5eb4:      	mov	sp, x22
    5eb8:      	ldr	x0, [x20, #0x50]
    5ebc:      	ldr	w1, [x20, #0x58]
    5ec0:      	sub	x2, x29, #0x18
    5ec4:      	mov	x3, x22
    5ec8:      	bl	0x7248 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1d90>
    5ecc:      	add	x8, x19, #0x68
    5ed0:      	mov	x0, x22
    5ed4:      	mov	w1, w21
    5ed8:      	bl	0x78b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x23f8>
    5edc:      	mov	w9, #0x2e32             // =11826
    5ee0:      	mov	w8, #0x6                // =6
    5ee4:      	movk	w9, #0x30, lsl #16
    5ee8:      	strb	w8, [x19, #0x50]
    5eec:      	stur	w9, [x19, #0x51]
    5ef0:      	mov	w0, #0x3                // =3
    5ef4:      	bl	0x722c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1d74>
    5ef8:      	mov	w9, w0
    5efc:      	mov	x10, sp
    5f00:      	mov	w20, w0
    5f04:      	add	x9, x9, #0xf
    5f08:      	add	x8, x19, #0x50
    5f0c:      	and	x9, x9, #0x1fffffff0
    5f10:      	orr	x8, x8, #0x1
    5f14:      	sub	x21, x10, x9
    5f18:      	mov	sp, x21
    5f1c:      	ldrb	w9, [x19, #0x50]
    5f20:      	ldr	x10, [x19, #0x60]
    5f24:      	ldr	w11, [x19, #0x58]
    5f28:      	lsr	x12, x9, #1
    5f2c:      	tst	w9, #0x1
    5f30:      	csel	x0, x8, x10, eq
    5f34:      	csel	w1, w12, w11, eq
    5f38:      	nop
    5f3c:      	adr	x2, 0x1bd3
    5f40:      	mov	x3, x21
    5f44:      	bl	0x7248 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1d90>
    5f48:      	add	x8, x19, #0x38
    5f4c:      	mov	x0, x21
    5f50:      	mov	w1, w20
    5f54:      	bl	0x78b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x23f8>
    5f58:      	mov	w0, #0xf8               // =248
    5f5c:      	bl	0xba00 <_Znwm@plt>
    5f60:      	mov	w8, #0xa                // =10
    5f64:      	movi	v0.2d, #0000000000000000
    5f68:      	mov	x20, x0
    5f6c:      	str	w8, [x0, #0xf0]
    5f70:      	mov	w8, #0x18               // =24
    5f74:      	strb	w8, [x19, #0x8]
    5f78:      	mov	w8, #0x6c59             // =27737
    5f7c:      	movk	w8, #0x4e32, lsl #16
    5f80:      	strb	wzr, [x19, #0x15]
    5f84:      	stur	w8, [x19, #0x11]
    5f88:      	adrp	x8, 0x1000
    5f8c:      	add	x8, x8, #0x6a9
    5f90:      	ldr	x8, [x8]
    5f94:      	stp	q0, q0, [x0, #0x10]
    5f98:      	stp	q0, q0, [x0, #0x30]
    5f9c:      	stp	q0, q0, [x0, #0x50]
    5fa0:      	stp	q0, q0, [x0, #0x70]
    5fa4:      	stp	q0, q0, [x0, #0x90]
    5fa8:      	stp	q0, q0, [x0, #0xb0]
    5fac:      	stp	q0, q0, [x0, #0xd0]
    5fb0:      	str	q0, [x0]
    5fb4:      	stur	x8, [x19, #0x9]
    5fb8:      	add	x8, x19, #0x20
    5fbc:      	add	x0, x19, #0x8
    5fc0:      	bl	0x5b04 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x64c>
    5fc4:      	ldrb	w8, [x20]
    5fc8:      	tbz	w8, #0x0, 0x5fd4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xb1c>
    5fcc:      	ldr	x0, [x20, #0x10]
    5fd0:      	bl	0xba10 <_ZdlPv@plt>
    5fd4:      	ldr	q0, [x19, #0x20]
    5fd8:      	ldr	x8, [x19, #0x30]
    5fdc:      	str	q0, [x20]
    5fe0:      	str	x8, [x20, #0x10]
    5fe4:      	add	x0, x20, #0x18
    5fe8:      	add	x1, x19, #0xb0
    5fec:      	bl	0xba40 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_@plt>
    5ff0:      	mov	x9, #0x6c5a             // =27738
    5ff4:      	mov	w8, #0x10               // =16
    5ff8:      	strb	wzr, [x19, #0x11]
    5ffc:      	movk	x9, #0x5243, lsl #16
    6000:      	strb	w8, [x19, #0x8]
    6004:      	movk	x9, #0x5831, lsl #32
    6008:      	movk	x9, #0x596b, lsl #48
    600c:      	stur	x9, [x19, #0x9]
    6010:      	add	x8, x19, #0x20
    6014:      	add	x0, x19, #0x8
    6018:      	bl	0x5b04 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x64c>
    601c:      	mov	x21, x20
    6020:      	ldrb	w8, [x21, #0x30]!
    6024:      	tbz	w8, #0x0, 0x6030 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xb78>
    6028:      	ldr	x0, [x20, #0x40]
    602c:      	bl	0xba10 <_ZdlPv@plt>
    6030:      	ldr	q0, [x19, #0x20]
    6034:      	ldr	x8, [x19, #0x30]
    6038:      	str	q0, [x21]
    603c:      	str	x8, [x21, #0x10]
    6040:      	add	x0, x20, #0x48
    6044:      	add	x1, x19, #0x98
    6048:      	bl	0xba40 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_@plt>
    604c:      	adrp	x9, 0x1000
    6050:      	add	x9, x9, #0x605
    6054:      	mov	w10, #0x7963            // =31075
    6058:      	ldr	x9, [x9]
    605c:      	mov	w8, #0x18               // =24
    6060:      	movk	w10, #0x6447, lsl #16
    6064:      	strb	w8, [x19, #0x8]
    6068:      	stur	w10, [x19, #0x11]
    606c:      	stur	x9, [x19, #0x9]
    6070:      	strb	wzr, [x19, #0x15]
    6074:      	add	x8, x19, #0x20
    6078:      	add	x0, x19, #0x8
    607c:      	bl	0x5b04 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x64c>
    6080:      	mov	x21, x20
    6084:      	ldrb	w8, [x21, #0x60]!
    6088:      	tbz	w8, #0x0, 0x6094 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xbdc>
    608c:      	ldr	x0, [x20, #0x70]
    6090:      	bl	0xba10 <_ZdlPv@plt>
    6094:      	ldr	q0, [x19, #0x20]
    6098:      	ldr	x8, [x19, #0x30]
    609c:      	str	q0, [x21]
    60a0:      	str	x8, [x21, #0x10]
    60a4:      	add	x0, x20, #0x78
    60a8:      	add	x1, x19, #0x38
    60ac:      	bl	0xba40 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_@plt>
    60b0:      	mov	x9, #0x7064             // =28772
    60b4:      	mov	w8, #0x10               // =16
    60b8:      	strb	wzr, [x19, #0x11]
    60bc:      	movk	x9, #0x4632, lsl #16
    60c0:      	strb	w8, [x19, #0x8]
    60c4:      	movk	x9, #0x4756, lsl #32
    60c8:      	movk	x9, #0x5a70, lsl #48
    60cc:      	stur	x9, [x19, #0x9]
    60d0:      	add	x8, x19, #0x20
    60d4:      	add	x0, x19, #0x8
    60d8:      	bl	0x5b04 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x64c>
    60dc:      	mov	x21, x20
    60e0:      	ldrb	w8, [x21, #0x90]!
    60e4:      	tbz	w8, #0x0, 0x60f0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xc38>
    60e8:      	ldr	x0, [x20, #0xa0]
    60ec:      	bl	0xba10 <_ZdlPv@plt>
    60f0:      	ldr	q0, [x19, #0x20]
    60f4:      	ldr	x8, [x19, #0x30]
    60f8:      	str	q0, [x21]
    60fc:      	str	x8, [x21, #0x10]
    6100:      	add	x0, x20, #0xa8
    6104:      	add	x1, x19, #0x80
    6108:      	bl	0xba40 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_@plt>
    610c:      	adrp	x9, 0x1000
    6110:      	add	x9, x9, #0x180
    6114:      	mov	w10, #0x6e63            // =28259
    6118:      	ldr	x9, [x9]
    611c:      	mov	w8, #0x18               // =24
    6120:      	movk	w10, #0x6c6d, lsl #16
    6124:      	strb	w8, [x19, #0x8]
    6128:      	stur	w10, [x19, #0x11]
    612c:      	stur	x9, [x19, #0x9]
    6130:      	strb	wzr, [x19, #0x15]
    6134:      	add	x8, x19, #0x20
    6138:      	add	x0, x19, #0x8
    613c:      	bl	0x5b04 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x64c>
    6140:      	mov	x21, x20
    6144:      	ldrb	w8, [x21, #0xc0]!
    6148:      	tbz	w8, #0x0, 0x6154 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xc9c>
    614c:      	ldr	x0, [x20, #0xd0]
    6150:      	bl	0xba10 <_ZdlPv@plt>
    6154:      	ldr	q0, [x19, #0x20]
    6158:      	ldr	x8, [x19, #0x30]
    615c:      	str	q0, [x21]
    6160:      	str	x8, [x21, #0x10]
    6164:      	add	x0, x20, #0xd8
    6168:      	add	x1, x19, #0x68
    616c:      	bl	0xba40 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_@plt>
    6170:      	ldrb	w8, [x19, #0x38]
    6174:      	tbnz	w8, #0x0, 0x61f4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xd3c>
    6178:      	ldrb	w8, [x19, #0x50]
    617c:      	tbnz	w8, #0x0, 0x6204 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xd4c>
    6180:      	ldrb	w8, [x19, #0x68]
    6184:      	tbnz	w8, #0x0, 0x6214 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xd5c>
    6188:      	ldrb	w8, [x19, #0x80]
    618c:      	tbnz	w8, #0x0, 0x6224 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xd6c>
    6190:      	ldrb	w8, [x19, #0x98]
    6194:      	tbz	w8, #0x0, 0x61a0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xce8>
    6198:      	ldr	x0, [x19, #0xa8]
    619c:      	bl	0xba10 <_ZdlPv@plt>
    61a0:      	mov	sp, x25
    61a4:      	ldrb	w8, [x19, #0xb0]
    61a8:      	tbz	w8, #0x0, 0x61b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xcfc>
    61ac:      	ldr	x0, [x19, #0xc0]
    61b0:      	bl	0xba10 <_ZdlPv@plt>
    61b4:      	ldrb	w8, [x19, #0xc8]
    61b8:      	tbz	w8, #0x0, 0x61c4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xd0c>
    61bc:      	ldr	x0, [x19, #0xd8]
    61c0:      	bl	0xba10 <_ZdlPv@plt>
    61c4:      	ldr	x8, [x24, #0x28]
    61c8:      	ldur	x9, [x29, #-0x8]
    61cc:      	cmp	x8, x9
    61d0:      	b.ne	0x6374 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xebc>
    61d4:      	mov	x0, x20
    61d8:      	mov	sp, x29
    61dc:      	ldp	x20, x19, [sp, #0x40]
    61e0:      	ldp	x22, x21, [sp, #0x30]
    61e4:      	ldp	x24, x23, [sp, #0x20]
    61e8:      	ldp	x28, x25, [sp, #0x10]
    61ec:      	ldp	x29, x30, [sp], #0x50
    61f0:      	ret
    61f4:      	ldr	x0, [x19, #0x48]
    61f8:      	bl	0xba10 <_ZdlPv@plt>
    61fc:      	ldrb	w8, [x19, #0x50]
    6200:      	tbz	w8, #0x0, 0x6180 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xcc8>
    6204:      	ldr	x0, [x19, #0x60]
    6208:      	bl	0xba10 <_ZdlPv@plt>
    620c:      	ldrb	w8, [x19, #0x68]
    6210:      	tbz	w8, #0x0, 0x6188 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xcd0>
    6214:      	ldr	x0, [x19, #0x78]
    6218:      	bl	0xba10 <_ZdlPv@plt>
    621c:      	ldrb	w8, [x19, #0x80]
    6220:      	tbz	w8, #0x0, 0x6190 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xcd8>
    6224:      	ldr	x0, [x19, #0x90]
    6228:      	bl	0xba10 <_ZdlPv@plt>
    622c:      	ldrb	w8, [x19, #0x98]
    6230:      	tbnz	w8, #0x0, 0x6198 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xce0>
    6234:      	b	0x61a0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xce8>
    6238:      	b	0x62b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xdfc>
    623c:      	b	0x62b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xdfc>
    6240:      	b	0x62b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xdfc>
    6244:      	b	0x62b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xdfc>
    6248:      	b	0x62b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xdfc>
    624c:      	b	0x6264 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xdac>
    6250:      	b	0x6274 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xdbc>
    6254:      	b	0x6284 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xdcc>
    6258:      	b	0x6294 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xddc>
    625c:      	b	0x62a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xdec>
    6260:      	b	0x62a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xdec>
    6264:      	mov	x20, x0
    6268:      	ldrb	w8, [x19, #0x50]
    626c:      	tbz	w8, #0x0, 0x62c8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe10>
    6270:      	b	0x6320 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe68>
    6274:      	mov	x20, x0
    6278:      	ldrb	w8, [x19, #0x80]
    627c:      	tbz	w8, #0x0, 0x62d8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe20>
    6280:      	b	0x6340 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe88>
    6284:      	mov	x20, x0
    6288:      	ldrb	w8, [x19, #0x98]
    628c:      	tbz	w8, #0x0, 0x62e0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe28>
    6290:      	b	0x6350 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe98>
    6294:      	mov	x20, x0
    6298:      	ldrb	w8, [x19, #0xb0]
    629c:      	tbz	w8, #0x0, 0x62e8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe30>
    62a0:      	b	0x6360 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xea8>
    62a4:      	mov	x20, x0
    62a8:      	ldrb	w8, [x19, #0xc8]
    62ac:      	tbnz	w8, #0x0, 0x62f0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe38>
    62b0:      	b	0x62f8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe40>
    62b4:      	ldrb	w8, [x19, #0x38]
    62b8:      	mov	x20, x0
    62bc:      	tbnz	w8, #0x0, 0x6310 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe58>
    62c0:      	ldrb	w8, [x19, #0x50]
    62c4:      	tbnz	w8, #0x0, 0x6320 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe68>
    62c8:      	ldrb	w8, [x19, #0x68]
    62cc:      	tbnz	w8, #0x0, 0x6330 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe78>
    62d0:      	ldrb	w8, [x19, #0x80]
    62d4:      	tbnz	w8, #0x0, 0x6340 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe88>
    62d8:      	ldrb	w8, [x19, #0x98]
    62dc:      	tbnz	w8, #0x0, 0x6350 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe98>
    62e0:      	ldrb	w8, [x19, #0xb0]
    62e4:      	tbnz	w8, #0x0, 0x6360 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xea8>
    62e8:      	ldrb	w8, [x19, #0xc8]
    62ec:      	tbz	w8, #0x0, 0x62f8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe40>
    62f0:      	ldr	x0, [x19, #0xd8]
    62f4:      	bl	0xba10 <_ZdlPv@plt>
    62f8:      	ldr	x8, [x24, #0x28]
    62fc:      	ldur	x9, [x29, #-0x8]
    6300:      	cmp	x8, x9
    6304:      	b.ne	0x6374 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xebc>
    6308:      	mov	x0, x20
    630c:      	bl	0x7cac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x27f4>
    6310:      	ldr	x0, [x19, #0x48]
    6314:      	bl	0xba10 <_ZdlPv@plt>
    6318:      	ldrb	w8, [x19, #0x50]
    631c:      	tbz	w8, #0x0, 0x62c8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe10>
    6320:      	ldr	x0, [x19, #0x60]
    6324:      	bl	0xba10 <_ZdlPv@plt>
    6328:      	ldrb	w8, [x19, #0x68]
    632c:      	tbz	w8, #0x0, 0x62d0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe18>
    6330:      	ldr	x0, [x19, #0x78]
    6334:      	bl	0xba10 <_ZdlPv@plt>
    6338:      	ldrb	w8, [x19, #0x80]
    633c:      	tbz	w8, #0x0, 0x62d8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe20>
    6340:      	ldr	x0, [x19, #0x90]
    6344:      	bl	0xba10 <_ZdlPv@plt>
    6348:      	ldrb	w8, [x19, #0x98]
    634c:      	tbz	w8, #0x0, 0x62e0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe28>
    6350:      	ldr	x0, [x19, #0xa8]
    6354:      	bl	0xba10 <_ZdlPv@plt>
    6358:      	ldrb	w8, [x19, #0xb0]
    635c:      	tbz	w8, #0x0, 0x62e8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe30>
    6360:      	ldr	x0, [x19, #0xc0]
    6364:      	bl	0xba10 <_ZdlPv@plt>
    6368:      	ldrb	w8, [x19, #0xc8]
    636c:      	tbnz	w8, #0x0, 0x62f0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe38>
    6370:      	b	0x62f8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xe40>
    6374:      	bl	0xb9e0 <__stack_chk_fail@plt>
    6378:      	cbz	x0, 0x63a0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xee8>
    637c:      	stp	x29, x30, [sp, #-0x20]!
    6380:      	str	x19, [sp, #0x10]
    6384:      	mov	x29, sp
    6388:      	mov	x19, x0
    638c:      	bl	0x63a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xeec>
    6390:      	mov	x0, x19
    6394:      	ldr	x19, [sp, #0x10]
    6398:      	ldp	x29, x30, [sp], #0x20
    639c:      	b	0xba10 <_ZdlPv@plt>
    63a0:      	ret
    63a4:      	stp	x29, x30, [sp, #-0x20]!
    63a8:      	str	x19, [sp, #0x10]
    63ac:      	mov	x29, sp
    63b0:      	ldrb	w8, [x0, #0xd8]
    63b4:      	mov	x19, x0
    63b8:      	tbnz	w8, #0x0, 0x6410 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xf58>
    63bc:      	ldrb	w8, [x19, #0xc0]
    63c0:      	tbnz	w8, #0x0, 0x6420 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xf68>
    63c4:      	ldrb	w8, [x19, #0xa8]
    63c8:      	tbnz	w8, #0x0, 0x6430 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xf78>
    63cc:      	ldrb	w8, [x19, #0x90]
    63d0:      	tbnz	w8, #0x0, 0x6440 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xf88>
    63d4:      	ldrb	w8, [x19, #0x78]
    63d8:      	tbnz	w8, #0x0, 0x6450 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xf98>
    63dc:      	ldrb	w8, [x19, #0x60]
    63e0:      	tbnz	w8, #0x0, 0x6460 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xfa8>
    63e4:      	ldrb	w8, [x19, #0x48]
    63e8:      	tbnz	w8, #0x0, 0x6470 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xfb8>
    63ec:      	ldrb	w8, [x19, #0x30]
    63f0:      	tbnz	w8, #0x0, 0x6480 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xfc8>
    63f4:      	ldrb	w8, [x19, #0x18]
    63f8:      	tbnz	w8, #0x0, 0x6490 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xfd8>
    63fc:      	ldrb	w8, [x19]
    6400:      	tbnz	w8, #0x0, 0x64a0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xfe8>
    6404:      	ldr	x19, [sp, #0x10]
    6408:      	ldp	x29, x30, [sp], #0x20
    640c:      	ret
    6410:      	ldr	x0, [x19, #0xe8]
    6414:      	bl	0xba10 <_ZdlPv@plt>
    6418:      	ldrb	w8, [x19, #0xc0]
    641c:      	tbz	w8, #0x0, 0x63c4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xf0c>
    6420:      	ldr	x0, [x19, #0xd0]
    6424:      	bl	0xba10 <_ZdlPv@plt>
    6428:      	ldrb	w8, [x19, #0xa8]
    642c:      	tbz	w8, #0x0, 0x63cc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xf14>
    6430:      	ldr	x0, [x19, #0xb8]
    6434:      	bl	0xba10 <_ZdlPv@plt>
    6438:      	ldrb	w8, [x19, #0x90]
    643c:      	tbz	w8, #0x0, 0x63d4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xf1c>
    6440:      	ldr	x0, [x19, #0xa0]
    6444:      	bl	0xba10 <_ZdlPv@plt>
    6448:      	ldrb	w8, [x19, #0x78]
    644c:      	tbz	w8, #0x0, 0x63dc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xf24>
    6450:      	ldr	x0, [x19, #0x88]
    6454:      	bl	0xba10 <_ZdlPv@plt>
    6458:      	ldrb	w8, [x19, #0x60]
    645c:      	tbz	w8, #0x0, 0x63e4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xf2c>
    6460:      	ldr	x0, [x19, #0x70]
    6464:      	bl	0xba10 <_ZdlPv@plt>
    6468:      	ldrb	w8, [x19, #0x48]
    646c:      	tbz	w8, #0x0, 0x63ec <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xf34>
    6470:      	ldr	x0, [x19, #0x58]
    6474:      	bl	0xba10 <_ZdlPv@plt>
    6478:      	ldrb	w8, [x19, #0x30]
    647c:      	tbz	w8, #0x0, 0x63f4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xf3c>
    6480:      	ldr	x0, [x19, #0x40]
    6484:      	bl	0xba10 <_ZdlPv@plt>
    6488:      	ldrb	w8, [x19, #0x18]
    648c:      	tbz	w8, #0x0, 0x63fc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xf44>
    6490:      	ldr	x0, [x19, #0x28]
    6494:      	bl	0xba10 <_ZdlPv@plt>
    6498:      	ldrb	w8, [x19]
    649c:      	tbz	w8, #0x0, 0x6404 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0xf4c>
    64a0:      	ldr	x0, [x19, #0x10]
    64a4:      	ldr	x19, [sp, #0x10]
    64a8:      	ldp	x29, x30, [sp], #0x20
    64ac:      	b	0xba10 <_ZdlPv@plt>
    64b0:      	sxtw	x0, w0
    64b4:      	b	0xba50 <_Znam@plt>
    64b8:      	sxtw	x0, w0
    64bc:      	b	0xba50 <_Znam@plt>
    64c0:      	sub	sp, sp, #0x110
    64c4:      	stp	x29, x30, [sp, #0xf0]
    64c8:      	stp	x28, x19, [sp, #0x100]
    64cc:      	add	x29, sp, #0xf0
    64d0:      	stp	x4, x5, [x29, #-0x70]
    64d4:      	sub	x9, x29, #0x70
    64d8:      	sub	x10, x29, #0x28
    64dc:      	stp	x6, x7, [x29, #-0x60]
    64e0:      	mov	x3, x1
    64e4:      	adrp	x4, 0x1000
    64e8:      	add	x4, x4, #0x23e
    64ec:      	stp	q0, q1, [sp]
    64f0:      	sub	x5, x29, #0x50
    64f4:      	stp	q2, q3, [sp, #0x20]
    64f8:      	mov	w1, #0x64               // =100
    64fc:      	mov	w2, wzr
    6500:      	stp	q4, q5, [sp, #0x40]
    6504:      	stp	q6, q7, [sp, #0x60]
    6508:      	mrs	x19, TPIDR_EL0
    650c:      	ldr	x8, [x19, #0x28]
    6510:      	stur	x8, [x29, #-0x8]
    6514:      	add	x8, x9, #0x20
    6518:      	add	x9, x29, #0x20
    651c:      	stp	x9, x8, [x29, #-0x28]
    6520:      	mov	x8, #-0x20              // =-32
    6524:      	mov	x9, sp
    6528:      	movk	x8, #0xff80, lsl #32
    652c:      	add	x9, x9, #0x80
    6530:      	stp	x9, x8, [x29, #-0x18]
    6534:      	ldp	q0, q1, [x10]
    6538:      	stp	q0, q1, [x29, #-0x50]
    653c:      	bl	0xba60 <__vsnprintf_chk@plt>
    6540:      	ldr	x8, [x19, #0x28]
    6544:      	ldur	x9, [x29, #-0x8]
    6548:      	cmp	x8, x9
    654c:      	b.ne	0x6560 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x10a8>
    6550:      	ldp	x28, x19, [sp, #0x100]
    6554:      	ldp	x29, x30, [sp, #0xf0]
    6558:      	add	sp, sp, #0x110
    655c:      	ret
    6560:      	bl	0xb9e0 <__stack_chk_fail@plt>
    6564:      	stp	x29, x30, [sp, #-0x10]!
    6568:      	mov	x29, sp
    656c:      	adrp	x0, 0x1000
    6570:      	add	x0, x0, #0x997
    6574:      	bl	0x6578 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x10c0>
    6578:      	stp	x29, x30, [sp, #-0x20]!
    657c:      	stp	x20, x19, [sp, #0x10]
    6580:      	mov	x29, sp
    6584:      	mov	x20, x0
    6588:      	mov	w0, #0x10               // =16
    658c:      	bl	0xba70 <__cxa_allocate_exception@plt>
    6590:      	mov	x19, x0
    6594:      	mov	x1, x20
    6598:      	bl	0x65c8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1110>
    659c:      	adrp	x1, 0xf000 <fwrite@plt+0x3470>
    65a0:      	adrp	x2, 0xf000 <fwrite@plt+0x3470>
    65a4:      	mov	x0, x19
    65a8:      	ldr	x1, [x1, #0xe10]
    65ac:      	ldr	x2, [x2, #0xe18]
    65b0:      	bl	0xba80 <__cxa_throw@plt>
    65b4:      	mov	x20, x0
    65b8:      	mov	x0, x19
    65bc:      	bl	0xba90 <__cxa_free_exception@plt>
    65c0:      	mov	x0, x20
    65c4:      	bl	0x7cac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x27f4>
    65c8:      	stp	x29, x30, [sp, #-0x20]!
    65cc:      	str	x19, [sp, #0x10]
    65d0:      	mov	x29, sp
    65d4:      	mov	x19, x0
    65d8:      	bl	0xbaa0 <_ZNSt11logic_errorC2EPKc@plt>
    65dc:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    65e0:      	ldr	x8, [x8, #0xe20]
    65e4:      	add	x8, x8, #0x10
    65e8:      	str	x8, [x19]
    65ec:      	ldr	x19, [sp, #0x10]
    65f0:      	ldp	x29, x30, [sp], #0x20
    65f4:      	ret
    65f8:      	sub	sp, sp, #0x90
    65fc:      	stp	x29, x30, [sp, #0x70]
    6600:      	stp	x20, x19, [sp, #0x80]
    6604:      	add	x29, sp, #0x70
    6608:      	mrs	x20, TPIDR_EL0
    660c:      	adrp	x9, 0x1000
    6610:      	mov	x19, x2
    6614:      	ldr	x8, [x20, #0x28]
    6618:      	ldr	q0, [x9, #0xbf0]
    661c:      	mov	w2, w1
    6620:      	mov	x1, x0
    6624:      	mov	x0, sp
    6628:      	stur	x8, [x29, #-0x8]
    662c:      	str	xzr, [sp, #0x10]
    6630:      	str	q0, [sp]
    6634:      	bl	0x66b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x11fc>
    6638:      	ldp	w8, w9, [sp, #0x10]
    663c:      	mov	w11, #0x78              // =120
    6640:      	mov	w12, #0x38              // =56
    6644:      	nop
    6648:      	adr	x1, 0x13f58
    664c:      	mov	x0, sp
    6650:      	ubfx	w10, w8, #3, #6
    6654:      	stp	w8, w9, [x29, #-0x10]
    6658:      	cmp	w10, #0x38
    665c:      	csel	w11, w12, w11, lo
    6660:      	sub	w2, w11, w10
    6664:      	bl	0x66b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x11fc>
    6668:      	mov	x0, sp
    666c:      	sub	x1, x29, #0x10
    6670:      	mov	w2, #0x8                // =8
    6674:      	bl	0x66b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x11fc>
    6678:      	ldr	w8, [sp]
    667c:      	ldur	x9, [sp, #0x4]
    6680:      	ldr	w10, [sp, #0xc]
    6684:      	str	w8, [x19]
    6688:      	stur	x9, [x19, #0x4]
    668c:      	str	w10, [x19, #0xc]
    6690:      	ldr	x8, [x20, #0x28]
    6694:      	ldur	x9, [x29, #-0x8]
    6698:      	cmp	x8, x9
    669c:      	b.ne	0x66b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x11f8>
    66a0:      	ldp	x20, x19, [sp, #0x80]
    66a4:      	ldp	x29, x30, [sp, #0x70]
    66a8:      	add	sp, sp, #0x90
    66ac:      	ret
    66b0:      	bl	0xb9e0 <__stack_chk_fail@plt>
    66b4:      	stp	x29, x30, [sp, #-0x40]!
    66b8:      	stp	x24, x23, [sp, #0x10]
    66bc:      	stp	x22, x21, [sp, #0x20]
    66c0:      	stp	x20, x19, [sp, #0x30]
    66c4:      	mov	x29, sp
    66c8:      	ldp	w8, w9, [x0, #0x10]
    66cc:      	lsr	w10, w2, #29
    66d0:      	mov	w11, #0x40              // =64
    66d4:      	mov	w19, w2
    66d8:      	mov	x21, x1
    66dc:      	mov	x20, x0
    66e0:      	ubfx	x24, x8, #3, #6
    66e4:      	adds	w8, w8, w2, lsl #3
    66e8:      	adc	w9, w10, w9
    66ec:      	sub	w22, w11, w24
    66f0:      	stp	w8, w9, [x0, #0x10]
    66f4:      	cmp	w22, w2
    66f8:      	b.ls	0x6708 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1250>
    66fc:      	mov	w22, wzr
    6700:      	mov	w8, w24
    6704:      	b	0x6760 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x12a8>
    6708:      	add	x23, x20, #0x18
    670c:      	mov	x1, x21
    6710:      	mov	x2, x22
    6714:      	add	x0, x23, x24
    6718:      	bl	0xb9b0 <memcpy@plt>
    671c:      	mov	x0, x20
    6720:      	mov	x1, x23
    6724:      	bl	0x6784 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x12cc>
    6728:      	eor	w23, w24, #0x7f
    672c:      	cmp	w23, w19
    6730:      	b.hs	0x675c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x12a4>
    6734:      	sub	w8, w23, #0x3f
    6738:      	mov	x0, x20
    673c:      	add	x1, x21, x8
    6740:      	bl	0x6784 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x12cc>
    6744:      	add	w23, w23, #0x40
    6748:      	cmp	w23, w19
    674c:      	b.lo	0x6734 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x127c>
    6750:      	mov	x8, xzr
    6754:      	sub	w22, w23, #0x3f
    6758:      	b	0x6760 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x12a8>
    675c:      	mov	x8, xzr
    6760:      	add	x8, x20, x8
    6764:      	add	x1, x21, w22, uxtw
    6768:      	sub	w2, w19, w22
    676c:      	add	x0, x8, #0x18
    6770:      	ldp	x20, x19, [sp, #0x30]
    6774:      	ldp	x22, x21, [sp, #0x20]
    6778:      	ldp	x24, x23, [sp, #0x10]
    677c:      	ldp	x29, x30, [sp], #0x40
    6780:      	b	0xb9b0 <memcpy@plt>
    6784:      	stp	x28, x27, [sp, #-0x50]!
    6788:      	stp	x26, x25, [sp, #0x10]
    678c:      	stp	x24, x23, [sp, #0x20]
    6790:      	stp	x22, x21, [sp, #0x30]
    6794:      	stp	x20, x19, [sp, #0x40]
    6798:      	ld4	{ v0.16b, v1.16b, v2.16b, v3.16b }, [x1]
    679c:      	mov	w12, #0x407d            // =16509
    67a0:      	ldr	w8, [x0, #0xc]
    67a4:      	movk	w12, #0x8a51, lsl #16
    67a8:      	ldr	w11, [x0]
    67ac:      	ldp	w10, w9, [x0, #0x4]
    67b0:      	and	w13, w9, w10
    67b4:      	bic	w14, w8, w10
    67b8:      	ushll	v4.8h, v0.8b, #0x0
    67bc:      	ushll	v5.8h, v1.8b, #0x0
    67c0:      	ushll	v6.8h, v2.8b, #0x0
    67c4:      	ushll	v7.8h, v3.8b, #0x0
    67c8:      	orr	w13, w14, w13
    67cc:      	add	w13, w11, w13
    67d0:      	ushll	v16.4s, v4.4h, #0x0
    67d4:      	ushll	v17.4s, v5.4h, #0x8
    67d8:      	shll	v18.4s, v6.4h, #16
    67dc:      	ushll	v19.4s, v7.4h, #0x0
    67e0:      	ushll2	v4.4s, v4.8h, #0x0
    67e4:      	ushll2	v5.4s, v5.8h, #0x8
    67e8:      	shll2	v6.4s, v6.8h, #16
    67ec:      	ushll2	v7.4s, v7.8h, #0x0
    67f0:      	orr	v16.16b, v17.16b, v16.16b
    67f4:      	shl	v17.4s, v19.4s, #0x18
    67f8:      	orr	v4.16b, v5.16b, v4.16b
    67fc:      	shl	v5.4s, v7.4s, #0x18
    6800:      	orr	v16.16b, v16.16b, v18.16b
    6804:      	orr	v4.16b, v4.16b, v6.16b
    6808:      	orr	v16.16b, v16.16b, v17.16b
    680c:      	orr	v6.16b, v4.16b, v5.16b
    6810:      	ushll2	v4.8h, v0.16b, #0x0
    6814:      	ushll2	v5.8h, v1.16b, #0x0
    6818:      	ushll2	v0.8h, v3.16b, #0x0
    681c:      	fmov	w17, s16
    6820:      	ushll	v1.4s, v4.4h, #0x0
    6824:      	ushll	v7.4s, v0.4h, #0x0
    6828:      	ushll2	v0.4s, v0.8h, #0x0
    682c:      	add	w14, w13, w17
    6830:      	mov	w13, v16.s[1]
    6834:      	add	w12, w14, w12
    6838:      	mov	w14, #0x995d            // =39261
    683c:      	ror	w12, w12, #0x19
    6840:      	movk	w14, #0x6a88, lsl #16
    6844:      	shl	v0.4s, v0.4s, #0x18
    6848:      	add	w16, w12, w10
    684c:      	add	w12, w8, w13
    6850:      	and	w15, w16, w10
    6854:      	bic	w1, w9, w16
    6858:      	add	w14, w12, w14
    685c:      	orr	w15, w15, w1
    6860:      	mov	w12, v16.s[2]
    6864:      	mov	w1, #0x25f4             // =9716
    6868:      	add	w14, w14, w15
    686c:      	movk	w1, #0xfd70, lsl #16
    6870:      	mov	w15, v16.s[3]
    6874:      	ror	w14, w14, #0x14
    6878:      	add	w4, w14, w16
    687c:      	add	w14, w9, w12
    6880:      	and	w2, w4, w16
    6884:      	bic	w3, w10, w4
    6888:      	add	w14, w14, w1
    688c:      	orr	w1, w2, w3
    6890:      	mov	w2, #0x3036             // =12342
    6894:      	add	w14, w14, w1
    6898:      	movk	w2, #0xa755, lsl #16
    689c:      	ror	w14, w14, #0xf
    68a0:      	add	w1, w14, w4
    68a4:      	add	w14, w10, w15
    68a8:      	and	w3, w1, w4
    68ac:      	bic	w5, w16, w1
    68b0:      	add	w14, w14, w2
    68b4:      	orr	w2, w3, w5
    68b8:      	mov	w5, #0x15c1             // =5569
    68bc:      	add	w14, w14, w2
    68c0:      	movk	w5, #0x489e, lsl #16
    68c4:      	ror	w2, w14, #0xa
    68c8:      	fmov	w14, s6
    68cc:      	add	w3, w2, w1
    68d0:      	add	w16, w14, w16
    68d4:      	and	w2, w3, w1
    68d8:      	bic	w6, w4, w3
    68dc:      	add	w16, w16, w5
    68e0:      	orr	w5, w2, w6
    68e4:      	mov	w2, v6.s[1]
    68e8:      	add	w16, w16, w5
    68ec:      	mov	w5, #0xb84b             // =47179
    68f0:      	ror	w16, w16, #0x19
    68f4:      	movk	w5, #0xf5cd, lsl #16
    68f8:      	add	w6, w16, w3
    68fc:      	add	w4, w2, w4
    6900:      	mov	w16, v6.s[2]
    6904:      	and	w7, w6, w3
    6908:      	bic	w19, w1, w6
    690c:      	add	w4, w4, w5
    6910:      	orr	w5, w7, w19
    6914:      	mov	w7, #0xbcf6             // =48374
    6918:      	add	w4, w4, w5
    691c:      	mov	w5, v6.s[3]
    6920:      	ushll2	v6.8h, v2.16b, #0x0
    6924:      	ror	w4, w4, #0x14
    6928:      	ushll	v2.4s, v5.4h, #0x8
    692c:      	movk	w7, #0xc0ff, lsl #16
    6930:      	add	w1, w16, w1
    6934:      	add	w20, w4, w6
    6938:      	shll	v3.4s, v6.4h, #16
    693c:      	add	w1, w1, w7
    6940:      	and	w4, w20, w6
    6944:      	bic	w19, w3, w20
    6948:      	orr	v1.16b, v2.16b, v1.16b
    694c:      	orr	w4, w4, w19
    6950:      	shl	v2.4s, v7.4s, #0x18
    6954:      	add	w1, w1, w4
    6958:      	mov	w4, #0x7d7e             // =32126
    695c:      	ror	w1, w1, #0xf
    6960:      	orr	v1.16b, v1.16b, v3.16b
    6964:      	movk	w4, #0x253f, lsl #16
    6968:      	shll2	v3.4s, v6.8h, #16
    696c:      	add	w7, w1, w20
    6970:      	add	w1, w5, w3
    6974:      	and	w3, w7, w20
    6978:      	bic	w19, w6, w7
    697c:      	orr	v1.16b, v1.16b, v2.16b
    6980:      	add	w1, w1, w4
    6984:      	orr	w3, w3, w19
    6988:      	ushll2	v2.4s, v5.8h, #0x8
    698c:      	add	w1, w1, w3
    6990:      	mov	w3, #0xd535             // =54581
    6994:      	ror	w1, w1, #0xa
    6998:      	fmov	w4, s1
    699c:      	movk	w3, #0xe93f, lsl #16
    69a0:      	add	w19, w1, w7
    69a4:      	add	w1, w4, w6
    69a8:      	and	w6, w19, w7
    69ac:      	bic	w21, w20, w19
    69b0:      	add	w3, w1, w3
    69b4:      	orr	w6, w6, w21
    69b8:      	mov	w1, v1.s[1]
    69bc:      	add	w3, w3, w6
    69c0:      	mov	w6, #0x6448             // =25672
    69c4:      	ror	w3, w3, #0x19
    69c8:      	movk	w6, #0xd6cd, lsl #16
    69cc:      	add	w21, w3, w19
    69d0:      	add	w3, w1, w20
    69d4:      	and	w20, w21, w19
    69d8:      	bic	w22, w7, w21
    69dc:      	add	w3, w3, w6
    69e0:      	orr	w20, w20, w22
    69e4:      	mov	w6, v1.s[2]
    69e8:      	mov	w22, #0xae4             // =2788
    69ec:      	add	w3, w3, w20
    69f0:      	movk	w22, #0x122, lsl #16
    69f4:      	ror	w20, w3, #0x14
    69f8:      	mov	w3, v1.s[3]
    69fc:      	ushll2	v1.4s, v4.8h, #0x0
    6a00:      	add	w23, w20, w21
    6a04:      	add	w7, w6, w7
    6a08:      	and	w20, w23, w21
    6a0c:      	bic	w24, w19, w23
    6a10:      	orr	v1.16b, v2.16b, v1.16b
    6a14:      	add	w7, w7, w22
    6a18:      	orr	w20, w20, w24
    6a1c:      	add	w7, w7, w20
    6a20:      	mov	w20, #0xd023            // =53283
    6a24:      	ror	w7, w7, #0xf
    6a28:      	orr	v1.16b, v1.16b, v3.16b
    6a2c:      	movk	w20, #0xd806, lsl #16
    6a30:      	add	w22, w7, w23
    6a34:      	add	w7, w3, w19
    6a38:      	and	w19, w22, w23
    6a3c:      	bic	w24, w21, w22
    6a40:      	orr	v0.16b, v1.16b, v0.16b
    6a44:      	add	w7, w7, w20
    6a48:      	orr	w19, w19, w24
    6a4c:      	add	w7, w7, w19
    6a50:      	mov	w19, #0x6ea9            // =28329
    6a54:      	ror	w7, w7, #0xa
    6a58:      	fmov	w20, s0
    6a5c:      	movk	w19, #0xe84e, lsl #16
    6a60:      	add	w24, w7, w22
    6a64:      	add	w7, w20, w21
    6a68:      	and	w21, w24, w22
    6a6c:      	bic	w25, w23, w24
    6a70:      	add	w19, w7, w19
    6a74:      	orr	w21, w21, w25
    6a78:      	mov	w7, v0.s[1]
    6a7c:      	add	w19, w19, w21
    6a80:      	mov	w21, #0x35d8            // =13784
    6a84:      	ror	w19, w19, #0x19
    6a88:      	movk	w21, #0x2301, lsl #16
    6a8c:      	add	w25, w19, w24
    6a90:      	add	w19, w7, w23
    6a94:      	and	w23, w25, w24
    6a98:      	bic	w26, w22, w25
    6a9c:      	add	w19, w19, w21
    6aa0:      	orr	w23, w23, w26
    6aa4:      	mov	w21, v0.s[2]
    6aa8:      	add	w19, w19, w23
    6aac:      	mov	w23, #0xe834            // =59444
    6ab0:      	ror	w19, w19, #0x14
    6ab4:      	movk	w23, #0xc27a, lsl #16
    6ab8:      	add	w26, w19, w25
    6abc:      	add	w19, w21, w22
    6ac0:      	and	w22, w26, w25
    6ac4:      	bic	w27, w24, w26
    6ac8:      	add	w23, w19, w23
    6acc:      	orr	w22, w22, w27
    6ad0:      	mov	w19, v0.s[3]
    6ad4:      	add	w22, w23, w22
    6ad8:      	mov	w23, #0x2bf4            // =11252
    6adc:      	ror	w22, w22, #0xf
    6ae0:      	movk	w23, #0xf529, lsl #16
    6ae4:      	add	w22, w22, w26
    6ae8:      	add	w24, w19, w24
    6aec:      	and	w27, w22, w26
    6af0:      	bic	w28, w25, w22
    6af4:      	add	w23, w24, w23
    6af8:      	orr	w24, w27, w28
    6afc:      	add	w25, w13, w25
    6b00:      	bic	w27, w22, w26
    6b04:      	add	w23, w23, w24
    6b08:      	mov	w24, #0x1ac1            // =6849
    6b0c:      	ror	w23, w23, #0xa
    6b10:      	movk	w24, #0x4671, lsl #16
    6b14:      	add	w24, w25, w24
    6b18:      	add	w23, w23, w22
    6b1c:      	and	w28, w23, w26
    6b20:      	add	w26, w16, w26
    6b24:      	orr	w25, w28, w27
    6b28:      	bic	w27, w23, w22
    6b2c:      	add	w24, w24, w25
    6b30:      	mov	w25, #0x840a            // =33802
    6b34:      	ror	w24, w24, #0x1b
    6b38:      	movk	w25, #0xa90a, lsl #16
    6b3c:      	add	w25, w26, w25
    6b40:      	add	w24, w24, w23
    6b44:      	and	w28, w24, w22
    6b48:      	add	w22, w3, w22
    6b4c:      	orr	w26, w28, w27
    6b50:      	bic	w27, w24, w23
    6b54:      	add	w25, w25, w26
    6b58:      	mov	w26, #0xbef0            // =48880
    6b5c:      	ror	w25, w25, #0x17
    6b60:      	movk	w26, #0xfd1b, lsl #16
    6b64:      	add	w22, w22, w26
    6b68:      	add	w25, w25, w24
    6b6c:      	and	w28, w25, w23
    6b70:      	add	w23, w17, w23
    6b74:      	orr	w26, w28, w27
    6b78:      	bic	w27, w25, w24
    6b7c:      	add	w22, w22, w26
    6b80:      	mov	w26, #0x10e5            // =4325
    6b84:      	ror	w22, w22, #0x12
    6b88:      	movk	w26, #0x6878, lsl #16
    6b8c:      	add	w23, w23, w26
    6b90:      	add	w22, w22, w25
    6b94:      	and	w28, w22, w24
    6b98:      	add	w24, w2, w24
    6b9c:      	orr	w26, w28, w27
    6ba0:      	bic	w27, w22, w25
    6ba4:      	add	w23, w23, w26
    6ba8:      	mov	w26, #0xfc1b            // =64539
    6bac:      	ror	w23, w23, #0xc
    6bb0:      	movk	w26, #0x8c37, lsl #16
    6bb4:      	add	w24, w24, w26
    6bb8:      	add	w23, w23, w22
    6bbc:      	and	w28, w23, w25
    6bc0:      	add	w25, w6, w25
    6bc4:      	orr	w26, w28, w27
    6bc8:      	sub	w25, w25, #0x29, lsl #12 // =0x29000
    6bcc:      	add	w24, w24, w26
    6bd0:      	bic	w26, w23, w22
    6bd4:      	sub	w25, w25, #0x13a
    6bd8:      	ror	w24, w24, #0x1b
    6bdc:      	add	w24, w24, w23
    6be0:      	and	w27, w24, w22
    6be4:      	add	w22, w19, w22
    6be8:      	orr	w26, w27, w26
    6bec:      	bic	w27, w24, w23
    6bf0:      	add	w25, w25, w26
    6bf4:      	mov	w26, #0xbeac            // =48812
    6bf8:      	ror	w25, w25, #0x17
    6bfc:      	movk	w26, #0x8867, lsl #16
    6c00:      	add	w22, w22, w26
    6c04:      	add	w25, w25, w24
    6c08:      	and	w28, w25, w23
    6c0c:      	add	w23, w14, w23
    6c10:      	orr	w26, w28, w27
    6c14:      	bic	w27, w25, w24
    6c18:      	add	w22, w22, w26
    6c1c:      	mov	w26, #0xfed4            // =65236
    6c20:      	ror	w22, w22, #0x12
    6c24:      	movk	w26, #0x6c96, lsl #16
    6c28:      	add	w23, w23, w26
    6c2c:      	add	w22, w22, w25
    6c30:      	and	w28, w22, w24
    6c34:      	add	w24, w1, w24
    6c38:      	orr	w26, w28, w27
    6c3c:      	bic	w27, w22, w25
    6c40:      	add	w23, w23, w26
    6c44:      	mov	w26, #0x77ac            // =30636
    6c48:      	ror	w23, w23, #0xc
    6c4c:      	movk	w26, #0xfdbf, lsl #16
    6c50:      	add	w24, w24, w26
    6c54:      	add	w23, w23, w22
    6c58:      	and	w28, w23, w25
    6c5c:      	add	w25, w21, w25
    6c60:      	orr	w26, w28, w27
    6c64:      	bic	w27, w23, w22
    6c68:      	add	w24, w24, w26
    6c6c:      	mov	w26, #0x8134            // =33076
    6c70:      	ror	w24, w24, #0x1b
    6c74:      	movk	w26, #0xa59c, lsl #16
    6c78:      	add	w25, w25, w26
    6c7c:      	add	w24, w24, w23
    6c80:      	and	w28, w24, w22
    6c84:      	add	w22, w15, w22
    6c88:      	orr	w26, w28, w27
    6c8c:      	bic	w27, w24, w23
    6c90:      	add	w25, w25, w26
    6c94:      	mov	w26, #0x9be5            // =39909
    6c98:      	ror	w25, w25, #0x17
    6c9c:      	movk	w26, #0x4ac9, lsl #16
    6ca0:      	add	w22, w22, w26
    6ca4:      	add	w25, w25, w24
    6ca8:      	and	w28, w25, w23
    6cac:      	add	w23, w4, w23
    6cb0:      	orr	w26, w28, w27
    6cb4:      	bic	w27, w25, w24
    6cb8:      	add	w22, w22, w26
    6cbc:      	mov	w26, #0x568a            // =22154
    6cc0:      	ror	w22, w22, #0x12
    6cc4:      	movk	w26, #0xf66d, lsl #16
    6cc8:      	add	w23, w23, w26
    6ccc:      	add	w22, w22, w25
    6cd0:      	and	w28, w22, w24
    6cd4:      	add	w24, w7, w24
    6cd8:      	orr	w26, w28, w27
    6cdc:      	bic	w27, w22, w25
    6ce0:      	add	w23, w23, w26
    6ce4:      	mov	w26, #0xb2c1            // =45761
    6ce8:      	ror	w23, w23, #0xc
    6cec:      	movk	w26, #0xbf80, lsl #16
    6cf0:      	add	w24, w24, w26
    6cf4:      	add	w23, w23, w22
    6cf8:      	and	w28, w23, w25
    6cfc:      	add	w25, w12, w25
    6d00:      	orr	w26, w28, w27
    6d04:      	bic	w27, w23, w22
    6d08:      	add	w24, w24, w26
    6d0c:      	mov	w26, #0x5e4             // =1508
    6d10:      	ror	w24, w24, #0x1b
    6d14:      	movk	w26, #0x277d, lsl #16
    6d18:      	add	w25, w25, w26
    6d1c:      	add	w24, w24, w23
    6d20:      	and	w28, w24, w22
    6d24:      	add	w22, w5, w22
    6d28:      	orr	w26, w28, w27
    6d2c:      	bic	w27, w24, w23
    6d30:      	add	w25, w25, w26
    6d34:      	mov	w26, #0x8e1f            // =36383
    6d38:      	ror	w25, w25, #0x17
    6d3c:      	movk	w26, #0xea2c, lsl #16
    6d40:      	add	w22, w22, w26
    6d44:      	add	w25, w25, w24
    6d48:      	and	w28, w25, w23
    6d4c:      	add	w23, w20, w23
    6d50:      	orr	w26, w28, w27
    6d54:      	bic	w27, w25, w24
    6d58:      	add	w22, w22, w26
    6d5c:      	mov	w26, #0xa982            // =43394
    6d60:      	ror	w22, w22, #0x12
    6d64:      	movk	w26, #0xd58f, lsl #16
    6d68:      	add	w23, w23, w26
    6d6c:      	add	w22, w22, w25
    6d70:      	and	w28, w22, w24
    6d74:      	add	w24, w2, w24
    6d78:      	orr	w26, w28, w27
    6d7c:      	add	w23, w23, w26
    6d80:      	mov	w26, #0x1adb            // =6875
    6d84:      	ror	w23, w23, #0xc
    6d88:      	movk	w26, #0x366, lsl #16
    6d8c:      	add	w24, w24, w26
    6d90:      	add	w23, w23, w22
    6d94:      	eor	w27, w23, w22
    6d98:      	add	w22, w3, w22
    6d9c:      	eor	w26, w27, w25
    6da0:      	add	w25, w4, w25
    6da4:      	add	w24, w24, w26
    6da8:      	mov	w26, #0xe6ca            // =59082
    6dac:      	ror	w24, w24, #0x1c
    6db0:      	movk	w26, #0xd93b, lsl #16
    6db4:      	add	w25, w25, w26
    6db8:      	add	w24, w24, w23
    6dbc:      	eor	w26, w27, w24
    6dc0:      	eor	w27, w24, w23
    6dc4:      	add	w23, w21, w23
    6dc8:      	add	w25, w25, w26
    6dcc:      	mov	w26, #0x5f52            // =24402
    6dd0:      	ror	w25, w25, #0x15
    6dd4:      	movk	w26, #0xe758, lsl #16
    6dd8:      	add	w22, w22, w26
    6ddc:      	add	w25, w25, w24
    6de0:      	eor	w26, w27, w25
    6de4:      	eor	w27, w25, w24
    6de8:      	add	w24, w13, w24
    6dec:      	add	w22, w22, w26
    6df0:      	mov	w26, #0x3a76            // =14966
    6df4:      	ror	w22, w22, #0x10
    6df8:      	movk	w26, #0x20c2, lsl #16
    6dfc:      	add	w23, w23, w26
    6e00:      	add	w22, w22, w25
    6e04:      	eor	w26, w27, w22
    6e08:      	eor	w27, w22, w25
    6e0c:      	add	w25, w14, w25
    6e10:      	add	w23, w23, w26
    6e14:      	mov	w26, #0x2ce1            // =11489
    6e18:      	ror	w23, w23, #0x9
    6e1c:      	movk	w26, #0xc3f2, lsl #16
    6e20:      	add	w24, w24, w26
    6e24:      	add	w23, w23, w22
    6e28:      	eor	w26, w27, w23
    6e2c:      	eor	w27, w23, w22
    6e30:      	add	w22, w5, w22
    6e34:      	add	w24, w24, w26
    6e38:      	mov	w26, #0xb4d2            // =46290
    6e3c:      	ror	w24, w24, #0x1c
    6e40:      	movk	w26, #0xf47f, lsl #16
    6e44:      	add	w25, w25, w26
    6e48:      	add	w24, w24, w23
    6e4c:      	eor	w26, w27, w24
    6e50:      	eor	w27, w24, w23
    6e54:      	add	w23, w6, w23
    6e58:      	add	w25, w25, w26
    6e5c:      	mov	w26, #0xb612            // =46610
    6e60:      	ror	w25, w25, #0x15
    6e64:      	movk	w26, #0x4442, lsl #16
    6e68:      	add	w22, w22, w26
    6e6c:      	add	w25, w25, w24
    6e70:      	eor	w26, w27, w25
    6e74:      	eor	w27, w25, w24
    6e78:      	add	w24, w7, w24
    6e7c:      	add	w22, w22, w26
    6e80:      	mov	w26, #0x73eb            // =29675
    6e84:      	ror	w22, w22, #0x10
    6e88:      	movk	w26, #0xaabc, lsl #16
    6e8c:      	add	w23, w23, w26
    6e90:      	add	w22, w22, w25
    6e94:      	eor	w26, w27, w22
    6e98:      	eor	w27, w22, w25
    6e9c:      	add	w25, w17, w25
    6ea0:      	add	w23, w23, w26
    6ea4:      	mov	w26, #0x4453            // =17491
    6ea8:      	ror	w23, w23, #0x9
    6eac:      	movk	w26, #0xfcc2, lsl #16
    6eb0:      	add	w24, w24, w26
    6eb4:      	add	w23, w23, w22
    6eb8:      	eor	w26, w27, w23
    6ebc:      	eor	w27, w23, w22
    6ec0:      	add	w22, w15, w22
    6ec4:      	add	w24, w24, w26
    6ec8:      	mov	w26, #0x7006            // =28678
    6ecc:      	ror	w24, w24, #0x1c
    6ed0:      	movk	w26, #0x6665, lsl #16
    6ed4:      	add	w25, w25, w26
    6ed8:      	add	w24, w24, w23
    6edc:      	eor	w26, w27, w24
    6ee0:      	eor	w27, w24, w23
    6ee4:      	add	w23, w16, w23
    6ee8:      	add	w25, w25, w26
    6eec:      	mov	w26, #0xe7c3            // =59331
    6ef0:      	sub	w23, w23, #0xa4, lsl #12 // =0xa4000
    6ef4:      	ror	w25, w25, #0x15
    6ef8:      	movk	w26, #0x8e1b, lsl #16
    6efc:      	sub	w23, w23, #0x4d9
    6f00:      	add	w22, w22, w26
    6f04:      	add	w25, w25, w24
    6f08:      	eor	w26, w27, w25
    6f0c:      	add	w22, w22, w26
    6f10:      	eor	w26, w25, w24
    6f14:      	add	w24, w1, w24
    6f18:      	ror	w22, w22, #0x10
    6f1c:      	add	w22, w22, w25
    6f20:      	eor	w26, w26, w22
    6f24:      	eor	w27, w22, w25
    6f28:      	add	w25, w20, w25
    6f2c:      	add	w23, w23, w26
    6f30:      	mov	w26, #0x8079            // =32889
    6f34:      	ror	w23, w23, #0x9
    6f38:      	movk	w26, #0x867b, lsl #16
    6f3c:      	add	w24, w24, w26
    6f40:      	add	w23, w23, w22
    6f44:      	eor	w26, w27, w23
    6f48:      	eor	w27, w23, w22
    6f4c:      	add	w22, w19, w22
    6f50:      	add	w24, w24, w26
    6f54:      	mov	w26, #0x36bb            // =14011
    6f58:      	ror	w24, w24, #0x1c
    6f5c:      	movk	w26, #0x6ea3, lsl #16
    6f60:      	add	w25, w25, w26
    6f64:      	add	w24, w24, w23
    6f68:      	eor	w26, w27, w24
    6f6c:      	eor	w27, w24, w23
    6f70:      	add	w23, w12, w23
    6f74:      	add	w25, w25, w26
    6f78:      	mov	w26, #0xb282            // =45698
    6f7c:      	add	w17, w17, w24
    6f80:      	ror	w25, w25, #0x15
    6f84:      	movk	w26, #0xfe09, lsl #16
    6f88:      	add	w22, w22, w26
    6f8c:      	add	w25, w25, w24
    6f90:      	eor	w26, w27, w25
    6f94:      	eor	w27, w25, w24
    6f98:      	add	w5, w5, w25
    6f9c:      	add	w22, w22, w26
    6fa0:      	mov	w26, #0x7fda            // =32730
    6fa4:      	ror	w22, w22, #0x10
    6fa8:      	movk	w26, #0xa3e0, lsl #16
    6fac:      	add	w23, w23, w26
    6fb0:      	add	w22, w22, w25
    6fb4:      	eor	w26, w27, w22
    6fb8:      	add	w21, w21, w22
    6fbc:      	add	w23, w23, w26
    6fc0:      	mov	w26, #0xa208            // =41480
    6fc4:      	ror	w23, w23, #0x9
    6fc8:      	movk	w26, #0x4cf3, lsl #16
    6fcc:      	add	w17, w17, w26
    6fd0:      	add	w23, w23, w22
    6fd4:      	orn	w24, w23, w25
    6fd8:      	add	w2, w2, w23
    6fdc:      	eor	w24, w24, w22
    6fe0:      	add	w17, w17, w24
    6fe4:      	mov	w24, #0x37e             // =894
    6fe8:      	ror	w17, w17, #0x1a
    6fec:      	movk	w24, #0xf708, lsl #16
    6ff0:      	add	w5, w5, w24
    6ff4:      	add	w17, w17, w23
    6ff8:      	orn	w25, w17, w22
    6ffc:      	eor	w24, w25, w23
    7000:      	ldp	x26, x25, [sp, #0x10]
    7004:      	add	w5, w5, w24
    7008:      	mov	w24, #0xd143            // =53571
    700c:      	ror	w5, w5, #0x16
    7010:      	movk	w24, #0xbdfd, lsl #16
    7014:      	add	w21, w21, w24
    7018:      	add	w5, w5, w17
    701c:      	orn	w22, w5, w23
    7020:      	add	w15, w15, w5
    7024:      	eor	w22, w22, w17
    7028:      	add	w21, w21, w22
    702c:      	mov	w22, #0xc389            // =50057
    7030:      	ror	w21, w21, #0x11
    7034:      	movk	w22, #0x29b9, lsl #16
    7038:      	add	w2, w2, w22
    703c:      	add	w21, w21, w5
    7040:      	orn	w23, w21, w17
    7044:      	add	w17, w20, w17
    7048:      	add	w6, w6, w21
    704c:      	eor	w22, w23, w5
    7050:      	ldp	x24, x23, [sp, #0x20]
    7054:      	add	w2, w2, w22
    7058:      	mov	w22, #0x94a7            // =38055
    705c:      	ror	w2, w2, #0xb
    7060:      	movk	w22, #0xeb14, lsl #16
    7064:      	add	w17, w17, w22
    7068:      	add	w2, w2, w21
    706c:      	orn	w20, w2, w5
    7070:      	add	w13, w13, w2
    7074:      	eor	w20, w20, w21
    7078:      	add	w17, w17, w20
    707c:      	mov	w20, #0xa632            // =42546
    7080:      	ror	w17, w17, #0x1a
    7084:      	movk	w20, #0xd44d, lsl #16
    7088:      	add	w15, w15, w20
    708c:      	add	w17, w17, w2
    7090:      	orn	w5, w17, w21
    7094:      	ldp	x22, x21, [sp, #0x30]
    7098:      	eor	w5, w5, w2
    709c:      	add	w15, w15, w5
    70a0:      	mov	w5, #0x195e             // =6494
    70a4:      	ror	w15, w15, #0x16
    70a8:      	movk	w5, #0x5aa, lsl #16
    70ac:      	add	w5, w6, w5
    70b0:      	add	w15, w15, w17
    70b4:      	orn	w20, w15, w2
    70b8:      	eor	w6, w20, w17
    70bc:      	add	w5, w5, w6
    70c0:      	mov	w6, #0xa20a             // =41482
    70c4:      	ror	w5, w5, #0x11
    70c8:      	movk	w6, #0xda6c, lsl #16
    70cc:      	add	w13, w13, w6
    70d0:      	add	w5, w5, w15
    70d4:      	orn	w2, w5, w17
    70d8:      	add	w17, w4, w17
    70dc:      	add	w16, w16, w5
    70e0:      	eor	w2, w2, w15
    70e4:      	add	w13, w13, w2
    70e8:      	mov	w2, #0xac20             // =44064
    70ec:      	ror	w13, w13, #0xb
    70f0:      	movk	w2, #0xe65d, lsl #16
    70f4:      	add	w17, w17, w2
    70f8:      	add	w13, w13, w5
    70fc:      	orn	w4, w13, w15
    7100:      	add	w15, w19, w15
    7104:      	eor	w2, w4, w5
    7108:      	ldp	x20, x19, [sp, #0x40]
    710c:      	add	w17, w17, w2
    7110:      	mov	w2, #0x96e0             // =38624
    7114:      	ror	w17, w17, #0x1a
    7118:      	movk	w2, #0x1e82, lsl #16
    711c:      	add	w15, w15, w2
    7120:      	add	w17, w17, w13
    7124:      	orn	w4, w17, w5
    7128:      	add	w14, w14, w17
    712c:      	eor	w2, w4, w13
    7130:      	add	w15, w15, w2
    7134:      	mov	w2, #0x8374             // =33652
    7138:      	ror	w15, w15, #0x16
    713c:      	movk	w2, #0xc565, lsl #16
    7140:      	add	w16, w16, w2
    7144:      	add	w15, w15, w17
    7148:      	orn	w4, w15, w13
    714c:      	add	w13, w7, w13
    7150:      	eor	w2, w4, w17
    7154:      	add	w16, w16, w2
    7158:      	mov	w2, #0x564b             // =22091
    715c:      	ror	w16, w16, #0x11
    7160:      	movk	w2, #0xf3d1, lsl #16
    7164:      	add	w13, w13, w2
    7168:      	add	w16, w16, w15
    716c:      	orn	w4, w16, w17
    7170:      	add	w12, w12, w16
    7174:      	eor	w2, w4, w15
    7178:      	add	w13, w13, w2
    717c:      	mov	w2, #0xf2e5             // =62181
    7180:      	ror	w13, w13, #0xb
    7184:      	movk	w2, #0x4212, lsl #16
    7188:      	add	w14, w14, w2
    718c:      	add	w13, w13, w16
    7190:      	orn	w17, w13, w15
    7194:      	add	w15, w3, w15
    7198:      	eor	w17, w17, w16
    719c:      	add	w14, w14, w17
    71a0:      	mov	w17, #0xf723            // =63267
    71a4:      	ror	w14, w14, #0x1a
    71a8:      	movk	w17, #0xac6a, lsl #16
    71ac:      	add	w15, w15, w17
    71b0:      	add	w14, w14, w13
    71b4:      	orn	w2, w14, w16
    71b8:      	add	w11, w14, w11
    71bc:      	eor	w17, w2, w13
    71c0:      	add	w15, w15, w17
    71c4:      	mov	w17, #0xb7e7            // =47079
    71c8:      	ror	w15, w15, #0x16
    71cc:      	movk	w17, #0xfc63, lsl #16
    71d0:      	add	w12, w12, w17
    71d4:      	add	w15, w15, w14
    71d8:      	orn	w16, w15, w13
    71dc:      	add	w13, w1, w13
    71e0:      	add	w8, w15, w8
    71e4:      	eor	w16, w16, w14
    71e8:      	add	w12, w12, w16
    71ec:      	mov	w16, #0xc165            // =49509
    71f0:      	ror	w12, w12, #0x11
    71f4:      	movk	w16, #0x6450, lsl #16
    71f8:      	add	w13, w13, w16
    71fc:      	add	w12, w12, w15
    7200:      	orn	w17, w12, w14
    7204:      	add	w10, w12, w10
    7208:      	add	w9, w12, w9
    720c:      	eor	w16, w17, w15
    7210:      	stp	w9, w8, [x0, #0x8]
    7214:      	add	w13, w13, w16
    7218:      	ror	w13, w13, #0xb
    721c:      	add	w10, w10, w13
    7220:      	stp	w11, w10, [x0]
    7224:      	ldp	x28, x27, [sp], #0x50
    7228:      	ret
    722c:      	negs	w8, w0
    7230:      	and	w9, w0, #0xf
    7234:      	and	w8, w8, #0xf
    7238:      	csneg	w8, w9, w8, mi
    723c:      	sub	w8, w0, w8
    7240:      	add	w0, w8, #0x10
    7244:      	ret
    7248:      	sub	sp, sp, #0x180
    724c:      	stp	x29, x30, [sp, #0x120]
    7250:      	stp	x28, x27, [sp, #0x130]
    7254:      	stp	x26, x25, [sp, #0x140]
    7258:      	stp	x24, x23, [sp, #0x150]
    725c:      	stp	x22, x21, [sp, #0x160]
    7260:      	stp	x20, x19, [sp, #0x170]
    7264:      	add	x29, sp, #0x120
    7268:      	str	x3, [sp, #0x48]
    726c:      	mov	w19, w1
    7270:      	add	x1, sp, #0x60
    7274:      	str	x0, [sp, #0x18]
    7278:      	mrs	x8, TPIDR_EL0
    727c:      	mov	x0, x2
    7280:      	str	x8, [sp]
    7284:      	mov	x2, xzr
    7288:      	add	x24, sp, #0x60
    728c:      	ldr	x8, [x8, #0x28]
    7290:      	stur	x8, [x29, #-0x10]
    7294:      	bl	0x7664 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x21ac>
    7298:      	negs	w8, w19
    729c:      	and	w9, w19, #0xf
    72a0:      	str	x19, [sp, #0x8]
    72a4:      	and	w8, w8, #0xf
    72a8:      	csneg	w8, w9, w8, mi
    72ac:      	sub	w8, w19, w8
    72b0:      	add	w9, w8, #0x10
    72b4:      	cmp	w9, #0x1
    72b8:      	b.lt	0x762c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2174>
    72bc:      	ldr	w10, [sp, #0x100]
    72c0:      	ldr	w9, [sp, #0x104]
    72c4:      	add	w8, w8, #0xf
    72c8:      	lsr	w8, w8, #4
    72cc:      	mov	x20, xzr
    72d0:      	mov	x25, xzr
    72d4:      	stp	w9, w10, [sp, #0x40]
    72d8:      	ldr	w10, [sp, #0x108]
    72dc:      	ldr	w9, [sp, #0x10c]
    72e0:      	nop
    72e4:      	adr	x27, 0x3050
    72e8:      	nop
    72ec:      	adr	x23, 0x3450
    72f0:      	stp	w9, w10, [sp, #0x38]
    72f4:      	add	w8, w8, #0x1
    72f8:      	ldp	w10, w9, [sp, #0x60]
    72fc:      	nop
    7300:      	adr	x21, 0x3850
    7304:      	nop
    7308:      	adr	x19, 0x3c50
    730c:      	nop
    7310:      	adr	x26, 0x2050
    7314:      	stp	w9, w10, [sp, #0x30]
    7318:      	ldp	w10, w9, [sp, #0x68]
    731c:      	str	x8, [sp, #0x20]
    7320:      	stp	w9, w10, [sp, #0x28]
    7324:      	ldr	x9, [sp, #0x8]
    7328:      	sxtw	x3, w9
    732c:      	str	x3, [sp, #0x10]
    7330:      	add	x28, x20, #0x10
    7334:      	cmp	x28, x3
    7338:      	b.le	0x7398 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1ee0>
    733c:      	sub	x22, x3, x20
    7340:      	cbz	w22, 0x7360 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1ea8>
    7344:      	ldr	x8, [sp, #0x18]
    7348:      	add	x0, sp, #0x50
    734c:      	mov	x2, x22
    7350:      	mov	w3, #0x10               // =16
    7354:      	add	x1, x8, x20
    7358:      	bl	0xbab0 <__memcpy_chk@plt>
    735c:      	ldr	x3, [sp, #0x10]
    7360:      	cmp	x22, #0xf
    7364:      	b.gt	0x73a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1eec>
    7368:      	ldr	x9, [sp, #0x8]
    736c:      	add	x10, sp, #0x50
    7370:      	sub	w8, w9, w25, lsl #4
    7374:      	add	x0, x10, w8, sxtw
    7378:      	sub	w8, w20, w9
    737c:      	mov	w9, #0x10               // =16
    7380:      	add	w8, w8, #0xf
    7384:      	sub	w1, w9, w22
    7388:      	add	x2, x8, #0x1
    738c:      	bl	0xbac0 <memset@plt>
    7390:      	ldr	x3, [sp, #0x10]
    7394:      	b	0x73a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1eec>
    7398:      	ldr	x8, [sp, #0x18]
    739c:      	ldr	q0, [x8, x20]
    73a0:      	str	q0, [sp, #0x50]
    73a4:      	ldp	w11, w12, [sp, #0x58]
    73a8:      	ldp	w8, w10, [sp, #0x50]
    73ac:      	mov	x9, xzr
    73b0:      	rev	w15, w12
    73b4:      	ldr	w12, [sp, #0x44]
    73b8:      	rev	w11, w11
    73bc:      	rev	w8, w8
    73c0:      	rev	w10, w10
    73c4:      	eor	w13, w12, w8
    73c8:      	ldr	w8, [sp, #0x40]
    73cc:      	eor	w14, w8, w10
    73d0:      	ldp	w8, w10, [sp, #0x38]
    73d4:      	eor	w12, w10, w11
    73d8:      	eor	w8, w8, w15
    73dc:      	lsr	w10, w13, #24
    73e0:      	add	x15, x24, x9
    73e4:      	ubfx	w11, w14, #16, #8
    73e8:      	ubfx	w16, w12, #8, #8
    73ec:      	lsr	w17, w14, #24
    73f0:      	ubfx	w1, w12, #16, #8
    73f4:      	ldp	w0, w2, [x15, #0x90]
    73f8:      	ldr	w10, [x27, w10, uxtw #2]
    73fc:      	ldr	w11, [x23, w11, uxtw #2]
    7400:      	ldr	w16, [x21, w16, uxtw #2]
    7404:      	ldr	w17, [x27, w17, uxtw #2]
    7408:      	ldr	w1, [x23, w1, uxtw #2]
    740c:      	sub	x9, x9, #0x10
    7410:      	eor	w10, w10, w0
    7414:      	ubfx	w0, w8, #8, #8
    7418:      	eor	w11, w11, w16
    741c:      	eor	w10, w10, w11
    7420:      	eor	w17, w17, w2
    7424:      	lsr	w2, w12, #24
    7428:      	ldr	w11, [x21, w0, uxtw #2]
    742c:      	and	w16, w8, #0xff
    7430:      	and	w0, w13, #0xff
    7434:      	ldr	w16, [x19, w16, uxtw #2]
    7438:      	ldr	w0, [x19, w0, uxtw #2]
    743c:      	and	w12, w12, #0xff
    7440:      	eor	w11, w1, w11
    7444:      	ldr	w1, [x27, w2, uxtw #2]
    7448:      	ldr	w12, [x19, w12, uxtw #2]
    744c:      	ldp	w2, w15, [x15, #0x98]
    7450:      	eor	w17, w17, w11
    7454:      	eor	w11, w10, w16
    7458:      	cmn	w9, #0x90
    745c:      	eor	w10, w17, w0
    7460:      	ubfx	w17, w8, #16, #8
    7464:      	ubfx	w0, w13, #8, #8
    7468:      	eor	w16, w1, w2
    746c:      	lsr	w8, w8, #24
    7470:      	ubfx	w13, w13, #16, #8
    7474:      	ubfx	w1, w14, #8, #8
    7478:      	ldr	w17, [x23, w17, uxtw #2]
    747c:      	ldr	w0, [x21, w0, uxtw #2]
    7480:      	and	w14, w14, #0xff
    7484:      	ldr	w8, [x27, w8, uxtw #2]
    7488:      	ldr	w13, [x23, w13, uxtw #2]
    748c:      	ldr	w1, [x21, w1, uxtw #2]
    7490:      	eor	w17, w17, w0
    7494:      	ldr	w14, [x19, w14, uxtw #2]
    7498:      	eor	w8, w8, w15
    749c:      	eor	w15, w16, w17
    74a0:      	eor	w13, w13, w1
    74a4:      	eor	w15, w15, w14
    74a8:      	mov	w14, w10
    74ac:      	eor	w8, w8, w13
    74b0:      	mov	w13, w11
    74b4:      	eor	w8, w8, w12
    74b8:      	mov	w12, w15
    74bc:      	b.ne	0x73dc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1f24>
    74c0:      	ubfx	w9, w10, #16, #8
    74c4:      	ubfx	w12, w15, #16, #8
    74c8:      	lsr	w13, w11, #24
    74cc:      	ubfx	w14, w15, #8, #8
    74d0:      	lsr	w16, w10, #24
    74d4:      	ubfx	w0, w8, #8, #8
    74d8:      	ldr	w9, [x26, w9, uxtw #2]
    74dc:      	ldr	w12, [x26, w12, uxtw #2]
    74e0:      	ldr	w13, [x26, w13, uxtw #2]
    74e4:      	ldr	w16, [x26, w16, uxtw #2]
    74e8:      	ldr	w14, [x26, w14, uxtw #2]
    74ec:      	ldr	w0, [x26, w0, uxtw #2]
    74f0:      	lsl	w9, w9, #16
    74f4:      	lsl	w12, w12, #16
    74f8:      	and	w17, w8, #0xff
    74fc:      	ldr	w17, [x26, w17, uxtw #2]
    7500:      	add	x25, x25, #0x1
    7504:      	orr	w9, w9, w13, lsl #24
    7508:      	ubfx	w13, w8, #16, #8
    750c:      	orr	w12, w12, w16, lsl #24
    7510:      	and	w16, w11, #0xff
    7514:      	lsr	w8, w8, #24
    7518:      	orr	w14, w9, w14, lsl #8
    751c:      	lsr	w9, w15, #24
    7520:      	ldr	w13, [x26, w13, uxtw #2]
    7524:      	orr	w12, w12, w0, lsl #8
    7528:      	ubfx	w0, w11, #8, #8
    752c:      	ldr	w16, [x26, w16, uxtw #2]
    7530:      	ldr	w1, [x26, w9, uxtw #2]
    7534:      	lsl	w13, w13, #16
    7538:      	ubfx	w11, w11, #16, #8
    753c:      	ldr	w0, [x26, w0, uxtw #2]
    7540:      	orr	w14, w14, w17
    7544:      	orr	w12, w12, w16
    7548:      	orr	w13, w13, w1, lsl #24
    754c:      	and	w16, w10, #0xff
    7550:      	ldr	w17, [sp, #0x34]
    7554:      	ldr	w11, [x26, w11, uxtw #2]
    7558:      	ldr	w16, [x26, w16, uxtw #2]
    755c:      	ldr	x9, [sp, #0x48]
    7560:      	orr	w13, w13, w0, lsl #8
    7564:      	ubfx	w10, w10, #8, #8
    7568:      	eor	w14, w17, w14
    756c:      	ldr	w8, [x26, w8, uxtw #2]
    7570:      	lsl	w11, w11, #16
    7574:      	lsr	w17, w14, #24
    7578:      	orr	w13, w13, w16
    757c:      	ldr	w16, [sp, #0x2c]
    7580:      	add	x9, x9, x20
    7584:      	ldr	w10, [x26, w10, uxtw #2]
    7588:      	and	w15, w15, #0xff
    758c:      	ldr	w0, [sp, #0x30]
    7590:      	orr	w8, w11, w8, lsl #24
    7594:      	ldr	w15, [x26, w15, uxtw #2]
    7598:      	strb	w17, [x9]
    759c:      	lsr	w17, w14, #8
    75a0:      	eor	w13, w16, w13
    75a4:      	eor	w12, w0, w12
    75a8:      	orr	w8, w8, w10, lsl #8
    75ac:      	lsr	w10, w13, #24
    75b0:      	lsr	w1, w14, #16
    75b4:      	strb	w17, [x9, #0x2]
    75b8:      	lsr	w17, w12, #24
    75bc:      	lsr	w11, w12, #8
    75c0:      	strb	w14, [x9, #0x3]
    75c4:      	lsr	w14, w12, #16
    75c8:      	orr	w8, w8, w15
    75cc:      	strb	w12, [x9, #0x7]
    75d0:      	ldr	w12, [sp, #0x28]
    75d4:      	mov	x20, x28
    75d8:      	strb	w10, [x9, #0x8]
    75dc:      	lsr	w10, w13, #8
    75e0:      	eor	w8, w12, w8
    75e4:      	strb	w11, [x9, #0x6]
    75e8:      	lsr	w11, w13, #16
    75ec:      	strb	w10, [x9, #0xa]
    75f0:      	lsr	w10, w8, #24
    75f4:      	strb	w11, [x9, #0x9]
    75f8:      	lsr	w11, w8, #16
    75fc:      	strb	w10, [x9, #0xc]
    7600:      	lsr	w10, w8, #8
    7604:      	strb	w1, [x9, #0x1]
    7608:      	strb	w10, [x9, #0xe]
    760c:      	ldr	x10, [sp, #0x20]
    7610:      	strb	w17, [x9, #0x4]
    7614:      	cmp	x25, x10
    7618:      	strb	w14, [x9, #0x5]
    761c:      	strb	w13, [x9, #0xb]
    7620:      	strb	w11, [x9, #0xd]
    7624:      	strb	w8, [x9, #0xf]
    7628:      	b.ne	0x7330 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x1e78>
    762c:      	ldr	x8, [sp]
    7630:      	ldr	x8, [x8, #0x28]
    7634:      	ldur	x9, [x29, #-0x10]
    7638:      	cmp	x8, x9
    763c:      	b.ne	0x7660 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x21a8>
    7640:      	ldp	x20, x19, [sp, #0x170]
    7644:      	ldp	x22, x21, [sp, #0x160]
    7648:      	ldp	x24, x23, [sp, #0x150]
    764c:      	ldp	x26, x25, [sp, #0x140]
    7650:      	ldp	x28, x27, [sp, #0x130]
    7654:      	ldp	x29, x30, [sp, #0x120]
    7658:      	add	sp, sp, #0x180
    765c:      	ret
    7660:      	bl	0xb9e0 <__stack_chk_fail@plt>
    7664:      	ldr	w8, [x0]
    7668:      	mov	x9, xzr
    766c:      	nop
    7670:      	adr	x10, 0x1c10
    7674:      	rev	w8, w8
    7678:      	str	w8, [x1]
    767c:      	ldr	w8, [x0, #0x4]
    7680:      	rev	w8, w8
    7684:      	str	w8, [x1, #0x4]
    7688:      	ldr	w8, [x0, #0x8]
    768c:      	rev	w8, w8
    7690:      	str	w8, [x1, #0x8]
    7694:      	ldr	w8, [x0, #0xc]
    7698:      	rev	w11, w8
    769c:      	nop
    76a0:      	adr	x8, 0x2050
    76a4:      	str	w11, [x1, #0xc]
    76a8:      	b	0x76c8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2210>
    76ac:      	ldr	w12, [x1, x9, lsl #2]
    76b0:      	add	x13, x1, x9, lsl #2
    76b4:      	add	x9, x9, #0x1
    76b8:      	cmp	x9, #0x28
    76bc:      	eor	w11, w12, w11
    76c0:      	str	w11, [x13, #0x10]
    76c4:      	b.eq	0x771c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2264>
    76c8:      	add	x12, x9, #0x4
    76cc:      	tst	w12, #0x3
    76d0:      	b.ne	0x76ac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x21f4>
    76d4:      	ror	w11, w11, #0x18
    76d8:      	ubfx	x12, x12, #2, #30
    76dc:      	ubfx	w13, w11, #16, #8
    76e0:      	lsr	w14, w11, #24
    76e4:      	ubfx	w15, w11, #8, #8
    76e8:      	and	w11, w11, #0xff
    76ec:      	sub	w12, w12, #0x1
    76f0:      	ldr	w13, [x8, w13, uxtw #2]
    76f4:      	ldr	w14, [x8, w14, uxtw #2]
    76f8:      	ldr	w11, [x8, w11, uxtw #2]
    76fc:      	ldr	w12, [x10, w12, uxtw #2]
    7700:      	lsl	w13, w13, #16
    7704:      	orr	w13, w13, w14, lsl #24
    7708:      	ldr	w14, [x8, w15, uxtw #2]
    770c:      	orr	w13, w13, w14, lsl #8
    7710:      	orr	w11, w13, w11
    7714:      	eor	w11, w11, w12, lsl #24
    7718:      	b	0x76ac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x21f4>
    771c:      	cbz	x2, 0x78ac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x23f4>
    7720:      	nop
    7724:      	adr	x9, 0x1c50
    7728:      	add	x10, x1, #0xac
    772c:      	nop
    7730:      	adr	x11, 0x2450
    7734:      	add	x12, x2, #0x8
    7738:      	nop
    773c:      	adr	x13, 0x2850
    7740:      	mov	x14, #-0x4              // =-4
    7744:      	nop
    7748:      	adr	x15, 0x2c50
    774c:      	b	0x7880 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x23c8>
    7750:      	lsr	x17, x16, #22
    7754:      	ubfx	x0, x16, #16, #8
    7758:      	ubfx	x1, x16, #8, #8
    775c:      	and	x16, x16, #0xff
    7760:      	and	x17, x17, #0x3fc
    7764:      	ldr	w0, [x8, x0, lsl #2]
    7768:      	ldr	w1, [x8, x1, lsl #2]
    776c:      	ldr	w17, [x8, x17]
    7770:      	ldr	w16, [x8, x16, lsl #2]
    7774:      	ldr	w0, [x11, x0, lsl #2]
    7778:      	ldr	w1, [x13, x1, lsl #2]
    777c:      	ldr	w17, [x9, x17, lsl #2]
    7780:      	ldr	w16, [x15, x16, lsl #2]
    7784:      	eor	w0, w0, w1
    7788:      	eor	w17, w0, w17
    778c:      	eor	w16, w17, w16
    7790:      	stur	w16, [x12, #-0x8]
    7794:      	ldur	w16, [x10, #-0x8]
    7798:      	lsr	x17, x16, #22
    779c:      	ubfx	x0, x16, #16, #8
    77a0:      	ubfx	x1, x16, #8, #8
    77a4:      	and	x16, x16, #0xff
    77a8:      	and	x17, x17, #0x3fc
    77ac:      	ldr	w0, [x8, x0, lsl #2]
    77b0:      	ldr	w1, [x8, x1, lsl #2]
    77b4:      	ldr	w17, [x8, x17]
    77b8:      	ldr	w16, [x8, x16, lsl #2]
    77bc:      	ldr	w0, [x11, x0, lsl #2]
    77c0:      	ldr	w1, [x13, x1, lsl #2]
    77c4:      	ldr	w17, [x9, x17, lsl #2]
    77c8:      	ldr	w16, [x15, x16, lsl #2]
    77cc:      	eor	w0, w0, w1
    77d0:      	eor	w17, w0, w17
    77d4:      	eor	w16, w17, w16
    77d8:      	stur	w16, [x12, #-0x4]
    77dc:      	ldur	w16, [x10, #-0x4]
    77e0:      	lsr	x17, x16, #22
    77e4:      	ubfx	x0, x16, #16, #8
    77e8:      	ubfx	x1, x16, #8, #8
    77ec:      	and	x16, x16, #0xff
    77f0:      	and	x17, x17, #0x3fc
    77f4:      	ldr	w0, [x8, x0, lsl #2]
    77f8:      	ldr	w1, [x8, x1, lsl #2]
    77fc:      	ldr	w17, [x8, x17]
    7800:      	ldr	w16, [x8, x16, lsl #2]
    7804:      	ldr	w0, [x11, x0, lsl #2]
    7808:      	ldr	w1, [x13, x1, lsl #2]
    780c:      	ldr	w17, [x9, x17, lsl #2]
    7810:      	ldr	w16, [x15, x16, lsl #2]
    7814:      	eor	w0, w0, w1
    7818:      	eor	w17, w0, w17
    781c:      	eor	w16, w17, w16
    7820:      	str	w16, [x12]
    7824:      	ldr	w16, [x10]
    7828:      	lsr	x17, x16, #22
    782c:      	ubfx	x0, x16, #16, #8
    7830:      	ubfx	x1, x16, #8, #8
    7834:      	and	x16, x16, #0xff
    7838:      	and	x17, x17, #0x3fc
    783c:      	ldr	w0, [x8, x0, lsl #2]
    7840:      	ldr	w1, [x8, x1, lsl #2]
    7844:      	ldr	w17, [x8, x17]
    7848:      	ldr	w16, [x8, x16, lsl #2]
    784c:      	ldr	w0, [x11, x0, lsl #2]
    7850:      	ldr	w1, [x13, x1, lsl #2]
    7854:      	ldr	w17, [x9, x17, lsl #2]
    7858:      	ldr	w16, [x15, x16, lsl #2]
    785c:      	eor	w0, w0, w1
    7860:      	eor	w17, w0, w17
    7864:      	eor	w16, w17, w16
    7868:      	add	x14, x14, #0x4
    786c:      	sub	x10, x10, #0x10
    7870:      	str	w16, [x12, #0x4]
    7874:      	cmp	x14, #0x28
    7878:      	add	x12, x12, #0x10
    787c:      	b.hs	0x78ac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x23f4>
    7880:      	add	w17, w14, #0x3
    7884:      	ldur	w16, [x10, #-0xc]
    7888:      	cmp	w17, #0x27
    788c:      	b.lo	0x7750 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2298>
    7890:      	stur	w16, [x12, #-0x8]
    7894:      	ldur	w16, [x10, #-0x8]
    7898:      	stur	w16, [x12, #-0x4]
    789c:      	ldur	w16, [x10, #-0x4]
    78a0:      	str	w16, [x12]
    78a4:      	ldr	w16, [x10]
    78a8:      	b	0x7868 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x23b0>
    78ac:      	ret
    78b0:      	stp	x29, x30, [sp, #-0x40]!
    78b4:      	stp	x24, x23, [sp, #0x10]
    78b8:      	stp	x22, x21, [sp, #0x20]
    78bc:      	stp	x20, x19, [sp, #0x30]
    78c0:      	mov	x29, sp
    78c4:      	mov	x19, x8
    78c8:      	tbnz	w1, #0x1f, 0x790c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2454>
    78cc:      	mov	w9, #0xaaab             // =43691
    78d0:      	add	w8, w1, #0x2
    78d4:      	mov	w21, w1
    78d8:      	movk	w9, #0xaaaa, lsl #16
    78dc:      	mov	x20, x0
    78e0:      	cmp	w1, #0x10
    78e4:      	umull	x8, w8, w9
    78e8:      	lsr	x8, x8, #31
    78ec:      	and	x22, x8, #0x1fffffffc
    78f0:      	b.hs	0x7914 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x245c>
    78f4:      	lsl	w8, w22, #1
    78f8:      	mov	x23, x19
    78fc:      	strb	w8, [x23], #0x1
    7900:      	cbnz	w21, 0x7930 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2478>
    7904:      	strb	wzr, [x23, x22]
    7908:      	b	0x79fc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2544>
    790c:      	strh	wzr, [x19]
    7910:      	b	0x79fc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2544>
    7914:      	orr	x24, x22, #0xf
    7918:      	add	x0, x24, #0x1
    791c:      	bl	0xba00 <_Znwm@plt>
    7920:      	mov	x23, x0
    7924:      	add	x8, x24, #0x2
    7928:      	stp	x22, x0, [x19, #0x8]
    792c:      	str	x8, [x19]
    7930:      	mov	x0, x23
    7934:      	mov	w1, #0x3d               // =61
    7938:      	mov	x2, x22
    793c:      	bl	0xbac0 <memset@plt>
    7940:      	mov	x10, xzr
    7944:      	mov	w13, wzr
    7948:      	mov	w15, wzr
    794c:      	mov	x9, xzr
    7950:      	add	x11, x19, #0x1
    7954:      	mov	w12, w21
    7958:      	nop
    795c:      	adr	x8, 0x16b6
    7960:      	strb	wzr, [x23, x22]
    7964:      	b	0x7978 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x24c0>
    7968:      	add	w15, w15, #0x8
    796c:      	add	x10, x10, #0x1
    7970:      	cmp	x10, x12
    7974:      	b.eq	0x79cc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2514>
    7978:      	lsl	w13, w13, #8
    797c:      	ldrb	w14, [x20, x10]
    7980:      	cmn	w15, #0x2
    7984:      	orr	x13, x13, x14
    7988:      	b.lt	0x7968 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x24b0>
    798c:      	add	w15, w15, #0xe
    7990:      	sub	w16, w15, #0xc
    7994:      	ldrb	w17, [x19]
    7998:      	ldr	x0, [x19, #0x10]
    799c:      	lsr	x16, x13, x16
    79a0:      	sub	w15, w15, #0x6
    79a4:      	tst	w17, #0x1
    79a8:      	and	x16, x16, #0x3f
    79ac:      	csel	x17, x11, x0, eq
    79b0:      	cmp	w15, #0xb
    79b4:      	ldrb	w16, [x8, x16]
    79b8:      	strb	w16, [x17, x9]
    79bc:      	add	x9, x9, #0x1
    79c0:      	b.hi	0x7990 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x24d8>
    79c4:      	sub	w15, w15, #0x6
    79c8:      	b	0x796c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x24b4>
    79cc:      	cmp	w15, #0x0
    79d0:      	b.le	0x79fc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2544>
    79d4:      	mov	w10, #0x6               // =6
    79d8:      	ldrb	w11, [x19]
    79dc:      	ldr	x12, [x19, #0x10]
    79e0:      	sub	x10, x10, w15, uxtw
    79e4:      	tst	w11, #0x1
    79e8:      	lsl	x10, x14, x10
    79ec:      	and	x10, x10, #0x3f
    79f0:      	ldrb	w8, [x8, x10]
    79f4:      	csinc	x10, x12, x19, ne
    79f8:      	strb	w8, [x10, x9]
    79fc:      	ldp	x20, x19, [sp, #0x30]
    7a00:      	ldp	x22, x21, [sp, #0x20]
    7a04:      	ldp	x24, x23, [sp, #0x10]
    7a08:      	ldp	x29, x30, [sp], #0x40
    7a0c:      	ret
    7a10:      	sub	sp, sp, #0x80
    7a14:      	stp	x29, x30, [sp, #0x20]
    7a18:      	str	x27, [sp, #0x30]
    7a1c:      	stp	x26, x25, [sp, #0x40]
    7a20:      	stp	x24, x23, [sp, #0x50]
    7a24:      	stp	x22, x21, [sp, #0x60]
    7a28:      	stp	x20, x19, [sp, #0x70]
    7a2c:      	add	x29, sp, #0x20
    7a30:      	mrs	x20, TPIDR_EL0
    7a34:      	mov	x19, x8
    7a38:      	ldr	x8, [x20, #0x28]
    7a3c:      	stur	x8, [x29, #-0x8]
    7a40:      	ldrb	w8, [x0]
    7a44:      	ldp	x9, x11, [x0, #0x8]
    7a48:      	stp	xzr, xzr, [sp]
    7a4c:      	lsr	x10, x8, #1
    7a50:      	tst	w8, #0x1
    7a54:      	str	xzr, [sp, #0x10]
    7a58:      	csinc	x22, x11, x0, ne
    7a5c:      	csel	x21, x10, x9, eq
    7a60:      	cbz	x21, 0x7af0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2638>
    7a64:      	mov	x25, #0x3e00            // =15872
    7a68:      	mov	w8, wzr
    7a6c:      	mov	w23, wzr
    7a70:      	movk	x25, #0x1, lsl #32
    7a74:      	mov	w24, #0x1               // =1
    7a78:      	nop
    7a7c:      	adr	x26, 0x4050
    7a80:      	movk	x25, #0x2000, lsl #48
    7a84:      	b	0x7a98 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x25e0>
    7a88:      	add	w8, w8, #0x6
    7a8c:      	subs	x21, x21, #0x1
    7a90:      	add	x22, x22, #0x1
    7a94:      	b.eq	0x7af0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2638>
    7a98:      	ldrb	w9, [x22]
    7a9c:      	and	x10, x9, #0xff
    7aa0:      	and	w11, w9, #0xff
    7aa4:      	lsl	x10, x24, x10
    7aa8:      	cmp	w11, #0x3d
    7aac:      	and	x10, x10, x25
    7ab0:      	ccmp	x10, #0x0, #0x4, ls
    7ab4:      	b.ne	0x7a8c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x25d4>
    7ab8:      	sxtb	w9, w9
    7abc:      	tbnz	w9, #0x1f, 0x7b30 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2678>
    7ac0:      	and	x9, x9, #0xff
    7ac4:      	ldrb	w9, [x26, x9]
    7ac8:      	cmp	w9, #0x3f
    7acc:      	b.hi	0x7b30 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2678>
    7ad0:      	orr	w23, w9, w23, lsl #6
    7ad4:      	subs	w27, w8, #0x2
    7ad8:      	b.lt	0x7a88 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x25d0>
    7adc:      	lsr	w1, w23, w27
    7ae0:      	mov	x0, sp
    7ae4:      	bl	0xbad0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt>
    7ae8:      	mov	w8, w27
    7aec:      	b	0x7a8c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x25d4>
    7af0:      	ldr	q0, [sp]
    7af4:      	ldr	x8, [sp, #0x10]
    7af8:      	str	q0, [x19]
    7afc:      	str	x8, [x19, #0x10]
    7b00:      	ldr	x8, [x20, #0x28]
    7b04:      	ldur	x9, [x29, #-0x8]
    7b08:      	cmp	x8, x9
    7b0c:      	b.ne	0x7b74 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x26bc>
    7b10:      	ldp	x20, x19, [sp, #0x70]
    7b14:      	ldr	x27, [sp, #0x30]
    7b18:      	ldp	x22, x21, [sp, #0x60]
    7b1c:      	ldp	x24, x23, [sp, #0x50]
    7b20:      	ldp	x26, x25, [sp, #0x40]
    7b24:      	ldp	x29, x30, [sp, #0x20]
    7b28:      	add	sp, sp, #0x80
    7b2c:      	ret
    7b30:      	ldrb	w8, [sp]
    7b34:      	strh	wzr, [x19]
    7b38:      	tbz	w8, #0x0, 0x7b00 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2648>
    7b3c:      	ldr	x0, [sp, #0x10]
    7b40:      	bl	0xba10 <_ZdlPv@plt>
    7b44:      	b	0x7b00 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2648>
    7b48:      	ldrb	w8, [sp]
    7b4c:      	mov	x19, x0
    7b50:      	tbz	w8, #0x0, 0x7b5c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x26a4>
    7b54:      	ldr	x0, [sp, #0x10]
    7b58:      	bl	0xba10 <_ZdlPv@plt>
    7b5c:      	ldr	x8, [x20, #0x28]
    7b60:      	ldur	x9, [x29, #-0x8]
    7b64:      	cmp	x8, x9
    7b68:      	b.ne	0x7b74 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x26bc>
    7b6c:      	mov	x0, x19
    7b70:      	bl	0x7cac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x27f4>
    7b74:      	bl	0xb9e0 <__stack_chk_fail@plt>
    7b78:      	paciasp
    7b7c:      	sub	sp, sp, #0x80
    7b80:      	stp	x29, x30, [sp, #0x50]
    7b84:      	stp	x22, x21, [sp, #0x60]
    7b88:      	stp	x20, x19, [sp, #0x70]
    7b8c:      	add	x29, sp, #0x50
    7b90:      	mov	x19, x1
    7b94:      	mov	x1, x0
    7b98:      	mov	x20, x2
    7b9c:      	mov	x0, x19
    7ba0:      	bl	0x7e24 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x296c>
    7ba4:      	mov	x0, x19
    7ba8:      	bl	0x7f48 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2a90>
    7bac:      	cbz	w0, 0x7c64 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x27ac>
    7bb0:      	mov	w21, #0x2               // =2
    7bb4:      	mov	w22, #0x6               // =6
    7bb8:      	b	0x7bc8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2710>
    7bbc:      	mov	x0, x19
    7bc0:      	bl	0x7f48 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2a90>
    7bc4:      	cbz	w0, 0x7c64 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x27ac>
    7bc8:      	tbnz	w0, #0x1f, 0x7c90 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x27d8>
    7bcc:      	sub	x2, x29, #0x8
    7bd0:      	mov	x0, x19
    7bd4:      	mov	w1, #-0x2               // =-2
    7bd8:      	bl	0x7ecc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2a14>
    7bdc:      	mov	x1, sp
    7be0:      	mov	x0, x19
    7be4:      	bl	0x7f5c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2aa4>
    7be8:      	cbnz	w0, 0x7c90 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x27d8>
    7bec:      	ldr	x8, [sp, #0x18]
    7bf0:      	cbz	x8, 0x7bbc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2704>
    7bf4:      	ldur	x9, [x29, #-0x8]
    7bf8:      	ldr	x10, [x20, #0x18]
    7bfc:      	mov	w0, #0x1                // =1
    7c00:      	ldr	x2, [x20]
    7c04:      	mov	x3, x20
    7c08:      	mov	x4, x19
    7c0c:      	cmp	x9, x10
    7c10:      	csel	w1, w22, w21, eq
    7c14:      	blr	x8
    7c18:      	cmp	w0, #0x8
    7c1c:      	b.ne	0x7c80 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x27c8>
    7c20:      	ldur	x8, [x29, #-0x8]
    7c24:      	ldr	x9, [x20, #0x18]
    7c28:      	cmp	x8, x9
    7c2c:      	b.ne	0x7bbc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2704>
    7c30:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    7c34:      	nop
    7c38:      	adr	x1, 0x1191
    7c3c:      	ldr	x19, [x19, #0xe28]
    7c40:      	adrp	x2, 0x1000
    7c44:      	add	x2, x2, #0x4e4
    7c48:      	adrp	x3, 0x1000
    7c4c:      	add	x3, x3, #0x741
    7c50:      	add	x0, x19, #0x130
    7c54:      	bl	0xbae0 <fprintf@plt>
    7c58:      	add	x0, x19, #0x130
    7c5c:      	bl	0xbaf0 <fflush@plt>
    7c60:      	bl	0xbb00 <abort@plt>
    7c64:      	mov	w0, #0x5                // =5
    7c68:      	ldp	x20, x19, [sp, #0x70]
    7c6c:      	ldp	x22, x21, [sp, #0x60]
    7c70:      	ldp	x29, x30, [sp, #0x50]
    7c74:      	add	sp, sp, #0x80
    7c78:      	autiasp
    7c7c:      	ret
    7c80:      	cmp	w0, #0x7
    7c84:      	b.ne	0x7c90 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x27d8>
    7c88:      	mov	x0, x19
    7c8c:      	bl	0x7f9c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2ae4>
    7c90:      	mov	w0, #0x2                // =2
    7c94:      	ldp	x20, x19, [sp, #0x70]
    7c98:      	ldp	x22, x21, [sp, #0x60]
    7c9c:      	ldp	x29, x30, [sp, #0x50]
    7ca0:      	add	sp, sp, #0x80
    7ca4:      	autiasp
    7ca8:      	ret
    7cac:      	paciasp
    7cb0:      	stp	x29, x30, [sp, #-0x20]!
    7cb4:      	stp	x28, x19, [sp, #0x10]
    7cb8:      	mov	x29, sp
    7cbc:      	sub	sp, sp, #0x480
    7cc0:      	mov	x19, x0
    7cc4:      	add	x0, sp, #0x270
    7cc8:      	bl	0xb8d0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6418>
    7ccc:      	ldr	x3, [x19, #0x10]
    7cd0:      	cbnz	x3, 0x7ce8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2830>
    7cd4:      	add	x0, sp, #0x270
    7cd8:      	mov	x1, sp
    7cdc:      	mov	x2, x19
    7ce0:      	bl	0x7b78 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x26c0>
    7ce4:      	b	0x7cfc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2844>
    7ce8:      	ldr	x4, [x19, #0x18]
    7cec:      	add	x0, sp, #0x270
    7cf0:      	mov	x1, sp
    7cf4:      	mov	x2, x19
    7cf8:      	bl	0x7d30 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2878>
    7cfc:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    7d00:      	nop
    7d04:      	adr	x1, 0x1191
    7d08:      	ldr	x19, [x19, #0xe28]
    7d0c:      	adrp	x2, 0x1000
    7d10:      	add	x2, x2, #0xa84
    7d14:      	adrp	x3, 0x1000
    7d18:      	add	x3, x3, #0x2c2
    7d1c:      	add	x0, x19, #0x130
    7d20:      	bl	0xbae0 <fprintf@plt>
    7d24:      	add	x0, x19, #0x130
    7d28:      	bl	0xbaf0 <fflush@plt>
    7d2c:      	bl	0xbb00 <abort@plt>
    7d30:      	paciasp
    7d34:      	sub	sp, sp, #0x80
    7d38:      	stp	x29, x30, [sp, #0x50]
    7d3c:      	stp	x22, x21, [sp, #0x60]
    7d40:      	stp	x20, x19, [sp, #0x70]
    7d44:      	add	x29, sp, #0x50
    7d48:      	mov	x21, x1
    7d4c:      	mov	x1, x0
    7d50:      	mov	x20, x4
    7d54:      	mov	x0, x21
    7d58:      	mov	x19, x3
    7d5c:      	mov	x22, x2
    7d60:      	bl	0x7e24 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x296c>
    7d64:      	mov	x0, x21
    7d68:      	bl	0x7f48 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2a90>
    7d6c:      	cmp	w0, #0x1
    7d70:      	b.ge	0x7db8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2900>
    7d74:      	ldr	x2, [x22]
    7d78:      	mov	w0, #0x1                // =1
    7d7c:      	mov	w1, #0x1a               // =26
    7d80:      	mov	x3, x22
    7d84:      	mov	x4, x21
    7d88:      	mov	x5, x20
    7d8c:      	blr	x19
    7d90:      	ldp	x20, x19, [sp, #0x70]
    7d94:      	ldp	x22, x21, [sp, #0x60]
    7d98:      	ldp	x29, x30, [sp, #0x50]
    7d9c:      	add	sp, sp, #0x80
    7da0:      	autiasp
    7da4:      	ret
    7da8:      	mov	x0, x21
    7dac:      	bl	0x7f48 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2a90>
    7db0:      	cmp	w0, #0x0
    7db4:      	b.le	0x7d74 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x28bc>
    7db8:      	add	x1, sp, #0x8
    7dbc:      	mov	x0, x21
    7dc0:      	bl	0x7f5c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2aa4>
    7dc4:      	cbnz	w0, 0x7d90 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x28d8>
    7dc8:      	ldr	x2, [x22]
    7dcc:      	mov	w0, #0x1                // =1
    7dd0:      	mov	w1, #0xa                // =10
    7dd4:      	mov	x3, x22
    7dd8:      	mov	x4, x21
    7ddc:      	mov	x5, x20
    7de0:      	blr	x19
    7de4:      	cbnz	w0, 0x7d90 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x28d8>
    7de8:      	ldr	x8, [sp, #0x20]
    7dec:      	cbz	x8, 0x7da8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x28f0>
    7df0:      	ldr	x2, [x22]
    7df4:      	mov	w0, #0x1                // =1
    7df8:      	mov	w1, #0xa                // =10
    7dfc:      	mov	x3, x22
    7e00:      	mov	x4, x21
    7e04:      	blr	x8
    7e08:      	cmp	w0, #0x8
    7e0c:      	b.eq	0x7da8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x28f0>
    7e10:      	cmp	w0, #0x7
    7e14:      	b.ne	0x7d90 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x28d8>
    7e18:      	mov	x0, x21
    7e1c:      	bl	0x7f9c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2ae4>
    7e20:      	b	0x7da8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x28f0>
    7e24:      	paciasp
    7e28:      	stp	x29, x30, [sp, #-0x20]!
    7e2c:      	stp	x20, x19, [sp, #0x10]
    7e30:      	mov	x29, sp
    7e34:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    7e38:      	add	x8, x8, #0xbb8
    7e3c:      	nop
    7e40:      	adr	x9, 0x13fb0
    7e44:      	mov	w2, #0x110              // =272
    7e48:      	mov	x20, x1
    7e4c:      	mov	x19, x0
    7e50:      	stp	x8, x9, [x0], #0x10
    7e54:      	bl	0xb9b0 <memcpy@plt>
    7e58:      	ldp	q1, q0, [x20, #0x130]
    7e5c:      	add	x8, x19, #0x220
    7e60:      	ldp	q3, q2, [x20, #0x110]
    7e64:      	mov	x0, x19
    7e68:      	mov	w1, wzr
    7e6c:      	stp	q1, q0, [x19, #0x140]
    7e70:      	stp	q3, q2, [x19, #0x120]
    7e74:      	ldp	q1, q0, [x20, #0x170]
    7e78:      	ldp	q3, q2, [x20, #0x150]
    7e7c:      	stp	q1, q0, [x19, #0x180]
    7e80:      	stp	q3, q2, [x19, #0x160]
    7e84:      	ldp	q1, q0, [x20, #0x1b0]
    7e88:      	ldp	q3, q2, [x20, #0x190]
    7e8c:      	stp	q1, q0, [x19, #0x1c0]
    7e90:      	stp	q3, q2, [x19, #0x1a0]
    7e94:      	movi	v2.2d, #0000000000000000
    7e98:      	ldp	q1, q0, [x20, #0x1f0]
    7e9c:      	ldp	q4, q3, [x20, #0x1d0]
    7ea0:      	stp	q1, q0, [x19, #0x200]
    7ea4:      	stp	q4, q3, [x19, #0x1e0]
    7ea8:      	stur	q2, [x8, #0x3b]
    7eac:      	stp	q2, q2, [x19, #0x220]
    7eb0:      	stp	q2, q2, [x19, #0x240]
    7eb4:      	bl	0x87ec <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3334>
    7eb8:      	mov	w0, wzr
    7ebc:      	ldp	x20, x19, [sp, #0x10]
    7ec0:      	ldp	x29, x30, [sp], #0x20
    7ec4:      	autiasp
    7ec8:      	ret
    7ecc:      	paciasp
    7ed0:      	stp	x29, x30, [sp, #-0x30]!
    7ed4:      	str	x21, [sp, #0x10]
    7ed8:      	stp	x20, x19, [sp, #0x20]
    7edc:      	mov	x29, sp
    7ee0:      	ldr	x8, [x0]
    7ee4:      	mov	x19, x2
    7ee8:      	mov	x20, x0
    7eec:      	mov	w21, w1
    7ef0:      	ldr	x8, [x8, #0x10]
    7ef4:      	blr	x8
    7ef8:      	tbz	w0, #0x0, 0x7f30 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2a78>
    7efc:      	ldr	x8, [x20]
    7f00:      	mov	x0, x20
    7f04:      	mov	w1, w21
    7f08:      	ldr	x8, [x8, #0x18]
    7f0c:      	blr	x8
    7f10:      	mov	x8, x0
    7f14:      	mov	w0, wzr
    7f18:      	str	x8, [x19]
    7f1c:      	ldp	x20, x19, [sp, #0x20]
    7f20:      	ldr	x21, [sp, #0x10]
    7f24:      	ldp	x29, x30, [sp], #0x30
    7f28:      	autiasp
    7f2c:      	ret
    7f30:      	mov	w0, #-0x198e            // =-6542
    7f34:      	ldp	x20, x19, [sp, #0x20]
    7f38:      	ldr	x21, [sp, #0x10]
    7f3c:      	ldp	x29, x30, [sp], #0x30
    7f40:      	autiasp
    7f44:      	ret
    7f48:      	bti	c
    7f4c:      	ldr	x8, [x0]
    7f50:      	mov	w1, #0x1                // =1
    7f54:      	ldr	x16, [x8, #0x40]
    7f58:      	br	x16
    7f5c:      	paciasp
    7f60:      	stp	x29, x30, [sp, #-0x20]!
    7f64:      	str	x19, [sp, #0x10]
    7f68:      	mov	x29, sp
    7f6c:      	ldr	x8, [x0]
    7f70:      	mov	x19, x1
    7f74:      	ldr	x8, [x8, #0x48]
    7f78:      	blr	x8
    7f7c:      	ldr	x8, [x19, #0x8]
    7f80:      	cmp	x8, #0x0
    7f84:      	mov	w8, #-0x1995            // =-6549
    7f88:      	csel	w0, w8, wzr, eq
    7f8c:      	ldr	x19, [sp, #0x10]
    7f90:      	ldp	x29, x30, [sp], #0x20
    7f94:      	autiasp
    7f98:      	ret
    7f9c:      	paciasp
    7fa0:      	stp	x29, x30, [sp, #-0x10]!
    7fa4:      	mov	x29, sp
    7fa8:      	ldr	x8, [x0]
    7fac:      	ldr	x8, [x8, #0x50]
    7fb0:      	blr	x8
    7fb4:      	mov	w0, #-0x198c            // =-6540
    7fb8:      	ldp	x29, x30, [sp], #0x10
    7fbc:      	autiasp
    7fc0:      	ret
    7fc4:      	paciasp
    7fc8:      	stp	x29, x30, [sp, #-0x60]!
    7fcc:      	str	x27, [sp, #0x10]
    7fd0:      	stp	x26, x25, [sp, #0x20]
    7fd4:      	stp	x24, x23, [sp, #0x30]
    7fd8:      	stp	x22, x21, [sp, #0x40]
    7fdc:      	stp	x20, x19, [sp, #0x50]
    7fe0:      	mov	x29, sp
    7fe4:      	mov	x23, x1
    7fe8:      	mov	x20, x3
    7fec:      	mov	x19, x2
    7ff0:      	ldr	w22, [x23], #0x4
    7ff4:      	mov	x21, x0
    7ff8:      	cmn	w22, #0x1
    7ffc:      	b.eq	0x8030 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2b78>
    8000:      	cbz	x22, 0x803c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2b84>
    8004:      	ldr	w8, [x23]
    8008:      	cbz	w8, 0x8048 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2b90>
    800c:      	mov	x25, x1
    8010:      	sub	x1, x23, x8
    8014:      	tbz	w4, #0x0, 0x8054 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2b9c>
    8018:      	ldr	x8, [x20]
    801c:      	cmp	x8, x1
    8020:      	b.eq	0x8064 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2bac>
    8024:      	adrp	x0, 0x1000
    8028:      	add	x0, x0, #0xaea
    802c:      	b	0x8134 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2c7c>
    8030:      	ldur	x22, [x1, #0x4]
    8034:      	add	x23, x1, #0xc
    8038:      	cbnz	x22, 0x8004 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2b4c>
    803c:      	adrp	x0, 0x1000
    8040:      	add	x0, x0, #0x3ba
    8044:      	b	0x8134 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2c7c>
    8048:      	adrp	x0, 0x1000
    804c:      	add	x0, x0, #0x5f1
    8050:      	b	0x8134 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2c7c>
    8054:      	mov	x0, x21
    8058:      	mov	x2, x20
    805c:      	bl	0x8154 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2c9c>
    8060:      	cbnz	x0, 0x8134 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2c7c>
    8064:      	ldrb	w3, [x20, #0x18]
    8068:      	add	x22, x23, x22
    806c:      	add	x8, x23, #0x4
    8070:      	add	x1, x29, #0x18
    8074:      	mov	x0, x21
    8078:      	mov	x2, x22
    807c:      	mov	x4, xzr
    8080:      	str	x8, [x29, #0x18]
    8084:      	bl	0x9fac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4af4>
    8088:      	ldrb	w8, [x20, #0x18]
    808c:      	mov	x23, x0
    8090:      	add	x1, x29, #0x18
    8094:      	mov	x0, x21
    8098:      	mov	x2, x22
    809c:      	mov	x4, xzr
    80a0:      	and	w3, w8, #0xf
    80a4:      	bl	0x9fac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4af4>
    80a8:      	ldrb	w8, [x20, #0x31]
    80ac:      	mov	x24, x0
    80b0:      	str	xzr, [x19, #0x28]
    80b4:      	cbz	w8, 0x8118 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2c60>
    80b8:      	add	x0, x29, #0x18
    80bc:      	mov	x1, x22
    80c0:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    80c4:      	ldrb	w8, [x20, #0x19]
    80c8:      	ldr	x27, [x29, #0x18]
    80cc:      	cmp	w8, #0xff
    80d0:      	add	x26, x27, x0
    80d4:      	b.eq	0x811c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2c64>
    80d8:      	add	x1, x29, #0x18
    80dc:      	and	w3, w8, #0xf
    80e0:      	mov	x0, x21
    80e4:      	mov	x2, x22
    80e8:      	mov	x4, xzr
    80ec:      	bl	0x9fac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4af4>
    80f0:      	cbz	x0, 0x811c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2c64>
    80f4:      	ldrb	w3, [x20, #0x19]
    80f8:      	add	x1, x29, #0x18
    80fc:      	mov	x0, x21
    8100:      	mov	x2, x22
    8104:      	mov	x4, xzr
    8108:      	str	x27, [x29, #0x18]
    810c:      	bl	0x9fac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4af4>
    8110:      	str	x0, [x19, #0x28]
    8114:      	b	0x811c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2c64>
    8118:      	ldr	x26, [x29, #0x18]
    811c:      	sub	x8, x22, x25
    8120:      	mov	x0, xzr
    8124:      	stp	x26, x23, [x19, #0x10]
    8128:      	stp	x25, x8, [x19]
    812c:      	add	x8, x24, x23
    8130:      	str	x8, [x19, #0x20]
    8134:      	ldp	x20, x19, [sp, #0x50]
    8138:      	ldr	x27, [sp, #0x10]
    813c:      	ldp	x22, x21, [sp, #0x40]
    8140:      	ldp	x24, x23, [sp, #0x30]
    8144:      	ldp	x26, x25, [sp, #0x20]
    8148:      	ldp	x29, x30, [sp], #0x60
    814c:      	autiasp
    8150:      	ret
    8154:      	paciasp
    8158:      	sub	sp, sp, #0x50
    815c:      	stp	x29, x30, [sp, #0x10]
    8160:      	stp	x24, x23, [sp, #0x20]
    8164:      	stp	x22, x21, [sp, #0x30]
    8168:      	stp	x20, x19, [sp, #0x40]
    816c:      	add	x29, sp, #0x10
    8170:      	movi	d0, #0x00ff000000ff00
    8174:      	sturh	wzr, [x2, #0x33]
    8178:      	mov	x8, x1
    817c:      	stp	xzr, xzr, [x2, #0x20]
    8180:      	mov	x19, x2
    8184:      	mov	x20, x1
    8188:      	strh	wzr, [x2, #0x30]
    818c:      	mov	x21, x0
    8190:      	str	x1, [x2]
    8194:      	str	s0, [x2, #0x18]
    8198:      	ldr	w9, [x8], #0x4
    819c:      	cmn	w9, #0x1
    81a0:      	b.eq	0x81c0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2d08>
    81a4:      	add	x22, x8, x9
    81a8:      	cbz	x9, 0x81d0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2d18>
    81ac:      	ldr	w9, [x8]
    81b0:      	cbz	w9, 0x81d8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2d20>
    81b4:      	adrp	x0, 0x1000
    81b8:      	add	x0, x0, #0xad7
    81bc:      	b	0x83cc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2f14>
    81c0:      	ldur	x9, [x20, #0x4]
    81c4:      	add	x8, x20, #0xc
    81c8:      	add	x22, x9, x8
    81cc:      	cbnz	x9, 0x81ac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2cf4>
    81d0:      	mov	x0, xzr
    81d4:      	b	0x83cc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2f14>
    81d8:      	ldrb	w24, [x8, #0x4]
    81dc:      	and	w9, w24, #0xfffffffd
    81e0:      	cmp	w9, #0x1
    81e4:      	b.ne	0x8290 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2dd8>
    81e8:      	add	x23, x8, #0x5
    81ec:      	mov	x8, x23
    81f0:      	ldrb	w9, [x8], #0x1
    81f4:      	cbnz	w9, 0x81f0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2d38>
    81f8:      	add	x0, sp, #0x8
    81fc:      	mov	x1, x22
    8200:      	str	x8, [sp, #0x8]
    8204:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    8208:      	ldr	x8, [sp, #0x8]
    820c:      	mov	x11, xzr
    8210:      	mov	x9, xzr
    8214:      	str	w0, [x19, #0x28]
    8218:      	mov	x10, x8
    821c:      	cmp	x10, x22
    8220:      	b.eq	0x83e8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2f30>
    8224:      	ldrb	w12, [x10], #0x1
    8228:      	add	x8, x8, #0x1
    822c:      	and	x13, x12, #0x7f
    8230:      	lsl	x13, x13, x11
    8234:      	add	x11, x11, #0x7
    8238:      	orr	x9, x13, x9
    823c:      	tbnz	w12, #0x7, 0x821c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2d64>
    8240:      	sub	w13, w11, #0x7
    8244:      	mov	x14, #-0x1              // =-1
    8248:      	str	x8, [sp, #0x8]
    824c:      	cmp	w13, #0x39
    8250:      	mov	w13, #0x3f              // =63
    8254:      	lsl	x11, x14, x11
    8258:      	ccmp	w12, w13, #0x0, lo
    825c:      	csel	w11, w11, wzr, hi
    8260:      	cmp	w24, #0x1
    8264:      	orr	w9, w9, w11
    8268:      	str	w9, [x19, #0x2c]
    826c:      	b.ne	0x829c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2de4>
    8270:      	add	x8, x8, #0x1
    8274:      	str	x8, [sp, #0x8]
    8278:      	ldrb	w0, [x10]
    827c:      	strb	w0, [x19, #0x32]
    8280:      	ldrb	w8, [x23]
    8284:      	cmp	w8, #0x7a
    8288:      	b.eq	0x82b8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2e00>
    828c:      	b	0x83b8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2f00>
    8290:      	adrp	x0, 0x1000
    8294:      	add	x0, x0, #0x2a8
    8298:      	b	0x83cc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2f14>
    829c:      	add	x0, sp, #0x8
    82a0:      	mov	x1, x22
    82a4:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    82a8:      	strb	w0, [x19, #0x32]
    82ac:      	ldrb	w8, [x23]
    82b0:      	cmp	w8, #0x7a
    82b4:      	b.ne	0x83b8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2f00>
    82b8:      	add	x0, sp, #0x8
    82bc:      	mov	x1, x22
    82c0:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    82c4:      	mov	w24, #0x1               // =1
    82c8:      	b	0x82d4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2e1c>
    82cc:      	strb	w24, [x19, #0x30]
    82d0:      	add	x23, x23, #0x1
    82d4:      	ldrb	w8, [x23]
    82d8:      	cmp	w8, #0x4f
    82dc:      	b.le	0x8310 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2e58>
    82e0:      	cmp	w8, #0x52
    82e4:      	b.gt	0x8340 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2e88>
    82e8:      	cmp	w8, #0x50
    82ec:      	b.eq	0x837c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2ec4>
    82f0:      	cmp	w8, #0x52
    82f4:      	b.ne	0x8374 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2ebc>
    82f8:      	ldr	x8, [sp, #0x8]
    82fc:      	add	x23, x23, #0x1
    8300:      	ldrb	w9, [x8], #0x1
    8304:      	str	x8, [sp, #0x8]
    8308:      	strb	w9, [x19, #0x18]
    830c:      	b	0x82d4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2e1c>
    8310:      	cmp	w8, #0x46
    8314:      	b.le	0x835c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2ea4>
    8318:      	cmp	w8, #0x47
    831c:      	b.eq	0x8370 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2eb8>
    8320:      	cmp	w8, #0x4c
    8324:      	b.ne	0x8374 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2ebc>
    8328:      	ldr	x8, [sp, #0x8]
    832c:      	add	x23, x23, #0x1
    8330:      	ldrb	w9, [x8], #0x1
    8334:      	str	x8, [sp, #0x8]
    8338:      	strb	w9, [x19, #0x19]
    833c:      	b	0x82d4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2e1c>
    8340:      	cmp	w8, #0x53
    8344:      	b.eq	0x82cc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2e14>
    8348:      	cmp	w8, #0x7a
    834c:      	b.ne	0x8374 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2ebc>
    8350:      	strb	w24, [x19, #0x31]
    8354:      	add	x23, x23, #0x1
    8358:      	b	0x82d4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2e1c>
    835c:      	cmp	w8, #0x42
    8360:      	b.ne	0x83b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2efc>
    8364:      	strb	w24, [x19, #0x33]
    8368:      	add	x23, x23, #0x1
    836c:      	b	0x82d4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2e1c>
    8370:      	strb	w24, [x19, #0x34]
    8374:      	add	x23, x23, #0x1
    8378:      	b	0x82d4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2e1c>
    837c:      	ldr	x8, [sp, #0x8]
    8380:      	add	x1, sp, #0x8
    8384:      	mov	x0, x21
    8388:      	mov	x2, x22
    838c:      	mov	x4, xzr
    8390:      	ldrb	w3, [x8], #0x1
    8394:      	str	x8, [sp, #0x8]
    8398:      	sub	w8, w8, w20
    839c:      	strb	w3, [x19, #0x1a]
    83a0:      	strb	w8, [x19, #0x1b]
    83a4:      	bl	0x9fac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4af4>
    83a8:      	str	x0, [x19, #0x20]
    83ac:      	add	x23, x23, #0x1
    83b0:      	b	0x82d4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2e1c>
    83b4:      	cbnz	w8, 0x8374 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2ebc>
    83b8:      	ldr	x8, [x19]
    83bc:      	ldr	x9, [sp, #0x8]
    83c0:      	mov	x0, xzr
    83c4:      	sub	x8, x22, x8
    83c8:      	stp	x8, x9, [x19, #0x8]
    83cc:      	ldp	x20, x19, [sp, #0x40]
    83d0:      	ldp	x22, x21, [sp, #0x30]
    83d4:      	ldp	x24, x23, [sp, #0x20]
    83d8:      	ldp	x29, x30, [sp, #0x10]
    83dc:      	add	sp, sp, #0x50
    83e0:      	autiasp
    83e4:      	ret
    83e8:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    83ec:      	nop
    83f0:      	adr	x1, 0x1191
    83f4:      	ldr	x19, [x19, #0xe28]
    83f8:      	adrp	x2, 0x1000
    83fc:      	add	x2, x2, #0x710
    8400:      	adrp	x3, 0x1000
    8404:      	add	x3, x3, #0x48b
    8408:      	add	x0, x19, #0x130
    840c:      	bl	0xbae0 <fprintf@plt>
    8410:      	add	x0, x19, #0x130
    8414:      	bl	0xbaf0 <fflush@plt>
    8418:      	bl	0xbb00 <abort@plt>
    841c:      	bti	c
    8420:      	ret
    8424:      	bti	c
    8428:      	ret
    842c:      	bti	c
    8430:      	cmn	w1, #0x3
    8434:      	b.ls	0x8440 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2f88>
    8438:      	mov	w0, #0x1                // =1
    843c:      	ret
    8440:      	cmp	w1, #0x5f
    8444:      	b.ls	0x8450 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2f98>
    8448:      	mov	w0, wzr
    844c:      	ret
    8450:      	cmp	w1, #0x22
    8454:      	b.ne	0x8460 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2fa8>
    8458:      	mov	w0, #0x1                // =1
    845c:      	ret
    8460:      	sub	w8, w1, #0x40
    8464:      	cmn	w8, #0x1f
    8468:      	cset	w0, lo
    846c:      	ret
    8470:      	bti	c
    8474:      	cmp	w1, #0x1d
    8478:      	b.le	0x8498 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2fe0>
    847c:      	cmp	w1, #0x1f
    8480:      	b.gt	0x84bc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3004>
    8484:      	cmp	w1, #0x1e
    8488:      	b.eq	0x84fc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3044>
    848c:      	cmp	w1, #0x1f
    8490:      	b.eq	0x84d8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3020>
    8494:      	b	0x84e4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x302c>
    8498:      	cmn	w1, #0x2
    849c:      	b.eq	0x84d8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3020>
    84a0:      	cmn	w1, #0x1
    84a4:      	b.eq	0x84cc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3014>
    84a8:      	cmp	w1, #0x1d
    84ac:      	b.ne	0x84e4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x302c>
    84b0:      	add	x8, x0, #0xf8
    84b4:      	ldr	x0, [x8]
    84b8:      	ret
    84bc:      	cmp	w1, #0x22
    84c0:      	b.eq	0x8508 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3050>
    84c4:      	cmp	w1, #0x20
    84c8:      	b.ne	0x84e4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x302c>
    84cc:      	add	x8, x0, #0x110
    84d0:      	ldr	x0, [x8]
    84d4:      	ret
    84d8:      	add	x8, x0, #0x108
    84dc:      	ldr	x0, [x8]
    84e0:      	ret
    84e4:      	cmp	w1, #0x1c
    84e8:      	b.hi	0x8514 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x305c>
    84ec:      	add	x8, x0, #0x10
    84f0:      	add	x8, x8, w1, uxtw #3
    84f4:      	ldr	x0, [x8]
    84f8:      	ret
    84fc:      	add	x8, x0, #0x100
    8500:      	ldr	x0, [x8]
    8504:      	ret
    8508:      	add	x8, x0, #0x118
    850c:      	ldr	x0, [x8]
    8510:      	ret
    8514:      	paciasp
    8518:      	stp	x29, x30, [sp, #-0x20]!
    851c:      	str	x19, [sp, #0x10]
    8520:      	mov	x29, sp
    8524:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    8528:      	nop
    852c:      	adr	x1, 0x1191
    8530:      	ldr	x19, [x19, #0xe28]
    8534:      	adrp	x2, 0x1000
    8538:      	add	x2, x2, #0x5dd
    853c:      	adrp	x3, 0x1000
    8540:      	add	x3, x3, #0x434
    8544:      	add	x0, x19, #0x130
    8548:      	bl	0xbae0 <fprintf@plt>
    854c:      	add	x0, x19, #0x130
    8550:      	bl	0xbaf0 <fflush@plt>
    8554:      	bl	0xbb00 <abort@plt>
    8558:      	bti	c
    855c:      	cmp	w1, #0x1d
    8560:      	b.le	0x8580 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x30c8>
    8564:      	cmp	w1, #0x1f
    8568:      	b.gt	0x85a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x30ec>
    856c:      	cmp	w1, #0x1e
    8570:      	b.eq	0x85e4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x312c>
    8574:      	cmp	w1, #0x1f
    8578:      	b.eq	0x85c0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3108>
    857c:      	b	0x85cc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3114>
    8580:      	cmn	w1, #0x2
    8584:      	b.eq	0x85c0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3108>
    8588:      	cmn	w1, #0x1
    858c:      	b.eq	0x85b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x30fc>
    8590:      	cmp	w1, #0x1d
    8594:      	b.ne	0x85cc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3114>
    8598:      	add	x8, x0, #0xf8
    859c:      	str	x2, [x8]
    85a0:      	ret
    85a4:      	cmp	w1, #0x22
    85a8:      	b.eq	0x85f0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3138>
    85ac:      	cmp	w1, #0x20
    85b0:      	b.ne	0x85cc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3114>
    85b4:      	add	x8, x0, #0x110
    85b8:      	str	x2, [x8]
    85bc:      	ret
    85c0:      	add	x8, x0, #0x108
    85c4:      	str	x2, [x8]
    85c8:      	ret
    85cc:      	cmp	w1, #0x1c
    85d0:      	b.hi	0x85fc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3144>
    85d4:      	add	x8, x0, #0x10
    85d8:      	add	x8, x8, w1, uxtw #3
    85dc:      	str	x2, [x8]
    85e0:      	ret
    85e4:      	add	x8, x0, #0x100
    85e8:      	str	x2, [x8]
    85ec:      	ret
    85f0:      	add	x8, x0, #0x118
    85f4:      	str	x2, [x8]
    85f8:      	ret
    85fc:      	paciasp
    8600:      	stp	x29, x30, [sp, #-0x20]!
    8604:      	str	x19, [sp, #0x10]
    8608:      	mov	x29, sp
    860c:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    8610:      	nop
    8614:      	adr	x1, 0x1191
    8618:      	ldr	x19, [x19, #0xe28]
    861c:      	adrp	x2, 0x1000
    8620:      	add	x2, x2, #0x80c
    8624:      	adrp	x3, 0x1000
    8628:      	add	x3, x3, #0x434
    862c:      	add	x0, x19, #0x130
    8630:      	bl	0xbae0 <fprintf@plt>
    8634:      	add	x0, x19, #0x130
    8638:      	bl	0xbaf0 <fflush@plt>
    863c:      	bl	0xbb00 <abort@plt>
    8640:      	bti	c
    8644:      	and	w8, w1, #0xffffffe0
    8648:      	cmp	w8, #0x40
    864c:      	cset	w0, eq
    8650:      	ret
    8654:      	bti	c
    8658:      	add	x8, x0, w1, sxtw #3
    865c:      	ldur	d0, [x8, #-0xe0]
    8660:      	ret
    8664:      	bti	c
    8668:      	add	x8, x0, w1, sxtw #3
    866c:      	stur	d0, [x8, #-0xe0]
    8670:      	ret
    8674:      	bti	c
    8678:      	ldrb	w8, [x0, #0x268]
    867c:      	cbz	w8, 0x8688 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x31d0>
    8680:      	mov	w0, wzr
    8684:      	ret
    8688:      	paciasp
    868c:      	stp	x29, x30, [sp, #-0x30]!
    8690:      	stp	x28, x21, [sp, #0x10]
    8694:      	stp	x20, x19, [sp, #0x20]
    8698:      	mov	x29, sp
    869c:      	sub	sp, sp, #0x210
    86a0:      	ldrb	w8, [x0, #0x26a]
    86a4:      	mov	x19, x0
    86a8:      	cbz	w8, 0x86e8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3230>
    86ac:      	mov	x0, sp
    86b0:      	mov	w1, wzr
    86b4:      	mov	w2, #0x210              // =528
    86b8:      	bl	0xbac0 <memset@plt>
    86bc:      	mov	x1, sp
    86c0:      	mov	x0, x19
    86c4:      	bl	0x8a78 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x35c0>
    86c8:      	cmp	w0, #0x1
    86cc:      	b.eq	0x8724 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x326c>
    86d0:      	add	sp, sp, #0x210
    86d4:      	ldp	x20, x19, [sp, #0x20]
    86d8:      	ldp	x28, x21, [sp, #0x10]
    86dc:      	ldp	x29, x30, [sp], #0x30
    86e0:      	autiasp
    86e4:      	ret
    86e8:      	ldp	x8, x20, [x19]
    86ec:      	mov	x0, x19
    86f0:      	mov	w21, w1
    86f4:      	mov	w1, #-0x1               // =-1
    86f8:      	ldr	x8, [x8, #0x18]
    86fc:      	blr	x8
    8700:      	ldr	x2, [x19, #0x258]
    8704:      	mov	x1, x0
    8708:      	add	x3, x19, #0x10
    870c:      	add	x4, x19, #0x269
    8710:      	and	w5, w21, #0x1
    8714:      	mov	x0, x20
    8718:      	bl	0x8b98 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x36e0>
    871c:      	cmp	w0, #0x1
    8720:      	b.ne	0x86d0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3218>
    8724:      	ldr	x8, [x19]
    8728:      	mov	w20, w0
    872c:      	mov	x0, x19
    8730:      	mov	w1, #0x1                // =1
    8734:      	ldr	x8, [x8, #0x68]
    8738:      	blr	x8
    873c:      	ldrb	w8, [x19, #0x268]
    8740:      	mov	w0, w20
    8744:      	cbz	w8, 0x86d0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3218>
    8748:      	mov	w0, wzr
    874c:      	add	sp, sp, #0x210
    8750:      	ldp	x20, x19, [sp, #0x20]
    8754:      	ldp	x28, x21, [sp, #0x10]
    8758:      	ldp	x29, x30, [sp], #0x30
    875c:      	autiasp
    8760:      	ret
    8764:      	bti	c
    8768:      	ldrb	w8, [x0, #0x268]
    876c:      	cbz	w8, 0x8784 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x32cc>
    8770:      	movi	v0.2d, #0000000000000000
    8774:      	str	xzr, [x1, #0x40]
    8778:      	stp	q0, q0, [x1]
    877c:      	stp	q0, q0, [x1, #0x20]
    8780:      	ret
    8784:      	ldr	q0, [x0, #0x220]
    8788:      	str	q0, [x1]
    878c:      	ldp	q2, q0, [x0, #0x240]
    8790:      	ldr	x8, [x0, #0x260]
    8794:      	ldr	q1, [x0, #0x230]
    8798:      	str	x8, [x1, #0x40]
    879c:      	stp	q2, q0, [x1, #0x20]
    87a0:      	str	q1, [x1, #0x10]
    87a4:      	ret
    87a8:      	bti	c
    87ac:      	add	x0, x0, #0x10
    87b0:      	b	0xb840 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6388>
    87b4:      	bti	c
    87b8:      	ldrb	w0, [x0, #0x269]
    87bc:      	ret
    87c0:      	paciasp
    87c4:      	stp	x29, x30, [sp, #-0x10]!
    87c8:      	mov	x29, sp
    87cc:      	ldr	x8, [x0]
    87d0:      	mov	w1, #-0x1               // =-1
    87d4:      	ldr	x8, [x8, #0x18]
    87d8:      	blr	x8
    87dc:      	mov	w0, wzr
    87e0:      	ldp	x29, x30, [sp], #0x10
    87e4:      	autiasp
    87e8:      	ret
    87ec:      	paciasp
    87f0:      	stp	x29, x30, [sp, #-0x30]!
    87f4:      	stp	x28, x21, [sp, #0x10]
    87f8:      	stp	x20, x19, [sp, #0x20]
    87fc:      	mov	x29, sp
    8800:      	sub	sp, sp, #0x6b0
    8804:      	ldr	x8, [x0]
    8808:      	strb	wzr, [x0, #0x26a]
    880c:      	mov	w20, w1
    8810:      	mov	w1, #-0x1               // =-1
    8814:      	mov	x19, x0
    8818:      	ldr	x8, [x8, #0x18]
    881c:      	blr	x8
    8820:      	cbz	x0, 0x8a30 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3578>
    8824:      	ldr	x8, [x19, #0x8]
    8828:      	and	x9, x20, #0x1
    882c:      	add	x10, sp, #0x68
    8830:      	sub	x20, x0, x9
    8834:      	nop
    8838:      	adr	x0, 0xb190 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5cd8>
    883c:      	add	x1, sp, #0x98
    8840:      	stp	x8, x10, [sp, #0x98]
    8844:      	str	x20, [sp, #0xa8]
    8848:      	bl	0xbb50 <dl_iterate_phdr@plt>
    884c:      	cbz	w0, 0x8870 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x33b8>
    8850:      	ldr	x8, [sp, #0x78]
    8854:      	cbz	x8, 0x8870 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x33b8>
    8858:      	add	x2, sp, #0x68
    885c:      	mov	x0, x19
    8860:      	mov	x1, x20
    8864:      	mov	w3, wzr
    8868:      	bl	0xaebc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5a04>
    886c:      	tbnz	w0, #0x0, 0x8a18 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3560>
    8870:      	nop
    8874:      	adr	x0, 0x13fb4
    8878:      	bl	0xbb60 <pthread_rwlock_rdlock@plt>
    887c:      	adrp	x8, 0x13000
    8880:      	adrp	x9, 0x13000
    8884:      	ldr	x8, [x8, #0xf98]
    8888:      	ldr	x9, [x9, #0xfa0]
    888c:      	b	0x8894 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x33dc>
    8890:      	add	x8, x8, #0x20
    8894:      	cmp	x8, x9
    8898:      	b.hs	0x8968 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x34b0>
    889c:      	ldr	x10, [x8, #0x8]
    88a0:      	cmp	x10, x20
    88a4:      	b.hi	0x8890 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x33d8>
    88a8:      	ldr	x10, [x8, #0x10]
    88ac:      	cmp	x10, x20
    88b0:      	b.ls	0x8890 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x33d8>
    88b4:      	ldr	x21, [x8, #0x18]
    88b8:      	nop
    88bc:      	adr	x0, 0x13fb4
    88c0:      	bl	0xbb20 <pthread_rwlock_unlock@plt>
    88c4:      	cbz	x21, 0x8974 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x34bc>
    88c8:      	ldr	x0, [x19, #0x8]
    88cc:      	add	x2, sp, #0x38
    88d0:      	mov	x3, sp
    88d4:      	mov	x1, x21
    88d8:      	mov	w4, wzr
    88dc:      	bl	0x7fc4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2b0c>
    88e0:      	cbnz	x0, 0x8974 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x34bc>
    88e4:      	add	x0, sp, #0x98
    88e8:      	mov	w1, wzr
    88ec:      	mov	w2, #0x618              // =1560
    88f0:      	bl	0xbac0 <memset@plt>
    88f4:      	ldr	x0, [x19, #0x8]
    88f8:      	add	x1, sp, #0x38
    88fc:      	mov	x2, sp
    8900:      	add	x5, sp, #0x98
    8904:      	mov	x3, x20
    8908:      	mov	w4, #0x4                // =4
    890c:      	bl	0x9020 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3b68>
    8910:      	tbz	w0, #0x0, 0x8974 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x34bc>
    8914:      	ldr	x8, [sp, #0x60]
    8918:      	ldr	x9, [sp, #0x20]
    891c:      	ldur	q0, [sp, #0x50]
    8920:      	str	xzr, [x19, #0x248]
    8924:      	str	x8, [x19, #0x230]
    8928:      	ldr	w8, [sp, #0xa8]
    892c:      	str	x9, [x19, #0x238]
    8930:      	mov	w9, #0x3000000          // =50331648
    8934:      	str	x8, [x19, #0x240]
    8938:      	str	w9, [x19, #0x250]
    893c:      	ldp	x8, x9, [sp, #0x38]
    8940:      	str	q0, [x19, #0x220]
    8944:      	str	xzr, [x19, #0x260]
    8948:      	str	x8, [x19, #0x258]
    894c:      	str	w9, [x19, #0x254]
    8950:      	add	sp, sp, #0x6b0
    8954:      	ldp	x20, x19, [sp, #0x20]
    8958:      	ldp	x28, x21, [sp, #0x10]
    895c:      	ldp	x29, x30, [sp], #0x30
    8960:      	autiasp
    8964:      	ret
    8968:      	nop
    896c:      	adr	x0, 0x13fb4
    8970:      	bl	0xbb20 <pthread_rwlock_unlock@plt>
    8974:      	ldr	x8, [x19]
    8978:      	mov	x0, x19
    897c:      	mov	w1, #-0x1               // =-1
    8980:      	ldr	x8, [x8, #0x18]
    8984:      	blr	x8
    8988:      	add	x8, sp, #0x38
    898c:      	mov	w9, #0x8                // =8
    8990:      	mov	x20, x0
    8994:      	stp	x8, x9, [sp, #0x98]
    8998:      	stp	x0, x9, [sp]
    899c:      	bl	0xbb70 <getpid@plt>
    89a0:      	mov	w1, w0
    89a4:      	add	x2, sp, #0x98
    89a8:      	mov	x4, sp
    89ac:      	mov	w0, #0x10e              // =270
    89b0:      	mov	w3, #0x1                // =1
    89b4:      	mov	w5, #0x1                // =1
    89b8:      	mov	w6, wzr
    89bc:      	mov	w21, #0x1               // =1
    89c0:      	bl	0xbb80 <syscall@plt>
    89c4:      	cmp	x0, #0x8
    89c8:      	b.ne	0x8a50 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3598>
    89cc:      	ldr	w8, [sp, #0x38]
    89d0:      	mov	w9, #0x1168             // =4456
    89d4:      	movk	w9, #0xd280, lsl #16
    89d8:      	cmp	w8, w9
    89dc:      	b.ne	0x8a50 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3598>
    89e0:      	ldr	w8, [sp, #0x3c]
    89e4:      	mov	w9, #0x1                // =1
    89e8:      	movk	w9, #0xd400, lsl #16
    89ec:      	cmp	w8, w9
    89f0:      	b.ne	0x8a50 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3598>
    89f4:      	movi	v0.2d, #0000000000000000
    89f8:      	add	x8, x20, #0x4
    89fc:      	str	xzr, [x19, #0x260]
    8a00:      	str	x8, [x19, #0x228]
    8a04:      	mov	w8, #0x1                // =1
    8a08:      	str	x20, [x19, #0x220]
    8a0c:      	strb	w8, [x19, #0x26a]
    8a10:      	stp	q0, q0, [x19, #0x240]
    8a14:      	str	q0, [x19, #0x230]
    8a18:      	add	sp, sp, #0x6b0
    8a1c:      	ldp	x20, x19, [sp, #0x20]
    8a20:      	ldp	x28, x21, [sp, #0x10]
    8a24:      	ldp	x29, x30, [sp], #0x30
    8a28:      	autiasp
    8a2c:      	ret
    8a30:      	mov	w8, #0x1                // =1
    8a34:      	strb	w8, [x19, #0x268]
    8a38:      	add	sp, sp, #0x6b0
    8a3c:      	ldp	x20, x19, [sp, #0x20]
    8a40:      	ldp	x28, x21, [sp, #0x10]
    8a44:      	ldp	x29, x30, [sp], #0x30
    8a48:      	autiasp
    8a4c:      	ret
    8a50:      	strb	w21, [x19, #0x268]
    8a54:      	add	sp, sp, #0x6b0
    8a58:      	ldp	x20, x19, [sp, #0x20]
    8a5c:      	ldp	x28, x21, [sp, #0x10]
    8a60:      	ldp	x29, x30, [sp], #0x30
    8a64:      	autiasp
    8a68:      	ret
    8a6c:      	bti	c
    8a70:      	mov	w0, w1
    8a74:      	b	0xb810 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6358>
    8a78:      	bti	c
    8a7c:      	ldr	x10, [x0, #0x108]
    8a80:      	mov	w9, #0x1                // =1
    8a84:      	ldr	x11, [x10, #0x138]
    8a88:      	str	x11, [x0, #0x10]
    8a8c:      	ldr	x11, [x10, #0x140]
    8a90:      	str	x11, [x0, #0x18]
    8a94:      	ldr	x11, [x10, #0x148]
    8a98:      	str	x11, [x0, #0x20]
    8a9c:      	ldr	x11, [x10, #0x150]
    8aa0:      	str	x11, [x0, #0x28]
    8aa4:      	ldr	x11, [x10, #0x158]
    8aa8:      	str	x11, [x0, #0x30]
    8aac:      	ldr	x11, [x10, #0x160]
    8ab0:      	str	x11, [x0, #0x38]
    8ab4:      	ldr	x11, [x10, #0x168]
    8ab8:      	str	x11, [x0, #0x40]
    8abc:      	ldr	x11, [x10, #0x170]
    8ac0:      	str	x11, [x0, #0x48]
    8ac4:      	ldr	x11, [x10, #0x178]
    8ac8:      	str	x11, [x0, #0x50]
    8acc:      	ldr	x11, [x10, #0x180]
    8ad0:      	str	x11, [x0, #0x58]
    8ad4:      	ldr	x11, [x10, #0x188]
    8ad8:      	str	x11, [x0, #0x60]
    8adc:      	ldr	x11, [x10, #0x190]
    8ae0:      	str	x11, [x0, #0x68]
    8ae4:      	ldr	x11, [x10, #0x198]
    8ae8:      	str	x11, [x0, #0x70]
    8aec:      	ldr	x11, [x10, #0x1a0]
    8af0:      	str	x11, [x0, #0x78]
    8af4:      	ldr	x11, [x10, #0x1a8]
    8af8:      	str	x11, [x0, #0x80]
    8afc:      	ldr	x11, [x10, #0x1b0]
    8b00:      	str	x11, [x0, #0x88]
    8b04:      	ldr	x11, [x10, #0x1b8]
    8b08:      	str	x11, [x0, #0x90]
    8b0c:      	ldr	x11, [x10, #0x1c0]
    8b10:      	str	x11, [x0, #0x98]
    8b14:      	ldr	x11, [x10, #0x1c8]
    8b18:      	str	x11, [x0, #0xa0]
    8b1c:      	ldr	x11, [x10, #0x1d0]
    8b20:      	str	x11, [x0, #0xa8]
    8b24:      	ldr	x11, [x10, #0x1d8]
    8b28:      	str	x11, [x0, #0xb0]
    8b2c:      	ldr	x11, [x10, #0x1e0]
    8b30:      	str	x11, [x0, #0xb8]
    8b34:      	ldr	x11, [x10, #0x1e8]
    8b38:      	str	x11, [x0, #0xc0]
    8b3c:      	ldr	x11, [x10, #0x1f0]
    8b40:      	str	x11, [x0, #0xc8]
    8b44:      	ldr	x11, [x10, #0x1f8]
    8b48:      	str	x11, [x0, #0xd0]
    8b4c:      	ldr	x11, [x10, #0x200]
    8b50:      	str	x11, [x0, #0xd8]
    8b54:      	ldr	x11, [x10, #0x208]
    8b58:      	str	x11, [x0, #0xe0]
    8b5c:      	ldr	x11, [x10, #0x210]
    8b60:      	str	x11, [x0, #0xe8]
    8b64:      	ldr	x11, [x10, #0x218]
    8b68:      	str	x11, [x0, #0xf0]
    8b6c:      	ldr	x11, [x10, #0x220]
    8b70:      	str	x11, [x0, #0xf8]
    8b74:      	ldr	x11, [x10, #0x228]
    8b78:      	str	x11, [x0, #0x100]
    8b7c:      	ldr	x11, [x10, #0x230]
    8b80:      	str	x11, [x0, #0x108]
    8b84:      	ldr	x10, [x10, #0x238]
    8b88:      	strb	w9, [x0, #0x269]
    8b8c:      	str	x10, [x0, #0x110]
    8b90:      	mov	w0, #0x1                // =1
    8b94:      	ret
    8b98:      	paciasp
    8b9c:      	stp	x29, x30, [sp, #-0x60]!
    8ba0:      	stp	x28, x27, [sp, #0x10]
    8ba4:      	stp	x26, x25, [sp, #0x20]
    8ba8:      	stp	x24, x23, [sp, #0x30]
    8bac:      	stp	x22, x21, [sp, #0x40]
    8bb0:      	stp	x20, x19, [sp, #0x50]
    8bb4:      	mov	x29, sp
    8bb8:      	sub	sp, sp, #0xb10
    8bbc:      	mov	x8, x2
    8bc0:      	mov	x21, x4
    8bc4:      	mov	x19, x3
    8bc8:      	mov	x22, x1
    8bcc:      	sub	x2, x29, #0x50
    8bd0:      	sub	x3, x29, #0x88
    8bd4:      	mov	x1, x8
    8bd8:      	mov	w4, wzr
    8bdc:      	mov	w23, w5
    8be0:      	mov	x20, x0
    8be4:      	bl	0x7fc4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2b0c>
    8be8:      	cbnz	x0, 0x8cc8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3810>
    8bec:      	add	x0, sp, #0x470
    8bf0:      	mov	w1, wzr
    8bf4:      	mov	w2, #0x618              // =1560
    8bf8:      	bl	0xbac0 <memset@plt>
    8bfc:      	sub	x1, x29, #0x50
    8c00:      	sub	x2, x29, #0x88
    8c04:      	add	x5, sp, #0x470
    8c08:      	mov	x0, x20
    8c0c:      	mov	x3, x22
    8c10:      	mov	w4, #0x4                // =4
    8c14:      	bl	0x9020 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3b68>
    8c18:      	tbz	w0, #0x0, 0x8cc8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3810>
    8c1c:      	add	x1, sp, #0x470
    8c20:      	mov	x0, x20
    8c24:      	mov	x2, x19
    8c28:      	add	x24, sp, #0x470
    8c2c:      	bl	0x9c68 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x47b0>
    8c30:      	mov	x22, x0
    8c34:      	tbz	w23, #0x0, 0x8c60 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x37a8>
    8c38:      	ldurb	w8, [x29, #-0x54]
    8c3c:      	cbz	w8, 0x8c60 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x37a8>
    8c40:      	ldr	x8, [x19, #0xf8]
    8c44:      	and	x8, x8, #0xfffffffffffffff0
    8c48:      	cmp	x8, x22
    8c4c:      	b.hs	0x8c60 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x37a8>
    8c50:      	stg	x8, [x8]
    8c54:      	add	x8, x8, #0x10
    8c58:      	cmp	x8, x22
    8c5c:      	b.lo	0x8c50 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3798>
    8c60:      	add	x0, sp, #0x260
    8c64:      	mov	x1, x19
    8c68:      	mov	w2, #0x210              // =528
    8c6c:      	add	x25, sp, #0x260
    8c70:      	bl	0xb9b0 <memcpy@plt>
    8c74:      	add	x9, x25, #0xf8
    8c78:      	add	x8, x25, #0xe8
    8c7c:      	add	x10, x19, #0xf8
    8c80:      	stp	x8, x9, [sp, #0x18]
    8c84:      	add	x9, x25, #0x100
    8c88:      	add	x8, x25, #0xf0
    8c8c:      	stp	x8, x9, [sp, #0x8]
    8c90:      	add	x9, x25, #0x108
    8c94:      	add	x8, x19, #0xe8
    8c98:      	stp	x8, x9, [sp, #0x40]
    8c9c:      	add	x8, x19, #0x100
    8ca0:      	mov	x26, xzr
    8ca4:      	mov	x23, xzr
    8ca8:      	add	x28, x19, #0x108
    8cac:      	stp	x10, x8, [sp, #0x30]
    8cb0:      	add	x8, x19, #0xf0
    8cb4:      	add	x24, x24, #0x18
    8cb8:      	add	x27, sp, #0x260
    8cbc:      	str	x22, [sp, #0x358]
    8cc0:      	str	x8, [sp, #0x28]
    8cc4:      	b	0x8d20 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3868>
    8cc8:      	mov	w0, #-0x1992            // =-6546
    8ccc:      	add	sp, sp, #0xb10
    8cd0:      	ldp	x20, x19, [sp, #0x50]
    8cd4:      	ldp	x22, x21, [sp, #0x40]
    8cd8:      	ldp	x24, x23, [sp, #0x30]
    8cdc:      	ldp	x26, x25, [sp, #0x20]
    8ce0:      	ldp	x28, x27, [sp, #0x10]
    8ce4:      	ldp	x29, x30, [sp], #0x60
    8ce8:      	autiasp
    8cec:      	ret
    8cf0:      	ldr	x8, [x24, #0x8]
    8cf4:      	mov	x9, #-0x4000000000      // =-274877906944
    8cf8:      	add	x8, x9, x8, lsl #32
    8cfc:      	add	x8, x19, x8, asr #29
    8d00:      	ldr	d0, [x8, #0x110]
    8d04:      	add	x8, x25, x26, lsl #3
    8d08:      	stur	d0, [x8, #-0xf0]
    8d0c:      	add	x26, x26, #0x1
    8d10:      	add	x24, x24, #0x10
    8d14:      	add	x27, x27, #0x8
    8d18:      	cmp	x26, #0x60
    8d1c:      	b.eq	0x8ee0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3a28>
    8d20:      	ldr	w8, [x24]
    8d24:      	cbz	w8, 0x8d5c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x38a4>
    8d28:      	and	w9, w26, #0x60
    8d2c:      	cmp	w9, #0x40
    8d30:      	b.ne	0x8d98 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x38e0>
    8d34:      	cmp	w8, #0x4
    8d38:      	b.gt	0x8dc0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3908>
    8d3c:      	movi	d0, #0000000000000000
    8d40:      	cmp	w8, #0x1
    8d44:      	b.eq	0x8d04 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x384c>
    8d48:      	cmp	w8, #0x2
    8d4c:      	b.ne	0x8f84 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3acc>
    8d50:      	ldr	x8, [x24, #0x8]
    8d54:      	ldr	d0, [x8, x22]
    8d58:      	b	0x8d04 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x384c>
    8d5c:      	ldurb	w8, [x29, #-0x56]
    8d60:      	cmp	x26, x8
    8d64:      	b.ne	0x8d0c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3854>
    8d68:      	cmp	w8, #0x1e
    8d6c:      	b.le	0x8e60 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x39a8>
    8d70:      	cmp	w8, #0x22
    8d74:      	mov	x9, x28
    8d78:      	b.eq	0x8e84 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x39cc>
    8d7c:      	ldr	x9, [sp, #0x38]
    8d80:      	cmp	w8, #0x20
    8d84:      	b.eq	0x8e84 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x39cc>
    8d88:      	ldr	x9, [sp, #0x30]
    8d8c:      	cmp	w8, #0x1f
    8d90:      	b.eq	0x8e84 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x39cc>
    8d94:      	b	0x8e78 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x39c0>
    8d98:      	ldurb	w8, [x29, #-0x56]
    8d9c:      	cmp	x26, x8
    8da0:      	b.ne	0x8dec <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3934>
    8da4:      	mov	x0, x20
    8da8:      	mov	x1, x19
    8dac:      	mov	x2, x22
    8db0:      	mov	x3, x24
    8db4:      	bl	0x9d9c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x48e4>
    8db8:      	mov	x23, x0
    8dbc:      	b	0x8d0c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3854>
    8dc0:      	cmp	w8, #0x5
    8dc4:      	b.eq	0x8cf0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3838>
    8dc8:      	cmp	w8, #0x6
    8dcc:      	b.ne	0x8f84 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3acc>
    8dd0:      	ldr	x0, [x24, #0x8]
    8dd4:      	mov	x1, x20
    8dd8:      	mov	x2, x19
    8ddc:      	mov	x3, x22
    8de0:      	bl	0xa500 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5048>
    8de4:      	ldr	d0, [x0]
    8de8:      	b	0x8d04 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x384c>
    8dec:      	cmp	x26, #0x22
    8df0:      	b.ne	0x8e14 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x395c>
    8df4:      	mov	x0, x20
    8df8:      	mov	x1, x19
    8dfc:      	mov	x2, x22
    8e00:      	mov	x3, x24
    8e04:      	bl	0x9d9c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x48e4>
    8e08:      	ldr	x8, [sp, #0x48]
    8e0c:      	str	x0, [x8]
    8e10:      	b	0x8d0c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3854>
    8e14:      	sub	w8, w26, #0x40
    8e18:      	cmn	w8, #0x20
    8e1c:      	b.hi	0x8f7c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3ac4>
    8e20:      	mov	x0, x20
    8e24:      	mov	x1, x19
    8e28:      	mov	x2, x22
    8e2c:      	mov	x3, x24
    8e30:      	bl	0x9d9c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x48e4>
    8e34:      	cmp	w26, #0x1e
    8e38:      	b.le	0x8e8c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x39d4>
    8e3c:      	cmp	w26, #0x1f
    8e40:      	b.eq	0x8ea8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x39f0>
    8e44:      	cmp	w26, #0x22
    8e48:      	b.eq	0x8eb4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x39fc>
    8e4c:      	cmp	w26, #0x20
    8e50:      	b.ne	0x8ecc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3a14>
    8e54:      	ldr	x8, [sp, #0x10]
    8e58:      	str	x0, [x8]
    8e5c:      	b	0x8d0c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3854>
    8e60:      	ldr	x9, [sp, #0x40]
    8e64:      	cmp	w8, #0x1d
    8e68:      	b.eq	0x8e84 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x39cc>
    8e6c:      	ldr	x9, [sp, #0x28]
    8e70:      	cmp	w8, #0x1e
    8e74:      	b.eq	0x8e84 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x39cc>
    8e78:      	cmp	w8, #0x1c
    8e7c:      	b.hi	0x8fb8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3b00>
    8e80:      	add	x9, x19, x8, lsl #3
    8e84:      	ldr	x23, [x9]
    8e88:      	b	0x8d0c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3854>
    8e8c:      	cmp	w26, #0x1d
    8e90:      	b.eq	0x8ec0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3a08>
    8e94:      	cmp	w26, #0x1e
    8e98:      	b.ne	0x8ecc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3a14>
    8e9c:      	ldr	x8, [sp, #0x8]
    8ea0:      	str	x0, [x8]
    8ea4:      	b	0x8d0c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3854>
    8ea8:      	ldr	x8, [sp, #0x20]
    8eac:      	str	x0, [x8]
    8eb0:      	b	0x8d0c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3854>
    8eb4:      	ldr	x8, [sp, #0x48]
    8eb8:      	str	x0, [x8]
    8ebc:      	b	0x8d0c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3854>
    8ec0:      	ldr	x8, [sp, #0x18]
    8ec4:      	str	x0, [x8]
    8ec8:      	b	0x8d0c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3854>
    8ecc:      	cmp	x26, #0x1d
    8ed0:      	mov	x8, x27
    8ed4:      	b.hs	0x8fec <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3b34>
    8ed8:      	str	x0, [x8]
    8edc:      	b	0x8d0c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3854>
    8ee0:      	ldurb	w8, [x29, #-0x58]
    8ee4:      	add	x0, sp, #0x50
    8ee8:      	mov	x1, x19
    8eec:      	mov	w2, #0x210              // =528
    8ef0:      	strb	w8, [x21]
    8ef4:      	bl	0xb9b0 <memcpy@plt>
    8ef8:      	add	x8, sp, #0x470
    8efc:      	add	x8, x8, #0x238
    8f00:      	ldr	q0, [x8]
    8f04:      	stur	q0, [x29, #-0x20]
    8f08:      	ldur	w8, [x29, #-0x20]
    8f0c:      	cbz	w8, 0x8f2c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3a74>
    8f10:      	add	x1, sp, #0x50
    8f14:      	sub	x3, x29, #0x20
    8f18:      	mov	x0, x20
    8f1c:      	mov	x2, x22
    8f20:      	bl	0x9d9c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x48e4>
    8f24:      	tbnz	w0, #0x0, 0x8f34 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3a7c>
    8f28:      	b	0x8f60 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3aa8>
    8f2c:      	ldur	x0, [x29, #-0x18]
    8f30:      	tbz	w0, #0x0, 0x8f60 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3aa8>
    8f34:      	cbz	x23, 0x8f60 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3aa8>
    8f38:      	ldurb	w8, [x29, #-0x55]
    8f3c:      	cbz	w8, 0x8f50 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3a98>
    8f40:      	mov	x17, x23
    8f44:      	mov	x16, x22
    8f48:      	autib1716
    8f4c:      	b	0x8f5c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3aa4>
    8f50:      	mov	x17, x23
    8f54:      	mov	x16, x22
    8f58:      	autia1716
    8f5c:      	mov	x23, x17
    8f60:      	add	x1, sp, #0x260
    8f64:      	mov	x0, x19
    8f68:      	mov	w2, #0x210              // =528
    8f6c:      	str	x23, [sp, #0x360]
    8f70:      	bl	0xb9b0 <memcpy@plt>
    8f74:      	mov	w0, #0x1                // =1
    8f78:      	b	0x8ccc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3814>
    8f7c:      	mov	w0, #-0x198e            // =-6542
    8f80:      	b	0x8ccc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3814>
    8f84:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    8f88:      	nop
    8f8c:      	adr	x1, 0x1191
    8f90:      	ldr	x19, [x19, #0xe28]
    8f94:      	adrp	x2, 0x1000
    8f98:      	add	x2, x2, #0x1dd
    8f9c:      	adrp	x3, 0x1000
    8fa0:      	add	x3, x3, #0x50f
    8fa4:      	add	x0, x19, #0x130
    8fa8:      	bl	0xbae0 <fprintf@plt>
    8fac:      	add	x0, x19, #0x130
    8fb0:      	bl	0xbaf0 <fflush@plt>
    8fb4:      	bl	0xbb00 <abort@plt>
    8fb8:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    8fbc:      	nop
    8fc0:      	adr	x1, 0x1191
    8fc4:      	ldr	x19, [x19, #0xe28]
    8fc8:      	adrp	x2, 0x1000
    8fcc:      	add	x2, x2, #0x5dd
    8fd0:      	adrp	x3, 0x1000
    8fd4:      	add	x3, x3, #0x434
    8fd8:      	add	x0, x19, #0x130
    8fdc:      	bl	0xbae0 <fprintf@plt>
    8fe0:      	add	x0, x19, #0x130
    8fe4:      	bl	0xbaf0 <fflush@plt>
    8fe8:      	bl	0xbb00 <abort@plt>
    8fec:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    8ff0:      	nop
    8ff4:      	adr	x1, 0x1191
    8ff8:      	ldr	x19, [x19, #0xe28]
    8ffc:      	adrp	x2, 0x1000
    9000:      	add	x2, x2, #0x80c
    9004:      	adrp	x3, 0x1000
    9008:      	add	x3, x3, #0x434
    900c:      	add	x0, x19, #0x130
    9010:      	bl	0xbae0 <fprintf@plt>
    9014:      	add	x0, x19, #0x130
    9018:      	bl	0xbaf0 <fflush@plt>
    901c:      	bl	0xbb00 <abort@plt>
    9020:      	paciasp
    9024:      	stp	x29, x30, [sp, #-0x60]!
    9028:      	stp	x28, x27, [sp, #0x10]
    902c:      	stp	x26, x25, [sp, #0x20]
    9030:      	stp	x24, x23, [sp, #0x30]
    9034:      	stp	x22, x21, [sp, #0x40]
    9038:      	stp	x20, x19, [sp, #0x50]
    903c:      	mov	x29, sp
    9040:      	sub	sp, sp, #0x680
    9044:      	ldp	x10, x8, [x2, #0x8]
    9048:      	mov	x19, sp
    904c:      	ldr	x9, [x2]
    9050:      	ldp	x11, x12, [x1, #0x10]
    9054:      	mov	x20, x5
    9058:      	mov	w28, w4
    905c:      	mov	x22, x2
    9060:      	add	x9, x10, x9
    9064:      	mov	x27, xzr
    9068:      	nop
    906c:      	adr	x23, 0x40d0
    9070:      	stp	x8, x9, [x29, #-0x38]
    9074:      	mov	x8, #-0x1               // =-1
    9078:      	ldp	x9, x10, [x1]
    907c:      	stp	x8, x11, [x29, #-0x28]
    9080:      	stp	x0, xzr, [x19, #0x18]
    9084:      	add	x8, x10, x9
    9088:      	sub	x9, x3, x12
    908c:      	stp	x8, x9, [x29, #-0x18]
    9090:      	add	x8, x19, #0x28
    9094:      	add	x9, x5, #0x238
    9098:      	add	x8, x8, #0x238
    909c:      	stp	x8, x9, [x19, #0x8]
    90a0:      	b	0x90b0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bf8>
    90a4:      	add	x27, x27, #0x18
    90a8:      	cmp	x27, #0x30
    90ac:      	b.eq	0x99dc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4524>
    90b0:      	sub	x8, x29, #0x38
    90b4:      	add	x8, x8, x27
    90b8:      	ldp	x9, x24, [x8]
    90bc:      	ldr	x21, [x8, #0x10]
    90c0:      	cmp	x9, x24
    90c4:      	stur	x9, [x29, #-0x40]
    90c8:      	ccmp	x21, #0x0, #0x4, lo
    90cc:      	b.eq	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    90d0:      	mov	x25, xzr
    90d4:      	mov	x8, x9
    90d8:      	ldrb	w10, [x8], #0x1
    90dc:      	stur	x8, [x29, #-0x40]
    90e0:      	cmp	w10, #0x2f
    90e4:      	b.hi	0x96d4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x421c>
    90e8:      	adr	x11, 0x90f8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3c40>
    90ec:      	ldrh	w12, [x23, x10, lsl #1]
    90f0:      	add	x11, x11, x12, lsl #2
    90f4:      	br	x11
    90f8:      	bti	j
    90fc:      	ldrb	w3, [x22, #0x18]
    9100:      	ldr	x0, [x19, #0x18]
    9104:      	sub	x1, x29, #0x40
    9108:      	mov	x2, x24
    910c:      	mov	x4, xzr
    9110:      	bl	0x9fac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4af4>
    9114:      	mov	x25, x0
    9118:      	ldur	x9, [x29, #-0x40]
    911c:      	cmp	x9, x24
    9120:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    9124:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    9128:      	bti	j
    912c:      	sub	x0, x29, #0x40
    9130:      	mov	x1, x24
    9134:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    9138:      	ldur	x10, [x29, #-0x40]
    913c:      	mov	x9, xzr
    9140:      	mov	x8, xzr
    9144:      	mov	x12, x10
    9148:      	cmp	x12, x24
    914c:      	b.eq	0x9bcc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4714>
    9150:      	ldrb	w11, [x12], #0x1
    9154:      	add	x10, x10, #0x1
    9158:      	and	x13, x11, #0x7f
    915c:      	lsl	x13, x13, x9
    9160:      	add	x9, x9, #0x7
    9164:      	orr	x8, x13, x8
    9168:      	tbnz	w11, #0x7, 0x9148 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3c90>
    916c:      	cmp	x0, #0x60
    9170:      	stur	x10, [x29, #-0x40]
    9174:      	b.hs	0x9b24 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x466c>
    9178:      	sub	w10, w9, #0x7
    917c:      	mov	x12, #-0x1              // =-1
    9180:      	cmp	w10, #0x39
    9184:      	mov	w10, #0x3f              // =63
    9188:      	lsl	x9, x12, x9
    918c:      	ccmp	w11, w10, #0x0, lo
    9190:      	ldr	w10, [x22, #0x2c]
    9194:      	csel	w9, w9, wzr, hi
    9198:      	orr	w8, w8, w9
    919c:      	mul	w8, w10, w8
    91a0:      	stp	w0, w8, [x20]
    91a4:      	ldur	x9, [x29, #-0x40]
    91a8:      	cmp	x9, x24
    91ac:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    91b0:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    91b4:      	bti	j
    91b8:      	sub	x0, x29, #0x40
    91bc:      	mov	x1, x24
    91c0:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    91c4:      	cmp	x0, #0x60
    91c8:      	b.hs	0x9a10 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4558>
    91cc:      	ldur	x9, [x29, #-0x40]
    91d0:      	mov	x10, xzr
    91d4:      	mov	x8, xzr
    91d8:      	mov	x12, x9
    91dc:      	cmp	x12, x24
    91e0:      	b.eq	0x9c34 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x477c>
    91e4:      	ldrb	w11, [x12], #0x1
    91e8:      	add	x9, x9, #0x1
    91ec:      	and	x13, x11, #0x7f
    91f0:      	lsl	x13, x13, x10
    91f4:      	add	x10, x10, #0x7
    91f8:      	orr	x8, x13, x8
    91fc:      	tbnz	w11, #0x7, 0x91dc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3d24>
    9200:      	add	x12, x20, x0, lsl #4
    9204:      	sub	w13, w10, #0x7
    9208:      	mov	x15, #-0x1              // =-1
    920c:      	cmp	w13, #0x39
    9210:      	mov	w14, #0x3f              // =63
    9214:      	lsl	x15, x15, x10
    9218:      	mov	x13, x12
    921c:      	ccmp	w11, w14, #0x0, lo
    9220:      	ldrsw	x10, [x22, #0x2c]
    9224:      	ldrb	w16, [x13, #0x1c]!
    9228:      	csel	x11, x15, xzr, hi
    922c:      	stur	x9, [x29, #-0x40]
    9230:      	cbnz	w16, 0x9254 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3d9c>
    9234:      	lsl	x9, x0, #4
    9238:      	add	x15, x19, #0x28
    923c:      	add	x14, x20, x9
    9240:      	add	x9, x15, x9
    9244:      	ldur	q0, [x14, #0x18]
    9248:      	mov	w14, #0x1               // =1
    924c:      	strb	w14, [x13]
    9250:      	stur	q0, [x9, #0x18]
    9254:      	orr	x8, x8, x11
    9258:      	mov	w9, #0x4                // =4
    925c:      	b	0x9868 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x43b0>
    9260:      	bti	j
    9264:      	sub	x0, x29, #0x40
    9268:      	mov	x1, x24
    926c:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    9270:      	cmp	x0, #0x60
    9274:      	b.hs	0x99e4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x452c>
    9278:      	str	w0, [x20]
    927c:      	ldur	x9, [x29, #-0x40]
    9280:      	cmp	x9, x24
    9284:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    9288:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    928c:      	bti	j
    9290:      	sub	x0, x29, #0x40
    9294:      	mov	x1, x24
    9298:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    929c:      	cmp	x0, #0x60
    92a0:      	b.hs	0x9a74 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x45bc>
    92a4:      	mov	x26, x0
    92a8:      	sub	x0, x29, #0x40
    92ac:      	mov	x1, x24
    92b0:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    92b4:      	add	x8, x20, x26, lsl #4
    92b8:      	ldrsw	x9, [x22, #0x2c]
    92bc:      	mov	x10, x8
    92c0:      	ldrb	w11, [x10, #0x1c]!
    92c4:      	cbnz	w11, 0x92e8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3e30>
    92c8:      	lsl	x11, x26, #4
    92cc:      	add	x13, x19, #0x28
    92d0:      	add	x12, x20, x11
    92d4:      	add	x11, x13, x11
    92d8:      	ldur	q0, [x12, #0x18]
    92dc:      	mov	w12, #0x1               // =1
    92e0:      	strb	w12, [x10]
    92e4:      	stur	q0, [x11, #0x18]
    92e8:      	mneg	x9, x0, x9
    92ec:      	b	0x94f8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4040>
    92f0:      	bti	j
    92f4:      	cmp	w28, #0x4
    92f8:      	b.ne	0x99a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44ec>
    92fc:      	ldrb	w8, [x20, #0x23c]
    9300:      	cbnz	w8, 0x9318 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3e60>
    9304:      	ldp	x9, x8, [x19, #0x8]
    9308:      	ldr	q0, [x8]
    930c:      	mov	w8, #0x1                // =1
    9310:      	strb	w8, [x20, #0x23c]
    9314:      	str	q0, [x9]
    9318:      	ldr	x8, [x20, #0x240]
    931c:      	eor	x8, x8, #0x1
    9320:      	str	x8, [x20, #0x240]
    9324:      	ldur	x9, [x29, #-0x40]
    9328:      	cmp	x9, x24
    932c:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    9330:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    9334:      	bti	j
    9338:      	sub	x26, sp, #0x620
    933c:      	mov	sp, x26
    9340:      	ldr	x8, [x19, #0x20]
    9344:      	mov	x0, x26
    9348:      	mov	x1, x20
    934c:      	mov	w2, #0x618              // =1560
    9350:      	str	x8, [x0], #0x8
    9354:      	bl	0xb9b0 <memcpy@plt>
    9358:      	str	x26, [x19, #0x20]
    935c:      	ldur	x9, [x29, #-0x40]
    9360:      	cmp	x9, x24
    9364:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    9368:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    936c:      	bti	j
    9370:      	ldrb	w8, [x9, #0x1]
    9374:      	ldr	w10, [x22, #0x28]
    9378:      	add	x9, x9, #0x2
    937c:      	b	0x955c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x40a4>
    9380:      	bti	j
    9384:      	ldur	w8, [x9, #0x1]
    9388:      	ldr	w10, [x22, #0x28]
    938c:      	add	x9, x9, #0x5
    9390:      	b	0x955c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x40a4>
    9394:      	bti	j
    9398:      	sub	x0, x29, #0x40
    939c:      	mov	x1, x24
    93a0:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    93a4:      	cmp	x0, #0x60
    93a8:      	b.hs	0x99f4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x453c>
    93ac:      	add	x8, x20, x0, lsl #4
    93b0:      	mov	x9, x8
    93b4:      	ldrb	w10, [x9, #0x1c]!
    93b8:      	cbnz	w10, 0x93dc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3f24>
    93bc:      	lsl	x10, x0, #4
    93c0:      	add	x12, x19, #0x28
    93c4:      	add	x11, x20, x10
    93c8:      	add	x10, x12, x10
    93cc:      	ldur	q0, [x11, #0x18]
    93d0:      	mov	w11, #0x1               // =1
    93d4:      	strb	w11, [x9]
    93d8:      	stur	q0, [x10, #0x18]
    93dc:      	ldur	x9, [x29, #-0x40]
    93e0:      	mov	w10, #0x7               // =7
    93e4:      	b	0x98d4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x441c>
    93e8:      	bti	j
    93ec:      	sub	x0, x29, #0x40
    93f0:      	mov	x1, x24
    93f4:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    93f8:      	mov	x26, x0
    93fc:      	sub	x0, x29, #0x40
    9400:      	mov	x1, x24
    9404:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    9408:      	cmp	x26, #0x60
    940c:      	b.hs	0x9a90 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x45d8>
    9410:      	stp	w26, w0, [x20]
    9414:      	ldur	x9, [x29, #-0x40]
    9418:      	cmp	x9, x24
    941c:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    9420:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    9424:      	bti	j
    9428:      	mov	x10, xzr
    942c:      	mov	x9, xzr
    9430:      	mov	x11, x8
    9434:      	cmp	x11, x24
    9438:      	b.eq	0x9b98 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x46e0>
    943c:      	ldrb	w12, [x11], #0x1
    9440:      	add	x8, x8, #0x1
    9444:      	and	x13, x12, #0x7f
    9448:      	lsl	x13, x13, x10
    944c:      	add	x10, x10, #0x7
    9450:      	orr	x9, x13, x9
    9454:      	tbnz	w12, #0x7, 0x9434 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3f7c>
    9458:      	sub	w11, w10, #0x7
    945c:      	mov	x13, #-0x1              // =-1
    9460:      	stur	x8, [x29, #-0x40]
    9464:      	cmp	w11, #0x39
    9468:      	mov	w11, #0x3f              // =63
    946c:      	lsl	x10, x13, x10
    9470:      	ccmp	w12, w11, #0x0, lo
    9474:      	ldr	w11, [x22, #0x2c]
    9478:      	csel	w10, w10, wzr, hi
    947c:      	orr	w9, w9, w10
    9480:      	mul	w9, w11, w9
    9484:      	str	w9, [x20, #0x4]
    9488:      	mov	x9, x8
    948c:      	cmp	x8, x24
    9490:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    9494:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    9498:      	bti	j
    949c:      	sub	x0, x29, #0x40
    94a0:      	mov	x1, x24
    94a4:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    94a8:      	mov	x26, x0
    94ac:      	sub	x0, x29, #0x40
    94b0:      	mov	x1, x24
    94b4:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    94b8:      	cmp	x26, #0x60
    94bc:      	b.hs	0x9a58 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x45a0>
    94c0:      	add	x8, x20, x26, lsl #4
    94c4:      	ldrsw	x9, [x22, #0x2c]
    94c8:      	mov	x10, x8
    94cc:      	ldrb	w11, [x10, #0x1c]!
    94d0:      	cbnz	w11, 0x94f4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x403c>
    94d4:      	lsl	x11, x26, #4
    94d8:      	add	x13, x19, #0x28
    94dc:      	add	x12, x20, x11
    94e0:      	add	x11, x13, x11
    94e4:      	ldur	q0, [x12, #0x18]
    94e8:      	mov	w12, #0x1               // =1
    94ec:      	strb	w12, [x10]
    94f0:      	stur	q0, [x11, #0x18]
    94f4:      	mul	x9, x0, x9
    94f8:      	mov	w10, #0x2               // =2
    94fc:      	str	w10, [x8, #0x18]
    9500:      	str	x9, [x8, #0x20]
    9504:      	ldur	x9, [x29, #-0x40]
    9508:      	cmp	x9, x24
    950c:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    9510:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    9514:      	bti	j
    9518:      	ldr	x8, [x19, #0x20]
    951c:      	cbz	x8, 0x9b70 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x46b8>
    9520:      	add	x1, x8, #0x8
    9524:      	mov	x0, x20
    9528:      	mov	w2, #0x618              // =1560
    952c:      	mov	x26, x8
    9530:      	bl	0xb9b0 <memcpy@plt>
    9534:      	ldr	x26, [x26]
    9538:      	str	x26, [x19, #0x20]
    953c:      	ldur	x9, [x29, #-0x40]
    9540:      	cmp	x9, x24
    9544:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    9548:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    954c:      	bti	j
    9550:      	ldurh	w8, [x9, #0x1]
    9554:      	ldr	w10, [x22, #0x28]
    9558:      	add	x9, x9, #0x3
    955c:      	mul	w8, w10, w8
    9560:      	add	x25, x25, x8
    9564:      	stur	x9, [x29, #-0x40]
    9568:      	cmp	x9, x24
    956c:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    9570:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    9574:      	bti	j
    9578:      	sub	x0, x29, #0x40
    957c:      	mov	x1, x24
    9580:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    9584:      	str	w0, [x20, #0x10]
    9588:      	ldur	x9, [x29, #-0x40]
    958c:      	cmp	x9, x24
    9590:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    9594:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    9598:      	bti	j
    959c:      	sub	x0, x29, #0x40
    95a0:      	mov	x1, x24
    95a4:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    95a8:      	cmp	x0, #0x60
    95ac:      	b.hs	0x9a3c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4584>
    95b0:      	add	x8, x20, x0, lsl #4
    95b4:      	ldrb	w8, [x8, #0x1c]
    95b8:      	cbz	w8, 0x99a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44ec>
    95bc:      	lsl	x8, x0, #4
    95c0:      	b	0x9990 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44d8>
    95c4:      	bti	j
    95c8:      	sub	x0, x29, #0x40
    95cc:      	mov	x1, x24
    95d0:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    95d4:      	cmp	x0, #0x60
    95d8:      	b.hs	0x9aac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x45f4>
    95dc:      	add	x8, x20, x0, lsl #4
    95e0:      	mov	x9, x8
    95e4:      	ldrb	w10, [x9, #0x1c]!
    95e8:      	cbnz	w10, 0x960c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4154>
    95ec:      	lsl	x10, x0, #4
    95f0:      	add	x12, x19, #0x28
    95f4:      	add	x11, x20, x10
    95f8:      	add	x10, x12, x10
    95fc:      	ldur	q0, [x11, #0x18]
    9600:      	mov	w11, #0x1               // =1
    9604:      	strb	w11, [x9]
    9608:      	stur	q0, [x10, #0x18]
    960c:      	mov	w9, #0x1                // =1
    9610:      	str	w9, [x8, #0x18]
    9614:      	ldur	x9, [x29, #-0x40]
    9618:      	cmp	x9, x24
    961c:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    9620:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    9624:      	bti	j
    9628:      	sub	x0, x29, #0x40
    962c:      	mov	x1, x24
    9630:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    9634:      	str	w0, [x20, #0x4]
    9638:      	ldur	x9, [x29, #-0x40]
    963c:      	cmp	x9, x24
    9640:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    9644:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    9648:      	bti	j
    964c:      	str	wzr, [x20]
    9650:      	str	x8, [x20, #0x8]
    9654:      	b	0x98dc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4424>
    9658:      	bti	j
    965c:      	sub	x0, x29, #0x40
    9660:      	mov	x1, x24
    9664:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    9668:      	mov	x26, x0
    966c:      	sub	x0, x29, #0x40
    9670:      	mov	x1, x24
    9674:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    9678:      	cmp	x26, #0x60
    967c:      	b.hs	0x9af8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4640>
    9680:      	cmp	x0, #0x60
    9684:      	b.hs	0x9b40 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4688>
    9688:      	add	x8, x20, x26, lsl #4
    968c:      	mov	x9, x8
    9690:      	ldrb	w10, [x9, #0x1c]!
    9694:      	cbnz	w10, 0x96b8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4200>
    9698:      	lsl	x10, x26, #4
    969c:      	add	x12, x19, #0x28
    96a0:      	add	x11, x20, x10
    96a4:      	add	x10, x12, x10
    96a8:      	ldur	q0, [x11, #0x18]
    96ac:      	mov	w11, #0x1               // =1
    96b0:      	strb	w11, [x9]
    96b4:      	stur	q0, [x10, #0x18]
    96b8:      	mov	w9, #0x5                // =5
    96bc:      	str	x0, [x8, #0x20]
    96c0:      	str	w9, [x8, #0x18]
    96c4:      	ldur	x9, [x29, #-0x40]
    96c8:      	cmp	x9, x24
    96cc:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    96d0:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    96d4:      	bti	j
    96d8:      	and	w8, w10, #0xc0
    96dc:      	and	x26, x10, #0x3f
    96e0:      	cmp	w8, #0x40
    96e4:      	b.eq	0x99c0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4508>
    96e8:      	cmp	w8, #0xc0
    96ec:      	b.eq	0x9980 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44c8>
    96f0:      	cmp	w8, #0x80
    96f4:      	b.ne	0x9b70 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x46b8>
    96f8:      	sub	x0, x29, #0x40
    96fc:      	mov	x1, x24
    9700:      	str	w28, [x19, #0x4]
    9704:      	mov	w28, w26
    9708:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    970c:      	add	x8, x20, w26, uxtw #4
    9710:      	ldrsw	x9, [x22, #0x2c]
    9714:      	ldrb	w10, [x8, #0x1c]!
    9718:      	cbnz	w10, 0x973c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4284>
    971c:      	lsl	x10, x28, #4
    9720:      	add	x11, x20, x10
    9724:      	ldur	q0, [x11, #0x18]
    9728:      	add	x11, x19, #0x28
    972c:      	add	x10, x11, x10
    9730:      	stur	q0, [x10, #0x18]
    9734:      	mov	w10, #0x1               // =1
    9738:      	strb	w10, [x8]
    973c:      	mul	x8, x0, x9
    9740:      	add	x9, x20, x28, lsl #4
    9744:      	mov	w10, #0x2               // =2
    9748:      	ldr	w28, [x19, #0x4]
    974c:      	str	w10, [x9, #0x18]
    9750:      	str	x8, [x9, #0x20]
    9754:      	ldur	x9, [x29, #-0x40]
    9758:      	cmp	x9, x24
    975c:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    9760:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    9764:      	bti	j
    9768:      	sub	x0, x29, #0x40
    976c:      	mov	x1, x24
    9770:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    9774:      	cmp	x0, #0x60
    9778:      	b.hs	0x9a2c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4574>
    977c:      	add	x8, x20, x0, lsl #4
    9780:      	mov	x9, x8
    9784:      	ldrb	w10, [x9, #0x1c]!
    9788:      	cbnz	w10, 0x97ac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x42f4>
    978c:      	lsl	x10, x0, #4
    9790:      	add	x12, x19, #0x28
    9794:      	add	x11, x20, x10
    9798:      	add	x10, x12, x10
    979c:      	ldur	q0, [x11, #0x18]
    97a0:      	mov	w11, #0x1               // =1
    97a4:      	strb	w11, [x9]
    97a8:      	stur	q0, [x10, #0x18]
    97ac:      	str	wzr, [x8, #0x18]
    97b0:      	ldur	x9, [x29, #-0x40]
    97b4:      	cmp	x9, x24
    97b8:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    97bc:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    97c0:      	bti	j
    97c4:      	sub	x0, x29, #0x40
    97c8:      	mov	x1, x24
    97cc:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    97d0:      	cmp	x0, #0x60
    97d4:      	b.hs	0x9adc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4624>
    97d8:      	ldur	x9, [x29, #-0x40]
    97dc:      	mov	x10, xzr
    97e0:      	mov	x8, xzr
    97e4:      	mov	x12, x9
    97e8:      	cmp	x12, x24
    97ec:      	b.eq	0x9c00 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4748>
    97f0:      	ldrb	w11, [x12], #0x1
    97f4:      	add	x9, x9, #0x1
    97f8:      	and	x13, x11, #0x7f
    97fc:      	lsl	x13, x13, x10
    9800:      	add	x10, x10, #0x7
    9804:      	orr	x8, x13, x8
    9808:      	tbnz	w11, #0x7, 0x97e8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4330>
    980c:      	add	x12, x20, x0, lsl #4
    9810:      	sub	w13, w10, #0x7
    9814:      	mov	x15, #-0x1              // =-1
    9818:      	cmp	w13, #0x39
    981c:      	mov	w14, #0x3f              // =63
    9820:      	lsl	x15, x15, x10
    9824:      	mov	x13, x12
    9828:      	ccmp	w11, w14, #0x0, lo
    982c:      	ldrsw	x10, [x22, #0x2c]
    9830:      	ldrb	w16, [x13, #0x1c]!
    9834:      	csel	x11, x15, xzr, hi
    9838:      	stur	x9, [x29, #-0x40]
    983c:      	cbnz	w16, 0x9860 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x43a8>
    9840:      	lsl	x9, x0, #4
    9844:      	add	x15, x19, #0x28
    9848:      	add	x14, x20, x9
    984c:      	add	x9, x15, x9
    9850:      	ldur	q0, [x14, #0x18]
    9854:      	mov	w14, #0x1               // =1
    9858:      	strb	w14, [x13]
    985c:      	stur	q0, [x9, #0x18]
    9860:      	orr	x8, x8, x11
    9864:      	mov	w9, #0x2                // =2
    9868:      	mul	x8, x8, x10
    986c:      	str	w9, [x12, #0x18]
    9870:      	str	x8, [x12, #0x20]
    9874:      	ldur	x9, [x29, #-0x40]
    9878:      	cmp	x9, x24
    987c:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    9880:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    9884:      	bti	j
    9888:      	sub	x0, x29, #0x40
    988c:      	mov	x1, x24
    9890:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    9894:      	cmp	x0, #0x60
    9898:      	b.hs	0x9b14 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x465c>
    989c:      	add	x8, x20, x0, lsl #4
    98a0:      	mov	x9, x8
    98a4:      	ldrb	w10, [x9, #0x1c]!
    98a8:      	cbnz	w10, 0x98cc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4414>
    98ac:      	lsl	x10, x0, #4
    98b0:      	add	x12, x19, #0x28
    98b4:      	add	x11, x20, x10
    98b8:      	add	x10, x12, x10
    98bc:      	ldur	q0, [x11, #0x18]
    98c0:      	mov	w11, #0x1               // =1
    98c4:      	strb	w11, [x9]
    98c8:      	stur	q0, [x10, #0x18]
    98cc:      	ldur	x9, [x29, #-0x40]
    98d0:      	mov	w10, #0x6               // =6
    98d4:      	str	w10, [x8, #0x18]
    98d8:      	str	x9, [x8, #0x20]
    98dc:      	sub	x0, x29, #0x40
    98e0:      	mov	x1, x24
    98e4:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    98e8:      	ldur	x8, [x29, #-0x40]
    98ec:      	add	x8, x8, x0
    98f0:      	stur	x8, [x29, #-0x40]
    98f4:      	mov	x9, x8
    98f8:      	cmp	x8, x24
    98fc:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    9900:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    9904:      	bti	j
    9908:      	sub	x0, x29, #0x40
    990c:      	mov	x1, x24
    9910:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    9914:      	mov	x26, x0
    9918:      	cmp	x0, #0x60
    991c:      	b.hs	0x9abc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4604>
    9920:      	sub	x0, x29, #0x40
    9924:      	mov	x1, x24
    9928:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    992c:      	add	x8, x20, x26, lsl #4
    9930:      	ldrsw	x9, [x22, #0x2c]
    9934:      	mov	x10, x8
    9938:      	ldrb	w11, [x10, #0x1c]!
    993c:      	cbnz	w11, 0x9960 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44a8>
    9940:      	lsl	x11, x26, #4
    9944:      	add	x13, x19, #0x28
    9948:      	add	x12, x20, x11
    994c:      	add	x11, x13, x11
    9950:      	ldur	q0, [x12, #0x18]
    9954:      	mov	w12, #0x1               // =1
    9958:      	strb	w12, [x10]
    995c:      	stur	q0, [x11, #0x18]
    9960:      	mul	x9, x0, x9
    9964:      	mov	w10, #0x4               // =4
    9968:      	str	w10, [x8, #0x18]
    996c:      	str	x9, [x8, #0x20]
    9970:      	ldur	x9, [x29, #-0x40]
    9974:      	cmp	x9, x24
    9978:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    997c:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    9980:      	add	x8, x20, x26, lsl #4
    9984:      	ldrb	w8, [x8, #0x1c]
    9988:      	cbz	w8, 0x99a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44ec>
    998c:      	lsl	x8, x26, #4
    9990:      	add	x9, x19, #0x28
    9994:      	add	x9, x9, x8
    9998:      	add	x8, x20, x8
    999c:      	ldur	q0, [x9, #0x18]
    99a0:      	stur	q0, [x8, #0x18]
    99a4:      	bti	j
    99a8:      	ldur	x9, [x29, #-0x40]
    99ac:      	cmp	x9, x24
    99b0:      	b.hs	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    99b4:      	cmp	x25, x21
    99b8:      	b.lo	0x90d4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3c1c>
    99bc:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    99c0:      	ldr	w8, [x22, #0x28]
    99c4:      	mul	w8, w8, w26
    99c8:      	add	x25, x25, x8
    99cc:      	ldur	x9, [x29, #-0x40]
    99d0:      	cmp	x9, x24
    99d4:      	b.lo	0x99b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x44fc>
    99d8:      	b	0x90a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3bec>
    99dc:      	mov	w0, #0x1                // =1
    99e0:      	b	0x9b74 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x46bc>
    99e4:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    99e8:      	adrp	x0, 0x1000
    99ec:      	add	x0, x0, #0xa38
    99f0:      	b	0x9a48 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4590>
    99f4:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    99f8:      	adrp	x0, 0x1000
    99fc:      	add	x0, x0, #0x8bc
    9a00:      	ldr	x8, [x8, #0xe28]
    9a04:      	mov	w1, #0x45               // =69
    9a08:      	add	x3, x8, #0x130
    9a0c:      	b	0x9b58 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x46a0>
    9a10:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    9a14:      	adrp	x0, 0x1000
    9a18:      	add	x0, x0, #0xb10
    9a1c:      	ldr	x8, [x8, #0xe28]
    9a20:      	mov	w1, #0x44               // =68
    9a24:      	add	x3, x8, #0x130
    9a28:      	b	0x9b58 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x46a0>
    9a2c:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    9a30:      	adrp	x0, 0x1000
    9a34:      	add	x0, x0, #0xb89
    9a38:      	b	0x9b30 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4678>
    9a3c:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    9a40:      	adrp	x0, 0x1000
    9a44:      	add	x0, x0, #0x81c
    9a48:      	ldr	x8, [x8, #0xe28]
    9a4c:      	add	x3, x8, #0x130
    9a50:      	mov	w1, #0x47               // =71
    9a54:      	b	0x9b58 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x46a0>
    9a58:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    9a5c:      	adrp	x0, 0x1000
    9a60:      	add	x0, x0, #0x370
    9a64:      	ldr	x8, [x8, #0xe28]
    9a68:      	mov	w1, #0x46               // =70
    9a6c:      	add	x3, x8, #0x130
    9a70:      	b	0x9b58 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x46a0>
    9a74:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    9a78:      	adrp	x0, 0x1000
    9a7c:      	add	x0, x0, #0x9a4
    9a80:      	ldr	x8, [x8, #0xe28]
    9a84:      	mov	w1, #0x53               // =83
    9a88:      	add	x3, x8, #0x130
    9a8c:      	b	0x9b58 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x46a0>
    9a90:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    9a94:      	adrp	x0, 0x1000
    9a98:      	add	x0, x0, #0x1f7
    9a9c:      	ldr	x8, [x8, #0xe28]
    9aa0:      	mov	w1, #0x3e               // =62
    9aa4:      	add	x3, x8, #0x130
    9aa8:      	b	0x9b58 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x46a0>
    9aac:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    9ab0:      	adrp	x0, 0x1000
    9ab4:      	add	x0, x0, #0xa93
    9ab8:      	b	0x9b4c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4694>
    9abc:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    9ac0:      	adrp	x1, 0x1000
    9ac4:      	add	x1, x1, #0x242
    9ac8:      	ldr	x8, [x8, #0xe28]
    9acc:      	mov	x2, x26
    9ad0:      	add	x0, x8, #0x130
    9ad4:      	bl	0xbae0 <fprintf@plt>
    9ad8:      	b	0x9b60 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x46a8>
    9adc:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    9ae0:      	adrp	x0, 0x1000
    9ae4:      	add	x0, x0, #0x658
    9ae8:      	ldr	x8, [x8, #0xe28]
    9aec:      	mov	w1, #0x49               // =73
    9af0:      	add	x3, x8, #0x130
    9af4:      	b	0x9b58 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x46a0>
    9af8:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    9afc:      	adrp	x0, 0x1000
    9b00:      	add	x0, x0, #0x9f8
    9b04:      	ldr	x8, [x8, #0xe28]
    9b08:      	mov	w1, #0x3f               // =63
    9b0c:      	add	x3, x8, #0x130
    9b10:      	b	0x9b58 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x46a0>
    9b14:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    9b18:      	adrp	x0, 0x1000
    9b1c:      	add	x0, x0, #0x612
    9b20:      	b	0x9b30 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4678>
    9b24:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    9b28:      	adrp	x0, 0x1000
    9b2c:      	add	x0, x0, #0x2e0
    9b30:      	ldr	x8, [x8, #0xe28]
    9b34:      	add	x3, x8, #0x130
    9b38:      	mov	w1, #0x41               // =65
    9b3c:      	b	0x9b58 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x46a0>
    9b40:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    9b44:      	adrp	x0, 0x1000
    9b48:      	add	x0, x0, #0x546
    9b4c:      	ldr	x8, [x8, #0xe28]
    9b50:      	add	x3, x8, #0x130
    9b54:      	mov	w1, #0x40               // =64
    9b58:      	mov	w2, #0x1                // =1
    9b5c:      	bl	0xbb90 <fwrite@plt>
    9b60:      	adrp	x8, 0xf000 <fwrite@plt+0x3470>
    9b64:      	ldr	x8, [x8, #0xe28]
    9b68:      	add	x0, x8, #0x130
    9b6c:      	bl	0xbaf0 <fflush@plt>
    9b70:      	mov	w0, wzr
    9b74:      	mov	sp, x29
    9b78:      	ldp	x20, x19, [sp, #0x50]
    9b7c:      	ldp	x22, x21, [sp, #0x40]
    9b80:      	ldp	x24, x23, [sp, #0x30]
    9b84:      	ldp	x26, x25, [sp, #0x20]
    9b88:      	ldp	x28, x27, [sp, #0x10]
    9b8c:      	ldp	x29, x30, [sp], #0x60
    9b90:      	autiasp
    9b94:      	ret
    9b98:      	adrp	x20, 0xf000 <fwrite@plt+0x3470>
    9b9c:      	nop
    9ba0:      	adr	x1, 0x1191
    9ba4:      	ldr	x20, [x20, #0xe28]
    9ba8:      	adrp	x2, 0x1000
    9bac:      	add	x2, x2, #0x710
    9bb0:      	adrp	x3, 0x1000
    9bb4:      	add	x3, x3, #0x48b
    9bb8:      	add	x0, x20, #0x130
    9bbc:      	bl	0xbae0 <fprintf@plt>
    9bc0:      	add	x0, x20, #0x130
    9bc4:      	bl	0xbaf0 <fflush@plt>
    9bc8:      	bl	0xbb00 <abort@plt>
    9bcc:      	adrp	x20, 0xf000 <fwrite@plt+0x3470>
    9bd0:      	nop
    9bd4:      	adr	x1, 0x1191
    9bd8:      	ldr	x20, [x20, #0xe28]
    9bdc:      	adrp	x2, 0x1000
    9be0:      	add	x2, x2, #0x710
    9be4:      	adrp	x3, 0x1000
    9be8:      	add	x3, x3, #0x48b
    9bec:      	add	x0, x20, #0x130
    9bf0:      	bl	0xbae0 <fprintf@plt>
    9bf4:      	add	x0, x20, #0x130
    9bf8:      	bl	0xbaf0 <fflush@plt>
    9bfc:      	bl	0xbb00 <abort@plt>
    9c00:      	adrp	x20, 0xf000 <fwrite@plt+0x3470>
    9c04:      	nop
    9c08:      	adr	x1, 0x1191
    9c0c:      	ldr	x20, [x20, #0xe28]
    9c10:      	adrp	x2, 0x1000
    9c14:      	add	x2, x2, #0x710
    9c18:      	adrp	x3, 0x1000
    9c1c:      	add	x3, x3, #0x48b
    9c20:      	add	x0, x20, #0x130
    9c24:      	bl	0xbae0 <fprintf@plt>
    9c28:      	add	x0, x20, #0x130
    9c2c:      	bl	0xbaf0 <fflush@plt>
    9c30:      	bl	0xbb00 <abort@plt>
    9c34:      	adrp	x20, 0xf000 <fwrite@plt+0x3470>
    9c38:      	nop
    9c3c:      	adr	x1, 0x1191
    9c40:      	ldr	x20, [x20, #0xe28]
    9c44:      	adrp	x2, 0x1000
    9c48:      	add	x2, x2, #0x710
    9c4c:      	adrp	x3, 0x1000
    9c50:      	add	x3, x3, #0x48b
    9c54:      	add	x0, x20, #0x130
    9c58:      	bl	0xbae0 <fprintf@plt>
    9c5c:      	add	x0, x20, #0x130
    9c60:      	bl	0xbaf0 <fflush@plt>
    9c64:      	bl	0xbb00 <abort@plt>
    9c68:      	bti	c
    9c6c:      	ldr	w8, [x1]
    9c70:      	cmp	w8, #0x1d
    9c74:      	b.gt	0x9c90 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x47d8>
    9c78:      	tbz	w8, #0x1f, 0x9cbc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4804>
    9c7c:      	cmn	w8, #0x2
    9c80:      	b.eq	0x9ca8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x47f0>
    9c84:      	cmn	w8, #0x1
    9c88:      	b.eq	0x9cec <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4834>
    9c8c:      	b	0x9d3c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4884>
    9c90:      	cmp	w8, #0x1f
    9c94:      	b.gt	0x9cdc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4824>
    9c98:      	cmp	w8, #0x1e
    9c9c:      	b.eq	0x9d00 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4848>
    9ca0:      	cmp	w8, #0x1f
    9ca4:      	b.ne	0x9d3c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4884>
    9ca8:      	add	x8, x2, #0xf8
    9cac:      	ldr	x8, [x8]
    9cb0:      	ldrsw	x9, [x1, #0x4]
    9cb4:      	add	x0, x8, x9
    9cb8:      	ret
    9cbc:      	cbz	w8, 0x9d14 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x485c>
    9cc0:      	cmp	w8, #0x1d
    9cc4:      	b.ne	0x9d3c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4884>
    9cc8:      	add	x8, x2, #0xe8
    9ccc:      	ldr	x8, [x8]
    9cd0:      	ldrsw	x9, [x1, #0x4]
    9cd4:      	add	x0, x8, x9
    9cd8:      	ret
    9cdc:      	cmp	w8, #0x22
    9ce0:      	b.eq	0x9d28 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4870>
    9ce4:      	cmp	w8, #0x20
    9ce8:      	b.ne	0x9d3c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4884>
    9cec:      	add	x8, x2, #0x100
    9cf0:      	ldr	x8, [x8]
    9cf4:      	ldrsw	x9, [x1, #0x4]
    9cf8:      	add	x0, x8, x9
    9cfc:      	ret
    9d00:      	add	x8, x2, #0xf0
    9d04:      	ldr	x8, [x8]
    9d08:      	ldrsw	x9, [x1, #0x4]
    9d0c:      	add	x0, x8, x9
    9d10:      	ret
    9d14:      	ldr	x8, [x1, #0x8]
    9d18:      	mov	x1, x0
    9d1c:      	mov	x3, xzr
    9d20:      	mov	x0, x8
    9d24:      	b	0xa500 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5048>
    9d28:      	add	x8, x2, #0x108
    9d2c:      	ldr	x8, [x8]
    9d30:      	ldrsw	x9, [x1, #0x4]
    9d34:      	add	x0, x8, x9
    9d38:      	ret
    9d3c:      	cmp	w8, #0x1c
    9d40:      	b.hi	0x9d58 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x48a0>
    9d44:      	add	x8, x2, x8, lsl #3
    9d48:      	ldr	x8, [x8]
    9d4c:      	ldrsw	x9, [x1, #0x4]
    9d50:      	add	x0, x8, x9
    9d54:      	ret
    9d58:      	paciasp
    9d5c:      	stp	x29, x30, [sp, #-0x20]!
    9d60:      	str	x19, [sp, #0x10]
    9d64:      	mov	x29, sp
    9d68:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    9d6c:      	nop
    9d70:      	adr	x1, 0x1191
    9d74:      	ldr	x19, [x19, #0xe28]
    9d78:      	adrp	x2, 0x1000
    9d7c:      	add	x2, x2, #0x5dd
    9d80:      	adrp	x3, 0x1000
    9d84:      	add	x3, x3, #0x434
    9d88:      	add	x0, x19, #0x130
    9d8c:      	bl	0xbae0 <fprintf@plt>
    9d90:      	add	x0, x19, #0x130
    9d94:      	bl	0xbaf0 <fflush@plt>
    9d98:      	bl	0xbb00 <abort@plt>
    9d9c:      	paciasp
    9da0:      	stp	x29, x30, [sp, #-0x20]!
    9da4:      	str	x19, [sp, #0x10]
    9da8:      	mov	x29, sp
    9dac:      	ldr	w9, [x3]
    9db0:      	mov	x8, x2
    9db4:      	cmp	w9, #0x4
    9db8:      	b.gt	0x9dec <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4934>
    9dbc:      	cmp	w9, #0x1
    9dc0:      	b.eq	0x9e44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x498c>
    9dc4:      	cmp	w9, #0x2
    9dc8:      	b.eq	0x9dd4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x491c>
    9dcc:      	cmp	w9, #0x3
    9dd0:      	b.ne	0x9f44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4a8c>
    9dd4:      	ldr	x9, [x3, #0x8]
    9dd8:      	ldr	x0, [x9, x8]
    9ddc:      	ldr	x19, [sp, #0x10]
    9de0:      	ldp	x29, x30, [sp], #0x20
    9de4:      	autiasp
    9de8:      	ret
    9dec:      	mov	x2, x1
    9df0:      	cmp	w9, #0x5
    9df4:      	b.eq	0x9e58 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x49a0>
    9df8:      	mov	x1, x0
    9dfc:      	cmp	w9, #0x6
    9e00:      	b.eq	0x9e24 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x496c>
    9e04:      	cmp	w9, #0x7
    9e08:      	b.ne	0x9f44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4a8c>
    9e0c:      	ldr	x0, [x3, #0x8]
    9e10:      	mov	x3, x8
    9e14:      	ldr	x19, [sp, #0x10]
    9e18:      	ldp	x29, x30, [sp], #0x20
    9e1c:      	autiasp
    9e20:      	b	0xa500 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5048>
    9e24:      	ldr	x0, [x3, #0x8]
    9e28:      	mov	x3, x8
    9e2c:      	bl	0xa500 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5048>
    9e30:      	ldr	x0, [x0]
    9e34:      	ldr	x19, [sp, #0x10]
    9e38:      	ldp	x29, x30, [sp], #0x20
    9e3c:      	autiasp
    9e40:      	ret
    9e44:      	mov	x0, xzr
    9e48:      	ldr	x19, [sp, #0x10]
    9e4c:      	ldp	x29, x30, [sp], #0x20
    9e50:      	autiasp
    9e54:      	ret
    9e58:      	ldr	x8, [x3, #0x8]
    9e5c:      	cmp	w8, #0x1d
    9e60:      	b.le	0x9e80 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x49c8>
    9e64:      	cmp	w8, #0x1f
    9e68:      	b.gt	0x9eb0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x49f8>
    9e6c:      	cmp	w8, #0x1e
    9e70:      	b.eq	0x9f14 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4a5c>
    9e74:      	cmp	w8, #0x1f
    9e78:      	b.eq	0x9ed8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4a20>
    9e7c:      	b	0x9ef0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4a38>
    9e80:      	cmn	w8, #0x2
    9e84:      	b.eq	0x9ed8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4a20>
    9e88:      	cmn	w8, #0x1
    9e8c:      	b.eq	0x9ec0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4a08>
    9e90:      	cmp	w8, #0x1d
    9e94:      	b.ne	0x9ef0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4a38>
    9e98:      	add	x8, x2, #0xe8
    9e9c:      	ldr	x0, [x8]
    9ea0:      	ldr	x19, [sp, #0x10]
    9ea4:      	ldp	x29, x30, [sp], #0x20
    9ea8:      	autiasp
    9eac:      	ret
    9eb0:      	cmp	w8, #0x22
    9eb4:      	b.eq	0x9f2c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4a74>
    9eb8:      	cmp	w8, #0x20
    9ebc:      	b.ne	0x9ef0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4a38>
    9ec0:      	add	x8, x2, #0x100
    9ec4:      	ldr	x0, [x8]
    9ec8:      	ldr	x19, [sp, #0x10]
    9ecc:      	ldp	x29, x30, [sp], #0x20
    9ed0:      	autiasp
    9ed4:      	ret
    9ed8:      	add	x8, x2, #0xf8
    9edc:      	ldr	x0, [x8]
    9ee0:      	ldr	x19, [sp, #0x10]
    9ee4:      	ldp	x29, x30, [sp], #0x20
    9ee8:      	autiasp
    9eec:      	ret
    9ef0:      	cmp	w8, #0x1c
    9ef4:      	b.hi	0x9f78 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4ac0>
    9ef8:      	and	x8, x8, #0xffffffff
    9efc:      	add	x8, x2, x8, lsl #3
    9f00:      	ldr	x0, [x8]
    9f04:      	ldr	x19, [sp, #0x10]
    9f08:      	ldp	x29, x30, [sp], #0x20
    9f0c:      	autiasp
    9f10:      	ret
    9f14:      	add	x8, x2, #0xf0
    9f18:      	ldr	x0, [x8]
    9f1c:      	ldr	x19, [sp, #0x10]
    9f20:      	ldp	x29, x30, [sp], #0x20
    9f24:      	autiasp
    9f28:      	ret
    9f2c:      	add	x8, x2, #0x108
    9f30:      	ldr	x0, [x8]
    9f34:      	ldr	x19, [sp, #0x10]
    9f38:      	ldp	x29, x30, [sp], #0x20
    9f3c:      	autiasp
    9f40:      	ret
    9f44:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    9f48:      	nop
    9f4c:      	adr	x1, 0x1191
    9f50:      	ldr	x19, [x19, #0xe28]
    9f54:      	adrp	x2, 0x1000
    9f58:      	add	x2, x2, #0x5b7
    9f5c:      	adrp	x3, 0x1000
    9f60:      	add	x3, x3, #0x44f
    9f64:      	add	x0, x19, #0x130
    9f68:      	bl	0xbae0 <fprintf@plt>
    9f6c:      	add	x0, x19, #0x130
    9f70:      	bl	0xbaf0 <fflush@plt>
    9f74:      	bl	0xbb00 <abort@plt>
    9f78:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    9f7c:      	nop
    9f80:      	adr	x1, 0x1191
    9f84:      	ldr	x19, [x19, #0xe28]
    9f88:      	adrp	x2, 0x1000
    9f8c:      	add	x2, x2, #0x5dd
    9f90:      	adrp	x3, 0x1000
    9f94:      	add	x3, x3, #0x434
    9f98:      	add	x0, x19, #0x130
    9f9c:      	bl	0xbae0 <fprintf@plt>
    9fa0:      	add	x0, x19, #0x130
    9fa4:      	bl	0xbaf0 <fflush@plt>
    9fa8:      	bl	0xbb00 <abort@plt>
    9fac:      	paciasp
    9fb0:      	stp	x29, x30, [sp, #-0x30]!
    9fb4:      	str	x21, [sp, #0x10]
    9fb8:      	stp	x20, x19, [sp, #0x20]
    9fbc:      	mov	x29, sp
    9fc0:      	and	w8, w3, #0xf
    9fc4:      	ldr	x19, [x1]
    9fc8:      	cmp	w8, #0x3
    9fcc:      	b.le	0x9ff4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4b3c>
    9fd0:      	cmp	w8, #0x9
    9fd4:      	b.le	0xa068 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4bb0>
    9fd8:      	cmp	w8, #0xa
    9fdc:      	b.eq	0xa138 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4c80>
    9fe0:      	cmp	w8, #0xb
    9fe4:      	b.eq	0xa158 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4ca0>
    9fe8:      	cmp	w8, #0xc
    9fec:      	b.eq	0xa0f8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4c40>
    9ff0:      	b	0xa304 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e4c>
    9ff4:      	cmp	w8, #0x1
    9ff8:      	b.gt	0xa038 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4b80>
    9ffc:      	cbz	w8, 0xa0f8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4c40>
    a000:      	cmp	w8, #0x1
    a004:      	b.ne	0xa304 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e4c>
    a008:      	mov	x0, x1
    a00c:      	mov	x1, x2
    a010:      	mov	w20, w3
    a014:      	mov	x21, x4
    a018:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    a01c:      	mov	x4, x21
    a020:      	mov	w3, w20
    a024:      	and	w8, w20, #0xff
    a028:      	ubfx	w8, w8, #4, #3
    a02c:      	cmp	w8, #0x1
    a030:      	b.le	0xa174 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4cbc>
    a034:      	b	0xa0e0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4c28>
    a038:      	cmp	w8, #0x2
    a03c:      	b.eq	0xa118 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4c60>
    a040:      	cmp	w8, #0x3
    a044:      	b.ne	0xa304 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e4c>
    a048:      	mov	x8, x19
    a04c:      	ldr	w0, [x8], #0x4
    a050:      	str	x8, [x1]
    a054:      	and	w8, w3, #0xff
    a058:      	ubfx	w8, w8, #4, #3
    a05c:      	cmp	w8, #0x1
    a060:      	b.le	0xa174 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4cbc>
    a064:      	b	0xa0e0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4c28>
    a068:      	cmp	w8, #0x4
    a06c:      	b.eq	0xa0f8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4c40>
    a070:      	cmp	w8, #0x9
    a074:      	b.ne	0xa304 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e4c>
    a078:      	mov	x10, xzr
    a07c:      	mov	x8, xzr
    a080:      	mov	x9, x19
    a084:      	mov	x11, x19
    a088:      	cmp	x11, x2
    a08c:      	b.eq	0xa1b4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4cfc>
    a090:      	ldrb	w12, [x11], #0x1
    a094:      	add	x9, x9, #0x1
    a098:      	and	x13, x12, #0x7f
    a09c:      	lsl	x13, x13, x10
    a0a0:      	add	x10, x10, #0x7
    a0a4:      	orr	x8, x13, x8
    a0a8:      	tbnz	w12, #0x7, 0xa088 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4bd0>
    a0ac:      	sub	w11, w10, #0x7
    a0b0:      	mov	x13, #-0x1              // =-1
    a0b4:      	str	x9, [x1]
    a0b8:      	cmp	w11, #0x39
    a0bc:      	mov	w11, #0x3f              // =63
    a0c0:      	lsl	x10, x13, x10
    a0c4:      	ccmp	w12, w11, #0x0, lo
    a0c8:      	csel	x10, x10, xzr, hi
    a0cc:      	orr	x0, x8, x10
    a0d0:      	and	w8, w3, #0xff
    a0d4:      	ubfx	w8, w8, #4, #3
    a0d8:      	cmp	w8, #0x1
    a0dc:      	b.le	0xa174 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4cbc>
    a0e0:      	cmp	w8, #0x3
    a0e4:      	b.gt	0xa1e8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4d30>
    a0e8:      	b.ne	0xa22c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4d74>
    a0ec:      	cbz	x4, 0xa29c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4de4>
    a0f0:      	add	x0, x0, x4
    a0f4:      	b	0xa184 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4ccc>
    a0f8:      	mov	x8, x19
    a0fc:      	ldr	x0, [x8], #0x8
    a100:      	str	x8, [x1]
    a104:      	and	w8, w3, #0xff
    a108:      	ubfx	w8, w8, #4, #3
    a10c:      	cmp	w8, #0x1
    a110:      	b.le	0xa174 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4cbc>
    a114:      	b	0xa0e0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4c28>
    a118:      	mov	x8, x19
    a11c:      	ldrh	w0, [x8], #0x2
    a120:      	str	x8, [x1]
    a124:      	and	w8, w3, #0xff
    a128:      	ubfx	w8, w8, #4, #3
    a12c:      	cmp	w8, #0x1
    a130:      	b.le	0xa174 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4cbc>
    a134:      	b	0xa0e0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4c28>
    a138:      	mov	x8, x19
    a13c:      	ldrsh	x0, [x8], #0x2
    a140:      	str	x8, [x1]
    a144:      	and	w8, w3, #0xff
    a148:      	ubfx	w8, w8, #4, #3
    a14c:      	cmp	w8, #0x1
    a150:      	b.le	0xa174 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4cbc>
    a154:      	b	0xa0e0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4c28>
    a158:      	mov	x8, x19
    a15c:      	ldrsw	x0, [x8], #0x4
    a160:      	str	x8, [x1]
    a164:      	and	w8, w3, #0xff
    a168:      	ubfx	w8, w8, #4, #3
    a16c:      	cmp	w8, #0x1
    a170:      	b.gt	0xa0e0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4c28>
    a174:      	cbz	w8, 0xa184 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4ccc>
    a178:      	cmp	w8, #0x1
    a17c:      	b.ne	0xa2d0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e18>
    a180:      	add	x0, x0, x19
    a184:      	tbnz	w3, #0x7, 0xa19c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4ce4>
    a188:      	ldp	x20, x19, [sp, #0x20]
    a18c:      	ldr	x21, [sp, #0x10]
    a190:      	ldp	x29, x30, [sp], #0x30
    a194:      	autiasp
    a198:      	ret
    a19c:      	ldr	x0, [x0]
    a1a0:      	ldp	x20, x19, [sp, #0x20]
    a1a4:      	ldr	x21, [sp, #0x10]
    a1a8:      	ldp	x29, x30, [sp], #0x30
    a1ac:      	autiasp
    a1b0:      	ret
    a1b4:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    a1b8:      	nop
    a1bc:      	adr	x1, 0x1191
    a1c0:      	ldr	x19, [x19, #0xe28]
    a1c4:      	adrp	x2, 0x1000
    a1c8:      	add	x2, x2, #0x710
    a1cc:      	adrp	x3, 0x1000
    a1d0:      	add	x3, x3, #0x48b
    a1d4:      	add	x0, x19, #0x130
    a1d8:      	bl	0xbae0 <fprintf@plt>
    a1dc:      	add	x0, x19, #0x130
    a1e0:      	bl	0xbaf0 <fflush@plt>
    a1e4:      	bl	0xbb00 <abort@plt>
    a1e8:      	cmp	w8, #0x4
    a1ec:      	b.eq	0xa268 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4db0>
    a1f0:      	cmp	w8, #0x5
    a1f4:      	b.ne	0xa2d0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e18>
    a1f8:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    a1fc:      	nop
    a200:      	adr	x1, 0x1191
    a204:      	ldr	x19, [x19, #0xe28]
    a208:      	adrp	x2, 0x1000
    a20c:      	add	x2, x2, #0xb55
    a210:      	adrp	x3, 0x1000
    a214:      	add	x3, x3, #0x587
    a218:      	add	x0, x19, #0x130
    a21c:      	bl	0xbae0 <fprintf@plt>
    a220:      	add	x0, x19, #0x130
    a224:      	bl	0xbaf0 <fflush@plt>
    a228:      	bl	0xbb00 <abort@plt>
    a22c:      	cmp	w8, #0x2
    a230:      	b.ne	0xa2d0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e18>
    a234:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    a238:      	nop
    a23c:      	adr	x1, 0x1191
    a240:      	ldr	x19, [x19, #0xe28]
    a244:      	adrp	x2, 0x1000
    a248:      	add	x2, x2, #0xb55
    a24c:      	adrp	x3, 0x1000
    a250:      	add	x3, x3, #0x864
    a254:      	add	x0, x19, #0x130
    a258:      	bl	0xbae0 <fprintf@plt>
    a25c:      	add	x0, x19, #0x130
    a260:      	bl	0xbaf0 <fflush@plt>
    a264:      	bl	0xbb00 <abort@plt>
    a268:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    a26c:      	nop
    a270:      	adr	x1, 0x1191
    a274:      	ldr	x19, [x19, #0xe28]
    a278:      	adrp	x2, 0x1000
    a27c:      	add	x2, x2, #0xb55
    a280:      	adrp	x3, 0x1000
    a284:      	add	x3, x3, #0x1a5
    a288:      	add	x0, x19, #0x130
    a28c:      	bl	0xbae0 <fprintf@plt>
    a290:      	add	x0, x19, #0x130
    a294:      	bl	0xbaf0 <fflush@plt>
    a298:      	bl	0xbb00 <abort@plt>
    a29c:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    a2a0:      	nop
    a2a4:      	adr	x1, 0x1191
    a2a8:      	ldr	x19, [x19, #0xe28]
    a2ac:      	adrp	x2, 0x1000
    a2b0:      	add	x2, x2, #0xb55
    a2b4:      	adrp	x3, 0x1000
    a2b8:      	add	x3, x3, #0x936
    a2bc:      	add	x0, x19, #0x130
    a2c0:      	bl	0xbae0 <fprintf@plt>
    a2c4:      	add	x0, x19, #0x130
    a2c8:      	bl	0xbaf0 <fflush@plt>
    a2cc:      	bl	0xbb00 <abort@plt>
    a2d0:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    a2d4:      	nop
    a2d8:      	adr	x1, 0x1191
    a2dc:      	ldr	x19, [x19, #0xe28]
    a2e0:      	adrp	x2, 0x1000
    a2e4:      	add	x2, x2, #0xb55
    a2e8:      	adrp	x3, 0x1000
    a2ec:      	add	x3, x3, #0x6f7
    a2f0:      	add	x0, x19, #0x130
    a2f4:      	bl	0xbae0 <fprintf@plt>
    a2f8:      	add	x0, x19, #0x130
    a2fc:      	bl	0xbaf0 <fflush@plt>
    a300:      	bl	0xbb00 <abort@plt>
    a304:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    a308:      	nop
    a30c:      	adr	x1, 0x1191
    a310:      	ldr	x19, [x19, #0xe28]
    a314:      	adrp	x2, 0x1000
    a318:      	add	x2, x2, #0xb55
    a31c:      	adrp	x3, 0x1000
    a320:      	add	x3, x3, #0x6f7
    a324:      	add	x0, x19, #0x130
    a328:      	bl	0xbae0 <fprintf@plt>
    a32c:      	add	x0, x19, #0x130
    a330:      	bl	0xbaf0 <fflush@plt>
    a334:      	bl	0xbb00 <abort@plt>
    a338:      	paciasp
    a33c:      	stp	x29, x30, [sp, #-0x20]!
    a340:      	str	x19, [sp, #0x10]
    a344:      	mov	x29, sp
    a348:      	ldr	x9, [x0]
    a34c:      	cmp	x9, x1
    a350:      	b.eq	0xa498 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4fe0>
    a354:      	mov	x10, x9
    a358:      	mov	x8, x0
    a35c:      	ldrb	w11, [x10], #0x1
    a360:      	and	x0, x11, #0x7f
    a364:      	tbnz	w11, #0x7, 0xa37c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4ec4>
    a368:      	str	x10, [x8]
    a36c:      	ldr	x19, [sp, #0x10]
    a370:      	ldp	x29, x30, [sp], #0x20
    a374:      	autiasp
    a378:      	ret
    a37c:      	cmp	x10, x1
    a380:      	b.eq	0xa498 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4fe0>
    a384:      	ldrsb	w11, [x9, #0x1]
    a388:      	and	w10, w11, #0x7f
    a38c:      	orr	x0, x0, x10, lsl #7
    a390:      	add	x10, x9, #0x2
    a394:      	tbz	w11, #0x1f, 0xa368 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4eb0>
    a398:      	cmp	x10, x1
    a39c:      	b.eq	0xa498 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4fe0>
    a3a0:      	ldrsb	w11, [x9, #0x2]
    a3a4:      	and	w10, w11, #0x7f
    a3a8:      	orr	x0, x0, x10, lsl #14
    a3ac:      	add	x10, x9, #0x3
    a3b0:      	tbz	w11, #0x1f, 0xa368 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4eb0>
    a3b4:      	cmp	x10, x1
    a3b8:      	b.eq	0xa498 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4fe0>
    a3bc:      	ldrsb	w11, [x9, #0x3]
    a3c0:      	and	w10, w11, #0x7f
    a3c4:      	orr	x0, x0, x10, lsl #21
    a3c8:      	add	x10, x9, #0x4
    a3cc:      	tbz	w11, #0x1f, 0xa368 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4eb0>
    a3d0:      	cmp	x10, x1
    a3d4:      	b.eq	0xa498 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4fe0>
    a3d8:      	ldrsb	w11, [x9, #0x4]
    a3dc:      	and	w10, w11, #0x7f
    a3e0:      	orr	x0, x0, x10, lsl #28
    a3e4:      	add	x10, x9, #0x5
    a3e8:      	tbz	w11, #0x1f, 0xa368 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4eb0>
    a3ec:      	cmp	x10, x1
    a3f0:      	b.eq	0xa498 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4fe0>
    a3f4:      	ldrsb	w11, [x9, #0x5]
    a3f8:      	and	w10, w11, #0x7f
    a3fc:      	orr	x0, x0, x10, lsl #35
    a400:      	add	x10, x9, #0x6
    a404:      	tbz	w11, #0x1f, 0xa368 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4eb0>
    a408:      	cmp	x10, x1
    a40c:      	b.eq	0xa498 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4fe0>
    a410:      	ldrsb	w11, [x9, #0x6]
    a414:      	and	w10, w11, #0x7f
    a418:      	orr	x0, x0, x10, lsl #42
    a41c:      	add	x10, x9, #0x7
    a420:      	tbz	w11, #0x1f, 0xa368 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4eb0>
    a424:      	cmp	x10, x1
    a428:      	b.eq	0xa498 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4fe0>
    a42c:      	ldrsb	w11, [x9, #0x7]
    a430:      	and	w10, w11, #0x7f
    a434:      	orr	x0, x0, x10, lsl #49
    a438:      	add	x10, x9, #0x8
    a43c:      	tbz	w11, #0x1f, 0xa368 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4eb0>
    a440:      	cmp	x10, x1
    a444:      	b.eq	0xa498 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4fe0>
    a448:      	ldrsb	w11, [x9, #0x8]
    a44c:      	and	w10, w11, #0x7f
    a450:      	orr	x0, x0, x10, lsl #56
    a454:      	add	x10, x9, #0x9
    a458:      	tbz	w11, #0x1f, 0xa368 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4eb0>
    a45c:      	cmp	x10, x1
    a460:      	b.eq	0xa498 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4fe0>
    a464:      	ldrb	w11, [x10]
    a468:      	tst	w11, #0x7e
    a46c:      	b.ne	0xa4cc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5014>
    a470:      	add	x10, x9, #0xa
    a474:      	tbnz	w11, #0x7, 0xa490 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4fd8>
    a478:      	orr	x0, x0, x11, lsl #63
    a47c:      	str	x10, [x8]
    a480:      	ldr	x19, [sp, #0x10]
    a484:      	ldp	x29, x30, [sp], #0x20
    a488:      	autiasp
    a48c:      	ret
    a490:      	cmp	x10, x1
    a494:      	b.ne	0xa4cc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5014>
    a498:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    a49c:      	nop
    a4a0:      	adr	x1, 0x1191
    a4a4:      	ldr	x19, [x19, #0xe28]
    a4a8:      	adrp	x2, 0x1000
    a4ac:      	add	x2, x2, #0x35f
    a4b0:      	adrp	x3, 0x1000
    a4b4:      	add	x3, x3, #0x3ce
    a4b8:      	add	x0, x19, #0x130
    a4bc:      	bl	0xbae0 <fprintf@plt>
    a4c0:      	add	x0, x19, #0x130
    a4c4:      	bl	0xbaf0 <fflush@plt>
    a4c8:      	bl	0xbb00 <abort@plt>
    a4cc:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    a4d0:      	nop
    a4d4:      	adr	x1, 0x1191
    a4d8:      	ldr	x19, [x19, #0xe28]
    a4dc:      	adrp	x2, 0x1000
    a4e0:      	add	x2, x2, #0x35f
    a4e4:      	adrp	x3, 0x1000
    a4e8:      	add	x3, x3, #0x4f2
    a4ec:      	add	x0, x19, #0x130
    a4f0:      	bl	0xbae0 <fprintf@plt>
    a4f4:      	add	x0, x19, #0x130
    a4f8:      	bl	0xbaf0 <fflush@plt>
    a4fc:      	bl	0xbb00 <abort@plt>
    a500:      	paciasp
    a504:      	stp	x29, x30, [sp, #-0x60]!
    a508:      	stp	x28, x27, [sp, #0x10]
    a50c:      	stp	x26, x25, [sp, #0x20]
    a510:      	stp	x24, x23, [sp, #0x30]
    a514:      	stp	x22, x21, [sp, #0x40]
    a518:      	stp	x20, x19, [sp, #0x50]
    a51c:      	mov	x29, sp
    a520:      	sub	sp, sp, #0x330
    a524:      	mov	x8, x0
    a528:      	stur	x0, [x29, #-0x8]
    a52c:      	sub	x0, x29, #0x8
    a530:      	add	x1, x8, #0x14
    a534:      	mov	x21, x3
    a538:      	mov	x19, x2
    a53c:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    a540:      	ldur	x10, [x29, #-0x8]
    a544:      	str	x21, [sp, #0x10]
    a548:      	add	x20, x10, x0
    a54c:      	cmp	x10, x20
    a550:      	b.hs	0xac80 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x57c8>
    a554:      	add	x8, sp, #0x8
    a558:      	add	x21, x19, #0xf0
    a55c:      	add	x22, x19, #0xe8
    a560:      	add	x23, x19, #0x108
    a564:      	add	x24, x19, #0xf8
    a568:      	add	x27, x8, #0x8
    a56c:      	add	x25, x19, #0x100
    a570:      	nop
    a574:      	adr	x26, 0x4130
    a578:      	b	0xa590 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50d8>
    a57c:      	ldr	x8, [x8]
    a580:      	str	x8, [x27, #0x8]!
    a584:      	ldur	x10, [x29, #-0x8]
    a588:      	cmp	x10, x20
    a58c:      	b.hs	0xac7c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x57c4>
    a590:      	add	x8, x10, #0x1
    a594:      	stur	x8, [x29, #-0x8]
    a598:      	ldrb	w9, [x10]
    a59c:      	sub	w11, w9, #0x3
    a5a0:      	cmp	w11, #0x91
    a5a4:      	b.hi	0xad78 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x58c0>
    a5a8:      	adr	x12, 0xa5b8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5100>
    a5ac:      	ldrh	w13, [x26, x11, lsl #1]
    a5b0:      	add	x12, x12, x13, lsl #2
    a5b4:      	br	x12
    a5b8:      	bti	j
    a5bc:      	sub	w8, w9, #0x30
    a5c0:      	b	0xa580 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c8>
    a5c4:      	bti	j
    a5c8:      	mov	x12, xzr
    a5cc:      	mov	x10, xzr
    a5d0:      	sub	w11, w9, #0x70
    a5d4:      	mov	x13, x8
    a5d8:      	cmp	x13, x20
    a5dc:      	b.eq	0xaca8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x57f0>
    a5e0:      	ldrb	w14, [x13], #0x1
    a5e4:      	add	x8, x8, #0x1
    a5e8:      	and	x15, x14, #0x7f
    a5ec:      	lsl	x15, x15, x12
    a5f0:      	add	x12, x12, #0x7
    a5f4:      	orr	x10, x15, x10
    a5f8:      	tbnz	w14, #0x7, 0xa5d8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5120>
    a5fc:      	sub	w13, w12, #0x7
    a600:      	mov	x15, #-0x1              // =-1
    a604:      	stur	x8, [x29, #-0x8]
    a608:      	cmp	w13, #0x39
    a60c:      	mov	w13, #0x3f              // =63
    a610:      	lsl	x12, x15, x12
    a614:      	ccmp	w14, w13, #0x0, lo
    a618:      	csel	x12, x12, xzr, hi
    a61c:      	cmp	w9, #0x8d
    a620:      	b.le	0xa67c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x51c4>
    a624:      	cmp	w9, #0x8f
    a628:      	b.gt	0xa6a4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x51ec>
    a62c:      	cmp	w9, #0x8e
    a630:      	mov	x8, x21
    a634:      	b.eq	0xa6c8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5210>
    a638:      	cmp	w9, #0x8f
    a63c:      	mov	x8, x24
    a640:      	b.eq	0xa6c8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5210>
    a644:      	b	0xa6bc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5204>
    a648:      	bti	j
    a64c:      	cmp	w9, #0x6f
    a650:      	mov	x8, x24
    a654:      	b.eq	0xa57c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c4>
    a658:      	cmp	w9, #0x6e
    a65c:      	mov	x8, x21
    a660:      	b.eq	0xa57c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c4>
    a664:      	cmp	w9, #0x6d
    a668:      	mov	x8, x22
    a66c:      	b.eq	0xa57c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c4>
    a670:      	sub	w8, w9, #0x50
    a674:      	add	x8, x19, w8, uxtw #3
    a678:      	b	0xa57c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c4>
    a67c:      	cmp	w9, #0x6e
    a680:      	mov	x8, x24
    a684:      	b.eq	0xa6c8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5210>
    a688:      	cmp	w9, #0x6f
    a68c:      	mov	x8, x25
    a690:      	b.eq	0xa6c8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5210>
    a694:      	cmp	w9, #0x8d
    a698:      	mov	x8, x22
    a69c:      	b.eq	0xa6c8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5210>
    a6a0:      	b	0xa6bc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5204>
    a6a4:      	cmp	w9, #0x90
    a6a8:      	mov	x8, x25
    a6ac:      	b.eq	0xa6c8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5210>
    a6b0:      	cmp	w9, #0x92
    a6b4:      	mov	x8, x23
    a6b8:      	b.eq	0xa6c8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5210>
    a6bc:      	cmp	w11, #0x1c
    a6c0:      	b.hi	0xad44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x588c>
    a6c4:      	add	x8, x19, w11, uxtw #3
    a6c8:      	ldr	x8, [x8]
    a6cc:      	orr	x9, x10, x12
    a6d0:      	add	x8, x8, x9
    a6d4:      	b	0xa580 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c8>
    a6d8:      	bti	j
    a6dc:      	ldur	x8, [x10, #0x1]
    a6e0:      	add	x9, x10, #0x9
    a6e4:      	b	0xa9e8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5530>
    a6e8:      	bti	j
    a6ec:      	sub	x0, x29, #0x8
    a6f0:      	mov	x1, x20
    a6f4:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    a6f8:      	ldur	x10, [x29, #-0x8]
    a6fc:      	mov	x9, xzr
    a700:      	mov	x8, xzr
    a704:      	mov	x11, x10
    a708:      	cmp	x11, x20
    a70c:      	b.eq	0xacdc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5824>
    a710:      	ldrb	w12, [x11], #0x1
    a714:      	add	x10, x10, #0x1
    a718:      	and	x13, x12, #0x7f
    a71c:      	lsl	x13, x13, x9
    a720:      	add	x9, x9, #0x7
    a724:      	orr	x8, x13, x8
    a728:      	tbnz	w12, #0x7, 0xa708 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5250>
    a72c:      	sub	w11, w9, #0x7
    a730:      	mov	x13, #-0x1              // =-1
    a734:      	stur	x10, [x29, #-0x8]
    a738:      	cmp	w11, #0x39
    a73c:      	mov	w11, #0x3f              // =63
    a740:      	lsl	x9, x13, x9
    a744:      	ccmp	w12, w11, #0x0, lo
    a748:      	csel	x9, x9, xzr, hi
    a74c:      	cmp	w0, #0x1d
    a750:      	b.le	0xabe0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5728>
    a754:      	cmp	w0, #0x1f
    a758:      	b.gt	0xac30 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5778>
    a75c:      	cmp	w0, #0x1e
    a760:      	mov	x10, x21
    a764:      	b.eq	0xac54 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x579c>
    a768:      	cmp	w0, #0x1f
    a76c:      	mov	x10, x24
    a770:      	b.eq	0xac54 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x579c>
    a774:      	b	0xac48 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5790>
    a778:      	bti	j
    a77c:      	mov	x8, x27
    a780:      	ldr	x9, [x27]
    a784:      	ldr	x10, [x8, #-0x8]!
    a788:      	cmp	x10, x9
    a78c:      	cset	w9, lo
    a790:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    a794:      	bti	j
    a798:      	mov	x8, x27
    a79c:      	ldr	x9, [x27]
    a7a0:      	ldr	x10, [x8, #-0x8]!
    a7a4:      	cmp	x10, x9
    a7a8:      	cset	w9, ls
    a7ac:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    a7b0:      	bti	j
    a7b4:      	mov	x8, x27
    a7b8:      	ldr	x9, [x27]
    a7bc:      	ldr	x10, [x8, #-0x8]!
    a7c0:      	sdiv	x11, x10, x9
    a7c4:      	msub	x9, x11, x9, x10
    a7c8:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    a7cc:      	bti	j
    a7d0:      	mov	x8, x27
    a7d4:      	ldr	x9, [x27]
    a7d8:      	ldr	x10, [x8, #-0x8]!
    a7dc:      	cmp	x10, x9
    a7e0:      	cset	w9, eq
    a7e4:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    a7e8:      	bti	j
    a7ec:      	ldursh	x8, [x10, #0x1]
    a7f0:      	add	x9, x10, #0x3
    a7f4:      	b	0xa9e8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5530>
    a7f8:      	bti	j
    a7fc:      	ldr	x11, [x27], #-0x8
    a800:      	ldursh	x8, [x10, #0x1]
    a804:      	add	x9, x10, #0x3
    a808:      	stur	x9, [x29, #-0x8]
    a80c:      	cbz	x11, 0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    a810:      	add	x8, x9, x8
    a814:      	stur	x8, [x29, #-0x8]
    a818:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    a81c:      	bti	j
    a820:      	mov	x8, x27
    a824:      	ldr	x9, [x27]
    a828:      	ldr	x10, [x8, #-0x8]!
    a82c:      	cmp	x10, x9
    a830:      	cset	w9, hs
    a834:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    a838:      	bti	j
    a83c:      	mov	x10, xzr
    a840:      	mov	x9, xzr
    a844:      	mov	x11, x8
    a848:      	cmp	x11, x20
    a84c:      	b.eq	0xad10 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5858>
    a850:      	ldrb	w12, [x11], #0x1
    a854:      	add	x8, x8, #0x1
    a858:      	and	x13, x12, #0x7f
    a85c:      	lsl	x13, x13, x10
    a860:      	add	x10, x10, #0x7
    a864:      	orr	x9, x13, x9
    a868:      	tbnz	w12, #0x7, 0xa848 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5390>
    a86c:      	sub	w11, w10, #0x7
    a870:      	mov	x13, #-0x1              // =-1
    a874:      	stur	x8, [x29, #-0x8]
    a878:      	cmp	w11, #0x39
    a87c:      	mov	w11, #0x3f              // =63
    a880:      	lsl	x10, x13, x10
    a884:      	ccmp	w12, w11, #0x0, lo
    a888:      	csel	x10, x10, xzr, hi
    a88c:      	orr	x9, x9, x10
    a890:      	str	x9, [x27, #0x8]!
    a894:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    a898:      	bti	j
    a89c:      	mov	x8, x27
    a8a0:      	ldr	x9, [x27]
    a8a4:      	ldr	x10, [x8, #-0x8]!
    a8a8:      	and	x9, x10, x9
    a8ac:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    a8b0:      	bti	j
    a8b4:      	mov	x8, x27
    a8b8:      	ldr	x9, [x27]
    a8bc:      	ldr	x10, [x8, #-0x8]!
    a8c0:      	cmp	x10, x9
    a8c4:      	cset	w9, hi
    a8c8:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    a8cc:      	bti	j
    a8d0:      	ldursw	x8, [x10, #0x1]
    a8d4:      	add	x9, x10, #0x5
    a8d8:      	b	0xa9e8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5530>
    a8dc:      	bti	j
    a8e0:      	mov	x8, x27
    a8e4:      	ldr	x9, [x27]
    a8e8:      	ldr	x10, [x8, #-0x8]!
    a8ec:      	eor	x9, x10, x9
    a8f0:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    a8f4:      	bti	j
    a8f8:      	ldr	x8, [x27]
    a8fc:      	tbz	x8, #0x3f, 0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    a900:      	b	0xab20 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5668>
    a904:      	bti	j
    a908:      	ldrsb	x8, [x10, #0x1]
    a90c:      	b	0xa94c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5494>
    a910:      	bti	j
    a914:      	ldr	x8, [x27]
    a918:      	b	0xa580 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c8>
    a91c:      	bti	j
    a920:      	sub	x0, x29, #0x8
    a924:      	mov	x1, x20
    a928:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    a92c:      	str	x0, [x27, #0x8]!
    a930:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    a934:      	bti	j
    a938:      	ldur	w8, [x10, #0x1]
    a93c:      	add	x9, x10, #0x5
    a940:      	b	0xa9e8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5530>
    a944:      	bti	j
    a948:      	ldrb	w8, [x10, #0x1]
    a94c:      	add	x9, x10, #0x2
    a950:      	b	0xa9e8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5530>
    a954:      	bti	j
    a958:      	sub	x27, x27, #0x8
    a95c:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    a960:      	bti	j
    a964:      	ldurh	w8, [x10, #0x1]
    a968:      	add	x9, x10, #0x3
    a96c:      	b	0xa9e8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5530>
    a970:      	bti	j
    a974:      	ldr	x8, [x27]
    a978:      	ldr	x8, [x8]
    a97c:      	str	x8, [x27]
    a980:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    a984:      	bti	j
    a988:      	ldur	q0, [x27, #-0x10]
    a98c:      	ldr	x8, [x27]
    a990:      	stur	q0, [x27, #-0x8]
    a994:      	stur	x8, [x27, #-0x10]
    a998:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    a99c:      	bti	j
    a9a0:      	mov	x8, x27
    a9a4:      	ldr	x9, [x27]
    a9a8:      	ldr	x10, [x8, #-0x8]!
    a9ac:      	sdiv	x9, x10, x9
    a9b0:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    a9b4:      	bti	j
    a9b8:      	ldur	x8, [x27, #-0x8]
    a9bc:      	b	0xa580 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c8>
    a9c0:      	bti	j
    a9c4:      	ldur	q0, [x27, #-0x8]
    a9c8:      	ext	v0.16b, v0.16b, v0.16b, #0x8
    a9cc:      	stur	q0, [x27, #-0x8]
    a9d0:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    a9d4:      	bti	j
    a9d8:      	ldrb	w8, [x10, #0x1]
    a9dc:      	add	x9, x10, #0x2
    a9e0:      	sub	x8, x27, x8, lsl #3
    a9e4:      	ldr	x8, [x8]
    a9e8:      	stur	x9, [x29, #-0x8]
    a9ec:      	b	0xa580 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c8>
    a9f0:      	bti	j
    a9f4:      	ldr	x8, [x27]
    a9f8:      	mvn	x8, x8
    a9fc:      	str	x8, [x27]
    aa00:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    aa04:      	bti	j
    aa08:      	mov	x8, x27
    aa0c:      	ldr	x9, [x27]
    aa10:      	ldr	x10, [x8, #-0x8]!
    aa14:      	lsl	x9, x10, x9
    aa18:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    aa1c:      	bti	j
    aa20:      	mov	x8, x27
    aa24:      	ldr	x9, [x27]
    aa28:      	ldr	x10, [x8, #-0x8]!
    aa2c:      	lsr	x9, x10, x9
    aa30:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    aa34:      	bti	j
    aa38:      	mov	x8, x27
    aa3c:      	ldr	x9, [x27]
    aa40:      	ldr	x10, [x8, #-0x8]!
    aa44:      	add	x9, x10, x9
    aa48:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    aa4c:      	bti	j
    aa50:      	add	x8, x10, #0x2
    aa54:      	stur	x8, [x29, #-0x8]
    aa58:      	ldr	x8, [x27]
    aa5c:      	ldrb	w9, [x10, #0x1]
    aa60:      	cmp	w9, #0x3
    aa64:      	b.gt	0xaba4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x56ec>
    aa68:      	cmp	w9, #0x1
    aa6c:      	b.eq	0xac64 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x57ac>
    aa70:      	cmp	w9, #0x2
    aa74:      	b.ne	0xae20 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5968>
    aa78:      	ldrh	w8, [x8]
    aa7c:      	str	x8, [x27]
    aa80:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    aa84:      	bti	j
    aa88:      	sub	x0, x29, #0x8
    aa8c:      	mov	x1, x20
    aa90:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    aa94:      	ldr	x8, [x27]
    aa98:      	add	x8, x8, x0
    aa9c:      	str	x8, [x27]
    aaa0:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    aaa4:      	bti	j
    aaa8:      	mov	x8, x27
    aaac:      	ldr	x9, [x27]
    aab0:      	ldr	x10, [x8, #-0x8]!
    aab4:      	asr	x9, x10, x9
    aab8:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    aabc:      	bti	j
    aac0:      	ldr	x8, [x27]
    aac4:      	ldr	x8, [x8]
    aac8:      	str	x8, [x27, #-0x8]!
    aacc:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    aad0:      	bti	j
    aad4:      	mov	x8, x27
    aad8:      	ldr	x9, [x27]
    aadc:      	ldr	x10, [x8, #-0x8]!
    aae0:      	mul	x9, x10, x9
    aae4:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    aae8:      	bti	j
    aaec:      	mov	x8, x27
    aaf0:      	ldr	x9, [x27]
    aaf4:      	ldr	x10, [x8, #-0x8]!
    aaf8:      	sub	x9, x10, x9
    aafc:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    ab00:      	bti	j
    ab04:      	mov	x8, x27
    ab08:      	ldr	x9, [x27]
    ab0c:      	ldr	x10, [x8, #-0x8]!
    ab10:      	orr	x9, x10, x9
    ab14:      	b	0xab44 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x568c>
    ab18:      	bti	j
    ab1c:      	ldr	x8, [x27]
    ab20:      	neg	x8, x8
    ab24:      	str	x8, [x27]
    ab28:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    ab2c:      	bti	j
    ab30:      	mov	x8, x27
    ab34:      	ldr	x9, [x27]
    ab38:      	ldr	x10, [x8, #-0x8]!
    ab3c:      	cmp	x10, x9
    ab40:      	cset	w9, ne
    ab44:      	str	x9, [x8]
    ab48:      	mov	x27, x8
    ab4c:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    ab50:      	bti	j
    ab54:      	ldursh	x8, [x10, #0x1]
    ab58:      	add	x8, x10, x8
    ab5c:      	add	x8, x8, #0x3
    ab60:      	stur	x8, [x29, #-0x8]
    ab64:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    ab68:      	bti	j
    ab6c:      	sub	x0, x29, #0x8
    ab70:      	mov	x1, x20
    ab74:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    ab78:      	cmp	w0, #0x1d
    ab7c:      	b.le	0xabb8 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5700>
    ab80:      	cmp	w0, #0x1f
    ab84:      	b.gt	0xac08 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5750>
    ab88:      	cmp	w0, #0x1e
    ab8c:      	mov	x8, x21
    ab90:      	b.eq	0xa57c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c4>
    ab94:      	cmp	w0, #0x1f
    ab98:      	mov	x8, x24
    ab9c:      	b.eq	0xa57c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c4>
    aba0:      	b	0xac20 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5768>
    aba4:      	cmp	w9, #0x4
    aba8:      	b.eq	0xac70 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x57b8>
    abac:      	cmp	w9, #0x8
    abb0:      	b.eq	0xa978 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x54c0>
    abb4:      	b	0xae20 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5968>
    abb8:      	cmn	w0, #0x2
    abbc:      	mov	x8, x24
    abc0:      	b.eq	0xa57c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c4>
    abc4:      	cmn	w0, #0x1
    abc8:      	mov	x8, x25
    abcc:      	b.eq	0xa57c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c4>
    abd0:      	cmp	w0, #0x1d
    abd4:      	mov	x8, x22
    abd8:      	b.eq	0xa57c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c4>
    abdc:      	b	0xac20 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5768>
    abe0:      	cmn	w0, #0x2
    abe4:      	mov	x10, x24
    abe8:      	b.eq	0xac54 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x579c>
    abec:      	cmn	w0, #0x1
    abf0:      	mov	x10, x25
    abf4:      	b.eq	0xac54 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x579c>
    abf8:      	cmp	w0, #0x1d
    abfc:      	mov	x10, x22
    ac00:      	b.eq	0xac54 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x579c>
    ac04:      	b	0xac48 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5790>
    ac08:      	cmp	w0, #0x20
    ac0c:      	mov	x8, x25
    ac10:      	b.eq	0xa57c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c4>
    ac14:      	cmp	w0, #0x22
    ac18:      	mov	x8, x23
    ac1c:      	b.eq	0xa57c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c4>
    ac20:      	cmp	w0, #0x1c
    ac24:      	b.hi	0xae88 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x59d0>
    ac28:      	add	x8, x19, w0, uxtw #3
    ac2c:      	b	0xa57c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c4>
    ac30:      	cmp	w0, #0x20
    ac34:      	mov	x10, x25
    ac38:      	b.eq	0xac54 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x579c>
    ac3c:      	cmp	w0, #0x22
    ac40:      	mov	x10, x23
    ac44:      	b.eq	0xac54 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x579c>
    ac48:      	cmp	w0, #0x1c
    ac4c:      	b.hi	0xae54 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x599c>
    ac50:      	add	x10, x19, w0, uxtw #3
    ac54:      	ldr	x10, [x10]
    ac58:      	orr	x8, x8, x9
    ac5c:      	add	x8, x10, x8
    ac60:      	b	0xa580 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50c8>
    ac64:      	ldrb	w8, [x8]
    ac68:      	str	x8, [x27]
    ac6c:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    ac70:      	ldr	w8, [x8]
    ac74:      	str	x8, [x27]
    ac78:      	b	0xa584 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x50cc>
    ac7c:      	ldr	x21, [x27]
    ac80:      	mov	x0, x21
    ac84:      	add	sp, sp, #0x330
    ac88:      	ldp	x20, x19, [sp, #0x50]
    ac8c:      	ldp	x22, x21, [sp, #0x40]
    ac90:      	ldp	x24, x23, [sp, #0x30]
    ac94:      	ldp	x26, x25, [sp, #0x20]
    ac98:      	ldp	x28, x27, [sp, #0x10]
    ac9c:      	ldp	x29, x30, [sp], #0x60
    aca0:      	autiasp
    aca4:      	ret
    aca8:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    acac:      	nop
    acb0:      	adr	x1, 0x1191
    acb4:      	ldr	x19, [x19, #0xe28]
    acb8:      	adrp	x2, 0x1000
    acbc:      	add	x2, x2, #0x710
    acc0:      	adrp	x3, 0x1000
    acc4:      	add	x3, x3, #0x48b
    acc8:      	add	x0, x19, #0x130
    accc:      	bl	0xbae0 <fprintf@plt>
    acd0:      	add	x0, x19, #0x130
    acd4:      	bl	0xbaf0 <fflush@plt>
    acd8:      	bl	0xbb00 <abort@plt>
    acdc:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    ace0:      	nop
    ace4:      	adr	x1, 0x1191
    ace8:      	ldr	x19, [x19, #0xe28]
    acec:      	adrp	x2, 0x1000
    acf0:      	add	x2, x2, #0x710
    acf4:      	adrp	x3, 0x1000
    acf8:      	add	x3, x3, #0x48b
    acfc:      	add	x0, x19, #0x130
    ad00:      	bl	0xbae0 <fprintf@plt>
    ad04:      	add	x0, x19, #0x130
    ad08:      	bl	0xbaf0 <fflush@plt>
    ad0c:      	bl	0xbb00 <abort@plt>
    ad10:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    ad14:      	nop
    ad18:      	adr	x1, 0x1191
    ad1c:      	ldr	x19, [x19, #0xe28]
    ad20:      	adrp	x2, 0x1000
    ad24:      	add	x2, x2, #0x710
    ad28:      	adrp	x3, 0x1000
    ad2c:      	add	x3, x3, #0x48b
    ad30:      	add	x0, x19, #0x130
    ad34:      	bl	0xbae0 <fprintf@plt>
    ad38:      	add	x0, x19, #0x130
    ad3c:      	bl	0xbaf0 <fflush@plt>
    ad40:      	bl	0xbb00 <abort@plt>
    ad44:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    ad48:      	nop
    ad4c:      	adr	x1, 0x1191
    ad50:      	ldr	x19, [x19, #0xe28]
    ad54:      	adrp	x2, 0x1000
    ad58:      	add	x2, x2, #0x5dd
    ad5c:      	adrp	x3, 0x1000
    ad60:      	add	x3, x3, #0x434
    ad64:      	add	x0, x19, #0x130
    ad68:      	bl	0xbae0 <fprintf@plt>
    ad6c:      	add	x0, x19, #0x130
    ad70:      	bl	0xbaf0 <fflush@plt>
    ad74:      	bl	0xbb00 <abort@plt>
    ad78:      	bti	j
    ad7c:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    ad80:      	nop
    ad84:      	adr	x1, 0x1191
    ad88:      	ldr	x19, [x19, #0xe28]
    ad8c:      	adrp	x2, 0x1000
    ad90:      	add	x2, x2, #0x4ce
    ad94:      	adrp	x3, 0x1000
    ad98:      	add	x3, x3, #0x894
    ad9c:      	add	x0, x19, #0x130
    ada0:      	bl	0xbae0 <fprintf@plt>
    ada4:      	add	x0, x19, #0x130
    ada8:      	bl	0xbaf0 <fflush@plt>
    adac:      	bl	0xbb00 <abort@plt>
    adb0:      	bti	j
    adb4:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    adb8:      	nop
    adbc:      	adr	x1, 0x1191
    adc0:      	ldr	x19, [x19, #0xe28]
    adc4:      	adrp	x2, 0x1000
    adc8:      	add	x2, x2, #0x4ce
    adcc:      	adrp	x3, 0x1000
    add0:      	add	x3, x3, #0x4a8
    add4:      	add	x0, x19, #0x130
    add8:      	bl	0xbae0 <fprintf@plt>
    addc:      	add	x0, x19, #0x130
    ade0:      	bl	0xbaf0 <fflush@plt>
    ade4:      	bl	0xbb00 <abort@plt>
    ade8:      	bti	j
    adec:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    adf0:      	nop
    adf4:      	adr	x1, 0x1191
    adf8:      	ldr	x19, [x19, #0xe28]
    adfc:      	adrp	x2, 0x1000
    ae00:      	add	x2, x2, #0x4ce
    ae04:      	adrp	x3, 0x1000
    ae08:      	add	x3, x3, #0xb61
    ae0c:      	add	x0, x19, #0x130
    ae10:      	bl	0xbae0 <fprintf@plt>
    ae14:      	add	x0, x19, #0x130
    ae18:      	bl	0xbaf0 <fflush@plt>
    ae1c:      	bl	0xbb00 <abort@plt>
    ae20:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    ae24:      	nop
    ae28:      	adr	x1, 0x1191
    ae2c:      	ldr	x19, [x19, #0xe28]
    ae30:      	adrp	x2, 0x1000
    ae34:      	add	x2, x2, #0x4ce
    ae38:      	adrp	x3, 0x1000
    ae3c:      	add	x3, x3, #0x71b
    ae40:      	add	x0, x19, #0x130
    ae44:      	bl	0xbae0 <fprintf@plt>
    ae48:      	add	x0, x19, #0x130
    ae4c:      	bl	0xbaf0 <fflush@plt>
    ae50:      	bl	0xbb00 <abort@plt>
    ae54:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    ae58:      	nop
    ae5c:      	adr	x1, 0x1191
    ae60:      	ldr	x19, [x19, #0xe28]
    ae64:      	adrp	x2, 0x1000
    ae68:      	add	x2, x2, #0x5dd
    ae6c:      	adrp	x3, 0x1000
    ae70:      	add	x3, x3, #0x434
    ae74:      	add	x0, x19, #0x130
    ae78:      	bl	0xbae0 <fprintf@plt>
    ae7c:      	add	x0, x19, #0x130
    ae80:      	bl	0xbaf0 <fflush@plt>
    ae84:      	bl	0xbb00 <abort@plt>
    ae88:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    ae8c:      	nop
    ae90:      	adr	x1, 0x1191
    ae94:      	ldr	x19, [x19, #0xe28]
    ae98:      	adrp	x2, 0x1000
    ae9c:      	add	x2, x2, #0x5dd
    aea0:      	adrp	x3, 0x1000
    aea4:      	add	x3, x3, #0x434
    aea8:      	add	x0, x19, #0x130
    aeac:      	bl	0xbae0 <fprintf@plt>
    aeb0:      	add	x0, x19, #0x130
    aeb4:      	bl	0xbaf0 <fflush@plt>
    aeb8:      	bl	0xbb00 <abort@plt>
    aebc:      	paciasp
    aec0:      	stp	x29, x30, [sp, #-0x60]!
    aec4:      	stp	x28, x27, [sp, #0x10]
    aec8:      	stp	x26, x25, [sp, #0x20]
    aecc:      	stp	x24, x23, [sp, #0x30]
    aed0:      	stp	x22, x21, [sp, #0x40]
    aed4:      	stp	x20, x19, [sp, #0x50]
    aed8:      	mov	x29, sp
    aedc:      	sub	sp, sp, #0x6a0
    aee0:      	mov	w21, w3
    aee4:      	mov	x19, x2
    aee8:      	mov	x22, x1
    aeec:      	mov	x20, x0
    aef0:      	cbz	w3, 0xaf14 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5a5c>
    aef4:      	ldp	x2, x3, [x19, #0x10]
    aef8:      	add	x5, sp, #0x50
    aefc:      	ldr	x0, [x20, #0x8]
    af00:      	add	x6, sp, #0x18
    af04:      	mov	x1, x22
    af08:      	add	x4, x2, w21, uxtw
    af0c:      	bl	0xb3e4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5f2c>
    af10:      	tbnz	w0, #0x0, 0xb02c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5b74>
    af14:      	ldr	x2, [x19, #0x20]
    af18:      	cbz	x2, 0xaf38 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5a80>
    af1c:      	ldr	x0, [x20, #0x8]
    af20:      	ldr	w3, [x19, #0x28]
    af24:      	add	x4, sp, #0x50
    af28:      	add	x5, sp, #0x18
    af2c:      	mov	x1, x22
    af30:      	bl	0xb5ac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x60f4>
    af34:      	tbnz	w0, #0x0, 0xb02c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5b74>
    af38:      	ldr	x23, [x19]
    af3c:      	nop
    af40:      	adr	x0, 0x13fb4
    af44:      	bl	0xbb60 <pthread_rwlock_rdlock@plt>
    af48:      	adrp	x8, 0x13000
    af4c:      	adrp	x9, 0x13000
    af50:      	ldr	x8, [x8, #0xf98]
    af54:      	ldr	x9, [x9, #0xfa0]
    af58:      	cmp	x8, x9
    af5c:      	b.hs	0xb000 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5b48>
    af60:      	cmn	x23, #0x1
    af64:      	b.ne	0xaf78 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5ac0>
    af68:      	b	0xafac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5af4>
    af6c:      	add	x8, x8, #0x20
    af70:      	cmp	x8, x9
    af74:      	b.hs	0xb000 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5b48>
    af78:      	ldr	x10, [x8]
    af7c:      	cmp	x10, x23
    af80:      	b.ne	0xaf6c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5ab4>
    af84:      	ldr	x10, [x8, #0x8]
    af88:      	cmp	x10, x22
    af8c:      	b.hi	0xaf6c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5ab4>
    af90:      	ldr	x10, [x8, #0x10]
    af94:      	cmp	x10, x22
    af98:      	b.ls	0xaf6c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5ab4>
    af9c:      	b	0xafc4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5b0c>
    afa0:      	add	x8, x8, #0x20
    afa4:      	cmp	x8, x9
    afa8:      	b.hs	0xb000 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5b48>
    afac:      	ldr	x10, [x8, #0x8]
    afb0:      	cmp	x10, x22
    afb4:      	b.hi	0xafa0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5ae8>
    afb8:      	ldr	x10, [x8, #0x10]
    afbc:      	cmp	x10, x22
    afc0:      	b.ls	0xafa0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5ae8>
    afc4:      	ldr	x23, [x8, #0x18]
    afc8:      	nop
    afcc:      	adr	x0, 0x13fb4
    afd0:      	bl	0xbb20 <pthread_rwlock_unlock@plt>
    afd4:      	cbz	x23, 0xb00c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5b54>
    afd8:      	ldp	x2, x3, [x19, #0x10]
    afdc:      	add	x5, sp, #0x50
    afe0:      	ldr	x0, [x20, #0x8]
    afe4:      	add	x6, sp, #0x18
    afe8:      	mov	x1, x22
    afec:      	mov	x4, x23
    aff0:      	bl	0xb3e4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5f2c>
    aff4:      	tbz	w0, #0x0, 0xb00c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5b54>
    aff8:      	mov	w24, wzr
    affc:      	b	0xb030 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5b78>
    b000:      	nop
    b004:      	adr	x0, 0x13fb4
    b008:      	bl	0xbb20 <pthread_rwlock_unlock@plt>
    b00c:      	ldp	x2, x3, [x19, #0x10]
    b010:      	add	x5, sp, #0x50
    b014:      	ldr	x0, [x20, #0x8]
    b018:      	add	x6, sp, #0x18
    b01c:      	mov	x1, x22
    b020:      	mov	x4, xzr
    b024:      	bl	0xb3e4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5f2c>
    b028:      	tbz	w0, #0x0, 0xb168 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5cb0>
    b02c:      	mov	w24, #0x1               // =1
    b030:      	ldr	x25, [x19]
    b034:      	add	x0, sp, #0x80
    b038:      	mov	w1, wzr
    b03c:      	mov	w2, #0x618              // =1560
    b040:      	bl	0xbac0 <memset@plt>
    b044:      	ldr	x0, [x20, #0x8]
    b048:      	add	x1, sp, #0x50
    b04c:      	add	x2, sp, #0x18
    b050:      	add	x5, sp, #0x80
    b054:      	mov	x3, x22
    b058:      	mov	w4, #0x4                // =4
    b05c:      	bl	0x9020 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x3b68>
    b060:      	tbz	w0, #0x0, 0xb168 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5cb0>
    b064:      	ldr	q0, [sp, #0x70]
    b068:      	add	x8, x20, #0x220
    b06c:      	ldr	x9, [sp, #0x38]
    b070:      	ldr	x22, [sp, #0x68]
    b074:      	cmp	w21, #0x0
    b078:      	mov	w0, #0x1                // =1
    b07c:      	stur	q0, [x8, #0x8]
    b080:      	ldr	w8, [sp, #0x90]
    b084:      	str	x9, [x20, #0x238]
    b088:      	eor	w9, w24, #0x1
    b08c:      	str	x8, [x20, #0x240]
    b090:      	mov	w8, #0x3000000          // =50331648
    b094:      	str	w8, [x20, #0x250]
    b098:      	ldp	x23, x8, [sp, #0x50]
    b09c:      	str	x22, [x20, #0x220]
    b0a0:      	str	xzr, [x20, #0x248]
    b0a4:      	str	w8, [x20, #0x254]
    b0a8:      	csinc	w8, w9, wzr, eq
    b0ac:      	str	x23, [x20, #0x258]
    b0b0:      	str	x25, [x20, #0x260]
    b0b4:      	tbnz	w8, #0x0, 0xb16c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5cb4>
    b0b8:      	ldr	x8, [x19, #0x20]
    b0bc:      	cbnz	x8, 0xb16c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5cb4>
    b0c0:      	ldr	x24, [x19]
    b0c4:      	nop
    b0c8:      	adr	x0, 0x13fb4
    b0cc:      	str	q0, [sp]
    b0d0:      	bl	0xbb10 <pthread_rwlock_wrlock@plt>
    b0d4:      	adrp	x25, 0x13000
    b0d8:      	adrp	x26, 0x13000
    b0dc:      	ldr	x8, [x25, #0xfa0]
    b0e0:      	ldr	x9, [x26, #0xfa8]
    b0e4:      	cmp	x8, x9
    b0e8:      	b.lo	0xb13c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5c84>
    b0ec:      	adrp	x27, 0x13000
    b0f0:      	ldr	x21, [x27, #0xf98]
    b0f4:      	sub	x19, x9, x21
    b0f8:      	lsl	x0, x19, #2
    b0fc:      	asr	x28, x19, #3
    b100:      	bl	0xbb30 <malloc@plt>
    b104:      	mov	x1, x21
    b108:      	mov	x2, x19
    b10c:      	mov	x20, x0
    b110:      	bl	0xb9b0 <memcpy@plt>
    b114:      	nop
    b118:      	adr	x8, 0x13ff0
    b11c:      	cmp	x21, x8
    b120:      	b.eq	0xb12c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5c74>
    b124:      	mov	x0, x21
    b128:      	bl	0xbb40 <free@plt>
    b12c:      	add	x9, x20, x28, lsl #5
    b130:      	add	x8, x20, x19
    b134:      	str	x20, [x27, #0xf98]
    b138:      	str	x9, [x26, #0xfa8]
    b13c:      	ldr	q0, [sp]
    b140:      	stp	x24, x22, [x8]
    b144:      	nop
    b148:      	adr	x0, 0x13fb4
    b14c:      	str	x23, [x8, #0x18]
    b150:      	str	d0, [x8, #0x10]
    b154:      	add	x8, x8, #0x20
    b158:      	str	x8, [x25, #0xfa0]
    b15c:      	bl	0xbb20 <pthread_rwlock_unlock@plt>
    b160:      	mov	w0, #0x1                // =1
    b164:      	b	0xb16c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5cb4>
    b168:      	mov	w0, wzr
    b16c:      	add	sp, sp, #0x6a0
    b170:      	ldp	x20, x19, [sp, #0x50]
    b174:      	ldp	x22, x21, [sp, #0x40]
    b178:      	ldp	x24, x23, [sp, #0x30]
    b17c:      	ldp	x26, x25, [sp, #0x20]
    b180:      	ldp	x28, x27, [sp, #0x10]
    b184:      	ldp	x29, x30, [sp], #0x60
    b188:      	autiasp
    b18c:      	ret
    b190:      	paciasp
    b194:      	sub	sp, sp, #0x70
    b198:      	stp	x29, x30, [sp, #0x20]
    b19c:      	str	x25, [sp, #0x30]
    b1a0:      	stp	x24, x23, [sp, #0x40]
    b1a4:      	stp	x22, x21, [sp, #0x50]
    b1a8:      	stp	x20, x19, [sp, #0x60]
    b1ac:      	add	x29, sp, #0x20
    b1b0:      	ldrh	w21, [x0, #0x18]
    b1b4:      	cbz	x21, 0xb1d0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5d18>
    b1b8:      	ldr	x8, [x2, #0x10]
    b1bc:      	ldr	x22, [x0]
    b1c0:      	mov	x20, x0
    b1c4:      	mov	x19, x2
    b1c8:      	cmp	x8, x22
    b1cc:      	b.hs	0xb1f4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5d3c>
    b1d0:      	mov	w0, wzr
    b1d4:      	ldp	x20, x19, [sp, #0x60]
    b1d8:      	ldr	x25, [sp, #0x30]
    b1dc:      	ldp	x22, x21, [sp, #0x50]
    b1e0:      	ldp	x24, x23, [sp, #0x40]
    b1e4:      	ldp	x29, x30, [sp, #0x20]
    b1e8:      	add	sp, sp, #0x70
    b1ec:      	autiasp
    b1f0:      	ret
    b1f4:      	ldr	x11, [x20, #0x10]
    b1f8:      	mov	x9, x21
    b1fc:      	mov	x10, x11
    b200:      	b	0xb210 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5d58>
    b204:      	subs	x9, x9, #0x1
    b208:      	mov	x11, x10
    b20c:      	b.eq	0xb1d0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5d18>
    b210:      	ldr	w12, [x10], #0x38
    b214:      	cmp	w12, #0x1
    b218:      	b.ne	0xb204 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5d4c>
    b21c:      	ldr	x12, [x11, #0x10]
    b220:      	add	x12, x12, x22
    b224:      	cmp	x8, x12
    b228:      	b.lo	0xb204 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5d4c>
    b22c:      	ldr	x11, [x11, #0x28]
    b230:      	add	x13, x11, x12
    b234:      	cmp	x8, x13
    b238:      	b.hs	0xb204 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5d4c>
    b23c:      	ldr	x8, [x19, #0x8]
    b240:      	mov	w9, #-0x1               // =-1
    b244:      	mov	w25, #0xe550            // =58704
    b248:      	add	x23, x21, x9
    b24c:      	mov	w24, #0x38              // =56
    b250:      	movk	w25, #0x6474, lsl #16
    b254:      	stp	x12, x11, [x8]
    b258:      	b	0xb26c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5db4>
    b25c:      	sub	w21, w21, #0x1
    b260:      	sub	x23, x23, #0x1
    b264:      	and	w8, w21, #0xffff
    b268:      	cbz	w8, 0xb1d0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5d18>
    b26c:      	and	x8, x23, #0xffffffff
    b270:      	ldr	x9, [x20, #0x10]
    b274:      	umull	x10, w8, w24
    b278:      	ldr	w10, [x9, x10]
    b27c:      	cmp	w10, w25
    b280:      	b.ne	0xb25c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5da4>
    b284:      	umaddl	x8, w8, w24, x9
    b288:      	ldp	x0, x10, [x19]
    b28c:      	mov	x3, sp
    b290:      	ldr	x9, [x8, #0x10]
    b294:      	ldr	x8, [x8, #0x28]
    b298:      	add	x1, x9, x22
    b29c:      	add	x2, x8, x1
    b2a0:      	stp	x1, x8, [x10, #0x20]
    b2a4:      	bl	0xb2c4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5e0c>
    b2a8:      	tbz	w0, #0x0, 0xb25c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5da4>
    b2ac:      	ldr	x8, [sp]
    b2b0:      	ldr	x9, [x19, #0x8]
    b2b4:      	mov	x10, #-0x1              // =-1
    b2b8:      	mov	w0, #0x1                // =1
    b2bc:      	stp	x8, x10, [x9, #0x10]
    b2c0:      	b	0xb1d4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5d1c>
    b2c4:      	paciasp
    b2c8:      	stp	x29, x30, [sp, #-0x40]!
    b2cc:      	str	x23, [sp, #0x10]
    b2d0:      	stp	x22, x21, [sp, #0x20]
    b2d4:      	stp	x20, x19, [sp, #0x30]
    b2d8:      	mov	x29, sp
    b2dc:      	mov	x20, x3
    b2e0:      	sub	x3, x2, x1
    b2e4:      	mov	x19, x1
    b2e8:      	cmp	x3, #0x3
    b2ec:      	b.hi	0xb318 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5e60>
    b2f0:      	cmp	x2, x19
    b2f4:      	b.eq	0xb3a0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5ee8>
    b2f8:      	adrp	x20, 0xf000 <fwrite@plt+0x3470>
    b2fc:      	adrp	x1, 0x1000
    b300:      	add	x1, x1, #0x7a4
    b304:      	ldr	x20, [x20, #0xe28]
    b308:      	mov	x2, x19
    b30c:      	add	x0, x20, #0x130
    b310:      	bl	0xbae0 <fprintf@plt>
    b314:      	b	0xb398 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5ee0>
    b318:      	ldrb	w8, [x19]
    b31c:      	cmp	w8, #0x1
    b320:      	b.ne	0xb378 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5ec0>
    b324:      	add	x8, x19, #0x4
    b328:      	ldrb	w21, [x19, #0x2]
    b32c:      	ldrb	w3, [x19, #0x1]
    b330:      	str	x8, [x29, #0x18]
    b334:      	add	x1, x29, #0x18
    b338:      	mov	x4, x19
    b33c:      	ldrb	w8, [x19, #0x3]
    b340:      	mov	x23, x0
    b344:      	mov	x22, x2
    b348:      	strb	w8, [x20, #0x18]
    b34c:      	bl	0x9fac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4af4>
    b350:      	cmp	w21, #0xff
    b354:      	str	x0, [x20]
    b358:      	b.eq	0xb3bc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5f04>
    b35c:      	add	x1, x29, #0x18
    b360:      	mov	x0, x23
    b364:      	mov	x2, x22
    b368:      	mov	w3, w21
    b36c:      	mov	x4, x19
    b370:      	bl	0x9fac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4af4>
    b374:      	b	0xb3c0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5f08>
    b378:      	adrp	x20, 0xf000 <fwrite@plt+0x3470>
    b37c:      	adrp	x1, 0x1000
    b380:      	add	x1, x1, #0x3eb
    b384:      	ldr	x20, [x20, #0xe28]
    b388:      	mov	w2, w8
    b38c:      	mov	x3, x19
    b390:      	add	x0, x20, #0x130
    b394:      	bl	0xbae0 <fprintf@plt>
    b398:      	add	x0, x20, #0x130
    b39c:      	bl	0xbaf0 <fflush@plt>
    b3a0:      	mov	w0, wzr
    b3a4:      	ldp	x20, x19, [sp, #0x30]
    b3a8:      	ldr	x23, [sp, #0x10]
    b3ac:      	ldp	x22, x21, [sp, #0x20]
    b3b0:      	ldp	x29, x30, [sp], #0x40
    b3b4:      	autiasp
    b3b8:      	ret
    b3bc:      	mov	x0, xzr
    b3c0:      	ldr	x8, [x29, #0x18]
    b3c4:      	stp	x0, x8, [x20, #0x8]
    b3c8:      	mov	w0, #0x1                // =1
    b3cc:      	ldp	x20, x19, [sp, #0x30]
    b3d0:      	ldr	x23, [sp, #0x10]
    b3d4:      	ldp	x22, x21, [sp, #0x20]
    b3d8:      	ldp	x29, x30, [sp], #0x40
    b3dc:      	autiasp
    b3e0:      	ret
    b3e4:      	paciasp
    b3e8:      	sub	sp, sp, #0x70
    b3ec:      	stp	x29, x30, [sp, #0x10]
    b3f0:      	stp	x28, x27, [sp, #0x20]
    b3f4:      	stp	x26, x25, [sp, #0x30]
    b3f8:      	stp	x24, x23, [sp, #0x40]
    b3fc:      	stp	x22, x21, [sp, #0x50]
    b400:      	stp	x20, x19, [sp, #0x60]
    b404:      	add	x29, sp, #0x10
    b408:      	cmp	x4, #0x0
    b40c:      	add	x8, x3, x2
    b410:      	csel	x22, x2, x4, eq
    b414:      	cmn	x3, #0x1
    b418:      	csinv	x27, x8, xzr, ne
    b41c:      	str	x22, [sp, #0x8]
    b420:      	cmp	x22, x27
    b424:      	b.hs	0xb568 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x60b0>
    b428:      	mov	x21, x6
    b42c:      	mov	x19, x5
    b430:      	mov	x23, x2
    b434:      	mov	x24, x1
    b438:      	mov	x20, x0
    b43c:      	b	0xb44c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5f94>
    b440:      	cmp	x22, x27
    b444:      	str	x22, [sp, #0x8]
    b448:      	b.hs	0xb568 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x60b0>
    b44c:      	mov	x8, x22
    b450:      	mov	x26, x22
    b454:      	ldr	w9, [x8], #0x4
    b458:      	str	x8, [sp, #0x8]
    b45c:      	cmn	w9, #0x1
    b460:      	b.ne	0xb470 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5fb8>
    b464:      	ldur	x9, [x26, #0x4]
    b468:      	add	x8, x26, #0xc
    b46c:      	str	x8, [sp, #0x8]
    b470:      	cbz	x9, 0xb568 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x60b0>
    b474:      	ldr	w10, [x8]
    b478:      	add	x22, x8, x9
    b47c:      	cbz	w10, 0xb440 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5f88>
    b480:      	sub	x1, x8, x10
    b484:      	cmp	x1, x23
    b488:      	b.lo	0xb440 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5f88>
    b48c:      	cmp	x1, x27
    b490:      	b.hs	0xb440 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5f88>
    b494:      	mov	x0, x20
    b498:      	mov	x2, x21
    b49c:      	bl	0x8154 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2c9c>
    b4a0:      	cbnz	x0, 0xb440 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5f88>
    b4a4:      	ldr	x8, [sp, #0x8]
    b4a8:      	ldrb	w3, [x21, #0x18]
    b4ac:      	add	x1, sp, #0x8
    b4b0:      	mov	x0, x20
    b4b4:      	mov	x2, x22
    b4b8:      	mov	x4, xzr
    b4bc:      	add	x8, x8, #0x4
    b4c0:      	str	x8, [sp, #0x8]
    b4c4:      	bl	0x9fac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4af4>
    b4c8:      	ldrb	w8, [x21, #0x18]
    b4cc:      	mov	x25, x0
    b4d0:      	add	x1, sp, #0x8
    b4d4:      	mov	x0, x20
    b4d8:      	mov	x2, x22
    b4dc:      	mov	x4, xzr
    b4e0:      	and	w3, w8, #0xf
    b4e4:      	bl	0x9fac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4af4>
    b4e8:      	cmp	x25, x24
    b4ec:      	b.hs	0xb440 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5f88>
    b4f0:      	add	x28, x0, x25
    b4f4:      	cmp	x28, x24
    b4f8:      	b.lo	0xb440 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5f88>
    b4fc:      	ldrb	w8, [x21, #0x31]
    b500:      	str	xzr, [x19, #0x28]
    b504:      	cbz	w8, 0xb590 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x60d8>
    b508:      	add	x0, sp, #0x8
    b50c:      	mov	x1, x22
    b510:      	bl	0xa338 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4e80>
    b514:      	ldrb	w8, [x21, #0x19]
    b518:      	ldr	x24, [sp, #0x8]
    b51c:      	cmp	w8, #0xff
    b520:      	add	x23, x24, x0
    b524:      	b.eq	0xb594 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x60dc>
    b528:      	add	x1, sp, #0x8
    b52c:      	and	w3, w8, #0xf
    b530:      	mov	x0, x20
    b534:      	mov	x2, x22
    b538:      	mov	x4, xzr
    b53c:      	bl	0x9fac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4af4>
    b540:      	cbz	x0, 0xb594 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x60dc>
    b544:      	ldrb	w3, [x21, #0x19]
    b548:      	add	x1, sp, #0x8
    b54c:      	mov	x0, x20
    b550:      	mov	x2, x22
    b554:      	mov	x4, xzr
    b558:      	str	x24, [sp, #0x8]
    b55c:      	bl	0x9fac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4af4>
    b560:      	str	x0, [x19, #0x28]
    b564:      	b	0xb594 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x60dc>
    b568:      	mov	w0, wzr
    b56c:      	ldp	x20, x19, [sp, #0x60]
    b570:      	ldp	x22, x21, [sp, #0x50]
    b574:      	ldp	x24, x23, [sp, #0x40]
    b578:      	ldp	x26, x25, [sp, #0x30]
    b57c:      	ldp	x28, x27, [sp, #0x20]
    b580:      	ldp	x29, x30, [sp, #0x10]
    b584:      	add	sp, sp, #0x70
    b588:      	autiasp
    b58c:      	ret
    b590:      	ldr	x23, [sp, #0x8]
    b594:      	sub	x8, x22, x26
    b598:      	stp	x23, x25, [x19, #0x10]
    b59c:      	mov	w0, #0x1                // =1
    b5a0:      	stp	x26, x8, [x19]
    b5a4:      	str	x28, [x19, #0x20]
    b5a8:      	b	0xb56c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x60b4>
    b5ac:      	paciasp
    b5b0:      	sub	sp, sp, #0xa0
    b5b4:      	stp	x29, x30, [sp, #0x40]
    b5b8:      	stp	x28, x27, [sp, #0x50]
    b5bc:      	stp	x26, x25, [sp, #0x60]
    b5c0:      	stp	x24, x23, [sp, #0x70]
    b5c4:      	stp	x22, x21, [sp, #0x80]
    b5c8:      	stp	x20, x19, [sp, #0x90]
    b5cc:      	add	x29, sp, #0x40
    b5d0:      	add	x24, x2, w3, uxtw
    b5d4:      	mov	x23, x2
    b5d8:      	mov	x20, x1
    b5dc:      	add	x3, sp, #0x20
    b5e0:      	mov	x1, x2
    b5e4:      	mov	x21, x5
    b5e8:      	mov	x2, x24
    b5ec:      	mov	x19, x4
    b5f0:      	mov	x22, x0
    b5f4:      	bl	0xb2c4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x5e0c>
    b5f8:      	tbz	w0, #0x0, 0xb6ec <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6234>
    b5fc:      	ldr	x8, [sp, #0x28]
    b600:      	cbz	x8, 0xb6ec <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6234>
    b604:      	ldrb	w0, [sp, #0x38]
    b608:      	stp	x21, x19, [sp, #0x8]
    b60c:      	bl	0xb714 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x625c>
    b610:      	ldr	x27, [sp, #0x28]
    b614:      	mov	x25, x0
    b618:      	mov	x26, xzr
    b61c:      	cmp	x27, #0x1
    b620:      	b.ls	0xb66c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x61b4>
    b624:      	lsr	x21, x27, #1
    b628:      	ldr	x8, [sp, #0x30]
    b62c:      	ldrb	w3, [sp, #0x38]
    b630:      	add	x1, sp, #0x18
    b634:      	mov	x0, x22
    b638:      	mov	x2, x24
    b63c:      	add	x19, x21, x26
    b640:      	mov	x4, x23
    b644:      	mul	x28, x19, x25
    b648:      	add	x8, x8, x28
    b64c:      	str	x8, [sp, #0x18]
    b650:      	bl	0x9fac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4af4>
    b654:      	sub	x8, x27, x21
    b658:      	cmp	x0, x20
    b65c:      	csel	x26, x26, x19, hs
    b660:      	csel	x27, x21, x8, hs
    b664:      	b.ne	0xb61c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6164>
    b668:      	b	0xb670 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x61b8>
    b66c:      	mul	x28, x26, x25
    b670:      	ldr	x8, [sp, #0x30]
    b674:      	ldrb	w25, [sp, #0x38]
    b678:      	add	x1, sp, #0x18
    b67c:      	mov	x0, x22
    b680:      	mov	x2, x24
    b684:      	mov	x4, x23
    b688:      	add	x8, x8, x28
    b68c:      	mov	w3, w25
    b690:      	str	x8, [sp, #0x18]
    b694:      	bl	0x9fac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4af4>
    b698:      	add	x1, sp, #0x18
    b69c:      	mov	x0, x22
    b6a0:      	mov	x2, x24
    b6a4:      	mov	w3, w25
    b6a8:      	mov	x4, x23
    b6ac:      	bl	0x9fac <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x4af4>
    b6b0:      	ldp	x3, x19, [sp, #0x8]
    b6b4:      	mov	x1, x0
    b6b8:      	mov	x0, x22
    b6bc:      	mov	w4, wzr
    b6c0:      	mov	x2, x19
    b6c4:      	bl	0x7fc4 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x2b0c>
    b6c8:      	cbnz	x0, 0xb6ec <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6234>
    b6cc:      	ldr	x8, [x19, #0x18]
    b6d0:      	cmp	x8, x20
    b6d4:      	b.hi	0xb6ec <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6234>
    b6d8:      	ldr	x8, [x19, #0x20]
    b6dc:      	cmp	x8, x20
    b6e0:      	b.ls	0xb6ec <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6234>
    b6e4:      	mov	w0, #0x1                // =1
    b6e8:      	b	0xb6f0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6238>
    b6ec:      	mov	w0, wzr
    b6f0:      	ldp	x20, x19, [sp, #0x90]
    b6f4:      	ldp	x22, x21, [sp, #0x80]
    b6f8:      	ldp	x24, x23, [sp, #0x70]
    b6fc:      	ldp	x26, x25, [sp, #0x60]
    b700:      	ldp	x28, x27, [sp, #0x50]
    b704:      	ldp	x29, x30, [sp, #0x40]
    b708:      	add	sp, sp, #0xa0
    b70c:      	autiasp
    b710:      	ret
    b714:      	paciasp
    b718:      	stp	x29, x30, [sp, #-0x20]!
    b71c:      	str	x19, [sp, #0x10]
    b720:      	mov	x29, sp
    b724:      	and	w8, w0, #0xf
    b728:      	mov	w0, #0x4                // =4
    b72c:      	cmp	w8, #0x8
    b730:      	b.gt	0xb750 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6298>
    b734:      	cmp	w8, #0x2
    b738:      	b.le	0xb790 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x62d8>
    b73c:      	cmp	w8, #0x3
    b740:      	b.eq	0xb768 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x62b0>
    b744:      	cmp	w8, #0x4
    b748:      	b.eq	0xb77c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x62c4>
    b74c:      	b	0xb79c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x62e4>
    b750:      	cmp	w8, #0xa
    b754:      	b.le	0xb7d0 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6318>
    b758:      	cmp	w8, #0xc
    b75c:      	b.eq	0xb77c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x62c4>
    b760:      	cmp	w8, #0xb
    b764:      	b.ne	0xb79c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x62e4>
    b768:      	mov	w0, #0x8                // =8
    b76c:      	ldr	x19, [sp, #0x10]
    b770:      	ldp	x29, x30, [sp], #0x20
    b774:      	autiasp
    b778:      	ret
    b77c:      	mov	w0, #0x10               // =16
    b780:      	ldr	x19, [sp, #0x10]
    b784:      	ldp	x29, x30, [sp], #0x20
    b788:      	autiasp
    b78c:      	ret
    b790:      	b.eq	0xb76c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x62b4>
    b794:      	cmp	w8, #0x1
    b798:      	b.eq	0xb7dc <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x6324>
    b79c:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    b7a0:      	nop
    b7a4:      	adr	x1, 0x1191
    b7a8:      	ldr	x19, [x19, #0xe28]
    b7ac:      	adrp	x2, 0x1000
    b7b0:      	add	x2, x2, #0x479
    b7b4:      	adrp	x3, 0x1000
    b7b8:      	add	x3, x3, #0x96a
    b7bc:      	add	x0, x19, #0x130
    b7c0:      	bl	0xbae0 <fprintf@plt>
    b7c4:      	add	x0, x19, #0x130
    b7c8:      	bl	0xbaf0 <fflush@plt>
    b7cc:      	bl	0xbb00 <abort@plt>
    b7d0:      	b.eq	0xb76c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x62b4>
    b7d4:      	cmp	w8, #0x9
    b7d8:      	b.ne	0xb79c <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x62e4>
    b7dc:      	adrp	x19, 0xf000 <fwrite@plt+0x3470>
    b7e0:      	nop
    b7e4:      	adr	x1, 0x1191
    b7e8:      	ldr	x19, [x19, #0xe28]
    b7ec:      	adrp	x2, 0x1000
    b7f0:      	add	x2, x2, #0x479
    b7f4:      	adrp	x3, 0x1000
    b7f8:      	add	x3, x3, #0x322
    b7fc:      	add	x0, x19, #0x130
    b800:      	bl	0xbae0 <fprintf@plt>
    b804:      	add	x0, x19, #0x130
    b808:      	bl	0xbaf0 <fflush@plt>
    b80c:      	bl	0xbb00 <abort@plt>
    b810:      	bti	c
    b814:      	add	w8, w0, #0x2
    b818:      	cmp	w8, #0x61
    b81c:      	b.hi	0xb834 <Java_com_meitu_library_httpsign_algorithm_NativeSign_send+0x637c>
    b820:      	nop
    b824:      	adr	x9, 0x4254
    b828:      	ldrsw	x8, [x9, w8, uxtw #2]
    b82c:      	add	x0, x9, x8
    b830:      	ret
    b834:      	adrp	x0, 0x1000
    b838:      	add	x0, x0, #0x925
    b83c:      	ret
    b840:      	bti	c
    b844:      	ldp	x2, x3, [x0, #0x10]
    b848:      	ldp	x4, x5, [x0, #0x20]
    b84c:      	ldp	x6, x7, [x0, #0x30]
    b850:      	ldp	x8, x9, [x0, #0x40]
    b854:      	ldp	x10, x11, [x0, #0x50]
    b858:      	ldp	x12, x13, [x0, #0x60]
    b85c:      	ldp	x14, x15, [x0, #0x70]
    b860:      	ldp	x18, x19, [x0, #0x90]
    b864:      	ldp	x20, x21, [x0, #0xa0]
    b868:      	ldp	x22, x23, [x0, #0xb0]
    b86c:      	ldp	x24, x25, [x0, #0xc0]
    b870:      	ldp	x26, x27, [x0, #0xd0]
    b874:      	ldp	x28, x29, [x0, #0xe0]
    b878:      	ldr	x30, [x0, #0x100]
    b87c:      	ldp	d0, d1, [x0, #0x110]
    b880:      	ldp	d2, d3, [x0, #0x120]
    b884:      	ldp	d4, d5, [x0, #0x130]
    b888:      	ldp	d6, d7, [x0, #0x140]
    b88c:      	ldp	d8, d9, [x0, #0x150]
    b890:      	ldp	d10, d11, [x0, #0x160]
    b894:      	ldp	d12, d13, [x0, #0x170]
    b898:      	ldp	d14, d15, [x0, #0x180]
    b89c:      	ldp	d16, d17, [x0, #0x190]
    b8a0:      	ldp	d18, d19, [x0, #0x1a0]
    b8a4:      	ldp	d20, d21, [x0, #0x1b0]
    b8a8:      	ldp	d22, d23, [x0, #0x1c0]
    b8ac:      	ldp	d24, d25, [x0, #0x1d0]
    b8b0:      	ldp	d26, d27, [x0, #0x1e0]
    b8b4:      	ldp	d28, d29, [x0, #0x1f0]
    b8b8:      	ldr	d30, [x0, #0x200]
    b8bc:      	ldr	d31, [x0, #0x208]
    b8c0:      	ldr	x16, [x0, #0xf8]
    b8c4:      	ldp	x0, x1, [x0]
    b8c8:      	mov	sp, x16
    b8cc:      	ret
    b8d0:      	bti	c
    b8d4:      	stp	x0, x1, [x0]
    b8d8:      	stp	x2, x3, [x0, #0x10]
    b8dc:      	stp	x4, x5, [x0, #0x20]
    b8e0:      	stp	x6, x7, [x0, #0x30]
    b8e4:      	stp	x8, x9, [x0, #0x40]
    b8e8:      	stp	x10, x11, [x0, #0x50]
    b8ec:      	stp	x12, x13, [x0, #0x60]
    b8f0:      	stp	x14, x15, [x0, #0x70]
    b8f4:      	stp	x16, x17, [x0, #0x80]
    b8f8:      	stp	x18, x19, [x0, #0x90]
    b8fc:      	stp	x20, x21, [x0, #0xa0]
    b900:      	stp	x22, x23, [x0, #0xb0]
    b904:      	stp	x24, x25, [x0, #0xc0]
    b908:      	stp	x26, x27, [x0, #0xd0]
    b90c:      	stp	x28, x29, [x0, #0xe0]
    b910:      	str	x30, [x0, #0xf0]
    b914:      	mov	x1, sp
    b918:      	str	x1, [x0, #0xf8]
    b91c:      	str	x30, [x0, #0x100]
    b920:      	stp	d0, d1, [x0, #0x110]
    b924:      	stp	d2, d3, [x0, #0x120]
    b928:      	stp	d4, d5, [x0, #0x130]
    b92c:      	stp	d6, d7, [x0, #0x140]
    b930:      	stp	d8, d9, [x0, #0x150]
    b934:      	stp	d10, d11, [x0, #0x160]
    b938:      	stp	d12, d13, [x0, #0x170]
    b93c:      	stp	d14, d15, [x0, #0x180]
    b940:      	stp	d16, d17, [x0, #0x190]
    b944:      	stp	d18, d19, [x0, #0x1a0]
    b948:      	stp	d20, d21, [x0, #0x1b0]
    b94c:      	stp	d22, d23, [x0, #0x1c0]
    b950:      	stp	d24, d25, [x0, #0x1d0]
    b954:      	stp	d26, d27, [x0, #0x1e0]
    b958:      	stp	d28, d29, [x0, #0x1f0]
    b95c:      	str	d30, [x0, #0x200]
    b960:      	str	d31, [x0, #0x208]
    b964:      	mov	x0, #0x0                // =0
    b968:      	ret

Disassembly of section .plt:

000000000000b970 <.plt>:
    b970:      	stp	x16, x30, [sp, #-0x10]!
    b974:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    b978:      	ldr	x17, [x16, #0xe40]
    b97c:      	add	x16, x16, #0xe40
    b980:      	br	x17
    b984:      	nop
    b988:      	nop
    b98c:      	nop

000000000000b990 <__cxa_finalize@plt>:
    b990:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    b994:      	ldr	x17, [x16, #0xe48]
    b998:      	add	x16, x16, #0xe48
    b99c:      	br	x17

000000000000b9a0 <__cxa_atexit@plt>:
    b9a0:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    b9a4:      	ldr	x17, [x16, #0xe50]
    b9a8:      	add	x16, x16, #0xe50
    b9ac:      	br	x17

000000000000b9b0 <memcpy@plt>:
    b9b0:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    b9b4:      	ldr	x17, [x16, #0xe58]
    b9b8:      	add	x16, x16, #0xe58
    b9bc:      	br	x17

000000000000b9c0 <strlen@plt>:
    b9c0:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    b9c4:      	ldr	x17, [x16, #0xe60]
    b9c8:      	add	x16, x16, #0xe60
    b9cc:      	br	x17

000000000000b9d0 <strcpy@plt>:
    b9d0:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    b9d4:      	ldr	x17, [x16, #0xe68]
    b9d8:      	add	x16, x16, #0xe68
    b9dc:      	br	x17

000000000000b9e0 <__stack_chk_fail@plt>:
    b9e0:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    b9e4:      	ldr	x17, [x16, #0xe70]
    b9e8:      	add	x16, x16, #0xe70
    b9ec:      	br	x17

000000000000b9f0 <_ZdaPv@plt>:
    b9f0:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    b9f4:      	ldr	x17, [x16, #0xe78]
    b9f8:      	add	x16, x16, #0xe78
    b9fc:      	br	x17

000000000000ba00 <_Znwm@plt>:
    ba00:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    ba04:      	ldr	x17, [x16, #0xe80]
    ba08:      	add	x16, x16, #0xe80
    ba0c:      	br	x17

000000000000ba10 <_ZdlPv@plt>:
    ba10:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    ba14:      	ldr	x17, [x16, #0xe88]
    ba18:      	add	x16, x16, #0xe88
    ba1c:      	br	x17

000000000000ba20 <gettimeofday@plt>:
    ba20:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    ba24:      	ldr	x17, [x16, #0xe90]
    ba28:      	add	x16, x16, #0xe90
    ba2c:      	br	x17

000000000000ba30 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc@plt>:
    ba30:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    ba34:      	ldr	x17, [x16, #0xe98]
    ba38:      	add	x16, x16, #0xe98
    ba3c:      	br	x17

000000000000ba40 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_@plt>:
    ba40:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    ba44:      	ldr	x17, [x16, #0xea0]
    ba48:      	add	x16, x16, #0xea0
    ba4c:      	br	x17

000000000000ba50 <_Znam@plt>:
    ba50:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    ba54:      	ldr	x17, [x16, #0xea8]
    ba58:      	add	x16, x16, #0xea8
    ba5c:      	br	x17

000000000000ba60 <__vsnprintf_chk@plt>:
    ba60:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    ba64:      	ldr	x17, [x16, #0xeb0]
    ba68:      	add	x16, x16, #0xeb0
    ba6c:      	br	x17

000000000000ba70 <__cxa_allocate_exception@plt>:
    ba70:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    ba74:      	ldr	x17, [x16, #0xeb8]
    ba78:      	add	x16, x16, #0xeb8
    ba7c:      	br	x17

000000000000ba80 <__cxa_throw@plt>:
    ba80:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    ba84:      	ldr	x17, [x16, #0xec0]
    ba88:      	add	x16, x16, #0xec0
    ba8c:      	br	x17

000000000000ba90 <__cxa_free_exception@plt>:
    ba90:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    ba94:      	ldr	x17, [x16, #0xec8]
    ba98:      	add	x16, x16, #0xec8
    ba9c:      	br	x17

000000000000baa0 <_ZNSt11logic_errorC2EPKc@plt>:
    baa0:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    baa4:      	ldr	x17, [x16, #0xed0]
    baa8:      	add	x16, x16, #0xed0
    baac:      	br	x17

000000000000bab0 <__memcpy_chk@plt>:
    bab0:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    bab4:      	ldr	x17, [x16, #0xed8]
    bab8:      	add	x16, x16, #0xed8
    babc:      	br	x17

000000000000bac0 <memset@plt>:
    bac0:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    bac4:      	ldr	x17, [x16, #0xee0]
    bac8:      	add	x16, x16, #0xee0
    bacc:      	br	x17

000000000000bad0 <_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc@plt>:
    bad0:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    bad4:      	ldr	x17, [x16, #0xee8]
    bad8:      	add	x16, x16, #0xee8
    badc:      	br	x17

000000000000bae0 <fprintf@plt>:
    bae0:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    bae4:      	ldr	x17, [x16, #0xef0]
    bae8:      	add	x16, x16, #0xef0
    baec:      	br	x17

000000000000baf0 <fflush@plt>:
    baf0:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    baf4:      	ldr	x17, [x16, #0xef8]
    baf8:      	add	x16, x16, #0xef8
    bafc:      	br	x17

000000000000bb00 <abort@plt>:
    bb00:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    bb04:      	ldr	x17, [x16, #0xf00]
    bb08:      	add	x16, x16, #0xf00
    bb0c:      	br	x17

000000000000bb10 <pthread_rwlock_wrlock@plt>:
    bb10:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    bb14:      	ldr	x17, [x16, #0xf08]
    bb18:      	add	x16, x16, #0xf08
    bb1c:      	br	x17

000000000000bb20 <pthread_rwlock_unlock@plt>:
    bb20:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    bb24:      	ldr	x17, [x16, #0xf10]
    bb28:      	add	x16, x16, #0xf10
    bb2c:      	br	x17

000000000000bb30 <malloc@plt>:
    bb30:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    bb34:      	ldr	x17, [x16, #0xf18]
    bb38:      	add	x16, x16, #0xf18
    bb3c:      	br	x17

000000000000bb40 <free@plt>:
    bb40:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    bb44:      	ldr	x17, [x16, #0xf20]
    bb48:      	add	x16, x16, #0xf20
    bb4c:      	br	x17

000000000000bb50 <dl_iterate_phdr@plt>:
    bb50:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    bb54:      	ldr	x17, [x16, #0xf28]
    bb58:      	add	x16, x16, #0xf28
    bb5c:      	br	x17

000000000000bb60 <pthread_rwlock_rdlock@plt>:
    bb60:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    bb64:      	ldr	x17, [x16, #0xf30]
    bb68:      	add	x16, x16, #0xf30
    bb6c:      	br	x17

000000000000bb70 <getpid@plt>:
    bb70:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    bb74:      	ldr	x17, [x16, #0xf38]
    bb78:      	add	x16, x16, #0xf38
    bb7c:      	br	x17

000000000000bb80 <syscall@plt>:
    bb80:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    bb84:      	ldr	x17, [x16, #0xf40]
    bb88:      	add	x16, x16, #0xf40
    bb8c:      	br	x17

000000000000bb90 <fwrite@plt>:
    bb90:      	adrp	x16, 0xf000 <fwrite@plt+0x3470>
    bb94:      	ldr	x17, [x16, #0xf48]
    bb98:      	add	x16, x16, #0xf48
    bb9c:      	br	x17
